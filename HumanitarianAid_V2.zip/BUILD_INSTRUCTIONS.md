# نظام إدارة المساعدات الإنسانية - دليل بناء تطبيق أندرويد (APK Build Guide)

هذا المشروع عبارة عن تطبيق أندرويد أصلي (Native Android App) مكتوب بلغة **Kotlin** مع واجهات **Jetpack Compose (Material 3)** وقاعدة بيانات محلية **Room Database** ويعمل بنمط **MVVM** وبدون الحاجة لإنترنت.

---

## 🛠️ متطلبات البناء:
1. **Android Studio**: إصدار Hedgehog (2023.1.1) أو أحدث (Iguana / Jellyfish / Koala).
2. **JDK**: الإصدار 17 (Java 17).
3. **Android SDK**: API 34 (Android 14) مع الحد الأدنى API 26 (Android 8.0).

---

## 🚀 خطوات فتح وبناء المشروع في Android Studio:

1. قم بفتح **Android Studio**.
2. اختر **Open Project** واختر المجلد `android`.
3. انتظر حتى يكتمل تزامن **Gradle Sync**.
4. لبناء ملف **APK التجريبي (`app-debug.apk`)**:
   - من القائمة العلوية: `Build` -> `Build Bundle(s) / APK(s)` -> `Build APK(s)`.
   - أو عبر سطر الأوامر من داخل مجلد `android`:
     ```bash
     ./gradlew assembleDebug
     ```
5. ستجد ملف الـ APK الناتج في المسار:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```
6. لتثبيته مباشرة على هاتفك المتصل عبر USB:
   ```bash
   adb install -r android/app/build/outputs/apk/debug/app-debug.apk
   ```

---

## 🔒 بيانات الدخول الافتراضية:
- **اسم المستخدم:** `admin`
- **كلمة المرور:** `admin123`
- **الصلاحية:** مدير النظام (وصول كامل لجميع المحليات والعمليات).

---

## 📂 هيكلية المشروع:
- `data/local/entities/`: الكيانات وجداول قاعدة البيانات (Users, Roles, Localities, Families, Children, AidTypes, AidRecords, Selections).
- `data/local/dao/`: استعلامات Room المعززة بفلاتر نطاق المحليات والبحث وتصفية التواريخ.
- `data/repository/`: نمط Repository لإدارة الجلسات والصلاحيات.
- `data/security/`: تشفير كلمات المرور وفحص محاولات القفل المؤقت.
- `engine/NominationEngine.kt`: محرك الترشيح الآلي ومنع التكرار وترحيل المرشحين.
- `ui/screens/`: شاشات Jetpack Compose متوافقة 100% مع اتجاه RTL والألوان الإنسانية.
