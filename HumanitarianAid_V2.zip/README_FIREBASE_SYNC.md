# دليل مزامنة Firebase Delta Sync

## الهيكلية:
- **FirebaseSyncManager**: يتولى إرسال التحديثات المحلية واستقبال التغييرات من السحابة.
- **SyncDelta**: يمثل الفروقات المزامنة وسجلات العمليات (`ADD`, `UPDATE`, `DELETE`).
- **FirebaseSyncListener**: استماع مباشر للتغييرات الفورية وإشعار المستخدم.
