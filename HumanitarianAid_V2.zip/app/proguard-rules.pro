# ProGuard / R8 rules for Humanitarian Aid Management App
-keep class com.humanitarian.aidmanagement.data.local.entities.** { *; }
-dontwarn org.mindrot.jbcrypt.**
