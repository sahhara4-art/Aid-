package com.humanitarian.aidmanagement.data.local.dao

import androidx.room.*
import com.humanitarian.aidmanagement.data.local.entities.*
import kotlinx.coroutines.flow.Flow

/**
 * كائن المحلية الديناميكية المستخرجة مباشرة من استعلام DISTINCT
 * بدون أي محليات ثابتة مبرمجة مسبقاً (No Hardcoded Localities)
 */
data class DynamicLocality(
    val localityID: Int,
    val localityName: String
)

/**
 * كائن إحصائيات المحليات المحسوبة ديناميكياً من استعلام GROUP BY
 * للأسر المستوفية للشرطين: حالة التنمية = 'معتمد' وحالة الإقامة = 'مقيم'
 */
data class DynamicLocalityStat(
    val localityName: String,
    val totalCount: Int
)

data class LocalityStatistic(
    val localityID: Int,
    val localityName: String,
    val approvedResidentFamiliesCount: Int,
    val approvedResidentBeneficiariesCount: Int,
    val aidDistributionCount: Int
)

data class AidTypeStatistic(
    val aidTypeID: Int,
    val aidTypeName: String,
    val totalAidCount: Int,
    val totalAidValue: Double
)

@Dao
interface UserDao {
    @Query("SELECT * FROM Users WHERE userName = :userName LIMIT 1")
    suspend fun getUserByUsername(userName: String): User?

    @Query("SELECT * FROM Users WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: Int): User?

    @Query("SELECT * FROM Users ORDER BY userId ASC")
    fun getAllUsers(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: User): Long

    @Update
    suspend fun updateUser(user: User)

    @Delete
    suspend fun deleteUser(user: User)

    @Query("UPDATE Users SET failedAttempts = :attempts, lockedUntil = :lockedUntil WHERE userId = :userId")
    suspend fun updateFailedAttempts(userId: Int, attempts: Int, lockedUntil: Long?)

    @Query("UPDATE Users SET failedAttempts = 0, lockedUntil = NULL, lastLogin = :lastLogin WHERE userId = :userId")
    suspend fun resetLockoutAndSetLogin(userId: Int, lastLogin: Long)

    @Query("SELECT LocalityID FROM UserLocalities WHERE UserID = :userId")
    suspend fun getUserLocalityIds(userId: Int): List<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun assignUserLocalities(links: List<UserLocality>)

    @Query("DELETE FROM UserLocalities WHERE UserID = :userId")
    suspend fun clearUserLocalities(userId: Int)
}

@Dao
interface RoleDao {
    @Query("SELECT * FROM Roles WHERE isActive = 1 ORDER BY roleId ASC")
    fun getActiveRoles(): Flow<List<Role>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoles(roles: List<Role>)
}

@Dao
interface LocalityDao {
    @Query("SELECT * FROM Localities WHERE isActive = 1 ORDER BY sortOrder ASC, localityId ASC")
    fun getAllLocalities(): Flow<List<Locality>>

    @Query("SELECT * FROM Localities WHERE localityId IN (:ids)")
    suspend fun getLocalitiesByIds(ids: List<Int>): List<Locality>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocalities(localities: List<Locality>)
}

@Dao
interface FamilyDao {

    // =========================================================================
    // 1. الاستعلامات الديناميكية الإلزامية (Dynamic Localities Architecture)
    // =========================================================================

    /**
     * استعلام القوائم المنسدلة الديناميكي:
     * يجلب قائمة المحليات الموجودة فعلياً في النظام لعرضها في شاشات الإضافة
     */
    @Query("""
        SELECT DISTINCT localityID, localityName 
        FROM Families 
        WHERE localityName IS NOT NULL AND localityName != ''
        ORDER BY localityName ASC
    """)
    fun getDistinctDynamicLocalities(): Flow<List<DynamicLocality>>

    /**
     * استعلام الإحصائيات الديناميكي:
     * يحسب الأعداد والنسب لكل محلية ديناميكياً بناءً على:
     * حالة التنمية = 'معتمد' وحالة الإقامة = 'مقيم'
     */
    @Query("""
        SELECT localityName, COUNT(*) as totalCount 
        FROM Families 
        WHERE developmentApproval = 'معتمد' 
        AND residentStatus = 'مقيم' 
        AND localityName IS NOT NULL AND localityName != ''
        GROUP BY localityName
        ORDER BY totalCount DESC
    """)
    fun getDynamicLocalityStatistics(): Flow<List<DynamicLocalityStat>>

    /**
     * استعلام الإحصائيات الديناميكي مع دعم تصفية التواريخ ونطاق الصلاحيات
     */
    @Query("""
        SELECT localityName, COUNT(*) as totalCount 
        FROM Families 
        WHERE developmentApproval = 'معتمد' 
        AND residentStatus = 'مقيم' 
        AND localityName IS NOT NULL AND localityName != ''
        AND (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))
        AND (:startDate IS NULL OR createdDate >= :startDate)
        AND (:endDate IS NULL OR createdDate <= :endDate)
        GROUP BY localityName
        ORDER BY totalCount DESC
    """)
    fun getDynamicLocalityStatisticsFiltered(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        startDate: Long?,
        endDate: Long?
    ): Flow<List<DynamicLocalityStat>>

    /**
     * استعلام عدد الأسر المعتمدة والمقيمة
     */
    @Query("""
        SELECT COUNT(*) FROM Families 
        WHERE developmentApproval = 'معتمد' 
        AND residentStatus = 'مقيم'
        AND (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))
        AND (:startDate IS NULL OR createdDate >= :startDate)
        AND (:endDate IS NULL OR createdDate <= :endDate)
    """)
    fun countApprovedResidentFamilies(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        startDate: Long?,
        endDate: Long?
    ): Flow<Int>

    /**
     * استعلام إجمالي أفراد الأسر المعتمدة والمقيمة
     */
    @Query("""
        SELECT COALESCE(SUM(familyMembersCount), 0) FROM Families 
        WHERE developmentApproval = 'معتمد' 
        AND residentStatus = 'مقيم'
        AND (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))
        AND (:startDate IS NULL OR createdDate >= :startDate)
        AND (:endDate IS NULL OR createdDate <= :endDate)
    """)
    fun countApprovedResidentBeneficiaries(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        startDate: Long?,
        endDate: Long?
    ): Flow<Int>

    @Query("""
        SELECT * FROM Families
        WHERE (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))
        AND (name LIKE '%' || :query || '%' OR nationalID LIKE '%' || :query || '%')
        AND (:localityId IS NULL OR localityID = :localityId)
        AND (:gender IS NULL OR gender = :gender)
        AND (:maritalStatus IS NULL OR maritalStatus = :maritalStatus)
        AND (:residentStatus IS NULL OR residentStatus = :residentStatus)
        AND (:devApproval IS NULL OR developmentApproval = :devApproval)
        AND (:workApproval IS NULL OR workApproval = :workApproval)
        AND (:shelterStatus IS NULL OR shelterStatus = :shelterStatus)
        ORDER BY familyID DESC
    """)
    fun getFamiliesFiltered(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        query: String,
        localityId: Int?,
        gender: String?,
        maritalStatus: String?,
        residentStatus: String?,
        devApproval: String?,
        workApproval: String?,
        shelterStatus: String?
    ): Flow<List<Family>>

    @Query("SELECT * FROM Families WHERE familyID = :familyId LIMIT 1")
    suspend fun getFamilyById(familyId: Int): Family?

    @Query("SELECT * FROM Families WHERE nationalID = :nationalId LIMIT 1")
    suspend fun getFamilyByNationalId(nationalId: String): Family?

    @Query("""
        SELECT COUNT(*) FROM Families 
        WHERE (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))
        AND (:startDate IS NULL OR createdDate >= :startDate)
        AND (:endDate IS NULL OR createdDate <= :endDate)
    """)
    fun countFamilies(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        startDate: Long?,
        endDate: Long?
    ): Flow<Int>

    @Query("""
        SELECT COALESCE(SUM(familyMembersCount), 0) FROM Families 
        WHERE (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))
        AND (:startDate IS NULL OR createdDate >= :startDate)
        AND (:endDate IS NULL OR createdDate <= :endDate)
    """)
    fun countBeneficiaries(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        startDate: Long?,
        endDate: Long?
    ): Flow<Int>

    @Query("""
        SELECT * FROM Families
        WHERE (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))
        AND (:localityId IS NULL OR localityID = :localityId)
        AND developmentApproval = 'معتمد'
        AND residentStatus = 'مقيم'
        AND workApproval = 'معتمد أشغال'
        AND shelterStatus = 'إيواء داخلي'
    """)
    suspend fun getCandidatesForAutoNomination(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        localityId: Int?
    ): List<Family>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertFamily(family: Family): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertFamilies(families: List<Family>): List<Long>

    @Update
    suspend fun updateFamily(family: Family)

    @Delete
    suspend fun deleteFamily(family: Family)
}

@Dao
interface ChildDao {
    @Query("SELECT * FROM Children WHERE familyID = :familyId ORDER BY birthDate DESC")
    fun getChildrenByFamily(familyId: Int): Flow<List<Child>>

    @Query("SELECT * FROM Children WHERE childNationalID = :childNationalId LIMIT 1")
    suspend fun getChildByNationalId(childNationalId: String): Child?

    @Query("SELECT COUNT(*) FROM Children WHERE familyID = :familyId")
    suspend fun getChildrenCountForFamily(familyId: Int): Int

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertChild(child: Child): Long

    @Update
    suspend fun updateChild(child: Child)

    @Delete
    suspend fun deleteChild(child: Child)
}

@Dao
interface AidTypeDao {
    @Query("SELECT * FROM AidTypes WHERE isActive = 1 ORDER BY sortOrder ASC")
    fun getAllActiveAidTypes(): Flow<List<AidType>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAidTypes(aidTypes: List<AidType>)
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM Projects WHERE isActive = 1 ORDER BY startDate DESC")
    fun getAllActiveProjects(): Flow<List<Project>>

    @Query("SELECT COUNT(*) FROM Projects WHERE isActive = 1")
    fun countActiveProjects(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: Project): Long
}

@Dao
interface AidRecordDao {
    @Query("""
        SELECT * FROM AidRecords 
        WHERE (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))
        AND (:aidTypeId IS NULL OR aidTypeID = :aidTypeId)
        AND (:projectId IS NULL OR projectID = :projectId)
        AND (:localityId IS NULL OR localityID = :localityId)
        AND (:startDate IS NULL OR aidDate >= :startDate)
        AND (:endDate IS NULL OR aidDate <= :endDate)
        ORDER BY aidDate DESC
    """)
    fun getAidRecordsFiltered(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        aidTypeId: Int?,
        projectId: Int?,
        localityId: Int?,
        startDate: Long?,
        endDate: Long?
    ): Flow<List<AidRecord>>

    @Query("SELECT * FROM AidRecords WHERE familyID = :familyId ORDER BY aidDate DESC")
    fun getAidRecordsByFamily(familyId: Int): Flow<List<AidRecord>>

    @Query("""
        SELECT COUNT(*) FROM AidRecords 
        WHERE (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))
        AND (:startDate IS NULL OR aidDate >= :startDate)
        AND (:endDate IS NULL OR aidDate <= :endDate)
    """)
    fun countTotalAids(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        startDate: Long?,
        endDate: Long?
    ): Flow<Int>

    @Query("SELECT COUNT(*) FROM AidRecords WHERE familyID = :familyId AND aidTypeID = :aidTypeId")
    suspend fun countAidByFamilyAndType(familyId: Int, aidTypeId: Int): Int

    @Query("""
        SELECT 
            t.aidTypeID AS aidTypeID,
            t.aidTypeName AS aidTypeName,
            COUNT(r.aidRecordID) AS totalAidCount,
            COALESCE(SUM(r.aidValue), 0.0) AS totalAidValue
        FROM AidTypes t
        LEFT JOIN AidRecords r ON t.aidTypeID = r.aidTypeID
            AND (:isSuperAdmin = 1 OR r.localityID IN (:allowedLocalityIds))
            AND (:startDate IS NULL OR r.aidDate >= :startDate)
            AND (:endDate IS NULL OR r.aidDate <= :endDate)
        GROUP BY t.aidTypeID, t.aidTypeName, t.sortOrder
        ORDER BY t.sortOrder ASC
    """)
    fun getRealAidTypeStatistics(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        startDate: Long?,
        endDate: Long?
    ): Flow<List<AidTypeStatistic>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAidRecord(record: AidRecord): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAidRecords(records: List<AidRecord>)

    @Update
    suspend fun updateAidRecord(record: AidRecord)

    @Delete
    suspend fun deleteAidRecord(record: AidRecord)
}

@Dao
interface SelectionDao {
    @Query("""
        SELECT * FROM Selections 
        WHERE (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))
        AND (:aidTypeId IS NULL OR aidTypeID = :aidTypeId)
        AND (:projectId IS NULL OR projectID = :projectId)
        ORDER BY selectionDate DESC
    """)
    fun getSelections(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        aidTypeId: Int?,
        projectId: Int?
    ): Flow<List<Selection>>

    @Query("SELECT COUNT(*) FROM Selections WHERE (:isSuperAdmin = 1 OR localityID IN (:allowedLocalityIds))")
    fun countSelections(isSuperAdmin: Boolean, allowedLocalityIds: List<Int>): Flow<Int>

    @Query("SELECT COUNT(*) FROM Selections WHERE familyID = :familyId AND aidTypeID = :aidTypeId")
    suspend fun countSelectionByFamilyAndType(familyId: Int, aidTypeId: Int): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSelection(selection: Selection): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSelections(selections: List<Selection>)

    @Query("DELETE FROM Selections WHERE selectionID = :selectionId")
    suspend fun deleteSelection(selectionId: Int)

    @Query("DELETE FROM Selections WHERE selectionID IN (:selectionIds)")
    suspend fun deleteSelections(selectionIds: List<Int>)
}
