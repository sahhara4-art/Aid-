package com.humanitarian.aidmanagement.ui.screens.users

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.RoleEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.PalestineNationalBanner
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch

data class ScreenItem(val id: String, val name: String, val icon: String)

val SYSTEM_SCREENS = listOf(
    ScreenItem("dashboard", "لوحة المؤشرات", "📊"),
    ScreenItem("families", "سجل الأسر والمواطنين", "👨‍👩‍👧"),
    ScreenItem("nomination", "ترشيح المساعدات", "⚖️"),
    ScreenItem("delivery", "تسليم وصرف المعونات", "📦"),
    ScreenItem("reports", "التقارير وتصدير المستندات", "📄"),
    ScreenItem("excel_import_export", "استيراد وتصدير إكسل", "📑"),
    ScreenItem("users", "إدارة الحسابات والصلاحيات", "🛡️"),
    ScreenItem("backup", "النسخ الاحتياطي والمزامنة", "💾")
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AccountsPermissionsScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val users by repository.getAllUsers().collectAsState(initial = emptyList())
    val roles by repository.getAllRoles().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val availableGroups = remember { repository.getAvailableGroups() }

    val roleMap = remember(roles) { roles.associateBy { it.RoleID } }
    val localityMap = remember(localities) { localities.associateBy { it.LocalityID } }

    var selectedRoleFilter by remember { mutableStateOf(0) } // 0 = الكل
    var selectedGroupFilter by remember { mutableStateOf("الكل") }
    var showAddUserDialog by remember { mutableStateOf(false) }
    var userToEdit by remember { mutableStateOf<UserEntity?>(null) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()
    val currentUser by repository.currentUserFlow.collectAsState(initial = repository.getCurrentUser())

    val filteredUsers = remember(users, selectedRoleFilter, selectedGroupFilter) {
        users.filter { user ->
            val matchRole = if (selectedRoleFilter == 0) true else user.RoleID == selectedRoleFilter
            val matchGroup = if (selectedGroupFilter == "الكل") true else user.AllowedGroup == selectedGroupFilter
            matchRole && matchGroup
        }
    }

    val activeCount = users.count { it.IsActive }
    val lockedCount = users.count { it.LockedUntil != null && it.LockedUntil > System.currentTimeMillis() }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "إدارة الحسابات والصلاحيات التفصيلية",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(text = "🇵🇸", fontSize = 16.sp)
                            }
                            Text(
                                text = "تحديد الشاشات المسموحة • المناطق • مجموعات العمل",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextSecondary
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = PalestineGreen)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showAddUserDialog = true }) {
                            Icon(Icons.Default.PersonAdd, contentDescription = "إضافة مستخدم", tint = PalestineGreen)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = PalestineWhite,
                        titleContentColor = SlateTextPrimary
                    )
                )
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { showAddUserDialog = true },
                    containerColor = PalestineGreen,
                    contentColor = PalestineWhite,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("إضافة مستخدم جديد", fontWeight = FontWeight.Bold) }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SlateBackground)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // 1. بصمة فلسطين الوطنية الرسمية
                PalestineNationalBanner(
                    subtitle = "نظام التحكم المركزي في صلاحيات الشاشات والمناطق والمجموعات الميدانية"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // 2. بطاقة إحصائيات سريعة للحسابات
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatPill("إجمالي الحسابات", "${users.size}", PalestineGreen, Modifier.weight(1f))
                    StatPill("الحسابات النشطة", "$activeCount", EmeraldSuccess, Modifier.weight(1f))
                    StatPill("مقفل أمنياً", "$lockedCount", PalestineRed, Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 3. شريط فلترة الأدوار أفقياً
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedRoleFilter == 0,
                            onClick = { selectedRoleFilter = 0 },
                            label = { Text("كافة الأدوار (${users.size})", fontSize = 11.sp) },
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                    items(roles) { role ->
                        val count = users.count { it.RoleID == role.RoleID }
                        FilterChip(
                            selected = selectedRoleFilter == role.RoleID,
                            onClick = { selectedRoleFilter = role.RoleID },
                            label = { Text("${role.RoleName} ($count)", fontSize = 11.sp) },
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }

                if (feedbackMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = PalestineGreenLight,
                        border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = feedbackMessage ?: "",
                            color = PalestineGreenDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 4. قائمة المستخدمين التفصيلية
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredUsers, key = { it.UserID }) { user ->
                        val roleName = roleMap[user.RoleID]?.RoleName ?: user.RoleName
                        val localityName = if (user.AllowedLocalityID == 0) "كافة المحليات" else localityMap[user.AllowedLocalityID]?.LocalityName ?: "منطقة ${user.AllowedLocalityID}"
                        val isPrimaryAdmin = user.UserID == 1 || user.UserName.equals("admin", ignoreCase = true)

                        DetailedUserCardItem(
                            user = user,
                            roleName = roleName,
                            localityName = localityName,
                            isPrimaryAdmin = isPrimaryAdmin,
                            onToggleActive = {
                                scope.launch {
                                    val newStatus = !user.IsActive
                                    repository.toggleUserActive(user.UserID, newStatus)
                                    feedbackMessage = if (newStatus) "تم تفعيل حساب ${user.UserName}" else "تم تعطيل حساب ${user.UserName}"
                                }
                            },
                            onUnlock = {
                                scope.launch {
                                    repository.unlockUser(user.UserID)
                                    feedbackMessage = "تم إلغاء قفل حساب ${user.UserName} وإعادة تصفير محاولات الدخول"
                                }
                            },
                            onEdit = { userToEdit = user },
                            onDelete = {
                                scope.launch {
                                    repository.deleteUser(user.UserID)
                                    feedbackMessage = "تم حذف الحساب بنجاح"
                                }
                            }
                        )
                    }
                }
            }
        }

        // نافذة إضافة مستخدم جديد مع الصلاحيات التفصيلية
        if (showAddUserDialog) {
            AddDetailedUserDialog(
                roles = roles,
                localities = localities,
                groups = availableGroups,
                onDismiss = { showAddUserDialog = false },
                onSave = { newUser ->
                    scope.launch {
                        repository.insertUser(newUser)
                        showAddUserDialog = false
                        feedbackMessage = "تمت إضافة المستخدم ${newUser.UserName} بصلاحياته التفصيلية بنجاح"
                    }
                }
            )
        }

        // نافذة تعديل المستخدم مع الصلاحيات التفصيلية
        if (userToEdit != null) {
            EditDetailedUserDialog(
                user = userToEdit!!,
                roles = roles,
                localities = localities,
                groups = availableGroups,
                onDismiss = { userToEdit = null },
                onSave = { updatedUser ->
                    scope.launch {
                        repository.updateUser(updatedUser)
                        userToEdit = null
                        feedbackMessage = "تم تحديث صلاحيات ومجموعة الحساب @${updatedUser.UserName} بنجاح"
                    }
                }
            )
        }
    }
}

@Composable
fun StatPill(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = PalestineWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.border(1.dp, SlateBorder, RoundedCornerShape(12.dp))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, maxLines = 1)
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = color)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DetailedUserCardItem(
    user: UserEntity,
    roleName: String,
    localityName: String,
    isPrimaryAdmin: Boolean,
    onToggleActive: () -> Unit,
    onUnlock: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isLocked = (user.LockedUntil != null && user.LockedUntil > System.currentTimeMillis()) || user.FailedAttempts >= 5
    val allowedScreenCount = user.AllowedScreens.split(",").filter { it.isNotBlank() }.size

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PalestineWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isPrimaryAdmin) PalestineRedLight else PalestineGreenContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPrimaryAdmin) Icons.Default.Security else Icons.Default.Person,
                            contentDescription = null,
                            tint = if (isPrimaryAdmin) PalestineRed else PalestineGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = user.FullName,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall,
                            color = SlateTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "@${user.UserName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateTextSecondary
                        )
                    }
                }

                // شارة الدور
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPrimaryAdmin) PalestineRedLight else PalestineGreenContainer
                ) {
                    Text(
                        text = roleName,
                        color = if (isPrimaryAdmin) PalestineRed else PalestineGreenDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // شارات الصلاحيات التفصيلية (الشاشات المسموحة، المنطقة، المجموعة)
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // شارة الشاشات المسموحة
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = SlateSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = "📱 الشاشات: $allowedScreenCount/8", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SlateTextPrimary)
                    }
                }

                // شارة المنطقة المسموحة
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = PalestineGreenLight,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.2f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = "📍 $localityName", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                    }
                }

                // شارة المجموعة
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = PalestineGoldLight,
                    border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGold.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = "👥 ${user.AllowedGroup}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                    }
                }

                // شارة الحالة
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (user.IsActive) EmeraldSuccess.copy(alpha = 0.15f) else PalestineRedLight
                ) {
                    Text(
                        text = if (user.IsActive) "نشط" else "معطل",
                        color = if (user.IsActive) EmeraldSuccess else PalestineRed,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }

                if (isLocked) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = PalestineRedLight
                    ) {
                        Text(
                            text = "مقفل أمنياً (${user.FailedAttempts})",
                            color = PalestineRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = SlateBorder)
            Spacer(modifier = Modifier.height(6.dp))

            // أزرار التحكم
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isLocked || user.FailedAttempts > 0) {
                    TextButton(onClick = onUnlock) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp), tint = EmeraldSuccess)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("فك القفل", color = EmeraldSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (!isPrimaryAdmin) {
                    TextButton(onClick = onToggleActive) {
                        Text(
                            text = if (user.IsActive) "تعطيل الحساب" else "تفعيل الحساب",
                            color = if (user.IsActive) PalestineRed else EmeraldSuccess,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "تعديل الصلاحيات", tint = PalestineGreen, modifier = Modifier.size(18.dp))
                }

                if (!isPrimaryAdmin) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = PalestineRed, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddDetailedUserDialog(
    roles: List<RoleEntity>,
    localities: List<LocalityEntity>,
    groups: List<String>,
    onDismiss: () -> Unit,
    onSave: (UserEntity) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var selectedRoleId by remember { mutableStateOf(roles.firstOrNull()?.RoleID ?: 2) }
    var selectedLocalityId by remember { mutableStateOf(0) } // 0 = الكل
    var selectedGroup by remember { mutableStateOf(groups.firstOrNull() ?: "كافة المجموعات") }
    var allowedScreensSet by remember { mutableStateOf(mutableSetOf("dashboard", "families", "delivery", "reports", "excel_import_export")) }
    var isActive by remember { mutableStateOf(true) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("إضافة مستخدم وتعيين الصلاحيات التفصيلية", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("🇵🇸", fontSize = 16.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("الاسم الكامل للمستخدم") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("اسم المستخدم (Username)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("كلمة المرور") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    HorizontalDivider(color = SlateBorder)

                    // 1. اختيار الدور الوظيفي
                    Text("الدور الوظيفي الأساسي:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        roles.forEach { role ->
                            FilterChip(
                                selected = selectedRoleId == role.RoleID,
                                onClick = { selectedRoleId = role.RoleID },
                                label = { Text(role.RoleName, fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = SlateBorder)

                    // 2. الشاشات المسموحة (Allowed Screens)
                    Text("الشاشات المصرح بها (Allowed Screens):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SYSTEM_SCREENS.forEach { screen ->
                            val isChecked = allowedScreensSet.contains(screen.id)
                            FilterChip(
                                selected = isChecked,
                                onClick = {
                                    val newSet = allowedScreensSet.toMutableSet()
                                    if (isChecked) newSet.remove(screen.id) else newSet.add(screen.id)
                                    allowedScreensSet = newSet
                                },
                                label = { Text("${screen.icon} ${screen.name}", fontSize = 10.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = SlateBorder)

                    // 3. المناطق المسموحة (Allowed Locality)
                    Text("المنطقة / المحلية المسموحة (Allowed Locality):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = selectedLocalityId == 0,
                                onClick = { selectedLocalityId = 0 },
                                label = { Text("كافة مناطق قطاع غزة", fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                        items(localities) { loc ->
                            FilterChip(
                                selected = selectedLocalityId == loc.LocalityID,
                                onClick = { selectedLocalityId = loc.LocalityID },
                                label = { Text(loc.LocalityName, fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = SlateBorder)

                    // 4. مجموعة العمل والتوزيع (Allowed Group)
                    Text("مجموعة العمل والتوزيع (Work Group):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(groups) { grp ->
                            FilterChip(
                                selected = selectedGroup == grp,
                                onClick = { selectedGroup = grp },
                                label = { Text(grp, fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (username.isNotBlank() && password.isNotBlank() && fullName.isNotBlank()) {
                            val newUser = UserEntity(
                                UserName = username.trim(),
                                PasswordHash = password.trim(),
                                FullName = fullName.trim(),
                                RoleID = selectedRoleId,
                                AllowedLocalityID = selectedLocalityId,
                                AllowedGroup = selectedGroup,
                                AllowedScreens = allowedScreensSet.joinToString(","),
                                IsActive = isActive,
                                CreatedBy = "مدير النظام"
                            )
                            onSave(newUser)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("حفظ المستخدم والصلاحيات", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("إلغاء", color = SlateTextSecondary)
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditDetailedUserDialog(
    user: UserEntity,
    roles: List<RoleEntity>,
    localities: List<LocalityEntity>,
    groups: List<String>,
    onDismiss: () -> Unit,
    onSave: (UserEntity) -> Unit
) {
    var password by remember { mutableStateOf(user.PasswordHash) }
    var fullName by remember { mutableStateOf(user.FullName) }
    var selectedRoleId by remember { mutableStateOf(user.RoleID) }
    var selectedLocalityId by remember { mutableStateOf(user.AllowedLocalityID) }
    var selectedGroup by remember { mutableStateOf(user.AllowedGroup) }
    var allowedScreensSet by remember {
        mutableStateOf(user.AllowedScreens.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableSet())
    }
    var isActive by remember { mutableStateOf(user.IsActive) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("تعديل صلاحيات @${user.UserName}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("🇵🇸", fontSize = 16.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("الاسم الكامل") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("تحديث كلمة المرور") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )

                    HorizontalDivider(color = SlateBorder)

                    // 1. الدور الوظيفي
                    Text("الدور الوظيفي:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        roles.forEach { role ->
                            FilterChip(
                                selected = selectedRoleId == role.RoleID,
                                onClick = { selectedRoleId = role.RoleID },
                                label = { Text(role.RoleName, fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = SlateBorder)

                    // 2. الشاشات المسموحة التفصيلية
                    Text("الشاشات المسموحة (Allowed Screens):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SYSTEM_SCREENS.forEach { screen ->
                            val isChecked = allowedScreensSet.contains(screen.id)
                            FilterChip(
                                selected = isChecked,
                                onClick = {
                                    val newSet = allowedScreensSet.toMutableSet()
                                    if (isChecked) newSet.remove(screen.id) else newSet.add(screen.id)
                                    allowedScreensSet = newSet
                                },
                                label = { Text("${screen.icon} ${screen.name}", fontSize = 10.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = SlateBorder)

                    // 3. المنطقة المسموحة
                    Text("المنطقة / المحلية المسموحة (Allowed Locality):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = selectedLocalityId == 0,
                                onClick = { selectedLocalityId = 0 },
                                label = { Text("كافة مناطق قطاع غزة", fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                        items(localities) { loc ->
                            FilterChip(
                                selected = selectedLocalityId == loc.LocalityID,
                                onClick = { selectedLocalityId = loc.LocalityID },
                                label = { Text(loc.LocalityName, fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = SlateBorder)

                    // 4. مجموعة العمل والتوزيع
                    Text("مجموعة العمل والتوزيع (Work Group):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(groups) { grp ->
                            FilterChip(
                                selected = selectedGroup == grp,
                                onClick = { selectedGroup = grp },
                                label = { Text(grp, fontSize = 11.sp) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val updated = user.copy(
                            FullName = fullName.trim(),
                            PasswordHash = password.trim(),
                            RoleID = selectedRoleId,
                            AllowedLocalityID = selectedLocalityId,
                            AllowedGroup = selectedGroup,
                            AllowedScreens = allowedScreensSet.joinToString(","),
                            IsActive = isActive
                        )
                        onSave(updated)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("حفظ التعديلات", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("إلغاء", color = SlateTextSecondary)
                }
            }
        )
    }
}
