package com.humanitarian.aidmanagement.notifications

import android.content.Context

object NotificationScheduler {
    fun schedulePeriodicCheck(context: Context) {
        // جدولة فحص دوري
        AidNotificationChannels.createNotificationChannels(context)
    }
}
