package com.humanitarian.aidmanagement.util

import android.content.Context
import com.humanitarian.aidmanagement.engine.ExclusionMode
import com.humanitarian.aidmanagement.engine.ScoringProfileConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * سياسة ومعايير وشروط الترشيح المحفوظة والمقفلة لكل مشروع إنساني على حدة.
 * تُخزَّن محلياً بصيغة JSON عبر SharedPreferences دون تعديل مخطط جداول Room.
 */
data class ProjectNominationPolicy(
    val projectId: Long,
    val isLocked: Boolean = true,
    // صفة الإقامة الإلزامية
    val residencyStatus: String? = null,
    // النطاق الجغرافي (المحليات والشُعب)
    val selectedLocalities: List<String> = emptyList(),
    val selectedBranches: List<String> = emptyList(),
    // حالة اعتماد الأشغال
    val worksApprovalEnabled: Boolean = true,
    val worksApprovalChips: Map<String, String> = emptyMap(),
    // حالة الإيواء ومراكز النزوح
    val shelterEnabled: Boolean = true,
    val shelterChips: Map<String, String> = emptyMap(),
    // أضرار الحرب والمنازل
    val damageEnabled: Boolean = true,
    val damageChips: Map<String, String> = emptyMap(),
    // الحالة الاجتماعية (مع خيار الاستثناء)
    val maritalStatusEnabled: Boolean = true,
    val selectedMaritalStatuses: List<String> = emptyList(),
    val excludeMaritalStatuses: Boolean = false,
    // حالة العمل والدخل
    val incomeEnabled: Boolean = true,
    val workStatusFilter: String = "الكل",
    // شرط وجود الأبناء ونطاق أعمارهم
    val hasChildrenOnly: Boolean = false,
    val minChildAgeText: String = "0",
    val maxChildAgeText: String = "18",
    // نوع المساعدة السابقة (تضمين/استثناء) وفترة الاستثناء الزمني
    val aidCategoryEnabled: Boolean = true,
    val aidCategoryChips: Map<String, String> = emptyMap(),
    val exclusionMode: String = ExclusionMode.DAYS.name,
    val exclusionDaysText: String = "30",
    val exclusionDateCutoffText: String = "",
    // الحد الأدنى والأقصى لأفراد الأسرة (0 في الحد الأقصى = غير محدد)
    val minFamilyMembers: Int = 1,
    val maxFamilyMembers: Int = 0,
    // قالب وأوزان مؤشر الهشاشة والترتيب
    val sortByVulnerability: Boolean = false,
    val scoringProfile: ScoringProfileConfig? = null,
    // بيانات الاعتماد الإداري
    val approvedBy: String = "",
    val approvedAt: String = ""
) {
    /**
     * يحوّل المعايير المحفوظة إلى بنود عربية واضحة ومرتبة لعرضها في بطاقة وتفاصيل المشروع.
     */
    fun toReadableSummaryLines(): List<String> {
        val lines = mutableListOf<String>()

        residencyStatus?.trim()?.takeIf { it.isNotBlank() }?.let {
            lines.add("صفة الإقامة: $it")
        }

        val cleanLocs = selectedLocalities.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val cleanBranches = selectedBranches.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        when {
            cleanLocs.isNotEmpty() && cleanBranches.isNotEmpty() ->
                lines.add("النطاق الجغرافي: ${cleanLocs.joinToString("، ")} — الشُعب: ${cleanBranches.joinToString("، ")}")
            cleanLocs.isNotEmpty() ->
                lines.add("النطاق الجغرافي: ${cleanLocs.joinToString("، ")}")
            cleanBranches.isNotEmpty() ->
                lines.add("الشُعب المستهدفة: ${cleanBranches.joinToString("، ")}")
            else ->
                lines.add("النطاق الجغرافي: جميع المحليات والشُعب المصرح بها")
        }

        // الاستثناء الزمني + نوع المساعدة المستبعدة إن وُجد
        val excludedAidCats = aidCategoryChips
            .filterValues { it.equals("EXCLUDED", ignoreCase = true) }
            .keys
            .map { it.trim() }
            .filter { it.isNotBlank() }
        val includedAidCats = aidCategoryChips
            .filterValues { it.equals("INCLUDED", ignoreCase = true) }
            .keys
            .map { it.trim() }
            .filter { it.isNotBlank() }

        val excludedCatsSuffix = if (aidCategoryEnabled && excludedAidCats.isNotEmpty()) {
            " (${excludedAidCats.joinToString("، ")})"
        } else {
            ""
        }

        when (exclusionMode.uppercase(Locale.US)) {
            ExclusionMode.DAYS.name -> {
                val days = exclusionDaysText.trim().toIntOrNull() ?: 0
                if (days > 0) {
                    lines.add("الاستثناء الزمني: آخر $days يوماً$excludedCatsSuffix")
                } else if (excludedCatsSuffix.isNotEmpty()) {
                    lines.add("استثناء مساعدات سابقة: ${excludedAidCats.joinToString("، ")}")
                }
            }
            ExclusionMode.DATE.name -> {
                val cutoff = exclusionDateCutoffText.trim()
                if (cutoff.isNotBlank()) {
                    lines.add("الاستثناء الزمني: منذ تاريخ $cutoff$excludedCatsSuffix")
                } else if (excludedCatsSuffix.isNotEmpty()) {
                    lines.add("استثناء مساعدات سابقة: ${excludedAidCats.joinToString("، ")}")
                }
            }
            else -> {
                if (aidCategoryEnabled && excludedAidCats.isNotEmpty()) {
                    lines.add("استثناء مساعدات سابقة: ${excludedAidCats.joinToString("، ")}")
                }
            }
        }

        if (aidCategoryEnabled && includedAidCats.isNotEmpty()) {
            lines.add("تضمين مستفيدي مساعدات سابقة: ${includedAidCats.joinToString("، ")}")
        } else if (!aidCategoryEnabled) {
            lines.add("فلتر المساعدات السابقة: متجاوز (معطّل)")
        }

        // عدد أفراد الأسرة (أدنى وأقصى)
        when {
            minFamilyMembers > 1 && maxFamilyMembers > 0 && maxFamilyMembers >= minFamilyMembers ->
                lines.add("عدد الأفراد: من $minFamilyMembers إلى $maxFamilyMembers أفراد")
            minFamilyMembers > 1 ->
                lines.add("عدد الأفراد: $minFamilyMembers فأكثر")
            maxFamilyMembers > 0 ->
                lines.add("عدد الأفراد: حتى $maxFamilyMembers أفراد كحد أقصى")
        }

        // اعتماد الأشغال
        formatChipSummary("اعتماد الأشغال", worksApprovalEnabled, worksApprovalChips)?.let { lines.add(it) }

        // حالة الإيواء
        formatChipSummary("حالة الإيواء", shelterEnabled, shelterChips)?.let { lines.add(it) }

        // أضرار الحرب
        formatChipSummary("الأضرار", damageEnabled, damageChips)?.let { lines.add(it) }

        // الحالة الاجتماعية
        if (!maritalStatusEnabled) {
            lines.add("الحالة الاجتماعية: متجاوز (معطّل)")
        } else if (selectedMaritalStatuses.isNotEmpty()) {
            val modeLabel = if (excludeMaritalStatuses) "استثناء" else "تضمين"
            lines.add("الحالة الاجتماعية ($modeLabel): ${selectedMaritalStatuses.joinToString("، ")}")
        }

        // حالة العمل والدخل
        if (!incomeEnabled) {
            lines.add("العمل والدخل: متجاوز (معطّل)")
        } else if (workStatusFilter.isNotBlank() && workStatusFilter != "الكل") {
            lines.add("العمل والدخل: $workStatusFilter")
        }

        // شرط الأبناء ونطاق الأعمار
        if (hasChildrenOnly) {
            val minAge = minChildAgeText.trim().ifBlank { "0" }
            val maxAge = maxChildAgeText.trim().ifBlank { "18" }
            lines.add("شرط الأبناء: وجود أبناء بأعمار $minAge إلى $maxAge سنة")
        }

        // قالب وأوزان مؤشر الهشاشة
        val profile = scoringProfile
        if (profile != null) {
            val sortTag = if (sortByVulnerability) " (الترتيب حسب الهشاشة مفعّل)" else ""
            lines.add(
                "معايرة الهشاشة: ${profile.profileName}$sortTag — " +
                    "ضرر ${profile.housingDamageWeight}% • أطفال ${profile.childAgeGroupWeight}% • " +
                    "انقطاع ${profile.daysSinceLastAidWeight}% • دخل ${profile.employmentIncomeWeight}% • " +
                    "شكاوى ${profile.openComplaintWeight}% • أفراد ${profile.familySizeWeight}%"
            )
        } else if (sortByVulnerability) {
            lines.add("الترتيب الذكي: مفعّل حسب الأعلى هشاشة (0-100)")
        }

        if (lines.isEmpty()) {
            lines.add("معايير افتراضية عامة (كافة الأسر المعتمدة)")
        }
        return lines
    }

    private fun formatChipSummary(
        label: String,
        enabled: Boolean,
        chips: Map<String, String>
    ): String? {
        if (!enabled) return "$label: متجاوز (معطّل)"
        if (chips.isEmpty()) return null
        val included = chips.filterValues { it.equals("INCLUDED", ignoreCase = true) }.keys.toList()
        val excluded = chips.filterValues { it.equals("EXCLUDED", ignoreCase = true) }.keys.toList()
        val parts = mutableListOf<String>()
        if (included.isNotEmpty()) parts.add(included.joinToString("، "))
        if (excluded.isNotEmpty()) parts.add("استثناء: ${excluded.joinToString("، ")}")
        return if (parts.isEmpty()) null else "$label: ${parts.joinToString(" | ")}"
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("projectId", projectId)
        put("isLocked", isLocked)
        put("residencyStatus", residencyStatus ?: JSONObject.NULL)
        put("selectedLocalities", JSONArray(selectedLocalities))
        put("selectedBranches", JSONArray(selectedBranches))
        put("worksApprovalEnabled", worksApprovalEnabled)
        put("worksApprovalChips", mapToJsonObject(worksApprovalChips))
        put("shelterEnabled", shelterEnabled)
        put("shelterChips", mapToJsonObject(shelterChips))
        put("damageEnabled", damageEnabled)
        put("damageChips", mapToJsonObject(damageChips))
        put("maritalStatusEnabled", maritalStatusEnabled)
        put("selectedMaritalStatuses", JSONArray(selectedMaritalStatuses))
        put("excludeMaritalStatuses", excludeMaritalStatuses)
        put("incomeEnabled", incomeEnabled)
        put("workStatusFilter", workStatusFilter)
        put("hasChildrenOnly", hasChildrenOnly)
        put("minChildAgeText", minChildAgeText)
        put("maxChildAgeText", maxChildAgeText)
        put("aidCategoryEnabled", aidCategoryEnabled)
        put("aidCategoryChips", mapToJsonObject(aidCategoryChips))
        put("exclusionMode", exclusionMode)
        put("exclusionDaysText", exclusionDaysText)
        put("exclusionDateCutoffText", exclusionDateCutoffText)
        put("minFamilyMembers", minFamilyMembers)
        put("maxFamilyMembers", maxFamilyMembers)
        put("sortByVulnerability", sortByVulnerability)
        if (scoringProfile != null) {
            put("scoringProfile", scoringProfile.toJson())
        } else {
            put("scoringProfile", JSONObject.NULL)
        }
        put("approvedBy", approvedBy)
        put("approvedAt", approvedAt)
    }

    companion object {
        private fun mapToJsonObject(map: Map<String, String>): JSONObject {
            val obj = JSONObject()
            map.forEach { (k, v) -> obj.put(k, v) }
            return obj
        }

        private fun jsonArrayToStringList(arr: JSONArray?): List<String> {
            if (arr == null) return emptyList()
            val list = ArrayList<String>(arr.length())
            for (i in 0 until arr.length()) {
                val item = arr.optString(i, "").trim()
                if (item.isNotBlank()) list.add(item)
            }
            return list
        }

        private fun jsonObjectToStringMap(obj: JSONObject?): Map<String, String> {
            if (obj == null) return emptyMap()
            val map = LinkedHashMap<String, String>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = obj.optString(k, "").trim()
                if (k.isNotBlank() && v.isNotBlank()) {
                    map[k] = v
                }
            }
            return map
        }

        fun fromJson(json: JSONObject): ProjectNominationPolicy {
            val rawResidency = if (json.isNull("residencyStatus")) null else json.optString("residencyStatus", "").trim().takeIf { it.isNotBlank() }
            val profileJson = json.optJSONObject("scoringProfile")
            val parsedProfile = profileJson?.let { runCatching { ScoringProfileConfig.fromJson(it) }.getOrNull() }

            return ProjectNominationPolicy(
                projectId = json.optLong("projectId", 0L),
                isLocked = json.optBoolean("isLocked", true),
                residencyStatus = rawResidency,
                selectedLocalities = jsonArrayToStringList(json.optJSONArray("selectedLocalities")),
                selectedBranches = jsonArrayToStringList(json.optJSONArray("selectedBranches")),
                worksApprovalEnabled = json.optBoolean("worksApprovalEnabled", true),
                worksApprovalChips = jsonObjectToStringMap(json.optJSONObject("worksApprovalChips")),
                shelterEnabled = json.optBoolean("shelterEnabled", true),
                shelterChips = jsonObjectToStringMap(json.optJSONObject("shelterChips")),
                damageEnabled = json.optBoolean("damageEnabled", true),
                damageChips = jsonObjectToStringMap(json.optJSONObject("damageChips")),
                maritalStatusEnabled = json.optBoolean("maritalStatusEnabled", true),
                selectedMaritalStatuses = jsonArrayToStringList(json.optJSONArray("selectedMaritalStatuses")),
                excludeMaritalStatuses = json.optBoolean("excludeMaritalStatuses", false),
                incomeEnabled = json.optBoolean("incomeEnabled", true),
                workStatusFilter = json.optString("workStatusFilter", "الكل").ifBlank { "الكل" },
                hasChildrenOnly = json.optBoolean("hasChildrenOnly", false),
                minChildAgeText = json.optString("minChildAgeText", "0"),
                maxChildAgeText = json.optString("maxChildAgeText", "18"),
                aidCategoryEnabled = json.optBoolean("aidCategoryEnabled", true),
                aidCategoryChips = jsonObjectToStringMap(json.optJSONObject("aidCategoryChips")),
                exclusionMode = json.optString("exclusionMode", ExclusionMode.DAYS.name),
                exclusionDaysText = json.optString("exclusionDaysText", "30"),
                exclusionDateCutoffText = json.optString("exclusionDateCutoffText", ""),
                minFamilyMembers = json.optInt("minFamilyMembers", 1).coerceAtLeast(1),
                maxFamilyMembers = json.optInt("maxFamilyMembers", 0).coerceAtLeast(0),
                sortByVulnerability = json.optBoolean("sortByVulnerability", false),
                scoringProfile = parsedProfile,
                approvedBy = json.optString("approvedBy", ""),
                approvedAt = json.optString("approvedAt", "")
            )
        }
    }
}

/**
 * مخزن محلي خفيف لسياسات الترشيح المعتمدة لكل مشروع عبر SharedPreferences + JSON.
 */
object ProjectNominationPolicyStore {
    private const val PREFS_NAME = "project_nomination_policies_prefs"
    private const val KEY_POLICY_PREFIX = "policy_project_"
    private const val KEY_PENDING_POLICY_SETUP_PROJECT_ID = "pending_policy_setup_project_id"
    private const val DATE_PATTERN = "yyyy-MM-dd HH:mm"

    private val _policiesVersion = MutableStateFlow(0L)
    val policiesVersion: StateFlow<Long> = _policiesVersion.asStateFlow()

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun formatCurrentTimestamp(): String =
        SimpleDateFormat(DATE_PATTERN, Locale.US).format(Date())

    fun savePolicy(context: Context, policy: ProjectNominationPolicy) {
        if (policy.projectId <= 0L) return
        prefs(context).edit()
            .putString(KEY_POLICY_PREFIX + policy.projectId, policy.toJson().toString())
            .apply()
        _policiesVersion.value = _policiesVersion.value + 1L
    }

    fun getPolicy(context: Context, projectId: Long): ProjectNominationPolicy? {
        if (projectId <= 0L) return null
        val raw = prefs(context).getString(KEY_POLICY_PREFIX + projectId, null) ?: return null
        return runCatching {
            ProjectNominationPolicy.fromJson(JSONObject(raw))
        }.getOrNull()
    }

    fun getAllPolicies(context: Context): Map<Long, ProjectNominationPolicy> {
        val result = LinkedHashMap<Long, ProjectNominationPolicy>()
        val all = prefs(context).all
        for ((key, value) in all) {
            if (!key.startsWith(KEY_POLICY_PREFIX)) continue
            val raw = value as? String ?: continue
            val policy = runCatching { ProjectNominationPolicy.fromJson(JSONObject(raw)) }.getOrNull()
            if (policy != null && policy.projectId > 0L) {
                result[policy.projectId] = policy
            }
        }
        return result
    }

    fun setPolicyLocked(
        context: Context,
        projectId: Long,
        locked: Boolean,
        approvedBy: String? = null
    ): ProjectNominationPolicy? {
        val existing = getPolicy(context, projectId) ?: return null
        val updated = existing.copy(
            isLocked = locked,
            approvedBy = approvedBy?.takeIf { it.isNotBlank() } ?: existing.approvedBy,
            approvedAt = if (locked) formatCurrentTimestamp() else existing.approvedAt
        )
        savePolicy(context, updated)
        return updated
    }

    fun deletePolicy(context: Context, projectId: Long) {
        if (projectId <= 0L) return
        prefs(context).edit().remove(KEY_POLICY_PREFIX + projectId).apply()
        _policiesVersion.value = _policiesVersion.value + 1L
    }

    /**
     * يحفظ معرف المشروع مؤقتاً لتسهيل انتقال المدير من شاشة المشاريع إلى خطوة ضبط معايير هذا المشروع مباشرة.
     */
    fun setPendingProjectForPolicySetup(context: Context, projectId: Long) {
        if (projectId <= 0L) return
        prefs(context).edit().putLong(KEY_PENDING_POLICY_SETUP_PROJECT_ID, projectId).apply()
    }

    fun consumePendingProjectForPolicySetup(context: Context): Long? {
        val sp = prefs(context)
        val pid = sp.getLong(KEY_PENDING_POLICY_SETUP_PROJECT_ID, -1L)
        if (pid <= 0L) return null
        sp.edit().remove(KEY_PENDING_POLICY_SETUP_PROJECT_ID).apply()
        return pid
    }
}
