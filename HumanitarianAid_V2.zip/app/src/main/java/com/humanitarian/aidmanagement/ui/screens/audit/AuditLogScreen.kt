package com.humanitarian.aidmanagement.ui.screens.audit

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.humanitarian.aidmanagement.security.AuditLogRecord
import com.humanitarian.aidmanagement.security.TamperProofAuditLog
import kotlinx.coroutines.launch

private val AuditBgGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFFEAF6F0),
        Color(0xFFF4F8FC),
        Color(0xFFF8FAFC)
    )
)

private val AuditEmerald = Color(0xFF047857)
private val AuditEmeraldBg = Color(0xFFDCFCE7)
private val AuditEmeraldBorder = Color(0xFF10B981)
private val AuditRed = Color(0xFFDC2626)
private val AuditRedBg = Color(0xFFFEE2E2)
private val AuditRedBorder = Color(0xFFF87171)
private val AuditSlateDark = Color(0xFF0F172A)
private val AuditSlateMuted = Color(0xFF64748B)
private val AuditBorderLight = Color(0xFFD5E4DC)

/**
 * شاشة الرقابة والتدقيق المقاومة للتلاعب (Tamper-Proof SHA-256 Audit Log Screen).
 * تعتمد حصراً على النصوص العربية الواضحة والشارات بدون استخدام Icons.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuditLogScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var logs by remember { mutableStateOf<List<AuditLogRecord>>(emptyList()) }
    var isChainIntact by remember { mutableStateOf<Boolean?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var isExporting by remember { mutableStateOf(false) }
    var refreshTrigger by remember { mutableStateOf(0) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedActionFilter by remember { mutableStateOf("الكل") }

    LaunchedEffect(refreshTrigger) {
        isLoading = true
        val integrity = runCatching { TamperProofAuditLog.verifyChainIntegrity(context) }.getOrDefault(false)
        val loaded = runCatching { TamperProofAuditLog.loadAllLogs(context) }.getOrDefault(emptyList())
        isChainIntact = integrity
        logs = loaded
        isLoading = false
    }

    val actionFilterOptions = remember(logs) {
        val defaults = listOf(
            "الكل",
            "ترحيل من السجل المدني",
            "استثناء في الترشيح",
            "تأكيد تسليم",
            "تعديل/حذف أسرة",
            "استعادة نسخة احتياطية"
        )
        val dynamic = logs.map { it.actionType.trim() }.filter { it.isNotBlank() }
        (defaults + dynamic).distinct()
    }

    val filteredLogs = remember(logs, searchQuery, selectedActionFilter) {
        val query = searchQuery.trim()
        logs.filter { record ->
            val matchesAction = selectedActionFilter == "الكل" ||
                record.actionType.trim().equals(selectedActionFilter, ignoreCase = true)

            val matchesQuery = query.isBlank() ||
                record.actionType.contains(query, ignoreCase = true) ||
                record.targetId.contains(query, ignoreCase = true) ||
                record.performedBy.contains(query, ignoreCase = true) ||
                record.details.contains(query, ignoreCase = true) ||
                record.timestampText.contains(query, ignoreCase = true)

            matchesAction && matchesQuery
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "سجل الرقابة والتدقيق",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = AuditSlateDark,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "سجل رقابي محصّن بسلسلة بصمات SHA-256",
                                fontSize = 11.sp,
                                color = AuditSlateMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    navigationIcon = {
                        TextButton(onClick = onNavigateBack) {
                            Text(
                                text = "رجوع",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = AuditEmerald
                            )
                        }
                    },
                    actions = {
                        TextButton(
                            onClick = { refreshTrigger += 1 },
                            enabled = !isLoading
                        ) {
                            Text(
                                text = "فحص وتحديث",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = AuditEmerald
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.White.copy(alpha = 0.92f),
                        titleContentColor = AuditSlateDark
                    )
                )
            },
            containerColor = Color.Transparent
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(AuditBgGradient)
                    .padding(paddingValues)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1) شارة حالة سلامة السلسلة الرقابية (SHA-256 Integrity Banner)
                ChainIntegrityBanner(
                    isLoading = isLoading,
                    isChainIntact = isChainIntact,
                    totalLogsCount = logs.size
                )

                // 2) زر تصدير السجل الرقابي إلى Excel (CSV UTF-8 BOM) ومشاركته عبر Intent.ACTION_SEND
                Button(
                    onClick = {
                        if (isExporting) return@Button
                        scope.launch {
                            isExporting = true
                            val result = runCatching {
                                val csvFile = TamperProofAuditLog.exportLogsToCsvFile(context)
                                val authority = "${context.packageName}.fileprovider"
                                val uri = FileProvider.getUriForFile(context, authority, csvFile)
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/csv"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    putExtra(Intent.EXTRA_SUBJECT, "سجل الرقابة والتدقيق المحصّن (SHA-256)")
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "مرفق السجل الرقابي الكامل (${logs.size} سجل) - حالة السلسلة: " +
                                            if (isChainIntact == true) "سليمة ومحصّنة" else "تحذير: يوجد تعديل غير مصرح"
                                    )
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                val chooser = Intent.createChooser(shareIntent, "تصدير ومشاركة السجل الرقابي (Excel)").apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(chooser)
                            }
                            isExporting = false
                            result.onFailure { err ->
                                Toast.makeText(
                                    context,
                                    "تعذر تصدير السجل الرقابي: ${err.message ?: "خطأ غير متوقع"}",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    },
                    enabled = !isLoading && !isExporting,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AuditEmerald,
                        contentColor = Color.White
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                ) {
                    Text(
                        text = if (isExporting) "جاري تجهيز ملف Excel..." else "تصدير السجل الرقابي (Excel)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // 3) شريط البحث والفلترة حسب نوع العملية أو رقم الهوية أو اسم المستخدم
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.88f),
                    border = BorderStroke(1.dp, AuditBorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = {
                                Text(
                                    text = "ابحث بنوع العملية أو رقم الهوية أو اسم المستخدم...",
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    TextButton(onClick = { searchQuery = "" }) {
                                        Text(
                                            text = "مسح",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AuditRed
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color(0xFFF8FAFC),
                                focusedBorderColor = AuditEmeraldBorder,
                                unfocusedBorderColor = AuditBorderLight
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            LazyRow(
                                modifier = Modifier.weight(1f),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(actionFilterOptions, key = { it }) { filterOption ->
                                    val selected = selectedActionFilter == filterOption
                                    FilterChip(
                                        selected = selected,
                                        onClick = { selectedActionFilter = filterOption },
                                        label = {
                                            Text(
                                                text = filterOption,
                                                fontSize = 11.sp,
                                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = AuditEmeraldBg,
                                            selectedLabelColor = AuditEmerald,
                                            containerColor = Color(0xFFF8FAFC)
                                        ),
                                        modifier = Modifier.height(30.dp)
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF0F172A).copy(alpha = 0.06f)
                            ) {
                                Text(
                                    text = "${filteredLogs.size} سجل",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AuditSlateDark,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // 4) قائمة السجلات الرقابية
                when {
                    isLoading -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(color = AuditEmerald)
                                Text(
                                    text = "جاري تحميل وفحص السلسلة الرقابية...",
                                    fontSize = 12.sp,
                                    color = AuditSlateMuted
                                )
                            }
                        }
                    }

                    filteredLogs.isEmpty() -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Color.White.copy(alpha = 0.9f),
                                border = BorderStroke(1.dp, AuditBorderLight),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = if (logs.isEmpty()) {
                                            "لا توجد عمليات مسجلة في السجل الرقابي حتى الآن"
                                        } else {
                                            "لا توجد نتائج مطابقة للبحث أو التصفية الحالية"
                                        },
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AuditSlateDark
                                    )
                                    if (searchQuery.isNotBlank() || selectedActionFilter != "الكل") {
                                        OutlinedButton(
                                            onClick = {
                                                searchQuery = ""
                                                selectedActionFilter = "الكل"
                                            },
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text(
                                                text = "إعادة ضبط البحث والفلتر",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = AuditEmerald
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    else -> {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 24.dp)
                        ) {
                            items(filteredLogs, key = { it.id }) { record ->
                                AuditLogRecordCard(record = record)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChainIntegrityBanner(
    isLoading: Boolean,
    isChainIntact: Boolean?,
    totalLogsCount: Int
) {
    val bgColor = when {
        isLoading || isChainIntact == null -> Color(0xFFF1F5F9)
        isChainIntact -> AuditEmeraldBg
        else -> AuditRedBg
    }
    val borderColor = when {
        isLoading || isChainIntact == null -> Color(0xFFCBD5E1)
        isChainIntact -> AuditEmeraldBorder
        else -> AuditRedBorder
    }
    val titleColor = when {
        isLoading || isChainIntact == null -> AuditSlateDark
        isChainIntact -> AuditEmerald
        else -> AuditRed
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        border = BorderStroke(1.2.dp, borderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = when {
                    isLoading || isChainIntact == null -> "جاري التحقق من سلامة السلسلة الرقابية (SHA-256)..."
                    isChainIntact -> "✓ السلسلة الرقابية سليمة ومحصّنة (SHA-256)"
                    else -> "⚠ تنبيه: تم اكتشاف تعديل غير مصرح في السجل"
                },
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = titleColor
            )
            Text(
                text = when {
                    isLoading || isChainIntact == null -> "يتم الآن فحص تطابق بصمات التجزئة التراكمية لجميع القيود."
                    isChainIntact -> "تم فحص $totalLogsCount قيد رقابي بنجاح دون أي كسر في تسلسل البصمات."
                    else -> "يوجد تعارض في بصمة SHA-256 أو حذف/تعديل يدوي خارج النظام داخل ملف السجل."
                },
                fontSize = 11.sp,
                color = titleColor.copy(alpha = 0.85f),
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun AuditLogRecordCard(record: AuditLogRecord) {
    val actionAccent = when {
        record.actionType.contains("حذف") || record.actionType.contains("استثناء") -> AuditRed
        record.actionType.contains("استعادة") || record.actionType.contains("ترحيل") -> Color(0xFFD97706)
        else -> AuditEmerald
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color.White.copy(alpha = 0.92f),
        border = BorderStroke(1.dp, AuditBorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = actionAccent.copy(alpha = 0.12f),
                    border = BorderStroke(0.8.dp, actionAccent.copy(alpha = 0.30f))
                ) {
                    Text(
                        text = record.actionType.ifBlank { "عملية رقابية" },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = actionAccent,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = record.timestampText,
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = AuditSlateMuted
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الهدف: ${record.targetId.ifBlank { "-" }}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = AuditSlateDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "بواسطة: ${record.performedBy.ifBlank { "مستخدم النظام" }}",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = AuditEmerald,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (record.details.isNotBlank()) {
                Text(
                    text = record.details,
                    fontSize = 12.sp,
                    color = Color(0xFF334155),
                    lineHeight = 18.sp
                )
            }

            HorizontalDivider(color = Color(0xFFE2E8F0), thickness = 0.7.dp)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(0.6.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "SHA-256: ${record.entryHash.take(16)}…  |  السابق: ${record.prevHash.take(12)}…",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AuditSlateMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
