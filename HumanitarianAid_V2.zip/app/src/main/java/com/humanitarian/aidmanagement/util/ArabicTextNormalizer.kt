package com.humanitarian.aidmanagement.util

/**
 * أداة قياسية خفيفة لتطبيع النصوص العربية وأرقام الجوال وتوسيع صيغ البحث لـ FTS
 * تعتمد حصراً على مكتبة Kotlin القياسية مع حدود صارمة لحماية الذاكرة (256MB Heap).
 */
object ArabicTextNormalizer {

    private const val MAX_QUERY_VARIANTS = 24

    /**
     * تطبيع النص العربي:
     * - تحويل أشكال الألف (أ، إ، آ، ٱ) إلى (ا)
     * - تحويل التاء المربوطة (ة) إلى (ه) والألف المقصورة (ى) إلى (ي)
     * - حذف التشكيل والمدّة (\u064B..\u065F، \u0670، ـ)
     * - تحويل الأرقام العربية الهندية والفارسية إلى أرقام قياسية (0..9) وتوحيد المسافات
     */
    fun normalizeArabic(text: String?): String {
        if (text.isNullOrBlank()) return ""

        val sb = StringBuilder(text.length)
        var prevSpace = true

        for (i in text.indices) {
            val ch = text[i]

            // حذف التشكيل والحركات والتطويل (المدّة)
            if (isDiacriticOrTatweel(ch)) continue

            val mapped: Char = when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ة' -> 'ه'
                'ى' -> 'ي'
                in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar()
                in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar()
                else -> ch.lowercaseChar()
            }

            if (mapped.isWhitespace()) {
                if (!prevSpace) {
                    sb.append(' ')
                    prevSpace = true
                }
            } else {
                sb.append(mapped)
                prevSpace = false
            }
        }

        if (sb.isNotEmpty() && sb[sb.length - 1] == ' ') {
            sb.setLength(sb.length - 1)
        }
        return sb.toString()
    }

    /**
     * استخراج جوهر رقم الجوال:
     * - تحويل الأرقام الهندية إلى قياسية وحذف المسافات والشرطات والأقواس وعلامة (+)
     * - إزالة البادئات الدولية والمحلية (00970، 970، 00972، 972 ثم الصفر البادئ 0)
     * مثال: "059-912-3456" أو "+970599123456" -> "599123456"
     */
    fun normalizePhoneCore(rawPhone: String?): String {
        if (rawPhone.isNullOrBlank()) return ""

        val digits = StringBuilder(rawPhone.length)
        for (i in rawPhone.indices) {
            val ch = rawPhone[i]
            when (ch) {
                in '0'..'9' -> digits.append(ch)
                in '٠'..'٩' -> digits.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> digits.append(('0'.code + (ch.code - '۰'.code)).toChar())
            }
        }

        var core = digits.toString()
        if (core.isEmpty()) return ""

        core = when {
            core.startsWith("00970") && core.length > 5 -> core.substring(5)
            core.startsWith("00972") && core.length > 5 -> core.substring(5)
            core.startsWith("970") && core.length > 3 -> core.substring(3)
            core.startsWith("972") && core.length > 3 -> core.substring(3)
            else -> core
        }

        while (core.startsWith("0") && core.length > 1) {
            core = core.substring(1)
        }
        if (core == "0") return ""

        return core
    }

    /**
     * التحقق من تطابق النص العربي مع استعلام البحث بعد التطبيع (احتواء النص على جميع كلمات البحث)
     */
    fun matchesArabicQuery(target: String?, query: String?): Boolean {
        val normalizedQuery = normalizeArabic(query)
        if (normalizedQuery.isEmpty()) return true

        val normalizedTarget = normalizeArabic(target)
        if (normalizedTarget.isEmpty()) return false

        val tokens = normalizedQuery.split(' ')
        for (token in tokens) {
            if (token.isNotEmpty() && !normalizedTarget.contains(token)) {
                return false
            }
        }
        return true
    }

    /**
     * التحقق من التطابق الجزئي لرقم الجوال عبر مقارنة جوهر الرقمين بعد إزالة البادئات والصفر البادئ
     */
    fun matchesPhoneQuery(targetPhone: String?, query: String?): Boolean {
        val queryCore = normalizePhoneCore(query)
        if (queryCore.isEmpty()) return false

        val targetCore = normalizePhoneCore(targetPhone)
        if (targetCore.isEmpty()) return false

        return targetCore.contains(queryCore)
    }

    /**
     * توليد الصيغ الإملائية البديلة للكلمة (ا/أ/إ و ه/ة و ي/ى) لاستخدامها في استعلامات children_fts
     */
    fun expandArabicQueryVariants(query: String): List<String> {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return emptyList()

        val normalized = normalizeArabic(trimmed)
        val result = LinkedHashSet<String>()
        result.add(trimmed)
        if (normalized.isNotEmpty()) {
            result.add(normalized)
        }

        val base = if (normalized.isNotEmpty()) normalized else trimmed
        val words = base.split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty()) return result.toList()

        // توسيع كل كلمة مفردة بصيغها الإملائية البديلة
        if (words.size == 1) {
            expandSingleWordVariants(words[0], result)
        } else {
            // في حال تعدد الكلمات: توليد الصيغ البديلة لكل كلمة مع الحفاظ على حد الذاكرة
            val perWordVariants = words.map { word ->
                val set = LinkedHashSet<String>()
                expandSingleWordVariants(word, set, maxCount = 6)
                set.toList()
            }

            var combinations = listOf("")
            for (wordVars in perWordVariants) {
                val next = ArrayList<String>(minOf(combinations.size * wordVars.size, MAX_QUERY_VARIANTS))
                outer@ for (prefix in combinations) {
                    for (variant in wordVars) {
                        val combined = if (prefix.isEmpty()) variant else "$prefix $variant"
                        next.add(combined)
                        if (next.size >= MAX_QUERY_VARIANTS) break@outer
                    }
                }
                combinations = next
            }

            for (combo in combinations) {
                if (result.size >= MAX_QUERY_VARIANTS) break
                result.add(combo)
            }
        }

        return result.toList()
    }

    private fun expandSingleWordVariants(
        word: String,
        target: MutableSet<String>,
        maxCount: Int = MAX_QUERY_VARIANTS
    ) {
        if (word.isEmpty() || target.size >= maxCount) return

        val normalizedWord = normalizeArabic(word)
        if (normalizedWord.isEmpty()) return
        target.add(normalizedWord)

        // تحديد المواضع القابلة للتبديل الإملائي (ا/أ/إ في الكلمة، و ه/ة و ي/ى)
        val expandablePositions = ArrayList<Pair<Int, CharArray>>()
        for (i in normalizedWord.indices) {
            when (normalizedWord[i]) {
                'ا' -> {
                    // الهمزة أكثر شيوعاً في بداية الكلمة أو بعد ال التعريف أو همزة القطع
                    expandablePositions.add(i to charArrayOf('ا', 'أ', 'إ'))
                }
                'ه' -> {
                    if (i == normalizedWord.lastIndex) {
                        expandablePositions.add(i to charArrayOf('ه', 'ة'))
                    }
                }
                'ي' -> {
                    if (i == normalizedWord.lastIndex) {
                        expandablePositions.add(i to charArrayOf('ي', 'ى'))
                    }
                }
            }
        }

        if (expandablePositions.isEmpty()) return

        // ترتيب المواضع ذات الأولوية أولاً (الحرف الأول والأخير) لمنع تضخم التوليفات
        val prioritized = expandablePositions
            .sortedBy { (idx, _) ->
                when (idx) {
                    0 -> 0
                    normalizedWord.lastIndex -> 1
                    else -> 2
                }
            }
            .take(4)

        var currentVariants = mutableListOf(normalizedWord.toCharArray())
        for ((pos, replacements) in prioritized) {
            val nextVariants = ArrayList<CharArray>(minOf(currentVariants.size * replacements.size, maxCount))
            outer@ for (chars in currentVariants) {
                for (rep in replacements) {
                    val copy = chars.copyOf()
                    copy[pos] = rep
                    nextVariants.add(copy)
                    if (nextVariants.size >= maxCount) break@outer
                }
            }
            currentVariants = nextVariants
        }

        for (chars in currentVariants) {
            if (target.size >= maxCount) break
            target.add(String(chars))
        }
    }

    private fun isDiacriticOrTatweel(ch: Char): Boolean {
        val code = ch.code
        return (code in 0x064B..0x065F) || code == 0x0670 || ch == 'ـ'
    }
}
