package com.humanitarian.aidmanagement.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * مولّد ومشارك بطاقة قسيمة الاستلام الرقمية بصيغة PNG لمشاركتها مباشرة عبر WhatsApp.
 * يعتمد حصراً على مكتبات Android القياسية المدمجة مع ضابط ذاكرة صارم (800x1100 + bitmap.recycle() في finally).
 */
object WhatsAppVoucherCardGenerator {

    private const val CARD_WIDTH = 800
    private const val CARD_HEIGHT = 1100
    private const val VOUCHERS_CACHE_DIR = "vouchers"

    /**
     * يولّد بطاقة قسيمة استلام رسمية موقّعة رقمياً عبر OfflineVoucherCrypto،
     * يحفظها في context.cacheDir/vouchers/ ثم يفتح نافذة المشاركة عبر FileProvider لإرسالها عبر WhatsApp.
     */
    fun shareVoucherCardViaWhatsApp(
        context: Context,
        projectId: String,
        projectName: String,
        pickupLocation: String,
        familyNationalId: String,
        beneficiaryName: String,
        fileProviderAuthority: String? = null
    ): Result<File> = runCatching {
        val signedPayload = OfflineVoucherCrypto.generateVoucherPayload(
            context = context,
            projectId = projectId,
            familyNationalId = familyNationalId,
            beneficiaryName = beneficiaryName
        )

        val pngFile = generateVoucherCardPng(
            context = context,
            projectId = projectId,
            projectName = projectName,
            pickupLocation = pickupLocation,
            familyNationalId = familyNationalId,
            beneficiaryName = beneficiaryName,
            signedPayload = signedPayload
        )

        val authority = fileProviderAuthority?.takeIf { it.isNotBlank() }
            ?: "${context.packageName}.fileprovider"
        val contentUri = FileProvider.getUriForFile(context, authority, pngFile)

        val captionText = buildString {
            append("قسيمة استلام مساعدة إنسانية\n")
            append("المشروع: ${projectName.ifBlank { "مشروع رقم $projectId" }}\n")
            append("المستفيد: ${beneficiaryName.ifBlank { "-" }}\n")
            append("رقم الهوية: ${familyNationalId.ifBlank { "-" }}\n")
            append("نقطة الاستلام: ${pickupLocation.ifBlank { "المستودع الرئيسي" }}\n")
            append("كود التحقق: $signedPayload\n")
            append("يُرجى إبراز هذه البطاقة عند الاستلام.")
        }

        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, contentUri)
            putExtra(Intent.EXTRA_TEXT, captionText)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        // محاولة التوجيه المباشر إلى WhatsApp إن كان مثبتاً، وإلا فتح قائمة المشاركة العامة
        val whatsappIntent = Intent(shareIntent).setPackage("com.whatsapp")
        val pm = context.packageManager
        val targetIntent = if (whatsappIntent.resolveActivity(pm) != null) {
            whatsappIntent
        } else {
            val whatsappBusinessIntent = Intent(shareIntent).setPackage("com.whatsapp.w4b")
            if (whatsappBusinessIntent.resolveActivity(pm) != null) {
                whatsappBusinessIntent
            } else {
                Intent.createChooser(shareIntent, "إرسال قسيمة الاستلام عبر واتساب").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        }

        context.startActivity(targetIntent)
        pngFile
    }

    /**
     * يرسم البطاقة بأبعاد 800x1100 بكسل (ARGB_8888) ويحفظها كملف PNG مؤقت
     * مع استدعاء bitmap.recycle() فوراً داخل كتلة finally لحماية الذاكرة (256MB Heap).
     */
    fun generateVoucherCardPng(
        context: Context,
        projectId: String,
        projectName: String,
        pickupLocation: String,
        familyNationalId: String,
        beneficiaryName: String,
        signedPayload: String
    ): File {
        val cacheDir = File(context.cacheDir, VOUCHERS_CACHE_DIR).apply {
            if (!exists()) mkdirs()
        }
        val safeProject = sanitizeFileToken(projectId).ifBlank { "proj" }
        val safeNatId = sanitizeFileToken(familyNationalId).ifBlank { "family" }
        val outFile = File(cacheDir, "voucher_${safeProject}_${safeNatId}.png")

        val bitmap = Bitmap.createBitmap(CARD_WIDTH, CARD_HEIGHT, Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(bitmap)
            drawVoucherCard(
                canvas = canvas,
                projectId = projectId,
                projectName = projectName,
                pickupLocation = pickupLocation,
                familyNationalId = familyNationalId,
                beneficiaryName = beneficiaryName,
                signedPayload = signedPayload
            )

            FileOutputStream(outFile).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 95, fos)
                fos.flush()
            }
        } finally {
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }
        return outFile
    }

    private fun drawVoucherCard(
        canvas: Canvas,
        projectId: String,
        projectName: String,
        pickupLocation: String,
        familyNationalId: String,
        beneficiaryName: String,
        signedPayload: String
    ) {
        val w = CARD_WIDTH.toFloat()
        val h = CARD_HEIGHT.toFloat()

        // 1) خلفية الصفحة والبطاقة الرئيسية
        canvas.drawColor(Color.parseColor("#EEF6F2"))

        val cardRect = RectF(28f, 28f, w - 28f, h - 28f)
        val cardFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val cardStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#C7DED2")
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        canvas.drawRoundRect(cardRect, 28f, 28f, cardFillPaint)
        canvas.drawRoundRect(cardRect, 28f, 28f, cardStrokePaint)

        // 2) الترويسة العلوية المتدرجة باسم المشروع ونقطة الاستلام
        val headerRect = RectF(28f, 28f, w - 28f, 250f)
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 28f, w, 250f,
                Color.parseColor("#0B5D3F"),
                Color.parseColor("#118A5E"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRoundRect(headerRect, 28f, 28f, headerPaint)
        // تسوية الحافة السفلية للترويسة
        canvas.drawRect(28f, 215f, w - 28f, 250f, headerPaint)

        val goldBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D97706")
            style = Paint.Style.FILL
        }
        canvas.drawRect(28f, 250f, w - 28f, 258f, goldBarPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 36f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E6F7EF")
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val locationPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FEF3C7")
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }

        val cleanProjectName = projectName.trim().ifBlank { "مشروع إغاثي #$projectId" }
        val cleanLocation = pickupLocation.trim().ifBlank { "نقطة التوزيع المعتمدة" }

        canvas.drawText("قسيمة استلام مساعدة إنسانية", w / 2f, 96f, titlePaint)
        canvas.drawText(ellipsizeText(cleanProjectName, subtitlePaint, w - 120f), w / 2f, 152f, subtitlePaint)
        canvas.drawText(
            ellipsizeText("نقطة الاستلام: $cleanLocation", locationPaint, w - 120f),
            w / 2f,
            208f,
            locationPaint
        )

        // 3) صندوق بيانات المستفيد (محاذاة عربية يمينية RTL)
        val infoBoxRect = RectF(58f, 286f, w - 58f, 598f)
        val infoBoxFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F7FBF9")
            style = Paint.Style.FILL
        }
        val infoBoxStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#D3E6DC")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRoundRect(infoBoxRect, 20f, 20f, infoBoxFill)
        canvas.drawRoundRect(infoBoxRect, 20f, 20f, infoBoxStroke)

        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#DCECE4")
            strokeWidth = 1.5f
        }

        val rightX = w - 88f
        val maxValWidth = w - 190f
        val issuedDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

        // صف 1: اسم المستفيد
        canvas.drawText("اسم المستفيد", rightX, 330f, labelPaint)
        canvas.drawText(
            ellipsizeText(beneficiaryName.trim().ifBlank { "غير محدد" }, valuePaint, maxValWidth),
            rightX,
            370f,
            valuePaint
        )
        canvas.drawLine(84f, 392f, w - 84f, 392f, dividerPaint)

        // صف 2: رقم الهوية
        canvas.drawText("رقم الهوية الوطنية", rightX, 430f, labelPaint)
        canvas.drawText(
            familyNationalId.trim().ifBlank { "-" },
            rightX,
            470f,
            valuePaint
        )
        canvas.drawLine(84f, 492f, w - 84f, 492f, dividerPaint)

        // صف 3: رقم المشروع وتاريخ الإصدار
        canvas.drawText("رقم المشروع وتاريخ الإصدار", rightX, 530f, labelPaint)
        canvas.drawText(
            "مشروع #${projectId.trim().ifBlank { "-" }}  •  $issuedDate",
            rightX,
            570f,
            valuePaint
        )

        // 4) منطقة رمز التحقق البصري (باركود مشفّر مرسوم بـ Canvas بدون مكتبات خارجية) ونص القسيمة
        val codeBoxRect = RectF(58f, 626f, w - 58f, 922f)
        val codeBoxFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val codeBoxStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F7B53")
            style = Paint.Style.STROKE
            strokeWidth = 2.5f
        }
        canvas.drawRoundRect(codeBoxRect, 20f, 20f, codeBoxFill)
        canvas.drawRoundRect(codeBoxRect, 20f, 20f, codeBoxStroke)

        val sectionHeaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F7B53")
            textSize = 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("رمز التحقق الرقمي المشفّر (Offline HMAC)", w / 2f, 666f, sectionHeaderPaint)

        // رسم باركود تحقق بصري واضح ومتباين مشتق من نص القسيمة الموقّعة
        val barcodeRect = RectF(108f, 686f, w - 108f, 816f)
        drawDeterministicVerificationBarcode(canvas, barcodeRect, signedPayload)

        val signatureToken = signedPayload.substringAfterLast("|", signedPayload)
        val sigBadgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 23f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("التوقيع: $signatureToken", w / 2f, 856f, sigBadgePaint)

        val payloadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#475569")
            textSize = 16f
            typeface = Typeface.MONOSPACE
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(
            ellipsizeText(signedPayload, payloadPaint, w - 150f),
            w / 2f,
            896f,
            payloadPaint
        )

        // 5) شريط التنبيه الإلزامي أسفل البطاقة
        val noticeRect = RectF(58f, 948f, w - 58f, 1044f)
        val noticeFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FEF3C7")
            style = Paint.Style.FILL
        }
        val noticeStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F59E0B")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRoundRect(noticeRect, 16f, 16f, noticeFill)
        canvas.drawRoundRect(noticeRect, 16f, 16f, noticeStroke)

        val noticePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#92400E")
            textSize = 23f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("يُرجى إبراز هذه البطاقة عند الاستلام", w / 2f, 992f, noticePaint)

        val subNoticePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#B45309")
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("تُستخدم هذه القسيمة لمرة واحدة فقط ضمن المشروع المحدد", w / 2f, 1026f, subNoticePaint)
    }

    /**
     * يرسم باركود تحقق بصري ثنائي التباين من بايتات القسيمة المشفّرة باستخدام Canvas القياسي فقط.
     */
    private fun drawDeterministicVerificationBarcode(
        canvas: Canvas,
        bounds: RectF,
        payload: String
    ) {
        val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            style = Paint.Style.FILL
        }
        val bytes = payload.toByteArray(Charsets.UTF_8)
        if (bytes.isEmpty()) return

        // بناء سلسلة بتات مضغوطة (حراس بداية ونهاية + بتات النص المشفّر)
        val bits = ArrayList<Boolean>(bytes.size * 8 + 16)
        // حارس البداية
        bits.add(true); bits.add(false); bits.add(true); bits.add(true); bits.add(false)
        val maxBytes = minOf(bytes.size, 28)
        for (i in 0 until maxBytes) {
            val value = bytes[i].toInt() and 0xFF
            for (bitIdx in 7 downTo 0) {
                bits.add(((value shr bitIdx) and 1) == 1)
            }
        }
        // حارس النهاية
        bits.add(false); bits.add(true); bits.add(true); bits.add(false); bits.add(true)

        val moduleWidth = bounds.width() / bits.size.toFloat()
        var x = bounds.left
        for (isBlack in bits) {
            if (isBlack) {
                canvas.drawRect(x, bounds.top, x + moduleWidth, bounds.bottom, barPaint)
            }
            x += moduleWidth
        }
    }

    private fun ellipsizeText(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        val suffix = "..."
        var end = text.length
        while (end > 1 && paint.measureText(text.substring(0, end) + suffix) > maxWidth) {
            end--
        }
        return text.substring(0, end) + suffix
    }

    private fun sanitizeFileToken(raw: String): String {
        return raw.trim().replace(Regex("[^A-Za-z0-9_-]"), "")
    }
}
