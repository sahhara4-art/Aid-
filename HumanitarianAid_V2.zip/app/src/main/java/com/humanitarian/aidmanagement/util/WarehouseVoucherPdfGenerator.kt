package com.humanitarian.aidmanagement.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import com.humanitarian.aidmanagement.warehouse.BlindAuditBatchReport
import com.humanitarian.aidmanagement.warehouse.ClientBillingSummary
import com.humanitarian.aidmanagement.warehouse.ClientStorageTx
import com.humanitarian.aidmanagement.warehouse.ClientStorageTxType
import com.humanitarian.aidmanagement.warehouse.StockMovement
import com.humanitarian.aidmanagement.warehouse.StockMovementType
import com.humanitarian.aidmanagement.warehouse.StorageClient
import com.humanitarian.aidmanagement.warehouse.Warehouse
import com.humanitarian.aidmanagement.warehouse.WarehouseBudgetEntry
import com.humanitarian.aidmanagement.warehouse.WarehouseErpStore
import com.humanitarian.aidmanagement.warehouse.WarehouseExpense
import com.humanitarian.aidmanagement.warehouse.WarehouseFinancialSummary
import com.humanitarian.aidmanagement.warehouse.WarehouseItem
import com.humanitarian.aidmanagement.warehouse.WarehousePayrollRecord
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

data class DynamicReportPdfSection(
    val title: String,
    val headers: List<String>,
    val weights: List<Float>,
    val rows: List<List<String>>,
    val emptyText: String = "لا توجد بيانات مسجلة ضمن نطاق الفلترة المحدد"
)

/**
 * أداة توليد وطباعة سندات المخازن وفواتير التخزين للغير (3PL) ومحاضر الجرد الأعمى والميزانية
 * بصيغة PDF رسمية باللغة العربية (RTL) وبنفس الهوية الزجاجية الخضراء،
 * مع الحفظ المباشر في مجلد Downloads/HumanitarianAid.
 */
object WarehouseVoucherPdfGenerator {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val MARGIN_X = 30f
    private const val CONTENT_WIDTH = PAGE_WIDTH - 60f

    private val COLOR_HEADER_DARK = Color.parseColor("#064E3B")
    private val COLOR_HEADER_LIGHT = Color.parseColor("#059669")
    private val COLOR_SURFACE_MINT = Color.parseColor("#ECFDF5")
    private val COLOR_BORDER_MINT = Color.parseColor("#A7F3D0")
    private val COLOR_BORDER_SLATE = Color.parseColor("#CBD5E1")
    private val COLOR_SURFACE_ALT = Color.parseColor("#F8FAFC")
    private val COLOR_TEXT_PRIMARY = Color.parseColor("#0F172A")
    private val COLOR_TEXT_SECONDARY = Color.parseColor("#475569")
    private val COLOR_ACCENT_RED = Color.parseColor("#B91C1C")
    private val COLOR_ACCENT_AMBER = Color.parseColor("#B45309")

    private fun fileStamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun nowDisplay(): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())

    private fun formatMoney(amount: Double): String = String.format(Locale.US, "%.2f", amount)

    // ========================================================================
    // 1. سند استلام واردات (GRN) / سند إرسال صادرات (GDN) / مناقلة / طرود
    // ========================================================================

    suspend fun generateStockMovementVoucherPdf(
        context: Context,
        warehouse: Warehouse,
        movement: StockMovement,
        item: WarehouseItem?,
        targetWarehouseName: String? = null
    ): SavedExportResult = withContext(Dispatchers.IO) {
        val doc = PdfDocument()
        try {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
            val page = doc.startPage(pageInfo)
            val canvas = page.canvas

            val title = when (movement.type) {
                StockMovementType.IN -> "سند استلام واردات مخزنية (GRN)"
                StockMovementType.OUT -> "سند إرسال صادرات / تصريح خروج (GDN)"
                StockMovementType.TRANSFER -> "سند مناقلة مخزنية معتمد (TRANSFER)"
                StockMovementType.KIT_ASSEMBLE -> "محضر تجميع طرود إغاثية (KIT ASSEMBLE)"
                StockMovementType.KIT_UNBUNDLE -> "محضر تفكيك طرود مخزنية (KIT UNBUNDLE)"
                StockMovementType.DELIVERY_DEDUCT -> "إشعار خصم تسليم ميداني آلي"
                StockMovementType.DELIVERY_RESTORE -> "إشعار إرجاع تسليم مخزني آلي"
                StockMovementType.AUDIT_ADJUST -> "سند تسوية جرد أعمى"
            }

            var y = drawInstitutionalHeader(
                canvas = canvas,
                title = title,
                subtitle = "رقم السند: ${movement.voucherNo}  •  التاريخ: ${movement.date}",
                badgeText = movement.type.voucherPrefix
            )

            val absDelta = abs(movement.totalMinorDelta)
            val isGatePassVoucher = movement.type == StockMovementType.OUT || movement.type == StockMovementType.TRANSFER
            if (isGatePassVoucher) {
                val matchedShipment = WarehouseErpStore.currentState.inTransitShipments
                    .firstOrNull { it.voucherNo == movement.voucherNo }
                val shipmentId = matchedShipment?.shipmentId ?: movement.voucherNo
                val fromName = warehouse.name.replace("|", "-")
                val toName = (targetWarehouseName ?: movement.recipientOrProject).ifBlank { "-" }.replace("|", "-")
                val driverSafe = movement.driverName.ifBlank { "-" }.replace("|", "-")
                val rawGatePassData = "SHIPMENT|$shipmentId|$fromName|$toName|$absDelta|$driverSafe"
                val securityHash = computeShortSha256("$rawGatePassData|${movement.waybillNo}|GATEPASS")
                val encodedPayload = "$rawGatePassData|HASH:$securityHash"

                y = drawGatePassQrCard(
                    canvas = canvas,
                    startY = y + 8f,
                    qrPayload = encodedPayload,
                    gatePassToken = movement.waybillNo.ifBlank { matchedShipment?.gatePassToken ?: movement.voucherNo },
                    routeSummary = "${warehouse.name} ⬅ ${targetWarehouseName ?: movement.recipientOrProject.ifBlank { "-" }}",
                    driverSummary = "${movement.driverName.ifBlank { "غير محدد" }} (${movement.vehiclePlate.ifBlank { "-" }})",
                    securityHash = securityHash
                )
            }

            // بطاقة بيانات المخزن
            y = drawKeyValueCard(
                canvas = canvas,
                startY = y + 8f,
                sectionTitle = "أولاً: بيانات المخزن والمسؤول",
                rows = listOf(
                    "اسم المخزن" to "${warehouse.name} (${warehouse.storageType}) • ${warehouse.location.ifBlank { "-" }}",
                    "أمين المخزن" to "${warehouse.keeperName.ifBlank { "-" }} ${if (warehouse.keeperPhone.isNotBlank()) "• ${warehouse.keeperPhone}" else ""}".trim(),
                    "منفذ الحركة" to movement.performedBy.ifBlank { warehouse.keeperName.ifBlank { "أمين المخزن" } }
                )
            )

            // بطاقة تفاصيل الأصناف والكميات بالوحدات المزدوجة
            val majorLabel = item?.majorUnitName?.ifBlank { "وحدة كبرى" } ?: "جملة"
            val minorLabel = item?.minorUnitName?.ifBlank { "قطعة" } ?: "فردي"
            val convFactor = item?.safeConversionFactor ?: 1
            val signPrefix = if (movement.totalMinorDelta >= 0L) "+" else "-"
            val detailRows = mutableListOf(
                "اسم الصنف" to movement.itemName,
                "الكمية بالوحدة الكبرى ($majorLabel) / الصغرى ($minorLabel)" to "${movement.majorQty} $majorLabel + ${movement.minorQty} $minorLabel (معامل: $convFactor)",
                "إجمالي الحركة (بالوحدة الصغرى)" to "$signPrefix$absDelta $minorLabel"
            )
            if (item != null) {
                detailRows.add("الرصيد الحالي المتبقي للصنف" to item.formatDualQuantity())
            }
            y = drawKeyValueCard(
                canvas = canvas,
                startY = y + 8f,
                sectionTitle = "ثانياً: تفاصيل الصنف والكميات (جملة / فردي)",
                rows = detailRows
            )

            // بطاقة بيانات التوريد / الصرف / السائق والمركبة
            val logisticsRows = mutableListOf<Pair<String, String>>()
            if (movement.supplierOrDonor.isNotBlank()) {
                logisticsRows.add("المورد / الجهة المانحة" to movement.supplierOrDonor)
            }
            if (movement.waybillNo.isNotBlank()) {
                logisticsRows.add(
                    (if (isGatePassVoucher) "رقم تصريح الخروج / البوليصة" else "رقم بوليصة الشحن / الإرسالية") to movement.waybillNo
                )
            }
            if (movement.recipientOrProject.isNotBlank()) {
                val lbl = if (movement.type == StockMovementType.TRANSFER) "المخزن المستقبل" else "الجهة المستلمة / المشروع"
                logisticsRows.add(lbl to (targetWarehouseName ?: movement.recipientOrProject))
            }
            if (!movement.linkedProjectId.isNullOrBlank()) {
                logisticsRows.add("معرف المشروع المرتبط" to "#${movement.linkedProjectId}")
            }
            if (movement.driverName.isNotBlank() || movement.vehiclePlate.isNotBlank()) {
                logisticsRows.add("السائق والمركبة" to "${movement.driverName.ifBlank { "-" }} • لوحة: ${movement.vehiclePlate.ifBlank { "-" }}")
            }
            if (movement.notes.isNotBlank()) {
                logisticsRows.add("ملاحظات السند" to movement.notes)
            }
            if (logisticsRows.isEmpty()) {
                logisticsRows.add("بيانات إضافية" to "لا توجد ملاحظات إضافية مسجلة على هذا السند")
            }

            y = drawKeyValueCard(
                canvas = canvas,
                startY = y + 8f,
                sectionTitle = "ثالثاً: بيانات النقل والجهة ذات العلاقة",
                rows = logisticsRows
            )

            // جدول تفصيلي بالتشغيلات المصروفة / المسجلة (Batch No — FEFO)
            val batchTokens = movement.batchNo
                .split(",")
                .map { it.trim() }
                .filter { it.isNotBlank() }
            if (isGatePassVoucher || batchTokens.isNotEmpty()) {
                val stateBatches = WarehouseErpStore.currentState.batches.filter { it.itemId == movement.itemId }
                val batchRows = if (batchTokens.isNotEmpty()) {
                    batchTokens.take(5).map { bNo ->
                        val matched = stateBatches.firstOrNull { it.batchNo.equals(bNo, ignoreCase = true) }
                        listOf(
                            bNo,
                            matched?.donorName?.ifBlank { movement.supplierOrDonor.ifBlank { "-" } } ?: movement.supplierOrDonor.ifBlank { "-" },
                            matched?.expiryDate?.ifBlank { item?.expiryDate?.ifBlank { "-" } ?: "-" } ?: (item?.expiryDate?.ifBlank { "-" } ?: "-"),
                            matched?.zoneName?.ifBlank { "جاف" } ?: "جاف",
                            if (batchTokens.size == 1) "$absDelta $minorLabel" else "ضمن دفعة ($absDelta $minorLabel)"
                        )
                    }
                } else {
                    listOf(
                        listOf(
                            "FEFO-AUTO",
                            movement.supplierOrDonor.ifBlank { "-" },
                            item?.expiryDate?.ifBlank { "-" } ?: "-",
                            "جاف",
                            "$absDelta $minorLabel"
                        )
                    )
                }
                y = drawRtlTable(
                    canvas = canvas,
                    startY = y + 8f,
                    sectionTitle = "رابعاً: جدول التشغيلات المصروفة (Batch No / FEFO)",
                    headers = listOf("رقم التشغيلة (Batch No)", "الجهة المانحة", "تاريخ الانتهاء", "المنطقة", "الكمية المصروفة"),
                    weights = listOf(0.26f, 0.22f, 0.18f, 0.14f, 0.20f),
                    rows = batchRows,
                    emptyText = "لا توجد تشغيلات محددة"
                )
            }

            // خانة التوقيعات وختم أمين المخزن الرسمي
            val sigStartY = minOf(maxOf(y + 12f, PAGE_HEIGHT - 128f), PAGE_HEIGHT - 122f)
            drawSignaturesAndStampBlock(
                canvas = canvas,
                startY = sigStartY,
                rightLabel = "توقيع وختم أمين المخزن",
                rightSub = warehouse.keeperName.ifBlank { movement.performedBy },
                centerLabel = "توقيع السائق / الناقل",
                centerSub = movement.driverName.ifBlank { "........................" },
                leftLabel = if (movement.type == StockMovementType.IN) "توقيع المورد / المسلّم" else "توقيع المستلم المعتمد",
                leftSub = movement.recipientOrProject.ifBlank { movement.supplierOrDonor.ifBlank { "........................" } },
                showOfficialKeeperStamp = true
            )

            drawPageFooter(canvas, 1, 1)
            doc.finishPage(page)

            val safeVoucher = movement.voucherNo.replace(Regex("[^A-Za-z0-9_-]"), "_")
            PublicDownloadsExporter.savePdfToPublicDownloads(
                context = context,
                fileName = "Warehouse_${safeVoucher}_${fileStamp()}.pdf"
            ) { outputStream ->
                doc.writeTo(outputStream)
            }
        } finally {
            doc.close()
        }
    }

    // ========================================================================
    // 2. سند إيداع / سحب بضائع للغير (3PL Storage Voucher)
    // ========================================================================

    suspend fun generateClientStorageVoucherPdf(
        context: Context,
        warehouse: Warehouse,
        client: StorageClient,
        tx: ClientStorageTx,
        billingSummary: ClientBillingSummary
    ): SavedExportResult = withContext(Dispatchers.IO) {
        val doc = PdfDocument()
        try {
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create()
            val page = doc.startPage(pageInfo)
            val canvas = page.canvas

            val title = when (tx.type) {
                ClientStorageTxType.DEPOSIT -> "سند إيداع بضائع تخزين للغير (3PL Deposit)"
                ClientStorageTxType.WITHDRAWAL -> "سند سحب وإخراج بضائع للغير (3PL Withdrawal)"
                ClientStorageTxType.PAYMENT -> "سند قبض دفعة مالية لتخزين للغير (3PL Receipt)"
            }

            var y = drawInstitutionalHeader(
                canvas = canvas,
                title = title,
                subtitle = "رقم الحركة: ${tx.id}  •  التاريخ: ${tx.date}",
                badgeText = "3PL"
            )

            y = drawKeyValueCard(
                canvas = canvas,
                startY = y + 12f,
                sectionTitle = "بيانات المخزن والعميل المودِع",
                rows = listOf(
                    "المخزن" to "${warehouse.name} (${warehouse.storageType})",
                    "اسم العميل / الجهة المودِعة" to client.clientName,
                    "مسؤول التواصل / الهاتف" to "${client.contactPerson.ifBlank { "-" }} • ${client.phone.ifBlank { "-" }}",
                    "نظام التسعير المتفق عليه" to "${client.billingModel.arabicLabel} • التعرفة: ${formatMoney(client.unitRate)} • السماح: ${client.freeGraceDays} يوم"
                )
            )

            val txRows = mutableListOf(
                "نوع العملية" to tx.type.arabicLabel,
                "تاريخ العملية" to tx.date
            )
            if (tx.type == ClientStorageTxType.PAYMENT) {
                txRows.add("المبلغ المقبوض" to formatMoney(tx.paymentAmount))
            } else {
                txRows.add("وصف البضاعة / الطرود" to tx.itemDescription.ifBlank { "بضائع مخزنة للغير" })
                txRows.add("عدد القطع" to "${tx.quantityPieces} قطعة")
            }
            if (tx.notes.isNotBlank()) {
                txRows.add("ملاحظات" to tx.notes)
            }
            txRows.add("الرصيد المتبقي للعميل في المخزن حالياً" to "${billingSummary.remainingPieces} قطعة")
            txRows.add("صافي المستحق المالي على العميل حتى تاريخه" to formatMoney(billingSummary.netAmountDue))

            y = drawKeyValueCard(
                canvas = canvas,
                startY = y + 10f,
                sectionTitle = "تفاصيل السند والرصيد المحدث",
                rows = txRows
            )

            drawSignaturesAndStampBlock(
                canvas = canvas,
                startY = maxOf(y + 26f, PAGE_HEIGHT - 165f),
                rightLabel = "توقيع وختم أمين المخزن",
                rightSub = warehouse.keeperName.ifBlank { tx.performedBy },
                centerLabel = "المحاسب اللوجستي",
                centerSub = "........................",
                leftLabel = "توقيع ممثل العميل",
                leftSub = client.contactPerson.ifBlank { client.clientName }
            )

            drawPageFooter(canvas, 1, 1)
            doc.finishPage(page)

            PublicDownloadsExporter.savePdfToPublicDownloads(
                context = context,
                fileName = "3PL_Voucher_${tx.type.name}_${fileStamp()}.pdf"
            ) { outputStream ->
                doc.writeTo(outputStream)
            }
        } finally {
            doc.close()
        }
    }

    // ========================================================================
    // 3. كشف حساب ومطالبة مالية لعميل تخزين (3PL Invoice)
    // ========================================================================

    suspend fun generateClientInvoicePdf(
        context: Context,
        warehouse: Warehouse,
        client: StorageClient,
        transactions: List<ClientStorageTx>,
        summary: ClientBillingSummary
    ): SavedExportResult = withContext(Dispatchers.IO) {
        val doc = PdfDocument()
        try {
            val sortedTxs = transactions.sortedBy { it.date }
            val rowsPerPage = 16
            val totalPages = maxOf(1, (sortedTxs.size + rowsPerPage - 1) / rowsPerPage)

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageIndex + 1).create()
                val page = doc.startPage(pageInfo)
                val canvas = page.canvas

                var y = drawInstitutionalHeader(
                    canvas = canvas,
                    title = "كشف حساب ومطالبة مالية — تخزين للغير (3PL Invoice)",
                    subtitle = "العميل: ${client.clientName}  •  تاريخ الإصدار: ${nowDisplay()}",
                    badgeText = "فاتورة"
                )

                if (pageIndex == 0) {
                    y = drawKeyValueCard(
                        canvas = canvas,
                        startY = y + 10f,
                        sectionTitle = "بيانات التعاقد والتعرفة",
                        rows = listOf(
                            "المخزن" to "${warehouse.name} (${warehouse.location.ifBlank { "-" }})",
                            "العميل / الجهة" to "${client.clientName} • ${client.contactPerson.ifBlank { "-" }} • ${client.phone.ifBlank { "-" }}",
                            "نظام الاحتساب" to "${client.billingModel.arabicLabel} • السعر: ${formatMoney(client.unitRate)} • رسوم مناولة: ${formatMoney(client.handlingFee)} • سماح مجاني: ${client.freeGraceDays} يوم"
                        )
                    )

                    // ملخص المطالبة المالية
                    y = drawKpiStrip(
                        canvas = canvas,
                        startY = y + 10f,
                        items = listOf(
                            Triple("القطع المتبقية", "${summary.remainingPieces} قطعة", COLOR_HEADER_DARK),
                            Triple("أيام التخزين", "${summary.totalBillableStorageDays} يوم", COLOR_TEXT_PRIMARY),
                            Triple("إجمالي الأجرة", formatMoney(summary.totalCharges), COLOR_ACCENT_AMBER),
                            Triple("المدفوع", formatMoney(summary.totalPaid), COLOR_HEADER_LIGHT),
                            Triple("صافي المستحق", formatMoney(summary.netAmountDue), if (summary.netAmountDue > 0.0) COLOR_ACCENT_RED else COLOR_HEADER_LIGHT)
                        )
                    )
                }

                // جدول الحركات
                val sliceStart = pageIndex * rowsPerPage
                val sliceEnd = minOf(sortedTxs.size, sliceStart + rowsPerPage)
                val pageSlice = if (sliceStart < sortedTxs.size) sortedTxs.subList(sliceStart, sliceEnd) else emptyList()

                val headers = listOf("التاريخ", "نوع الحركة", "الوصف / البيان", "الكمية", "المبلغ المدفوع")
                val weights = listOf(0.18f, 0.22f, 0.30f, 0.14f, 0.16f)
                val tableRows = pageSlice.map { tx ->
                    listOf(
                        tx.date,
                        tx.type.arabicLabel,
                        tx.itemDescription.ifBlank { tx.notes.ifBlank { "-" } },
                        if (tx.type == ClientStorageTxType.PAYMENT) "-" else "${tx.quantityPieces}",
                        if (tx.type == ClientStorageTxType.PAYMENT) formatMoney(tx.paymentAmount) else "-"
                    )
                }

                y = drawRtlTable(
                    canvas = canvas,
                    startY = y + 12f,
                    sectionTitle = "جدول حركات الإيداع والسحب والسداد (${sortedTxs.size} حركة)",
                    headers = headers,
                    weights = weights,
                    rows = tableRows,
                    emptyText = "لا توجد حركات مسجلة لهذا العميل حتى الآن"
                )

                if (pageIndex == totalPages - 1) {
                    y = drawKeyValueCard(
                        canvas = canvas,
                        startY = y + 10f,
                        sectionTitle = "تفصيل الاحتساب الآلي للمطالبة (FIFO)",
                        rows = listOf(
                            "إجمالي القطع المودعة / المسحوبة / المتبقية" to "${summary.totalDepositedPieces} مودع  |  ${summary.totalWithdrawnPieces} مسحوب  |  ${summary.remainingPieces} متبقي",
                            "إجمالي (قطعة × يوم) بعد خصم أيام السماح" to "${summary.totalBillablePieceDays} قطعة-يوم",
                            "أجرة التخزين + رسوم المناولة" to "${formatMoney(summary.storageFeeTotal)} + ${formatMoney(summary.handlingFeeTotal)} = ${formatMoney(summary.totalCharges)}",
                            "إجمالي الدفعات المسددة" to formatMoney(summary.totalPaid),
                            "صافي المبلغ المستحق للدفع" to formatMoney(summary.netAmountDue)
                        )
                    )

                    if (y < PAGE_HEIGHT - 140f) {
                        drawSignaturesAndStampBlock(
                            canvas = canvas,
                            startY = maxOf(y + 18f, PAGE_HEIGHT - 145f),
                            rightLabel = "أمين المخزن",
                            rightSub = warehouse.keeperName.ifBlank { "........................" },
                            centerLabel = "المحاسبة اللوجستية",
                            centerSub = "معتمد رسمياً",
                            leftLabel = "إقرار واستلام العميل",
                            leftSub = client.clientName
                        )
                    }
                }

                drawPageFooter(canvas, pageIndex + 1, totalPages)
                doc.finishPage(page)
            }

            PublicDownloadsExporter.savePdfToPublicDownloads(
                context = context,
                fileName = "3PL_Invoice_${fileStamp()}.pdf"
            ) { outputStream ->
                doc.writeTo(outputStream)
            }
        } finally {
            doc.close()
        }
    }

    // ========================================================================
    // 4. محضر وكشف الجرد الأعمى والفروقات (Blind Audit Report PDF)
    // ========================================================================

    suspend fun generateBlindAuditReportPdf(
        context: Context,
        warehouse: Warehouse,
        report: BlindAuditBatchReport
    ): SavedExportResult = withContext(Dispatchers.IO) {
        val doc = PdfDocument()
        try {
            val rowsPerPage = 18
            val totalPages = maxOf(1, (report.results.size + rowsPerPage - 1) / rowsPerPage)

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageIndex + 1).create()
                val page = doc.startPage(pageInfo)
                val canvas = page.canvas

                var y = drawInstitutionalHeader(
                    canvas = canvas,
                    title = "محضر وكشف الجرد الأعمى والفروقات المخزنية",
                    subtitle = "المخزن: ${warehouse.name}  •  التاريخ: ${report.auditedAt}",
                    badgeText = "جرد أعمى"
                )

                if (pageIndex == 0) {
                    val deficits = report.results.count { it.varianceMinorQty < 0L }
                    val surpluses = report.results.count { it.varianceMinorQty > 0L }
                    val matched = report.results.count { it.varianceMinorQty == 0L }
                    y = drawKeyValueCard(
                        canvas = canvas,
                        startY = y + 10f,
                        sectionTitle = "بيانات التوثيق والرقابة (SHA-256)",
                        rows = listOf(
                            "المخزن / أمين المخزن" to "${warehouse.name} • ${warehouse.keeperName.ifBlank { "-" }}",
                            "منفذ الجرد" to report.performedBy,
                            "ملخص النتيجة" to "إجمالي الأصناف: ${report.results.size}  |  مطابق: $matched  |  عجز: $deficits  |  زيادة: $surpluses",
                            "ملاحظة الجرد" to report.reason.ifBlank { "جرد دوري معتمد" },
                            "بصمة سجل الرقابة (SHA-256)" to report.auditEntryHash.ifBlank { "موثّق في سجل الرقابة" }
                        )
                    )
                }

                val sliceStart = pageIndex * rowsPerPage
                val sliceEnd = minOf(report.results.size, sliceStart + rowsPerPage)
                val pageSlice = if (sliceStart < report.results.size) report.results.subList(sliceStart, sliceEnd) else emptyList()

                val headers = listOf("الصنف", "الرصيد الدفتري", "العد الفعلي", "الفارق", "الحالة")
                val weights = listOf(0.36f, 0.16f, 0.16f, 0.16f, 0.16f)
                val tableRows = pageSlice.map { res ->
                    val statusLabel = when {
                        res.varianceMinorQty == 0L -> "مطابق"
                        res.varianceMinorQty < 0L -> "عجز"
                        else -> "زيادة"
                    }
                    val varStr = if (res.varianceMinorQty > 0L) "+${res.varianceMinorQty}" else "${res.varianceMinorQty}"
                    listOf(
                        res.itemName,
                        "${res.systemMinorQty}",
                        "${res.countedMinorQty}",
                        varStr,
                        statusLabel
                    )
                }

                y = drawRtlTable(
                    canvas = canvas,
                    startY = y + 12f,
                    sectionTitle = "كشف مقارنة الأرصدة الدفترية بالعد الفعلي (بالوحدة الصغرى)",
                    headers = headers,
                    weights = weights,
                    rows = tableRows,
                    emptyText = "لا توجد أصناف في محضر الجرد"
                )

                if (pageIndex == totalPages - 1 && y < PAGE_HEIGHT - 140f) {
                    drawSignaturesAndStampBlock(
                        canvas = canvas,
                        startY = maxOf(y + 22f, PAGE_HEIGHT - 150f),
                        rightLabel = "رئيس لجنة الجرد",
                        rightSub = report.performedBy,
                        centerLabel = "أمين المخزن",
                        centerSub = warehouse.keeperName.ifBlank { "........................" },
                        leftLabel = "اعتماد الإدارة المالية",
                        leftSub = "........................"
                    )
                }

                drawPageFooter(canvas, pageIndex + 1, totalPages)
                doc.finishPage(page)
            }

            PublicDownloadsExporter.savePdfToPublicDownloads(
                context = context,
                fileName = "Warehouse_BlindAudit_${fileStamp()}.pdf"
            ) { outputStream ->
                doc.writeTo(outputStream)
            }
        } finally {
            doc.close()
        }
    }

    // ========================================================================
    // 5. كشف الميزانية والمصروفات والرواتب للمخزن (Financial Report PDF)
    // ========================================================================

    suspend fun generateFinancialReportPdf(
        context: Context,
        warehouse: Warehouse,
        summary: WarehouseFinancialSummary,
        budgets: List<WarehouseBudgetEntry>,
        expenses: List<WarehouseExpense>,
        payrolls: List<WarehousePayrollRecord>
    ): SavedExportResult = withContext(Dispatchers.IO) {
        val doc = PdfDocument()
        try {
            // الصفحة 1: ملخص الأداء المالي + الموازنة + المصروفات
            val p1 = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 1).create())
            val c1 = p1.canvas
            var y1 = drawInstitutionalHeader(
                canvas = c1,
                title = "التقرير المالي الشامل — الميزانية والمصروفات والرواتب",
                subtitle = "المخزن: ${warehouse.name}  •  تاريخ الإصدار: ${nowDisplay()}",
                badgeText = "مالية"
            )

            y1 = drawKpiStrip(
                canvas = c1,
                startY = y1 + 12f,
                items = listOf(
                    Triple("الموازنة المعتمدة", formatMoney(summary.approvedBudget), COLOR_HEADER_DARK),
                    Triple("إيرادات 3PL", formatMoney(summary.thirdPartyStorageRevenue), COLOR_HEADER_LIGHT),
                    Triple("المصروفات", formatMoney(summary.totalExpenses), COLOR_ACCENT_AMBER),
                    Triple("الرواتب المصروفة", formatMoney(summary.totalPayroll), COLOR_ACCENT_RED),
                    Triple("صافي الرصيد", formatMoney(summary.netWarehouseBalance), if (summary.netWarehouseBalance >= 0.0) COLOR_HEADER_LIGHT else COLOR_ACCENT_RED)
                )
            )

            y1 = drawKeyValueCard(
                canvas = c1,
                startY = y1 + 10f,
                sectionTitle = "مؤشرات الكفاءة التشغيلية",
                rows = listOf(
                    "إجمالي الوحدات المناولة" to "${summary.totalHandledUnits} وحدة",
                    "متوسط تكلفة مناولة الوحدة الواحدة" to formatMoney(summary.avgHandlingCostPerUnit),
                    "رواتب قيد الاعتماد / مستحقات 3PL غير محصلة" to "رواتب معلقة: ${formatMoney(summary.pendingPayroll)}  |  مستحقات عملاء: ${formatMoney(summary.thirdPartyReceivables)}"
                )
            )

            y1 = drawRtlTable(
                canvas = c1,
                startY = y1 + 10f,
                sectionTitle = "تخصيصات الموازنة (${budgets.size})",
                headers = listOf("التاريخ", "مصدر التمويل", "المبلغ", "ملاحظات"),
                weights = listOf(0.18f, 0.32f, 0.18f, 0.32f),
                rows = budgets.take(6).map { listOf(it.date, it.fundingSource.ifBlank { "-" }, formatMoney(it.allocatedAmount), it.notes.ifBlank { "-" }) },
                emptyText = "لا توجد تخصيصات موازنة مسجلة"
            )

            y1 = drawRtlTable(
                canvas = c1,
                startY = y1 + 10f,
                sectionTitle = "المصروفات التشغيلية (${expenses.size})",
                headers = listOf("التاريخ", "البند", "رقم الفاتورة", "المبلغ", "ملاحظات"),
                weights = listOf(0.16f, 0.22f, 0.16f, 0.16f, 0.30f),
                rows = expenses.take(8).map { listOf(it.date, it.category, it.invoiceNo.ifBlank { "-" }, formatMoney(it.amount), it.notes.ifBlank { "-" }) },
                emptyText = "لا توجد مصروفات تشغيلية مسجلة"
            )

            drawPageFooter(c1, 1, 2)
            doc.finishPage(p1)

            // الصفحة 2: مسير رواتب العاملين والتوقيعات
            val p2 = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, 2).create())
            val c2 = p2.canvas
            var y2 = drawInstitutionalHeader(
                canvas = c2,
                title = "مسير رواتب وأجور طاقم المخزن",
                subtitle = "المخزن: ${warehouse.name}  •  عدد السجلات: ${payrolls.size}",
                badgeText = "رواتب"
            )

            y2 = drawRtlTable(
                canvas = c2,
                startY = y2 + 12f,
                sectionTitle = "تفاصيل كشف الرواتب والأجور",
                headers = listOf("الفترة", "العامل", "الوظيفة", "النظام", "المبلغ", "الحالة"),
                weights = listOf(0.14f, 0.24f, 0.18f, 0.14f, 0.15f, 0.15f),
                rows = payrolls.take(22).map { p ->
                    listOf(
                        p.periodLabel,
                        p.workerName,
                        p.role,
                        if (p.payType.name == "DAILY") "يومي (${p.daysWorked} ي)" else "شهري",
                        formatMoney(p.amount),
                        if (p.isPaid) "مصروف" else "معلّق"
                    )
                },
                emptyText = "لا توجد سجلات رواتب مصدرة لهذا المخزن"
            )

            drawSignaturesAndStampBlock(
                canvas = c2,
                startY = maxOf(y2 + 24f, PAGE_HEIGHT - 155f),
                rightLabel = "أمين المخزن",
                rightSub = warehouse.keeperName.ifBlank { "........................" },
                centerLabel = "المحاسب اللوجستي",
                centerSub = "........................",
                leftLabel = "اعتماد المدير المالي",
                leftSub = "........................"
            )

            drawPageFooter(c2, 2, 2)
            doc.finishPage(p2)

            PublicDownloadsExporter.savePdfToPublicDownloads(
                context = context,
                fileName = "Warehouse_Finance_${fileStamp()}.pdf"
            ) { outputStream ->
                doc.writeTo(outputStream)
            }
        } finally {
            doc.close()
        }
    }

    // ========================================================================
    // دوال الرسم الاحترافية بالهوية الزجاجية الخضراء (RTL Canvas Helpers)
    // ========================================================================

    private fun drawInstitutionalHeader(
        canvas: Canvas,
        title: String,
        subtitle: String,
        badgeText: String
    ): Float {
        val headerRect = RectF(MARGIN_X, 24f, PAGE_WIDTH - MARGIN_X, 108f)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                headerRect.left, headerRect.top, headerRect.right, headerRect.bottom,
                COLOR_HEADER_DARK, COLOR_HEADER_LIGHT, Shader.TileMode.CLAMP
            )
        }
        canvas.drawRoundRect(headerRect, 14f, 14f, bgPaint)

        // طبقة زجاجية شفافة علوية
        val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(38, 255, 255, 255)
        }
        canvas.drawRoundRect(
            RectF(headerRect.left + 8f, headerRect.top + 6f, headerRect.right - 8f, headerRect.top + 32f),
            10f, 10f, sheenPaint
        )

        // شارة النوع على اليسار
        val badgeRect = RectF(headerRect.left + 14f, headerRect.top + 22f, headerRect.left + 94f, headerRect.bottom - 22f)
        val badgeBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(55, 255, 255, 255) }
        val badgeStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
            color = Color.argb(140, 255, 255, 255)
        }
        canvas.drawRoundRect(badgeRect, 10f, 10f, badgeBg)
        canvas.drawRoundRect(badgeRect, 10f, 10f, badgeStroke)

        val badgeTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(badgeText, badgeRect.centerX(), badgeRect.centerY() + 4f, badgeTextPaint)

        val textAreaWidth = (headerRect.width() - 122f).toInt().coerceAtLeast(180)
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 15.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(235, 236, 253, 245)
            textSize = 10.5f
        }

        drawRtlParagraph(canvas, "منظومة إدارة المساعدات الإنسانية — قطاع المخازن واللوجستيات", subPaint, headerRect.left + 108f, headerRect.top + 12f, textAreaWidth)
        drawRtlParagraph(canvas, title, titlePaint, headerRect.left + 108f, headerRect.top + 32f, textAreaWidth)
        drawRtlParagraph(canvas, subtitle, subPaint, headerRect.left + 108f, headerRect.top + 66f, textAreaWidth)

        return headerRect.bottom
    }

    private fun drawKeyValueCard(
        canvas: Canvas,
        startY: Float,
        sectionTitle: String,
        rows: List<Pair<String, String>>
    ): Float {
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_HEADER_DARK
            textSize = 11.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val labelPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_SECONDARY
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val valuePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_PRIMARY
            textSize = 10.2f
        }

        val labelColWidth = 175
        val valueColWidth = (CONTENT_WIDTH - 24f - labelColWidth - 10f).toInt().coerceAtLeast(150)

        var totalHeight = 32f
        val rowHeights = rows.map { (k, v) ->
            val h1 = measureRtlHeight(k, labelPaint, labelColWidth)
            val h2 = measureRtlHeight(v, valuePaint, valueColWidth)
            val h = maxOf(h1, h2, 16f) + 8f
            totalHeight += h
            h
        }

        val cardRect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + totalHeight + 6f)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1f
            color = COLOR_BORDER_MINT
        }
        canvas.drawRoundRect(cardRect, 10f, 10f, bgPaint)

        // شريط عنوان البطاقة
        val headerBar = RectF(cardRect.left, cardRect.top, cardRect.right, cardRect.top + 26f)
        val headerBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_SURFACE_MINT }
        canvas.drawRoundRect(headerBar, 10f, 10f, headerBg)
        canvas.drawRoundRect(cardRect, 10f, 10f, borderPaint)

        drawRtlParagraph(canvas, sectionTitle, titlePaint, cardRect.left + 12f, cardRect.top + 6f, (CONTENT_WIDTH - 24f).toInt())

        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E2E8F0")
            strokeWidth = 0.7f
        }

        var cursorY = cardRect.top + 30f
        rows.forEachIndexed { idx, (k, v) ->
            val rowH = rowHeights[idx]
            // RTL: العمود الأيمن للعنوان والعمود الأيسر للقيمة
            val labelX = cardRect.right - 12f - labelColWidth
            val valueX = cardRect.left + 12f
            drawRtlParagraph(canvas, "$k:", labelPaint, labelX, cursorY + 2f, labelColWidth)
            drawRtlParagraph(canvas, v, valuePaint, valueX, cursorY + 2f, valueColWidth)
            cursorY += rowH
            if (idx < rows.lastIndex) {
                canvas.drawLine(cardRect.left + 10f, cursorY - 2f, cardRect.right - 10f, cursorY - 2f, dividerPaint)
            }
        }

        return cardRect.bottom
    }

    private fun drawKpiStrip(
        canvas: Canvas,
        startY: Float,
        items: List<Triple<String, String, Int>>
    ): Float {
        if (items.isEmpty()) return startY
        val gap = 6f
        val boxW = (CONTENT_WIDTH - gap * (items.size - 1)) / items.size
        val boxH = 52f

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_SURFACE_MINT }
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1f
            color = COLOR_BORDER_MINT
        }
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_SECONDARY
            textSize = 8.8f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        // عرض من اليمين إلى اليسار (RTL)
        items.forEachIndexed { idx, (label, value, colorInt) ->
            val rightX = PAGE_WIDTH - MARGIN_X - idx * (boxW + gap)
            val rect = RectF(rightX - boxW, startY, rightX, startY + boxH)
            canvas.drawRoundRect(rect, 9f, 9f, bgPaint)
            canvas.drawRoundRect(rect, 9f, 9f, strokePaint)

            val valPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = colorInt
                textSize = 12f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(label, rect.centerX(), rect.top + 18f, titlePaint)
            canvas.drawText(value, rect.centerX(), rect.top + 39f, valPaint)
        }

        return startY + boxH
    }

    private fun drawRtlTable(
        canvas: Canvas,
        startY: Float,
        sectionTitle: String,
        headers: List<String>,
        weights: List<Float>,
        rows: List<List<String>>,
        emptyText: String
    ): Float {
        val secPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_HEADER_DARK
            textSize = 11.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        drawRtlParagraph(canvas, sectionTitle, secPaint, MARGIN_X, startY, CONTENT_WIDTH.toInt())

        var y = startY + 20f
        val headerH = 24f
        val headerRect = RectF(MARGIN_X, y, PAGE_WIDTH - MARGIN_X, y + headerH)
        canvas.drawRoundRect(headerRect, 6f, 6f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_HEADER_DARK })

        val headTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 9.2f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val cellTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_PRIMARY
            textSize = 9f
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 0.7f
            color = COLOR_BORDER_SLATE
        }

        // رسم الترويسة من اليمين إلى اليسار
        var colRight = PAGE_WIDTH - MARGIN_X
        headers.forEachIndexed { i, head ->
            val colW = CONTENT_WIDTH * weights[i]
            val colLeft = colRight - colW
            drawRtlParagraph(canvas, head, headTextPaint, colLeft + 4f, y + 6f, (colW - 8f).toInt().coerceAtLeast(24))
            colRight = colLeft
        }
        y += headerH

        if (rows.isEmpty()) {
            val emptyRect = RectF(MARGIN_X, y, PAGE_WIDTH - MARGIN_X, y + 26f)
            canvas.drawRect(emptyRect, Paint().apply { color = COLOR_SURFACE_ALT })
            canvas.drawRect(emptyRect, borderPaint)
            drawRtlParagraph(canvas, emptyText, cellTextPaint, MARGIN_X + 8f, y + 7f, (CONTENT_WIDTH - 16f).toInt())
            return emptyRect.bottom
        }

        rows.forEachIndexed { rowIdx, cells ->
            var rowH = 20f
            cells.forEachIndexed { colIdx, text ->
                val colW = (CONTENT_WIDTH * weights[colIdx] - 8f).toInt().coerceAtLeast(24)
                val h = measureRtlHeight(text, cellTextPaint, colW) + 8f
                if (h > rowH) rowH = h
            }

            val rowRect = RectF(MARGIN_X, y, PAGE_WIDTH - MARGIN_X, y + rowH)
            if (rowIdx % 2 == 1) {
                canvas.drawRect(rowRect, Paint().apply { color = COLOR_SURFACE_ALT })
            }
            canvas.drawRect(rowRect, borderPaint)

            var cRight = PAGE_WIDTH - MARGIN_X
            cells.forEachIndexed { colIdx, text ->
                val colW = CONTENT_WIDTH * weights[colIdx]
                val cLeft = cRight - colW
                drawRtlParagraph(canvas, text, cellTextPaint, cLeft + 4f, y + 4f, (colW - 8f).toInt().coerceAtLeast(24))
                if (colIdx < cells.lastIndex) {
                    canvas.drawLine(cLeft, y, cLeft, y + rowH, borderPaint)
                }
                cRight = cLeft
            }
            y += rowH
        }

        return y
    }

    private fun computeShortSha256(input: String): String {
        return runCatching {
            val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
            bytes.joinToString("") { "%02X".format(it) }.take(12)
        }.getOrElse { "VERIFIED" }
    }

    private fun generateQrBitmap(content: String, sizePx: Int = 200): Bitmap? {
        return runCatching {
            WarehouseQrCodeEncoder.createQrBitmap(content, sizePx, COLOR_HEADER_DARK)
        }.getOrNull()
    }

    private fun drawGatePassQrCard(
        canvas: Canvas,
        startY: Float,
        qrPayload: String,
        gatePassToken: String,
        routeSummary: String,
        driverSummary: String,
        securityHash: String
    ): Float {
        val cardH = 84f
        val rect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + cardH)
        canvas.drawRoundRect(rect, 10f, 10f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_SURFACE_MINT })
        canvas.drawRoundRect(
            rect, 10f, 10f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 1.2f
                color = COLOR_HEADER_LIGHT
            }
        )

        val qrBoxSize = 68f
        val qrRect = RectF(rect.left + 10f, rect.top + 8f, rect.left + 10f + qrBoxSize, rect.top + 8f + qrBoxSize)
        canvas.drawRoundRect(qrRect, 6f, 6f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
        canvas.drawRoundRect(
            qrRect, 6f, 6f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
                color = COLOR_BORDER_MINT
            }
        )

        val qrBitmap = generateQrBitmap(qrPayload, 200)
        if (qrBitmap != null) {
            val dst = RectF(qrRect.left + 3f, qrRect.top + 3f, qrRect.right - 3f, qrRect.bottom - 3f)
            canvas.drawBitmap(qrBitmap, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
            qrBitmap.recycle()
        }

        val textAreaLeft = qrRect.right + 12f
        val textAreaW = (rect.right - 12f - textAreaLeft).toInt().coerceAtLeast(180)
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_HEADER_DARK
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val infoPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_PRIMARY
            textSize = 9.2f
        }
        val hashPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_SECONDARY
            textSize = 8.4f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }

        drawRtlParagraph(canvas, "تصريح خروج أمني مشفّر (Gate Pass QR)", titlePaint, textAreaLeft, rect.top + 8f, textAreaW)
        drawRtlParagraph(canvas, "رمز التصريح: $gatePassToken  •  المسار: $routeSummary", infoPaint, textAreaLeft, rect.top + 26f, textAreaW)
        drawRtlParagraph(canvas, "السائق والمركبة: $driverSummary", infoPaint, textAreaLeft, rect.top + 44f, textAreaW)
        drawRtlParagraph(canvas, "التوقيع الرقمي SHA-256: $securityHash", hashPaint, textAreaLeft, rect.top + 62f, textAreaW)

        return rect.bottom
    }

    private fun drawSignaturesAndStampBlock(
        canvas: Canvas,
        startY: Float,
        rightLabel: String,
        rightSub: String,
        centerLabel: String,
        centerSub: String,
        leftLabel: String,
        leftSub: String,
        showOfficialKeeperStamp: Boolean = false
    ) {
        val boxRect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + 95f)
        canvas.drawRoundRect(boxRect, 10f, 10f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_SURFACE_MINT })
        canvas.drawRoundRect(
            boxRect, 10f, 10f,
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 1f
                color = COLOR_BORDER_MINT
            }
        )

        val colW = CONTENT_WIDTH / 3f
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_HEADER_DARK
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val subPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_SECONDARY
            textSize = 9.5f
            textAlign = Paint.Align.CENTER
        }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_HEADER_LIGHT
            strokeWidth = 1f
        }

        val cols = listOf(
            leftLabel to leftSub,
            centerLabel to centerSub,
            rightLabel to rightSub
        )
        cols.forEachIndexed { idx, (lbl, sub) ->
            val cx = MARGIN_X + idx * colW + colW / 2f
            canvas.drawText(lbl, cx, startY + 22f, titlePaint)
            canvas.drawText(sub.take(26), cx, startY + 42f, subPaint)
            canvas.drawLine(cx - 56f, startY + 76f, cx + 56f, startY + 76f, linePaint)
        }

        if (showOfficialKeeperStamp) {
            val stampCx = PAGE_WIDTH - MARGIN_X - 42f
            val stampCy = startY + 62f
            val outerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 1.6f
                color = Color.argb(180, 5, 150, 105)
            }
            val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
                color = Color.argb(150, 6, 78, 59)
            }
            canvas.drawCircle(stampCx, stampCy, 24f, outerPaint)
            canvas.drawCircle(stampCx, stampCy, 19.5f, innerPaint)
            val stampTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.argb(200, 6, 78, 59)
                textSize = 7f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("ختم المخزن", stampCx, stampCy - 2f, stampTextPaint)
            canvas.drawText("معتمد رسمياً", stampCx, stampCy + 8f, stampTextPaint)
        }
    }

    private fun drawPageFooter(canvas: Canvas, pageNum: Int, totalPages: Int) {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_SECONDARY
            textSize = 8.5f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(
            "وثيقة إلكترونية معتمدة — نظام إدارة المخازن والمحاسبة اللوجستية (ERP & 3PL)  •  صفحة $pageNum من $totalPages",
            PAGE_WIDTH / 2f,
            PAGE_HEIGHT - 18f,
            paint
        )
    }

    private fun drawRtlParagraph(
        canvas: Canvas,
        text: String,
        paint: TextPaint,
        left: Float,
        top: Float,
        widthPx: Int
    ): Float {
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, paint, widthPx.coerceAtLeast(16))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false)
            .build()
        canvas.save()
        canvas.translate(left, top)
        layout.draw(canvas)
        canvas.restore()
        return layout.height.toFloat()
    }

    // ========================================================================
    // 5. تقارير المخازن التفصيلية الديناميكية متعددة الصفحات (RTL Dynamic Reports PDF)
    // ========================================================================

    suspend fun generateDynamicWarehouseReportPdf(
        context: Context,
        reportTitle: String,
        warehouseScopeLabel: String,
        dateRangeLabel: String,
        issuerName: String,
        kpiSummary: List<Triple<String, String, Int>>,
        sections: List<DynamicReportPdfSection>,
        fileNamePrefix: String = "Warehouse_Dynamic_Report"
    ): SavedExportResult = withContext(Dispatchers.IO) {
        val doc = PdfDocument()
        try {
            var pageNum = 1
            var currentPage = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNum).create())
            var canvas = currentPage.canvas

            val maxContentBottom = PAGE_HEIGHT - 44f
            val secPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = COLOR_HEADER_DARK
                textSize = 11.2f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val headTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 8.8f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val cellTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = COLOR_TEXT_PRIMARY
                textSize = 8.6f
            }
            val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 0.7f
                color = COLOR_BORDER_SLATE
            }
            val altBgPaint = Paint().apply { color = COLOR_SURFACE_ALT }
            val headerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = COLOR_HEADER_DARK }

            fun drawDynamicFooter(c: Canvas, pNum: Int) {
                val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = COLOR_TEXT_SECONDARY
                    textSize = 8.2f
                    textAlign = Paint.Align.CENTER
                }
                c.drawText(
                    "تقرير مخازن إلكتروني معتمد  •  $warehouseScopeLabel  •  مُصدر التقرير: $issuerName  •  صفحة $pNum",
                    PAGE_WIDTH / 2f,
                    PAGE_HEIGHT - 16f,
                    paint
                )
            }

            fun startContinuationPage(continuedSectionTitle: String? = null): Float {
                drawDynamicFooter(canvas, pageNum)
                doc.finishPage(currentPage)
                pageNum += 1
                currentPage = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNum).create())
                canvas = currentPage.canvas

                val barRect = RectF(MARGIN_X, 20f, PAGE_WIDTH - MARGIN_X, 52f)
                val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    shader = LinearGradient(
                        barRect.left, barRect.top, barRect.right, barRect.bottom,
                        COLOR_HEADER_DARK, COLOR_HEADER_LIGHT, Shader.TileMode.CLAMP
                    )
                }
                canvas.drawRoundRect(barRect, 8f, 8f, barPaint)
                val contTitlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    textSize = 10.5f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                }
                val bannerText = if (continuedSectionTitle.isNullOrBlank()) {
                    "$reportTitle — $warehouseScopeLabel (صفحة $pageNum)"
                } else {
                    "$reportTitle — تابع: $continuedSectionTitle (صفحة $pageNum)"
                }
                drawRtlParagraph(canvas, bannerText, contTitlePaint, barRect.left + 10f, barRect.top + 8f, (CONTENT_WIDTH - 20f).toInt())
                return barRect.bottom + 12f
            }

            fun drawTableHeaderRow(startY: Float, headers: List<String>, weights: List<Float>): Float {
                val headerH = 23f
                val headerRect = RectF(MARGIN_X, startY, PAGE_WIDTH - MARGIN_X, startY + headerH)
                canvas.drawRoundRect(headerRect, 5f, 5f, headerBgPaint)
                var colRight = PAGE_WIDTH - MARGIN_X
                headers.forEachIndexed { idx, head ->
                    val w = weights.getOrElse(idx) { 1f / headers.size.coerceAtLeast(1) }
                    val colW = CONTENT_WIDTH * w
                    val colLeft = colRight - colW
                    drawRtlParagraph(canvas, head, headTextPaint, colLeft + 4f, startY + 5f, (colW - 8f).toInt().coerceAtLeast(22))
                    colRight = colLeft
                }
                return startY + headerH
            }

            // الترويسة المؤسسية في الصفحة الأولى
            var cursorY = drawInstitutionalHeader(
                canvas = canvas,
                title = reportTitle,
                subtitle = "النطاق: $warehouseScopeLabel  •  الفترة: $dateRangeLabel",
                badgeText = "تقرير معتمد"
            )

            cursorY = drawKeyValueCard(
                canvas = canvas,
                startY = cursorY + 8f,
                sectionTitle = "بيانات تعريف التقرير والاعتماد",
                rows = listOf(
                    "النطاق المخزني" to warehouseScopeLabel,
                    "الفترة الزمنية للتقرير" to dateRangeLabel,
                    "مُصدر التقرير" to issuerName.ifBlank { "مدير النظام" },
                    "تاريخ ووقت الإصدار" to nowDisplay()
                )
            )

            // شرائط مؤشرات الأداء الرئيسية (حتى 4 بطاقات في الصف)
            if (kpiSummary.isNotEmpty()) {
                kpiSummary.chunked(4).forEach { chunk ->
                    if (cursorY + 66f > maxContentBottom) {
                        cursorY = startContinuationPage()
                    }
                    cursorY = drawKpiStrip(canvas, cursorY + 8f, chunk)
                }
            }

            // رسم الأقسام والجداول بترقيم صفحات تلقائي
            sections.forEach { section ->
                if (cursorY + 95f > maxContentBottom) {
                    cursorY = startContinuationPage()
                } else {
                    cursorY += 12f
                }

                val titleH = drawRtlParagraph(canvas, section.title, secPaint, MARGIN_X, cursorY, CONTENT_WIDTH.toInt())
                cursorY += maxOf(titleH, 16f) + 4f
                cursorY = drawTableHeaderRow(cursorY, section.headers, section.weights)

                if (section.rows.isEmpty()) {
                    val emptyRect = RectF(MARGIN_X, cursorY, PAGE_WIDTH - MARGIN_X, cursorY + 24f)
                    canvas.drawRect(emptyRect, altBgPaint)
                    canvas.drawRect(emptyRect, borderPaint)
                    drawRtlParagraph(canvas, section.emptyText, cellTextPaint, MARGIN_X + 8f, cursorY + 6f, (CONTENT_WIDTH - 16f).toInt())
                    cursorY = emptyRect.bottom + 4f
                } else {
                    section.rows.forEachIndexed { rowIdx, cells ->
                        var rowH = 19f
                        cells.forEachIndexed { colIdx, text ->
                            val w = section.weights.getOrElse(colIdx) { 1f / section.headers.size.coerceAtLeast(1) }
                            val colW = (CONTENT_WIDTH * w - 8f).toInt().coerceAtLeast(22)
                            val h = measureRtlHeight(text, cellTextPaint, colW) + 7f
                            if (h > rowH) rowH = h
                        }

                        if (cursorY + rowH > maxContentBottom) {
                            cursorY = startContinuationPage(section.title)
                            cursorY = drawTableHeaderRow(cursorY, section.headers, section.weights)
                        }

                        val rowRect = RectF(MARGIN_X, cursorY, PAGE_WIDTH - MARGIN_X, cursorY + rowH)
                        if (rowIdx % 2 == 1) {
                            canvas.drawRect(rowRect, altBgPaint)
                        }
                        canvas.drawRect(rowRect, borderPaint)

                        var cRight = PAGE_WIDTH - MARGIN_X
                        cells.forEachIndexed { colIdx, text ->
                            val w = section.weights.getOrElse(colIdx) { 1f / section.headers.size.coerceAtLeast(1) }
                            val colW = CONTENT_WIDTH * w
                            val cLeft = cRight - colW
                            drawRtlParagraph(canvas, text, cellTextPaint, cLeft + 4f, cursorY + 3.5f, (colW - 8f).toInt().coerceAtLeast(22))
                            if (colIdx < cells.lastIndex) {
                                canvas.drawLine(cLeft, cursorY, cLeft, cursorY + rowH, borderPaint)
                            }
                            cRight = cLeft
                        }
                        cursorY += rowH
                    }
                }
            }

            // بلوك الاعتماد والختم الرسمي في نهاية التقرير
            if (cursorY + 110f > maxContentBottom) {
                cursorY = startContinuationPage()
            }
            drawSignaturesAndStampBlock(
                canvas = canvas,
                startY = maxOf(cursorY + 14f, PAGE_HEIGHT - 134f).coerceAtMost(PAGE_HEIGHT - 126f),
                rightLabel = "مُعدّ ومُصدر التقرير",
                rightSub = issuerName.ifBlank { "مستخدم النظام" },
                centerLabel = "مراجعة المحاسبة والرقابة",
                centerSub = "........................",
                leftLabel = "اعتماد إدارة المخازن",
                leftSub = warehouseScopeLabel.take(26),
                showOfficialKeeperStamp = true
            )

            drawDynamicFooter(canvas, pageNum)
            doc.finishPage(currentPage)

            val safePrefix = fileNamePrefix.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "Warehouse_Report" }
            PublicDownloadsExporter.savePdfToPublicDownloads(
                context = context,
                fileName = "${safePrefix}_${fileStamp()}.pdf"
            ) { outputStream ->
                doc.writeTo(outputStream)
            }
        } finally {
            doc.close()
        }
    }

    private fun measureRtlHeight(text: String, paint: TextPaint, widthPx: Int): Float {
        val layout = StaticLayout.Builder
            .obtain(text, 0, text.length, paint, widthPx.coerceAtLeast(16))
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setIncludePad(false)
            .build()
        return layout.height.toFloat()
    }
}

/**
 * مولّد رمز QR قياسي (ISO/IEC 18004 - Byte Mode - ECC Level L - Versions 1..10)
 * مكتوب بلغة Kotlin الصافية بدون أي مكتبات خارجية لينتج رمز QR قابلاً للمسح الفوري عبر الكاميرا و ML Kit.
 */
private object WarehouseQrCodeEncoder {

    private data class VersionSpec(
        val version: Int,
        val ecPerBlock: Int,
        val g1Blocks: Int,
        val g1Data: Int,
        val g2Blocks: Int,
        val g2Data: Int,
        val alignmentCenters: IntArray
    ) {
        val totalDataCodewords: Int get() = g1Blocks * g1Data + g2Blocks * g2Data
        val size: Int get() = 17 + version * 4
    }

    // مواصفات ISO/IEC 18004 (المستوى L) للإصدارات 1 إلى 10 (تستوعب حتى 271 بايت UTF-8)
    private val SPECS_L = arrayOf(
        VersionSpec(1, 7, 1, 19, 0, 0, intArrayOf()),
        VersionSpec(2, 10, 1, 34, 0, 0, intArrayOf(6, 18)),
        VersionSpec(3, 15, 1, 55, 0, 0, intArrayOf(6, 22)),
        VersionSpec(4, 20, 1, 80, 0, 0, intArrayOf(6, 26)),
        VersionSpec(5, 26, 1, 108, 0, 0, intArrayOf(6, 30)),
        VersionSpec(6, 18, 2, 68, 0, 0, intArrayOf(6, 34)),
        VersionSpec(7, 20, 2, 78, 0, 0, intArrayOf(6, 22, 38)),
        VersionSpec(8, 24, 2, 97, 0, 0, intArrayOf(6, 24, 42)),
        VersionSpec(9, 30, 2, 116, 0, 0, intArrayOf(6, 26, 46)),
        VersionSpec(10, 18, 2, 68, 2, 69, intArrayOf(6, 28, 50))
    )

    // جداول الحقل المنتهي GF(256) بمتعددة الحدود 0x11D
    private val GF_EXP = IntArray(512)
    private val GF_LOG = IntArray(256)

    init {
        var v = 1
        for (i in 0 until 255) {
            GF_EXP[i] = v
            GF_LOG[v] = i
            v = v shl 1
            if ((v and 0x100) != 0) {
                v = v xor 0x11D
            }
        }
        for (i in 255 until 512) {
            GF_EXP[i] = GF_EXP[i - 255]
        }
    }

    fun createQrBitmap(content: String, sizePx: Int, darkColor: Int = Color.BLACK): Bitmap {
        val matrix = encodeByteModeL(content.toByteArray(Charsets.UTF_8))
        val moduleCount = matrix.size
        val quietZone = 2
        val totalModules = moduleCount + quietZone * 2

        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(sizePx * sizePx)
        pixels.fill(Color.WHITE)

        val scale = sizePx.toFloat() / totalModules.toFloat()
        for (r in 0 until moduleCount) {
            val yStart = ((r + quietZone) * scale).toInt().coerceIn(0, sizePx)
            val yEnd = (((r + quietZone + 1) * scale).toInt()).coerceIn(yStart, sizePx)
            val rowData = matrix[r]
            for (c in 0 until moduleCount) {
                if (rowData[c]) {
                    val xStart = ((c + quietZone) * scale).toInt().coerceIn(0, sizePx)
                    val xEnd = (((c + quietZone + 1) * scale).toInt()).coerceIn(xStart, sizePx)
                    for (py in yStart until yEnd) {
                        val rowOffset = py * sizePx
                        for (px in xStart until xEnd) {
                            pixels[rowOffset + px] = darkColor
                        }
                    }
                }
            }
        }
        bitmap.setPixels(pixels, 0, sizePx, 0, 0, sizePx, sizePx)
        return bitmap
    }

    private fun encodeByteModeL(rawBytes: ByteArray): Array<BooleanArray> {
        val spec = SPECS_L.firstOrNull { s ->
            val countBits = if (s.version <= 9) 8 else 16
            val neededBits = 4 + countBits + rawBytes.size * 8
            neededBits <= s.totalDataCodewords * 8
        } ?: SPECS_L.last()

        val countBits = if (spec.version <= 9) 8 else 16
        val maxBytesAllowed = ((spec.totalDataCodewords * 8 - 4 - countBits) / 8).coerceAtLeast(1)
        val dataBytes = if (rawBytes.size > maxBytesAllowed) {
            rawBytes.copyOf(maxBytesAllowed)
        } else {
            rawBytes
        }

        // 1) بناء دفق البتات (Mode 0100 + Char Count + Data + Terminator + Pad)
        val totalDataBits = spec.totalDataCodewords * 8
        val bits = ArrayList<Int>(totalDataBits)

        fun appendBits(value: Int, bitCount: Int) {
            for (i in (bitCount - 1) downTo 0) {
                bits.add((value ushr i) and 1)
            }
        }

        appendBits(0b0100, 4) // Byte mode
        appendBits(dataBytes.size, countBits)
        for (b in dataBytes) {
            appendBits(b.toInt() and 0xFF, 8)
        }
        val terminatorLen = minOf(4, totalDataBits - bits.size)
        for (i in 0 until terminatorLen) bits.add(0)
        while (bits.size % 8 != 0) bits.add(0)

        val dataCodewords = IntArray(spec.totalDataCodewords)
        var cwIdx = 0
        var bitPtr = 0
        while (bitPtr < bits.size && cwIdx < dataCodewords.size) {
            var byteVal = 0
            for (b in 0 until 8) {
                byteVal = (byteVal shl 1) or bits[bitPtr++]
            }
            dataCodewords[cwIdx++] = byteVal
        }
        var padToggle = true
        while (cwIdx < dataCodewords.size) {
            dataCodewords[cwIdx++] = if (padToggle) 0xEC else 0x11
            padToggle = !padToggle
        }

        // 2) تقسيم الكتل وحساب رموز تصحيح الخطأ Reed-Solomon ثم دمجها
        val dataBlocks = ArrayList<IntArray>()
        val ecBlocks = ArrayList<IntArray>()
        val rsGenerator = buildRsGenerator(spec.ecPerBlock)

        var offset = 0
        for (b in 0 until spec.g1Blocks) {
            val block = dataCodewords.copyOfRange(offset, offset + spec.g1Data)
            offset += spec.g1Data
            dataBlocks.add(block)
            ecBlocks.add(computeRsEcc(block, rsGenerator, spec.ecPerBlock))
        }
        for (b in 0 until spec.g2Blocks) {
            val block = dataCodewords.copyOfRange(offset, offset + spec.g2Data)
            offset += spec.g2Data
            dataBlocks.add(block)
            ecBlocks.add(computeRsEcc(block, rsGenerator, spec.ecPerBlock))
        }

        val finalCodewords = ArrayList<Int>(spec.totalDataCodewords + (spec.g1Blocks + spec.g2Blocks) * spec.ecPerBlock)
        val maxDataBlockLen = maxOf(spec.g1Data, spec.g2Data)
        for (i in 0 until maxDataBlockLen) {
            for (blk in dataBlocks) {
                if (i < blk.size) finalCodewords.add(blk[i])
            }
        }
        for (i in 0 until spec.ecPerBlock) {
            for (ec in ecBlocks) {
                finalCodewords.add(ec[i])
            }
        }

        // 3) إنشاء المصفوفة ورسم الأنماط الوظيفية
        val size = spec.size
        val baseModules = Array(size) { BooleanArray(size) }
        val isFunction = Array(size) { BooleanArray(size) }

        drawFunctionPatterns(spec, baseModules, isFunction)
        placeCodewords(baseModules, isFunction, finalCodewords)

        // 4) اختيار أفضل قناع (Mask 0..7) بأقل عقوبة بصرية لضمان أعلى سرعة قراءة بالكاميرا
        var bestMask = 0
        var bestPenalty = Int.MAX_VALUE
        var bestMatrix: Array<BooleanArray>? = null

        for (mask in 0..7) {
            val candidate = Array(size) { r -> baseModules[r].copyOf() }
            applyMask(candidate, isFunction, mask)
            drawFormatBits(candidate, mask)
            val penalty = computePenaltyScore(candidate)
            if (penalty < bestPenalty) {
                bestPenalty = penalty
                bestMask = mask
                bestMatrix = candidate
            }
        }

        return bestMatrix ?: run {
            applyMask(baseModules, isFunction, bestMask)
            drawFormatBits(baseModules, bestMask)
            baseModules
        }
    }

    private fun gfMul(a: Int, b: Int): Int {
        if (a == 0 || b == 0) return 0
        return GF_EXP[GF_LOG[a] + GF_LOG[b]]
    }

    private fun buildRsGenerator(degree: Int): IntArray {
        var poly = intArrayOf(1)
        for (i in 0 until degree) {
            val next = IntArray(poly.size + 1)
            val factor = GF_EXP[i]
            for (j in poly.indices) {
                next[j] = next[j] xor poly[j]
                next[j + 1] = next[j + 1] xor gfMul(poly[j], factor)
            }
            poly = next
        }
        return poly
    }

    private fun computeRsEcc(data: IntArray, generator: IntArray, ecCount: Int): IntArray {
        val rem = IntArray(ecCount)
        for (byteVal in data) {
            val factor = byteVal xor rem[0]
            for (i in 0 until ecCount - 1) {
                rem[i] = rem[i + 1]
            }
            rem[ecCount - 1] = 0
            if (factor != 0) {
                for (i in 0 until ecCount) {
                    rem[i] = rem[i] xor gfMul(generator[i + 1], factor)
                }
            }
        }
        return rem
    }

    private fun drawFunctionPatterns(
        spec: VersionSpec,
        modules: Array<BooleanArray>,
        isFunction: Array<BooleanArray>
    ) {
        val size = spec.size

        fun setFunc(r: Int, c: Int, dark: Boolean) {
            if (r in 0 until size && c in 0 until size) {
                modules[r][c] = dark
                isFunction[r][c] = true
            }
        }

        // أنماط التحديد الثلاثة (Finder Patterns + Separators)
        fun drawFinder(centerR: Int, centerC: Int) {
            for (dr in -4..4) {
                for (dc in -4..4) {
                    val rr = centerR + dr
                    val cc = centerC + dc
                    if (rr in 0 until size && cc in 0 until size) {
                        val dist = maxOf(abs(dr), abs(dc))
                        val dark = dist != 2 && dist != 4
                        setFunc(rr, cc, dark)
                    }
                }
            }
        }

        drawFinder(3, 3)
        drawFinder(3, size - 4)
        drawFinder(size - 4, 3)

        // أنماط التوقيت (Timing Patterns)
        for (i in 8 until size - 8) {
            val dark = (i % 2 == 0)
            setFunc(6, i, dark)
            setFunc(i, 6, dark)
        }

        // أنماط المحاذاة (Alignment Patterns)
        val centers = spec.alignmentCenters
        for (i in centers.indices) {
            for (j in centers.indices) {
                val isCornerOverlap =
                    (i == 0 && j == 0) ||
                        (i == 0 && j == centers.lastIndex) ||
                        (i == centers.lastIndex && j == 0)
                if (!isCornerOverlap) {
                    val cr = centers[i]
                    val cc = centers[j]
                    for (dr in -2..2) {
                        for (dc in -2..2) {
                            val dist = maxOf(abs(dr), abs(dc))
                            setFunc(cr + dr, cc + dc, dist != 1)
                        }
                    }
                }
            }
        }

        // حجز مواقع معلومات التنسيق (Format Info) والوحدة الداكنة الثابتة
        for (i in 0..8) {
            if (i != 6) {
                setFunc(8, i, false)
                setFunc(i, 8, false)
            }
        }
        for (i in 0..7) {
            setFunc(8, size - 1 - i, false)
        }
        for (i in 0..6) {
            setFunc(size - 1 - i, 8, false)
        }
        setFunc(size - 8, 8, true) // Dark module

        // معلومات الإصدار (للإصدار 7 فأعلى)
        if (spec.version >= 7) {
            var rem = spec.version
            for (i in 0 until 12) {
                rem = (rem shl 1) xor (((rem ushr 11) and 1) * 0x1F25)
            }
            val versionBits = (spec.version shl 12) or rem
            for (i in 0 until 18) {
                val dark = ((versionBits ushr i) and 1) != 0
                val a = size - 11 + (i % 3)
                val b = i / 3
                setFunc(a, b, dark)
                setFunc(b, a, dark)
            }
        }
    }

    private fun placeCodewords(
        modules: Array<BooleanArray>,
        isFunction: Array<BooleanArray>,
        codewords: List<Int>
    ) {
        val size = modules.size
        val totalBits = codewords.size * 8
        var bitIdx = 0
        var upward = true
        var col = size - 1

        while (col >= 1) {
            if (col == 6) col-- // تجاوز عمود التوقيت
            for (step in 0 until size) {
                val row = if (upward) (size - 1 - step) else step
                for (dx in 0..1) {
                    val c = col - dx
                    if (!isFunction[row][c]) {
                        val isDark = if (bitIdx < totalBits) {
                            val cw = codewords[bitIdx ushr 3]
                            val shift = 7 - (bitIdx and 7)
                            ((cw ushr shift) and 1) != 0
                        } else {
                            false
                        }
                        modules[row][c] = isDark
                        bitIdx++
                    }
                }
            }
            upward = !upward
            col -= 2
        }
    }

    private fun applyMask(
        modules: Array<BooleanArray>,
        isFunction: Array<BooleanArray>,
        mask: Int
    ) {
        val size = modules.size
        for (r in 0 until size) {
            for (c in 0 until size) {
                if (!isFunction[r][c]) {
                    val invert = when (mask) {
                        0 -> (r + c) % 2 == 0
                        1 -> r % 2 == 0
                        2 -> c % 3 == 0
                        3 -> (r + c) % 3 == 0
                        4 -> ((r / 2) + (c / 3)) % 2 == 0
                        5 -> ((r * c) % 2) + ((r * c) % 3) == 0
                        6 -> ((((r * c) % 2) + ((r * c) % 3)) % 2) == 0
                        7 -> ((((r + c) % 2) + ((r * c) % 3)) % 2) == 0
                        else -> false
                    }
                    if (invert) {
                        modules[r][c] = !modules[r][c]
                    }
                }
            }
        }
    }

    private fun drawFormatBits(modules: Array<BooleanArray>, mask: Int) {
        val size = modules.size
        // ECC Level L = 01
        val data = (0b01 shl 3) or (mask and 0b111)
        var rem = data
        for (i in 0 until 10) {
            rem = (rem shl 1) xor (((rem ushr 9) and 1) * 0x537)
        }
        val bits = ((data shl 10) or rem) xor 0x5412

        // النسخة الأولى حول الزاوية العلوية اليسرى
        for (i in 0..5) modules[8][i] = ((bits ushr (14 - i)) and 1) != 0
        modules[8][7] = ((bits ushr 8) and 1) != 0
        modules[8][8] = ((bits ushr 7) and 1) != 0
        modules[7][8] = ((bits ushr 6) and 1) != 0
        for (i in 0..5) modules[5 - i][8] = ((bits ushr (5 - i)) and 1) != 0

        // النسخة الثانية في الزاويتين السفلية اليسرى والعلوية اليمنى
        for (i in 0..6) modules[size - 1 - i][8] = ((bits ushr (14 - i)) and 1) != 0
        for (i in 0..7) modules[8][size - 8 + i] = ((bits ushr (7 - i)) and 1) != 0
        modules[size - 8][8] = true
    }

    private fun computePenaltyScore(modules: Array<BooleanArray>): Int {
        val size = modules.size
        var penalty = 0

        // القاعدة 1: سلاسل أفقية وعمودية من نفس اللون (5 فأكثر)
        for (r in 0 until size) {
            var runColor = modules[r][0]
            var runLen = 1
            for (c in 1 until size) {
                if (modules[r][c] == runColor) {
                    runLen++
                } else {
                    if (runLen >= 5) penalty += 3 + (runLen - 5)
                    runColor = modules[r][c]
                    runLen = 1
                }
            }
            if (runLen >= 5) penalty += 3 + (runLen - 5)
        }
        for (c in 0 until size) {
            var runColor = modules[0][c]
            var runLen = 1
            for (r in 1 until size) {
                if (modules[r][c] == runColor) {
                    runLen++
                } else {
                    if (runLen >= 5) penalty += 3 + (runLen - 5)
                    runColor = modules[r][c]
                    runLen = 1
                }
            }
            if (runLen >= 5) penalty += 3 + (runLen - 5)
        }

        // القاعدة 2: مربعات 2×2 من نفس اللون
        for (r in 0 until size - 1) {
            for (c in 0 until size - 1) {
                val color = modules[r][c]
                if (color == modules[r][c + 1] &&
                    color == modules[r + 1][c] &&
                    color == modules[r + 1][c + 1]
                ) {
                    penalty += 3
                }
            }
        }

        // القاعدة 4: توازن نسبة الوحدات الداكنة
        var darkCount = 0
        for (r in 0 until size) {
            for (c in 0 until size) {
                if (modules[r][c]) darkCount++
            }
        }
        val total = size * size
        val k = (abs(darkCount * 20 - total * 10) + total - 1) / total - 1
        if (k > 0) penalty += k * 10

        return penalty
    }
}
