package com.humanitarian.aidmanagement.ui.screens.projects

import android.content.Context
import android.graphics.Color as AndroidGraphicsColor
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.util.AidRecordWithBeneficiary
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.BorderStyle
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.HorizontalAlignment
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.ss.usermodel.VerticalAlignment
import org.apache.poi.xssf.streaming.SXSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class ProjectExportFormat(
    val label: String,
    val shortLabel: String,
    val extension: String,
    val mimeType: String
) {
    XLSX(
        label = "إكسل منسق (.xlsx)",
        shortLabel = ".xlsx",
        extension = "xlsx",
        mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ),
    CSV(
        label = "بيانات خام (.csv)",
        shortLabel = ".csv",
        extension = "csv",
        mimeType = "text/csv"
    ),
    PDF(
        label = "ملف (.pdf)",
        shortLabel = ".pdf",
        extension = "pdf",
        mimeType = "application/pdf"
    )
}

data class ExportFieldOption(
    val key: String,
    val label: String,
    val pdfWeight: Float = 1.1f
)

data class ExportProjectUiState(
    val isLoading: Boolean = true,
    val project: ProjectEntity? = null,
    val aidTypeName: String = "",
    val beneficiariesCount: Int = 0,
    val selectedFamilyFields: Set<String> = DEFAULT_FAMILY_FIELDS,
    val includeChildren: Boolean = false,
    val childMinAge: String = "0",
    val childMaxAge: String = "18",
    val selectedChildFields: Set<String> = DEFAULT_CHILD_FIELDS,
    val selectedProjectFields: Set<String> = emptySet(),
    val selectedFormat: ProjectExportFormat = ProjectExportFormat.XLSX,
    val isExporting: Boolean = false,
    val exportProgress: Float = 0f,
    val statusMessage: String? = null,
    val errorMessage: String? = null
) {
    companion object {
        val FAMILY_FIELD_OPTIONS: List<ExportFieldOption> = listOf(
            ExportFieldOption("row_index", "م", 0.45f),
            ExportFieldOption("name", "الاسم الرباعي", 2.2f),
            ExportFieldOption("nationalID", "رقم الهوية الوطنية", 1.35f),
            ExportFieldOption("primary_phone", "رقم الجوال", 1.25f),
            ExportFieldOption("alternative_phone_1", "جوال بديل", 1.2f),
            ExportFieldOption("localityName", "المحافظة / المحلية", 1.2f),
            ExportFieldOption("currentMainArea", "المنطقة الرئيسية", 1.25f),
            ExportFieldOption("currentSubArea", "المنطقة الفرعية", 1.35f),
            ExportFieldOption("currentBranch", "الشعبة الميدانية", 1.2f),
            ExportFieldOption("familyMembersCount", "عدد أفراد الأسرة", 0.85f),
            ExportFieldOption("maritalStatus", "الحالة الاجتماعية", 1.0f),
            ExportFieldOption("date_of_birth", "تاريخ الميلاد", 1.05f),
            ExportFieldOption("age", "العمر", 0.7f),
            ExportFieldOption("gender", "الجنس", 0.75f),
            ExportFieldOption("wifeName", "اسم الزوج/الزوجة", 1.7f),
            ExportFieldOption("wifeNationalID", "هوية الزوج/الزوجة", 1.3f),
            ExportFieldOption("shelterStatus", "حالة الإيواء", 1.1f),
            ExportFieldOption("shelter_center_name", "مركز الإيواء / المخيم", 1.3f),
            ExportFieldOption("damageType", "حالة الضرر", 1.15f),
            ExportFieldOption("injuryStatus", "حالة الإصابة", 1.05f),
            ExportFieldOption("incomeSource1", "مصدر الدخل", 1.15f),
            ExportFieldOption("residentStatus", "صفة الإقامة", 1.0f),
            ExportFieldOption("developmentApproval", "اعتماد التنمية", 1.05f),
            ExportFieldOption("worksApproval", "اعتماد الأشغال", 1.05f),
            ExportFieldOption("rationCardNumber", "رقم كرت المؤن", 1.1f),
            ExportFieldOption("notes", "ملاحظات الأسرة", 1.5f)
        )

        val CHILD_FIELD_OPTIONS: List<ExportFieldOption> = listOf(
            ExportFieldOption("childName", "اسم الابن", 1.9f),
            ExportFieldOption("childAge", "عمر الابن", 0.75f),
            ExportFieldOption("childNationalId", "رقم هوية الابن", 1.3f),
            ExportFieldOption("childBirthDate", "تاريخ ميلاد الابن", 1.05f),
            ExportFieldOption("childGender", "جنس الابن", 0.8f),
            ExportFieldOption("childShelterStatus", "حالة إيواء الابن", 1.15f)
        )

        val PROJECT_FIELD_OPTIONS: List<ExportFieldOption> = listOf(
            ExportFieldOption("projectName", "اسم المشروع", 1.8f),
            ExportFieldOption("projectNumber", "رقم المشروع", 1.1f),
            ExportFieldOption("deliveryDate", "تاريخ التسليم", 1.15f),
            ExportFieldOption("fundingInstitution", "الممول", 1.5f),
            ExportFieldOption("aidTypeName", "نوع المساعدة", 1.2f),
            ExportFieldOption("projectDate", "تاريخ المشروع", 1.1f),
            ExportFieldOption("warehouseName", "المستودع المنفذ", 1.2f),
            ExportFieldOption("recipientStatus", "حالة الاستلام", 1.05f),
            ExportFieldOption("stageUserName", "المرشح / المشرف", 1.25f),
            ExportFieldOption("recordNotes", "ملاحظات السجل", 1.4f)
        )

        val DEFAULT_FAMILY_FIELDS: Set<String> = setOf(
            "row_index",
            "name",
            "nationalID",
            "primary_phone",
            "localityName",
            "currentSubArea",
            "familyMembersCount",
            "maritalStatus"
        )

        val DEFAULT_CHILD_FIELDS: Set<String> = setOf(
            "childName",
            "childAge",
            "childNationalId"
        )
    }
}

private data class ExportColumnSpec(
    val header: String,
    val pdfWeight: Float,
    val extractor: (
        index: Int,
        family: FamilyEntity,
        localityName: String,
        record: AidRecordEntity,
        matchedChild: ChildEntity?,
        matchedChildAge: Int?,
        project: ProjectEntity,
        aidTypeName: String
    ) -> String
)

private data class DynamicExportTable(
    val headers: List<String>,
    val pdfWeights: List<Float>,
    val rows: List<List<String>>
)

class ExportProjectViewModel(
    private val projectId: Long,
    private val repository: AidRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ExportProjectUiState())
    val uiState: StateFlow<ExportProjectUiState> = _uiState.asStateFlow()

    private var cachedBeneficiaries: List<AidRecordWithBeneficiary> = emptyList()
    private var cachedLocalitiesMap: Map<Int, String> = emptyMap()

    init {
        loadProjectData()
    }

    fun loadProjectData() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            try {
                val project = repository.getProjectById(projectId)
                val beneficiaries = repository.getProjectBeneficiariesWithFamilies(projectId)
                val aidTypeName = project?.let {
                    repository.getAidTypeByIdSync(it.aidTypeID)?.aidTypeName
                } ?: ""
                val localitiesMap = repository.getAllLocalitiesSync()
                    .associate { it.LocalityID to it.LocalityName }

                cachedBeneficiaries = beneficiaries
                cachedLocalitiesMap = localitiesMap

                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    project = project,
                    aidTypeName = aidTypeName,
                    beneficiariesCount = beneficiaries.size
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "تعذر تحميل بيانات المشروع: ${e.message}"
                )
            }
        }
    }

    fun toggleFamilyField(key: String) {
        val current = _uiState.value.selectedFamilyFields
        val updated = if (current.contains(key)) current - key else current + key
        _uiState.value = _uiState.value.copy(selectedFamilyFields = updated, statusMessage = null, errorMessage = null)
    }

    fun selectAllFamilyFields() {
        _uiState.value = _uiState.value.copy(
            selectedFamilyFields = ExportProjectUiState.FAMILY_FIELD_OPTIONS.map { it.key }.toSet(),
            statusMessage = null,
            errorMessage = null
        )
    }

    fun clearFamilyFields() {
        _uiState.value = _uiState.value.copy(
            selectedFamilyFields = setOf("row_index", "name"),
            statusMessage = null,
            errorMessage = null
        )
    }

    fun setIncludeChildren(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(
            includeChildren = enabled,
            statusMessage = null,
            errorMessage = null
        )
    }

    fun updateChildMinAge(value: String) {
        val clean = value.filter { it.isDigit() }.take(3)
        _uiState.value = _uiState.value.copy(childMinAge = clean, statusMessage = null, errorMessage = null)
    }

    fun updateChildMaxAge(value: String) {
        val clean = value.filter { it.isDigit() }.take(3)
        _uiState.value = _uiState.value.copy(childMaxAge = clean, statusMessage = null, errorMessage = null)
    }

    fun toggleChildField(key: String) {
        val current = _uiState.value.selectedChildFields
        val updated = if (current.contains(key)) current - key else current + key
        _uiState.value = _uiState.value.copy(selectedChildFields = updated, statusMessage = null, errorMessage = null)
    }

    fun toggleProjectField(key: String) {
        val current = _uiState.value.selectedProjectFields
        val updated = if (current.contains(key)) current - key else current + key
        _uiState.value = _uiState.value.copy(selectedProjectFields = updated, statusMessage = null, errorMessage = null)
    }

    fun selectAllProjectFields() {
        _uiState.value = _uiState.value.copy(
            selectedProjectFields = ExportProjectUiState.PROJECT_FIELD_OPTIONS.map { it.key }.toSet(),
            statusMessage = null,
            errorMessage = null
        )
    }

    fun clearProjectFields() {
        _uiState.value = _uiState.value.copy(
            selectedProjectFields = emptySet(),
            statusMessage = null,
            errorMessage = null
        )
    }

    fun selectFormat(format: ProjectExportFormat) {
        _uiState.value = _uiState.value.copy(selectedFormat = format, statusMessage = null, errorMessage = null)
    }

    fun clearMessages() {
        _uiState.value = _uiState.value.copy(statusMessage = null, errorMessage = null)
    }

    fun suggestedFileName(): String {
        val state = _uiState.value
        val prjNum = (state.project?.projectNumber ?: "PRJ_$projectId")
            .replace(Regex("[^a-zA-Z0-9_\\-\\u0600-\\u06FF]"), "_")
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        return "Project_${prjNum}_$timestamp.${state.selectedFormat.extension}"
    }

    fun totalSelectedColumnsCount(): Int {
        val state = _uiState.value
        val childCount = if (state.includeChildren) state.selectedChildFields.size else 0
        return state.selectedFamilyFields.size + childCount + state.selectedProjectFields.size
    }

    suspend fun exportToUri(context: Context, uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        val state = _uiState.value
        val project = state.project
            ?: return@withContext Result.failure(Exception("لم يتم العثور على بيانات المشروع."))

        if (state.selectedFamilyFields.isEmpty()) {
            val msg = "يرجى تحديد حقل واحد على الأقل من بيانات الأسرة الأساسية."
            _uiState.value = _uiState.value.copy(errorMessage = msg)
            return@withContext Result.failure(Exception(msg))
        }

        _uiState.value = _uiState.value.copy(
            isExporting = true,
            exportProgress = 0.05f,
            statusMessage = null,
            errorMessage = null
        )

        try {
            val beneficiaries = if (cachedBeneficiaries.isNotEmpty()) {
                cachedBeneficiaries
            } else {
                repository.getProjectBeneficiariesWithFamilies(projectId).also {
                    cachedBeneficiaries = it
                }
            }

            if (beneficiaries.isEmpty()) {
                val msg = "لا توجد أسر مرشحة أو مستفيدة مسجلة في هذا المشروع للتصدير."
                _uiState.value = _uiState.value.copy(isExporting = false, errorMessage = msg)
                return@withContext Result.failure(Exception(msg))
            }

            if (cachedLocalitiesMap.isEmpty()) {
                cachedLocalitiesMap = repository.getAllLocalitiesSync()
                    .associate { it.LocalityID to it.LocalityName }
            }

            _uiState.value = _uiState.value.copy(exportProgress = 0.18f)

            // Left Join مع جدول الأبناء فقط عند التفعيل
            val childrenByFamilyNationalId: Map<String, List<ChildEntity>> =
                if (state.includeChildren && state.selectedChildFields.isNotEmpty()) {
                    val familyNatIds: List<String> = beneficiaries
                        .mapNotNull { item: AidRecordWithBeneficiary -> item.family?.nationalID?.trim() }
                        .filter { natId: String -> natId.isNotBlank() }
                        .distinct()
                    repository.getChildrenByFamilyNationalIdsSync(familyNatIds)
                        .groupBy { it.familyNationalID.trim() }
                } else {
                    emptyMap()
                }

            _uiState.value = _uiState.value.copy(exportProgress = 0.35f)

            val table = buildDynamicTable(
                state = state,
                project = project,
                aidTypeName = state.aidTypeName,
                beneficiaries = beneficiaries,
                localitiesMap = cachedLocalitiesMap,
                childrenByFamilyNationalId = childrenByFamilyNationalId
            )

            if (table.headers.isEmpty()) {
                val msg = "لم يتم اختيار أي أعمدة للتصدير."
                _uiState.value = _uiState.value.copy(isExporting = false, errorMessage = msg)
                return@withContext Result.failure(Exception(msg))
            }

            _uiState.value = _uiState.value.copy(exportProgress = 0.55f)

            when (state.selectedFormat) {
                ProjectExportFormat.XLSX -> writeFormattedXlsxToUri(context, uri, project, table)
                ProjectExportFormat.CSV -> writeCsvToUri(context, uri, table)
                ProjectExportFormat.PDF -> writePdfToUri(context, uri, project, state.aidTypeName, table)
            }

            val successMsg = "تم تصدير ${table.rows.size} سجل بنجاح بصيغة ${state.selectedFormat.shortLabel}"
            _uiState.value = _uiState.value.copy(
                isExporting = false,
                exportProgress = 1.0f,
                statusMessage = successMsg,
                errorMessage = null
            )
            Result.success(successMsg)
        } catch (ce: CancellationException) {
            _uiState.value = _uiState.value.copy(isExporting = false)
            throw ce
        } catch (t: Throwable) {
            val errMsg = "فشل التصدير: ${t.message ?: "خطأ غير متوقع"}"
            _uiState.value = _uiState.value.copy(
                isExporting = false,
                errorMessage = errMsg
            )
            Result.failure(Exception(errMsg, t))
        }
    }

    private fun buildDynamicTable(
        state: ExportProjectUiState,
        project: ProjectEntity,
        aidTypeName: String,
        beneficiaries: List<AidRecordWithBeneficiary>,
        localitiesMap: Map<Int, String>,
        childrenByFamilyNationalId: Map<String, List<ChildEntity>>
    ): DynamicExportTable {
        val columnSpecs = mutableListOf<ExportColumnSpec>()

        // 1. أعمدة الأسرة (Root Entity)
        ExportProjectUiState.FAMILY_FIELD_OPTIONS.forEach { field: ExportFieldOption ->
            if (state.selectedFamilyFields.contains(field.key)) {
                columnSpecs.add(buildFamilyColumnSpec(field))
            }
        }

        // 2. أعمدة الابن (Left Join - ابن واحد مطابق ضمن الفئة العمرية إن وجد)
        if (state.includeChildren && state.selectedChildFields.isNotEmpty()) {
            ExportProjectUiState.CHILD_FIELD_OPTIONS.forEach { field ->
                if (state.selectedChildFields.contains(field.key)) {
                    columnSpecs.add(buildChildColumnSpec(field))
                }
            }
        }

        // 3. أعمدة المشروع (Left Join)
        ExportProjectUiState.PROJECT_FIELD_OPTIONS.forEach { field ->
            if (state.selectedProjectFields.contains(field.key)) {
                columnSpecs.add(buildProjectColumnSpec(field))
            }
        }

        val rawMin = state.childMinAge.toIntOrNull() ?: 0
        val rawMax = state.childMaxAge.toIntOrNull() ?: 18
        val minAge = minOf(rawMin, rawMax).coerceAtLeast(0)
        val maxAge = maxOf(rawMin, rawMax).coerceAtLeast(minAge)

        val rows = ArrayList<List<String>>(beneficiaries.size)
        beneficiaries.forEachIndexed { index: Int, item: AidRecordWithBeneficiary ->
            val rec: AidRecordEntity = item.record
            val fam: FamilyEntity = item.family ?: FamilyEntity(
                familyID = rec.familyID,
                nationalID = "",
                name = rec.actualRecipientName?.takeIf { it.isNotBlank() } ?: "مستفيد #${rec.familyID}"
            )
            val localityName = localitiesMap[fam.localityID] ?: fam.currentMainArea.ifBlank { "-" }

            var matchedChild: ChildEntity? = null
            var matchedChildAge: Int? = null
            if (state.includeChildren && state.selectedChildFields.isNotEmpty()) {
                val familyChildren: List<ChildEntity> = childrenByFamilyNationalId[fam.nationalID.trim()].orEmpty()
                for (child: ChildEntity in familyChildren.sortedBy { c: ChildEntity -> c.childID }) {
                    val age = computeAgeSafe(child.birthDate)
                    if (age in minAge..maxAge) {
                        matchedChild = child
                        matchedChildAge = age
                        break // ابن واحد مطابق للأسرة إن وجد
                    }
                }
            }

            val rowValues = columnSpecs.map { spec ->
                spec.extractor(
                    index + 1,
                    fam,
                    localityName,
                    rec,
                    matchedChild,
                    matchedChildAge,
                    project,
                    aidTypeName
                )
            }
            rows.add(rowValues)
        }

        return DynamicExportTable(
            headers = columnSpecs.map { it.header },
            pdfWeights = columnSpecs.map { it.pdfWeight },
            rows = rows
        )
    }

    private fun buildFamilyColumnSpec(field: ExportFieldOption): ExportColumnSpec {
        return ExportColumnSpec(
            header = field.label,
            pdfWeight = field.pdfWeight
        ) { idx, fam, localityName, _, _, _, _, _ ->
            when (field.key) {
                "row_index" -> idx.toString()
                "name" -> fam.name.ifBlank { "-" }
                "nationalID" -> fam.nationalID.ifBlank { "-" }
                "primary_phone" -> fam.primary_phone.ifBlank { "-" }
                "alternative_phone_1" -> fam.alternative_phone_1?.takeIf { it.isNotBlank() } ?: "-"
                "localityName" -> localityName.ifBlank { "-" }
                "currentMainArea" -> fam.currentMainArea.ifBlank { "-" }
                "currentSubArea" -> fam.currentSubArea.ifBlank { "-" }
                "currentBranch" -> fam.currentBranch.ifBlank { "-" }
                "familyMembersCount" -> fam.familyMembersCount.toString()
                "maritalStatus" -> fam.maritalStatus.ifBlank { "-" }
                "date_of_birth" -> fam.date_of_birth.ifBlank { "-" }
                "age" -> computeAgeSafe(fam.date_of_birth).toString()
                "gender" -> fam.gender.ifBlank { "-" }
                "wifeName" -> fam.wifeName?.takeIf { it.isNotBlank() } ?: "-"
                "wifeNationalID" -> fam.wifeNationalID?.takeIf { it.isNotBlank() } ?: "-"
                "shelterStatus" -> fam.shelterStatus.ifBlank { "-" }
                "shelter_center_name" -> fam.shelter_center_name?.takeIf { it.isNotBlank() } ?: "-"
                "damageType" -> fam.damageType.ifBlank { "-" }
                "injuryStatus" -> fam.injuryStatus.ifBlank { "-" }
                "incomeSource1" -> fam.incomeSource1.ifBlank { "-" }
                "residentStatus" -> fam.residentStatus.ifBlank { "-" }
                "developmentApproval" -> fam.developmentApproval.ifBlank { "-" }
                "worksApproval" -> fam.worksApproval.ifBlank { "-" }
                "rationCardNumber" -> fam.rationCardNumber?.takeIf { it.isNotBlank() } ?: "-"
                "notes" -> fam.notes?.takeIf { it.isNotBlank() } ?: ""
                else -> ""
            }
        }
    }

    private fun buildChildColumnSpec(field: ExportFieldOption): ExportColumnSpec {
        return ExportColumnSpec(
            header = field.label,
            pdfWeight = field.pdfWeight
        ) { _, _, _, _, child, childAge, _, _ ->
            if (child == null) {
                ""
            } else {
                when (field.key) {
                    "childName" -> child.childName.ifBlank { "-" }
                    "childAge" -> (childAge ?: computeAgeSafe(child.birthDate)).toString()
                    "childNationalId" -> child.nationalID.ifBlank { "-" }
                    "childBirthDate" -> child.birthDate.ifBlank { "-" }
                    "childGender" -> child.gender.ifBlank { "-" }
                    "childShelterStatus" -> child.shelterStatus.ifBlank { "-" }
                    else -> ""
                }
            }
        }
    }

    private fun buildProjectColumnSpec(field: ExportFieldOption): ExportColumnSpec {
        return ExportColumnSpec(
            header = field.label,
            pdfWeight = field.pdfWeight
        ) { _, _, _, rec, _, _, prj, aidType ->
            when (field.key) {
                "projectName" -> prj.projectName.ifBlank { "-" }
                "projectNumber" -> prj.projectNumber.ifBlank { "-" }
                "deliveryDate" -> rec.deliveryDate?.takeIf { it.isNotBlank() } ?: "قيد التسليم"
                "fundingInstitution" -> prj.fundingInstitution.ifBlank { "-" }
                "aidTypeName" -> aidType.ifBlank { "-" }
                "projectDate" -> prj.projectDate.ifBlank { "-" }
                "warehouseName" -> rec.warehouse.ifBlank { prj.warehouseName.ifBlank { "-" } }
                "recipientStatus" -> rec.recipientStatus.ifBlank { "-" }
                "stageUserName" -> rec.stageUserName?.takeIf { it.isNotBlank() } ?: "النظام"
                "recordNotes" -> rec.notes?.takeIf { it.isNotBlank() } ?: ""
                else -> ""
            }
        }
    }

    private fun computeAgeSafe(dobString: String?): Int {
        if (dobString.isNullOrBlank()) return 0
        return try {
            val parts = dobString.trim().split("-", "/")
            if (parts.size < 3) return 0
            val p0 = parts[0].toIntOrNull() ?: return 0
            val p1 = parts[1].toIntOrNull() ?: 1
            val p2 = parts[2].toIntOrNull() ?: 1
            val (year, month, day) = if (parts[0].trim().length == 4) {
                Triple(p0, p1.coerceIn(1, 12), p2.coerceIn(1, 31))
            } else if (parts[2].trim().length == 4) {
                Triple(p2, p1.coerceIn(1, 12), p0.coerceIn(1, 31))
            } else {
                Triple(p0, p1.coerceIn(1, 12), p2.coerceIn(1, 31))
            }
            val birthCal = Calendar.getInstance().apply { set(year, month - 1, day) }
            val today = Calendar.getInstance()
            var age = today.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR)
            if (today.get(Calendar.DAY_OF_YEAR) < birthCal.get(Calendar.DAY_OF_YEAR)) {
                age--
            }
            age.coerceAtLeast(0)
        } catch (_: Exception) {
            0
        }
    }

    private fun writeFormattedXlsxToUri(
        context: Context,
        uri: Uri,
        project: ProjectEntity,
        table: DynamicExportTable
    ) {
        val tempDir = File(context.cacheDir, "project_exports").apply { mkdirs() }
        val tempFile = File(tempDir, "project_export_${System.currentTimeMillis()}.xlsx")
        var activeWorkbook: SXSSFWorkbook? = null

        try {
            val wb = SXSSFWorkbook(100).apply {
                isCompressTempFiles = true
            }
            activeWorkbook = wb

            val safeSheetName = project.projectName
                .replace(Regex("[\\\\/?*\\[\\]:]"), "-")
                .trim()
                .take(31)
                .ifBlank { "Project_${project.projectID}" }

            val sheet = wb.createSheet(safeSheetName)
            sheet.isRightToLeft = true

            // تجميد الصف الأول (صف العناوين)
            sheet.createFreezePane(0, 1)

            // حساب توافق عرض الأعمدة رياضياً (آمن 100% على Android بدون java.awt)
            val maxColLengths = IntArray(table.headers.size) { colIdx ->
                table.headers[colIdx].length
            }
            for (row in table.rows) {
                for (colIdx in row.indices) {
                    val len = row[colIdx].length
                    if (len > maxColLengths[colIdx]) {
                        maxColLengths[colIdx] = len
                    }
                }
            }
            maxColLengths.forEachIndexed { colIdx, maxLen ->
                val computedWidth = ((maxLen + 5) * 290).coerceIn(2500, 15000)
                sheet.setColumnWidth(colIdx, computedWidth)
            }

            val headerFont = wb.createFont().apply {
                bold = true
                color = IndexedColors.WHITE.index
                fontHeightInPoints = 11.toShort()
            }
            val headerStyle = wb.createCellStyle().apply {
                setFont(headerFont)
                fillForegroundColor = IndexedColors.DARK_TEAL.index
                fillPattern = FillPatternType.SOLID_FOREGROUND
                alignment = HorizontalAlignment.CENTER
                verticalAlignment = VerticalAlignment.CENTER
                borderTop = BorderStyle.THIN
                borderBottom = BorderStyle.MEDIUM
                borderLeft = BorderStyle.THIN
                borderRight = BorderStyle.THIN
                topBorderColor = IndexedColors.WHITE.index
                bottomBorderColor = IndexedColors.WHITE.index
                leftBorderColor = IndexedColors.WHITE.index
                rightBorderColor = IndexedColors.WHITE.index
            }

            val evenRowStyle = wb.createCellStyle().apply {
                alignment = HorizontalAlignment.RIGHT
                verticalAlignment = VerticalAlignment.CENTER
                borderBottom = BorderStyle.THIN
                borderLeft = BorderStyle.THIN
                borderRight = BorderStyle.THIN
                bottomBorderColor = IndexedColors.GREY_25_PERCENT.index
                leftBorderColor = IndexedColors.GREY_25_PERCENT.index
                rightBorderColor = IndexedColors.GREY_25_PERCENT.index
            }

            val oddRowStyle = wb.createCellStyle().apply {
                fillForegroundColor = IndexedColors.GREY_25_PERCENT.index
                fillPattern = FillPatternType.SOLID_FOREGROUND
                alignment = HorizontalAlignment.RIGHT
                verticalAlignment = VerticalAlignment.CENTER
                borderBottom = BorderStyle.THIN
                borderLeft = BorderStyle.THIN
                borderRight = BorderStyle.THIN
                bottomBorderColor = IndexedColors.GREY_25_PERCENT.index
                leftBorderColor = IndexedColors.GREY_25_PERCENT.index
                rightBorderColor = IndexedColors.GREY_25_PERCENT.index
            }

            // الصف الأول: الترويسة الملونة
            val headerRow = sheet.createRow(0).apply {
                heightInPoints = 26f
            }
            table.headers.forEachIndexed { colIdx, headerTitle ->
                headerRow.createCell(colIdx).apply {
                    setCellValue(headerTitle)
                    cellStyle = headerStyle
                }
            }

            val total = table.rows.size.coerceAtLeast(1)
            table.rows.forEachIndexed { rIdx, rowCells ->
                val dataRow = sheet.createRow(rIdx + 1).apply {
                    heightInPoints = 20f
                }
                val rowStyle = if (rIdx % 2 == 0) evenRowStyle else oddRowStyle
                rowCells.forEachIndexed { colIdx, value ->
                    dataRow.createCell(colIdx).apply {
                        setCellValue(value)
                        cellStyle = rowStyle
                    }
                }
                if ((rIdx + 1) % 200 == 0) {
                    _uiState.value = _uiState.value.copy(
                        exportProgress = (0.55f + 0.35f * ((rIdx + 1).toFloat() / total)).coerceIn(0.55f, 0.90f)
                    )
                }
            }

            FileOutputStream(tempFile).use { fos ->
                wb.write(fos)
                fos.flush()
            }
            try { wb.dispose() } catch (_: Throwable) {}
            try { wb.close() } catch (_: Throwable) {}
            activeWorkbook = null

            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: throw Exception("تعذر فتح مجرى الكتابة عبر SAF (ContentResolver).")
            tempFile.inputStream().use { input ->
                outputStream.use { out ->
                    input.copyTo(out)
                    out.flush()
                }
            }
        } finally {
            try { activeWorkbook?.dispose() } catch (_: Throwable) {}
            try { activeWorkbook?.close() } catch (_: Throwable) {}
            try { if (tempFile.exists()) tempFile.delete() } catch (_: Throwable) {}
        }
    }

    private fun writeCsvToUri(
        context: Context,
        uri: Uri,
        table: DynamicExportTable
    ) {
        val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
            ?: throw Exception("تعذر فتح مجرى الكتابة عبر SAF (ContentResolver).")

        outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
            // UTF-8 BOM لدعم اللغة العربية بشكل سليم في Microsoft Excel
            writer.write("\uFEFF")
            writer.write(table.headers.joinToString(",") { escapeCsvCell(it) })
            writer.write("\n")

            val total = table.rows.size.coerceAtLeast(1)
            val sb = StringBuilder(256)
            table.rows.forEachIndexed { idx, row ->
                sb.setLength(0)
                for (c in row.indices) {
                    if (c > 0) sb.append(',')
                    sb.append(escapeCsvCell(row[c]))
                }
                sb.append('\n')
                writer.write(sb.toString())

                if ((idx + 1) % 300 == 0) {
                    writer.flush()
                    _uiState.value = _uiState.value.copy(
                        exportProgress = (0.55f + 0.40f * ((idx + 1).toFloat() / total)).coerceIn(0.55f, 0.95f)
                    )
                }
            }
            writer.flush()
        }
    }

    private fun escapeCsvCell(value: String): String {
        val clean = value.replace("\"", "\"\"")
        return if (clean.contains(",") || clean.contains("\"") || clean.contains("\n") || clean.contains("\r")) {
            "\"$clean\""
        } else {
            clean
        }
    }

    private fun writePdfToUri(
        context: Context,
        uri: Uri,
        project: ProjectEntity,
        aidTypeName: String,
        table: DynamicExportTable
    ) {
        val tempDir = File(context.cacheDir, "project_pdf_exports").apply { mkdirs() }
        val tempFile = File(tempDir, "project_export_${System.currentTimeMillis()}.pdf")
        var activePdf: PdfDocument? = null

        try {
            val doc = PdfDocument()
            activePdf = doc

            val colCount = table.headers.size
            val useLandscape = colCount > 6
            val pageWidth = if (useLandscape) 842 else 595
            val pageHeight = if (useLandscape) 595 else 842
            val marginH = 24f
            val availableWidth = pageWidth - (marginH * 2)
            val totalWeight = table.pdfWeights.sum().coerceAtLeast(1f)
            val colWidths = table.pdfWeights.map { (it / totalWeight) * availableWidth }

            val itemsPerPage = if (useLandscape) 18 else 25
            val totalPages = if (table.rows.isEmpty()) 1 else ((table.rows.size - 1) / itemsPerPage) + 1
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())

            val topBarPaint = Paint().apply { color = AndroidGraphicsColor.rgb(0, 122, 61) }
            val infoBoxPaint = Paint().apply { color = AndroidGraphicsColor.rgb(241, 245, 249) }
            val fillPaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
            val strokePaint = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = 0.6f }

            val titlePaint = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.rgb(0, 122, 61)
                textSize = 14f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val metaPaint = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.rgb(30, 41, 59)
                textSize = 8.5f
                textAlign = Paint.Align.RIGHT
            }
            val datePaint = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.rgb(100, 116, 139)
                textSize = 8f
                textAlign = Paint.Align.LEFT
            }
            val headerTextPaint = Paint().apply {
                isAntiAlias = true
                textSize = if (colCount > 8) 7.5f else 8.6f
                color = AndroidGraphicsColor.WHITE
                isFakeBoldText = true
            }
            val cellTextPaint = Paint().apply {
                isAntiAlias = true
                textSize = if (colCount > 8) 7.1f else 8.1f
                color = AndroidGraphicsColor.rgb(15, 23, 42)
                typeface = Typeface.DEFAULT
            }
            val footerPaint = Paint().apply {
                isAntiAlias = true
                textSize = 8f
                color = AndroidGraphicsColor.GRAY
            }

            for (pageIdx in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIdx + 1).create()
                val page = doc.startPage(pageInfo)
                val canvas = page.canvas

                // شريط علوي
                canvas.drawRect(0f, 0f, pageWidth.toFloat(), 10f, topBarPaint)
                canvas.drawText("كشف المشروع المخصص: ${project.projectName}", pageWidth - marginH, 32f, titlePaint)
                canvas.drawText("تاريخ الاستخراج: $dateStr", marginH, 32f, datePaint)

                val metaBox = RectF(marginH, 42f, pageWidth - marginH, 76f)
                canvas.drawRoundRect(metaBox, 6f, 6f, infoBoxPaint)
                canvas.drawText(
                    "رقم المشروع: ${project.projectNumber}  |  الممول: ${project.fundingInstitution}  |  نوع المساعدة: ${aidTypeName.ifBlank { "-" }}",
                    pageWidth - marginH - 10f,
                    57f,
                    metaPaint
                )
                canvas.drawText(
                    "إجمالي الأسر المستفيدة في الكشف: ${table.rows.size} أسرة",
                    pageWidth - marginH - 10f,
                    70f,
                    metaPaint
                )

                var currentY = 86f
                val headerHeight = 22f
                val rowHeight = 19f

                // ترويسة الجدول RTL
                fillPaint.color = AndroidGraphicsColor.rgb(15, 23, 42)
                canvas.drawRect(marginH, currentY, pageWidth - marginH, currentY + headerHeight, fillPaint)

                var tableX = pageWidth - marginH
                strokePaint.color = AndroidGraphicsColor.rgb(51, 65, 85)
                table.headers.forEachIndexed { cIdx, label ->
                    val w = colWidths[cIdx]
                    val cellLeft = tableX - w
                    tableX -= w
                    canvas.drawLine(cellLeft, currentY, cellLeft, currentY + headerHeight, strokePaint)
                    val displayHeader = fitTextToWidth(label, headerTextPaint, w - 4f)
                    val tw = headerTextPaint.measureText(displayHeader)
                    val tx = cellLeft + (w - tw) / 2f
                    val ty = currentY + (headerHeight / 2f) - ((headerTextPaint.descent() + headerTextPaint.ascent()) / 2f)
                    canvas.drawText(displayHeader, tx, ty, headerTextPaint)
                }
                currentY += headerHeight

                val startRow = pageIdx * itemsPerPage
                val endRow = minOf(startRow + itemsPerPage, table.rows.size)
                for (rIdx in startRow until endRow) {
                    val localIdx = rIdx - startRow
                    fillPaint.color = if (localIdx % 2 == 0) AndroidGraphicsColor.WHITE else AndroidGraphicsColor.rgb(241, 245, 249)
                    canvas.drawRect(marginH, currentY, pageWidth - marginH, currentY + rowHeight, fillPaint)

                    strokePaint.color = AndroidGraphicsColor.rgb(226, 232, 240)
                    canvas.drawLine(marginH, currentY + rowHeight, pageWidth - marginH, currentY + rowHeight, strokePaint)

                    val rowCells = table.rows[rIdx]
                    var cellX = pageWidth - marginH
                    for (cIdx in table.headers.indices) {
                        val w = colWidths[cIdx]
                        val cellLeft = cellX - w
                        cellX -= w
                        canvas.drawLine(cellLeft, currentY, cellLeft, currentY + rowHeight, strokePaint)

                        val rawVal = rowCells.getOrNull(cIdx).orEmpty().ifBlank { "-" }
                        val displayVal = fitTextToWidth(rawVal, cellTextPaint, w - 6f)
                        val tw = cellTextPaint.measureText(displayVal)
                        val tx = cellLeft + (w - tw) / 2f
                        val ty = currentY + (rowHeight / 2f) - ((cellTextPaint.descent() + cellTextPaint.ascent()) / 2f)
                        canvas.drawText(displayVal, tx, ty, cellTextPaint)
                    }
                    currentY += rowHeight
                }

                val footerText = "صفحة ${pageIdx + 1} من $totalPages • نظام إدارة المساعدات الإنسانية"
                val fw = footerPaint.measureText(footerText)
                canvas.drawText(footerText, (pageWidth - fw) / 2f, pageHeight - 14f, footerPaint)

                doc.finishPage(page)
                _uiState.value = _uiState.value.copy(
                    exportProgress = (0.55f + 0.35f * ((pageIdx + 1).toFloat() / totalPages)).coerceIn(0.55f, 0.90f)
                )
            }

            FileOutputStream(tempFile).use { fos ->
                doc.writeTo(fos)
                fos.flush()
            }
            doc.close()
            activePdf = null

            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: throw Exception("تعذر فتح مجرى الكتابة عبر SAF (ContentResolver).")
            tempFile.inputStream().use { input ->
                outputStream.use { out ->
                    input.copyTo(out)
                    out.flush()
                }
            }
        } finally {
            try { activePdf?.close() } catch (_: Throwable) {}
            try { if (tempFile.exists()) tempFile.delete() } catch (_: Throwable) {}
        }
    }

    private fun fitTextToWidth(text: String, paint: Paint, maxWidth: Float): String {
        if (maxWidth <= 8f || paint.measureText(text) <= maxWidth) return text
        var truncated = text
        while (truncated.isNotEmpty() && paint.measureText("$truncated…") > maxWidth) {
            truncated = truncated.dropLast(1)
        }
        return if (truncated.isEmpty()) text.take(1) else "$truncated…"
    }
}

class ExportProjectViewModelFactory(
    private val projectId: Long,
    private val repository: AidRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ExportProjectViewModel::class.java)) {
            return ExportProjectViewModel(projectId, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
