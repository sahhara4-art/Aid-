package com.humanitarian.aidmanagement.util

import com.humanitarian.aidmanagement.data.local.entities.Family

data class ExcelRowError(
    val rowIndex: Int,
    val nationalId: String?,
    val name: String?,
    val errorMessage: String
)

data class ExcelImportResult(
    val importedFamilies: List<Family>,
    val skippedErrors: List<ExcelRowError>,
    val totalProcessedRows: Int,
    val successCount: Int,
    val errorCount: Int
)

/**
 * محرك استيراد الإكسل الديناميكي (Dynamic Localities Excel Parser)
 * - تم التخلي تماماً عن أي قاموس أو خريطة ثابتة (Map أو when).
 * - يقرأ حقل "معرف المحلية" (ID) وحقل "اسم المحلية" (Name) مباشرة من كل سطر في ملف الإكسل.
 * - يحفظهما كما هما داخل كيان الأسرة (Family) في قاعدة بيانات Room.
 * - يمنع منعاً باتاً أي قيمة افتراضية صامتة (No Fallback to default locality).
 */
object ExcelParserHelper {

    /**
     * معالجة وتحليل أسطر ملف Excel أو CSV بالهيكلية الديناميكية
     * ترتيب الأعمدة المتوقع:
     * 0: اسم رب الأسرة
     * 1: رقم الهوية
     * 2: معرف المحلية (LocalityID - رقم)
     * 3: اسم المحلية (LocalityName - نص)
     * 4: عدد أفراد الأسرة
     * 5: حالة الإقامة (مقيم / نازح)
     * 6: حالة التنمية (معتمد / غير معتمد)
     * 7: حالة الأشغال (معتمد أشغال / غير معتمد)
     * 8: حالة الإيواء
     */
    fun parseRows(rawLines: List<List<String>>): ExcelImportResult {
        val importedFamilies = mutableListOf<Family>()
        val skippedErrors = mutableListOf<ExcelRowError>()
        var totalRows = 0

        for ((index, row) in rawLines.withIndex()) {
            if (index == 0 && isHeaderRow(row)) continue

            totalRows++
            val rowNumber = index + 1

            if (row.isEmpty() || row.all { it.isBlank() }) {
                skippedErrors.add(
                    ExcelRowError(rowNumber, null, null, "سطر فارغ تم تخطيه.")
                )
                continue
            }

            val name = row.getOrNull(0)?.trim()
            val nationalId = row.getOrNull(1)?.trim()
            val rawLocalityId = row.getOrNull(2)?.trim()
            val rawLocalityName = row.getOrNull(3)?.trim()
            val membersCountStr = row.getOrNull(4)?.trim()
            val residentStatus = row.getOrNull(5)?.trim() ?: "مقيم"
            val devApproval = row.getOrNull(6)?.trim() ?: "معتمد"
            val workApproval = row.getOrNull(7)?.trim() ?: "معتمد أشغال"
            val shelterStatus = row.getOrNull(8)?.trim() ?: "إيواء داخلي"

            // 1. التحقق من اسم رب الأسرة
            if (name.isNullOrBlank()) {
                skippedErrors.add(
                    ExcelRowError(rowNumber, nationalId, name, "تم تخطي السطر: حقل اسم رب الأسرة فارغ.")
                )
                continue
            }

            // 2. التحقق من رقم الهوية
            if (nationalId.isNullOrBlank() || nationalId.length < 9) {
                skippedErrors.add(
                    ExcelRowError(rowNumber, nationalId, name, "تم تخطي السطر: رقم الهوية غير صحيح أو أقل من 9 أرقام.")
                )
                continue
            }

            // =================================================================
            // 3. قراءة معرف المحلية واسمها ديناميكياً مباشرة بدون أي قاموس ثابت
            // وبدون أي Fallback افتراضي
            // =================================================================
            val localityId = rawLocalityId?.toIntOrNull()
            if (localityId == null || localityId <= 0) {
                skippedErrors.add(
                    ExcelRowError(
                        rowIndex = rowNumber,
                        nationalId = nationalId,
                        name = name,
                        errorMessage = "تم تخطي السطر: معرف المحلية (ID) غير صالح أو مفقود ('$rawLocalityId'). مرفوض التعيين الافتراضي."
                    )
                )
                continue
            }

            if (rawLocalityName.isNullOrBlank()) {
                skippedErrors.add(
                    ExcelRowError(
                        rowIndex = rowNumber,
                        nationalId = nationalId,
                        name = name,
                        errorMessage = "تم تخطي السطر: اسم المحلية مفقود أو فارغ. مرفوض التعيين الافتراضي."
                    )
                )
                continue
            }

            val membersCount = membersCountStr?.toIntOrNull() ?: 1

            // حفظ البيانات كما هي داخل كيان الأسرة Family
            val family = Family(
                name = name,
                nationalID = nationalId,
                birthDate = System.currentTimeMillis() - 35L * 365 * 24 * 3600 * 1000,
                gender = "ذكر",
                maritalStatus = "متزوج",
                familyMembersCount = membersCount.coerceAtLeast(1),
                residentStatus = if (residentStatus.contains("نازح")) "نازح" else "مقيم",
                developmentApproval = if (devApproval.contains("غير")) "غير معتمد" else "معتمد",
                workApproval = if (workApproval.contains("اشغال") || workApproval.contains("أشغال")) "معتمد أشغال" else "غير معتمد",
                shelterStatus = shelterStatus,
                localityID = localityId,
                localityName = rawLocalityName, // حفظ اسم المحلية ديناميكياً كما ورد في الملف
                createdDate = System.currentTimeMillis(),
                modifiedDate = System.currentTimeMillis()
            )

            importedFamilies.add(family)
        }

        return ExcelImportResult(
            importedFamilies = importedFamilies,
            skippedErrors = skippedErrors,
            totalProcessedRows = totalRows,
            successCount = importedFamilies.size,
            errorCount = skippedErrors.size
        )
    }

    private fun isHeaderRow(row: List<String>): Boolean {
        val firstCell = row.firstOrNull()?.trim() ?: ""
        val secondCell = row.getOrNull(1)?.trim() ?: ""
        return firstCell.contains("الاسم") || firstCell.contains("name", ignoreCase = true) ||
                secondCell.contains("هوية") || secondCell.contains("id", ignoreCase = true)
    }
}
