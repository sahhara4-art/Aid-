package com.humanitarian.aidmanagement.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecord
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AidRecordsScreen(
    repository: AidRepository,
    isSuperAdmin: Boolean,
    allowedLocalityIds: List<Int>,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dateFormatter = remember { SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH) }

    var selectedAidTypeId by remember { mutableStateOf<Int?>(null) }
    var selectedProjectId by remember { mutableStateOf<Int?>(null) }
    var selectedLocalityId by remember { mutableStateOf<Int?>(null) }
    var showAddAidDialog by remember { mutableStateOf(false) }

    val aidTypes by repository.getAidTypes().collectAsState(initial = emptyList())
    val projects by repository.getProjects().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val aidRecords by repository.getAidRecords(
        isSuperAdmin = isSuperAdmin,
        allowedLocalityIds = allowedLocalityIds,
        aidTypeId = selectedAidTypeId,
        projectId = selectedProjectId,
        localityId = selectedLocalityId
    ).collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("إدارة المساعدات (${aidRecords.size})", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "القائمة")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddAidDialog = true },
                containerColor = Color(0xFF1976D2),
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مساعدة")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
        ) {
            // Filters row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedAidTypeId == null,
                    onClick = { selectedAidTypeId = null },
                    label = { Text("جميع الأنواع") }
                )
                aidTypes.take(4).forEach { type ->
                    FilterChip(
                        selected = selectedAidTypeId == type.aidTypeID,
                        onClick = { selectedAidTypeId = type.aidTypeID },
                        label = { Text(type.aidTypeName) }
                    )
                }
            }

            if (aidRecords.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Inbox, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(56.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("لا توجد سجلات مساعدة مسجلة", color = Color(0xFF64748B))
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(aidRecords, key = { it.aidRecordID }) { rec ->
                        val typeName = aidTypes.find { it.aidTypeID == rec.aidTypeID }?.aidTypeName ?: "نوع ${rec.aidTypeID}"
                        val projName = projects.find { it.projectID == rec.projectID }?.projectName ?: "مشروع عام"
                        val locName = localities.find { it.localityId == rec.localityID }?.localityName ?: "محلية ${rec.localityID}"

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            elevation = CardDefaults.cardElevation(2.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(typeName, fontWeight = FontWeight.Bold, color = Color(0xFF1976D2), fontSize = 15.sp)
                                    Text(dateFormatter.format(Date(rec.aidDate)), fontSize = 12.sp, color = Color(0xFF64748B))
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("رقم الهوية للمستفيد: ${rec.nationalID}", fontSize = 13.sp, color = Color(0xFF334155), fontWeight = FontWeight.Medium)
                                Text("المشروع: $projName", fontSize = 12.sp, color = Color(0xFF475569))
                                Text("المحلية: $locName | القيمة: ${rec.aidValue} شيكل", fontSize = 12.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddAidDialog) {
        var nationalIdInput by remember { mutableStateOf("") }
        var aidValueInput by remember { mutableStateOf("50") }
        var selectedType by remember { mutableStateOf(aidTypes.firstOrNull()?.aidTypeID ?: 1) }
        var selectedProject by remember { mutableStateOf(projects.firstOrNull()?.projectID ?: 1) }

        AlertDialog(
            onDismissRequest = { showAddAidDialog = false },
            title = { Text("تسجيل تسليم مساعدة", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = nationalIdInput,
                        onValueChange = { nationalIdInput = it },
                        label = { Text("رقم هوية المستفيد") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = aidValueInput,
                        onValueChange = { aidValueInput = it },
                        label = { Text("القيمة التقديرية (شيكل)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nationalIdInput.isBlank()) return@Button
                        scope.launch {
                            val family = repository.getFamiliesFiltered(true, emptyList(), query = nationalIdInput.trim())
                            val record = AidRecord(
                                familyID = 1,
                                nationalID = nationalIdInput.trim(),
                                aidTypeID = selectedType,
                                projectID = selectedProject,
                                detailedDescription = "تسجيل مساعدة مباشرة",
                                aidDate = System.currentTimeMillis(),
                                aidValue = aidValueInput.toDoubleOrNull() ?: 50.0,
                                localityID = 1,
                                createdBy = 1
                            )
                            repository.addAidRecord(record)
                            Toast.makeText(context, "تم تسجيل المساعدة", Toast.LENGTH_SHORT).show()
                            showAddAidDialog = false
                        }
                    }
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddAidDialog = false }) { Text("إلغاء") }
            }
        )
    }
}
