package com.humanitarian.aidmanagement.notifications

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.humanitarian.aidmanagement.MainActivity
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit

class AidNotificationWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val appContext = context.applicationContext
            val prefs = appContext.getSharedPreferences(ALERT_PREFS_NAME, Context.MODE_PRIVATE)
            val nowMillis = System.currentTimeMillis()

            val database = AidDatabase.getDatabase(
                appContext,
                CoroutineScope(SupervisorJob())
            )
            val readableDb = database.openHelper.readableDatabase

            // 1. تنبيه استباقي: وجود شكاوى مفتوحة (OPEN) مرّ عليها أكثر من 7 أيام دون ترشيح
            checkOverdueOpenComplaints(
                db = readableDb,
                prefs = prefs,
                nowMillis = nowMillis
            )

            // 2. تنبيه استباقي: مرور أكثر من 3 أيام دون أخذ نسخة احتياطية لقاعدة البيانات
            checkOverdueDatabaseBackup(
                appContext = appContext,
                db = readableDb,
                prefs = prefs,
                nowMillis = nowMillis
            )

            // 3. تنبيه استباقي: وجود أسر معتمدة أو مقيمة تجاوزت 90 يوماً بدون استلام أي معونة
            checkUnservedFamiliesOver90Days(
                db = readableDb,
                prefs = prefs,
                nowMillis = nowMillis
            )

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }

    /**
     * الفحص الأول: عدّ الشكاوى المفتوحة (OPEN) التي مرّ عليها أكثر من 7 أيام دون ترشيح عبر SELECT COUNT(*)
     */
    private fun checkOverdueOpenComplaints(
        db: SupportSQLiteDatabase,
        prefs: SharedPreferences,
        nowMillis: Long
    ) {
        if (!canSendAlert(prefs, KEY_LAST_ALERT_OPEN_COMPLAINTS, nowMillis)) return

        val overdueCount = countOverdueOpenComplaints(db, nowMillis)
        if (overdueCount <= 0) return

        val title = "⚠️ شكاوى مفتوحة متأخرة عن الترشيح ($overdueCount)"
        val shortText = "توجد $overdueCount شكوى مفتوحة (OPEN) مرّ عليها أكثر من $COMPLAINTS_THRESHOLD_DAYS أيام دون ترشيح."
        val bigText = """
            يوجد حالياً $overdueCount شكوى مفتوحة بحالة (OPEN) تجاوزت $COMPLAINTS_THRESHOLD_DAYS أيام دون ترشيح أو معالجة.
            يرجى مراجعة شاشة الشكاوى والأولويات وترحيل الأسر المستحقة في أقرب مشروع إغاثي.
        """.trimIndent()

        if (sendProactiveNotification(
                notificationId = NOTIFICATION_ID_OVERDUE_COMPLAINTS,
                title = title,
                shortText = shortText,
                bigText = bigText,
                navigateTarget = "families",
                actionLabel = "مراجعة الشكاوى"
            )
        ) {
            markAlertSent(prefs, KEY_LAST_ALERT_OPEN_COMPLAINTS, nowMillis)
        }
    }

    /**
     * الفحص الثاني: التحقق من مرور أكثر من 3 أيام دون أخذ نسخة احتياطية لقاعدة البيانات
     */
    private fun checkOverdueDatabaseBackup(
        appContext: Context,
        db: SupportSQLiteDatabase,
        prefs: SharedPreferences,
        nowMillis: Long
    ) {
        if (!canSendAlert(prefs, KEY_LAST_ALERT_BACKUP_OVERDUE, nowMillis)) return

        val lastBackupMillis = resolveLastBackupTimestampMillis(appContext, db, prefs)
        val referenceMillis = if (lastBackupMillis > 0L) {
            lastBackupMillis
        } else {
            resolveInstallOrFirstRunBaselineMillis(appContext, prefs, nowMillis)
        }

        val elapsedMillis = (nowMillis - referenceMillis).coerceAtLeast(0L)
        if (elapsedMillis <= BACKUP_THRESHOLD_MILLIS) return

        val daysElapsed = TimeUnit.MILLISECONDS.toDays(elapsedMillis).toInt().coerceAtLeast(BACKUP_THRESHOLD_DAYS + 1)
        val title = "🛡️ تنبيه أمن البيانات: النسخ الاحتياطي متأخر"
        val shortText = if (lastBackupMillis > 0L) {
            "مرّ $daysElapsed أيام منذ آخر نسخة احتياطية لقاعدة البيانات."
        } else {
            "لم يتم تسجيل نسخة احتياطية لقاعدة البيانات منذ أكثر من $BACKUP_THRESHOLD_DAYS أيام."
        }
        val bigText = """
            $shortText
            حفاظاً على بيانات الأسر وسجلات التوزيع من الفقدان، يُوصى بأخذ نسخة احتياطية محلية أو سحابية الآن.
        """.trimIndent()

        if (sendProactiveNotification(
                notificationId = NOTIFICATION_ID_OVERDUE_BACKUP,
                title = title,
                shortText = shortText,
                bigText = bigText,
                navigateTarget = "backup",
                actionLabel = "أخذ نسخة احتياطية"
            )
        ) {
            markAlertSent(prefs, KEY_LAST_ALERT_BACKUP_OVERDUE, nowMillis)
        }
    }

    /**
     * الفحص الثالث: عدّ الأسر المعتمدة أو المقيمة التي تجاوزت 90 يوماً بدون استلام أي معونة عبر SELECT COUNT(*)
     */
    private fun checkUnservedFamiliesOver90Days(
        db: SupportSQLiteDatabase,
        prefs: SharedPreferences,
        nowMillis: Long
    ) {
        if (!canSendAlert(prefs, KEY_LAST_ALERT_UNSERVED_FAMILIES, nowMillis)) return

        val unservedCount = countUnservedFamiliesOver90Days(db, nowMillis)
        if (unservedCount <= 0) return

        val title = "📌 أسر معتمدة/مقيمة بلا معونة منذ أكثر من 90 يوماً ($unservedCount)"
        val shortText = "توجد $unservedCount أسرة معتمدة أو مقيمة تجاوزت $UNSERVED_THRESHOLD_DAYS يوماً دون استلام أي مساعدة."
        val bigText = """
            رصد النظام وجود $unservedCount أسرة معتمدة أو مقيمة تجاوزت $UNSERVED_THRESHOLD_DAYS يوماً بدون تسجيل أي استلام معونة.
            يُرجى فحص رادار الأسر المنسية وإدراجها ضمن أولويات الترشيح القادمة لتحقيق العدالة الإغاثية.
        """.trimIndent()

        if (sendProactiveNotification(
                notificationId = NOTIFICATION_ID_UNSERVED_FAMILIES,
                title = title,
                shortText = shortText,
                bigText = bigText,
                navigateTarget = "nomination",
                actionLabel = "فتح الترشيح الذكي"
            )
        ) {
            markAlertSent(prefs, KEY_LAST_ALERT_UNSERVED_FAMILIES, nowMillis)
        }
    }

    /**
     * استعلام SQL خفيف (COUNT) لعدّ الشكاوى المفتوحة التي مرّ عليها أكثر من 7 أيام دون تحميل أي صفوف في الذاكرة
     */
    private fun countOverdueOpenComplaints(
        db: SupportSQLiteDatabase,
        nowMillis: Long
    ): Int {
        val tableName = findTableName(db) { name ->
            val lower = name.lowercase(Locale.US)
            lower.contains("complaint")
        } ?: return 0

        val columns = getTableColumns(db, tableName)
        val statusCol = findColumn(columns, "status", "complaintstatus", "complaint_status") ?: return 0
        val dateCol = findColumn(
            columns,
            "createdat",
            "created_at",
            "createddate",
            "created_date",
            "complaintdate",
            "complaint_date",
            "timestamp"
        ) ?: return 0

        val cutoffMillis = nowMillis - TimeUnit.DAYS.toMillis(COMPLAINTS_THRESHOLD_DAYS.toLong())
        val cutoffDateStr = formatIsoDate(cutoffMillis)

        val sql = """
            SELECT COUNT(*) FROM ${quoteIdent(tableName)}
            WHERE UPPER(TRIM(COALESCE(${quoteIdent(statusCol)}, ''))) IN ('OPEN', 'مفتوحة', 'مفتوح')
              AND (
                (typeof(${quoteIdent(dateCol)}) IN ('integer', 'real')
                 AND ${quoteIdent(dateCol)} > 0
                 AND (CASE WHEN ${quoteIdent(dateCol)} < 100000000000 THEN ${quoteIdent(dateCol)} * 1000 ELSE ${quoteIdent(dateCol)} END) < ?)
                OR
                (typeof(${quoteIdent(dateCol)}) = 'text'
                 AND length(trim(${quoteIdent(dateCol)})) >= 8
                 AND substr(replace(trim(${quoteIdent(dateCol)}), '/', '-'), 1, 10) < ?)
              )
        """.trimIndent()

        return querySingleCount(db, sql, arrayOf(cutoffMillis, cutoffDateStr))
    }

    /**
     * استعلام SQL خفيف (COUNT + NOT EXISTS) لعدّ الأسر المعتمدة أو المقيمة التي تجاوزت 90 يوماً بلا استلام معونة
     */
    private fun countUnservedFamiliesOver90Days(
        db: SupportSQLiteDatabase,
        nowMillis: Long
    ): Int {
        val familiesTable = findTableName(db) { name ->
            val lower = name.lowercase(Locale.US)
            lower == "families" || (lower.contains("famil") && !lower.contains("complaint") && !lower.contains("child"))
        } ?: return 0

        val aidTable = findTableName(db) { name ->
            val lower = name.lowercase(Locale.US)
            lower == "aid_records" || lower == "aidrecords" || (lower.contains("aid") && lower.contains("record"))
        } ?: return 0

        val familyCols = getTableColumns(db, familiesTable)
        val aidCols = getTableColumns(db, aidTable)

        val familyPkCol = findColumn(familyCols, "familyid", "family_id", "id") ?: return 0
        val aidFamilyFkCol = findColumn(aidCols, "familyid", "family_id") ?: return 0

        val devApprovalCol = findColumn(familyCols, "developmentapproval", "development_approval")
        val locApprovalCol = findColumn(familyCols, "localityapproval", "locality_approval")
        val worksApprovalCol = findColumn(familyCols, "worksapproval", "works_approval")
        val residentCol = findColumn(familyCols, "residentstatus", "resident_status")

        val eligibilityClauses = mutableListOf<String>()
        if (devApprovalCol != null) {
            val c = quoteIdent(devApprovalCol)
            eligibilityClauses.add("(COALESCE(f.$c, '') LIKE '%معتمد%' AND COALESCE(f.$c, '') NOT LIKE '%غير%')")
        }
        if (locApprovalCol != null) {
            val c = quoteIdent(locApprovalCol)
            eligibilityClauses.add("(COALESCE(f.$c, '') LIKE '%معتمد%' AND COALESCE(f.$c, '') NOT LIKE '%غير%')")
        }
        if (worksApprovalCol != null) {
            val c = quoteIdent(worksApprovalCol)
            eligibilityClauses.add("(COALESCE(f.$c, '') LIKE '%معتمد%' AND COALESCE(f.$c, '') NOT LIKE '%غير%')")
        }
        if (residentCol != null) {
            val c = quoteIdent(residentCol)
            eligibilityClauses.add("(COALESCE(f.$c, '') LIKE '%مقيم%' AND COALESCE(f.$c, '') NOT LIKE '%غير%')")
        }

        val familyWhereClause = if (eligibilityClauses.isNotEmpty()) {
            eligibilityClauses.joinToString(" OR ")
        } else {
            "1 = 1"
        }

        val deliveryDateCol = findColumn(aidCols, "deliverydate", "delivery_date")
        val aidDateCol = findColumn(aidCols, "aiddate", "aid_date")
        val selectionDateCol = findColumn(aidCols, "selectiondate", "selection_date")
        val recipientStatusCol = findColumn(aidCols, "recipientstatus", "recipient_status", "status")

        val dateCandidates = listOfNotNull(deliveryDateCol, aidDateCol, selectionDateCol)
        if (dateCandidates.isEmpty()) return 0

        val dateExpr = if (dateCandidates.size == 1) {
            "COALESCE(a.${quoteIdent(dateCandidates.first())}, '')"
        } else {
            val coalesceArgs = dateCandidates.joinToString(", ") { col ->
                "NULLIF(TRIM(COALESCE(a.${quoteIdent(col)}, '')), '')"
            }
            "COALESCE($coalesceArgs, '')"
        }

        val deliveredCondition = buildList {
            if (recipientStatusCol != null) {
                val sc = quoteIdent(recipientStatusCol)
                add("COALESCE(a.$sc, '') LIKE '%مستلم%'")
                add("COALESCE(a.$sc, '') LIKE '%مستفيد%'")
                add("COALESCE(a.$sc, '') LIKE '%تم التسليم%'")
            }
            if (deliveryDateCol != null) {
                val dc = quoteIdent(deliveryDateCol)
                add("TRIM(COALESCE(a.$dc, '')) != ''")
            }
        }.let { clauses ->
            if (clauses.isEmpty()) "1 = 1" else "(${clauses.joinToString(" OR ")})"
        }

        val cutoffMillis = nowMillis - TimeUnit.DAYS.toMillis(UNSERVED_THRESHOLD_DAYS.toLong())
        val cutoffDateStr = formatIsoDate(cutoffMillis)

        val sql = """
            SELECT COUNT(*)
            FROM ${quoteIdent(familiesTable)} f
            WHERE ($familyWhereClause)
              AND NOT EXISTS (
                SELECT 1
                FROM ${quoteIdent(aidTable)} a
                WHERE a.${quoteIdent(aidFamilyFkCol)} = f.${quoteIdent(familyPkCol)}
                  AND $deliveredCondition
                  AND length(trim($dateExpr)) >= 8
                  AND substr(replace(trim($dateExpr), '/', '-'), 1, 10) >= ?
              )
        """.trimIndent()

        return querySingleCount(db, sql, arrayOf(cutoffDateStr))
    }

    /**
     * البحث الخفيف عن تاريخ آخر نسخة احتياطية من SharedPreferences أو ملفات النسخ المحلية
     */
    private fun resolveLastBackupTimestampMillis(
        appContext: Context,
        db: SupportSQLiteDatabase,
        alertPrefs: SharedPreferences
    ): Long {
        var latestMillis = alertPrefs.getLong(KEY_LAST_BACKUP_TIMESTAMP, 0L)

        // فحص ملفات SharedPreferences الشائعة لحفظ تاريخ آخر نسخة احتياطية
        val candidatePrefsNames = listOf(
            "backup_prefs",
            "aid_backup_prefs",
            "cloud_backup_prefs",
            "sync_prefs",
            "aid_sync_prefs",
            "app_settings",
            "${appContext.packageName}_preferences"
        )
        for (prefsName in candidatePrefsNames) {
            val sp = appContext.getSharedPreferences(prefsName, Context.MODE_PRIVATE)
            val allEntries = sp.all
            for ((key, value) in allEntries) {
                val lowerKey = key.lowercase(Locale.US)
                if (!lowerKey.contains("backup") && !lowerKey.contains("نسخ")) continue
                val parsed = extractTimestampFromPrefValue(value)
                if (parsed > latestMillis) {
                    latestMillis = parsed
                }
            }
        }

        // فحص مجلدات النسخ الاحتياطي المحلية دون قراءة محتوى الملفات (lastModified فقط)
        val candidateDirs = listOfNotNull(
            File(appContext.filesDir, "backups"),
            File(appContext.filesDir, "backup"),
            appContext.getExternalFilesDir("backups"),
            appContext.getExternalFilesDir("backup"),
            appContext.getExternalFilesDir(null)
        )
        for (dir in candidateDirs) {
            if (!dir.exists() || !dir.isDirectory) continue
            val files = dir.listFiles() ?: continue
            for (file in files) {
                if (!file.isFile) continue
                val lowerName = file.name.lowercase(Locale.US)
                val looksLikeBackup = lowerName.contains("backup") ||
                    lowerName.endsWith(".db") ||
                    lowerName.endsWith(".bak") ||
                    lowerName.endsWith(".zip") ||
                    lowerName.endsWith(".sqlite")
                if (looksLikeBackup && file.lastModified() > latestMillis) {
                    latestMillis = file.lastModified()
                }
            }
        }

        // فحص جدول سجل النسخ الاحتياطي إن وُجد في قاعدة البيانات عبر MAX فقط
        val backupTable = findTableName(db) { name ->
            name.lowercase(Locale.US).contains("backup")
        }
        if (backupTable != null) {
            val cols = getTableColumns(db, backupTable)
            val tsCol = findColumn(cols, "timestamp", "createdat", "created_at", "backupdate", "backup_date", "date")
            if (tsCol != null) {
                val dbLatest = queryMaxTimestampMillis(db, backupTable, tsCol)
                if (dbLatest > latestMillis) {
                    latestMillis = dbLatest
                }
            }
        }

        return latestMillis
    }

    private fun resolveInstallOrFirstRunBaselineMillis(
        appContext: Context,
        prefs: SharedPreferences,
        nowMillis: Long
    ): Long {
        val stored = prefs.getLong(KEY_BACKUP_BASELINE_TIMESTAMP, 0L)
        if (stored > 0L) return stored

        val installTime = runCatching {
            appContext.packageManager.getPackageInfo(appContext.packageName, 0).firstInstallTime
        }.getOrDefault(nowMillis)
        val baseline = if (installTime > 0L) installTime else nowMillis
        prefs.edit().putLong(KEY_BACKUP_BASELINE_TIMESTAMP, baseline).apply()
        return baseline
    }

    private fun extractTimestampFromPrefValue(value: Any?): Long {
        return when (value) {
            is Long -> normalizeEpochMillis(value)
            is Int -> normalizeEpochMillis(value.toLong())
            is String -> parseDateStringToMillis(value)
            else -> 0L
        }
    }

    private fun normalizeEpochMillis(raw: Long): Long {
        if (raw <= 0L) return 0L
        return if (raw < 100_000_000_000L) raw * 1000L else raw
    }

    private fun parseDateStringToMillis(raw: String): Long {
        val clean = raw.trim()
        if (clean.isEmpty()) return 0L
        clean.toLongOrNull()?.let { return normalizeEpochMillis(it) }

        val normalized = clean.replace('/', '-').take(19)
        val patterns = listOf(
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd'T'HH:mm:ss",
            "yyyy-MM-dd HH:mm",
            "yyyy-MM-dd"
        )
        for (pattern in patterns) {
            val parsed = runCatching {
                SimpleDateFormat(pattern, Locale.US).apply { isLenient = false }.parse(normalized)?.time
            }.getOrNull()
            if (parsed != null && parsed > 0L) return parsed
        }
        return 0L
    }

    private fun queryMaxTimestampMillis(
        db: SupportSQLiteDatabase,
        tableName: String,
        colName: String
    ): Long {
        return runCatching {
            db.query("SELECT MAX(${quoteIdent(colName)}) FROM ${quoteIdent(tableName)}").use { cursor ->
                if (cursor.moveToFirst() && !cursor.isNull(0)) {
                    val rawStr = cursor.getString(0)
                    if (rawStr != null) parseDateStringToMillis(rawStr) else 0L
                } else {
                    0L
                }
            }
        }.getOrDefault(0L)
    }

    private fun findTableName(
        db: SupportSQLiteDatabase,
        matcher: (String) -> Boolean
    ): String? {
        return runCatching {
            var found: String? = null
            db.query("SELECT name FROM sqlite_master WHERE type = 'table'").use { cursor ->
                while (cursor.moveToNext()) {
                    val name = cursor.getString(0) ?: continue
                    if (isSafeIdentifier(name) && matcher(name)) {
                        found = name
                        break
                    }
                }
            }
            found
        }.getOrNull()
    }

    private fun getTableColumns(
        db: SupportSQLiteDatabase,
        tableName: String
    ): List<String> {
        return runCatching {
            val cols = mutableListOf<String>()
            db.query("PRAGMA table_info(${quoteIdent(tableName)})").use { cursor ->
                val nameIndex = cursor.getColumnIndex("name")
                if (nameIndex >= 0) {
                    while (cursor.moveToNext()) {
                        val col = cursor.getString(nameIndex) ?: continue
                        if (isSafeIdentifier(col)) cols.add(col)
                    }
                }
            }
            cols
        }.getOrDefault(emptyList())
    }

    private fun findColumn(columns: List<String>, vararg normalizedCandidates: String): String? {
        val normalizedMap = columns.associateBy { it.lowercase(Locale.US) }
        for (candidate in normalizedCandidates) {
            normalizedMap[candidate.lowercase(Locale.US)]?.let { return it }
        }
        return null
    }

    private fun querySingleCount(
        db: SupportSQLiteDatabase,
        sql: String,
        bindArgs: Array<Any>
    ): Int {
        return runCatching {
            db.query(sql, bindArgs).use { cursor ->
                if (cursor.moveToFirst()) cursor.getInt(0) else 0
            }
        }.getOrDefault(0)
    }

    private fun isSafeIdentifier(name: String): Boolean =
        name.isNotEmpty() && name.all { it.isLetterOrDigit() || it == '_' }

    private fun quoteIdent(name: String): String = "\"$name\""

    private fun formatIsoDate(epochMillis: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = epochMillis }
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }

    private fun canSendAlert(
        prefs: SharedPreferences,
        key: String,
        nowMillis: Long
    ): Boolean {
        val lastSent = prefs.getLong(key, 0L)
        return lastSent <= 0L || (nowMillis - lastSent) >= ALERT_COOLDOWN_MILLIS
    }

    private fun markAlertSent(
        prefs: SharedPreferences,
        key: String,
        nowMillis: Long
    ) {
        prefs.edit().putLong(key, nowMillis).apply()
    }

    private fun sendProactiveNotification(
        notificationId: Int,
        title: String,
        shortText: String,
        bigText: String,
        navigateTarget: String,
        actionLabel: String
    ): Boolean {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_NAVIGATE_TO", navigateTarget)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(
            context,
            AidNotificationChannels.CHANNEL_URGENT_ALERTS
        )
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(shortText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_menu_view,
                actionLabel,
                pendingIntent
            )
            .build()

        return try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
            true
        } catch (_: SecurityException) {
            false
        }
    }

    companion object {
        private const val ALERT_PREFS_NAME = "proactive_aid_alerts_prefs"
        private const val KEY_LAST_ALERT_OPEN_COMPLAINTS = "last_alert_open_complaints_7d"
        private const val KEY_LAST_ALERT_BACKUP_OVERDUE = "last_alert_backup_overdue_3d"
        private const val KEY_LAST_ALERT_UNSERVED_FAMILIES = "last_alert_unserved_families_90d"
        private const val KEY_LAST_BACKUP_TIMESTAMP = "last_backup_timestamp_millis"
        private const val KEY_BACKUP_BASELINE_TIMESTAMP = "backup_baseline_timestamp_millis"

        private const val COMPLAINTS_THRESHOLD_DAYS = 7
        private const val BACKUP_THRESHOLD_DAYS = 3
        private const val UNSERVED_THRESHOLD_DAYS = 90

        private val ALERT_COOLDOWN_MILLIS = TimeUnit.HOURS.toMillis(24)
        private val BACKUP_THRESHOLD_MILLIS = TimeUnit.DAYS.toMillis(BACKUP_THRESHOLD_DAYS.toLong())

        private const val NOTIFICATION_ID_OVERDUE_COMPLAINTS = 3001
        private const val NOTIFICATION_ID_OVERDUE_BACKUP = 3002
        private const val NOTIFICATION_ID_UNSERVED_FAMILIES = 3003

        /**
         * دالة مساعدة لتسجيل وقت إتمام النسخة الاحتياطية بنجاح لإعادة ضبط عدّاد تنبيه الـ 3 أيام
         */
        fun recordBackupCompleted(
            context: Context,
            timestampMillis: Long = System.currentTimeMillis()
        ) {
            context.applicationContext
                .getSharedPreferences(ALERT_PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putLong(KEY_LAST_BACKUP_TIMESTAMP, timestampMillis)
                .apply()
        }
    }
}
