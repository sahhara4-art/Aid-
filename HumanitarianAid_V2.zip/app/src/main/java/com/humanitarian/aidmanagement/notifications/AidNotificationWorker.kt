package com.humanitarian.aidmanagement.notifications

import android.content.Context

class AidNotificationWorker(
    private val context: Context
) {
    fun doWork(): Boolean {
        val helper = AidNotificationHelper(context)
        helper.showNominationAlert(
            "تحديث نظام المساعدات",
            "تم التحقق من بيانات الأسر والمساعدات بنجاح في الخلفية."
        )
        return true
    }
}
