package com.humanitarian.aidmanagement.sync

import android.content.Context
import android.util.Log
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * FirebaseSyncManager - غلاف توافقي خفيف (Lightweight Compatibility Wrapper)
 *
 * تم توحيد مسار المزامنة السحابية بالكامل عبر FirestoreSyncManager (المزامنة التفاضلية المجزأة بسقف 40MB)
 * وإلغاء إنشاء مثيل مكرر لـ Firebase Realtime Database أو فتح مستمعات ValueEventListener في الخلفية
 * لمنع استنزاف الذاكرة العشوائية (OutOfMemoryError) على الأجهزة المتوسطة.
 */
class FirebaseSyncManager private constructor(private val context: Context) {

    private val firestoreSyncManager: FirestoreSyncManager
        get() = FirestoreSyncManager.getInstance(context)

    val isConnected: StateFlow<Boolean>
        get() = firestoreSyncManager.isConnected

    private val _recentUploadedDeltas = MutableStateFlow<List<SyncDelta>>(emptyList())
    val recentUploadedDeltas: StateFlow<List<SyncDelta>> = _recentUploadedDeltas.asStateFlow()

    val totalUploadedCount: StateFlow<Int>
        get() = firestoreSyncManager.totalUploadedCount

    private val _customDatabaseUrl = MutableStateFlow<String?>(null)
    val customDatabaseUrl: StateFlow<String?> = _customDatabaseUrl.asStateFlow()

    val deviceId: String
        get() = firestoreSyncManager.deviceId

    companion object {
        private const val TAG = "FirebaseSyncManager"
        const val ROOT_NODE = "humanitarian_aid_sync"
        const val DELTAS_NODE = "deltas"
        const val NODES_STATUS = "mandoob_heartbeats"

        @Volatile
        private var INSTANCE: FirebaseSyncManager? = null

        fun getInstance(context: Context): FirebaseSyncManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: FirebaseSyncManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    internal fun getUnifiedFirestoreSyncManager(): FirestoreSyncManager = firestoreSyncManager

    /**
     * توجيه التهيئة مباشرة إلى FirestoreSyncManager الموحّد دون فتح اتصال Realtime Database مكرر
     */
    fun initialize(customUrl: String? = null) {
        _customDatabaseUrl.value = customUrl
        firestoreSyncManager.initialize()
        Log.i(TAG, "FirebaseSyncManager delegated initialization to unified FirestoreSyncManager.")
    }

    /**
     * معطّل عمداً بعد توحيد المزامنة عبر Cloud Firestore لمنع ازدواجية الذاكرة والكاش المحلي
     */
    fun getDatabaseInstance(): FirebaseDatabase? = null

    /**
     * تحويل حركة SyncDelta وتمريرها عبر المسار الموحّد FirestoreSyncManager.pushDelta
     */
    suspend fun pushDelta(delta: SyncDelta): Boolean = withContext(Dispatchers.IO) {
        val unifiedDelta = FirestoreSyncDelta(
            deltaId = delta.deltaId,
            localityId = delta.localityId,
            localityName = delta.localityName,
            userId = delta.userId,
            userName = delta.userName,
            entityType = delta.entityType,
            operation = delta.operation,
            recordId = delta.recordId,
            payloadJson = delta.payloadJson,
            clientTimestamp = delta.timestamp,
            deviceId = delta.deviceId.ifBlank { deviceId }
        )

        val uploaded = firestoreSyncManager.pushDelta(unifiedDelta)
        if (uploaded) {
            val currentList = _recentUploadedDeltas.value.toMutableList()
            currentList.add(0, delta)
            if (currentList.size > 30) currentList.removeAt(currentList.lastIndex)
            _recentUploadedDeltas.value = currentList
        }
        uploaded
    }

    /**
     * دالة توافقية خفيفة لا تحتفظ بمراجع إضافية في الذاكرة
     */
    suspend fun removeDelta(localityId: Int, deltaId: String): Boolean = withContext(Dispatchers.IO) {
        Log.d(TAG, "removeDelta($localityId, $deltaId) skipped: managed by unified Firestore Delta Sync.")
        true
    }
}
