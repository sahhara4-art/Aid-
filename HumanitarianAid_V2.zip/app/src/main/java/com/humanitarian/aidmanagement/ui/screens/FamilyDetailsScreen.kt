package com.humanitarian.aidmanagement.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.Child
import com.humanitarian.aidmanagement.data.local.entities.Family
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamilyDetailsScreen(
    familyId: Int,
    repository: AidRepository,
    isSuperAdmin: Boolean,
    allowedLocalityIds: List<Int>,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dateFormatter = remember { SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH) }

    var family by remember { mutableStateOf<Family?>(null) }
    var showAddChildDialog by remember { mutableStateOf(false) }

    LaunchedEffect(familyId) {
        family = repository.getFamilyById(familyId)
    }

    val children by repository.getChildrenByFamily(familyId).collectAsState(initial = emptyList())
    val aidHistory by repository.getFamilyAidHistory(familyId).collectAsState(initial = emptyList())
    val aidTypes by repository.getAidTypes().collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(family?.name ?: "تفاصيل الأسرة", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        if (family == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            val f = family!!
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color(0xFFF8FAFC))
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Family Primary Details Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("البيانات الأساسية لرب الأسرة", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2), fontSize = 16.sp)
                            Spacer(Modifier.height(12.dp))

                            InfoRow("الاسم الكامل:", f.name)
                            InfoRow("رقم الهوية الوطنية:", f.nationalID)
                            InfoRow("الجنس والحالة الاجتماعية:", "${f.gender} - ${f.maritalStatus}")
                            InfoRow("عدد أفراد الأسرة:", "${f.familyMembersCount} أفراد")
                            InfoRow("اسم الزوجة:", f.wifeName ?: "غير مسجل")
                            InfoRow("رقم هوية الزوجة:", f.wifeNationalID ?: "غير مسجل")
                            InfoRow("حالة الإقامة والإيواء:", "${f.residentStatus} - ${f.shelterStatus}")
                            InfoRow("حالة الأضرار:", f.damageType)
                            InfoRow("اعتماد التنمية الاجتماعية:", f.developmentApproval)
                            InfoRow("اعتماد وزارة الأشغال:", f.workApproval)
                            if (!f.notes.isNullOrBlank()) {
                                InfoRow("ملاحظات:", f.notes ?: "")
                            }
                        }
                    }
                }

                // Children Section ("أبناء الأسرة")
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ChildCare, contentDescription = null, tint = Color(0xFF2E7D32))
                                    Spacer(Modifier.width(8.dp))
                                    Text("أبناء الأسرة (${children.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                                Button(
                                    onClick = { showAddChildDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("إضافة ابن", fontSize = 12.sp)
                                }
                            }

                            Spacer(Modifier.height(12.dp))

                            if (children.isEmpty()) {
                                Text("لا يوجد أبناء مسجلين لهذه الأسرة حتى الآن.", color = Color(0xFF64748B), fontSize = 13.sp)
                            } else {
                                children.forEach { child ->
                                    // Automatic age calculation from birthdate
                                    val ageInYears = calculateAgeInYears(child.birthDate)
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(child.childName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Text("هوية: ${child.childNationalID} | الجنس: ${child.gender}", fontSize = 12.sp, color = Color(0xFF64748B))
                                            Text("العمر المحسوب: $ageInYears سنة (تاريخ الميلاد: ${dateFormatter.format(Date(child.birthDate))})", fontSize = 11.sp, color = Color(0xFF1976D2))
                                        }
                                        IconButton(
                                            onClick = {
                                                scope.launch {
                                                    val res = repository.deleteChild(child)
                                                    if (res.isSuccess) {
                                                        Toast.makeText(context, "تم حذف الابن", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            }
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
                                        }
                                    }
                                    HorizontalDivider(color = Color(0xFFF1F5F9))
                                }
                            }
                        }
                    }
                }

                // Aid History Section
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.History, contentDescription = null, tint = Color(0xFF1976D2))
                                Spacer(Modifier.width(8.dp))
                                Text("سجل المساعدات المستلمة (${aidHistory.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }

                            Spacer(Modifier.height(12.dp))

                            if (aidHistory.isEmpty()) {
                                Text("لم تستلم الأسرة أي مساعدات مسجلة حتى الآن.", color = Color(0xFF64748B), fontSize = 13.sp)
                            } else {
                                aidHistory.forEach { rec ->
                                    val typeName = aidTypes.find { it.aidTypeID == rec.aidTypeID }?.aidTypeName ?: "نوع ${rec.aidTypeID}"
                                    Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(typeName, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A), fontSize = 13.sp)
                                            Text(dateFormatter.format(Date(rec.aidDate)), fontSize = 12.sp, color = Color(0xFF64748B))
                                        }
                                        Text(rec.detailedDescription ?: "لا يوجد وصف إضافي", fontSize = 12.sp, color = Color(0xFF475569))
                                    }
                                    HorizontalDivider(color = Color(0xFFF1F5F9))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Child Dialog with unique National ID validation
    if (showAddChildDialog && family != null) {
        var childName by remember { mutableStateOf("") }
        var childIdNum by remember { mutableStateOf("") }
        var childGender by remember { mutableStateOf("ذكر") }
        var birthYear by remember { mutableStateOf("2018") }

        AlertDialog(
            onDismissRequest = { showAddChildDialog = false },
            title = { Text("إضافة ابن للأسرة", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = childName,
                        onValueChange = { childName = it },
                        label = { Text("اسم الابن رباعي") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = childIdNum,
                        onValueChange = { childIdNum = it },
                        label = { Text("رقم هوية الابن (يجب ألا يتكرر)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = birthYear,
                        onValueChange = { birthYear = it },
                        label = { Text("سنة الميلاد (مثال: 2018)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (childName.isBlank() || childIdNum.isBlank()) return@Button
                        val year = birthYear.toIntOrNull() ?: 2020
                        val cal = Calendar.getInstance()
                        cal.set(year, Calendar.JANUARY, 1)

                        val child = Child(
                            familyID = familyId,
                            childNationalID = childIdNum.trim(),
                            childName = childName.trim(),
                            birthDate = cal.timeInMillis,
                            gender = childGender,
                            localityID = family!!.localityID
                        )

                        scope.launch {
                            val res = repository.addChild(child)
                            res.onSuccess {
                                Toast.makeText(context, "تمت إضافة الابن بنجاح", Toast.LENGTH_SHORT).show()
                                showAddChildDialog = false
                            }.onFailure { ex ->
                                Toast.makeText(context, ex.message ?: "خطأ في إضافة الابن", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddChildDialog = false }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color(0xFF64748B), fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.SemiBold, color = Color(0xFF0F172A), fontSize = 13.sp)
    }
}

fun calculateAgeInYears(birthDateMillis: Long): Int {
    val birth = Calendar.getInstance().apply { timeInMillis = birthDateMillis }
    val now = Calendar.getInstance()
    var age = now.get(Calendar.YEAR) - birth.get(Calendar.YEAR)
    if (now.get(Calendar.DAY_OF_YEAR) < birth.get(Calendar.DAY_OF_YEAR)) {
        age--
    }
    return age.coerceAtLeast(0)
}
