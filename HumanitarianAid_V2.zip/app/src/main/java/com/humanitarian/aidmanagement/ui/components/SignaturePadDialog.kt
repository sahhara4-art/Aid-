package com.humanitarian.aidmanagement.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.graphics.Path as AndroidPath
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

private val SigEmerald = Color(0xFF0F7B53)
private val SigAmber = Color(0xFFD97706)
private val SigSlateDark = Color(0xFF0F172A)
private val SigSlateMuted = Color(0xFF64748B)
private val SigSurfaceBg = Color(0xFFF4F9F6)
private val SigBorder = Color(0xFFD0E3D9)

/**
 * مساعد تخزين واسترجاع صور التوقيع الإلكتروني كملفات PNG مضغوطة (320x130 - أقل من 15KB)
 * خارج قاعدة البيانات لمنع تضخم Room وحماية الذاكرة عبر استدعاء bitmap.recycle() في finally.
 */
object SignatureStorageHelper {

    private const val TARGET_WIDTH = 320
    private const val TARGET_HEIGHT = 130
    private const val SIGNATURES_DIR_NAME = "signatures"

    fun saveSignaturePng(
        context: Context,
        projectId: String,
        nationalId: String,
        strokes: List<List<Offset>>,
        canvasWidth: Float,
        canvasHeight: Float
    ): String {
        val dir = File(context.filesDir, SIGNATURES_DIR_NAME).apply {
            if (!exists()) mkdirs()
        }
        val fileName = buildSignatureFileName(projectId, nationalId)
        val outFile = File(dir, fileName)

        val safeWidth = if (canvasWidth > 1f) canvasWidth else TARGET_WIDTH.toFloat()
        val safeHeight = if (canvasHeight > 1f) canvasHeight else TARGET_HEIGHT.toFloat()
        val scaleX = TARGET_WIDTH.toFloat() / safeWidth
        val scaleY = TARGET_HEIGHT.toFloat() / safeHeight

        val bitmap = Bitmap.createBitmap(TARGET_WIDTH, TARGET_HEIGHT, Bitmap.Config.ARGB_8888)
        try {
            val canvas = AndroidCanvas(bitmap)
            canvas.drawColor(AndroidColor.WHITE)

            val strokePaint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
                color = AndroidColor.BLACK
                style = AndroidPaint.Style.STROKE
                strokeWidth = 3.2f
                strokeCap = AndroidPaint.Cap.ROUND
                strokeJoin = AndroidPaint.Join.ROUND
            }
            val dotPaint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG).apply {
                color = AndroidColor.BLACK
                style = AndroidPaint.Style.FILL
            }

            for (stroke in strokes) {
                if (stroke.isEmpty()) continue
                if (stroke.size == 1) {
                    val p = stroke[0]
                    canvas.drawCircle(p.x * scaleX, p.y * scaleY, 1.8f, dotPaint)
                } else {
                    val path = AndroidPath()
                    val first = stroke[0]
                    path.moveTo(first.x * scaleX, first.y * scaleY)
                    for (i in 1 until stroke.size) {
                        val pt = stroke[i]
                        path.lineTo(pt.x * scaleX, pt.y * scaleY)
                    }
                    canvas.drawPath(path, strokePaint)
                }
            }

            FileOutputStream(outFile).use { fos ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, fos)
                fos.flush()
            }
        } finally {
            if (!bitmap.isRecycled) {
                bitmap.recycle()
            }
        }

        return outFile.absolutePath
    }

    fun getSignatureFile(
        context: Context,
        projectId: String,
        nationalId: String
    ): File? {
        val file = File(File(context.filesDir, SIGNATURES_DIR_NAME), buildSignatureFileName(projectId, nationalId))
        return if (file.exists() && file.length() > 0L) file else null
    }

    private fun buildSignatureFileName(projectId: String, nationalId: String): String {
        val cleanProject = sanitizeFilePart(projectId).ifBlank { "project" }
        val cleanNatId = sanitizeFilePart(nationalId).ifBlank { "unknown" }
        return "${cleanProject}_${cleanNatId}.png"
    }

    private fun sanitizeFilePart(raw: String): String {
        val trimmed = raw.trim()
        val sb = StringBuilder(trimmed.length)
        for (ch in trimmed) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                in '0'..'9', in 'a'..'z', in 'A'..'Z', '_', '-' -> sb.append(ch)
            }
        }
        return sb.toString()
    }
}

/**
 * نافذة التوقيع الإلكتروني باللمس لتأكيد استلام المساعدة (RTL - Material 3 بدون استخدام Icons).
 */
@Composable
fun SignaturePadDialog(
    context: Context,
    projectId: String,
    nationalId: String,
    beneficiaryName: String,
    onSignatureSaved: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val completedStrokes = remember { mutableStateListOf<List<Offset>>() }
    val activeStroke = remember { mutableStateListOf<Offset>() }

    var canvasWidth by remember { mutableFloatStateOf(0f) }
    var canvasHeight by remember { mutableFloatStateOf(0f) }
    var isSaving by remember { mutableStateOf(false) }

    val hasSignature = completedStrokes.isNotEmpty() || activeStroke.isNotEmpty()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = { if (!isSaving) onDismiss() },
            properties = DialogProperties(usePlatformDefaultWidth = false),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 12.dp),
            title = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "التوقيع الإلكتروني لتأكيد الاستلام",
                        color = SigSlateDark,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "يُرجى الطلب من المستفيد التوقيع بإصبعه داخل الإطار الأبيض أدناه.",
                        color = SigSlateMuted,
                        fontSize = 12.sp
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // بطاقة بيانات المستفيد
                    Surface(
                        color = SigSurfaceBg,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SigBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "المستفيد: ${beneficiaryName.trim().ifBlank { "غير محدد" }}",
                                color = SigSlateDark,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "رقم الهوية: ${nationalId.trim().ifBlank { "-" }}  •  المشروع: #${projectId.trim().ifBlank { "-" }}",
                                color = SigSlateMuted,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // لوحة التوقيع البيضاء التفاعلية باللمس
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White)
                            .border(
                                width = 1.8.dp,
                                color = if (hasSignature) SigEmerald else SigBorder,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .onSizeChanged { size ->
                                canvasWidth = size.width.toFloat()
                                canvasHeight = size.height.toFloat()
                            }
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { startOffset ->
                                        val clamped = Offset(
                                            x = startOffset.x.coerceIn(0f, size.width.toFloat()),
                                            y = startOffset.y.coerceIn(0f, size.height.toFloat())
                                        )
                                        activeStroke.clear()
                                        activeStroke.add(clamped)
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        val pos = change.position
                                        val clamped = Offset(
                                            x = pos.x.coerceIn(0f, size.width.toFloat()),
                                            y = pos.y.coerceIn(0f, size.height.toFloat())
                                        )
                                        activeStroke.add(clamped)
                                    },
                                    onDragEnd = {
                                        if (activeStroke.isNotEmpty()) {
                                            completedStrokes.add(activeStroke.toList())
                                            activeStroke.clear()
                                        }
                                    },
                                    onDragCancel = {
                                        if (activeStroke.isNotEmpty()) {
                                            completedStrokes.add(activeStroke.toList())
                                            activeStroke.clear()
                                        }
                                    }
                                )
                            }
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // خط إرشادي خفيف لسطر التوقيع
                            val baselineY = size.height * 0.78f
                            drawLine(
                                color = Color(0xFFE2E8F0),
                                start = Offset(24f, baselineY),
                                end = Offset(size.width - 24f, baselineY),
                                strokeWidth = 2f
                            )

                            val strokeStyle = Stroke(
                                width = 5f,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )

                            fun drawStrokePoints(points: List<Offset>) {
                                if (points.isEmpty()) return
                                if (points.size == 1) {
                                    drawCircle(
                                        color = Color.Black,
                                        radius = 2.8f,
                                        center = points[0]
                                    )
                                } else {
                                    val path = Path().apply {
                                        moveTo(points[0].x, points[0].y)
                                        for (i in 1 until points.size) {
                                            lineTo(points[i].x, points[i].y)
                                        }
                                    }
                                    drawPath(
                                        path = path,
                                        color = Color.Black,
                                        style = strokeStyle
                                    )
                                }
                            }

                            completedStrokes.forEach { stroke ->
                                drawStrokePoints(stroke)
                            }
                            if (activeStroke.isNotEmpty()) {
                                drawStrokePoints(activeStroke)
                            }
                        }

                        if (!hasSignature) {
                            Text(
                                text = "وقّع هنا بإصبعك",
                                color = SigSlateMuted.copy(alpha = 0.55f),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }
                    }

                    // أزرار التحكم (مسح وإعادة + إلغاء + اعتماد التوقيع وتأكيد التسليم)
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (isSaving) return@Button
                                val snapshotStrokes = buildList {
                                    addAll(completedStrokes)
                                    if (activeStroke.isNotEmpty()) {
                                        add(activeStroke.toList())
                                    }
                                }
                                if (snapshotStrokes.isEmpty()) return@Button

                                scope.launch {
                                    isSaving = true
                                    val savedResult = runCatching {
                                        withContext(Dispatchers.IO) {
                                            SignatureStorageHelper.saveSignaturePng(
                                                context = context,
                                                projectId = projectId,
                                                nationalId = nationalId,
                                                strokes = snapshotStrokes,
                                                canvasWidth = canvasWidth,
                                                canvasHeight = canvasHeight
                                            )
                                        }
                                    }
                                    isSaving = false
                                    savedResult.onSuccess { filePath ->
                                        onSignatureSaved(filePath)
                                    }.onFailure { err ->
                                        Toast.makeText(
                                            context,
                                            "تعذر حفظ التوقيع: ${err.message ?: "خطأ غير متوقع"}",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            },
                            enabled = hasSignature && !isSaving,
                            colors = ButtonDefaults.buttonColors(containerColor = SigEmerald),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (isSaving) "جاري حفظ التوقيع..." else "اعتماد التوقيع وتأكيد التسليم",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    completedStrokes.clear()
                                    activeStroke.clear()
                                },
                                enabled = hasSignature && !isSaving,
                                border = BorderStroke(
                                    1.dp,
                                    if (hasSignature && !isSaving) SigAmber else SigBorder
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "مسح وإعادة",
                                    color = if (hasSignature && !isSaving) SigAmber else SigSlateMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            TextButton(
                                onClick = onDismiss,
                                enabled = !isSaving,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "إلغاء",
                                    color = SigSlateMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }
}
