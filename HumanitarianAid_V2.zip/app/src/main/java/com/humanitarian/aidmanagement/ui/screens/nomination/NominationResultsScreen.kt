package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.GlassButton
import com.humanitarian.aidmanagement.ui.components.GlassCard
import com.humanitarian.aidmanagement.ui.components.GlassStatusBadge
import com.humanitarian.aidmanagement.ui.theme.PalestineGreen
import com.humanitarian.aidmanagement.ui.theme.PalestineGreenContainer
import com.humanitarian.aidmanagement.ui.theme.PalestineGreenDark
import com.humanitarian.aidmanagement.ui.theme.StatusNominated
import kotlinx.coroutines.launch

/**
 * شاشة الترحيل واعتماد المرشحين بتصميم الزجاج العاكس (Glassmorphism UI)
 * تعرض السجلات ذات حالة 'مرشح' التي تنتظر الترحيل من Room، وتنفذ عملية الترحيل التفاعلية.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NominationResultsScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateHome: () -> Unit,
    viewModel: TransferViewModel = viewModel(
        factory = TransferViewModel.Factory(repository)
    )
) {
    // 3. قراءة البيانات التفاعلية من الـ ViewModel باستخدام collectAsStateWithLifecycle()
    val nominatedRecords by viewModel.nominatedRecords.collectAsStateWithLifecycle()
    val nominatedItems by viewModel.nominatedItems.collectAsStateWithLifecycle()
    val activeProjects by viewModel.activeProjects.collectAsStateWithLifecycle()
    val activeAidTypes by viewModel.activeAidTypes.collectAsStateWithLifecycle()
    val selectedProjectId by viewModel.selectedProjectId.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val isMigrating by viewModel.isMigrating.collectAsStateWithLifecycle()
    val migrationSuccessCount by viewModel.migrationSuccessCount.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()

    var showConfirmDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Send, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(20.dp))
                            Text(
                                text = "ترحيل واعتماد المرشحين للصرف",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        }
                        Text(
                            text = "السجلات ذات حالة 'مرشح' بانتظار الترحيل إلى كشوفات التسليم",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        viewModel.resetFilters()
                        onNavigateBack()
                    }) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    if (nominatedItems.isNotEmpty()) {
                        FilledTonalButton(
                            onClick = { showConfirmDialog = true },
                            enabled = !isMigrating,
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = PalestineGreenContainer,
                                contentColor = PalestineGreenDark
                            ),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ترحيل الكل (${nominatedItems.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.People, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                            Text(
                                text = "المرشحون الجاهزون: ${nominatedItems.size} أسرة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = PalestineGreen
                            )
                        }
                        val totalMembers = nominatedItems.sumOf { it.family?.familyMembersCount ?: 0 }
                        Text(
                            text = "إجمالي أفراد المستفيدين: $totalMembers فرد",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }

                    // زر الترحيل الزجاجي GlassButton: مفعل فقط إذا كانت القائمة غير فارغة
                    GlassButton(
                        onClick = { showConfirmDialog = true },
                        enabled = nominatedItems.isNotEmpty() && !isMigrating,
                        containerColor = PalestineGreen,
                        contentColor = Color.White,
                        icon = if (isMigrating) null else Icons.Default.Send,
                        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp)
                    ) {
                        if (isMigrating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري الترحيل...", fontWeight = FontWeight.Bold)
                        } else {
                            Text(
                                text = "اعتماد وترحيل (${nominatedItems.size})",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 20.dp)
        ) {
            // شريط الفلاتر والبحث في بطاقة زجاجية GlassCard
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // حقل البحث
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setSearchQuery(it) },
                            placeholder = { Text("بحث باسم المستفيد، رقم الهوية، أو الجوال...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = PalestineGreen) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                        Icon(Icons.Default.Clear, contentDescription = "مسح")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        // فلاتر المشاريع
                        if (activeProjects.isNotEmpty()) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.FilterList, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                                Text(
                                    text = "تصفية حسب المشروع:",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                FilterChip(
                                    selected = selectedProjectId == null || selectedProjectId == 0L,
                                    onClick = { viewModel.selectProject(null) },
                                    leadingIcon = { Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                    label = { Text("كافة المشاريع (${nominatedRecords.size})", fontSize = 11.sp) }
                                )
                                activeProjects.forEach { prj ->
                                    val countForPrj = nominatedRecords.count { it.projectID == prj.projectID }
                                    if (countForPrj > 0 || prj.projectID == selectedProjectId) {
                                        FilterChip(
                                            selected = selectedProjectId == prj.projectID,
                                            onClick = { viewModel.selectProject(prj.projectID) },
                                            leadingIcon = { Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(14.dp)) },
                                            label = { Text("${prj.projectName} ($countForPrj)", fontSize = 11.sp) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // بطاقة المؤشرات السريعة الزجاجية GlassCard
            item {
                GlassCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("حالة السجلات", style = MaterialTheme.typography.labelSmall)
                            Spacer(modifier = Modifier.height(2.dp))
                            GlassStatusBadge(status = "مرشح للصرف")
                        }
                        Divider(modifier = Modifier.height(30.dp).width(1.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("المشاريع المشمولة", style = MaterialTheme.typography.labelSmall)
                            val prjCount = nominatedItems.map { it.record.projectID }.distinct().size
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(14.dp))
                                Text("$prjCount", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = PalestineGreen)
                            }
                        }
                        Divider(modifier = Modifier.height(30.dp).width(1.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("إجمالي الأسر", style = MaterialTheme.typography.labelSmall)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.Groups, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Text("${nominatedItems.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }

            // الحالة الفارغة إذا لم توجد سجلات ذات حالة "مرشح"
            if (nominatedItems.isEmpty()) {
                item {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .background(PalestineGreenContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.AssignmentTurnedIn,
                                    contentDescription = null,
                                    tint = PalestineGreenDark,
                                    modifier = Modifier.size(38.dp)
                                )
                            }

                            Text(
                                text = "لا توجد سجلات بانتظار الترحيل حالياً",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )

                            Text(
                                text = "كافة المرشحين تم ترحيلهم واعتمادهم رسمياً ونقلهم إلى كشوفات التسليم والصرف، أو يمكنك اعتماد ترشيحات جديدة من شاشة 'الترشيح' لتظهر هنا فوراً.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp
                            )

                            GlassButton(
                                onClick = {
                                    viewModel.resetFilters()
                                    onNavigateBack()
                                },
                                containerColor = PalestineGreen,
                                icon = Icons.Default.ArrowForward
                            ) {
                                Text("الانتقال لشاشة الترشيح", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.FormatListNumbered, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            Text(
                                text = "كشف الأسر المرشحة بانتظار الاعتماد والترحيل:",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Text(
                            text = "${nominatedItems.size} سجل",
                            style = MaterialTheme.typography.labelMedium,
                            color = PalestineGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // كشف المرشحين التفاعلي المقروء من StateFlow في بطاقات زجاجية GlassCard
                itemsIndexed(nominatedItems, key = { _, item -> item.record.aidRecordID }) { index, item ->
                    val family = item.family
                    val record = item.record

                    GlassCard(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .background(PalestineGreenContainer, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${index + 1}",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = PalestineGreenDark
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = family?.name ?: "مستفيد غير مسجل #${record.familyID}",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )

                                    // شارة الحالة الزجاجية مع أيقونة معبرة
                                    GlassStatusBadge(status = "مرشح بانتظار الترحيل")
                                }

                                Spacer(modifier = Modifier.height(3.dp))

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.Badge, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f), modifier = Modifier.size(13.dp))
                                    Text(
                                        text = "الهوية: ${family?.nationalID ?: "-"} • المنطقة: ${family?.currentSubArea?.ifBlank { "غير محددة" } ?: "-"} • جوال: ${family?.primary_phone ?: "-"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                                    )
                                }

                                Spacer(modifier = Modifier.height(2.dp))

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(Icons.Default.Inventory2, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(13.dp))
                                    Text(
                                        text = "المشروع: ${item.projectName} • المساعدة: ${item.aidTypeName} • ${family?.familyMembersCount ?: 0} أفراد",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = PalestineGreen,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            IconButton(
                                onClick = { viewModel.removeNominatedRecord(record.aidRecordID) }
                            ) {
                                Icon(
                                    Icons.Default.DeleteOutline,
                                    contentDescription = "استبعاد من الترحيل",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة تأكيد الترحيل النهائي
    if (showConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmDialog = false },
            icon = {
                Icon(
                    Icons.Default.Send,
                    contentDescription = null,
                    tint = PalestineGreen,
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "تأكيد اعتماد وترحيل المرشحين",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من ترحيل ${nominatedItems.size} أسرة مرشحة؟\n\nسيتم تحديث حالة السجلات في قاعدة البيانات ونقلها مباشرة إلى كشوفات التسليم والصرف الميداني.",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                GlassButton(
                    onClick = {
                        showConfirmDialog = false
                        viewModel.executeMigration()
                    },
                    containerColor = PalestineGreen,
                    icon = Icons.Default.Check
                ) {
                    Text("نعم، ترحيل الآن 🚀", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showConfirmDialog = false }) {
                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إلغاء")
                }
            }
        )
    }

    // نافذة نجاح الترحيل
    if (migrationSuccessCount != null) {
        AlertDialog(
            onDismissRequest = {
                viewModel.clearMessages()
            },
            icon = {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = PalestineGreen,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = {
                Text(
                    text = "تم الترحيل والاعتماد بنجاح! 🎉",
                    fontWeight = FontWeight.Bold,
                    color = PalestineGreenDark,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "تم بنجاح ترحيل $migrationSuccessCount أسرة مرشحة وتحديث حالتها في قاعدة البيانات Room.\n\nأصبحت السجلات الآن متاحة فورياً في شاشة التسليم والصرف الميداني للبدء بتوزيع المساعدات وتوليد السندات والباركود.",
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                GlassButton(
                    onClick = {
                        viewModel.clearMessages()
                        viewModel.resetFilters()
                        onNavigateHome()
                    },
                    containerColor = PalestineGreen,
                    icon = Icons.Default.Home
                ) {
                    Text("العودة للرئيسية", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { viewModel.clearMessages() }
                ) {
                    Text("إغلاق")
                }
            }
        )
    }

    // عرض رسالة الخطأ إن وُجدت
    if (errorMessage != null) {
        AlertDialog(
            onDismissRequest = { viewModel.clearMessages() },
            icon = { Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("تنبيه", color = MaterialTheme.colorScheme.error) },
            text = { Text(errorMessage ?: "حدث خطأ غير متوقع") },
            confirmButton = {
                Button(onClick = { viewModel.clearMessages() }) {
                    Text("حسناً")
                }
            }
        )
    }
}

/**
 * شاشة الترحيل المباشرة (Alias Screen)
 */
@Composable
fun MigrationScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateHome: () -> Unit = onNavigateBack
) {
    NominationResultsScreen(
        repository = repository,
        onNavigateBack = onNavigateBack,
        onNavigateHome = onNavigateHome
    )
}
