package com.humanitarian.aidmanagement.ui.screens.excel

import androidx.compose.runtime.Composable
import com.humanitarian.aidmanagement.data.repository.AidRepository

/**
 * شاشة الاستيراد المستقلة (ImportScreen)
 * مفصولة بالكامل عن شاشة التقارير والمعاينة والتصدير الديناميكي [DynamicReportExportScreen].
 */
@Composable
fun ImportScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    ExcelImportExportScreen(
        repository = repository,
        onNavigateBack = onNavigateBack
    )
}
