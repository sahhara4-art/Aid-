package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.DynamicFilterOptions
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.*
import kotlinx.coroutines.launch

// -------------------------------------------------------------
// لوحة الألوان المحددة إلزامياً في هوية محرك الترشيح الحساس
// -------------------------------------------------------------
private val BluePrimary = Color(0xFF1976D2)       // أزرار رئيسية، عناوين، وحالة التحميل
private val GreenSecondary = Color(0xFF2E7D32)    // مطابقة 100% للشروط وزر اعتماد الترشيح
private val AmberWarning = Color(0xFFD97706)      // تنبيه المدير (استلام قريب / اقتراب الحصة)
private val RedError = Color(0xFFDC2626)          // العائلات المستبعدة ونقص الحصة
private val Slate50 = Color(0xFFF8FAFC)           // لون خلفية الشاشة لراحة العين
private val SlateCardBorder = Color(0xFFE2E8F0)
private val SlateTextMuted = Color(0xFF64748B)

enum class ProjectLifecycleStage(val stageNumber: Int, val title: String, val subtitle: String) {
    DRAFT(1, "قيد الطرح", "تحديد المشروع والحصص"),
    NOMINATION_ACTIVE(2, "الترشيح النشط", "تشغيل محرك الفلترة"),
    REVIEW_APPROVAL(3, "المراجعة والاعتماد", "مطابقة الحصص والمفاضلة"),
    DISPATCHED(4, "معتمد ومُرحّل", "جاهز للصرف والتسليم")
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DynamicNominationScreen(
    repository: AidRepository,
    nominationViewModel: NominationViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = NominationViewModel.Factory(repository)
    ),
    onNavigateBack: () -> Unit,
    onNavigateToManualSelection: ((aidTypeId: Int, projectId: Long) -> Unit)? = null,
    onOpenProjectManager: (() -> Unit)? = null
) {
    val scope = rememberCoroutineScope()

    // البيانات المرجعية من المستودع
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val projects by repository.getActiveProjects().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val currentUser by repository.currentUserFlow.collectAsState()

    val isSuperAdmin = repository.isSuperAdmin()
    val userAllowedLocalityId = currentUser?.AllowedLocalityID ?: 0
    val isLocalitySupervisor = !isSuperAdmin && userAllowedLocalityId > 0
    val supervisorLocalityName = remember(userAllowedLocalityId, localities) {
        localities.find { it.LocalityID == userAllowedLocalityId }?.LocalityName ?: "المحلية المخصصة (#$userAllowedLocalityId)"
    }

    // مرحلة دورة حياة المشروع الحالية (Project Lifecycle Stepper)
    var currentStage by remember { mutableStateOf(ProjectLifecycleStage.DRAFT) }

    // خيارات الفلاتر الديناميكية المستمدة من قاعدة البيانات عبر SELECT DISTINCT (Zero Hardcoded Data)
    var dynamicDamageTypes by remember { mutableStateOf<List<String>>(emptyList()) }
    var dynamicMaritalStatuses by remember { mutableStateOf<List<String>>(emptyList()) }
    var dynamicWorksApprovals by remember { mutableStateOf<List<String>>(emptyList()) }
    var dynamicShelterStatuses by remember { mutableStateOf<List<String>>(emptyList()) }
    var dynamicIncomeSources by remember { mutableStateOf<List<String>>(emptyList()) }
    var dynamicInjuryStatuses by remember { mutableStateOf<List<String>>(emptyList()) }
    var dynamicSubAreas by remember { mutableStateOf<List<String>>(emptyList()) }

    // ---------------------------------------------------------
    // حالة معايير محرك القواعد الديناميكي المرفوعة كـ MutableStateFlow في NominationViewModel
    // (State Persistence across navigation 100%)
    // ---------------------------------------------------------
    val targetBeneficiariesText by nominationViewModel.targetBeneficiariesText.collectAsState()
    val calculatedQuotas by nominationViewModel.calculatedQuotas.collectAsState()

    // استثناء زمني: بالأيام أو بتاريخ محدد
    val exclusionMode by nominationViewModel.exclusionMode.collectAsState()
    val exclusionDaysText by nominationViewModel.exclusionDaysText.collectAsState()
    val exclusionDateCutoffText by nominationViewModel.exclusionDateCutoffText.collectAsState()
    val selectedAidCategories by nominationViewModel.selectedAidCategories.collectAsState()
    val excludeAidCategories by nominationViewModel.excludeAidCategories.collectAsState()

    // فلتر الأطفال
    val hasChildrenOnly by nominationViewModel.hasChildrenOnly.collectAsState()
    val minChildAgeText by nominationViewModel.minChildAgeText.collectAsState()
    val maxChildAgeText by nominationViewModel.maxChildAgeText.collectAsState()

    // خيارات متعددة ديناميكية ومفاتيح التبديل للاستثناء (Multi-select Lists & Exclusion Toggles)
    val selectedDamageTypes by nominationViewModel.selectedDamageTypes.collectAsState()
    val excludeDamageTypes by nominationViewModel.excludeDamageTypes.collectAsState()

    val selectedMaritalStatuses by nominationViewModel.selectedMaritalStatuses.collectAsState()
    val excludeMaritalStatuses by nominationViewModel.excludeMaritalStatuses.collectAsState()

    val selectedWorksApprovals by nominationViewModel.selectedWorksApprovals.collectAsState()
    val excludeWorksApprovals by nominationViewModel.excludeWorksApprovals.collectAsState()

    val selectedShelterStatuses by nominationViewModel.selectedShelterStatuses.collectAsState()
    val excludeShelterStatuses by nominationViewModel.excludeShelterStatuses.collectAsState()

    val selectedIncomeSources by nominationViewModel.selectedIncomeSources.collectAsState()
    val excludeIncomeSources by nominationViewModel.excludeIncomeSources.collectAsState()

    val selectedInjuryStatuses by nominationViewModel.selectedInjuryStatuses.collectAsState()
    val excludeInjuryStatuses by nominationViewModel.excludeInjuryStatuses.collectAsState()

    val selectedSubAreas by nominationViewModel.selectedSubAreas.collectAsState()
    val excludeSubAreas by nominationViewModel.excludeSubAreas.collectAsState()

    val selectedLocalityId by nominationViewModel.selectedLocalityId.collectAsState()
    val excludeLocality by nominationViewModel.excludeLocality.collectAsState()

    val selectedAidTypeId by nominationViewModel.selectedAidTypeId.collectAsState()
    val selectedProjectId by nominationViewModel.selectedProjectId.collectAsState()
    val resultLimitText by nominationViewModel.resultLimitText.collectAsState()

    // التحكم في طي وتمدد لوحة شروط الفلترة
    var isFiltersExpanded by remember { mutableStateOf(true) }

    // حالة المحرك والتنفيذ المرفوعة
    val isLoading by nominationViewModel.isFiltering.collectAsState()
    val nominationResult by nominationViewModel.dynamicNominationResult.collectAsState()
    var statusFilterTab by remember { mutableStateOf<CandidateStatus?>(null) } // null = الكل
    var searchQuery by remember { mutableStateOf("") }

    // نوافذ الاعتماد والحصص
    var showApprovalDialog by remember { mutableStateOf(false) }
    var showQuotasDialog by remember { mutableStateOf(false) }
    var approvalSuccessMessage by remember { mutableStateOf<String?>(null) }

    // جلب الخيارات الديناميكية فور بدء الشاشة مباشرة من Room DAO عبر SELECT DISTINCT
    LaunchedEffect(Unit) {
        val options = repository.getDynamicFilterOptions()
        dynamicDamageTypes = options.damageTypes
        dynamicMaritalStatuses = options.maritalStatuses
        dynamicWorksApprovals = options.worksApprovals
        dynamicShelterStatuses = if (!options.shelterStatuses.contains("بدون تصنيف")) {
            options.shelterStatuses + "بدون تصنيف"
        } else {
            options.shelterStatuses
        }
        dynamicIncomeSources = options.incomeSources
        dynamicInjuryStatuses = options.injuryStatuses
        dynamicSubAreas = options.subAreas

        val target = targetBeneficiariesText.toIntOrNull() ?: 100
        nominationViewModel.calculatedQuotas.value = repository.calculateDynamicLocalityQuotas(target)
    }

    // إعادة حساب الحصص ديناميكياً فور تغيير "العدد المطلوب" بناءً على معادلة الـ View
    LaunchedEffect(targetBeneficiariesText) {
        val target = targetBeneficiariesText.toIntOrNull() ?: 0
        if (target > 0) {
            nominationViewModel.calculatedQuotas.value = repository.calculateDynamicLocalityQuotas(target)
        }
    }

    // قفل وتحديث المحلية للمشرف الميداني
    LaunchedEffect(isLocalitySupervisor, userAllowedLocalityId) {
        if (isLocalitySupervisor) {
            nominationViewModel.selectedLocalityId.value = userAllowedLocalityId
        }
    }

    // تحديث المشروع التلقائي
    LaunchedEffect(projects) {
        if (projects.isNotEmpty() && projects.none { it.projectID == selectedProjectId }) {
            nominationViewModel.selectedProjectId.value = projects.first().projectID
            nominationViewModel.selectedAidTypeId.value = projects.first().aidTypeID
        }
    }

    // حصة المشرف الميداني إن وجد
    val userSupervisorQuota = remember(calculatedQuotas, userAllowedLocalityId) {
        calculatedQuotas.find { it.localityId == userAllowedLocalityId }?.allocatedCount ?: 0
    }

    // دالة تنفيذ محرك الترشيح البرمجي الذكي المعتمد 100% على EligibleFamiliesView
    fun executeEngine() {
        scope.launch {
            isFiltersExpanded = false
            currentStage = ProjectLifecycleStage.NOMINATION_ACTIVE
            nominationViewModel.runFilteringEngine()
            currentStage = ProjectLifecycleStage.REVIEW_APPROVAL
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Slate50,
            contentWindowInsets = WindowInsets(0.dp),
            topBar = {
                TopAppBar(
                    windowInsets = WindowInsets(0.dp),
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "محرك الترشيح الذكي المتقدم",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp,
                                    color = BluePrimary
                                )
                                Surface(
                                    shape = CircleShape,
                                    color = BluePrimary.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "Smart Engine",
                                        color = BluePrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "خيارات ديناميكية 100% • ثوابت إجبارية • حساب الحصص الجغرافية",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextMuted,
                                fontSize = 11.sp
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = BluePrimary)
                        }
                    },
                    actions = {
                        if (onOpenProjectManager != null) {
                            IconButton(onClick = onOpenProjectManager) {
                                Icon(
                                    Icons.Default.DashboardCustomize,
                                    contentDescription = "طرح المشاريع والحصص",
                                    tint = BluePrimary
                                )
                            }
                        }
                        IconButton(onClick = { isFiltersExpanded = !isFiltersExpanded }) {
                            Icon(
                                if (isFiltersExpanded) Icons.Default.FilterListOff else Icons.Default.FilterList,
                                contentDescription = "طي/تمدد الفلاتر",
                                tint = BluePrimary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                val eligibleCount = nominationResult?.candidates?.count { it.status != CandidateStatus.EXCLUDED } ?: 0
                if (eligibleCount > 0 && !isLoading && currentStage != ProjectLifecycleStage.DISPATCHED) {
                    Surface(
                        color = Color.White,
                        shadowElevation = 10.dp,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(GreenSecondary)
                                    )
                                    Text(
                                        text = "$eligibleCount مرشح مؤهل للاعتماد",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = GreenSecondary
                                    )
                                }
                                Text(
                                    text = "جاهزون للترحيل المباشر إلى جدول التسليم والصرف",
                                    fontSize = 11.sp,
                                    color = SlateTextMuted
                                )
                            }

                            Button(
                                onClick = { showApprovalDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenSecondary),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("اعتماد وترحيل 🚀", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // -------------------------------------------------------------
                // 1. شريط دورة حياة المشروع البصري (Project Lifecycle Stepper)
                // -------------------------------------------------------------
                item {
                    ProjectLifecycleStepper(
                        currentStage = currentStage,
                        onStageClick = { stage ->
                            if (stage.stageNumber <= currentStage.stageNumber || (stage == ProjectLifecycleStage.REVIEW_APPROVAL && nominationResult != null)) {
                                currentStage = stage
                            }
                        }
                    )
                }

                // -------------------------------------------------------------
                // 2. إشعار تنبيهي لمشرف المحلية حسب الصلاحية (RBAC Supervisor Banner)
                // -------------------------------------------------------------
                if (isLocalitySupervisor) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = BluePrimary.copy(alpha = 0.08f),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, BluePrimary.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                                    Text(
                                        text = "تنبيه صلاحيات مشرف المحلية",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = BluePrimary
                                    )
                                }
                                Text(
                                    text = "أهلاً بك (${currentUser?.fullName ?: currentUser?.UserName}) • أنت مسجل كمشرف على محلية ($supervisorLocalityName).",
                                    fontSize = 12.sp,
                                    color = Color(0xFF1E293B),
                                    fontWeight = FontWeight.SemiBold
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "حصتك المخصصة لهذا المشروع: $userSupervisorQuota أسرة",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GreenSecondary
                                    )
                                    if (onNavigateToManualSelection != null) {
                                        OutlinedButton(
                                            onClick = { onNavigateToManualSelection(selectedAidTypeId, selectedProjectId) },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Text("ترشيح يدوي للحصة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // -------------------------------------------------------------
                // 3. بطاقة الثوابت الإجبارية الصارمة (تنمية = معتمد وَ إقامة = مقيم)
                // -------------------------------------------------------------
                item {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                        shadowElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(18.dp))
                                    Text(
                                        text = "الثوابت الإجبارية المستثناة بقاعدة البيانات",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = BluePrimary
                                    )
                                }
                                Surface(
                                    color = GreenSecondary.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "مطبق آلياً وبشكل صارم",
                                        color = GreenSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .wrapContentHeight(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .wrapContentHeight(),
                                    color = Slate50,
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GreenSecondary, modifier = Modifier.size(16.dp))
                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .wrapContentHeight()
                                        ) {
                                            Text(
                                                text = "حالة التنمية الاجتماعية",
                                                fontSize = 10.sp,
                                                color = SlateTextMuted,
                                                maxLines = 1,
                                                softWrap = false,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "معتمد 🔒",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF0F172A),
                                                maxLines = 1,
                                                softWrap = false,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }

                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .wrapContentHeight(),
                                    color = Slate50,
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GreenSecondary, modifier = Modifier.size(16.dp))
                                        Column(
                                            modifier = Modifier
                                                .weight(1f)
                                                .wrapContentHeight()
                                        ) {
                                            Text(
                                                text = "حالة الإقامة",
                                                fontSize = 10.sp,
                                                color = SlateTextMuted,
                                                maxLines = 1,
                                                softWrap = false,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "مقيم 🔒",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF0F172A),
                                                maxLines = 1,
                                                softWrap = false,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // -------------------------------------------------------------
                // 4. بطاقة التوزيع الجغرافي وحساب الحصص (Dynamic Quota Allocation)
                // -------------------------------------------------------------
                item {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                        shadowElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.PieChart, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(18.dp))
                                    Text(
                                        text = "التوزيع الجغرافي وحصص المحليات",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = BluePrimary
                                    )
                                }
                                Text(
                                    text = "معادلة النسب الحقيقية",
                                    fontSize = 11.sp,
                                    color = SlateTextMuted,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // إدخال العدد المطلوب للمشروع
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = targetBeneficiariesText,
                                    onValueChange = { nominationViewModel.targetBeneficiariesText.value = it.filter { c -> c.isDigit() } },
                                    label = { Text("العدد المطلوب للمشروع") },
                                    placeholder = { Text("100") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                )

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Slate50,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                                    modifier = Modifier.weight(1.3f)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text("معادلة الحصة:", fontSize = 10.sp, color = SlateTextMuted)
                                        Text(
                                            text = "العدد المطلوب × (المعتمد بالمحلية ÷ الإجمالي)",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = BluePrimary
                                        )
                                    }
                                }
                            }

                            // عرض الحصص كبطاقات للمحليات
                            if (calculatedQuotas.isNotEmpty()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    calculatedQuotas.forEach { quota ->
                                        val isHighlighted = isLocalitySupervisor && quota.localityId == userAllowedLocalityId
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = if (isHighlighted) BluePrimary.copy(alpha = 0.08f) else Slate50,
                                            border = androidx.compose.foundation.BorderStroke(
                                                width = if (isHighlighted) 1.5.dp else 1.dp,
                                                color = if (isHighlighted) BluePrimary else SlateCardBorder
                                            ),
                                            modifier = Modifier.width(140.dp)
                                        ) {
                                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(
                                                    text = quota.localityName,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    maxLines = 1,
                                                    color = if (isHighlighted) BluePrimary else Color(0xFF0F172A)
                                                )
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text("${quota.percentage}%", fontSize = 11.sp, color = SlateTextMuted)
                                                    Text("${quota.allocatedCount} حصة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = BluePrimary)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // -------------------------------------------------------------
                // 5. محددات وشروط الفلترة الديناميكية بالكامل (Dynamic Criteria Panel)
                // -------------------------------------------------------------
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isFiltersExpanded) BluePrimary.copy(alpha = 0.4f) else SlateCardBorder),
                        shadowElevation = 2.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // ترويسة اللوحة وزر الطي/التمدد
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isFiltersExpanded = !isFiltersExpanded },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(BluePrimary.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Tune, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                                    }
                                    Column {
                                        Text(
                                            text = "شروط وفلاتر الترشيح الديناميكية",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = BluePrimary
                                        )
                                        Text(
                                            text = if (isFiltersExpanded) "اضغط للطي وتوفير مساحة للنتائج" else "تم طي اللوحة • اضغط للتعديل وإعادة الضبط",
                                            fontSize = 11.sp,
                                            color = SlateTextMuted
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(
                                        if (isFiltersExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = null,
                                        tint = BluePrimary
                                    )
                                }
                            }

                            // محتوى الشروط
                            AnimatedVisibility(
                                visible = isFiltersExpanded,
                                enter = expandVertically() + fadeIn(),
                                exit = shrinkVertically() + fadeOut()
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    HorizontalDivider(color = SlateCardBorder)

                                    // أ) نظام الاستثناء الزمني والمكاني (مدة بالأيام أو تاريخ محدد + تصنيفات المساعدات)
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Icon(Icons.Default.HistoryToggleOff, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(16.dp))
                                                Text("نظام الاستثناء الزمني والمكاني:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }

                                            // التبديل بين بالأيام أو بتاريخ محدد
                                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                ExclusionMode.values().forEach { mode ->
                                                    val isSel = exclusionMode == mode
                                                    Surface(
                                                        onClick = { nominationViewModel.exclusionMode.value = mode },
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = if (isSel) BluePrimary else Color(0xFFF1F5F9),
                                                        contentColor = if (isSel) Color.White else Color(0xFF1E293B)
                                                    ) {
                                                        Text(
                                                            text = mode.label,
                                                            fontSize = 10.sp,
                                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        if (exclusionMode == ExclusionMode.DAYS) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                OutlinedTextField(
                                                    value = exclusionDaysText,
                                                    onValueChange = { nominationViewModel.exclusionDaysText.value = it },
                                                    label = { Text("مدة الاستثناء بالأيام") },
                                                    placeholder = { Text("30") },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(10.dp),
                                                    singleLine = true
                                                )
                                                Row(
                                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    listOf("15", "30", "45", "60", "90").forEach { d ->
                                                        val isSelected = exclusionDaysText == d
                                                        Surface(
                                                            onClick = { nominationViewModel.exclusionDaysText.value = d },
                                                            shape = RoundedCornerShape(8.dp),
                                                            color = if (isSelected) BluePrimary else Color(0xFFF1F5F9),
                                                            contentColor = if (isSelected) Color.White else Color(0xFF1E293B)
                                                        ) {
                                                            Text(
                                                                text = "$d يوم",
                                                                fontSize = 11.sp,
                                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        } else {
                                            OutlinedTextField(
                                                value = exclusionDateCutoffText,
                                                onValueChange = { nominationViewModel.exclusionDateCutoffText.value = it },
                                                label = { Text("استثناء من استلم بعد تاريخ (YYYY-MM-DD)") },
                                                placeholder = { Text("2025-01-01") },
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(10.dp),
                                                singleLine = true
                                            )
                                        }

                                        // تصنيفات المساعدات المستثناة (Multi-select Chips)
                                        Text("تصنيفات المساعدات المستثناة (فارغ = الكل):", fontSize = 11.sp, color = SlateTextMuted)
                                        Row(
                                             modifier = Modifier
                                                 .fillMaxWidth()
                                                 .horizontalScroll(rememberScrollState()),
                                             horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                             val isAllTypes = selectedAidCategories.isEmpty()
                                             Surface(
                                                 onClick = { nominationViewModel.clearCategories() },
                                                 shape = RoundedCornerShape(8.dp),
                                                 color = if (isAllTypes) BluePrimary else Color(0xFFF1F5F9),
                                                 contentColor = if (isAllTypes) Color.White else Color(0xFF1E293B)
                                             ) {
                                                 Text("كافة التصنيفات", fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                                             }
                                             aidTypes.forEach { type ->
                                                 val isSelected = selectedAidCategories.contains(type.aidTypeName)
                                                 Surface(
                                                     onClick = {
                                                         nominationViewModel.toggleCategory(type.aidTypeName)
                                                     },
                                                     shape = RoundedCornerShape(8.dp),
                                                     color = if (isSelected) BluePrimary else Color(0xFFF1F5F9),
                                                     contentColor = if (isSelected) Color.White else Color(0xFF1E293B)
                                                 ) {
                                                     Text(type.aidTypeName, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                                                 }
                                             }
                                        }
                                    }

                                    // ب) فلتر الأطفال: مفتاح تبديل (Switch) ونطاق الأعمار
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Icon(Icons.Default.ChildCare, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(16.dp))
                                                Text("فلتر الأطفال (يوجد أطفال):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                            Switch(
                                                checked = hasChildrenOnly,
                                                onCheckedChange = { nominationViewModel.hasChildrenOnly.value = it },
                                                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = BluePrimary)
                                            )
                                        }

                                        AnimatedVisibility(
                                            visible = hasChildrenOnly,
                                            enter = expandVertically() + fadeIn(),
                                            exit = shrinkVertically() + fadeOut()
                                        ) {
                                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text("تحديد نطاق عمر الابن (بالسنوات):", fontSize = 11.sp, color = SlateTextMuted)
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    OutlinedTextField(
                                                        value = minChildAgeText,
                                                        onValueChange = { nominationViewModel.minChildAgeText.value = it },
                                                        label = { Text("عمر الابن: من") },
                                                        placeholder = { Text("0") },
                                                        modifier = Modifier.weight(1f),
                                                        shape = RoundedCornerShape(10.dp),
                                                        singleLine = true
                                                    )
                                                    OutlinedTextField(
                                                        value = maxChildAgeText,
                                                        onValueChange = { nominationViewModel.maxChildAgeText.value = it },
                                                        label = { Text("عمر الابن: إلى") },
                                                        placeholder = { Text("18") },
                                                        modifier = Modifier.weight(1f),
                                                        shape = RoundedCornerShape(10.dp),
                                                        singleLine = true
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    // ج) متعدد الخيارات للحالة الاجتماعية (مستمدة ديناميكياً 100% عبر SELECT DISTINCT)
                                    MultiSelectSection(
                                        title = "الحالة الاجتماعية (تحديد متعدد + استثناء):",
                                        icon = Icons.Default.People,
                                        options = dynamicMaritalStatuses,
                                        selectedItems = selectedMaritalStatuses,
                                        isExcluded = excludeMaritalStatuses,
                                        onExcludedChange = { nominationViewModel.excludeMaritalStatuses.value = it },
                                        onToggle = { option -> nominationViewModel.toggleMaritalStatus(option) },
                                        onClear = { nominationViewModel.clearMaritalStatuses() }
                                    )

                                    // د) متعدد الخيارات لحالة الضرر (مستمدة ديناميكياً 100%)
                                    MultiSelectSection(
                                        title = "حالة الضرر المسجل (ديناميكي):",
                                        icon = Icons.Default.BrokenImage,
                                        options = dynamicDamageTypes,
                                        selectedItems = selectedDamageTypes,
                                        isExcluded = excludeDamageTypes,
                                        onExcludedChange = { nominationViewModel.excludeDamageTypes.value = it },
                                        onToggle = { option -> nominationViewModel.toggleDamageType(option) },
                                        onClear = { nominationViewModel.clearDamageTypes() }
                                    )

                                    // هـ) متعدد الخيارات لاعتماد الأشغال (مستمدة ديناميكياً 100%)
                                    MultiSelectSection(
                                        title = "اعتماد وزارة الأشغال (ديناميكي):",
                                        icon = Icons.Default.DomainVerification,
                                        options = dynamicWorksApprovals,
                                        selectedItems = selectedWorksApprovals,
                                        isExcluded = excludeWorksApprovals,
                                        onExcludedChange = { nominationViewModel.excludeWorksApprovals.value = it },
                                        onToggle = { option -> nominationViewModel.toggleWorksApproval(option) },
                                        onClear = { nominationViewModel.clearWorksApprovals() }
                                    )

                                    // و) متعدد الخيارات لحالة الإيواء مع دعم 'بدون تصنيف' (مستمدة ديناميكياً)
                                    MultiSelectSection(
                                        title = "حالة الإيواء (تشمل 'بدون تصنيف'):",
                                        icon = Icons.Default.HolidayVillage,
                                        options = dynamicShelterStatuses,
                                        selectedItems = selectedShelterStatuses,
                                        isExcluded = excludeShelterStatuses,
                                        onExcludedChange = { nominationViewModel.excludeShelterStatuses.value = it },
                                        onToggle = { option -> nominationViewModel.toggleShelterStatus(option) },
                                        onClear = { nominationViewModel.clearShelterStatuses() }
                                    )

                                    // ز) متعدد الخيارات لمصدر الدخل (مستمدة ديناميكياً 100%)
                                    if (dynamicIncomeSources.isNotEmpty()) {
                                        MultiSelectSection(
                                            title = "مصدر الدخل (ديناميكي):",
                                            icon = Icons.Default.WorkOutline,
                                            options = dynamicIncomeSources,
                                            selectedItems = selectedIncomeSources,
                                            isExcluded = excludeIncomeSources,
                                            onExcludedChange = { nominationViewModel.excludeIncomeSources.value = it },
                                            onToggle = { option -> nominationViewModel.toggleIncomeSource(option) },
                                            onClear = { nominationViewModel.clearIncomeSources() }
                                        )
                                    }

                                    // ح) متعدد الخيارات لحالة الإصابة (مستمدة ديناميكياً 100%)
                                    if (dynamicInjuryStatuses.isNotEmpty()) {
                                        MultiSelectSection(
                                            title = "حالة الإصابة الصحية (ديناميكي):",
                                            icon = Icons.Default.MedicalServices,
                                            options = dynamicInjuryStatuses,
                                            selectedItems = selectedInjuryStatuses,
                                            isExcluded = excludeInjuryStatuses,
                                            onExcludedChange = { nominationViewModel.excludeInjuryStatuses.value = it },
                                            onToggle = { option -> nominationViewModel.toggleInjuryStatus(option) },
                                            onClear = { nominationViewModel.clearInjuryStatuses() }
                                        )
                                    }

                                    // ط) متعدد الخيارات للمناطق الفرعية (مستمدة ديناميكياً 100%)
                                    if (dynamicSubAreas.isNotEmpty()) {
                                        MultiSelectSection(
                                            title = "المناطق الفرعية الحالية (ديناميكي):",
                                            icon = Icons.Default.LocationOn,
                                            options = dynamicSubAreas,
                                            selectedItems = selectedSubAreas,
                                            isExcluded = excludeSubAreas,
                                            onExcludedChange = { nominationViewModel.excludeSubAreas.value = it },
                                            onToggle = { option -> nominationViewModel.toggleSubArea(option) },
                                            onClear = { nominationViewModel.clearSubAreas() }
                                        )
                                    }

                                    // ي) تحديد نطاق التوزيع الجغرافي (محمي بالصلاحية)
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("نطاق التوزيع الجغرافي للمحليات:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            if (!isLocalitySupervisor) {
                                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                    Text(
                                                        text = if (excludeLocality) "استثناء ⛔" else "استثناء",
                                                        fontSize = 11.sp,
                                                        color = if (excludeLocality) RedError else SlateTextMuted
                                                    )
                                                    Switch(
                                                        checked = excludeLocality,
                                                        onCheckedChange = { nominationViewModel.excludeLocality.value = it },
                                                        modifier = Modifier.scale(0.75f),
                                                        colors = SwitchDefaults.colors(
                                                            checkedThumbColor = Color.White,
                                                            checkedTrackColor = RedError
                                                        )
                                                    )
                                                }
                                            }
                                        }
                                        if (isLocalitySupervisor) {
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = BluePrimary,
                                                contentColor = Color.White
                                            ) {
                                                Text(
                                                    text = "محلية: $supervisorLocalityName (مقيد بصلاحيتك 🔒)",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                )
                                            }
                                        } else {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .horizontalScroll(rememberScrollState()),
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                val isAllSelected = selectedLocalityId == 0
                                                Surface(
                                                    onClick = { nominationViewModel.selectedLocalityId.value = 0 },
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = if (isAllSelected) BluePrimary else Color(0xFFF1F5F9),
                                                    contentColor = if (isAllSelected) Color.White else Color(0xFF1E293B)
                                                ) {
                                                    Text(
                                                        text = "كافة المحليات",
                                                        fontSize = 11.sp,
                                                        fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Normal,
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                    )
                                                }
                                                localities.forEach { loc ->
                                                    val isSel = selectedLocalityId == loc.LocalityID
                                                    Surface(
                                                        onClick = { nominationViewModel.selectedLocalityId.value = loc.LocalityID },
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = if (isSel) BluePrimary else Color(0xFFF1F5F9),
                                                        contentColor = if (isSel) Color.White else Color(0xFF1E293B)
                                                    ) {
                                                        Text(
                                                            text = loc.LocalityName,
                                                            fontSize = 11.sp,
                                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // ز) أزرار تطبيق الفلاتر والترشيح الآلي أو اليدوي
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { executeEngine() },
                                            modifier = Modifier
                                                .weight(1.3f)
                                                .height(48.dp),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                                        ) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("تشغيل الترشيح الذكي (الأشد احتياجاً) ⚡", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                                        }

                                        if (onNavigateToManualSelection != null) {
                                            OutlinedButton(
                                                onClick = {
                                                    nominationViewModel.runFilteringEngine()
                                                    onNavigateToManualSelection(selectedAidTypeId, selectedProjectId)
                                                },
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier
                                                    .weight(0.9f)
                                                    .height(48.dp)
                                            ) {
                                                Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("ترشيح يدوي", fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            // شريط سريع عند طي الفلاتر
                            if (!isFiltersExpanded) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "الفلاتر الديناميكية مفعلة • اضغط للتحديث",
                                        fontSize = 11.sp,
                                        color = SlateTextMuted
                                    )
                                    Button(
                                        onClick = { executeEngine() },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تحديث المرشحين", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // -------------------------------------------------------------
                // 6. تأثير التحميل النبضي (Shimmer Effect Cards)
                // -------------------------------------------------------------
                if (isLoading) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(color = BluePrimary, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "جاري تشغيل محرك الترشيح وحساب درجات الاستحقاق...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = BluePrimary
                                )
                            }
                            repeat(3) {
                                ShimmerCandidateCard()
                            }
                        }
                    }
                }

                // -------------------------------------------------------------
                // 7. شاشة المراجعة والاعتماد (Review & Approve: مؤشرات اكتمال الحصص)
                // -------------------------------------------------------------
                if (!isLoading && nominationResult != null) {
                    val res = nominationResult!!
                    val candidateList = res.candidates

                    item {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                            shadowElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("مؤشرات اكتمال الحصص الجغرافية (المراجعة والاعتماد):", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0F172A))

                                // شبكة مؤشرات اكتمال المحليات (أخضر عند الاكتمال، أحمر عند النقص)
                                res.quotas.forEach { quota ->
                                    val nominatedCount = candidateList.count { it.family.localityID == quota.localityId && it.status != CandidateStatus.EXCLUDED }
                                    val isComplete = nominatedCount >= quota.allocatedCount && quota.allocatedCount > 0
                                    val diff = quota.allocatedCount - nominatedCount

                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isComplete) GreenSecondary.copy(alpha = 0.08f) else RedError.copy(alpha = 0.08f),
                                        border = androidx.compose.foundation.BorderStroke(
                                            width = 1.dp,
                                            color = if (isComplete) GreenSecondary.copy(alpha = 0.4f) else RedError.copy(alpha = 0.4f)
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 10.dp, vertical = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Icon(
                                                    if (isComplete) Icons.Default.CheckCircle else Icons.Default.ErrorOutline,
                                                    contentDescription = null,
                                                    tint = if (isComplete) GreenSecondary else RedError,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Text(quota.localityName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Text(
                                                    text = "$nominatedCount / ${quota.allocatedCount}",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = if (isComplete) GreenSecondary else RedError
                                                )
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = if (isComplete) GreenSecondary else RedError
                                                ) {
                                                    Text(
                                                        text = if (isComplete) "مكتملة (100%)" else "نقص: $diff أسرة",
                                                        color = Color.White,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // تبويبات تصفية حالة المرشحين
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StatSummaryBadge(
                                title = "الكل",
                                count = res.totalMatched + res.excludedCount,
                                color = BluePrimary,
                                isSelected = statusFilterTab == null,
                                modifier = Modifier.weight(1f),
                                onClick = { statusFilterTab = null }
                            )
                            StatSummaryBadge(
                                title = "مطابقة 100%",
                                count = res.fullMatchCount,
                                color = GreenSecondary,
                                isSelected = statusFilterTab == CandidateStatus.MATCHED_100,
                                modifier = Modifier.weight(1f),
                                onClick = { statusFilterTab = CandidateStatus.MATCHED_100 }
                            )
                            StatSummaryBadge(
                                title = "تنبيهات",
                                count = res.warningCount,
                                color = AmberWarning,
                                isSelected = statusFilterTab == CandidateStatus.WARNING,
                                modifier = Modifier.weight(1f),
                                onClick = { statusFilterTab = CandidateStatus.WARNING }
                            )
                            StatSummaryBadge(
                                title = "مستبعد",
                                count = res.excludedCount,
                                color = RedError,
                                isSelected = statusFilterTab == CandidateStatus.EXCLUDED,
                                modifier = Modifier.weight(1f),
                                onClick = { statusFilterTab = CandidateStatus.EXCLUDED }
                            )
                        }
                    }

                    // فلترة النتائج حسب البحث والتبويب
                    val filteredCandidates = candidateList
                        .filter { cand ->
                            (statusFilterTab == null || cand.status == statusFilterTab) &&
                                    (searchQuery.isBlank() ||
                                            cand.family.name.contains(searchQuery) ||
                                            cand.family.nationalID.contains(searchQuery))
                        }

                    val candidatesByLocality = filteredCandidates.groupBy { it.localityName.ifBlank { "محلية غير محددة" } }

                    candidatesByLocality.forEach { (localityName, listInLocality) ->
                        stickyHeader(key = "header_$localityName") {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(
                                            Icons.Default.Place,
                                            contentDescription = null,
                                            tint = BluePrimary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = localityName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = "${listInLocality.size} مرشح",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = BluePrimary
                                    )
                                }
                            }
                        }

                        items(listInLocality, key = { "${it.family.familyID}_${it.status.name}" }) { candidate ->
                            CandidateCardItem(
                                candidate = candidate,
                                modifier = Modifier.animateItemPlacement()
                            )
                        }
                    }
                }
            }
        }
    }

    // نافذة تأكيد الاعتماد والترحيل (Approve & Dispatch Dialog)
    if (showApprovalDialog && nominationResult != null) {
        val eligibleCandidates = nominationResult!!.candidates.filter { it.status != CandidateStatus.EXCLUDED }
        AlertDialog(
            onDismissRequest = { showApprovalDialog = false },
            icon = { Icon(Icons.Default.Verified, contentDescription = null, tint = GreenSecondary, modifier = Modifier.size(36.dp)) },
            title = { Text("تأكيد اعتماد وترحيل المرشحين", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "سيتم اعتماد ${eligibleCandidates.size} عائلة مستحقة وقفل مرحلة الترشيح، مع ترحيل السجلات مباشرة إلى جدول التسليم والصرف الميداني (tbl_Aid_Records).",
                        fontSize = 13.sp,
                        color = Color(0xFF334155)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showApprovalDialog = false
                        scope.launch {
                            val count = repository.approveDynamicNomination(
                                candidates = nominationResult!!.candidates,
                                projectId = selectedProjectId,
                                aidTypeId = selectedAidTypeId,
                                notes = "معتمد ومرحل آلياً عبر محرك الترشيح الذكي"
                            )
                            currentStage = ProjectLifecycleStage.DISPATCHED
                            approvalSuccessMessage = "تم بنجاح اعتماد وترحيل $count عائلة إلى كشوفات التسليم والصرف وقفل المشروع."
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenSecondary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("تأكيد الاعتماد والترحيل 🚀", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApprovalDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // نافذة إشعار نجاح الاعتماد
    if (approvalSuccessMessage != null) {
        AlertDialog(
            onDismissRequest = { approvalSuccessMessage = null },
            title = { Text("تم الاعتماد والترحيل بنجاح", color = GreenSecondary, fontWeight = FontWeight.Bold) },
            text = { Text(approvalSuccessMessage ?: "") },
            confirmButton = {
                Button(
                    onClick = { approvalSuccessMessage = null },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenSecondary)
                ) {
                    Text("حسناً")
                }
            }
        )
    }
}

// -------------------------------------------------------------
// شريط دورة حياة المشروع التفاعلي (Project Lifecycle Stepper)
// -------------------------------------------------------------
@Composable
fun ProjectLifecycleStepper(
    currentStage: ProjectLifecycleStage,
    onStageClick: (ProjectLifecycleStage) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ProjectLifecycleStage.values().forEachIndexed { index, stage ->
                val isActive = stage == currentStage
                val isCompleted = stage.stageNumber < currentStage.stageNumber || currentStage == ProjectLifecycleStage.DISPATCHED
                val stepColor = when {
                    isCompleted -> GreenSecondary
                    isActive -> BluePrimary
                    else -> SlateTextMuted
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .wrapContentHeight()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onStageClick(stage) }
                        .padding(horizontal = 4.dp, vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(if (isActive || isCompleted) stepColor else Color(0xFFE2E8F0)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        } else {
                            Text(
                                text = stage.stageNumber.toString(),
                                color = if (isActive) Color.White else SlateTextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = stage.title,
                        fontSize = 11.sp,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                        color = if (isActive) BluePrimary else if (isCompleted) GreenSecondary else SlateTextMuted,
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (index < ProjectLifecycleStage.values().size - 1) {
                    Box(
                        modifier = Modifier
                            .width(16.dp)
                            .height(2.dp)
                            .background(if (stage.stageNumber < currentStage.stageNumber) GreenSecondary else SlateCardBorder)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// مكون متعدد الخيارات (MultiSelectSection) المعتمد على FilterChip (Material 3) ومفتاح التبديل للاستثناء
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MultiSelectSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    options: List<String>,
    selectedItems: Collection<String>,
    isExcluded: Boolean = false,
    onExcludedChange: ((Boolean) -> Unit)? = null,
    onToggle: (String) -> Unit,
    onClear: () -> Unit
) {
    val activeColor by animateColorAsState(
        targetValue = if (isExcluded) RedError else Color(0xFF10B981),
        label = "activeColor"
    )
    val activeBgColor by animateColorAsState(
        targetValue = if (isExcluded) RedError.copy(alpha = 0.12f) else Color(0xFF10B981).copy(alpha = 0.12f),
        label = "activeBgColor"
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.animateContentSize()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Icon(icon, contentDescription = null, tint = if (selectedItems.isNotEmpty()) activeColor else BluePrimary, modifier = Modifier.size(16.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (isExcluded && selectedItems.isNotEmpty()) RedError else Color(0xFF0F172A),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (onExcludedChange != null) {
                    Surface(
                        onClick = { onExcludedChange(!isExcluded) },
                        shape = RoundedCornerShape(12.dp),
                        color = activeBgColor,
                        border = androidx.compose.foundation.BorderStroke(1.dp, activeColor.copy(alpha = 0.4f)),
                        modifier = Modifier.animateContentSize()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Icon(
                                imageVector = if (isExcluded) Icons.Default.Block else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = activeColor,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = if (isExcluded) "استثناء ⛔" else "تضمين ✓",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = activeColor
                            )
                        }
                    }
                }
                if (selectedItems.isNotEmpty()) {
                    Text(
                        text = "مسح (${selectedItems.size})",
                        fontSize = 11.sp,
                        color = BluePrimary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { onClear() }
                    )
                }
            }
        }

        if (options.isEmpty()) {
            Text(
                text = "جاري تحميل الخيارات من قاعدة البيانات أو لا توجد تسجيلات...",
                fontSize = 11.sp,
                color = SlateTextMuted,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        } else {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                options.forEach { option ->
                    val isSelected = selectedItems.contains(option)
                    val chipBg by animateColorAsState(
                        targetValue = if (isSelected) activeBgColor else Color.White,
                        label = "chipBg"
                    )
                    val chipBorderColor by animateColorAsState(
                        targetValue = if (isSelected) activeColor else SlateCardBorder,
                        label = "chipBorder"
                    )
                    FilterChip(
                        selected = isSelected,
                        enabled = true,
                        onClick = { onToggle(option) },
                        label = {
                            Text(
                                text = option,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    imageVector = if (isExcluded) Icons.Default.Block else Icons.Default.Check,
                                    contentDescription = null,
                                    tint = activeColor,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = chipBg,
                            selectedLabelColor = activeColor,
                            selectedLeadingIconColor = activeColor
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = chipBorderColor,
                            selectedBorderColor = activeColor
                        )
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// شارة إحصائية تفاعلية في شريط النتائج
// -------------------------------------------------------------
@Composable
fun StatSummaryBadge(
    title: String,
    count: Int,
    color: Color,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) color.copy(alpha = 0.15f) else Slate50,
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) color else SlateCardBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = count.toString(), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = color)
            Text(text = title, fontSize = 10.sp, color = if (isSelected) color else SlateTextMuted, maxLines = 1)
        }
    }
}

// -------------------------------------------------------------
// بطاقة عرض الأسرة المرشحة وفقاً للألوان المحددة وحالة الأهلية
// -------------------------------------------------------------
@Composable
fun CandidateCardItem(
    candidate: DynamicCandidateModel,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    val (statusColor, statusBg, statusTitle) = when (candidate.status) {
        CandidateStatus.MATCHED_100 -> Triple(GreenSecondary, GreenSecondary.copy(alpha = 0.12f), "مطابقة 100%")
        CandidateStatus.WARNING -> Triple(AmberWarning, AmberWarning.copy(alpha = 0.12f), "تنبيه وملاحظة")
        CandidateStatus.EXCLUDED -> Triple(RedError, RedError.copy(alpha = 0.12f), "مستبعد من الترشيح")
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (candidate.status == CandidateStatus.MATCHED_100) GreenSecondary.copy(alpha = 0.4f) else SlateCardBorder),
        shadowElevation = 1.dp,
        modifier = modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // الصف العلوي: الاسم والحالة والدرجة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = candidate.family.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                    Text(
                        text = "هوية: ${candidate.family.nationalID} • ${candidate.localityName}",
                        fontSize = 11.sp,
                        color = SlateTextMuted
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusBg
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Text(
                            text = statusTitle,
                            color = statusColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // إظهار سبب الاستبعاد بخط صغير باللون الأحمر للعائلات المستبعدة
            if (candidate.status == CandidateStatus.EXCLUDED && candidate.exclusionReason != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = RedError.copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = RedError, modifier = Modifier.size(14.dp))
                        Text(
                            text = candidate.exclusionReason,
                            color = RedError,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // إظهار سبب التحذير باللون البرتقالي
            if (candidate.status == CandidateStatus.WARNING && candidate.warningReason != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = AmberWarning.copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(14.dp))
                        Text(
                            text = candidate.warningReason,
                            color = AmberWarning,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // الأيقونات الدلالية
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                QuickTag(
                    text = "الأفراد: ${candidate.family.familyMembersCount}",
                    icon = Icons.Default.Groups,
                    modifier = Modifier.weight(1f)
                )
                QuickTag(
                    text = "الأطفال: ${candidate.childrenCount}",
                    icon = Icons.Default.ChildCare,
                    modifier = Modifier.weight(1f)
                )
                QuickTag(
                    text = candidate.family.shelterStatus,
                    icon = Icons.Default.Home,
                    modifier = Modifier.weight(1f)
                )
            }

            // سجل تدقيق الترشيح المنزلق (Audit Trail)
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Slate50,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.FactCheck,
                                    contentDescription = null,
                                    tint = BluePrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "سجل تدقيق الترشيح (Audit Trail)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = BluePrimary
                                )
                            }
                            Text(
                                text = "درجة المطابقة: ${candidate.matchScore.toInt()}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusColor
                            )
                        }

                        HorizontalDivider(color = SlateCardBorder)

                        if (candidate.auditTrail.isNotEmpty()) {
                            candidate.auditTrail.forEach { trailStep ->
                                val stepColor = when {
                                    trailStep.startsWith("✓") -> GreenSecondary
                                    trailStep.startsWith("⚠") -> AmberWarning
                                    trailStep.startsWith("✗") -> RedError
                                    else -> SlateTextMuted
                                }
                                Row(
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "•",
                                        color = stepColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = trailStep,
                                        fontSize = 11.sp,
                                        color = if (stepColor != SlateTextMuted) stepColor else Color(0xFF334155),
                                        fontWeight = if (stepColor != SlateTextMuted) FontWeight.SemiBold else FontWeight.Normal
                                    )
                                }
                            }
                        }

                        HorizontalDivider(color = SlateCardBorder)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "اعتماد الأشغال: ${candidate.family.worksApproval}",
                                fontSize = 10.sp,
                                color = SlateTextMuted
                            )
                            Text(
                                text = "حالة الضرر: ${candidate.family.damageType}",
                                fontSize = 10.sp,
                                color = SlateTextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickTag(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = Slate50,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = null, tint = SlateTextMuted, modifier = Modifier.size(12.dp))
            Text(text = text, fontSize = 10.sp, color = Color(0xFF334155), maxLines = 1)
        }
    }
}

// -------------------------------------------------------------
// بطاقة التحميل النبضي (Shimmer Effect Card)
// -------------------------------------------------------------
@Composable
fun ShimmerCandidateCard() {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_offset"
    )

    val shimmerBrush = Brush.linearGradient(
        colors = listOf(
            Color(0xFFF1F5F9),
            Color(0xFFE2E8F0),
            Color(0xFFF1F5F9)
        ),
        start = Offset(translateAnim - 400f, translateAnim - 400f),
        end = Offset(translateAnim, translateAnim)
    )

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .height(18.dp)
                        .width(160.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(shimmerBrush)
                )
                Box(
                    modifier = Modifier
                        .height(18.dp)
                        .width(70.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(shimmerBrush)
                )
            }
            Box(
                modifier = Modifier
                    .height(14.dp)
                    .width(220.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(shimmerBrush)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(3) {
                    Box(
                        modifier = Modifier
                            .height(20.dp)
                            .width(65.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(shimmerBrush)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// شاشة بناء المعايير وإدارة الترشيح (CriteriaBuilderScreen)
// -------------------------------------------------------------
@Composable
fun CriteriaBuilderScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    nominationViewModel: NominationViewModel? = null,
    onNavigateToManualSelection: ((aidTypeId: Int, projectId: Long) -> Unit)? = null,
    onOpenProjectManager: (() -> Unit)? = null
) {
    if (nominationViewModel != null) {
        DynamicNominationScreen(
            repository = repository,
            nominationViewModel = nominationViewModel,
            onNavigateBack = onNavigateBack,
            onNavigateToManualSelection = onNavigateToManualSelection,
            onOpenProjectManager = onOpenProjectManager
        )
    } else {
        DynamicNominationScreen(
            repository = repository,
            onNavigateBack = onNavigateBack,
            onNavigateToManualSelection = onNavigateToManualSelection,
            onOpenProjectManager = onOpenProjectManager
        )
    }
}
