package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.*
import kotlinx.coroutines.launch

// -------------------------------------------------------------
// لوحة الألوان المحددة إلزامياً في هوية محرك الترشيح الحساس
// -------------------------------------------------------------
private val BluePrimary = Color(0xFF1976D2)       // أزرار رئيسية، عناوين، وحالة التحميل
private val GreenSecondary = Color(0xFF2E7D32)    // مطابقة 100% للشروط وزر اعتماد الترشيح
private val AmberWarning = Color(0xFFD97706)      // تنبيه المدير (استلام قريب / اقتراب الحصة)
private val RedError = Color(0xFFDC2626)          // العائلات المستبعدة وسبب الاستبعاد
private val Slate50 = Color(0xFFF8FAFC)           // لون خلفية الشاشة لراحة العين
private val SlateCardBorder = Color(0xFFE2E8F0)
private val SlateTextMuted = Color(0xFF64748B)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DynamicNominationScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToManualSelection: ((aidTypeId: Int, projectId: Long) -> Unit)? = null,
    onOpenProjectManager: (() -> Unit)? = null
) {
    val scope = rememberCoroutineScope()

    // البيانات المرجعية من المستودع
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val projects by repository.getActiveProjects().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())

    // ---------------------------------------------------------
    // حالة معايير محرك القواعد الديناميكي (Dynamic Rules State)
    // ---------------------------------------------------------
    var exclusionDaysText by remember { mutableStateOf("30") }
    var childrenFilterMode by remember { mutableStateOf(ChildrenFilterMode.IGNORE) }
    var minChildAgeText by remember { mutableStateOf("") }
    var maxChildAgeText by remember { mutableStateOf("") }

    // خيارات متعددة (Multi-select Sets)
    val selectedDamageTypes = remember { mutableStateSetOf<String>() }
    val selectedWorksApprovals = remember { mutableStateSetOf<String>() }
    val selectedShelterStatuses = remember { mutableStateSetOf<String>() }

    var selectedLocalityId by remember { mutableStateOf(0) } // 0 = كافة المحليات
    var selectedAidTypeId by remember { mutableStateOf(1) }
    var selectedProjectId by remember { mutableStateOf(1L) }
    var resultLimitText by remember { mutableStateOf("250") }

    // التحكم في طي وتمدد لوحة شروط الفلترة
    var isFiltersExpanded by remember { mutableStateOf(true) }

    // حالة المحرك والتنفيذ
    var isLoading by remember { mutableStateOf(false) }
    var nominationResult by remember { mutableStateOf<DynamicNominationResult?>(null) }
    var statusFilterTab by remember { mutableStateOf<CandidateStatus?>(null) } // null = الكل
    var searchQuery by remember { mutableStateOf("") }

    // نوافذ الاعتماد والحصص
    var showApprovalDialog by remember { mutableStateOf(false) }
    var showQuotasDialog by remember { mutableStateOf(false) }
    var approvalSuccessMessage by remember { mutableStateOf<String?>(null) }

    // تحديث المشروع التلقائي
    LaunchedEffect(projects) {
        if (projects.isNotEmpty() && projects.none { it.projectID == selectedProjectId }) {
            selectedProjectId = projects.first().projectID
            selectedAidTypeId = projects.first().aidTypeID
        }
    }

    // دالة تنفيذ محرك الترشيح البرمجي
    fun executeEngine() {
        val exclDays = exclusionDaysText.toIntOrNull()
        val minAge = minChildAgeText.toIntOrNull()
        val maxAge = maxChildAgeText.toIntOrNull()
        val limit = resultLimitText.toIntOrNull() ?: 250

        val criteria = DynamicNominationCriteria(
            exclusionDays = if (exclDays != null && exclDays > 0) exclDays else null,
            childrenFilter = childrenFilterMode,
            minChildAge = minAge,
            maxChildAge = maxAge,
            selectedDamageTypes = selectedDamageTypes.toSet(),
            selectedWorksApprovals = selectedWorksApprovals.toSet(),
            selectedShelterStatuses = selectedShelterStatuses.toSet(),
            selectedLocalityId = if (selectedLocalityId > 0) selectedLocalityId else null,
            selectedAidTypeId = selectedAidTypeId,
            projectId = selectedProjectId,
            limit = limit
        )

        scope.launch {
            isLoading = true
            isFiltersExpanded = false // طي تلقائي ناعم للوحة الشروط بعد الضغط لتوفير مساحة للنتائج
            try {
                val result = repository.runDynamicNomination(criteria)
                nominationResult = result
            } finally {
                isLoading = false
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Slate50,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "محرك الترشيح الديناميكي",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = BluePrimary
                                )
                                Surface(
                                    shape = CircleShape,
                                    color = BluePrimary.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "Dynamic Engine",
                                        color = BluePrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "فلترة مرنة متعددة الخيارات • ثوابت إجبارية • تقييم أهليّة لحظي",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextMuted,
                                fontSize = 11.sp
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = BluePrimary)
                        }
                    },
                    actions = {
                        if (onOpenProjectManager != null) {
                            IconButton(onClick = onOpenProjectManager) {
                                Icon(
                                    Icons.Default.DashboardCustomize,
                                    contentDescription = "طرح المشاريع والحصص",
                                    tint = BluePrimary
                                )
                            }
                        }
                        // زر التبديل السريع لطي وتمدد لوحة الشروط
                        IconButton(onClick = { isFiltersExpanded = !isFiltersExpanded }) {
                            Icon(
                                if (isFiltersExpanded) Icons.Default.FilterListOff else Icons.Default.FilterList,
                                contentDescription = "طي/تمدد الفلاتر",
                                tint = BluePrimary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                // شريط السفلي لاعتماد الترشيح باللون الأخضر المميز عند وجود نتائج مؤهلة
                val eligibleCount = nominationResult?.candidates?.count { it.status != CandidateStatus.EXCLUDED } ?: 0
                if (eligibleCount > 0 && !isLoading) {
                    Surface(
                        color = Color.White,
                        shadowElevation = 10.dp,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(GreenSecondary)
                                    )
                                    Text(
                                        text = "$eligibleCount عائلة مؤهلة للاعتماد",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = GreenSecondary
                                    )
                                }
                                Text(
                                    text = "جاهزون للترحيل المباشر إلى جدول المعتمدين",
                                    fontSize = 11.sp,
                                    color = SlateTextMuted
                                )
                            }

                            Button(
                                onClick = { showApprovalDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = GreenSecondary),
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                            ) {
                                Icon(Icons.Default.Verified, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("اعتماد الترشيح 🚀", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // -------------------------------------------------------------
                // 1. بطاقة الثوابت الإجبارية الصارمة (Mandatory Engine Rules)
                // -------------------------------------------------------------
                item {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                        shadowElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(18.dp))
                                    Text(
                                        text = "الثوابت الإجبارية لمنظومة المساعدات",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = BluePrimary
                                    )
                                }
                                Surface(
                                    color = GreenSecondary.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "مطبق آلياً وبشكل صارم",
                                        color = GreenSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    color = Slate50,
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GreenSecondary, modifier = Modifier.size(16.dp))
                                        Column {
                                            Text("حالة التنمية الاجتماعية", fontSize = 10.sp, color = SlateTextMuted)
                                            Text("معتمد 🔒", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                                        }
                                    }
                                }

                                Surface(
                                    modifier = Modifier.weight(1f),
                                    color = Slate50,
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GreenSecondary, modifier = Modifier.size(16.dp))
                                        Column {
                                            Text("حالة الإقامة", fontSize = 10.sp, color = SlateTextMuted)
                                            Text("مقيم 🔒", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // -------------------------------------------------------------
                // 2. لوحة شروط الفلترة المرنة القابلة للطي والتمدد (Expandable Criteria)
                // -------------------------------------------------------------
                item {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isFiltersExpanded) BluePrimary.copy(alpha = 0.4f) else SlateCardBorder),
                        shadowElevation = 2.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // ترويسة اللوحة وزر الطي/التمدد
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { isFiltersExpanded = !isFiltersExpanded },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(BluePrimary.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Tune, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                                    }
                                    Column {
                                        Text(
                                            text = "محددات وشروط الفلترة المرنة",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = BluePrimary
                                        )
                                        Text(
                                            text = if (isFiltersExpanded) "اضغط للطي وتوفير مساحة للنتائج" else "تم طي اللوحة • اضغط للتعديل وإعادة الضبط",
                                            fontSize = 11.sp,
                                            color = SlateTextMuted
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    val activeCount = listOf(
                                        exclusionDaysText.isNotBlank(),
                                        childrenFilterMode != ChildrenFilterMode.IGNORE,
                                        minChildAgeText.isNotBlank() || maxChildAgeText.isNotBlank(),
                                        selectedDamageTypes.isNotEmpty(),
                                        selectedWorksApprovals.isNotEmpty(),
                                        selectedShelterStatuses.isNotEmpty(),
                                        selectedLocalityId > 0
                                    ).count { it }

                                    if (activeCount > 0) {
                                        Surface(
                                            shape = CircleShape,
                                            color = BluePrimary
                                        ) {
                                            Text(
                                                text = "$activeCount شرط نشط",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Icon(
                                        if (isFiltersExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                        contentDescription = null,
                                        tint = BluePrimary
                                    )
                                }
                            }

                            // محتوى الشروط (يظهر عند التمدد فقط)
                            AnimatedVisibility(
                                visible = isFiltersExpanded,
                                enter = expandVertically() + fadeIn(),
                                exit = shrinkVertically() + fadeOut()
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    HorizontalDivider(color = SlateCardBorder)

                                    // أ) شرط الاستثناء الزمني: استثناء من استلم خلال X يوماً
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Icon(Icons.Default.HistoryToggleOff, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(16.dp))
                                                Text("استثناء من استلم خلال X يوماً:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                            if (exclusionDaysText.isNotBlank()) {
                                                Text(
                                                    text = "تجاهل الشرط",
                                                    fontSize = 11.sp,
                                                    color = BluePrimary,
                                                    fontWeight = FontWeight.SemiBold,
                                                    modifier = Modifier.clickable { exclusionDaysText = "" }
                                                )
                                            }
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedTextField(
                                                value = exclusionDaysText,
                                                onValueChange = { exclusionDaysText = it },
                                                label = { Text("عدد الأيام (فارغ = تجاهل)") },
                                                placeholder = { Text("مثال: 30") },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(10.dp),
                                                singleLine = true
                                            )

                                            // خيارات سريعة للأيام
                                            LazyRow(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                items(listOf("15", "30", "45", "60", "90")) { days ->
                                                    val isSelected = exclusionDaysText == days
                                                    FilterChip(
                                                        selected = isSelected,
                                                        onClick = { exclusionDaysText = if (isSelected) "" else days },
                                                        label = { Text("$days يوم", fontSize = 11.sp) },
                                                        shape = RoundedCornerShape(8.dp),
                                                        colors = FilterChipDefaults.filterChipColors(
                                                            selectedContainerColor = BluePrimary,
                                                            selectedLabelColor = Color.White
                                                        )
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    // ب) شرط وجود الأطفال ونطاق أعمارهم (من-إلى)
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Icon(Icons.Default.ChildCare, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(16.dp))
                                            Text("وجود أطفال بالأسرة:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            ChildrenFilterMode.values().forEach { mode ->
                                                val isSelected = childrenFilterMode == mode
                                                FilterChip(
                                                    selected = isSelected,
                                                    onClick = { childrenFilterMode = mode },
                                                    leadingIcon = {
                                                        if (isSelected) Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                                    },
                                                    label = { Text(mode.label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                                    shape = RoundedCornerShape(10.dp),
                                                    modifier = Modifier.weight(1f),
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        selectedContainerColor = BluePrimary,
                                                        selectedLabelColor = Color.White
                                                    )
                                                )
                                            }
                                        }

                                        // نطاق أعمار الأطفال (من-إلى)
                                        if (childrenFilterMode != ChildrenFilterMode.NO) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                OutlinedTextField(
                                                    value = minChildAgeText,
                                                    onValueChange = { minChildAgeText = it },
                                                    label = { Text("عمر الطفل (من)") },
                                                    placeholder = { Text("0") },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(10.dp),
                                                    singleLine = true
                                                )
                                                OutlinedTextField(
                                                    value = maxChildAgeText,
                                                    onValueChange = { maxChildAgeText = it },
                                                    label = { Text("عمر الطفل (إلى)") },
                                                    placeholder = { Text("18") },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(10.dp),
                                                    singleLine = true
                                                )
                                            }
                                        }
                                    }

                                    // ج) متعدد الخيارات لحالة الضرر (Multi-select Damage Types)
                                    MultiSelectSection(
                                        title = "حالة الضرر المسجل:",
                                        icon = Icons.Default.BrokenImage,
                                        options = listOf("أضرار كلية", "أضرار جزئية بليغة", "أضرار جزئية", "أضرار طفيفة", "غير متضرر"),
                                        selectedItems = selectedDamageTypes,
                                        onToggle = { option ->
                                            if (selectedDamageTypes.contains(option)) {
                                                selectedDamageTypes.remove(option)
                                            } else {
                                                selectedDamageTypes.add(option)
                                            }
                                        },
                                        onClear = { selectedDamageTypes.clear() }
                                    )

                                    // د) متعدد الخيارات لاعتماد الأشغال (Multi-select Works Approvals)
                                    MultiSelectSection(
                                        title = "اعتماد وزارة الأشغال:",
                                        icon = Icons.Default.DomainVerification,
                                        options = listOf("معتمد أشغال", "غير معتمد", "قيد التدقيق"),
                                        selectedItems = selectedWorksApprovals,
                                        onToggle = { option ->
                                            if (selectedWorksApprovals.contains(option)) {
                                                selectedWorksApprovals.remove(option)
                                            } else {
                                                selectedWorksApprovals.add(option)
                                            }
                                        },
                                        onClear = { selectedWorksApprovals.clear() }
                                    )

                                    // هـ) متعدد الخيارات لحالة الإيواء (Multi-select Shelter Statuses)
                                    MultiSelectSection(
                                        title = "حالة الإيواء:",
                                        icon = Icons.Default.HolidayVillage,
                                        options = listOf("إيواء داخلي (مراكز إيواء)", "إيواء خارجي / مخيمات", "مستضاف لدى أقارب", "منزل متضرر جزئياً"),
                                        selectedItems = selectedShelterStatuses,
                                        onToggle = { option ->
                                            if (selectedShelterStatuses.contains(option)) {
                                                selectedShelterStatuses.remove(option)
                                            } else {
                                                selectedShelterStatuses.add(option)
                                            }
                                        },
                                        onClear = { selectedShelterStatuses.clear() }
                                    )

                                    // و) تحديد المحلية ونوع المساعدة والحد الأقصى للنتائج
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("نطاق التوزيع الجغرافي:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        LazyRow(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            item {
                                                FilterChip(
                                                    selected = selectedLocalityId == 0,
                                                    onClick = { selectedLocalityId = 0 },
                                                    label = { Text("كافة المحليات", fontSize = 11.sp) },
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        selectedContainerColor = BluePrimary,
                                                        selectedLabelColor = Color.White
                                                    )
                                                )
                                            }
                                            items(localities) { loc ->
                                                val isSel = selectedLocalityId == loc.LocalityID
                                                FilterChip(
                                                    selected = isSel,
                                                    onClick = { selectedLocalityId = loc.LocalityID },
                                                    label = { Text(loc.LocalityName, fontSize = 11.sp) },
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        selectedContainerColor = BluePrimary,
                                                        selectedLabelColor = Color.White
                                                    )
                                                )
                                            }
                                        }
                                    }

                                    // ز) أزرار تطبيق الفلاتر وإعادة الضبط
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { executeEngine() },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                                        ) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("تطبيق فلاتر البحث ⚡", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                exclusionDaysText = ""
                                                childrenFilterMode = ChildrenFilterMode.IGNORE
                                                minChildAgeText = ""
                                                maxChildAgeText = ""
                                                selectedDamageTypes.clear()
                                                selectedWorksApprovals.clear()
                                                selectedShelterStatuses.clear()
                                                selectedLocalityId = 0
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.height(48.dp)
                                        ) {
                                            Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("إعادة ضبط", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }

                            // عند طي اللوحة، عرض شريط مصغر للبحث والتطبيق السريع
                            if (!isFiltersExpanded) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "المحددات مفعلة • انقر على تطبيق لتحديث المرشحين",
                                        fontSize = 11.sp,
                                        color = SlateTextMuted
                                    )
                                    Button(
                                        onClick = { executeEngine() },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تحديث النتائج", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // -------------------------------------------------------------
                // 3. تأثير التحميل النبضي الناعم (Shimmer Effect Cards)
                // -------------------------------------------------------------
                if (isLoading) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(color = BluePrimary, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "جاري تشغيل محرك الفلترة وحساب درجات المطابقة بأمان...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = BluePrimary
                                )
                            }
                            // 3 بطاقات Shimmer
                            repeat(3) {
                                ShimmerCandidateCard()
                            }
                        }
                    }
                }

                // -------------------------------------------------------------
                // 4. ملخص إحصائيات الترشيح وتبويبات الفرز التفاعلية
                // -------------------------------------------------------------
                if (!isLoading && nominationResult != null) {
                    val res = nominationResult!!

                    item {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                            shadowElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("نتائج محرك الترشيح:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0F172A))
                                    if (res.quotas.isNotEmpty()) {
                                        Text(
                                            text = "عرض الحصص الجغرافية 📊",
                                            color = BluePrimary,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.clickable { showQuotasDialog = true }
                                        )
                                    }
                                }

                                // بطاقات العدادات الأربعة الملونة بدقة الهوية المطلوبة
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    // 1. الكل
                                    StatSummaryBadge(
                                        title = "الإجمالي",
                                        count = res.candidates.size,
                                        color = BluePrimary,
                                        isSelected = statusFilterTab == null,
                                        modifier = Modifier.weight(1f)
                                    ) { statusFilterTab = null }

                                    // 2. مطابقة 100% (GreenSecondary)
                                    StatSummaryBadge(
                                        title = "مطابقة 100%",
                                        count = res.fullMatchCount,
                                        color = GreenSecondary,
                                        isSelected = statusFilterTab == CandidateStatus.MATCHED_100,
                                        modifier = Modifier.weight(1f)
                                    ) { statusFilterTab = CandidateStatus.MATCHED_100 }

                                    // 3. تنبيهات (AmberWarning)
                                    StatSummaryBadge(
                                        title = "تنبيهات",
                                        count = res.warningCount,
                                        color = AmberWarning,
                                        isSelected = statusFilterTab == CandidateStatus.WARNING,
                                        modifier = Modifier.weight(1f)
                                    ) { statusFilterTab = CandidateStatus.WARNING }

                                    // 4. مستبعدون (RedError)
                                    StatSummaryBadge(
                                        title = "مستبعدون",
                                        count = res.excludedCount,
                                        color = RedError,
                                        isSelected = statusFilterTab == CandidateStatus.EXCLUDED,
                                        modifier = Modifier.weight(1f)
                                    ) { statusFilterTab = CandidateStatus.EXCLUDED }
                                }

                                // حقل البحث السريع داخل النتائج
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    placeholder = { Text("بحث باسم رب الأسرة أو رقم الهوية...", fontSize = 12.sp) },
                                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SlateTextMuted) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true
                                )
                            }
                        }
                    }

                    // تصفية المرشحين المعروضين بناءً على التبويب والبحث
                    val filteredCandidates = res.candidates.filter { cand ->
                        val matchesStatus = statusFilterTab == null || cand.status == statusFilterTab
                        val matchesSearch = searchQuery.isBlank() ||
                                cand.family.familyHeadName.contains(searchQuery.trim(), ignoreCase = true) ||
                                cand.family.nationalID.contains(searchQuery.trim())
                        matchesStatus && matchesSearch
                    }

                    if (filteredCandidates.isEmpty()) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White,
                                border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Outlined.FolderOff, contentDescription = null, tint = SlateTextMuted, modifier = Modifier.size(36.dp))
                                    Text("لا توجد أسر تطابق معايير الفلترة المحددة في هذا التبويب", fontSize = 12.sp, color = SlateTextMuted)
                                }
                            }
                        }
                    } else {
                        // ---------------------------------------------------------
                        // 5. قائمة بطاقات العائلات المرشحة مع أنيميشن انزلاق ناعم
                        // ---------------------------------------------------------
                        items(filteredCandidates, key = { it.family.familyID }) { candidate ->
                            AnimatedVisibility(
                                visible = true,
                                enter = slideInVertically(
                                    initialOffsetY = { 40 },
                                    animationSpec = tween(durationMillis = 350)
                                ) + fadeIn(animationSpec = tween(durationMillis = 350))
                            ) {
                                CandidateCardItem(candidate = candidate)
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة اعتماد الترشيح الجماعي (Confirmation Dialog)
    if (showApprovalDialog && nominationResult != null) {
        val eligible = nominationResult!!.candidates.filter { it.status != CandidateStatus.EXCLUDED }
        AlertDialog(
            onDismissRequest = { showApprovalDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GreenSecondary)
                    Text("اعتماد ونقل قائمة المرشحين", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("أنت على وشك اعتماد وتثبيت ترشيح (${eligible.size}) أسرة مستحقة في جدول المواطنين المختارين (tbl_Selected_Citizens).")
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Slate50,
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("• مطابقة 100%: ${nominationResult!!.fullMatchCount} أسرة", fontSize = 12.sp, color = GreenSecondary, fontWeight = FontWeight.Bold)
                            Text("• حالات تنبيه وملاحظات: ${nominationResult!!.warningCount} أسرة", fontSize = 12.sp, color = AmberWarning, fontWeight = FontWeight.Bold)
                            Text("• سيتم استثناء العائلات المستبعدة تلقائياً (${nominationResult!!.excludedCount})", fontSize = 12.sp, color = RedError)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            val inserted = repository.approveDynamicNomination(
                                candidates = eligible,
                                projectId = selectedProjectId,
                                aidTypeId = selectedAidTypeId
                            )
                            showApprovalDialog = false
                            approvalSuccessMessage = "تم اعتماد $inserted أسرة بنجاح وترحيلها لجدول المعتمدين!"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenSecondary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("تأكيد الاعتماد والترحيل", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApprovalDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // نافذة إشعار نجاح الاعتماد
    if (approvalSuccessMessage != null) {
        AlertDialog(
            onDismissRequest = { approvalSuccessMessage = null },
            title = { Text("تم الاعتماد بنجاح", color = GreenSecondary, fontWeight = FontWeight.Bold) },
            text = { Text(approvalSuccessMessage ?: "") },
            confirmButton = {
                Button(
                    onClick = { approvalSuccessMessage = null },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenSecondary)
                ) {
                    Text("حسناً")
                }
            }
        )
    }

    // نافذة استعراض الحصص الجغرافية للمحليات
    if (showQuotasDialog && nominationResult != null) {
        AlertDialog(
            onDismissRequest = { showQuotasDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.PieChart, contentDescription = null, tint = BluePrimary)
                    Text("الحصص الجغرافية للمحليات", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("توزيع الحصص المحسوب رسمياً بخوارزمية أكبر الكسور المتبقية:", fontSize = 12.sp, color = SlateTextMuted)
                    nominationResult!!.quotas.forEach { quota ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Slate50,
                            border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(quota.localityName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("${quota.percentage}%", fontSize = 11.sp, color = SlateTextMuted)
                                    Text("${quota.allocatedCount} حصة", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = BluePrimary)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showQuotasDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)) {
                    Text("إغلاق")
                }
            }
        )
    }
}

// -------------------------------------------------------------
// مكون متعدد الخيارات (MultiSelectSection) للرقاقات التفاعلية
// -------------------------------------------------------------
@Composable
fun MultiSelectSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    options: List<String>,
    selectedItems: Set<String>,
    onToggle: (String) -> Unit,
    onClear: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(icon, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(16.dp))
                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
            if (selectedItems.isNotEmpty()) {
                Text(
                    text = "مسح (${selectedItems.size})",
                    fontSize = 11.sp,
                    color = BluePrimary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onClear() }
                )
            }
        }

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            options.forEach { option ->
                val isSelected = selectedItems.contains(option)
                FilterChip(
                    selected = isSelected,
                    onClick = { onToggle(option) },
                    leadingIcon = {
                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                        }
                    },
                    label = {
                        Text(
                            text = option,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = BluePrimary,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }
    }
}

// -------------------------------------------------------------
// شارة إحصائية تفاعلية في شريط النتائج
// -------------------------------------------------------------
@Composable
fun StatSummaryBadge(
    title: String,
    count: Int,
    color: Color,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) color.copy(alpha = 0.15f) else Slate50,
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) color else SlateCardBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = count.toString(), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = color)
            Text(text = title, fontSize = 10.sp, color = if (isSelected) color else SlateTextMuted, maxLines = 1)
        }
    }
}

// -------------------------------------------------------------
// بطاقة عرض الأسرة المرشحة وفقاً للألوان المحددة وحالة الأهلية
// -------------------------------------------------------------
@Composable
fun CandidateCardItem(candidate: DynamicCandidateModel) {
    var isExpanded by remember { mutableStateOf(false) }

    // تحديد اللون والرمز طبقاً للهوية البصرية الإلزامية:
    // GreenSecondary = مطابقة 100%
    // AmberWarning = تنبيه (استلام قريب أو اكتمال حصة)
    // RedError = مستبعد
    val (statusColor, statusBg, statusTitle) = when (candidate.status) {
        CandidateStatus.MATCHED_100 -> Triple(GreenSecondary, GreenSecondary.copy(alpha = 0.12f), "مطابقة 100%")
        CandidateStatus.WARNING -> Triple(AmberWarning, AmberWarning.copy(alpha = 0.12f), "تنبيه وملاحظة")
        CandidateStatus.EXCLUDED -> Triple(RedError, RedError.copy(alpha = 0.12f), "مستبعد من الترشيح")
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (candidate.status == CandidateStatus.MATCHED_100) GreenSecondary.copy(alpha = 0.4f) else SlateCardBorder),
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { isExpanded = !isExpanded }
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // الصف العلوي: الاسم والحالة والدرجة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = candidate.family.familyHeadName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "هوية: ${candidate.family.nationalID} • ${candidate.localityName}",
                        fontSize = 11.sp,
                        color = SlateTextMuted
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusBg
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Text(
                            text = statusTitle,
                            color = statusColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // إظهار سبب الاستبعاد بخط صغير باللون الأحمر (RedError) للعائلات المستبعدة
            if (candidate.status == CandidateStatus.EXCLUDED && candidate.exclusionReason != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = RedError.copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = RedError, modifier = Modifier.size(14.dp))
                        Text(
                            text = candidate.exclusionReason,
                            color = RedError,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // إظهار سبب التحذير باللون البرتقالي (AmberWarning)
            if (candidate.status == CandidateStatus.WARNING && candidate.warningReason != null) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = AmberWarning.copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.WarningAmber, contentDescription = null, tint = AmberWarning, modifier = Modifier.size(14.dp))
                        Text(
                            text = candidate.warningReason,
                            color = AmberWarning,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // تفاصيل موجزة سريعة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickTag(text = "الأفراد: ${candidate.family.familyMembersCount}", icon = Icons.Default.People)
                QuickTag(text = "الأطفال: ${candidate.childrenCount}", icon = Icons.Default.ChildCare)
                QuickTag(text = candidate.family.damageType, icon = Icons.Default.BrokenImage)
            }

            // تفاصيل موسعة عند الضغط على البطاقة
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    HorizontalDivider(color = SlateCardBorder)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("حالة الإيواء: ${candidate.family.shelterStatus}", fontSize = 11.sp, color = SlateTextMuted)
                        Text("اعتماد الأشغال: ${candidate.family.worksApproval}", fontSize = 11.sp, color = SlateTextMuted)
                    }
                    if (candidate.lastAidDate != null) {
                        Text(
                            text = "آخر مساعدة: ${candidate.lastAidTypeName ?: "معونة"} بتاريخ ${candidate.lastAidDate} (قبل ${candidate.daysSinceLastAid ?: "?"} يوماً)",
                            fontSize = 11.sp,
                            color = SlateTextMuted
                        )
                    } else {
                        Text("لم تسجل أي مساعدة سابقة لهذه الأسرة في النظام", fontSize = 11.sp, color = GreenSecondary)
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickTag(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = Slate50,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCBD5E1))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(icon, contentDescription = null, tint = SlateTextMuted, modifier = Modifier.size(12.dp))
            Text(text = text, fontSize = 10.sp, color = Color(0xFF334155))
        }
    }
}

// -------------------------------------------------------------
// بطاقة التحميل النبضي (Shimmer Effect Card)
// -------------------------------------------------------------
@Composable
fun ShimmerCandidateCard() {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val translateAnim by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_offset"
    )

    val shimmerBrush = Brush.linearGradient(
        colors = listOf(
            Color(0xFFF1F5F9),
            Color(0xFFE2E8F0),
            Color(0xFFF1F5F9)
        ),
        start = Offset(translateAnim - 400f, translateAnim - 400f),
        end = Offset(translateAnim, translateAnim)
    )

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White,
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .height(18.dp)
                        .width(160.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(shimmerBrush)
                )
                Box(
                    modifier = Modifier
                        .height(18.dp)
                        .width(70.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(shimmerBrush)
                )
            }
            Box(
                modifier = Modifier
                    .height(14.dp)
                    .width(220.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(shimmerBrush)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(3) {
                    Box(
                        modifier = Modifier
                            .height(20.dp)
                            .width(65.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(shimmerBrush)
                    )
                }
            }
        }
    }
}
