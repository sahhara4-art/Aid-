package com.humanitarian.aidmanagement.ui.screens.projects

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.ProjectBeneficiaryItem
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

/**
 * شاشة تفاصيل المشروع والمستفيدين (ProjectDetailsScreen)
 * تعرض قائمة بأسماء المستفيدين من هذا المشروع فقط
 * وتحتوي في أعلاها على:
 * 1. زر تصدير: لتصدير بيانات المستفيدين إلى ملف إكسل
 * 2. زر التسليم: للانتقال إلى شاشة تسليم المساعدات أو تأكيد التسليم
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailsScreen(
    projectId: Long,
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToDelivery: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var project by remember { mutableStateOf<ProjectEntity?>(null) }
    var beneficiaries by remember { mutableStateOf<List<ProjectBeneficiaryItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var isExporting by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("الكل") }
    var statusFilterTabs by remember { mutableStateOf<List<String>>(listOf("الكل")) }
    var beneficiaryToDelete by remember { mutableStateOf<ProjectBeneficiaryItem?>(null) }
    var projectToDelete by remember { mutableStateOf<ProjectEntity?>(null) }
    var showEditDialog by remember { mutableStateOf(false) }
    val aidTypes by repository.getActiveAidTypes().collectAsStateWithLifecycle(initialValue = emptyList())

    LaunchedEffect(projectId) {
        isLoading = true
        withContext(Dispatchers.IO) {
            project = repository.getProjectById(projectId)
            beneficiaries = repository.getProjectBeneficiaries(projectId)
            val distinctStatuses = repository.getDistinctAidRecordStatusesForProjectSync(projectId)
            statusFilterTabs = listOf("الكل") + distinctStatuses
        }
        isLoading = false
    }

    val filteredBeneficiaries = remember(beneficiaries, searchQuery, selectedFilter) {
        beneficiaries.filter { item ->
            val matchesFilter = if (selectedFilter == "الكل" || selectedFilter.isBlank()) {
                true
            } else {
                item.status.trim() == selectedFilter.trim()
            }
            val matchesSearch = if (searchQuery.isBlank()) true else {
                val q = searchQuery.trim().lowercase()
                item.familyName.lowercase().contains(q) ||
                item.nationalId.lowercase().contains(q) ||
                item.phone.lowercase().contains(q) ||
                item.subArea.lowercase().contains(q) ||
                (item.stageUserName?.lowercase()?.contains(q) == true)
            }
            matchesFilter && matchesSearch
        }
    }

    val deliveredCount = remember(beneficiaries) {
        beneficiaries.count { it.status.trim() == "مستفيد" }
    }
    val candidateCount = remember(beneficiaries) {
        beneficiaries.size
    }

    fun exportToExcel() {
        if (beneficiaries.isEmpty()) {
            Toast.makeText(context, "لا يوجد مستفيدون مسجلون في هذا المشروع للتصدير", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch(Dispatchers.IO) {
            isExporting = true
            try {
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val prjNameClean = (project?.projectName ?: "Project_$projectId").replace(" ", "_")
                val fileName = "Beneficiaries_${prjNameClean}_$timeStamp.csv"
                val exportDir = File(context.cacheDir, "exports")
                if (!exportDir.exists()) exportDir.mkdirs()
                val file = File(exportDir, fileName)

                FileWriter(file).use { writer ->
                    writer.append("\uFEFF") // UTF-8 BOM لدعم فتح اللغة العربية في Microsoft Excel
                    writer.append("دولة فلسطين - الهيئة الوطنية لإدارة وتوزيع المساعدات الإنسانية - قطاع غزة\n")
                    writer.append("كشف المستفيدين من مشروع: ${project?.projectName ?: ""} (رقم المشروع: ${project?.projectNumber ?: ""})\n")
                    writer.append("الجهة الممولة: ${project?.fundingInstitution ?: ""} | تاريخ المشروع: ${project?.projectDate ?: ""} | المستودع: ${project?.warehouseName ?: ""}\n")
                    writer.append("إجمالي المستهدف: ${project?.quantity ?: 0} | عدد المرشحين: $candidateCount | عدد المستلمين الفعليين: $deliveredCount\n\n")

                    // العناوين
                    writer.append("م,رقم الهوية الوطنية,اسم المستفيد الرباعي,رقم الجوال,المنطقة الفرعية,عدد أفراد الأسرة,حالة الاستلام,تاريخ التسليم,اسم الباحث أو المرشح\n")

                    beneficiaries.forEachIndexed { index, b ->
                        val escapedName = b.familyName.replace(",", " ")
                        val escapedSubArea = b.subArea.replace(",", " ")
                        val escapedUser = (b.stageUserName ?: "النظام").replace(",", " ")
                        val status = if (b.deliveryDate != null || b.status.contains("مستلم")) "مستلم" else "مرشح"
                        val deliveryDate = b.deliveryDate ?: "قيد التسليم"
                        writer.append("${index + 1},${b.nationalId},$escapedName,${b.phone},$escapedSubArea,${b.membersCount},$status,$deliveryDate,$escapedUser\n")
                    }
                }

                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "تم تصدير ملف الإكسل بنجاح: ${file.name}", Toast.LENGTH_LONG).show()
                    try {
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/csv"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة ملف كشف المستفيدين"))
                    } catch (e: Exception) {
                        // File created successfully in cache
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "خطأ أثناء تصدير ملف الإكسل: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                isExporting = false
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = project?.projectName ?: "تفاصيل المشروع",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (project != null) {
                                Text(
                                    text = "رقم المشروع: ${project!!.projectNumber} • ${beneficiaries.size} مستفيد",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        // 1. زر تصدير: لتصدير بيانات هؤلاء المستفيدين إلى ملف إكسل
                        FilledTonalButton(
                            onClick = { exportToExcel() },
                            enabled = !isExporting,
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = PalestineGreenContainer,
                                contentColor = PalestineGreen
                            )
                        ) {
                            if (isExporting) {
                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = PalestineGreen)
                            } else {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تصدير إكسل", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        // 2. زر التسليم: للانتقال إلى شاشة تسليم المساعدات أو تأكيد التسليم
                        Button(
                            onClick = onNavigateToDelivery,
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("شاشة التسليم", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        IconButton(
                            onClick = { showEditDialog = true }
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = "تعديل بيانات المشروع",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        IconButton(
                            onClick = { projectToDelete = project }
                        ) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "حذف المشروع",
                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = PalestineGreen)
                }
            } else if (project == null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    Text("لم يتم العثور على المشروع المحدد", style = MaterialTheme.typography.bodyLarge)
                }
            } else {
                val currentProject = project!!

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .padding(paddingValues)
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    // بطاقة ملخص تفاصيل المشروع العلوية
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = currentProject.projectName,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFFEF3C7)
                                ) {
                                    Text(
                                        text = currentProject.warehouseName,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF92400E),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "الممول: ${currentProject.fundingInstitution} • تاريخ البدء: ${currentProject.projectDate}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // إحصائيات المشروع
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(SlateSurfaceVariant)
                                    .padding(vertical = 8.dp, horizontal = 12.dp),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                BeneficiaryStatItem("المستهدف", "${currentProject.quantity}", MaterialTheme.colorScheme.onSurface)
                                Divider(modifier = Modifier.height(20.dp).width(1.dp), color = SlateBorder)
                                BeneficiaryStatItem("المرشحون", "$candidateCount", Color(0xFF2563EB))
                                Divider(modifier = Modifier.height(20.dp).width(1.dp), color = SlateBorder)
                                BeneficiaryStatItem("تم التسليم", "$deliveredCount", Color(0xFF059669))
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // حالة قفل المشروع وإمكانية الترشيح
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (currentProject.isLocked) Color(0xFFFEF2F2) else Color(0xFFF0FDF4))
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        if (currentProject.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                        contentDescription = null,
                                        tint = if (currentProject.isLocked) Color(0xFFDC2626) else Color(0xFF16A34A),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Column {
                                        Text(
                                            text = if (currentProject.isLocked) "المشروع مقفل (🔒) ومغلق للترشيح" else "المشروع مفتوح للترشيح (🔓)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = if (currentProject.isLocked) Color(0xFF991B1B) else Color(0xFF166534)
                                        )
                                        Text(
                                            text = if (currentProject.isLocked) "تم إيقاف إضافة ترشيحات جديدة للمشروع" else "متاح لإضافة وترشيح أسر مستحقة",
                                            fontSize = 9.sp,
                                            color = if (currentProject.isLocked) Color(0xFFB91C1C) else Color(0xFF15803D)
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(
                                        checked = currentProject.isLocked,
                                        onCheckedChange = { isChecked ->
                                            scope.launch(Dispatchers.IO) {
                                                repository.setProjectLocked(currentProject.projectID, isChecked)
                                                val updated = repository.getProjectById(currentProject.projectID)
                                                withContext(Dispatchers.Main) {
                                                    project = updated
                                                    Toast.makeText(
                                                        context,
                                                        if (isChecked) "تم إقفال المشروع وإيقاف الترشيح" else "تم فتح المشروع للترشيح بنجاح",
                                                        Toast.LENGTH_SHORT
                                                    ).show()
                                                }
                                            }
                                        },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color.White,
                                            checkedTrackColor = Color(0xFFDC2626),
                                            uncheckedThumbColor = Color.White,
                                            uncheckedTrackColor = Color(0xFF16A34A)
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                OutlinedButton(
                                    onClick = { showEditDialog = true },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp), tint = PalestineGreen)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تعديل بيانات المشروع", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PalestineGreen)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // مربع البحث وفلاتر الحالة
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("بحث باسم المستفيد، رقم الهوية، الجوال أو المنطقة...", fontSize = 13.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = PalestineGreen) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "مسح")
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // فلاتر التصنيف السريعة الديناميكية المستمدة من قاعدة البيانات
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(statusFilterTabs, key = { it }) { tab ->
                            FilterChip(
                                selected = selectedFilter == tab,
                                onClick = { selectedFilter = tab },
                                label = {
                                    val count = if (tab == "الكل") {
                                        candidateCount
                                    } else {
                                        beneficiaries.count { it.status.trim() == tab.trim() }
                                    }
                                    Text("$tab ($count)", fontWeight = if (selectedFilter == tab) FontWeight.Bold else FontWeight.Normal)
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PalestineGreen,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // قائمة بأسماء المستفيدين من هذا المشروع فقط
                    if (filteredBeneficiaries.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.GroupOff,
                                    contentDescription = null,
                                    modifier = Modifier.size(48.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "لا يوجد مستفيدون مطابقون للبحث في هذا المشروع",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .weight(1f),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(bottom = 24.dp)
                        ) {
                            items(items = filteredBeneficiaries, key = { it.recordId }) { item: ProjectBeneficiaryItem ->
                                BeneficiaryCardItem(
                                    item = item,
                                    onDelete = { beneficiaryToDelete = item }
                                )
                            }
                        }
                    }
                }
            }
        }

        if (beneficiaryToDelete != null) {
            com.humanitarian.aidmanagement.ui.components.TypeToConfirmDeleteDialog(
                title = "حذف المستفيد من المشروع نهائياً",
                itemTypeLabel = "المستفيد",
                expectedName = beneficiaryToDelete!!.familyName,
                onConfirm = {
                    val ben = beneficiaryToDelete!!
                    beneficiaryToDelete = null
                    scope.launch {
                        val updatedBeneficiaries = withContext(Dispatchers.IO) {
                            repository.deleteAidRecord(ben.recordId)
                            repository.getProjectBeneficiaries(projectId)
                        }
                        beneficiaries = updatedBeneficiaries
                    }
                },
                onDismiss = { beneficiaryToDelete = null }
            )
        }

        if (projectToDelete != null) {
            com.humanitarian.aidmanagement.ui.components.TypeToConfirmDeleteDialog(
                title = "حذف المشروع وسجلاته نهائياً",
                itemTypeLabel = "المشروع",
                expectedName = projectToDelete!!.projectName,
                onConfirm = {
                    val prj = projectToDelete!!
                    projectToDelete = null
                    scope.launch {
                        withContext(Dispatchers.IO) {
                            repository.deleteProject(prj.projectID)
                        }
                        onNavigateBack()
                    }
                },
                onDismiss = { projectToDelete = null }
            )
        }

        if (showEditDialog && project != null) {
            EditProjectDetailsDialog(
                project = project!!,
                aidTypes = aidTypes,
                onDismiss = { showEditDialog = false },
                onSave = { updated ->
                    scope.launch(Dispatchers.IO) {
                        repository.updateProject(updated)
                        val refreshed = repository.getProjectById(projectId)
                        withContext(Dispatchers.Main) {
                            project = refreshed
                            showEditDialog = false
                            Toast.makeText(context, "تم حفظ تعديلات المشروع بنجاح", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun BeneficiaryCardItem(
    item: ProjectBeneficiaryItem,
    onDelete: (() -> Unit)? = null
) {
    val isDelivered = item.deliveryDate != null || item.status.contains("مستلم") || item.status.contains("مستفيد")

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isDelivered) Color(0xFF10B981).copy(alpha = 0.3f) else SlateBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.familyName,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isDelivered) Color(0xFFD1FAE5) else Color(0xFFDBEAFE)
                    ) {
                        Text(
                            text = if (isDelivered) "مستلم فعلي" else "مرشح",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isDelivered) Color(0xFF065F46) else Color(0xFF1E40AF),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }

                    if (onDelete != null) {
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(32.dp).padding(start = 4.dp)
                        ) {
                            Icon(
                                Icons.Default.DeleteOutline,
                                contentDescription = "حذف المستفيد من المشروع",
                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "هوية: ${item.nationalId}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(text = "•", color = SlateBorder)
                Text(
                    text = "${item.membersCount} أفراد",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (item.subArea.isNotBlank()) {
                    Text(text = "•", color = SlateBorder)
                    Text(
                        text = item.subArea,
                        style = MaterialTheme.typography.bodySmall,
                        color = PalestineGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (item.phone.isNotBlank() || item.deliveryDate != null || item.stageUserName != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (item.phone.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = item.phone, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    if (item.deliveryDate != null) {
                        Text(
                            text = "تاريخ الاستلام: ${item.deliveryDate}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF059669)
                        )
                    } else if (item.stageUserName != null) {
                        Text(
                            text = "المرشح: ${item.stageUserName}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BeneficiaryStatItem(title: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = color)
        Text(text = title, fontSize = 10.sp, color = SlateTextMuted)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProjectDetailsDialog(
    project: ProjectEntity,
    aidTypes: List<AidTypeEntity>,
    onDismiss: () -> Unit,
    onSave: (ProjectEntity) -> Unit
) {
    var name by remember { mutableStateOf(project.projectName) }
    var funder by remember { mutableStateOf(project.fundingInstitution) }
    var selectedAidTypeId by remember { mutableStateOf(project.aidTypeID) }
    var warehouse by remember { mutableStateOf(project.warehouseName) }
    var quantityText by remember { mutableStateOf(project.quantity.toString()) }
    var isAidTypeExpanded by remember { mutableStateOf(false) }

    var aidTypeInputText by remember {
        mutableStateOf(aidTypes.find { it.aidTypeID == selectedAidTypeId }?.aidTypeName ?: "")
    }

    val filteredAidTypes = remember(aidTypeInputText, aidTypes) {
        if (aidTypeInputText.isBlank()) aidTypes
        else aidTypes.filter { it.aidTypeName.contains(aidTypeInputText, ignoreCase = true) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = PalestineGreen)
                Text("تعديل بيانات المشروع", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المشروع") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = funder,
                    onValueChange = { funder = it },
                    label = { Text("الجهة الممولة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // اختيار وتعديل نوع المساعدة عبر Editable ComboBox
                ExposedDropdownMenuBox(
                    expanded = isAidTypeExpanded,
                    onExpandedChange = { isAidTypeExpanded = !isAidTypeExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = aidTypeInputText,
                        onValueChange = {
                            aidTypeInputText = it
                            isAidTypeExpanded = true
                            val match = aidTypes.find { t -> t.aidTypeName.equals(it.trim(), ignoreCase = true) }
                            if (match != null) {
                                selectedAidTypeId = match.aidTypeID
                            }
                        },
                        readOnly = false,
                        label = { Text("نوع وتصنيف المساعدة (اختر أو اكتب جديداً) *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isAidTypeExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = isAidTypeExpanded && filteredAidTypes.isNotEmpty(),
                        onDismissRequest = { isAidTypeExpanded = false }
                    ) {
                        filteredAidTypes.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type.aidTypeName) },
                                onClick = {
                                    selectedAidTypeId = type.aidTypeID
                                    aidTypeInputText = type.aidTypeName
                                    isAidTypeExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = warehouse,
                    onValueChange = { warehouse = it },
                    label = { Text("المستودع / مركز التوزيع") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = quantityText,
                    onValueChange = { if (it.all { ch -> ch.isDigit() }) quantityText = it },
                    label = { Text("الحصة المستهدفة (الكمية)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = quantityText.toIntOrNull() ?: project.quantity
                    val updated = project.copy(
                        projectName = name.trim().ifBlank { project.projectName },
                        fundingInstitution = funder.trim().ifBlank { project.fundingInstitution },
                        aidTypeID = selectedAidTypeId,
                        warehouseName = warehouse.trim().ifBlank { project.warehouseName },
                        quantity = qty
                    )
                    onSave(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("حفظ التعديلات", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
