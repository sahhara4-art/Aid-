package com.humanitarian.aidmanagement.ui.screens.dashboard

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.data.repository.DashboardStats
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.sync.SyncUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/**
 * إدارة حالة تدفق بيانات لوحة القيادة بنمط Sealed Interface الحديث
 */
sealed interface DashboardUiState {
    object Loading : DashboardUiState
    data class Success(
        val stats: DashboardStats,
        val totalNomineesCount: Int = stats.totalNomineesCount,
        val actualRecipientsCount: Int = stats.actualRecipientsCount,
        val totalAidsCount: Int = stats.totalAidRecords,
        val localityStats: List<LocalityDistributionStat>,
        val aidTypeStats: List<AidTypeDistributionStat>,
        val injuryStats: List<KeyCountRecord>,
        val damageStats: List<KeyCountRecord>,
        val approvalStats: List<KeyCountRecord>,
        val residentStats: List<KeyCountRecord>,
        val categories: List<AidCategoryUi>,
        val aidCategories: List<String> = emptyList(),
        val activeProjects: List<ProjectEntity> = emptyList(),
        val fromDate: String,
        val toDate: String,
        val totalDeliveriesInPeriod: Int,
        val currentUser: UserEntity?
    ) : DashboardUiState
    data class Error(val message: String) : DashboardUiState
}

class DashboardViewModel(
    val repository: AidRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<DashboardUiState>(DashboardUiState.Loading)
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    // التدفقات التفاعلية المستقلة والمفصولة تماماً للمؤشرات الإحصائية
    val totalNomineesCount: StateFlow<Int> = repository.getTotalNomineesCountFlow()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val actualRecipientsCount: StateFlow<Int> = repository.getActualRecipientsCountFlow()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalAidsCount: StateFlow<Int> = repository.getTotalAidRecordsCountFlow()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _fromDate = MutableStateFlow("2026-01-01")
    val fromDate: StateFlow<String> = _fromDate.asStateFlow()

    private val _toDate = MutableStateFlow("2026-12-31")
    val toDate: StateFlow<String> = _toDate.asStateFlow()

    val syncState: StateFlow<SyncUiState> = repository.getSyncState()
    val currentUserFlow: StateFlow<UserEntity?> = repository.currentUserFlow
    val distinctAidCategoriesFlow: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val localities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { raw ->
            val clean = raw.filter { s -> s.isNotBlank() }
            if (repository.canManageAllLocalities()) listOf("الكل") + clean else clean
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    private var loadJob: Job? = null

    init {
        loadDashboardData()
        viewModelScope.launch {
            repository.currentUserFlow
                .drop(1)
                .collect {
                    loadDashboardData()
                }
        }
    }

    fun onDateRangeChanged(from: String, to: String) {
        if (_fromDate.value == from && _toDate.value == to) return
        _fromDate.value = from
        _toDate.value = to
        loadDashboardData()
    }

    fun loadDashboardData() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch(Dispatchers.IO) {
            _uiState.value = DashboardUiState.Loading
            try {
                val from = _fromDate.value
                val to = _toDate.value

                // كافة الأرقام والإحصائيات مستخرجة حصراً عبر استعلامات SQL الصارمة في Room بدون أي Hardcoded Data
                val currentStats = repository.getDashboardStats()
                val currentLocalityStats = repository.getLocalityDistributionStats()
                val currentAidTypeStats = repository.getAidTypeDistributionStats(from, to)
                val currentDeliveriesCount = repository.getDeliveredCountInDateRange(from, to)

                // التوزيعات الديناميكية المستخرجة حصراً عبر GROUP BY و COUNT
                val injuryStats = repository.getInjuryDistributionStats()
                val damageStats = repository.getWarDamageDistributionStats()
                val approvalStats = repository.getDevelopmentApprovalDistributionStats()
                val residentStats = repository.getResidentStatusDistributionStats()
                val distinctCategories = repository.getDistinctAidCategoriesSync()

                // تحويل بيانات أنواع المساعدات الحقيقية إلى عناصر واجهة (فقط الأنواع التي بها تسليمات فعلية، واستبعاد الصفر تماماً)
                val realCategories = currentAidTypeStats
                    .filter { it.deliveredCount > 0 }
                    .map { stat ->
                        val icon = when (stat.aidTypeId) {
                            1 -> Icons.Default.Restaurant
                            2 -> Icons.Default.Eco
                            3 -> Icons.Default.Fastfood
                            4 -> Icons.Default.Payments
                            5 -> Icons.Default.Checkroom
                            6 -> Icons.Default.LocalHospital
                            7 -> Icons.Default.Bed
                            8 -> Icons.Default.SoupKitchen
                            9 -> Icons.Default.ChildCare
                            10 -> Icons.Default.Shield
                            else -> Icons.Default.People
                        }
                        AidCategoryUi(
                            id = stat.aidTypeId,
                            name = stat.aidTypeName,
                            count = stat.deliveredCount,
                            icon = icon,
                            color = Color(stat.colorHex)
                        )
                    }

                // جلب المشاريع المفتوحة التي تتطلب ترشيحاً (المرشحون < العدد المطلوب والمشروع غير مقفل)
                val activeProjects = repository.getOpenProjectsNeedingNomination().first()

                _uiState.value = DashboardUiState.Success(
                    stats = currentStats,
                    totalNomineesCount = currentStats.totalNomineesCount,
                    actualRecipientsCount = currentStats.actualRecipientsCount,
                    totalAidsCount = currentStats.totalAidRecords,
                    localityStats = currentLocalityStats,
                    aidTypeStats = currentAidTypeStats,
                    injuryStats = injuryStats,
                    damageStats = damageStats,
                    approvalStats = approvalStats,
                    residentStats = residentStats,
                    categories = realCategories,
                    aidCategories = distinctCategories,
                    activeProjects = activeProjects,
                    fromDate = from,
                    toDate = to,
                    totalDeliveriesInPeriod = currentDeliveriesCount,
                    currentUser = repository.getCurrentUser()
                )
            } catch (e: Exception) {
                _uiState.value = DashboardUiState.Error(
                    message = "تعذر تحميل الإحصائيات: ${e.message}"
                )
            }
        }
    }

    fun refresh() {
        loadDashboardData()
    }

    fun resetFilters() {
        _fromDate.value = "2026-01-01"
        _toDate.value = "2026-12-31"
    }

    fun clearState() {
        loadJob?.cancel()
        resetFilters()
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DashboardViewModel(repository) as T
        }
    }
}
