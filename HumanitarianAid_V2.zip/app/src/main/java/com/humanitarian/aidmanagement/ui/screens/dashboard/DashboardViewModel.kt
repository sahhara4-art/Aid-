package com.humanitarian.aidmanagement.ui.screens.dashboard

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.data.repository.DashboardStats
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DashboardUiState(
    val stats: DashboardStats? = null,
    val localityStats: List<LocalityDistributionStat> = emptyList(),
    val aidTypeStats: List<AidTypeDistributionStat> = emptyList(),
    val categories: List<AidCategoryUi> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class DashboardViewModel(
    private val repository: AidRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        loadDashboardData()
    }

    fun loadDashboardData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                // كافة الأرقام والإحصائيات مستخرجة حصراً عبر استعلامات SQL الصارمة في Room
                val currentStats = repository.getDashboardStats()
                val currentLocalityStats = repository.getLocalityDistributionStats()
                val currentAidTypeStats = repository.getAidTypeDistributionStats()

                // تحويل بيانات أنواع المساعدات الحقيقية إلى عناصر واجهة دون أي أرقام وهمية
                val realCategories = currentAidTypeStats.map { stat ->
                    val icon = when (stat.aidTypeId) {
                        1 -> Icons.Default.Restaurant
                        2 -> Icons.Default.Eco
                        3 -> Icons.Default.Fastfood
                        4 -> Icons.Default.Payments
                        5 -> Icons.Default.Checkroom
                        6 -> Icons.Default.LocalHospital
                        7 -> Icons.Default.Bed
                        8 -> Icons.Default.SoupKitchen
                        9 -> Icons.Default.ChildCare
                        10 -> Icons.Default.Shield
                        else -> Icons.Default.People
                    }
                    AidCategoryUi(
                        id = stat.aidTypeId,
                        name = stat.aidTypeName,
                        count = stat.deliveredCount, // الرقم الحقيقي المعتمد من قاعدة البيانات
                        icon = icon,
                        color = Color(stat.colorHex)
                    )
                }

                _uiState.update {
                    it.copy(
                        stats = currentStats,
                        localityStats = currentLocalityStats,
                        aidTypeStats = currentAidTypeStats,
                        categories = realCategories,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "تعذر تحميل الإحصائيات: ${e.message}"
                    )
                }
            }
        }
    }

    fun refresh() {
        loadDashboardData()
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DashboardViewModel(repository) as T
        }
    }
}
