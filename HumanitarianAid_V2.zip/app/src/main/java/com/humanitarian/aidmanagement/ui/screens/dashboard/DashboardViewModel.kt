package com.humanitarian.aidmanagement.ui.screens.dashboard

import android.content.Context
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord
import com.humanitarian.aidmanagement.data.local.entities.FamilyComplaintEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.data.repository.DashboardStats
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.sync.SyncUiState
import com.humanitarian.aidmanagement.util.AidCategoryCatalog
import com.humanitarian.aidmanagement.util.DateNormalizationUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.PriorityQueue
import java.util.concurrent.TimeUnit

/**
 * إدارة حالة تدفق بيانات لوحة القيادة بنمط Sealed Interface الحديث
 */
sealed interface DashboardUiState {
    object Loading : DashboardUiState
    data class Success(
        val stats: DashboardStats,
        val totalNomineesCount: Int = stats.totalNomineesCount,
        val actualRecipientsCount: Int = stats.actualRecipientsCount,
        val totalAidsCount: Int = stats.totalAidRecords,
        val localityStats: List<LocalityDistributionStat>,
        val aidTypeStats: List<AidTypeDistributionStat>,
        val injuryStats: List<KeyCountRecord>,
        val damageStats: List<KeyCountRecord>,
        val approvalStats: List<KeyCountRecord>,
        val residentStats: List<KeyCountRecord>,
        val categories: List<AidCategoryUi>,
        val aidCategories: List<String> = emptyList(),
        val activeProjects: List<ProjectEntity> = emptyList(),
        val fromDate: String,
        val toDate: String,
        val totalDeliveriesInPeriod: Int,
        val currentUser: UserEntity?
    ) : DashboardUiState
    data class Error(val message: String) : DashboardUiState
}

data class ForgottenRadarUiState(
    val totalCount: Int = 0,
    val thresholdDays: Int = 60,
    val items: List<ForgottenFamilyItem> = emptyList(),
    val isLoading: Boolean = false,
    val lastActionMessage: String? = null
)

class DashboardViewModel(
    val repository: AidRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<DashboardUiState>(DashboardUiState.Loading)
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    private val _forgottenRadarState = MutableStateFlow(ForgottenRadarUiState())
    val forgottenRadarState: StateFlow<ForgottenRadarUiState> = _forgottenRadarState.asStateFlow()

    // التدفقات التفاعلية المستقلة والمفصولة تماماً للمؤشرات الإحصائية
    val totalNomineesCount: StateFlow<Int> = repository.getTotalNomineesCountFlow()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val actualRecipientsCount: StateFlow<Int> = repository.getActualRecipientsCountFlow()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalAidsCount: StateFlow<Int> = repository.getTotalAidRecordsCountFlow()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val currentYear: Int = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)

    private val _fromDate = MutableStateFlow("$currentYear-01-01")
    val fromDate: StateFlow<String> = _fromDate.asStateFlow()

    private val _toDate = MutableStateFlow("$currentYear-12-31")
    val toDate: StateFlow<String> = _toDate.asStateFlow()

    val syncState: StateFlow<SyncUiState> = repository.getSyncState()
    val currentUserFlow: StateFlow<UserEntity?> = repository.currentUserFlow
    val distinctAidCategoriesFlow: StateFlow<List<String>> = repository.getUnifiedAidCategoriesFlow()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val localities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { raw ->
            val clean = raw.filter { s -> s.isNotBlank() }
            if (repository.canManageAllLocalities()) listOf("الكل") + clean else clean
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aidCategories: StateFlow<List<String>> = repository.getUnifiedAidCategoriesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    private var loadJob: Job? = null
    private var radarJob: Job? = null

    init {
        loadDashboardData()
        viewModelScope.launch {
            repository.currentUserFlow
                .drop(1)
                .collect {
                    loadDashboardData()
                }
        }
        viewModelScope.launch {
            repository.getActiveAidTypes()
                .distinctUntilChanged()
                .drop(1)
                .collect {
                    loadDashboardData()
                }
        }
        viewModelScope.launch {
            repository.getActiveProjects()
                .distinctUntilChanged()
                .drop(1)
                .collect {
                    loadDashboardData()
                }
        }
    }

    fun onDateRangeChanged(from: String, to: String) {
        val normalizedFrom = DateNormalizationUtil.normalizeFilterBound(from, "$currentYear-01-01")
        val normalizedTo = DateNormalizationUtil.normalizeFilterBound(to, "$currentYear-12-31")
        if (_fromDate.value == normalizedFrom && _toDate.value == normalizedTo) return
        _fromDate.value = normalizedFrom
        _toDate.value = normalizedTo
        loadDashboardData()
    }

    fun loadDashboardData() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch(Dispatchers.IO) {
            _uiState.value = DashboardUiState.Loading
            try {
                val from = DateNormalizationUtil.normalizeFilterBound(_fromDate.value, "$currentYear-01-01")
                val to = DateNormalizationUtil.normalizeFilterBound(_toDate.value, "$currentYear-12-31")

                // كافة الأرقام والإحصائيات مستخرجة حصراً عبر استعلامات SQL في Room بدون أي بيانات ثابتة
                val currentStats = repository.getDashboardStats()
                val currentLocalityStats = repository.getLocalityDistributionStats()
                val currentAidTypeStats = repository.getAidTypeDistributionStats(from, to)
                val currentDeliveriesCount = repository.getDeliveredCountInDateRange(from, to)

                // التوزيعات الديناميكية المستخرجة حصراً عبر GROUP BY و COUNT
                val injuryStats = repository.getInjuryDistributionStats()
                val damageStats = repository.getWarDamageDistributionStats()
                val approvalStats = repository.getDevelopmentApprovalDistributionStats()
                val residentStats = repository.getResidentStatusDistributionStats()
                val distinctCategories = repository.getDistinctAidCategoriesSync()

                // تحويل كافة أنواع المساعدات الحقيقية من قاعدة البيانات إلى عناصر واجهة ديناميكية
                val realCategories = currentAidTypeStats
                    .filter { it.deliveredCount > 0 }
                    .map { stat ->
                        val name = stat.aidTypeName
                        val icon = when {
                            name.contains("غذاء") || name.contains("غذائي") || name.contains("سلة") || stat.aidTypeId == 1 -> Icons.Default.Restaurant
                            name.contains("خضار") || name.contains("فواكه") || stat.aidTypeId == 2 -> Icons.Default.Eco
                            name.contains("لحوم") || stat.aidTypeId == 3 -> Icons.Default.Fastfood
                            name.contains("نقد") || name.contains("مالي") || stat.aidTypeId == 4 -> Icons.Default.Payments
                            name.contains("كسوة") || name.contains("ملابس") || stat.aidTypeId == 5 -> Icons.Default.Checkroom
                            name.contains("صح") || name.contains("طبي") || name.contains("نظافة") || stat.aidTypeId == 6 -> Icons.Default.LocalHospital
                            name.contains("فرش") || name.contains("شادر") || name.contains("شوادر") || name.contains("إيواء") || stat.aidTypeId == 7 -> Icons.Default.Bed
                            name.contains("مطبخ") || name.contains("أواني") || stat.aidTypeId == 8 -> Icons.Default.SoupKitchen
                            name.contains("طفل") || name.contains("أطفال") || name.contains("بامبرز") || name.contains("حليب") || stat.aidTypeId == 9 -> Icons.Default.ChildCare
                            name.contains("فارس") || name.contains("تنمية") || stat.aidTypeId == 10 || stat.aidTypeId == 11 -> Icons.Default.VolunteerActivism
                            else -> Icons.Default.Category
                        }
                        AidCategoryUi(
                            id = stat.aidTypeId,
                            name = stat.aidTypeName,
                            count = stat.deliveredCount,
                            icon = icon,
                            color = Color(stat.colorHex)
                        )
                    }

                // جلب المشاريع المفتوحة التي تتطلب ترشيحاً
                val activeProjects = repository.getOpenProjectsNeedingNomination().first()

                _uiState.value = DashboardUiState.Success(
                    stats = currentStats,
                    totalNomineesCount = currentStats.totalNomineesCount,
                    actualRecipientsCount = currentStats.actualRecipientsCount,
                    totalAidsCount = currentStats.totalAidRecords,
                    localityStats = currentLocalityStats,
                    aidTypeStats = currentAidTypeStats,
                    injuryStats = injuryStats,
                    damageStats = damageStats,
                    approvalStats = approvalStats,
                    residentStats = residentStats,
                    categories = realCategories,
                    aidCategories = distinctCategories,
                    activeProjects = activeProjects,
                    fromDate = from,
                    toDate = to,
                    totalDeliveriesInPeriod = currentDeliveriesCount,
                    currentUser = repository.getCurrentUser()
                )
            } catch (e: Exception) {
                _uiState.value = DashboardUiState.Error(
                    message = "تعذر تحميل الإحصائيات: ${e.message}"
                )
            }
        }
    }

    fun loadForgottenRadar(
        context: Context,
        thresholdDays: Int = _forgottenRadarState.value.thresholdDays
    ) {
        val safeThreshold = thresholdDays.coerceIn(30, 120)
        val appContext = context.applicationContext
        radarJob?.cancel()
        radarJob = viewModelScope.launch(Dispatchers.IO) {
            _forgottenRadarState.update {
                it.copy(thresholdDays = safeThreshold, isLoading = true)
            }
            try {
                val snoozedIds = ForgottenRadarSnoozeStore.getActiveSnoozedIds(appContext)
                val nowMs = System.currentTimeMillis()
                val maxDisplayCount = 300
                val pageSize = 500
                var offset = 0
                var totalCount = 0

                // Min-heap محدودة بـ 300 عنصر فقط لحماية الذاكرة (256MB Heap)
                val topHeap = PriorityQueue<ForgottenFamilyItem>(
                    maxDisplayCount + 1,
                    compareBy<ForgottenFamilyItem> { effectiveDisconnectionDays(it.daysSinceLastAid) }
                        .thenByDescending { it.headName }
                )

                while (true) {
                    val chunk = repository.getFamiliesChunkSync(limit = pageSize, offset = offset)
                    if (chunk.isEmpty()) break
                    offset += chunk.size

                    val eligibleBatch = chunk.filter { fam ->
                        val isApproved = isApprovedFamilyStatus(fam.developmentApproval)
                        val isResident = isResidentFamilyStatus(fam.residentStatus)
                        val normalizedNatId = normalizeRadarDigits(fam.nationalID)
                        val isSnoozed = normalizedNatId.isNotBlank() && normalizedNatId in snoozedIds
                        isApproved && isResident && !isSnoozed
                    }

                    if (eligibleBatch.isNotEmpty()) {
                        val latestAidMap = repository.getLatestDeliveredAidDateMapForFamiliesSync(
                            eligibleBatch.map { it.familyID }
                        )

                        for (fam in eligibleBatch) {
                            val rawDate = latestAidMap[fam.familyID]?.trim().orEmpty()
                            val daysSince = calculateRadarDaysSinceAid(rawDate, nowMs)
                            if (daysSince < 0 || daysSince >= safeThreshold) {
                                totalCount++
                                val item = ForgottenFamilyItem(
                                    familyId = fam.familyID.toString(),
                                    headName = fam.name,
                                    nationalId = fam.nationalID,
                                    subRegion = fam.currentSubRegion,
                                    status = "${fam.developmentApproval.ifBlank { "معتمد" }} • ${fam.residentStatus.ifBlank { "مقيم" }}",
                                    daysSinceLastAid = daysSince,
                                    lastAidDateText = rawDate.ifBlank { "لم تستلم سابقاً" }
                                )
                                topHeap.offer(item)
                                if (topHeap.size > maxDisplayCount) {
                                    topHeap.poll()
                                }
                            }
                        }
                    }

                    if (chunk.size < pageSize) break
                }

                val sortedTopItems = topHeap.toList().sortedWith(
                    compareByDescending<ForgottenFamilyItem> { effectiveDisconnectionDays(it.daysSinceLastAid) }
                        .thenBy { it.headName }
                )

                _forgottenRadarState.update {
                    it.copy(
                        totalCount = totalCount,
                        thresholdDays = safeThreshold,
                        items = sortedTopItems,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _forgottenRadarState.update {
                    it.copy(
                        isLoading = false,
                        lastActionMessage = "تعذر تحديث رادار الأسر المنسية: ${e.message}"
                    )
                }
            }
        }
    }

    fun onRadarThresholdChanged(context: Context, newThresholdDays: Int) {
        if (newThresholdDays !in listOf(30, 60, 90, 120)) return
        loadForgottenRadar(context = context, thresholdDays = newThresholdDays)
    }

    fun snoozeForgottenFamilies(context: Context, nationalIds: List<String>) {
        if (nationalIds.isEmpty()) return
        val appContext = context.applicationContext
        viewModelScope.launch(Dispatchers.IO) {
            ForgottenRadarSnoozeStore.snoozeFamilies(appContext, nationalIds)
            _forgottenRadarState.update {
                it.copy(lastActionMessage = "تم تأجيل ${nationalIds.size} أسرة مؤقتاً لمدة 30 يوماً")
            }
            loadForgottenRadar(appContext, _forgottenRadarState.value.thresholdDays)
        }
    }

    fun transferForgottenFamiliesToComplaints(
        context: Context,
        families: List<ForgottenFamilyItem>,
        targetAidCategory: String
    ) {
        if (families.isEmpty()) return
        val appContext = context.applicationContext
        val cleanCategory = AidCategoryCatalog.cleanName(targetAidCategory).ifBlank { "غذائي" }
        val targetCategoryKey = AidCategoryCatalog.canonicalKey(cleanCategory)

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val complaintDao = repository.getDatabase().familyComplaintDao()
                val existingOpen = complaintDao.getAllOpenComplaintsSync()
                val existingPairs = existingOpen.map { open ->
                    normalizeRadarDigits(open.familyId) to AidCategoryCatalog.canonicalKey(open.targetAidCategory)
                }.toHashSet()

                var insertedCount = 0
                var skippedDuplicateCount = 0
                val now = System.currentTimeMillis()

                for (item in families) {
                    val familyIdentifier = item.nationalId.trim().ifBlank { item.familyId.trim() }
                    val pairKey = normalizeRadarDigits(familyIdentifier) to targetCategoryKey
                    if (pairKey in existingPairs) {
                        skippedDuplicateCount++
                        continue
                    }

                    val autoReason = if (item.daysSinceLastAid < 0) {
                        "رصد تلقائي من رادار الأسر المنسية (لم تستلم أي معونة مسبقاً)"
                    } else {
                        "رصد تلقائي من رادار الأسر المنسية (منقطعة منذ ${item.daysSinceLastAid} يوم)"
                    }

                    complaintDao.insertComplaint(
                        FamilyComplaintEntity(
                            familyId = familyIdentifier,
                            familyName = item.headName,
                            localArea = item.subRegion,
                            complaintReason = autoReason,
                            targetAidCategory = cleanCategory,
                            status = FamilyComplaintEntity.STATUS_OPEN,
                            createdAt = now,
                            nominatedProjectName = null
                        )
                    )
                    existingPairs.add(pairKey)
                    insertedCount++
                }

                val summaryMessage = when {
                    insertedCount > 0 && skippedDuplicateCount > 0 ->
                        "تم تحويل $insertedCount أسرة إلى الشكاوى ($cleanCategory) وتخطي $skippedDuplicateCount مكررة"
                    insertedCount > 0 ->
                        "تم تحويل $insertedCount أسرة بنجاح إلى قائمة الشكاوى والأولويات ($cleanCategory)"
                    else ->
                        "جميع الأسر المحددة لديها شكوى مفتوحة مسبقاً لنفس التصنيف ($cleanCategory)"
                }

                _forgottenRadarState.update { it.copy(lastActionMessage = summaryMessage) }
                loadForgottenRadar(appContext, _forgottenRadarState.value.thresholdDays)
            } catch (e: Exception) {
                _forgottenRadarState.update {
                    it.copy(lastActionMessage = "تعذر التحويل إلى الشكاوى: ${e.message}")
                }
            }
        }
    }

    fun clearRadarActionMessage() {
        _forgottenRadarState.update { it.copy(lastActionMessage = null) }
    }

    private fun isApprovedFamilyStatus(raw: String?): Boolean {
        val text = raw?.trim().orEmpty()
        if (text.isBlank()) return false
        return text.contains("معتمد") &&
            !text.contains("غير") &&
            !text.contains("مرفوض") &&
            !text.contains("معلق")
    }

    private fun isResidentFamilyStatus(raw: String?): Boolean {
        val text = raw?.trim().orEmpty()
        if (text.isBlank()) return false
        return text.contains("مقيم") &&
            !text.contains("غير") &&
            !text.contains("مغادر") &&
            !text.contains("متوف")
    }

    private fun effectiveDisconnectionDays(daysSinceLastAid: Int): Int {
        return if (daysSinceLastAid < 0) Int.MAX_VALUE else daysSinceLastAid
    }

    private fun normalizeRadarDigits(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return ""
        val sb = StringBuilder(trimmed.length)
        for (ch in trimmed) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun calculateRadarDaysSinceAid(rawDate: String?, nowMs: Long): Int {
        val clean = rawDate?.trim().orEmpty()
        if (clean.isBlank()) return -1
        val datePart = clean.take(10)
        val patterns = listOf("yyyy-MM-dd", "dd/MM/yyyy", "yyyy/MM/dd", "dd-MM-yyyy")
        for (pattern in patterns) {
            val parsed = runCatching {
                SimpleDateFormat(pattern, Locale.US).apply { isLenient = false }.parse(datePart)
            }.getOrNull()
            if (parsed != null) {
                val diffMs = (nowMs - parsed.time).coerceAtLeast(0L)
                return TimeUnit.MILLISECONDS.toDays(diffMs).toInt()
            }
        }
        return -1
    }

    fun refresh() {
        loadDashboardData()
    }

    fun resetFilters() {
        _fromDate.value = "$currentYear-01-01"
        _toDate.value = "$currentYear-12-31"
    }

    fun clearState() {
        loadJob?.cancel()
        radarJob?.cancel()
        resetFilters()
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DashboardViewModel(repository) as T
        }
    }
}
