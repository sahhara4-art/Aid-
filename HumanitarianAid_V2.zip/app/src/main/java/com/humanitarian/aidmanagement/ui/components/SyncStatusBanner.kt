package com.humanitarian.aidmanagement.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.repository.AidRepository

@Composable
fun SyncStatusBanner(
    repository: AidRepository,
    onOpenSyncDetails: () -> Unit,
    modifier: Modifier = Modifier
) {
    val syncState by repository.getSyncState().collectAsStateWithLifecycle()

    AnimatedVisibility(
        visible = !syncState.isOnline || syncState.isSyncing || syncState.pendingCount > 0,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
        modifier = modifier
    ) {
        val bgColor = when {
            syncState.isSyncing -> Color(0xFFEFF6FF)
            !syncState.isOnline -> Color(0xFFFFF4E5)
            else -> Color(0xFFECFDF5)
        }
        val borderColor = when {
            syncState.isSyncing -> Color(0xFF93C5FD)
            !syncState.isOnline -> Color(0xFFF5C26B)
            else -> Color(0xFFA7F3D0)
        }
        val contentColor = when {
            syncState.isSyncing -> Color(0xFF1D4ED8)
            !syncState.isOnline -> Color(0xFF9A5B00)
            else -> Color(0xFF047857)
        }
        val statusIcon = when {
            syncState.isSyncing -> Icons.Default.Sync
            !syncState.isOnline -> Icons.Default.CloudOff
            else -> Icons.Default.CloudDone
        }
        val singleLineMessage = when {
            syncState.isSyncing -> "جاري التزامن السحابي (${syncState.pendingCount} عملية)"
            !syncState.isOnline -> if (syncState.pendingCount > 0) {
                "وضع عدم الاتصال • ${syncState.pendingCount} عملية بانتظار المزامنة"
            } else {
                "وضع عدم الاتصال • العمل مستمر محلياً"
            }
            else -> "متصل • ${syncState.pendingCount} عملية بانتظار المزامنة"
        }

        Surface(
            color = bgColor,
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, borderColor),
            shadowElevation = 0.dp,
            tonalElevation = 0.dp,
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clickable { onOpenSyncDetails() }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = statusIcon,
                        contentDescription = null,
                        tint = contentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = singleLineMessage,
                        color = contentColor,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "تفاصيل",
                    color = contentColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clickable { onOpenSyncDetails() }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                )
            }
        }
    }
}
