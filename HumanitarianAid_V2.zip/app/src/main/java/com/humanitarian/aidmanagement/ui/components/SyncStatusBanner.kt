package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.sync.SyncStatus

@Composable
fun SyncStatusBanner(
    status: SyncStatus,
    pendingCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, icon) = when (status) {
        SyncStatus.IDLE -> Triple(Color(0xFFF1F5F9), Color(0xFF475569), Icons.Default.CloudDone)
        SyncStatus.SYNCING -> Triple(Color(0xFFE0F2FE), Color(0xFF0369A1), Icons.Default.Sync)
        SyncStatus.SUCCESS -> Triple(Color(0xFFDCFCE7), Color(0xFF15803D), Icons.Default.CloudDone)
        SyncStatus.ERROR -> Triple(Color(0xFFFEE2E2), Color(0xFFB91C1C), Icons.Default.CloudOff)
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(bgColor, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, contentDescription = null, tint = textColor, modifier = Modifier.size(16.dp))
            Text(
                text = if (status == SyncStatus.SYNCING) "جارٍ المزامنة السحابية..." else "حالة النظام: متصل محلياً",
                color = textColor,
                fontSize = 12.sp
            )
        }
        if (pendingCount > 0) {
            Text("$pendingCount معلق", color = textColor, fontSize = 11.sp)
        }
    }
}
