package com.humanitarian.aidmanagement.ui.screens.projects

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.launch

private val ExportBgGradient = listOf(
    Color(0xFF071324),
    Color(0xFF0C2636),
    Color(0xFF0A3832),
    Color(0xFF091625)
)

private val GlassCardFill = Color.White.copy(alpha = 0.10f)
private val GlassCardHighlight = Color.White.copy(alpha = 0.15f)
private val GlassCardSubtleFill = Color.White.copy(alpha = 0.06f)
private val GlassBorderWhite = Color.White.copy(alpha = 0.34f)
private val GlassBorderSoft = Color.White.copy(alpha = 0.18f)

private val EmeraldAccent = Color(0xFF10B981)
private val EmeraldGlow = Color(0xFF34D399)
private val SkyAccent = Color(0xFF38BDF8)
private val AmberAccent = Color(0xFFFBBF24)
private val RoseAccent = Color(0xFFFB7185)

@Composable
fun ExportProjectScreen(
    projectId: Long,
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    exportViewModel: ExportProjectViewModel = viewModel(
        factory = ExportProjectViewModelFactory(projectId, repository)
    )
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val uiState by exportViewModel.uiState.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    fun handlePickedUri(uri: Uri?) {
        if (uri == null) return
        scope.launch {
            val result = exportViewModel.exportToUri(context, uri)
            result.onSuccess { msg ->
                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            }.onFailure { err ->
                Toast.makeText(context, err.message ?: "تعذر إتمام التصدير", Toast.LENGTH_LONG).show()
            }
        }
    }

    val xlsxLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(ProjectExportFormat.XLSX.mimeType)
    ) { uri -> handlePickedUri(uri) }

    val csvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(ProjectExportFormat.CSV.mimeType)
    ) { uri -> handlePickedUri(uri) }

    val pdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(ProjectExportFormat.PDF.mimeType)
    ) { uri -> handlePickedUri(uri) }

    fun launchSafDocumentPicker() {
        if (uiState.selectedFamilyFields.isEmpty()) {
            Toast.makeText(
                context,
                "يرجى اختيار حقل واحد على الأقل من بيانات الأسرة الأساسية",
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        if (uiState.beneficiariesCount == 0) {
            Toast.makeText(
                context,
                "لا توجد أسر مستفيدة أو مرشحة في هذا المشروع للتصدير",
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        val suggestedName = exportViewModel.suggestedFileName()
        when (uiState.selectedFormat) {
            ProjectExportFormat.XLSX -> xlsxLauncher.launch(suggestedName)
            ProjectExportFormat.CSV -> csvLauncher.launch(suggestedName)
            ProjectExportFormat.PDF -> pdfLauncher.launch(suggestedName)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(colors = ExportBgGradient))
        ) {
            // إضاءة محيطية ناعمة لإبراز العمق الزجاجي (Glassmorphism Ambient Glow)
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF10B981).copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.12f),
                        radius = size.width * 0.65f
                    ),
                    radius = size.width * 0.65f,
                    center = Offset(size.width * 0.85f, size.height * 0.12f)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF0284C7).copy(alpha = 0.18f), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.55f),
                        radius = size.width * 0.55f
                    ),
                    radius = size.width * 0.55f,
                    center = Offset(size.width * 0.15f, size.height * 0.55f)
                )
            }

            Column(modifier = Modifier.fillMaxSize()) {
                // الترويسة الزجاجية العلوية
                ExportGlassHeader(
                    projectName = uiState.project?.projectName ?: "المشروع #$projectId",
                    projectNumber = uiState.project?.projectNumber ?: "",
                    beneficiariesCount = uiState.beneficiariesCount,
                    onNavigateBack = onNavigateBack
                )

                if (uiState.isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(color = EmeraldGlow)
                            Text(
                                text = "جاري تحميل بيانات الأسر والمشروع...",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 13.sp
                            )
                        }
                    }
                } else if (uiState.project == null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            shape = RoundedCornerShape(24.dp),
                            color = GlassCardFill,
                            border = BorderStroke(1.dp, GlassBorderWhite)
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ErrorOutline,
                                    contentDescription = null,
                                    tint = RoseAccent,
                                    modifier = Modifier.size(40.dp)
                                )
                                Text(
                                    text = "لم يتم العثور على بيانات المشروع المحدد",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Button(
                                    onClick = onNavigateBack,
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent)
                                ) {
                                    Text("العودة", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .verticalScroll(scrollState)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // بطاقة توضيحية لنظام الكيان الأساسي (Root Entity + Left Join)
                        RootEntityOverviewGlassBanner(
                            aidTypeName = uiState.aidTypeName,
                            funder = uiState.project?.fundingInstitution.orEmpty(),
                            beneficiariesCount = uiState.beneficiariesCount
                        )

                        // القسم 1: بيانات الأسرة الأساسية (مفتوح افتراضياً)
                        ExpandableGlassCard(
                            title = "بيانات الأسرة الأساسية",
                            subtitle = "الكيان الأساسي (Root Entity) — رب الأسرة والاتصال والسكن",
                            icon = Icons.Rounded.FamilyRestroom,
                            accentColor = EmeraldGlow,
                            selectedBadge = "${uiState.selectedFamilyFields.size} حقل",
                            initiallyExpanded = true
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
                                ) {
                                    GlassMiniActionChip(
                                        text = "تحديد الكل",
                                        accent = EmeraldGlow,
                                        onClick = { exportViewModel.selectAllFamilyFields() }
                                    )
                                    GlassMiniActionChip(
                                        text = "الحقول الأساسية فقط",
                                        accent = SkyAccent,
                                        onClick = { exportViewModel.clearFamilyFields() }
                                    )
                                }

                                FieldCheckboxGrid(
                                    options = ExportProjectUiState.FAMILY_FIELD_OPTIONS,
                                    selectedKeys = uiState.selectedFamilyFields,
                                    enabled = true,
                                    accentColor = EmeraldGlow,
                                    onToggle = { exportViewModel.toggleFamilyField(it) }
                                )
                            }
                        }

                        // القسم 2: بيانات الأبناء (مغلق افتراضياً)
                        ExpandableGlassCard(
                            title = "بيانات الأبناء (Left Join)",
                            subtitle = if (uiState.includeChildren) {
                                "مفعّل • ابن واحد مطابق (${uiState.childMinAge} - ${uiState.childMaxAge} سنة)"
                            } else {
                                "معطّل • دمج ابن واحد مطابق للأسرة حسب العمر إن وجد"
                            },
                            icon = Icons.Rounded.ChildCare,
                            accentColor = SkyAccent,
                            selectedBadge = if (uiState.includeChildren) "${uiState.selectedChildFields.size} حقل" else "مغلق",
                            initiallyExpanded = false
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                // مفتاح تفعيل دمج الأبناء
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (uiState.includeChildren) SkyAccent.copy(alpha = 0.16f) else GlassCardSubtleFill,
                                    border = BorderStroke(
                                        1.dp,
                                        if (uiState.includeChildren) SkyAccent.copy(alpha = 0.6f) else GlassBorderSoft
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable { exportViewModel.setIncludeChildren(!uiState.includeChildren) }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "تفعيل دمج الأبناء مع بيانات الأسرة",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = "يُصدر ابن واحد مطابق للفئة العمرية إن وجد (Left Join)",
                                                color = Color.White.copy(alpha = 0.72f),
                                                fontSize = 11.sp
                                            )
                                        }
                                        Switch(
                                            checked = uiState.includeChildren,
                                            onCheckedChange = { exportViewModel.setIncludeChildren(it) },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = Color.White,
                                                checkedTrackColor = SkyAccent,
                                                uncheckedThumbColor = Color.White.copy(alpha = 0.8f),
                                                uncheckedTrackColor = Color.White.copy(alpha = 0.2f)
                                            )
                                        )
                                    }
                                }

                                // تحديد فئة العمر (من - إلى)
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = "فئة العمر المستهدفة للابن (بالسنوات):",
                                        color = Color.White.copy(alpha = if (uiState.includeChildren) 0.92f else 0.45f),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        GlassAgeInputField(
                                            label = "من عمر",
                                            value = uiState.childMinAge,
                                            enabled = uiState.includeChildren,
                                            onValueChange = { exportViewModel.updateChildMinAge(it) },
                                            modifier = Modifier.weight(1f)
                                        )
                                        GlassAgeInputField(
                                            label = "إلى عمر",
                                            value = uiState.childMaxAge,
                                            enabled = uiState.includeChildren,
                                            onValueChange = { exportViewModel.updateChildMaxAge(it) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }

                                    // اختصارات سريعة للفئات العمرية
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        listOf(
                                            "0 - 5" to (0 to 5),
                                            "6 - 12" to (6 to 12),
                                            "13 - 18" to (13 to 18),
                                            "0 - 18" to (0 to 18)
                                        ).forEach { (label, range) ->
                                            val isSelectedRange = uiState.childMinAge == range.first.toString() &&
                                                uiState.childMaxAge == range.second.toString()
                                            Surface(
                                                shape = RoundedCornerShape(10.dp),
                                                color = if (isSelectedRange && uiState.includeChildren) {
                                                    SkyAccent.copy(alpha = 0.26f)
                                                } else {
                                                    GlassCardSubtleFill
                                                },
                                                border = BorderStroke(
                                                    1.dp,
                                                    if (isSelectedRange && uiState.includeChildren) {
                                                        SkyAccent.copy(alpha = 0.7f)
                                                    } else {
                                                        GlassBorderSoft
                                                    }
                                                ),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .clickable(enabled = uiState.includeChildren) {
                                                        exportViewModel.updateChildMinAge(range.first.toString())
                                                        exportViewModel.updateChildMaxAge(range.second.toString())
                                                    }
                                            ) {
                                                Text(
                                                    text = label,
                                                    color = Color.White.copy(alpha = if (uiState.includeChildren) 0.9f else 0.4f),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    textAlign = TextAlign.Center,
                                                    modifier = Modifier.padding(vertical = 6.dp)
                                                )
                                            }
                                        }
                                    }
                                }

                                HorizontalDivider(color = GlassBorderSoft)

                                Text(
                                    text = "حقول الابن المطلوب تضمينها:",
                                    color = Color.White.copy(alpha = if (uiState.includeChildren) 0.92f else 0.45f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )

                                FieldCheckboxGrid(
                                    options = ExportProjectUiState.CHILD_FIELD_OPTIONS,
                                    selectedKeys = uiState.selectedChildFields,
                                    enabled = uiState.includeChildren,
                                    accentColor = SkyAccent,
                                    onToggle = { exportViewModel.toggleChildField(it) }
                                )
                            }
                        }

                        // القسم 3: بيانات المشروع (مغلق افتراضياً)
                        ExpandableGlassCard(
                            title = "بيانات المشروع والصرف",
                            subtitle = "اسم المشروع، تاريخ التسليم، الممول، وحالة الاستلام",
                            icon = Icons.Rounded.FolderSpecial,
                            accentColor = AmberAccent,
                            selectedBadge = "${uiState.selectedProjectFields.size} حقل",
                            initiallyExpanded = false
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)
                                ) {
                                    GlassMiniActionChip(
                                        text = "تحديد الكل",
                                        accent = AmberAccent,
                                        onClick = { exportViewModel.selectAllProjectFields() }
                                    )
                                    GlassMiniActionChip(
                                        text = "مسح الكل",
                                        accent = RoseAccent,
                                        onClick = { exportViewModel.clearProjectFields() }
                                    )
                                }

                                FieldCheckboxGrid(
                                    options = ExportProjectUiState.PROJECT_FIELD_OPTIONS,
                                    selectedKeys = uiState.selectedProjectFields,
                                    enabled = true,
                                    accentColor = AmberAccent,
                                    onToggle = { exportViewModel.toggleProjectField(it) }
                                )
                            }
                        }

                        // القسم 4: اختيار صيغة الملف (Segmented Buttons زجاجية)
                        ExportFormatSelectorGlassCard(
                            selectedFormat = uiState.selectedFormat,
                            onSelectFormat = { exportViewModel.selectFormat(it) }
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    // الشريط السفلي الثابت لزر الحفظ والتصدير عبر SAF
                    ExportBottomSafBar(
                        uiState = uiState,
                        totalSelectedColumns = exportViewModel.totalSelectedColumnsCount(),
                        onDismissMessages = { exportViewModel.clearMessages() },
                        onClickExport = { launchSafDocumentPicker() }
                    )
                }
            }
        }
    }
}

@Composable
private fun ExportGlassHeader(
    projectName: String,
    projectNumber: String,
    beneficiariesCount: Int,
    onNavigateBack: () -> Unit
) {
    Surface(
        color = Color.White.copy(alpha = 0.09f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.28f)),
        shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f))
                        .border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ArrowForward,
                        contentDescription = "رجوع",
                        tint = Color.White
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "التصدير المخصص المتقدم",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = buildString {
                            append(projectName)
                            if (projectNumber.isNotBlank()) append(" • #$projectNumber")
                        },
                        color = Color.White.copy(alpha = 0.74f),
                        fontSize = 11.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = EmeraldAccent.copy(alpha = 0.22f),
                border = BorderStroke(1.dp, EmeraldGlow.copy(alpha = 0.55f))
            ) {
                Text(
                    text = "$beneficiariesCount أسرة",
                    color = Color(0xFFA7F3D0),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun RootEntityOverviewGlassBanner(
    aidTypeName: String,
    funder: String,
    beneficiariesCount: Int
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = GlassCardHighlight,
        border = BorderStroke(1.dp, GlassBorderWhite),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(EmeraldAccent.copy(alpha = 0.22f))
                    .border(1.dp, EmeraldGlow.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.AccountTree,
                    contentDescription = null,
                    tint = EmeraldGlow,
                    modifier = Modifier.size(22.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "بنية التصدير: الأسرة أساس الكشف (Left Join)",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    text = buildString {
                        append("$beneficiariesCount مستفيد")
                        if (aidTypeName.isNotBlank()) append(" • $aidTypeName")
                        if (funder.isNotBlank()) append(" • $funder")
                    },
                    color = Color.White.copy(alpha = 0.76f),
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun ExpandableGlassCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    selectedBadge: String,
    initiallyExpanded: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by remember { mutableStateOf(initiallyExpanded) }
    val chevronRotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(220),
        label = "chevronRotation"
    )
    val cardBg by animateColorAsState(
        targetValue = if (expanded) GlassCardHighlight else GlassCardFill,
        animationSpec = tween(220),
        label = "cardBg"
    )

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = cardBg,
        border = BorderStroke(1.dp, GlassBorderWhite),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // رأس البطاقة القابل للضغط للطي والفتح
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.2f))
                        .border(1.dp, accentColor.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = subtitle,
                        color = Color.White.copy(alpha = 0.72f),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = accentColor.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = selectedBadge,
                        color = Color.White,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Icon(
                    imageVector = Icons.Rounded.ExpandMore,
                    contentDescription = if (expanded) "طي القسم" else "فتح القسم",
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier
                        .size(24.dp)
                        .rotate(chevronRotation)
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically(animationSpec = tween(240)) + fadeIn(animationSpec = tween(200)),
                exit = shrinkVertically(animationSpec = tween(220)) + fadeOut(animationSpec = tween(160))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 14.dp, end = 14.dp, bottom = 16.dp)
                ) {
                    HorizontalDivider(
                        color = GlassBorderSoft,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    content()
                }
            }
        }
    }
}

@Composable
private fun FieldCheckboxGrid(
    options: List<ExportFieldOption>,
    selectedKeys: Set<String>,
    enabled: Boolean,
    accentColor: Color,
    onToggle: (String) -> Unit
) {
    val rows = remember(options) { options.chunked(2) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                pair.forEach { option ->
                    val isChecked = selectedKeys.contains(option.key)
                    GlassCheckboxItem(
                        label = option.label,
                        checked = isChecked,
                        enabled = enabled,
                        accentColor = accentColor,
                        onClick = { onToggle(option.key) },
                        modifier = Modifier.weight(1f)
                    )
                }
                if (pair.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun GlassCheckboxItem(
    label: String,
    checked: Boolean,
    enabled: Boolean,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = when {
        !enabled -> Color.White.copy(alpha = 0.03f)
        checked -> accentColor.copy(alpha = 0.20f)
        else -> GlassCardSubtleFill
    }
    val borderColor = when {
        !enabled -> Color.White.copy(alpha = 0.10f)
        checked -> accentColor.copy(alpha = 0.72f)
        else -> GlassBorderSoft
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = checked,
                onCheckedChange = { if (enabled) onClick() },
                enabled = enabled,
                colors = CheckboxDefaults.colors(
                    checkedColor = accentColor,
                    uncheckedColor = Color.White.copy(alpha = 0.6f),
                    checkmarkColor = Color(0xFF071324),
                    disabledCheckedColor = accentColor.copy(alpha = 0.35f),
                    disabledUncheckedColor = Color.White.copy(alpha = 0.25f)
                ),
                modifier = Modifier.size(30.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = Color.White.copy(alpha = if (enabled) 0.95f else 0.42f),
                fontSize = 11.5.sp,
                fontWeight = if (checked) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun GlassMiniActionChip(
    text: String,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = accent.copy(alpha = 0.18f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.5f)),
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
private fun GlassAgeInputField(
    label: String,
    value: String,
    enabled: Boolean,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        enabled = enabled,
        label = { Text(label, fontSize = 11.sp) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            disabledTextColor = Color.White.copy(alpha = 0.4f),
            focusedBorderColor = SkyAccent,
            unfocusedBorderColor = GlassBorderSoft,
            disabledBorderColor = GlassBorderSoft.copy(alpha = 0.4f),
            focusedLabelColor = SkyAccent,
            unfocusedLabelColor = Color.White.copy(alpha = 0.7f),
            disabledLabelColor = Color.White.copy(alpha = 0.35f),
            cursorColor = SkyAccent,
            focusedContainerColor = Color.White.copy(alpha = 0.08f),
            unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
            disabledContainerColor = Color.White.copy(alpha = 0.03f)
        ),
        modifier = modifier
    )
}

@Composable
private fun ExportFormatSelectorGlassCard(
    selectedFormat: ProjectExportFormat,
    onSelectFormat: (ProjectExportFormat) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = GlassCardFill,
        border = BorderStroke(1.dp, GlassBorderWhite),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Tune,
                    contentDescription = null,
                    tint = EmeraldGlow,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "صيغة الملف",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.5.sp
                )
            }

            // Segmented Buttons زجاجية لاختيار الصيغة
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(GlassCardSubtleFill)
                    .border(1.dp, GlassBorderSoft, RoundedCornerShape(16.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ProjectExportFormat.entries.forEach { format ->
                    val isSelected = selectedFormat == format
                    val accent = when (format) {
                        ProjectExportFormat.XLSX -> EmeraldGlow
                        ProjectExportFormat.CSV -> SkyAccent
                        ProjectExportFormat.PDF -> RoseAccent
                    }
                    val icon = when (format) {
                        ProjectExportFormat.XLSX -> Icons.Rounded.TableChart
                        ProjectExportFormat.CSV -> Icons.Rounded.Description
                        ProjectExportFormat.PDF -> Icons.Rounded.PictureAsPdf
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) accent.copy(alpha = 0.25f) else Color.Transparent,
                        border = if (isSelected) BorderStroke(1.dp, accent.copy(alpha = 0.8f)) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectFormat(format) }
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (isSelected) accent else Color.White.copy(alpha = 0.65f),
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = format.label,
                                color = if (isSelected) Color.White else Color.White.copy(alpha = 0.72f),
                                fontSize = 10.5.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExportBottomSafBar(
    uiState: ExportProjectUiState,
    totalSelectedColumns: Int,
    onDismissMessages: () -> Unit,
    onClickExport: () -> Unit
) {
    Surface(
        color = Color(0xFF0A1D2B).copy(alpha = 0.92f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.28f)),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (uiState.statusMessage != null) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = EmeraldAccent.copy(alpha = 0.20f),
                    border = BorderStroke(1.dp, EmeraldGlow.copy(alpha = 0.55f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onDismissMessages() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldGlow,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = uiState.statusMessage,
                            color = Color(0xFFA7F3D0),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            if (uiState.errorMessage != null) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = RoseAccent.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, RoseAccent.copy(alpha = 0.55f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onDismissMessages() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ErrorOutline,
                            contentDescription = null,
                            tint = RoseAccent,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = uiState.errorMessage,
                            color = Color(0xFFFECDD3),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            if (uiState.isExporting) {
                LinearProgressIndicator(
                    progress = { uiState.exportProgress.coerceIn(0f, 1f) },
                    color = EmeraldGlow,
                    trackColor = Color.White.copy(alpha = 0.15f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الأعمدة المختارة: $totalSelectedColumns عمود",
                    color = Color.White.copy(alpha = 0.78f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "الصيغة: ${uiState.selectedFormat.label}",
                    color = EmeraldGlow,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = onClickExport,
                enabled = !uiState.isExporting,
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    disabledContainerColor = Color.White.copy(alpha = 0.12f)
                ),
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = if (uiState.isExporting) {
                                listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.14f))
                            } else {
                                listOf(Color(0xFF059669), Color(0xFF10B981))
                            }
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (uiState.isExporting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.5.dp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "جاري تجهيز وحفظ الملف...",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.SaveAlt,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اختيار مسار الحفظ والتصدير",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp
                        )
                    }
                }
            }
        }
    }
}
