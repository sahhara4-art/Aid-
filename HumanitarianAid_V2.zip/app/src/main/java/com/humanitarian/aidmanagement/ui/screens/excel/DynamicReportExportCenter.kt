package com.humanitarian.aidmanagement.ui.screens.excel

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.humanitarian.aidmanagement.data.repository.AidRepository

/**
 * غلاف توافقي (Compatibility Wrapper) يقوم بتمرير العرض إلى الشاشة المستقلة الجديدة
 * [DynamicReportExportScreen] / [DynamicReportExportContent].
 */
@Deprecated(
    message = "Use standalone DynamicReportExportScreen instead.",
    replaceWith = ReplaceWith("DynamicReportExportScreen(repository = repository, onNavigateBack = {})")
)
@Composable
fun DynamicReportExportCenter(
    viewModel: DynamicExportViewModel,
    @Suppress("UNUSED_PARAMETER") repository: AidRepository
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = Color.Transparent,
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0A192F),
                        Color(0xFF0F2E3A),
                        Color(0xFF0B3D38)
                    )
                ),
                shape = RoundedCornerShape(24.dp)
            )
    ) {
        DynamicReportExportContent(
            viewModel = viewModel,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 1400.dp)
        )
    }
}
