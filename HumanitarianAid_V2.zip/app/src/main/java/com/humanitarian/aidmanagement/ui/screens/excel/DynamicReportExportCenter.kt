package com.humanitarian.aidmanagement.ui.screens.excel

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.ChildExportColumnRegistry
import com.humanitarian.aidmanagement.util.ExportColumnRegistry
import com.humanitarian.aidmanagement.util.ProjectExportColumnRegistry
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * مركز التقارير والمعاينة الديناميكي التفاعلي 100% (Dynamic Report & Export Center)
 * يتيح تصفية وتخصيص وتصدير البيانات وفق خطوات منطقية واضحة مع شروط استثناء متقدمة ومعاينة فائقة الأداء
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DynamicReportExportCenter(
    viewModel: DynamicExportViewModel,
    repository: AidRepository
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val selectedEntity by viewModel.selectedEntity.collectAsStateWithLifecycle()
    val toggleApproval by viewModel.toggleApproval.collectAsStateWithLifecycle()
    val selectedApproval by viewModel.selectedApproval.collectAsStateWithLifecycle()
    val toggleLocality by viewModel.toggleLocality.collectAsStateWithLifecycle()
    val selectedLocalityId by viewModel.selectedLocalityId.collectAsStateWithLifecycle()
    val selectedLocalityName by viewModel.selectedLocalityName.collectAsStateWithLifecycle()
    val toggleWorks by viewModel.toggleWorks.collectAsStateWithLifecycle()
    val selectedWorks by viewModel.selectedWorks.collectAsStateWithLifecycle()
    val toggleDamage by viewModel.toggleDamage.collectAsStateWithLifecycle()
    val selectedDamage by viewModel.selectedDamage.collectAsStateWithLifecycle()
    val toggleMarital by viewModel.toggleMarital.collectAsStateWithLifecycle()
    val selectedMarital by viewModel.selectedMarital.collectAsStateWithLifecycle()
    val toggleMembers by viewModel.toggleMembers.collectAsStateWithLifecycle()
    val minMembers by viewModel.minMembers.collectAsStateWithLifecycle()
    val maxMembers by viewModel.maxMembers.collectAsStateWithLifecycle()

    val toggleProjectActive by viewModel.toggleProjectActive.collectAsStateWithLifecycle()
    val selectedProjectActive by viewModel.selectedProjectActive.collectAsStateWithLifecycle()
    val toggleProjectAidType by viewModel.toggleProjectAidType.collectAsStateWithLifecycle()
    val selectedProjectAidTypeId by viewModel.selectedProjectAidTypeId.collectAsStateWithLifecycle()

    val toggleChildGender by viewModel.toggleChildGender.collectAsStateWithLifecycle()
    val selectedChildGender by viewModel.selectedChildGender.collectAsStateWithLifecycle()
    val toggleChildShelter by viewModel.toggleChildShelter.collectAsStateWithLifecycle()
    val selectedChildShelter by viewModel.selectedChildShelter.collectAsStateWithLifecycle()
    val toggleChildLocality by viewModel.toggleChildLocality.collectAsStateWithLifecycle()
    val selectedChildLocalityId by viewModel.selectedChildLocalityId.collectAsStateWithLifecycle()

    val isLoadingPreview by viewModel.isLoadingPreview.collectAsStateWithLifecycle()
    val previewFamilies by viewModel.previewFamilies.collectAsStateWithLifecycle()
    val previewProjects by viewModel.previewProjects.collectAsStateWithLifecycle()
    val previewChildren by viewModel.previewChildren.collectAsStateWithLifecycle()
    val totalMatchingCount by viewModel.totalMatchingCount.collectAsStateWithLifecycle()

    val selectedColumnKeys by viewModel.selectedColumnKeys.collectAsStateWithLifecycle()
    val selectedFormat by viewModel.selectedFormat.collectAsStateWithLifecycle()
    val isExporting by viewModel.isExporting.collectAsStateWithLifecycle()
    val exportProgress by viewModel.exportProgress.collectAsStateWithLifecycle()
    val exportStatusMessage by viewModel.exportStatusMessage.collectAsStateWithLifecycle()

    val localities by repository.getLocalities().collectAsStateWithLifecycle(initialValue = emptyList())
    val aidTypes by repository.getActiveAidTypes().collectAsStateWithLifecycle(initialValue = emptyList())

    // مشغل نظام التخزين الآمن (Storage Access Framework - SAF)
    val dynamicExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(selectedFormat.mimeType)
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val title = when (selectedEntity) {
                    DynamicEntityType.FAMILIES -> "تقرير كشف الأسر والمواطنين المعتمد"
                    DynamicEntityType.PROJECTS -> "تقرير كشف المشاريع الإغاثية والمنح"
                    DynamicEntityType.CHILDREN -> "تقرير كشف الأبناء والتابعين المعتمد"
                }
                val res = viewModel.exportFullDataToUri(context, uri, title)
                res.onSuccess {
                    Toast.makeText(context, "✅ تم حفظ وتصدير الكشف بنجاح عبر التخزين الآمن (SAF)!", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    Toast.makeText(context, "❌ فشل تصدير الكشف: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {

        // =========================================================================
        // القسم 1 (الكيان): اختيار نوع البيانات (مشاريع، أسر/مواطنين، أبناء)
        // =========================================================================
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = CircleShape,
                        color = PalestineGreen,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("1", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Column {
                        Text("القسم 1: اختيار الكيان ومجال التقرير", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("حدد نوع البيانات المستهدفة لتفعيل الفلاتر وجداول المعاينة المخصصة لها", fontSize = 10.sp, color = SlateTextSecondary)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DynamicEntityType.values().forEach { entity ->
                        val isSelected = selectedEntity == entity
                        Surface(
                            onClick = { viewModel.selectEntity(entity) },
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) PalestineGreenContainer else SlateSurfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.5.dp, if (isSelected) PalestineGreen else SlateBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(entity.icon, fontSize = 22.sp)
                                Text(
                                    text = entity.label,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 11.sp,
                                    color = if (isSelected) PalestineGreenDark else SlateTextPrimary,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        // =========================================================================
        // القسم 2 (الفلاتر الديناميكية): قائمة فلاتر متقدمة مع زر تفعيل/استثناء (Toggle)
        // =========================================================================
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            shape = CircleShape,
                            color = PalestineGreen,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("2", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Column {
                            Text("القسم 2: الفلاتر المتقدمة (تفعيل / استثناء)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("فعّل أو استثنِ أي شرط بحرية تامة دون حجب باقي البيانات", fontSize = 10.sp, color = SlateTextSecondary)
                        }
                    }
                    TextButton(onClick = { viewModel.loadPreview() }) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تحديث", fontSize = 11.sp)
                    }
                }

                when (selectedEntity) {
                    DynamicEntityType.FAMILIES -> {
                        // 1. حالة الاعتماد
                        DynamicFilterCard(
                            title = "حالة الاعتماد الحكومي / التنمية",
                            icon = Icons.Default.Verified,
                            isEnabled = toggleApproval,
                            onToggleChange = {
                                viewModel.toggleApproval.value = it
                                viewModel.loadPreview()
                            }
                        ) {
                            val approvals = listOf("معتمد", "حجب اعتماد", "مجمد")
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                approvals.forEach { app ->
                                    FilterChip(
                                        selected = selectedApproval == app,
                                        onClick = {
                                            viewModel.selectedApproval.value = app
                                            viewModel.loadPreview()
                                        },
                                        label = { Text(app, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        // 2. مكان الإقامة / النطاق الجغرافي
                        DynamicFilterCard(
                            title = "مكان الإقامة / النطاق الجغرافي",
                            icon = Icons.Default.LocationOn,
                            isEnabled = toggleLocality,
                            onToggleChange = {
                                viewModel.toggleLocality.value = it
                                viewModel.loadPreview()
                            }
                        ) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                item {
                                    FilterChip(
                                        selected = selectedLocalityId == 0 && selectedLocalityName.isEmpty(),
                                        onClick = {
                                            viewModel.selectedLocalityId.value = 0
                                            viewModel.selectedLocalityName.value = ""
                                            viewModel.loadPreview()
                                        },
                                        label = { Text("كافة المحليات", fontSize = 11.sp) }
                                    )
                                }
                                items(localities) { loc ->
                                    FilterChip(
                                        selected = selectedLocalityId == loc.LocalityID,
                                        onClick = {
                                            viewModel.selectedLocalityId.value = loc.LocalityID
                                            viewModel.selectedLocalityName.value = loc.LocalityName
                                            viewModel.loadPreview()
                                        },
                                        label = { Text(loc.LocalityName, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        // 3. حالة الأشغال (العمل)
                        DynamicFilterCard(
                            title = "حالة اعتماد الأشغال / طبيعة العمل",
                            icon = Icons.Default.Work,
                            isEnabled = toggleWorks,
                            onToggleChange = {
                                viewModel.toggleWorks.value = it
                                viewModel.loadPreview()
                            }
                        ) {
                            val workOptions = listOf("اعتماد أشغال", "بلا عمل", "موظف", "عمال مياومة")
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                workOptions.forEach { w ->
                                    FilterChip(
                                        selected = selectedWorks == w,
                                        onClick = {
                                            viewModel.selectedWorks.value = w
                                            viewModel.loadPreview()
                                        },
                                        label = { Text(w, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        // 4. تصنيف الأضرار
                        DynamicFilterCard(
                            title = "تصنيف أضرار الحرب والسكن",
                            icon = Icons.Default.HomeWork,
                            isEnabled = toggleDamage,
                            onToggleChange = {
                                viewModel.toggleDamage.value = it
                                viewModel.loadPreview()
                            }
                        ) {
                            val damageOptions = listOf("أضرار كلية", "أضرار جزئية بليغة", "أضرار جزئية صالحة للسكن", "غير متضرر")
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                damageOptions.forEach { d ->
                                    FilterChip(
                                        selected = selectedDamage == d,
                                        onClick = {
                                            viewModel.selectedDamage.value = d
                                            viewModel.loadPreview()
                                        },
                                        label = { Text(d, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        // 5. الحالة الاجتماعية
                        DynamicFilterCard(
                            title = "الحالة الاجتماعية لرب الأسرة",
                            icon = Icons.Default.FamilyRestroom,
                            isEnabled = toggleMarital,
                            onToggleChange = {
                                viewModel.toggleMarital.value = it
                                viewModel.loadPreview()
                            }
                        ) {
                            val maritalOptions = listOf("متزوج", "أعزب", "أرمل", "مطلق")
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                maritalOptions.forEach { m ->
                                    FilterChip(
                                        selected = selectedMarital == m,
                                        onClick = {
                                            viewModel.selectedMarital.value = m
                                            viewModel.loadPreview()
                                        },
                                        label = { Text(m, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        // 6. عدد أفراد الأسرة (من - إلى)
                        DynamicFilterCard(
                            title = "عدد أفراد الأسرة ($minMembers إلى $maxMembers أفراد)",
                            icon = Icons.Default.Group,
                            isEnabled = toggleMembers,
                            onToggleChange = {
                                viewModel.toggleMembers.value = it
                                viewModel.loadPreview()
                            }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = minMembers.toString(),
                                    onValueChange = {
                                        val v = it.toIntOrNull() ?: 1
                                        viewModel.minMembers.value = v.coerceAtLeast(1)
                                        viewModel.loadPreview()
                                    },
                                    label = { Text("الحد الأدنى") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = maxMembers.toString(),
                                    onValueChange = {
                                        val v = it.toIntOrNull() ?: 15
                                        viewModel.maxMembers.value = v.coerceAtLeast(1)
                                        viewModel.loadPreview()
                                    },
                                    label = { Text("الحد الأقصى") },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true
                                )
                            }
                        }
                    }
                    DynamicEntityType.PROJECTS -> {
                        // حالة المشروع
                        DynamicFilterCard(
                            title = "حالة نشاط المشروع",
                            icon = Icons.Default.CheckCircle,
                            isEnabled = toggleProjectActive,
                            onToggleChange = {
                                viewModel.toggleProjectActive.value = it
                                viewModel.loadPreview()
                            }
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(
                                    selected = selectedProjectActive,
                                    onClick = {
                                        viewModel.selectedProjectActive.value = true
                                        viewModel.loadPreview()
                                    },
                                    label = { Text("المشاريع النشطة فقط", fontSize = 11.sp) }
                                )
                                FilterChip(
                                    selected = !selectedProjectActive,
                                    onClick = {
                                        viewModel.selectedProjectActive.value = false
                                        viewModel.loadPreview()
                                    },
                                    label = { Text("المشاريع المؤرشفة/المغلقة", fontSize = 11.sp) }
                                )
                            }
                        }
                        // نوع المعونة
                        DynamicFilterCard(
                            title = "نوع المعونة / التصنيف",
                            icon = Icons.Default.Category,
                            isEnabled = toggleProjectAidType,
                            onToggleChange = {
                                viewModel.toggleProjectAidType.value = it
                                viewModel.loadPreview()
                            }
                        ) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                item {
                                    FilterChip(
                                        selected = selectedProjectAidTypeId == 0,
                                        onClick = {
                                            viewModel.selectedProjectAidTypeId.value = 0
                                            viewModel.loadPreview()
                                        },
                                        label = { Text("كافة الأنواع", fontSize = 11.sp) }
                                    )
                                }
                                items(aidTypes) { at ->
                                    FilterChip(
                                        selected = selectedProjectAidTypeId == at.aidTypeID,
                                        onClick = {
                                            viewModel.selectedProjectAidTypeId.value = at.aidTypeID
                                            viewModel.loadPreview()
                                        },
                                        label = { Text(at.aidTypeName, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    }
                    DynamicEntityType.CHILDREN -> {
                        // الجنس
                        DynamicFilterCard(
                            title = "جنس الطفل",
                            icon = Icons.Default.Person,
                            isEnabled = toggleChildGender,
                            onToggleChange = {
                                viewModel.toggleChildGender.value = it
                                viewModel.loadPreview()
                            }
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("ذكر", "أنثى").forEach { g ->
                                    FilterChip(
                                        selected = selectedChildGender == g,
                                        onClick = {
                                            viewModel.selectedChildGender.value = g
                                            viewModel.loadPreview()
                                        },
                                        label = { Text(g, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                        // حالة الإيواء
                        DynamicFilterCard(
                            title = "حالة إيواء الطفل",
                            icon = Icons.Default.Home,
                            isEnabled = toggleChildShelter,
                            onToggleChange = {
                                viewModel.toggleChildShelter.value = it
                                viewModel.loadPreview()
                            }
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("إيواء داخلي", "خارج الإيواء").forEach { sh ->
                                    FilterChip(
                                        selected = selectedChildShelter == sh,
                                        onClick = {
                                            viewModel.selectedChildShelter.value = sh
                                            viewModel.loadPreview()
                                        },
                                        label = { Text(sh, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // =========================================================================
        // القسم 3 (المعاينة الحية): جدول (LazyColumn) يعرض عينة سريعة لتأكيد البيانات
        // =========================================================================
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            shape = CircleShape,
                            color = PalestineGreen,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("3", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Column {
                            Text("القسم 3: المعاينة الحية الفورية", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("عينة سريعة بأداء صاروخي (LIMIT 50) لتأكيد صحة الفلاتر", fontSize = 10.sp, color = SlateTextSecondary)
                        }
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = PalestineGreenContainer
                    ) {
                        Text(
                            text = "$totalMatchingCount سجل مطابق",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PalestineGreenDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                if (isLoadingPreview) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = PalestineGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جارِ معالجة المعاينة بسرعة فائقة...", fontSize = 11.sp)
                    }
                } else if (totalMatchingCount == 0) {
                    Text(
                        text = "⚠️ لا توجد سجلات تطابق الفلاتر المحددة حالياً. قم بتعديل خيارات الفلاتر أو تفعيل الاستثناء للوصول للبيانات.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        when (selectedEntity) {
                            DynamicEntityType.FAMILIES -> {
                                Surface(color = SlateSurfaceVariant, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("الاسم", modifier = Modifier.weight(2.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("الهوية", modifier = Modifier.weight(2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("المنطقة", modifier = Modifier.weight(2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("الأفراد", modifier = Modifier.weight(1f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("الضرر", modifier = Modifier.weight(1.8f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                previewFamilies.forEachIndexed { i, f ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(if (i % 2 == 0) Color.Transparent else SlateSurfaceVariant.copy(alpha = 0.3f))
                                            .padding(vertical = 4.dp, horizontal = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(f.name, modifier = Modifier.weight(2.5f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(f.nationalID, modifier = Modifier.weight(2f), fontSize = 10.sp)
                                        Text(f.currentSubArea.ifBlank { f.currentMainArea }, modifier = Modifier.weight(2f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(f.familyMembersCount.toString(), modifier = Modifier.weight(1f), fontSize = 10.sp)
                                        Text(f.damageType, modifier = Modifier.weight(1.8f), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                            DynamicEntityType.PROJECTS -> {
                                Surface(color = SlateSurfaceVariant, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("رقم المشروع", modifier = Modifier.weight(2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("اسم المشروع", modifier = Modifier.weight(3f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("الجهة الممولة", modifier = Modifier.weight(2.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("الحصة", modifier = Modifier.weight(1f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                previewProjects.forEachIndexed { i, p ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(if (i % 2 == 0) Color.Transparent else SlateSurfaceVariant.copy(alpha = 0.3f))
                                            .padding(vertical = 4.dp, horizontal = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(p.projectNumber, modifier = Modifier.weight(2f), fontSize = 10.sp)
                                        Text(p.projectName, modifier = Modifier.weight(3f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(p.fundingInstitution, modifier = Modifier.weight(2.5f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(p.quantity.toString(), modifier = Modifier.weight(1f), fontSize = 10.sp)
                                    }
                                }
                            }
                            DynamicEntityType.CHILDREN -> {
                                Surface(color = SlateSurfaceVariant, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("اسم الطفل", modifier = Modifier.weight(3f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("الهوية", modifier = Modifier.weight(2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("هوية المعيل", modifier = Modifier.weight(2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text("الجنس", modifier = Modifier.weight(1f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                previewChildren.forEachIndexed { i, c ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(if (i % 2 == 0) Color.Transparent else SlateSurfaceVariant.copy(alpha = 0.3f))
                                            .padding(vertical = 4.dp, horizontal = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(c.childName, modifier = Modifier.weight(3f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(c.nationalID, modifier = Modifier.weight(2f), fontSize = 10.sp)
                                        Text(c.familyNationalID, modifier = Modifier.weight(2f), fontSize = 10.sp)
                                        Text(c.gender, modifier = Modifier.weight(1f), fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                    Text(
                        text = "💡 تُعرض أول 50 نتيجة فقط لتأكيد مطابقة البيانات بسرعة فائقة. التصدير النهائي سيشمل كافة الـ $totalMatchingCount سجل بالكامل.",
                        fontSize = 10.sp,
                        color = SlateTextSecondary
                    )
                }
            }
        }

        // =========================================================================
        // القسم 4 (تخصيص التصدير): Checkboxes للأعمدة واختيار الصيغة (Excel/PDF)
        // =========================================================================
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            shape = CircleShape,
                            color = PalestineGreen,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("4", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Column {
                            Text("القسم 4: تخصيص الأعمدة وصيغة التصدير", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("اختر الأعمدة التي تود ظهورها في الملف واستثنِ الباقي", fontSize = 10.sp, color = SlateTextSecondary)
                        }
                    }
                    Text("${selectedColumnKeys.size} عمود محدد", fontSize = 11.sp, color = PalestineGreenDark, fontWeight = FontWeight.Bold)
                }

                // أزرار التحكم السريع بالأعمدة
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.selectAllColumns() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("تحديد الكل", fontSize = 10.sp)
                    }
                    OutlinedButton(
                        onClick = { viewModel.selectDefaultColumns() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("الافتراضي", fontSize = 10.sp)
                    }
                    OutlinedButton(
                        onClick = { viewModel.clearAllColumns() },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("إلغاء الكل", fontSize = 10.sp)
                    }
                }

                // شبكة Checkbox للأعمدة المتاحة للكيان المختار
                val columns = when (selectedEntity) {
                    DynamicEntityType.FAMILIES -> ExportColumnRegistry.ALL_COLUMNS.map { it.key to it.label }
                    DynamicEntityType.PROJECTS -> ProjectExportColumnRegistry.ALL_COLUMNS.map { it.key to it.label }
                    DynamicEntityType.CHILDREN -> ChildExportColumnRegistry.ALL_COLUMNS.map { it.key to it.label }
                }

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    columns.forEach { (key, label) ->
                        val isChecked = selectedColumnKeys.contains(key)
                        FilterChip(
                            selected = isChecked,
                            onClick = { viewModel.toggleColumnKey(key) },
                            label = { Text(label, fontSize = 10.sp) },
                            leadingIcon = if (isChecked) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp)) }
                            } else null,
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }

                HorizontalDivider(color = SlateBorder)

                // اختيار الصيغة (Excel / PDF)
                Text("صيغة الملف المصدر:", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DynamicExportFormat.values().forEach { fmt ->
                        val isSel = selectedFormat == fmt
                        Surface(
                            onClick = { viewModel.setFormat(fmt) },
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSel) PalestineGreenContainer else SlateSurfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(1.5.dp, if (isSel) PalestineGreen else SlateBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (fmt == DynamicExportFormat.EXCEL) Icons.Default.TableChart else Icons.Default.PictureAsPdf,
                                    contentDescription = null,
                                    tint = if (isSel) PalestineGreenDark else SlateTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(fmt.label, fontSize = 11.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                }

                if (isExporting) {
                    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        LinearProgressIndicator(
                            progress = { exportProgress },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = PalestineGreen
                        )
                        Text(
                            text = "جارِ استخراج وحفظ الكشف الكامل في الذاكرة...",
                            fontSize = 11.sp,
                            color = PalestineGreenDark,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // زر التصدير الرئيسي
                Button(
                    onClick = {
                        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                        val prefix = when (selectedEntity) {
                            DynamicEntityType.FAMILIES -> "Families_Custom"
                            DynamicEntityType.PROJECTS -> "Projects_Custom"
                            DynamicEntityType.CHILDREN -> "Children_Custom"
                        }
                        val ext = selectedFormat.extension
                        val fileName = "${prefix}_$timeStamp.$ext"
                        dynamicExportLauncher.launch(fileName)
                    },
                    enabled = !isExporting && totalMatchingCount > 0 && selectedColumnKeys.isNotEmpty(),
                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تصدير الكشف النهائي الكامل ($totalMatchingCount سجل)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (exportStatusMessage != null) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = PalestineGreenLight,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = exportStatusMessage!!,
                            fontSize = 11.sp,
                            color = PalestineGreenDark,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * بطاقة الفلتر التفاعلية مع مفتاح التفعيل / الاستثناء (Toggle Switch)
 */
@Composable
fun DynamicFilterCard(
    title: String,
    icon: ImageVector,
    isEnabled: Boolean,
    onToggleChange: (Boolean) -> Unit,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isEnabled) PalestineGreenContainer.copy(alpha = 0.35f) else SlateSurfaceVariant.copy(alpha = 0.35f),
        border = BorderStroke(1.dp, if (isEnabled) PalestineGreen.copy(alpha = 0.4f) else SlateBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(icon, contentDescription = null, tint = if (isEnabled) PalestineGreen else SlateTextSecondary, modifier = Modifier.size(16.dp))
                    Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isEnabled) SlateTextPrimary else SlateTextSecondary)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (isEnabled) "مُفعل" else "مُستثنى",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isEnabled) PalestineGreenDark else SlateTextSecondary
                    )
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = onToggleChange,
                        modifier = Modifier.scale(0.8f)
                    )
                }
            }
            if (isEnabled) {
                content()
            }
        }
    }
}
