package com.humanitarian.aidmanagement.civilregistry.data

import android.database.sqlite.SQLiteDatabase
import android.os.CancellationSignal
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryDbStatus
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySchema
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchPage
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * مصدر بيانات تجريبي محلي مفصول بالكامل (Sample Civil Registry Data Source Adapter)
 *
 * يمكّن التشغيل والتجربة الفورية داخل AI Studio دون الحاجة لرفع ملف civil_registry.db،
 * مع مطابقة 100% لاسم الجدول civil_registry وكافة الأعمدة الـ 14 حرفياً، والفهارس
 * (idx_citizen_id, idx_citizen_name, idx_wife_id)، وتواريخ YYYY-MM-DD، وهويات نظيفة بدون .0.
 */
class SampleCivilRegistryDataSource : CivilRegistryDataSource {

    private val lock = Any()
    @Volatile
    private var memoryDb: SQLiteDatabase? = null

    override suspend fun ensureDatabaseReady(): CivilRegistryDbStatus = withContext(Dispatchers.IO) {
        try {
            val db = getOrCreateSeededMemoryDb()
            val count = CivilRegistryQueryExecutor.queryTotalCountFast(db)
            CivilRegistryDbStatus.Ready(
                totalRecords = count,
                dbPath = "in-memory://sample_civil_registry.db"
            )
        } catch (t: Throwable) {
            CivilRegistryDbStatus.Error(
                message = t.localizedMessage ?: "تعذر تهيئة مصدر البيانات التجريبي للسجل المدني."
            )
        }
    }

    override suspend fun search(
        query: CivilRegistrySearchQuery,
        offset: Int,
        pageSize: Int,
        cancellationSignal: CancellationSignal?
    ): CivilRegistrySearchPage = withContext(Dispatchers.IO) {
        val db = getOrCreateSeededMemoryDb()
        CivilRegistryQueryExecutor.executeSearch(
            db = db,
            query = query,
            offset = offset,
            pageSize = pageSize,
            cancellationSignal = cancellationSignal
        )
    }

    override fun close() {
        synchronized(lock) {
            try {
                memoryDb?.close()
            } catch (_: Throwable) {
            } finally {
                memoryDb = null
            }
        }
    }

    private fun getOrCreateSeededMemoryDb(): SQLiteDatabase {
        synchronized(lock) {
            val existing = memoryDb
            if (existing != null && existing.isOpen) return existing

            val db = SQLiteDatabase.create(null)
            val table = CivilRegistrySchema.TABLE_NAME
            db.execSQL(
                """
                CREATE TABLE "$table" (
                    "${CivilRegistrySchema.COL_NATIONAL_ID}" TEXT,
                    "${CivilRegistrySchema.COL_NAME}" TEXT,
                    "${CivilRegistrySchema.COL_BIRTH_DATE}" TEXT,
                    "${CivilRegistrySchema.COL_MARITAL_STATUS}" TEXT,
                    "${CivilRegistrySchema.COL_DEATH_STATUS}" TEXT,
                    "${CivilRegistrySchema.COL_DEATH_DATE}" TEXT,
                    "${CivilRegistrySchema.COL_GENDER}" TEXT,
                    "${CivilRegistrySchema.COL_DEV_PHONE}" TEXT,
                    "${CivilRegistrySchema.COL_MOBILE_PHONE}" TEXT,
                    "${CivilRegistrySchema.COL_MAIN_AREA}" TEXT,
                    "${CivilRegistrySchema.COL_FAMILY_MEMBERS_COUNT}" TEXT,
                    "${CivilRegistrySchema.COL_DEV_APPROVAL}" TEXT,
                    "${CivilRegistrySchema.COL_WIFE_NAME}" TEXT,
                    "${CivilRegistrySchema.COL_WIFE_NATIONAL_ID}" TEXT
                )
                """.trimIndent()
            )

            db.execSQL("CREATE INDEX idx_citizen_id ON \"$table\" (\"${CivilRegistrySchema.COL_NATIONAL_ID}\")")
            db.execSQL("CREATE INDEX idx_citizen_name ON \"$table\" (\"${CivilRegistrySchema.COL_NAME}\")")
            db.execSQL("CREATE INDEX idx_wife_id ON \"$table\" (\"${CivilRegistrySchema.COL_WIFE_NATIONAL_ID}\")")

            val insertSql = "INSERT INTO \"$table\" (${CivilRegistrySchema.ALL_COLUMNS_SQL}) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"

            db.beginTransaction()
            try {
                val stmt = db.compileStatement(insertSql)
                SAMPLE_ROWS.forEach { row ->
                    stmt.clearBindings()
                    for (i in row.indices) {
                        stmt.bindString(i + 1, row[i])
                    }
                    stmt.executeInsert()
                }
                stmt.close()
                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }

            // تفعيل وضع القراءة فقط بعد التهيئة لضمان عدم إمكانية أي تعديل على البيانات التجريبية
            db.rawQuery("PRAGMA query_only = ON", null).close()

            memoryDb = db
            return db
        }
    }

    companion object {
        /**
         * بيانات تجريبية واقعية منظمة بنفس ترتيب الأعمدة الـ 14 الحرفية:
         * 0: رقم الهوية | 1: الاسم | 2: تاريخ_الميلاد | 3: الحالة الاجتماعية | 4: الوفاة | 5: تاريخ_الوفاة | 6: الجنس
         * 7: جوال تنمية | 8: رقم الجوال | 9: المنطقة الرئيسية | 10: عدد افراد الاسرة | 11: حالة اعتماد التنمية | 12: اسم الزوجة | 13: هويتها
         */
        private val SAMPLE_ROWS: List<Array<String>> = listOf(
            arrayOf("901245678", "أحمد محمود خليل السحار", "1982-04-15", "متزوج", "على قيد الحياة", "", "ذكر", "0599123456", "0599887766", "شمال غزة", "7", "معتمد", "فاطمة يوسف حسن النجار", "902345671"),
            arrayOf("903456789", "محمد عبد الله سليمان أبو عاصي", "1978-11-03", "متزوج", "على قيد الحياة", "", "ذكر", "0597654321", "0598112233", "غزة", "6", "معتمد", "سعاد إبراهيم سالم المصري", "904567892"),
            arrayOf("801122334", "خالد سعيد مصطفى حمدان", "1986-07-22", "متزوج", "على قيد الحياة", "", "ذكر", "0592334455", "0595443322", "الوسطى", "5", "معتمد", "أمل محمد عطية بركة", "802233445"),
            arrayOf("402567891", "يوسف حسن إبراهيم العطار", "1990-02-10", "متزوج", "على قيد الحياة", "", "ذكر", "0594112299", "0569112299", "شمال غزة", "4", "معتمد", "هدى سامي عبد الرحمن زعرب", "403678912"),
            arrayOf("911234567", "إبراهيم خليل رمضان الفرا", "1974-09-18", "متزوج", "على قيد الحياة", "", "ذكر", "0599301122", "0599301122", "خانيونس", "9", "معتمد", "مريم جمال أحمد الأسطل", "912345678"),
            arrayOf("922345678", "سامي فتحي محمود الشوا", "1980-01-29", "متزوج", "على قيد الحياة", "", "ذكر", "0597223311", "0598776655", "غزة", "6", "حجب اعتماد", "نادية كمال توفيق سكيك", "923456781"),
            arrayOf("804455667", "طارق زياد عمر أبو شقفة", "1988-06-14", "متزوج", "على قيد الحياة", "", "ذكر", "0595119988", "0594887711", "رفح", "5", "معتمد", "رنا وليد حسن قشطة", "805566778"),
            arrayOf("905678912", "عبد الرحمن ناصر محمد المبحوح", "1976-03-08", "متزوج", "متوفى", "2024-01-19", "ذكر", "0599445566", "0598990011", "شمال غزة", "8", "معتمد", "إيمان عادل سلمان حمودة", "906789123"),
            arrayOf("406789123", "عمر مازن عبد القادر اللوح", "1992-12-05", "متزوج", "على قيد الحياة", "", "ذكر", "0567889900", "0592778899", "الوسطى", "3", "قيد المراجعة", "سارة أيمن محمود درويش", "407891234"),
            arrayOf("914567890", "محمود رامي سليمان الأغا", "1984-05-27", "متزوج", "على قيد الحياة", "", "ذكر", "0599556677", "0597114422", "خانيونس", "7", "معتمد", "دعاء نبيل حسين شراب", "915678901"),
            arrayOf("808899001", "رامي جهاد علي الكحلوت", "1987-08-11", "متزوج", "على قيد الحياة", "", "ذكر", "0598667788", "0598667788", "شمال غزة", "6", "معتمد", "حنين ماجد عوض صالحة", "809900112"),
            arrayOf("930112233", "سلمى حسن عبد الله أبو دان", "1979-10-04", "أرمل", "على قيد الحياة", "", "أنثى", "0599214365", "0595321456", "غزة", "5", "معتمد", "", ""),
            arrayOf("410223344", "بلال أشرف محمد أبو نحل", "1994-03-19", "متزوج", "على قيد الحياة", "", "ذكر", "0569445511", "0594123789", "رفح", "4", "معتمد", "نور عماد سعيد أبو طه", "411334455"),
            arrayOf("916789012", "مصطفى كامل أحمد الشنطي", "1972-07-07", "متزوج", "على قيد الحياة", "", "ذكر", "0599778811", "0599223344", "غزة", "10", "معتمد", "ليلى صبري محمود مشتهى", "917890123"),
            arrayOf("812345670", "هشام نافذ يوسف العبادلة", "1985-11-30", "متزوج", "على قيد الحياة", "", "ذكر", "0597881122", "0592665544", "خانيونس", "6", "مجمد", "عبير سعيد خليل البريم", "813456781"),
            arrayOf("408912345", "أنس رائد فتحي أبو مراحيل", "1991-09-12", "متزوج", "على قيد الحياة", "", "ذكر", "0595998877", "0567123450", "الوسطى", "4", "معتمد", "شيماء خالد محمد عقل", "409023456"),
            arrayOf("907891234", "سليم عطا الله حمدان الزعانين", "1977-04-25", "متزوج", "متوفى", "2023-11-12", "ذكر", "0599654789", "0598123987", "شمال غزة", "7", "معتمد", "وفاء محمد سليمان الكفارنة", "908912345"),
            arrayOf("412456789", "هبة الله سمير إبراهيم قاسم", "1989-01-17", "مطلق", "على قيد الحياة", "", "أنثى", "0594776622", "0597991133", "الوسطى", "3", "معتمد", "", ""),
            arrayOf("815678902", "عماد الدين تيسير محمود حلس", "1983-06-09", "متزوج", "على قيد الحياة", "", "ذكر", "0599102030", "0599405060", "غزة", "8", "معتمد", "سمية رفيق حسن الجعبري", "816789013"),
            arrayOf("414567893", "معاذ جمال عبد العزيز أبو جزر", "1995-08-23", "متزوج", "على قيد الحياة", "", "ذكر", "0568332211", "0595774411", "رفح", "3", "معتمد", "تسنيم مروان أحمد زعرب", "415678904"),
            arrayOf("918901234", "ناصر صبحي محمد العكلوك", "1975-12-01", "متزوج", "على قيد الحياة", "", "ذكر", "0599876543", "0597543210", "الوسطى", "9", "معتمد", "ختام عبد الله سلمان شاهين", "919012345"),
            arrayOf("818901235", "فادي أكرم سليمان شبير", "1986-02-14", "متزوج", "على قيد الحياة", "", "ذكر", "0592113355", "0598224466", "خانيونس", "5", "معتمد", "إسراء عماد محمد المجايدة", "819012346"),
            arrayOf("920123456", "وائل منير عبد الفتاح غبن", "1981-05-06", "متزوج", "على قيد الحياة", "", "ذكر", "0599336699", "0595112233", "شمال غزة", "6", "معتمد", "رشا حسام الدين خليل معروف", "921234567"),
            arrayOf("416789014", "حسام خالد عطية الحساينة", "1993-10-21", "أعزب", "على قيد الحياة", "", "ذكر", "0569887700", "0594665500", "غزة", "1", "قيد المراجعة", "", ""),
            arrayOf("924567895", "جمال الدين سعيد عمر أبو لبدة", "1979-03-16", "متزوج", "على قيد الحياة", "", "ذكر", "0597443322", "0599118822", "رفح", "8", "معتمد", "منى عبد الكريم سالم شيخ العيد", "925678906")
        )
    }
}
