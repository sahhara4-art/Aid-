package com.humanitarian.aidmanagement.civilregistry.data

import android.database.sqlite.SQLiteDatabase
import android.os.CancellationSignal
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryChildRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryChildrenSchema
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryDbStatus
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySchema
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchPage
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * مصدر بيانات تجريبي محلي مفصول بالكامل (Sample Civil Registry Data Source Adapter)
 *
 * يطابق 100% هيكل قاعدة civil_registry.db الجديدة:
 * - جدول civil_registry بجميع أعمدته الـ 14 وفهارسه (idx_citizen_id, idx_citizen_name, idx_wife_id)
 * - جدول children_registry بجميع أعمدته الـ 11 وفهارسه (idx_children_parent_id, idx_children_child_id, idx_children_birth_date)
 * - عرض v_children_with_age
 */
class SampleCivilRegistryDataSource : CivilRegistryDataSource {

    private val lock = Any()
    @Volatile
    private var memoryDb: SQLiteDatabase? = null

    override suspend fun ensureDatabaseReady(): CivilRegistryDbStatus = withContext(Dispatchers.IO) {
        try {
            val db = getOrCreateSeededMemoryDb()
            val count = CivilRegistryQueryExecutor.queryTotalCountFast(db)
            val hasChildren = CivilRegistryQueryExecutor.hasTable(db, CivilRegistryChildrenSchema.TABLE_NAME)
            val childrenCount = if (hasChildren) CivilRegistryQueryExecutor.queryChildrenCountFast(db) else 0L
            val hasView = CivilRegistryQueryExecutor.hasView(db, CivilRegistryChildrenSchema.VIEW_NAME)
            val hasFts = CivilRegistryQueryExecutor.hasTable(db, CivilRegistryChildrenSchema.FTS_TABLE_NAME)
            CivilRegistryDbStatus.Ready(
                totalRecords = count,
                dbPath = "in-memory://sample_civil_registry.db",
                hasChildrenRegistry = hasChildren,
                totalChildrenRecords = childrenCount,
                hasChildrenAgeView = hasView,
                hasChildrenFts = hasFts
            )
        } catch (t: Throwable) {
            CivilRegistryDbStatus.Error(
                message = t.localizedMessage ?: "تعذر تهيئة مصدر البيانات التجريبي للسجل المدني."
            )
        }
    }

    override suspend fun search(
        query: CivilRegistrySearchQuery,
        offset: Int,
        pageSize: Int,
        cancellationSignal: CancellationSignal?
    ): CivilRegistrySearchPage = withContext(Dispatchers.IO) {
        val db = getOrCreateSeededMemoryDb()
        CivilRegistryQueryExecutor.executeSearch(
            db = db,
            query = query,
            offset = offset,
            pageSize = pageSize,
            cancellationSignal = cancellationSignal
        )
    }

    override suspend fun getChildrenForParent(
        parentId: String,
        minBirthDateIso: String?,
        maxBirthDateIso: String?,
        cancellationSignal: CancellationSignal?
    ): List<CivilRegistryChildRecord> = withContext(Dispatchers.IO) {
        val db = getOrCreateSeededMemoryDb()
        CivilRegistryQueryExecutor.queryChildrenByParentId(
            db = db,
            parentId = parentId,
            minBirthDateIso = minBirthDateIso,
            maxBirthDateIso = maxBirthDateIso,
            cancellationSignal = cancellationSignal,
            enforceCivilRegistryAccessGuard = true
        )
    }

    internal suspend fun getChildrenForOfficialSync(
        parentId: String,
        minBirthDateIso: String? = null,
        maxBirthDateIso: String? = null
    ): List<CivilRegistryChildRecord> = withContext(Dispatchers.IO) {
        val db = getOrCreateSeededMemoryDb()
        CivilRegistryQueryExecutor.queryChildrenByParentId(
            db = db,
            parentId = parentId,
            minBirthDateIso = minBirthDateIso,
            maxBirthDateIso = maxBirthDateIso,
            cancellationSignal = null,
            enforceCivilRegistryAccessGuard = false
        )
    }

    internal suspend fun getChildrenForOfficialSyncChunk(
        parentIds: List<String>,
        minBirthDateIso: String? = null,
        maxBirthDateIso: String? = null
    ): List<CivilRegistryChildRecord> = withContext(Dispatchers.IO) {
        if (parentIds.isEmpty()) return@withContext emptyList()
        val db = getOrCreateSeededMemoryDb()
        CivilRegistryQueryExecutor.queryChildrenByParentIdsChunk(
            db = db,
            parentIds = parentIds,
            minBirthDateIso = minBirthDateIso,
            maxBirthDateIso = maxBirthDateIso,
            cancellationSignal = null,
            enforceCivilRegistryAccessGuard = false
        )
    }

    override suspend fun hasChildrenRegistryTable(): Boolean = withContext(Dispatchers.IO) {
        val db = getOrCreateSeededMemoryDb()
        CivilRegistryQueryExecutor.hasTable(db, CivilRegistryChildrenSchema.TABLE_NAME)
    }

    override fun close() {
        synchronized(lock) {
            try {
                memoryDb?.close()
            } catch (_: Throwable) {
            } finally {
                memoryDb = null
            }
        }
    }

    private fun getOrCreateSeededMemoryDb(): SQLiteDatabase {
        synchronized(lock) {
            val existing = memoryDb
            if (existing != null && existing.isOpen) return existing

            val db = SQLiteDatabase.create(null)
            val table = CivilRegistrySchema.TABLE_NAME
            db.execSQL(
                """
                CREATE TABLE "$table" (
                    "${CivilRegistrySchema.COL_NATIONAL_ID}" TEXT,
                    "${CivilRegistrySchema.COL_NAME}" TEXT,
                    "${CivilRegistrySchema.COL_BIRTH_DATE}" TEXT,
                    "${CivilRegistrySchema.COL_MARITAL_STATUS}" TEXT,
                    "${CivilRegistrySchema.COL_DEATH_STATUS}" TEXT,
                    "${CivilRegistrySchema.COL_DEATH_DATE}" TEXT,
                    "${CivilRegistrySchema.COL_GENDER}" TEXT,
                    "${CivilRegistrySchema.COL_DEV_PHONE}" TEXT,
                    "${CivilRegistrySchema.COL_MOBILE_PHONE}" TEXT,
                    "${CivilRegistrySchema.COL_MAIN_AREA}" TEXT,
                    "${CivilRegistrySchema.COL_FAMILY_MEMBERS_COUNT}" TEXT,
                    "${CivilRegistrySchema.COL_DEV_APPROVAL}" TEXT,
                    "${CivilRegistrySchema.COL_WIFE_NAME}" TEXT,
                    "${CivilRegistrySchema.COL_WIFE_NATIONAL_ID}" TEXT
                )
                """.trimIndent()
            )

            db.execSQL("CREATE INDEX idx_citizen_id ON \"$table\" (\"${CivilRegistrySchema.COL_NATIONAL_ID}\")")
            db.execSQL("CREATE INDEX idx_citizen_name ON \"$table\" (\"${CivilRegistrySchema.COL_NAME}\")")
            db.execSQL("CREATE INDEX idx_wife_id ON \"$table\" (\"${CivilRegistrySchema.COL_WIFE_NATIONAL_ID}\")")

            val childrenTable = CivilRegistryChildrenSchema.TABLE_NAME
            db.execSQL(
                """
                CREATE TABLE "$childrenTable" (
                    "${CivilRegistryChildrenSchema.COL_ID}" INTEGER PRIMARY KEY AUTOINCREMENT,
                    "${CivilRegistryChildrenSchema.COL_PARENT_ID}" TEXT NOT NULL,
                    "${CivilRegistryChildrenSchema.COL_PARENT_NAME}" TEXT,
                    "${CivilRegistryChildrenSchema.COL_CHILD_ID}" TEXT,
                    "${CivilRegistryChildrenSchema.COL_CHILD_NAME}" TEXT,
                    "${CivilRegistryChildrenSchema.COL_GENDER}" TEXT,
                    "${CivilRegistryChildrenSchema.COL_SOCIAL_STATUS}" TEXT,
                    "${CivilRegistryChildrenSchema.COL_REGION}" TEXT,
                    "${CivilRegistryChildrenSchema.COL_CITY}" TEXT,
                    "${CivilRegistryChildrenSchema.COL_BIRTH_DATE}" TEXT,
                    "${CivilRegistryChildrenSchema.COL_IS_WEST_GAZA}" TEXT
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX idx_children_parent_id ON \"$childrenTable\" (\"${CivilRegistryChildrenSchema.COL_PARENT_ID}\")")
            db.execSQL("CREATE INDEX idx_children_child_id ON \"$childrenTable\" (\"${CivilRegistryChildrenSchema.COL_CHILD_ID}\")")
            db.execSQL("CREATE INDEX idx_children_birth_date ON \"$childrenTable\" (\"${CivilRegistryChildrenSchema.COL_BIRTH_DATE}\")")
            db.execSQL("CREATE INDEX idx_children_parent_birth ON \"$childrenTable\" (\"${CivilRegistryChildrenSchema.COL_PARENT_ID}\", \"${CivilRegistryChildrenSchema.COL_BIRTH_DATE}\" DESC)")

            val ftsTable = CivilRegistryChildrenSchema.FTS_TABLE_NAME
            val ftsCol = CivilRegistryChildrenSchema.FTS_COL_CHILD_NAME_NORM
            db.execSQL("CREATE VIRTUAL TABLE \"$ftsTable\" USING fts4(\"$ftsCol\")")

            db.execSQL(
                """
                CREATE VIEW "${CivilRegistryChildrenSchema.VIEW_NAME}" AS
                SELECT
                    *,
                    CAST((julianday('now') - julianday(birth_date)) / 365.25 AS INTEGER) AS age_years,
                    CAST(((julianday('now') - julianday(birth_date)) % 365.25) / 30.4375 AS INTEGER) AS age_months,
                    CAST(((julianday('now') - julianday(birth_date)) % 30.4375) AS INTEGER) AS age_days,
                    '' AS age_text
                FROM "$childrenTable"
                """.trimIndent()
            )

            val insertSql = "INSERT INTO \"$table\" (${CivilRegistrySchema.ALL_COLUMNS_SQL}) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"

            val insertChildSql = """
                INSERT INTO "$childrenTable" (
                    "${CivilRegistryChildrenSchema.COL_PARENT_ID}",
                    "${CivilRegistryChildrenSchema.COL_PARENT_NAME}",
                    "${CivilRegistryChildrenSchema.COL_CHILD_ID}",
                    "${CivilRegistryChildrenSchema.COL_CHILD_NAME}",
                    "${CivilRegistryChildrenSchema.COL_GENDER}",
                    "${CivilRegistryChildrenSchema.COL_SOCIAL_STATUS}",
                    "${CivilRegistryChildrenSchema.COL_REGION}",
                    "${CivilRegistryChildrenSchema.COL_CITY}",
                    "${CivilRegistryChildrenSchema.COL_BIRTH_DATE}",
                    "${CivilRegistryChildrenSchema.COL_IS_WEST_GAZA}"
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """.trimIndent()

            val insertFtsSql = "INSERT INTO \"$ftsTable\" (docid, \"$ftsCol\") VALUES (?, ?)"

            db.beginTransaction()
            try {
                val stmt = db.compileStatement(insertSql)
                SAMPLE_ROWS.forEach { row ->
                    stmt.clearBindings()
                    for (i in row.indices) {
                        stmt.bindString(i + 1, row[i])
                    }
                    stmt.executeInsert()
                }
                stmt.close()

                val childStmt = db.compileStatement(insertChildSql)
                val ftsStmt = db.compileStatement(insertFtsSql)
                SAMPLE_CHILDREN_ROWS.forEach { row ->
                    childStmt.clearBindings()
                    for (i in row.indices) {
                        childStmt.bindString(i + 1, row[i])
                    }
                    val insertedRowId = childStmt.executeInsert()
                    if (insertedRowId > 0L) {
                        ftsStmt.clearBindings()
                        ftsStmt.bindLong(1, insertedRowId)
                        ftsStmt.bindString(2, CivilRegistryQueryExecutor.normalizeArabicForFts(row[3]))
                        ftsStmt.executeInsert()
                    }
                }
                childStmt.close()
                ftsStmt.close()

                db.setTransactionSuccessful()
            } finally {
                db.endTransaction()
            }

            // تفعيل وضع القراءة فقط بعد التهيئة لضمان عدم إمكانية أي تعديل على البيانات التجريبية
            db.rawQuery("PRAGMA query_only = ON", null).close()

            memoryDb = db
            return db
        }
    }

    companion object {
        private val SAMPLE_ROWS: List<Array<String>> = listOf(
            arrayOf("901245678", "أحمد محمود خليل السحار", "1982-04-15", "متزوج", "على قيد الحياة", "", "ذكر", "0599123456", "0599887766", "شمال غزة", "7", "معتمد", "فاطمة يوسف حسن النجار", "902345671"),
            arrayOf("903456789", "محمد عبد الله سليمان أبو عاصي", "1978-11-03", "متزوج", "على قيد الحياة", "", "ذكر", "0597654321", "0598112233", "غزة", "6", "معتمد", "سعاد إبراهيم سالم المصري", "904567892"),
            arrayOf("801122334", "خالد سعيد مصطفى حمدان", "1986-07-22", "متزوج", "على قيد الحياة", "", "ذكر", "0592334455", "0595443322", "الوسطى", "5", "معتمد", "أمل محمد عطية بركة", "802233445"),
            arrayOf("402567891", "يوسف حسن إبراهيم العطار", "1990-02-10", "متزوج", "على قيد الحياة", "", "ذكر", "0594112299", "0569112299", "شمال غزة", "4", "معتمد", "هدى سامي عبد الرحمن زعرب", "403678912"),
            arrayOf("911234567", "إبراهيم خليل رمضان الفرا", "1974-09-18", "متزوج", "على قيد الحياة", "", "ذكر", "0599301122", "0599301122", "خانيونس", "9", "معتمد", "مريم جمال أحمد الأسطل", "912345678"),
            arrayOf("922345678", "سامي فتحي محمود الشوا", "1980-01-29", "متزوج", "على قيد الحياة", "", "ذكر", "0597223311", "0598776655", "غزة", "6", "حجب اعتماد", "نادية كمال توفيق سكيك", "923456781"),
            arrayOf("804455667", "طارق زياد عمر أبو شقفة", "1988-06-14", "متزوج", "على قيد الحياة", "", "ذكر", "0595119988", "0594887711", "رفح", "5", "معتمد", "رنا وليد حسن قشطة", "805566778"),
            arrayOf("905678912", "عبد الرحمن ناصر محمد المبحوح", "1976-03-08", "متزوج", "متوفى", "2024-01-19", "ذكر", "0599445566", "0598990011", "شمال غزة", "8", "معتمد", "إيمان عادل سلمان حمودة", "906789123"),
            arrayOf("406789123", "عمر مازن عبد القادر اللوح", "1992-12-05", "متزوج", "على قيد الحياة", "", "ذكر", "0567889900", "0592778899", "الوسطى", "3", "قيد المراجعة", "سارة أيمن محمود درويش", "407891234"),
            arrayOf("914567890", "محمود رامي سليمان الأغا", "1984-05-27", "متزوج", "على قيد الحياة", "", "ذكر", "0599556677", "0597114422", "خانيونس", "7", "معتمد", "دعاء نبيل حسين شراب", "915678901"),
            arrayOf("808899001", "رامي جهاد علي الكحلوت", "1987-08-11", "متزوج", "على قيد الحياة", "", "ذكر", "0598667788", "0598667788", "شمال غزة", "6", "معتمد", "حنين ماجد عوض صالحة", "809900112"),
            arrayOf("930112233", "سلمى حسن عبد الله أبو دان", "1979-10-04", "أرمل", "على قيد الحياة", "", "أنثى", "0599214365", "0595321456", "غزة", "5", "معتمد", "", ""),
            arrayOf("410223344", "بلال أشرف محمد أبو نحل", "1994-03-19", "متزوج", "على قيد الحياة", "", "ذكر", "0569445511", "0594123789", "رفح", "4", "معتمد", "نور عماد سعيد أبو طه", "411334455"),
            arrayOf("916789012", "مصطفى كامل أحمد الشنطي", "1972-07-07", "متزوج", "على قيد الحياة", "", "ذكر", "0599778811", "0599223344", "غزة", "10", "معتمد", "ليلى صبري محمود مشتهى", "917890123"),
            arrayOf("812345670", "هشام نافذ يوسف العبادلة", "1985-11-30", "متزوج", "على قيد الحياة", "", "ذكر", "0597881122", "0592665544", "خانيونس", "6", "مجمد", "عبير سعيد خليل البريم", "813456781"),
            arrayOf("408912345", "أنس رائد فتحي أبو مراحيل", "1991-09-12", "متزوج", "على قيد الحياة", "", "ذكر", "0595998877", "0567123450", "الوسطى", "4", "معتمد", "شيماء خالد محمد عقل", "409023456"),
            arrayOf("907891234", "سليم عطا الله حمدان الزعانين", "1977-04-25", "متزوج", "متوفى", "2023-11-12", "ذكر", "0599654789", "0598123987", "شمال غزة", "7", "معتمد", "وفاء محمد سليمان الكفارنة", "908912345"),
            arrayOf("412456789", "هبة الله سمير إبراهيم قاسم", "1989-01-17", "مطلق", "على قيد الحياة", "", "أنثى", "0594776622", "0597991133", "الوسطى", "3", "معتمد", "", ""),
            arrayOf("815678902", "عماد الدين تيسير محمود حلس", "1983-06-09", "متزوج", "على قيد الحياة", "", "ذكر", "0599102030", "0599405060", "غزة", "8", "معتمد", "سمية رفيق حسن الجعبري", "816789013"),
            arrayOf("414567893", "معاذ جمال عبد العزيز أبو جزر", "1995-08-23", "متزوج", "على قيد الحياة", "", "ذكر", "0568332211", "0595774411", "رفح", "3", "معتمد", "تسنيم مروان أحمد زعرب", "415678904"),
            arrayOf("918901234", "ناصر صبحي محمد العكلوك", "1975-12-01", "متزوج", "على قيد الحياة", "", "ذكر", "0599876543", "0597543210", "الوسطى", "9", "معتمد", "ختام عبد الله سلمان شاهين", "919012345"),
            arrayOf("818901235", "فادي أكرم سليمان شبير", "1986-02-14", "متزوج", "على قيد الحياة", "", "ذكر", "0592113355", "0598224466", "خانيونس", "5", "معتمد", "إسراء عماد محمد المجايدة", "819012346"),
            arrayOf("920123456", "وائل منير عبد الفتاح غبن", "1981-05-06", "متزوج", "على قيد الحياة", "", "ذكر", "0599336699", "0595112233", "شمال غزة", "6", "معتمد", "رشا حسام الدين خليل معروف", "921234567"),
            arrayOf("416789014", "حسام خالد عطية الحساينة", "1993-10-21", "أعزب", "على قيد الحياة", "", "ذكر", "0569887700", "0594665500", "غزة", "1", "قيد المراجعة", "", ""),
            arrayOf("924567895", "جمال الدين سعيد عمر أبو لبدة", "1979-03-16", "متزوج", "على قيد الحياة", "", "ذكر", "0597443322", "0599118822", "رفح", "8", "معتمد", "منى عبد الكريم سالم شيخ العيد", "925678906")
        )

        /**
         * بيانات تجريبية لجدول الأبناء (children_registry) مرتبطة بأرباب الأسر أعلاه بأعمار متنوعة
         * 0: parent_id | 1: parent_name | 2: child_id | 3: child_name | 4: gender | 5: social_status | 6: region | 7: city | 8: birth_date | 9: is_west_gaza
         */
        private val SAMPLE_CHILDREN_ROWS: List<Array<String>> = listOf(
            arrayOf("901245678", "أحمد محمود خليل السحار", "441001122", "ليان أحمد محمود السحار", "أنثى", "أعزب", "شمال غزة", "جباليا", "2025-07-18", "لا"),
            arrayOf("901245678", "أحمد محمود خليل السحار", "441001123", "كرم أحمد محمود السحار", "ذكر", "أعزب", "شمال غزة", "جباليا", "2024-02-11", "لا"),
            arrayOf("901245678", "أحمد محمود خليل السحار", "441001124", "محمود أحمد محمود السحار", "ذكر", "أعزب", "شمال غزة", "جباليا", "2018-09-05", "لا"),
            arrayOf("901245678", "أحمد محمود خليل السحار", "441001125", "سارة أحمد محمود السحار", "أنثى", "أعزب", "شمال غزة", "جباليا", "2014-05-20", "لا"),
            arrayOf("903456789", "محمد عبد الله سليمان أبو عاصي", "442002211", "جود محمد عبد الله أبو عاصي", "أنثى", "أعزب", "غزة", "الرمال", "2025-05-10", "نعم"),
            arrayOf("903456789", "محمد عبد الله سليمان أبو عاصي", "442002212", "عبد الله محمد عبد الله أبو عاصي", "ذكر", "أعزب", "غزة", "الرمال", "2021-11-24", "نعم"),
            arrayOf("903456789", "محمد عبد الله سليمان أبو عاصي", "442002213", "رغد محمد عبد الله أبو عاصي", "أنثى", "أعزب", "غزة", "الرمال", "2016-03-14", "نعم"),
            arrayOf("801122334", "خالد سعيد مصطفى حمدان", "443003311", "زين خالد سعيد حمدان", "ذكر", "أعزب", "الوسطى", "دير البلح", "2024-12-03", "لا"),
            arrayOf("801122334", "خالد سعيد مصطفى حمدان", "443003312", "ميار خالد سعيد حمدان", "أنثى", "أعزب", "الوسطى", "دير البلح", "2019-08-29", "لا"),
            arrayOf("402567891", "يوسف حسن إبراهيم العطار", "444004411", "آدم يوسف حسن العطار", "ذكر", "أعزب", "شمال غزة", "بيت لاهيا", "2025-09-01", "لا"),
            arrayOf("402567891", "يوسف حسن إبراهيم العطار", "444004412", "حلا يوسف حسن العطار", "أنثى", "أعزب", "شمال غزة", "بيت لاهيا", "2023-04-17", "لا"),
            arrayOf("911234567", "إبراهيم خليل رمضان الفرا", "445005511", "عمر إبراهيم خليل الفرا", "ذكر", "أعزب", "خانيونس", "البلد", "2022-06-12", "لا"),
            arrayOf("911234567", "إبراهيم خليل رمضان الفرا", "445005512", "تالا إبراهيم خليل الفرا", "أنثى", "أعزب", "خانيونس", "البلد", "2017-01-30", "لا"),
            arrayOf("905678912", "عبد الرحمن ناصر محمد المبحوح", "446006611", "ناصر عبد الرحمن ناصر المبحوح", "ذكر", "أعزب", "شمال غزة", "جباليا", "2020-10-08", "لا"),
            arrayOf("905678912", "عبد الرحمن ناصر محمد المبحوح", "446006612", "مريم عبد الرحمن ناصر المبحوح", "أنثى", "أعزب", "شمال غزة", "جباليا", "2024-06-22", "لا")
        )
    }
}
