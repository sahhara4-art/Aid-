package com.humanitarian.aidmanagement.util

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * نتيجة التحقق الفوري من قسيمة التسليم الرقمية بدون اتصال بالإنترنت.
 */
data class VoucherVerificationResult(
    val isValid: Boolean,
    val familyNationalId: String,
    val projectId: String,
    val beneficiaryName: String,
    val errorMessageAr: String
)

/**
 * محرك التوقيع والتحقق المشفّر للقسائم الرقمية دون اتصال بالإنترنت (Offline HMAC-SHA256).
 * يعتمد حصراً على مكتبات Android و Java القياسية المدمجة بدون أي مكتبات خارجية.
 */
object OfflineVoucherCrypto {

    const val PAYLOAD_PREFIX = "HUMV1"
    private const val DELIMITER = "|"
    private const val HMAC_ALGORITHM = "HmacSHA256"
    private const val SIGNATURE_LENGTH = 12
    private const val MAX_NAME_LENGTH = 48
    private const val PREFS_NAME = "offline_voucher_crypto_prefs"
    private const val KEY_SHARED_SIGNING_SECRET = "org_shared_hmac_secret_b64"

    /**
     * يجلب مفتاح التوقيع السري المشترك المحفوظ محلياً في SharedPreferences،
     * أو يولّد مفتاحاً عشوائياً آمناً (256-bit) عند أول استخدام ويحفظه محلياً.
     */
    fun getOrCreateSharedSecret(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY_SHARED_SIGNING_SECRET, null)?.trim()
        if (!existing.isNullOrBlank()) {
            return existing
        }

        val randomBytes = ByteArray(32)
        SecureRandom().nextBytes(randomBytes)
        val generated = Base64.encodeToString(randomBytes, Base64.NO_WRAP)
        prefs.edit().putString(KEY_SHARED_SIGNING_SECRET, generated).apply()
        return generated
    }

    /**
     * تعيين مفتاح توقيع مشترك موحّد لمزامنته بين أجهزة المؤسسة الميدانية دون إنترنت.
     */
    fun setSharedSecret(context: Context, sharedSecret: String) {
        val clean = sharedSecret.trim()
        if (clean.isBlank()) return
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_SHARED_SIGNING_SECRET, clean).apply()
    }

    /**
     * توليد نص قسيمة مضغوط وموقّع بصيغة:
     * HUMV1|<projectId>|<familyNationalId>|<beneficiaryName>|<hmacSignature12Chars>
     */
    fun generateVoucherPayload(
        context: Context,
        projectId: String,
        familyNationalId: String,
        beneficiaryName: String
    ): String {
        val cleanProjectId = sanitizeToken(normalizeDigits(projectId))
        val cleanNationalId = sanitizeToken(normalizeDigits(familyNationalId))
        val cleanName = sanitizeToken(beneficiaryName).take(MAX_NAME_LENGTH)

        val unsignedCore = buildString {
            append(PAYLOAD_PREFIX)
            append(DELIMITER)
            append(cleanProjectId)
            append(DELIMITER)
            append(cleanNationalId)
            append(DELIMITER)
            append(cleanName)
        }

        val secret = getOrCreateSharedSecret(context)
        val signature12 = computeHmacSignature12(unsignedCore, secret)
        return "$unsignedCore$DELIMITER$signature12"
    }

    /**
     * التحقق الفوري من صحة القسيمة الممسوحة بالكاميرا بدون إنترنت:
     * 1. التحقق من البادئة HUMV1 وبنية الحقول الخمسة.
     * 2. إعادة حساب توقيع HmacSHA256 ومقارنته بزمن ثابت لمنع التزوير.
     * 3. التحقق من تطابق رقم المشروع مع المشروع المفتوح حالياً (expectedProjectId).
     */
    fun verifyVoucherPayload(
        context: Context,
        rawQrText: String,
        expectedProjectId: String
    ): VoucherVerificationResult {
        val trimmed = rawQrText.trim()
        if (trimmed.isBlank()) {
            return VoucherVerificationResult(
                isValid = false,
                familyNationalId = "",
                projectId = "",
                beneficiaryName = "",
                errorMessageAr = "قسيمة غير صالحة أو مزورة"
            )
        }

        val parts = trimmed.split(DELIMITER)
        if (parts.size != 5) {
            return VoucherVerificationResult(
                isValid = false,
                familyNationalId = "",
                projectId = "",
                beneficiaryName = "",
                errorMessageAr = "قسيمة غير صالحة أو مزورة"
            )
        }

        val prefix = parts[0].trim()
        val parsedProjectId = sanitizeToken(normalizeDigits(parts[1]))
        val parsedNationalId = sanitizeToken(normalizeDigits(parts[2]))
        val parsedName = sanitizeToken(parts[3])
        val providedSignature = parts[4].trim()

        if (prefix != PAYLOAD_PREFIX ||
            parsedProjectId.isBlank() ||
            parsedNationalId.isBlank() ||
            providedSignature.length != SIGNATURE_LENGTH
        ) {
            return VoucherVerificationResult(
                isValid = false,
                familyNationalId = parsedNationalId,
                projectId = parsedProjectId,
                beneficiaryName = parsedName,
                errorMessageAr = "قسيمة غير صالحة أو مزورة"
            )
        }

        val unsignedCore = "$PAYLOAD_PREFIX$DELIMITER$parsedProjectId$DELIMITER$parsedNationalId$DELIMITER$parsedName"
        val secret = getOrCreateSharedSecret(context)
        val expectedSignature = computeHmacSignature12(unsignedCore, secret)

        val signatureMatches = MessageDigest.isEqual(
            expectedSignature.toByteArray(Charsets.UTF_8),
            providedSignature.toByteArray(Charsets.UTF_8)
        )

        if (!signatureMatches) {
            return VoucherVerificationResult(
                isValid = false,
                familyNationalId = parsedNationalId,
                projectId = parsedProjectId,
                beneficiaryName = parsedName,
                errorMessageAr = "قسيمة غير صالحة أو مزورة"
            )
        }

        val cleanExpectedProjectId = sanitizeToken(normalizeDigits(expectedProjectId))
        if (cleanExpectedProjectId.isNotBlank() && parsedProjectId != cleanExpectedProjectId) {
            return VoucherVerificationResult(
                isValid = false,
                familyNationalId = parsedNationalId,
                projectId = parsedProjectId,
                beneficiaryName = parsedName,
                errorMessageAr = "هذه القسيمة تخص مشروعاً آخر"
            )
        }

        return VoucherVerificationResult(
            isValid = true,
            familyNationalId = parsedNationalId,
            projectId = parsedProjectId,
            beneficiaryName = parsedName,
            errorMessageAr = ""
        )
    }

    private fun computeHmacSignature12(data: String, sharedSecret: String): String {
        val secretBytes = decodeSecretBytes(sharedSecret)
        val mac = Mac.getInstance(HMAC_ALGORITHM)
        mac.init(SecretKeySpec(secretBytes, HMAC_ALGORITHM))
        val digest = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        val encoded = Base64.encodeToString(
            digest,
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        )
        return encoded.take(SIGNATURE_LENGTH)
    }

    private fun decodeSecretBytes(sharedSecret: String): ByteArray {
        return runCatching {
            val decoded = Base64.decode(sharedSecret, Base64.DEFAULT)
            if (decoded.isNotEmpty()) decoded else sharedSecret.toByteArray(Charsets.UTF_8)
        }.getOrElse {
            sharedSecret.toByteArray(Charsets.UTF_8)
        }
    }

    private fun sanitizeToken(raw: String): String {
        return raw
            .replace(DELIMITER, " ")
            .replace("\r", " ")
            .replace("\n", " ")
            .trim()
            .replace(Regex("\\s+"), " ")
    }

    private fun normalizeDigits(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return ""
        val sb = StringBuilder(trimmed.length)
        for (ch in trimmed) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }
}
