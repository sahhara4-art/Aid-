package com.humanitarian.aidmanagement.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.TextUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil

enum class BulkVoucherDensity(
    val cardsPerPage: Int,
    val columns: Int,
    val rows: Int,
    val arabicLabel: String
) {
    CARDS_24(24, 3, 8, "24 بطاقة في الصفحة (3×8)"),
    CARDS_21(21, 3, 7, "21 بطاقة في الصفحة (3×7)")
}

data class BulkVoucherBeneficiaryItem(
    val serialNumber: Int,
    val familyId: Long,
    val nationalId: String,
    val beneficiaryName: String,
    val familySize: Int,
    val isDelivered: Boolean
)

data class BulkA4VouchersConfig(
    val projectId: Long,
    val projectName: String,
    val projectNumber: String = "",
    val aidTypeName: String,
    val pickupDate: String,
    val pickupTime: String,
    val pickupLocation: String,
    val density: BulkVoucherDensity = BulkVoucherDensity.CARDS_24
)

data class BulkA4PdfExportResult(
    val savedResult: SavedExportResult,
    val totalCards: Int,
    val totalPages: Int
)

data class BulkA4PrintFileResult(
    val file: File,
    val jobName: String,
    val totalCards: Int,
    val totalPages: Int
)

/**
 * مولّد بطاقات التوزيع الجماعية على ورق A4 (1240x1754 @ 150 DPI) بواقع 24 بطاقة (3×8) أو 21 بطاقة (3×7) في الصفحة.
 * يستخدم نفس صيغة التوقيع المشفّر في بطاقة واتساب (OfflineVoucherCrypto.generateVoucherPayload)
 * ويرسم رمز QR قياسي (ISO/IEC 18004) بحجم 130x130 بكسل مع تحرير فوري للذاكرة (qrBitmap.recycle()).
 */
object BulkA4VouchersPdfGenerator {

    const val PAGE_WIDTH = 1240
    const val PAGE_HEIGHT = 1754
    private const val PAGE_MARGIN_X = 28f
    private const val PAGE_MARGIN_Y = 28f
    private const val CELL_INSET = 7f
    private const val QR_SIZE_PX = 130

    private val COLOR_EMERALD_BORDER = Color.parseColor("#059669")
    private val COLOR_HEADER_DARK_GREEN = Color.parseColor("#065F46")
    private val COLOR_TEXT_PRIMARY = Color.parseColor("#0F172A")
    private val COLOR_TEXT_SECONDARY = Color.parseColor("#1E293B")
    private val COLOR_TEXT_ACCENT = Color.parseColor("#047857")
    private val COLOR_TEXT_LOCATION = Color.parseColor("#334155")
    private val COLOR_CUT_LINE = Color.parseColor("#94A3B8")
    private val COLOR_DIVIDER = Color.parseColor("#D1FAE5")

    fun calculatePageCount(totalCards: Int, density: BulkVoucherDensity): Int {
        if (totalCards <= 0) return 0
        return ceil(totalCards.toDouble() / density.cardsPerPage.toDouble()).toInt()
    }

    /**
     * توليد ملف PDF وحفظه مباشرة في مجلد التنزيلات العام: Downloads/HumanitarianAid
     */
    suspend fun generateAndSaveToDownloads(
        context: Context,
        config: BulkA4VouchersConfig,
        beneficiaries: List<BulkVoucherBeneficiaryItem>,
        fileProviderAuthority: String? = null
    ): BulkA4PdfExportResult = withContext(Dispatchers.IO) {
        require(beneficiaries.isNotEmpty()) { "لا يوجد مستفيدون لطباعة بطاقاتهم" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safeProjToken = sanitizeFileToken(config.projectNumber.ifBlank { config.projectId.toString() })
            .ifBlank { config.projectId.toString() }
        val fileName = "vouchers_A4_P${safeProjToken}_${beneficiaries.size}cards_$stamp.pdf"
        val totalPages = calculatePageCount(beneficiaries.size, config.density)

        val savedResult = PublicDownloadsExporter.savePdfToPublicDownloads(
            context = context,
            fileName = fileName,
            fileProviderAuthority = fileProviderAuthority
        ) { outputStream ->
            writeVouchersPdfToStream(
                context = context,
                config = config,
                beneficiaries = beneficiaries,
                outputStream = outputStream
            )
        }

        BulkA4PdfExportResult(
            savedResult = savedResult,
            totalCards = beneficiaries.size,
            totalPages = totalPages
        )
    }

    /**
     * توليد ملف PDF مؤقت في الذاكرة المخبأة للطباعة المباشرة عبر نظام الطباعة في أندرويد (PrintManager).
     */
    suspend fun generateTempPdfForPrinting(
        context: Context,
        config: BulkA4VouchersConfig,
        beneficiaries: List<BulkVoucherBeneficiaryItem>
    ): BulkA4PrintFileResult = withContext(Dispatchers.IO) {
        require(beneficiaries.isNotEmpty()) { "لا يوجد مستفيدون لطباعة بطاقاتهم" }
        val printDir = File(context.cacheDir, "vouchers_print").apply {
            if (!exists()) mkdirs()
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outFile = File(printDir, "vouchers_A4_${config.projectId}_$stamp.pdf")
        val totalPages = calculatePageCount(beneficiaries.size, config.density)

        FileOutputStream(outFile).use { fos ->
            writeVouchersPdfToStream(
                context = context,
                config = config,
                beneficiaries = beneficiaries,
                outputStream = fos
            )
            fos.flush()
        }

        BulkA4PrintFileResult(
            file = outFile,
            jobName = "بطاقات_توزيع_A4_${config.projectNumber.ifBlank { config.projectId.toString() }}",
            totalCards = beneficiaries.size,
            totalPages = totalPages
        )
    }

    /**
     * فتح نظام الطباعة الأصلي في أندرويد (PrintManager) مباشرة على مقاس ورق A4.
     */
    fun launchAndroidPrintManager(
        context: Context,
        printFileResult: BulkA4PrintFileResult
    ): Boolean {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return false
        return runCatching {
            val adapter = object : PrintDocumentAdapter() {
                override fun onLayout(
                    oldAttributes: PrintAttributes?,
                    newAttributes: PrintAttributes?,
                    cancellationSignal: CancellationSignal?,
                    callback: LayoutResultCallback?,
                    extras: Bundle?
                ) {
                    if (cancellationSignal?.isCanceled == true) {
                        callback?.onLayoutCancelled()
                        return
                    }
                    val info = PrintDocumentInfo.Builder("${printFileResult.jobName}.pdf")
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(printFileResult.totalPages)
                        .build()
                    callback?.onLayoutFinished(info, true)
                }

                override fun onWrite(
                    pages: Array<out PageRange>?,
                    destination: ParcelFileDescriptor?,
                    cancellationSignal: CancellationSignal?,
                    callback: WriteResultCallback?
                ) {
                    val fd = destination?.fileDescriptor
                    if (fd == null) {
                        callback?.onWriteFailed("تعذر الوصول إلى وجهة الطباعة")
                        return
                    }
                    try {
                        FileInputStream(printFileResult.file).use { input ->
                            FileOutputStream(fd).use { output ->
                                input.copyTo(output)
                            }
                        }
                        callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                    } catch (t: Throwable) {
                        callback?.onWriteFailed(t.message)
                    }
                }
            }

            val attributes = PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build()

            printManager.print(printFileResult.jobName, adapter, attributes)
            true
        }.getOrDefault(false)
    }

    private fun writeVouchersPdfToStream(
        context: Context,
        config: BulkA4VouchersConfig,
        beneficiaries: List<BulkVoucherBeneficiaryItem>,
        outputStream: OutputStream
    ) {
        val density = config.density
        val columns = density.columns
        val rows = density.rows
        val cardsPerPage = density.cardsPerPage
        val totalPages = calculatePageCount(beneficiaries.size, density)

        val gridWidth = PAGE_WIDTH - (PAGE_MARGIN_X * 2f)
        val gridHeight = PAGE_HEIGHT - (PAGE_MARGIN_Y * 2f)
        val cellWidth = gridWidth / columns.toFloat()
        val cellHeight = gridHeight / rows.toFloat()

        // أدوات الرسم المشتركة لتجنب تخصيص الكائنات داخل الحلقات
        val cutLinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_CUT_LINE
            style = Paint.Style.STROKE
            strokeWidth = 1.4f
            pathEffect = DashPathEffect(floatArrayOf(10f, 8f), 0f)
        }
        val cardFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val cardBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_EMERALD_BORDER
            style = Paint.Style.STROKE
            strokeWidth = 2.4f
        }
        val headerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_HEADER_DARK_GREEN
            style = Paint.Style.FILL
        }
        val innerDividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_DIVIDER
            strokeWidth = 1.4f
        }
        val qrBitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            isAntiAlias = false
            isFilterBitmap = false
        }
        val headerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_PRIMARY
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        val detailsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_SECONDARY
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        val schedulePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_ACCENT
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        val qrCaptionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_PRIMARY
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val locationTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = COLOR_TEXT_LOCATION
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textSize = if (density == BulkVoucherDensity.CARDS_21) 12.2f else 11.2f
        }

        val headerTitleRaw = buildString {
            val aidPart = config.aidTypeName.trim().ifBlank { "مساعدة إنسانية" }
            val prjPart = config.projectName.trim().ifBlank { "مشروع #${config.projectId}" }
            append(aidPart)
            append(" • ")
            append(prjPart)
        }
        val dateClean = config.pickupDate.trim().ifBlank { "-" }
        val timeClean = config.pickupTime.trim().ifBlank { "-" }
        val scheduleLineText = "📅 $dateClean  ⏰ $timeClean"
        val locationLineText = "📍 ${config.pickupLocation.trim().ifBlank { "نقطة التوزيع المعتمدة" }}"

        val pdfDocument = PdfDocument()
        try {
            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                // خلفية بيضاء صافية موفرة للحبر
                canvas.drawColor(Color.WHITE)

                val startItemIndex = pageIndex * cardsPerPage
                val endItemIndex = minOf(startItemIndex + cardsPerPage, beneficiaries.size)

                // خطوط القص المتقطعة للشبكة
                drawDashedCuttingGrid(
                    canvas = canvas,
                    columns = columns,
                    rows = rows,
                    cellWidth = cellWidth,
                    cellHeight = cellHeight,
                    paint = cutLinePaint
                )

                for (idx in startItemIndex until endItemIndex) {
                    val slot = idx - startItemIndex
                    val row = slot / columns
                    val col = slot % columns
                    // ترتيب البطاقات من اليمين إلى اليسار (RTL) لتسهيل التسلسل العربي عند الطباعة والقص
                    val rtlCol = (columns - 1) - col

                    val cellLeft = PAGE_MARGIN_X + rtlCol * cellWidth
                    val cellTop = PAGE_MARGIN_Y + row * cellHeight
                    val cardRect = RectF(
                        cellLeft + CELL_INSET,
                        cellTop + CELL_INSET,
                        cellLeft + cellWidth - CELL_INSET,
                        cellTop + cellHeight - CELL_INSET
                    )

                    drawSingleVoucherCard(
                        context = context,
                        canvas = canvas,
                        cardRect = cardRect,
                        item = beneficiaries[idx],
                        projectIdStr = config.projectId.toString(),
                        headerTitle = headerTitleRaw,
                        scheduleLineText = scheduleLineText,
                        locationLineText = locationLineText,
                        isSpacious21 = density == BulkVoucherDensity.CARDS_21,
                        cardFillPaint = cardFillPaint,
                        cardBorderPaint = cardBorderPaint,
                        headerBgPaint = headerBgPaint,
                        innerDividerPaint = innerDividerPaint,
                        qrBitmapPaint = qrBitmapPaint,
                        headerTextPaint = headerTextPaint,
                        namePaint = namePaint,
                        detailsPaint = detailsPaint,
                        schedulePaint = schedulePaint,
                        qrCaptionPaint = qrCaptionPaint,
                        locationTextPaint = locationTextPaint
                    )
                }

                pdfDocument.finishPage(page)
            }

            pdfDocument.writeTo(outputStream)
        } finally {
            pdfDocument.close()
        }
    }

    private fun drawDashedCuttingGrid(
        canvas: Canvas,
        columns: Int,
        rows: Int,
        cellWidth: Float,
        cellHeight: Float,
        paint: Paint
    ) {
        val left = PAGE_MARGIN_X
        val right = PAGE_MARGIN_X + columns * cellWidth
        val top = PAGE_MARGIN_Y
        val bottom = PAGE_MARGIN_Y + rows * cellHeight

        for (c in 0..columns) {
            val x = left + c * cellWidth
            canvas.drawLine(x, top, x, bottom, paint)
        }
        for (r in 0..rows) {
            val y = top + r * cellHeight
            canvas.drawLine(left, y, right, y, paint)
        }
    }

    private fun drawSingleVoucherCard(
        context: Context,
        canvas: Canvas,
        cardRect: RectF,
        item: BulkVoucherBeneficiaryItem,
        projectIdStr: String,
        headerTitle: String,
        scheduleLineText: String,
        locationLineText: String,
        isSpacious21: Boolean,
        cardFillPaint: Paint,
        cardBorderPaint: Paint,
        headerBgPaint: Paint,
        innerDividerPaint: Paint,
        qrBitmapPaint: Paint,
        headerTextPaint: Paint,
        namePaint: Paint,
        detailsPaint: Paint,
        schedulePaint: Paint,
        qrCaptionPaint: Paint,
        locationTextPaint: TextPaint
    ) {
        // 1) إطار البطاقة الخارجي (أبيض نقي + حدود زمردية دائرية)
        canvas.drawRoundRect(cardRect, 12f, 12f, cardFillPaint)
        canvas.drawRoundRect(cardRect, 12f, 12f, cardBorderPaint)

        // 2) القسم الأيسر: رمز QR بحجم 130x130 بكسل + رقم التسلسل والهوية أسفله
        val qrLeft = cardRect.left + 8f
        val qrRight = qrLeft + QR_SIZE_PX
        val qrBlockHeight = QR_SIZE_PX + 24f
        val qrTop = cardRect.top + ((cardRect.height() - qrBlockHeight) / 2f).coerceAtLeast(10f)
        val qrBottom = qrTop + QR_SIZE_PX
        val qrDestRect = Rect(
            qrLeft.toInt(),
            qrTop.toInt(),
            qrRight.toInt(),
            qrBottom.toInt()
        )

        // نفس دالة وتشفير بطاقة واتساب بالضبط لضمان المسح المباشر في شاشة التسليم
        val signedPayload = OfflineVoucherCrypto.generateVoucherPayload(
            context = context,
            projectId = projectIdStr,
            familyNationalId = item.nationalId,
            beneficiaryName = item.beneficiaryName
        )

        val qrBitmap = QrCodeMatrixEncoder.createQrBitmap(
            content = signedPayload,
            sizePx = QR_SIZE_PX
        )
        try {
            canvas.drawBitmap(qrBitmap, null, qrDestRect, qrBitmapPaint)
        } finally {
            if (!qrBitmap.isRecycled) {
                qrBitmap.recycle()
            }
        }

        val qrCenterX = (qrLeft + qrRight) / 2f
        val idCaption = buildString {
            append("#${item.serialNumber}")
            val nid = item.nationalId.trim()
            if (nid.isNotBlank()) {
                append(" • ")
                append(nid)
            }
        }
        fitSingleLinePaint(
            text = idCaption,
            paint = qrCaptionPaint,
            maxWidth = QR_SIZE_PX + 6f,
            startSize = 11.5f,
            minSize = 8.5f
        )
        canvas.drawText(
            ellipsizeText(idCaption, qrCaptionPaint, QR_SIZE_PX + 6f),
            qrCenterX,
            qrBottom + 16f,
            qrCaptionPaint
        )

        // فاصل عمودي رقيق بين منطقة QR ومنطقة البيانات العربية
        val separatorX = qrRight + 7f
        canvas.drawLine(separatorX, cardRect.top + 10f, separatorX, cardRect.bottom - 10f, innerDividerPaint)

        // 3) القسم الأيمن (محاذاة عربية RTL منسقة)
        val contentLeft = separatorX + 7f
        val contentRight = cardRect.right - 9f
        val contentWidth = (contentRight - contentLeft).coerceAtLeast(120f)

        // 3.1) شريط العنوان العلوي بلون أخضر داكن (#065F46) ونص أبيض
        val headerHeight = if (isSpacious21) 33f else 29f
        val headerRect = RectF(
            contentLeft,
            cardRect.top + 8f,
            contentRight,
            cardRect.top + 8f + headerHeight
        )
        canvas.drawRoundRect(headerRect, 7f, 7f, headerBgPaint)

        fitSingleLinePaint(
            text = headerTitle,
            paint = headerTextPaint,
            maxWidth = contentWidth - 10f,
            startSize = if (isSpacious21) 13f else 12f,
            minSize = 9.2f
        )
        val headerTextY = headerRect.centerY() - ((headerTextPaint.descent() + headerTextPaint.ascent()) / 2f)
        canvas.drawText(
            ellipsizeText(headerTitle, headerTextPaint, contentWidth - 10f),
            headerRect.centerX(),
            headerTextY,
            headerTextPaint
        )

        var yCursor = headerRect.bottom + (if (isSpacious21) 24f else 21f)

        // 3.2) اسم المستفيد (رب الأسرة) بخط أسود عريض مع تقليص تلقائي للاسماء الطويلة
        val cleanName = item.beneficiaryName.trim().ifBlank { "مستفيد غير مسمى" }
        fitSingleLinePaint(
            text = cleanName,
            paint = namePaint,
            maxWidth = contentWidth,
            startSize = if (isSpacious21) 17.5f else 16f,
            minSize = 10.5f
        )
        canvas.drawText(
            ellipsizeText(cleanName, namePaint, contentWidth),
            contentRight,
            yCursor,
            namePaint
        )

        // 3.3) بيانات المستفيد: الهوية | الأفراد
        yCursor += if (isSpacious21) 25f else 22f
        val detailsLine = "الهوية: ${item.nationalId.trim().ifBlank { "-" }}  |  الأفراد: ${item.familySize}"
        fitSingleLinePaint(
            text = detailsLine,
            paint = detailsPaint,
            maxWidth = contentWidth,
            startSize = if (isSpacious21) 12.6f else 11.6f,
            minSize = 9.2f
        )
        canvas.drawText(
            ellipsizeText(detailsLine, detailsPaint, contentWidth),
            contentRight,
            yCursor,
            detailsPaint
        )

        // 3.4) موعد الاستلام: التاريخ والوقت
        yCursor += if (isSpacious21) 24f else 21f
        fitSingleLinePaint(
            text = scheduleLineText,
            paint = schedulePaint,
            maxWidth = contentWidth,
            startSize = if (isSpacious21) 12f else 11f,
            minSize = 8.6f
        )
        canvas.drawText(
            ellipsizeText(scheduleLineText, schedulePaint, contentWidth),
            contentRight,
            yCursor,
            schedulePaint
        )

        // 3.5) مكان الاستلام (سطران كحد أقصى عبر StaticLayout RTL)
        val locationTop = yCursor + (if (isSpacious21) 10f else 8f)
        val remainingHeight = (cardRect.bottom - 6f - locationTop).coerceAtLeast(18f)
        val locationLayout = StaticLayout.Builder
            .obtain(locationLineText, 0, locationLineText.length, locationTextPaint, contentWidth.toInt())
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setMaxLines(2)
            .setEllipsize(TextUtils.TruncateAt.END)
            .setLineSpacing(2f, 1.05f)
            .build()

        canvas.save()
        canvas.clipRect(contentLeft, locationTop, contentRight, locationTop + remainingHeight)
        canvas.translate(contentLeft, locationTop)
        locationLayout.draw(canvas)
        canvas.restore()
    }

    private fun fitSingleLinePaint(
        text: String,
        paint: Paint,
        maxWidth: Float,
        startSize: Float,
        minSize: Float
    ) {
        var size = startSize
        paint.textSize = size
        while (size > minSize && paint.measureText(text) > maxWidth) {
            size -= 0.6f
            paint.textSize = size
        }
    }

    private fun ellipsizeText(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        val suffix = "..."
        var end = text.length
        while (end > 1 && paint.measureText(text.substring(0, end) + suffix) > maxWidth) {
            end--
        }
        return text.substring(0, end) + suffix
    }

    private fun sanitizeFileToken(raw: String): String {
        return raw.trim().replace(Regex("[^A-Za-z0-9_-]"), "")
    }
}

/**
 * مولّد رمز QR قياسي (ISO/IEC 18004 - Byte Mode - ECC Level L - Versions 1..10)
 * مكتوب بلغة Kotlin الصافية بدون أي مكتبات خارجية لينتج رمز QR قابلاً للمسح الفوري عبر الكاميرا و ML Kit.
 */
private object QrCodeMatrixEncoder {

    private data class VersionSpec(
        val version: Int,
        val ecPerBlock: Int,
        val g1Blocks: Int,
        val g1Data: Int,
        val g2Blocks: Int,
        val g2Data: Int,
        val alignmentCenters: IntArray
    ) {
        val totalDataCodewords: Int get() = g1Blocks * g1Data + g2Blocks * g2Data
        val size: Int get() = 17 + version * 4
    }

    // مواصفات ISO/IEC 18004 (المستوى L) للإصدارات 1 إلى 10 (تستوعب حتى 271 بايت UTF-8)
    private val SPECS_L = arrayOf(
        VersionSpec(1, 7, 1, 19, 0, 0, intArrayOf()),
        VersionSpec(2, 10, 1, 34, 0, 0, intArrayOf(6, 18)),
        VersionSpec(3, 15, 1, 55, 0, 0, intArrayOf(6, 22)),
        VersionSpec(4, 20, 1, 80, 0, 0, intArrayOf(6, 26)),
        VersionSpec(5, 26, 1, 108, 0, 0, intArrayOf(6, 30)),
        VersionSpec(6, 18, 2, 68, 0, 0, intArrayOf(6, 34)),
        VersionSpec(7, 20, 2, 78, 0, 0, intArrayOf(6, 22, 38)),
        VersionSpec(8, 24, 2, 97, 0, 0, intArrayOf(6, 24, 42)),
        VersionSpec(9, 30, 2, 116, 0, 0, intArrayOf(6, 26, 46)),
        VersionSpec(10, 18, 2, 68, 2, 69, intArrayOf(6, 28, 50))
    )

    // جداول الحقل المنتهي GF(256) بمتعددة الحدود 0x11D
    private val GF_EXP = IntArray(512)
    private val GF_LOG = IntArray(256)

    init {
        var v = 1
        for (i in 0 until 255) {
            GF_EXP[i] = v
            GF_LOG[v] = i
            v = v shl 1
            if ((v and 0x100) != 0) {
                v = v xor 0x11D
            }
        }
        for (i in 255 until 512) {
            GF_EXP[i] = GF_EXP[i - 255]
        }
    }

    fun createQrBitmap(content: String, sizePx: Int): Bitmap {
        val matrix = encodeByteModeL(content.toByteArray(Charsets.UTF_8))
        val moduleCount = matrix.size
        val quietZone = 2
        val totalModules = moduleCount + quietZone * 2

        val bitmap = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.RGB_565)
        val pixels = IntArray(sizePx * sizePx)
        pixels.fill(Color.WHITE)

        val scale = sizePx.toFloat() / totalModules.toFloat()
        for (r in 0 until moduleCount) {
            val yStart = ((r + quietZone) * scale).toInt().coerceIn(0, sizePx)
            val yEnd = (((r + quietZone + 1) * scale).toInt()).coerceIn(yStart, sizePx)
            val rowData = matrix[r]
            for (c in 0 until moduleCount) {
                if (rowData[c]) {
                    val xStart = ((c + quietZone) * scale).toInt().coerceIn(0, sizePx)
                    val xEnd = (((c + quietZone + 1) * scale).toInt()).coerceIn(xStart, sizePx)
                    for (py in yStart until yEnd) {
                        val rowOffset = py * sizePx
                        for (px in xStart until xEnd) {
                            pixels[rowOffset + px] = Color.BLACK
                        }
                    }
                }
            }
        }
        bitmap.setPixels(pixels, 0, sizePx, 0, 0, sizePx, sizePx)
        return bitmap
    }

    private fun encodeByteModeL(rawBytes: ByteArray): Array<BooleanArray> {
        val spec = SPECS_L.firstOrNull { s ->
            val countBits = if (s.version <= 9) 8 else 16
            val neededBits = 4 + countBits + rawBytes.size * 8
            neededBits <= s.totalDataCodewords * 8
        } ?: SPECS_L.last()

        val countBits = if (spec.version <= 9) 8 else 16
        val maxBytesAllowed = ((spec.totalDataCodewords * 8 - 4 - countBits) / 8).coerceAtLeast(1)
        val dataBytes = if (rawBytes.size > maxBytesAllowed) {
            rawBytes.copyOf(maxBytesAllowed)
        } else {
            rawBytes
        }

        // 1) بناء دفق البتات (Mode 0100 + Char Count + Data + Terminator + Pad)
        val totalDataBits = spec.totalDataCodewords * 8
        val bits = ArrayList<Int>(totalDataBits)

        fun appendBits(value: Int, bitCount: Int) {
            for (i in (bitCount - 1) downTo 0) {
                bits.add((value ushr i) and 1)
            }
        }

        appendBits(0b0100, 4) // Byte mode
        appendBits(dataBytes.size, countBits)
        for (b in dataBytes) {
            appendBits(b.toInt() and 0xFF, 8)
        }
        val terminatorLen = minOf(4, totalDataBits - bits.size)
        for (i in 0 until terminatorLen) bits.add(0)
        while (bits.size % 8 != 0) bits.add(0)

        val dataCodewords = IntArray(spec.totalDataCodewords)
        var cwIdx = 0
        var bitPtr = 0
        while (bitPtr < bits.size && cwIdx < dataCodewords.size) {
            var byteVal = 0
            for (b in 0 until 8) {
                byteVal = (byteVal shl 1) or bits[bitPtr++]
            }
            dataCodewords[cwIdx++] = byteVal
        }
        var padToggle = true
        while (cwIdx < dataCodewords.size) {
            dataCodewords[cwIdx++] = if (padToggle) 0xEC else 0x11
            padToggle = !padToggle
        }

        // 2) تقسيم الكتل وحساب رموز تصحيح الخطأ Reed-Solomon ثم دمجها
        val dataBlocks = ArrayList<IntArray>()
        val ecBlocks = ArrayList<IntArray>()
        val rsGenerator = buildRsGenerator(spec.ecPerBlock)

        var offset = 0
        for (b in 0 until spec.g1Blocks) {
            val block = dataCodewords.copyOfRange(offset, offset + spec.g1Data)
            offset += spec.g1Data
            dataBlocks.add(block)
            ecBlocks.add(computeRsEcc(block, rsGenerator, spec.ecPerBlock))
        }
        for (b in 0 until spec.g2Blocks) {
            val block = dataCodewords.copyOfRange(offset, offset + spec.g2Data)
            offset += spec.g2Data
            dataBlocks.add(block)
            ecBlocks.add(computeRsEcc(block, rsGenerator, spec.ecPerBlock))
        }

        val finalCodewords = ArrayList<Int>(spec.totalDataCodewords + (spec.g1Blocks + spec.g2Blocks) * spec.ecPerBlock)
        val maxDataBlockLen = maxOf(spec.g1Data, spec.g2Data)
        for (i in 0 until maxDataBlockLen) {
            for (blk in dataBlocks) {
                if (i < blk.size) finalCodewords.add(blk[i])
            }
        }
        for (i in 0 until spec.ecPerBlock) {
            for (ec in ecBlocks) {
                finalCodewords.add(ec[i])
            }
        }

        // 3) إنشاء المصفوفة ورسم الأنماط الوظيفية
        val size = spec.size
        val baseModules = Array(size) { BooleanArray(size) }
        val isFunction = Array(size) { BooleanArray(size) }

        drawFunctionPatterns(spec, baseModules, isFunction)
        placeCodewords(baseModules, isFunction, finalCodewords)

        // 4) اختيار أفضل قناع (Mask 0..7) بأقل عقوبة بصرية لضمان أعلى سرعة قراءة بالكاميرا
        var bestMask = 0
        var bestPenalty = Int.MAX_VALUE
        var bestMatrix: Array<BooleanArray>? = null

        for (mask in 0..7) {
            val candidate = Array(size) { r -> baseModules[r].copyOf() }
            applyMask(candidate, isFunction, mask)
            drawFormatBits(candidate, mask)
            val penalty = computePenaltyScore(candidate)
            if (penalty < bestPenalty) {
                bestPenalty = penalty
                bestMask = mask
                bestMatrix = candidate
            }
        }

        return bestMatrix ?: run {
            applyMask(baseModules, isFunction, bestMask)
            drawFormatBits(baseModules, bestMask)
            baseModules
        }
    }

    private fun gfMul(a: Int, b: Int): Int {
        if (a == 0 || b == 0) return 0
        return GF_EXP[GF_LOG[a] + GF_LOG[b]]
    }

    private fun buildRsGenerator(degree: Int): IntArray {
        var poly = intArrayOf(1)
        for (i in 0 until degree) {
            val next = IntArray(poly.size + 1)
            val factor = GF_EXP[i]
            for (j in poly.indices) {
                next[j] = next[j] xor poly[j]
                next[j + 1] = next[j + 1] xor gfMul(poly[j], factor)
            }
            poly = next
        }
        return poly
    }

    private fun computeRsEcc(data: IntArray, generator: IntArray, ecCount: Int): IntArray {
        val rem = IntArray(ecCount)
        for (byteVal in data) {
            val factor = byteVal xor rem[0]
            for (i in 0 until ecCount - 1) {
                rem[i] = rem[i + 1]
            }
            rem[ecCount - 1] = 0
            if (factor != 0) {
                for (i in 0 until ecCount) {
                    rem[i] = rem[i] xor gfMul(generator[i + 1], factor)
                }
            }
        }
        return rem
    }

    private fun drawFunctionPatterns(
        spec: VersionSpec,
        modules: Array<BooleanArray>,
        isFunction: Array<BooleanArray>
    ) {
        val size = spec.size

        fun setFunc(r: Int, c: Int, dark: Boolean) {
            if (r in 0 until size && c in 0 until size) {
                modules[r][c] = dark
                isFunction[r][c] = true
            }
        }

        // أنماط التحديد الثلاثة (Finder Patterns + Separators)
        fun drawFinder(centerR: Int, centerC: Int) {
            for (dr in -4..4) {
                for (dc in -4..4) {
                    val rr = centerR + dr
                    val cc = centerC + dc
                    if (rr in 0 until size && cc in 0 until size) {
                        val dist = maxOf(abs(dr), abs(dc))
                        val dark = dist != 2 && dist != 4
                        setFunc(rr, cc, dark)
                    }
                }
            }
        }

        drawFinder(3, 3)
        drawFinder(3, size - 4)
        drawFinder(size - 4, 3)

        // أنماط التوقيت (Timing Patterns)
        for (i in 8 until size - 8) {
            val dark = (i % 2 == 0)
            setFunc(6, i, dark)
            setFunc(i, 6, dark)
        }

        // أنماط المحاذاة (Alignment Patterns)
        val centers = spec.alignmentCenters
        for (i in centers.indices) {
            for (j in centers.indices) {
                val isCornerOverlap =
                    (i == 0 && j == 0) ||
                        (i == 0 && j == centers.lastIndex) ||
                        (i == centers.lastIndex && j == 0)
                if (!isCornerOverlap) {
                    val cr = centers[i]
                    val cc = centers[j]
                    for (dr in -2..2) {
                        for (dc in -2..2) {
                            val dist = maxOf(abs(dr), abs(dc))
                            setFunc(cr + dr, cc + dc, dist != 1)
                        }
                    }
                }
            }
        }

        // حجز مواقع معلومات التنسيق (Format Info) والوحدة الداكنة الثابتة
        for (i in 0..8) {
            if (i != 6) {
                setFunc(8, i, false)
                setFunc(i, 8, false)
            }
        }
        for (i in 0..7) {
            setFunc(8, size - 1 - i, false)
        }
        for (i in 0..6) {
            setFunc(size - 1 - i, 8, false)
        }
        setFunc(size - 8, 8, true) // Dark module

        // معلومات الإصدار (للإصدار 7 فأعلى)
        if (spec.version >= 7) {
            var rem = spec.version
            for (i in 0 until 12) {
                rem = (rem shl 1) xor (((rem ushr 11) and 1) * 0x1F25)
            }
            val versionBits = (spec.version shl 12) or rem
            for (i in 0 until 18) {
                val dark = ((versionBits ushr i) and 1) != 0
                val a = size - 11 + (i % 3)
                val b = i / 3
                setFunc(a, b, dark)
                setFunc(b, a, dark)
            }
        }
    }

    private fun placeCodewords(
        modules: Array<BooleanArray>,
        isFunction: Array<BooleanArray>,
        codewords: List<Int>
    ) {
        val size = modules.size
        val totalBits = codewords.size * 8
        var bitIdx = 0
        var upward = true
        var col = size - 1

        while (col >= 1) {
            if (col == 6) col-- // تجاوز عمود التوقيت
            for (step in 0 until size) {
                val row = if (upward) (size - 1 - step) else step
                for (dx in 0..1) {
                    val c = col - dx
                    if (!isFunction[row][c]) {
                        val isDark = if (bitIdx < totalBits) {
                            val cw = codewords[bitIdx ushr 3]
                            val shift = 7 - (bitIdx and 7)
                            ((cw ushr shift) and 1) != 0
                        } else {
                            false
                        }
                        modules[row][c] = isDark
                        bitIdx++
                    }
                }
            }
            upward = !upward
            col -= 2
        }
    }

    private fun applyMask(
        modules: Array<BooleanArray>,
        isFunction: Array<BooleanArray>,
        mask: Int
    ) {
        val size = modules.size
        for (r in 0 until size) {
            for (c in 0 until size) {
                if (!isFunction[r][c]) {
                    val invert = when (mask) {
                        0 -> (r + c) % 2 == 0
                        1 -> r % 2 == 0
                        2 -> c % 3 == 0
                        3 -> (r + c) % 3 == 0
                        4 -> ((r / 2) + (c / 3)) % 2 == 0
                        5 -> ((r * c) % 2) + ((r * c) % 3) == 0
                        6 -> ((((r * c) % 2) + ((r * c) % 3)) % 2) == 0
                        7 -> ((((r + c) % 2) + ((r * c) % 3)) % 2) == 0
                        else -> false
                    }
                    if (invert) {
                        modules[r][c] = !modules[r][c]
                    }
                }
            }
        }
    }

    private fun drawFormatBits(modules: Array<BooleanArray>, mask: Int) {
        val size = modules.size
        // ECC Level L = 01
        val data = (0b01 shl 3) or (mask and 0b111)
        var rem = data
        for (i in 0 until 10) {
            rem = (rem shl 1) xor (((rem ushr 9) and 1) * 0x537)
        }
        val bits = ((data shl 10) or rem) xor 0x5412

        // النسخة الأولى حول الزاوية العلوية اليسرى
        for (i in 0..5) modules[8][i] = ((bits ushr (14 - i)) and 1) != 0
        modules[8][7] = ((bits ushr 8) and 1) != 0
        modules[8][8] = ((bits ushr 7) and 1) != 0
        modules[7][8] = ((bits ushr 6) and 1) != 0
        for (i in 0..5) modules[5 - i][8] = ((bits ushr (5 - i)) and 1) != 0

        // النسخة الثانية في الزاويتين السفلية اليسرى والعلوية اليمنى
        for (i in 0..6) modules[size - 1 - i][8] = ((bits ushr (14 - i)) and 1) != 0
        for (i in 0..7) modules[8][size - 8 + i] = ((bits ushr (7 - i)) and 1) != 0
        modules[size - 8][8] = true
    }

    private fun computePenaltyScore(modules: Array<BooleanArray>): Int {
        val size = modules.size
        var penalty = 0

        // القاعدة 1: سلاسل أفقية وعمودية من نفس اللون (5 فأكثر)
        for (r in 0 until size) {
            var runColor = modules[r][0]
            var runLen = 1
            for (c in 1 until size) {
                if (modules[r][c] == runColor) {
                    runLen++
                } else {
                    if (runLen >= 5) penalty += 3 + (runLen - 5)
                    runColor = modules[r][c]
                    runLen = 1
                }
            }
            if (runLen >= 5) penalty += 3 + (runLen - 5)
        }
        for (c in 0 until size) {
            var runColor = modules[0][c]
            var runLen = 1
            for (r in 1 until size) {
                if (modules[r][c] == runColor) {
                    runLen++
                } else {
                    if (runLen >= 5) penalty += 3 + (runLen - 5)
                    runColor = modules[r][c]
                    runLen = 1
                }
            }
            if (runLen >= 5) penalty += 3 + (runLen - 5)
        }

        // القاعدة 2: مربعات 2×2 من نفس اللون
        for (r in 0 until size - 1) {
            for (c in 0 until size - 1) {
                val color = modules[r][c]
                if (color == modules[r][c + 1] &&
                    color == modules[r + 1][c] &&
                    color == modules[r + 1][c + 1]
                ) {
                    penalty += 3
                }
            }
        }

        // القاعدة 4: توازن نسبة الوحدات الداكنة
        var darkCount = 0
        for (r in 0 until size) {
            for (c in 0 until size) {
                if (modules[r][c]) darkCount++
            }
        }
        val total = size * size
        val k = (abs(darkCount * 20 - total * 10) + total - 1) / total - 1
        if (k > 0) penalty += k * 10

        return penalty
    }
}
