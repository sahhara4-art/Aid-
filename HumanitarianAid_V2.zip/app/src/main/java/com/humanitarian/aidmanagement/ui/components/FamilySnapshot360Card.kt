package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyComplaintEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.engine.ScoringProfileStore
import com.humanitarian.aidmanagement.engine.VulnerabilityFamilyInput
import com.humanitarian.aidmanagement.engine.VulnerabilityScoringEngine
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val SnapshotPrimaryText = Color(0xFF0F172A)
private val SnapshotSecondaryText = Color(0xFF475569)
private val SnapshotEmerald = Color(0xFF0F7B53)
private val SnapshotAmber = Color(0xFFB45309)
private val SnapshotRose = Color(0xFFBE123C)
private val SnapshotSky = Color(0xFF0369A1)

/**
 * بطاقة نبض بصرية مكثّفة 360° تلخّص وضع الأسرة في نظرة واحدة (بدون Icons)
 * متوافقة تلقائياً مع وضع الشمس عالي التباين عبر GlassCard.
 */
@Composable
fun FamilySnapshot360Card(
    family: FamilyEntity,
    children: List<ChildEntity>,
    aidRecords: List<AidRecordEntity>,
    openComplaints: List<FamilyComplaintEntity>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isSunlight = OutdoorSunlightState.isEnabled

    val metrics = remember(
        family.familyID,
        family.familyMembersCount,
        family.damageType,
        family.incomeSource1,
        family.income_source_2,
        family.developmentApproval,
        family.localityApproval,
        children,
        aidRecords,
        openComplaints
    ) {
        val activeProfile = ScoringProfileStore.getActiveProfile(context)
        val parsedAgesMonths = children.mapNotNull { parseAgeInMonths(it.birthDate) }
        val childrenAgesYears = parsedAgesMonths.map { (it / 12).coerceAtLeast(0) }
        val infantsUnderTwoCount = parsedAgesMonths.count { it in 0..23 }

        val deliveredRecords = aidRecords.filter { isAidRecordDelivered(it) }
        val deliveredCount = deliveredRecords.size
        val daysSinceLastAid = computeDaysSinceLastAid(deliveredRecords)

        val totalMembers = if (family.familyMembersCount > 0) {
            family.familyMembersCount
        } else {
            (children.size + 1).coerceAtLeast(1)
        }

        val employmentText = listOf(family.incomeSource1, family.income_source_2)
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .joinToString(" - ")

        val scoreResult = VulnerabilityScoringEngine.evaluateFamily(
            input = VulnerabilityFamilyInput(
                familyId = family.familyID.toString(),
                housingDamage = family.damageType,
                childrenAgesYears = childrenAgesYears,
                familySize = totalMembers,
                employmentStatus = employmentText,
                daysSinceLastAid = daysSinceLastAid,
                hasOpenComplaint = openComplaints.isNotEmpty()
            ),
            profile = activeProfile
        )

        Snapshot360Metrics(
            score = scoreResult.score,
            explanationSummary = scoreResult.explanationSummary,
            profileName = activeProfile.profileName,
            totalMembers = totalMembers,
            infantsUnderTwoCount = infantsUnderTwoCount,
            approvalStatus = resolveApprovalLabel(family),
            housingDamage = family.damageType.trim().ifBlank { "غير محدد" },
            deliveredCount = deliveredCount,
            daysSinceLastAid = daysSinceLastAid,
            openComplaintsCount = openComplaints.size
        )
    }

    val scoreColor = when {
        metrics.score >= 75 -> SnapshotRose
        metrics.score >= 50 -> SnapshotAmber
        metrics.score >= 25 -> SnapshotSky
        else -> SnapshotEmerald
    }
    val scoreTierLabel = when {
        metrics.score >= 75 -> "هشاشة حرجة"
        metrics.score >= 50 -> "أولوية عالية"
        metrics.score >= 25 -> "أولوية متوسطة"
        else -> "وضع مستقر"
    }

    val labelColor = if (isSunlight) SnapshotPrimaryText else SnapshotSecondaryText
    val tileBg = if (isSunlight) Color.White else Color(0xFFF3F9F6)
    val tileBorderColor = if (isSunlight) SnapshotPrimaryText else Color(0xFFD6E8DF)
    val tileBorderWidth = if (isSunlight) 1.5.dp else 1.dp

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        GlassCard(modifier = modifier.fillMaxWidth()) {
            // الترويسة العلوية: عنوان بطاقة النبض + درجة مؤشر الهشاشة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "بطاقة النبض السريع للأسرة (360°)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = SnapshotPrimaryText,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "القالب النشط: ${metrics.profileName}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = labelColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSunlight) Color.White else scoreColor.copy(alpha = 0.13f),
                    border = BorderStroke(
                        width = if (isSunlight) 2.dp else 1.dp,
                        color = if (isSunlight) SnapshotPrimaryText else scoreColor.copy(alpha = 0.45f)
                    ),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "${metrics.score} / 100",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isSunlight) SnapshotPrimaryText else scoreColor
                        )
                        Text(
                            text = scoreTierLabel,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSunlight) SnapshotPrimaryText else scoreColor
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // شريط تقدم درجة الهشاشة والتفسير المختصر من المحرك
            LinearProgressIndicator(
                progress = { (metrics.score / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = if (isSunlight) SnapshotPrimaryText else scoreColor,
                trackColor = if (isSunlight) Color(0xFFE2E8F0) else scoreColor.copy(alpha = 0.15f)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "التفسير المختصر: ${metrics.explanationSummary}",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = SnapshotPrimaryText,
                lineHeight = 18.sp
            )

            // شارة تنبيه في حال وجود شكوى / أولوية مفتوحة
            if (metrics.openComplaintsCount > 0) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSunlight) Color.White else Color(0xFFFFF1F2),
                    border = BorderStroke(
                        width = if (isSunlight) 2.dp else 1.dp,
                        color = if (isSunlight) SnapshotPrimaryText else SnapshotRose.copy(alpha = 0.55f)
                    ),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Text(
                        text = "⚠ تنبيه أولوية: توجد ${metrics.openComplaintsCount} شكوى/أولوية مفتوحة تتطلب المتابعة",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isSunlight) SnapshotPrimaryText else SnapshotRose,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(
                color = if (isSunlight) SnapshotPrimaryText else Color(0xFFD6E8DF),
                thickness = if (isSunlight) 1.dp else 0.8.dp
            )
            Spacer(modifier = Modifier.height(10.dp))

            // الصف الأول من المؤشرات: الأفراد والرضع + الاعتماد وضرر السكن
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SnapshotMetricTile(
                    title = "تركيبة الأسرة",
                    primaryValue = "${metrics.totalMembers} أفراد",
                    secondaryValue = "أقل من سنتين: ${metrics.infantsUnderTwoCount}",
                    accentColor = SnapshotSky,
                    bgColor = tileBg,
                    borderColor = tileBorderColor,
                    borderWidth = tileBorderWidth,
                    labelColor = labelColor,
                    isSunlight = isSunlight,
                    modifier = Modifier.weight(1f)
                )

                val damageAccent = when {
                    metrics.housingDamage.contains("كلي") || metrics.housingDamage.contains("غير صالح") -> SnapshotRose
                    metrics.housingDamage.contains("جزئي") || metrics.housingDamage.contains("بليغ") -> SnapshotAmber
                    else -> SnapshotEmerald
                }
                SnapshotMetricTile(
                    title = "الاعتماد وضرر السكن",
                    primaryValue = metrics.approvalStatus,
                    secondaryValue = "السكن: ${metrics.housingDamage}",
                    accentColor = damageAccent,
                    bgColor = tileBg,
                    borderColor = tileBorderColor,
                    borderWidth = tileBorderWidth,
                    labelColor = labelColor,
                    isSunlight = isSunlight,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // الصف الثاني من المؤشرات: عدد المساعدات المستلمة + الأيام منذ آخر استلام
            val lastAidText = when {
                metrics.daysSinceLastAid < 0 -> "لم يستلم سابقاً"
                metrics.daysSinceLastAid == 0 -> "اليوم (0 يوم)"
                else -> "منذ ${metrics.daysSinceLastAid} يوم"
            }
            val aidGapAccent = when {
                metrics.daysSinceLastAid < 0 || metrics.daysSinceLastAid >= 90 -> SnapshotRose
                metrics.daysSinceLastAid >= 45 -> SnapshotAmber
                else -> SnapshotEmerald
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SnapshotMetricTile(
                    title = "المساعدات المستلمة",
                    primaryValue = "${metrics.deliveredCount} مساعدة",
                    secondaryValue = "إجمالي السجلات: ${aidRecords.size}",
                    accentColor = SnapshotEmerald,
                    bgColor = tileBg,
                    borderColor = tileBorderColor,
                    borderWidth = tileBorderWidth,
                    labelColor = labelColor,
                    isSunlight = isSunlight,
                    modifier = Modifier.weight(1f)
                )

                SnapshotMetricTile(
                    title = "الفجوة منذ آخر استلام",
                    primaryValue = lastAidText,
                    secondaryValue = if (metrics.openComplaintsCount > 0) "شكاوى مفتوحة: ${metrics.openComplaintsCount}" else "لا توجد شكاوى مفتوحة",
                    accentColor = aidGapAccent,
                    bgColor = tileBg,
                    borderColor = tileBorderColor,
                    borderWidth = tileBorderWidth,
                    labelColor = labelColor,
                    isSunlight = isSunlight,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun SnapshotMetricTile(
    title: String,
    primaryValue: String,
    secondaryValue: String,
    accentColor: Color,
    bgColor: Color,
    borderColor: Color,
    borderWidth: androidx.compose.ui.unit.Dp,
    labelColor: Color,
    isSunlight: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .border(borderWidth, borderColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(
            text = title,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold,
            color = labelColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = primaryValue,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            color = if (isSunlight) SnapshotPrimaryText else accentColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = secondaryValue,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = SnapshotPrimaryText,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

private data class Snapshot360Metrics(
    val score: Int,
    val explanationSummary: String,
    val profileName: String,
    val totalMembers: Int,
    val infantsUnderTwoCount: Int,
    val approvalStatus: String,
    val housingDamage: String,
    val deliveredCount: Int,
    val daysSinceLastAid: Int,
    val openComplaintsCount: Int
)

private fun resolveApprovalLabel(family: FamilyEntity): String {
    val dev = family.developmentApproval.trim()
    val loc = family.localityApproval.trim()
    return when {
        dev.isNotBlank() -> dev
        loc.isNotBlank() -> loc
        else -> "غير محدد"
    }
}

private fun isAidRecordDelivered(record: AidRecordEntity): Boolean {
    val status = record.recipientStatus.trim()
    return status.contains("مستلم") ||
        status.contains("مستفيد") ||
        status.contains("تم التسليم") ||
        !record.deliveryDate.isNullOrBlank()
}

private fun computeDaysSinceLastAid(deliveredRecords: List<AidRecordEntity>): Int {
    if (deliveredRecords.isEmpty()) return -1
    var latestMillis: Long? = null
    for (record in deliveredRecords) {
        val candidates = listOf(record.deliveryDate, record.aidDate, record.selectionDate)
        for (raw in candidates) {
            val parsed = parseDateToMillis(raw)
            if (parsed != null) {
                if (latestMillis == null || parsed > latestMillis) {
                    latestMillis = parsed
                }
                break
            }
        }
    }
    val last = latestMillis ?: return -1
    val diffDays = ((System.currentTimeMillis() - last) / 86_400_000L).toInt()
    return diffDays.coerceAtLeast(0)
}

private fun parseAgeInMonths(rawBirthDate: String?): Int? {
    val millis = parseDateToMillis(rawBirthDate) ?: return null
    val birthCal = Calendar.getInstance().apply { timeInMillis = millis }
    val nowCal = Calendar.getInstance()
    if (birthCal.after(nowCal)) return 0
    var months = (nowCal.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR)) * 12 +
        (nowCal.get(Calendar.MONTH) - birthCal.get(Calendar.MONTH))
    if (nowCal.get(Calendar.DAY_OF_MONTH) < birthCal.get(Calendar.DAY_OF_MONTH)) {
        months -= 1
    }
    return months.coerceAtLeast(0)
}

private fun parseDateToMillis(raw: String?): Long? {
    val clean = raw?.trim().orEmpty()
    if (clean.isEmpty() || clean == "-" || clean.equals("null", ignoreCase = true)) return null
    val normalized = clean.replace('/', '-').take(19)
    val patterns = listOf(
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd'T'HH:mm:ss",
        "yyyy-MM-dd HH:mm",
        "yyyy-MM-dd",
        "dd-MM-yyyy",
        "MM-dd-yyyy"
    )
    for (pattern in patterns) {
        val parsed: Date? = runCatching {
            SimpleDateFormat(pattern, Locale.US).apply { isLenient = false }.parse(normalized)
        }.getOrNull()
        if (parsed != null) return parsed.time
    }
    return null
}
