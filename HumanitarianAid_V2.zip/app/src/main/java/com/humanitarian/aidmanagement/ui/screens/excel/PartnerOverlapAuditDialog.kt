package com.humanitarian.aidmanagement.ui.screens.excel

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import androidx.sqlite.db.SupportSQLiteDatabase
import com.humanitarian.aidmanagement.data.local.entities.FamilyComplaintEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyTable
import com.humanitarian.aidmanagement.util.AidCategoryCatalog
import com.humanitarian.aidmanagement.util.ExcelPriorityNominationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val OverlapEmerald = Color(0xFF0F7B53)
private val OverlapCrimson = Color(0xFFDC2626)
private val OverlapAmber = Color(0xFFD97706)
private val OverlapIndigo = Color(0xFF4338CA)
private val OverlapTeal = Color(0xFF0D9488)
private val OverlapSlateDark = Color(0xFF0F172A)
private val OverlapSlateMuted = Color(0xFF64748B)
private val OverlapSurfaceBg = Color(0xFFF4F9F6)
private val OverlapSelectedBg = Color(0xFFEAF7F1)
private val OverlapBorder = Color(0xFFD5E5DD)

/**
 * تصنيفات التقاطع الأربعة بين كشف المؤسسة الشريكة وقاعدة البيانات الرسمية لدينا.
 */
enum class OverlapCategory(
    val arabicLabel: String,
    val shortTabTitle: String
) {
    UNSERVED_BY_BOTH(
        arabicLabel = "غير مخدوم لا منا ولا من الشريك - مستحق أولوية",
        shortTabTitle = "غير مخدوم"
    ),
    SERVED_BY_PARTNER_ONLY(
        arabicLabel = "استلم من الشريك فقط",
        shortTabTitle = "الشريك فقط"
    ),
    SERVED_BY_US_ONLY(
        arabicLabel = "استلم منا فقط",
        shortTabTitle = "نحن فقط"
    ),
    SERVED_BY_BOTH(
        arabicLabel = "استلم من الطرفين - ازدواجية توزيع",
        shortTabTitle = "الطرفان"
    )
}

/**
 * صف نتيجة تدقيق التقاطع لكل أسرة.
 */
data class PartnerAuditRow(
    val nationalId: String,
    val headName: String,
    val currentSubRegion: String,
    val systemStatus: String,
    val overlapCategory: OverlapCategory,
    val lastAidDetails: String,
    val isEligibleForComplaint: Boolean = false
)

/**
 * ملخص نتيجة مقارنة كشف الشريك بقاعدة البيانات الرسمية.
 */
data class PartnerOverlapAuditResult(
    val fileName: String = "",
    val partnerUniqueIdsCount: Int = 0,
    val unservedByBoth: List<PartnerAuditRow> = emptyList(),
    val servedByPartnerOnly: List<PartnerAuditRow> = emptyList(),
    val servedByUsOnly: List<PartnerAuditRow> = emptyList(),
    val servedByBoth: List<PartnerAuditRow> = emptyList()
) {
    val totalRowsCount: Int
        get() = unservedByBoth.size + servedByPartnerOnly.size + servedByUsOnly.size + servedByBoth.size

    fun rowsForCategory(category: OverlapCategory): List<PartnerAuditRow> = when (category) {
        OverlapCategory.UNSERVED_BY_BOTH -> unservedByBoth
        OverlapCategory.SERVED_BY_PARTNER_ONLY -> servedByPartnerOnly
        OverlapCategory.SERVED_BY_US_ONLY -> servedByUsOnly
        OverlapCategory.SERVED_BY_BOTH -> servedByBoth
    }

    fun allRows(): List<PartnerAuditRow> = buildList(totalRowsCount) {
        addAll(unservedByBoth)
        addAll(servedByPartnerOnly)
        addAll(servedByUsOnly)
        addAll(servedByBoth)
    }
}

data class ComplaintTransferSummary(
    val insertedCount: Int,
    val skippedDuplicateCount: Int
)

/**
 * محرك مقارنة كشف المؤسسة الشريكة مع قاعدة بيانات الأسر والمساعدات الرسمية على Dispatchers.IO.
 * يلتزم بضابط الذاكرة (256MB Heap) باستخدام خرائط تجزئة خفيفة HashMap و HashSet لأرقام الهويات (9 أرقام).
 */
object PartnerOverlapAuditEngine {

    const val ALL_CATEGORIES_FILTER = "كل المساعدات"

    private data class LatestAidInfo(
        val aidTypeName: String,
        val dateText: String
    )

    suspend fun runAudit(
        context: Context,
        partnerFileUri: Uri,
        fileName: String,
        database: SupportSQLiteDatabase,
        aidCategoryFilter: String = ALL_CATEGORIES_FILTER
    ): PartnerOverlapAuditResult = withContext(Dispatchers.IO) {
        // 1) قراءة عمود أرقام الهويات من ملف الشريك (.xlsx / .xls / .csv) وتطبيعه إلى 9 أرقام
        val parsedRows = ExcelPriorityNominationHelper.parseNationalIdsFromUri(
            context = context,
            uri = partnerFileUri,
            fileName = fileName
        )
        val partnerIds = HashSet<String>(parsedRows.size + 16)
        for (row in parsedRows) {
            val norm9 = normalizeNineDigitId(row.cleanedNationalId)
            if (norm9 != null) {
                partnerIds.add(norm9)
            }
        }

        // 2) قراءة خريطة تصنيفات المساعدات (aid_types + الافتراضية من AidCategoryCatalog)
        val aidTypeNamesById = HashMap<Int, String>(32)
        for (defType in AidCategoryCatalog.DEFAULT_AID_TYPES) {
            aidTypeNamesById[defType.aidTypeID] = AidCategoryCatalog.cleanName(defType.aidTypeName)
        }
        runCatching {
            database.query("SELECT aidTypeID, aidTypeName FROM aid_types").use { cursor ->
                while (cursor.moveToNext()) {
                    val id = cursor.getInt(0)
                    val name = AidCategoryCatalog.cleanName(cursor.getString(1))
                    if (name.isNotBlank()) {
                        aidTypeNamesById[id] = name
                    }
                }
            }
        }

        val cleanFilter = AidCategoryCatalog.cleanName(aidCategoryFilter)
        val filterByCategory = cleanFilter.isNotBlank() && cleanFilter != ALL_CATEGORIES_FILTER
        val targetFilterKey = if (filterByCategory) AidCategoryCatalog.canonicalKey(cleanFilter) else ""
        val allowedAidTypeIds = HashSet<Int>()
        if (filterByCategory) {
            for ((typeId, typeName) in aidTypeNamesById) {
                if (AidCategoryCatalog.canonicalKey(typeName) == targetFilterKey) {
                    allowedAidTypeIds.add(typeId)
                }
            }
        }

        // 3) قراءة آخر مساعدة مستلمة لكل familyID من جدول aid_records بخريطة تجزئة خفيفة
        val latestAidByFamilyId = HashMap<Long, LatestAidInfo>(4096)
        val aidSql = """
            SELECT familyID, aidTypeID, recipientStatus, deliveryDate, aidDate
            FROM aid_records
            WHERE (recipientStatus LIKE '%مستلم%' OR recipientStatus LIKE '%مسلم%' OR (deliveryDate IS NOT NULL AND TRIM(deliveryDate) != ''))
        """.trimIndent()

        database.query(aidSql).use { cursor ->
            while (cursor.moveToNext()) {
                val familyId = cursor.getLong(0)
                val aidTypeId = cursor.getInt(1)
                if (filterByCategory && aidTypeId !in allowedAidTypeIds) continue

                val deliveryDate = cursor.getString(3).orEmpty().trim()
                val aidDate = cursor.getString(4).orEmpty().trim()
                val effectiveDate = deliveryDate.ifBlank { aidDate }
                val aidTypeName = aidTypeNamesById[aidTypeId] ?: "تصنيف #$aidTypeId"

                val existing = latestAidByFamilyId[familyId]
                if (existing == null || effectiveDate >= existing.dateText) {
                    latestAidByFamilyId[familyId] = LatestAidInfo(
                        aidTypeName = aidTypeName,
                        dateText = effectiveDate.ifBlank { "غير مؤرخ" }
                    )
                }
            }
        }

        // 4) مسح جدول الأسر الرسمي وتصنيف كل أسرة ضمن الفئات الأربع
        val unservedList = ArrayList<PartnerAuditRow>()
        val partnerOnlyList = ArrayList<PartnerAuditRow>()
        val usOnlyList = ArrayList<PartnerAuditRow>()
        val bothList = ArrayList<PartnerAuditRow>()
        val matchedPartnerIds = HashSet<String>(partnerIds.size + 16)

        val familySql = """
            SELECT
                ${FamilyTable.COL_FAMILY_ID},
                ${FamilyTable.COL_NATIONAL_ID},
                ${FamilyTable.COL_NAME},
                ${FamilyTable.COL_CURRENT_SUB_AREA},
                ${FamilyTable.COL_DEVELOPMENT_APPROVAL},
                ${FamilyTable.COL_RESIDENT_STATUS}
            FROM ${FamilyTable.TABLE_NAME}
        """.trimIndent()

        database.query(familySql).use { cursor ->
            while (cursor.moveToNext()) {
                val familyId = cursor.getLong(0)
                val rawNatId = cursor.getString(1).orEmpty().trim()
                val headName = cursor.getString(2).orEmpty().trim().ifBlank { "بدون اسم" }
                val subRegion = cursor.getString(3).orEmpty().trim().ifBlank { "غير محددة" }
                val devApproval = cursor.getString(4).orEmpty().trim()
                val residentStatus = cursor.getString(5).orEmpty().trim()

                val norm9 = normalizeNineDigitId(rawNatId)
                val displayNatId = norm9 ?: rawNatId
                val servedByPartner = norm9 != null && partnerIds.contains(norm9)
                if (servedByPartner && norm9 != null) {
                    matchedPartnerIds.add(norm9)
                }

                val latestAid = latestAidByFamilyId[familyId]
                val servedByUs = latestAid != null

                val category = when {
                    !servedByUs && !servedByPartner -> OverlapCategory.UNSERVED_BY_BOTH
                    !servedByUs && servedByPartner -> OverlapCategory.SERVED_BY_PARTNER_ONLY
                    servedByUs && !servedByPartner -> OverlapCategory.SERVED_BY_US_ONLY
                    else -> OverlapCategory.SERVED_BY_BOTH
                }

                val statusText = listOf(devApproval, residentStatus)
                    .filter { it.isNotBlank() }
                    .joinToString(" • ")
                    .ifBlank { "غير محدد" }

                val eligibleForComplaint = isApprovedOrResident(devApproval, residentStatus)
                val aidDetails = if (latestAid != null) {
                    "${latestAid.aidTypeName} (${latestAid.dateText})"
                } else {
                    "لا يوجد استلام مسجل"
                }

                val auditRow = PartnerAuditRow(
                    nationalId = displayNatId,
                    headName = headName,
                    currentSubRegion = subRegion,
                    systemStatus = statusText,
                    overlapCategory = category,
                    lastAidDetails = aidDetails,
                    isEligibleForComplaint = eligibleForComplaint
                )

                when (category) {
                    OverlapCategory.UNSERVED_BY_BOTH -> unservedList.add(auditRow)
                    OverlapCategory.SERVED_BY_PARTNER_ONLY -> partnerOnlyList.add(auditRow)
                    OverlapCategory.SERVED_BY_US_ONLY -> usOnlyList.add(auditRow)
                    OverlapCategory.SERVED_BY_BOTH -> bothList.add(auditRow)
                }
            }
        }

        // 5) أرقام الهويات الموجودة في كشف الشريك وغير مسجلة لدينا في جدول الأسر
        for (pid in partnerIds) {
            if (!matchedPartnerIds.contains(pid)) {
                partnerOnlyList.add(
                    PartnerAuditRow(
                        nationalId = pid,
                        headName = "غير مسجل في قاعدة بياناتنا",
                        currentSubRegion = "خارج السجل المحلي",
                        systemStatus = "غير مسجل بالنظام",
                        overlapCategory = OverlapCategory.SERVED_BY_PARTNER_ONLY,
                        lastAidDetails = "لا يوجد استلام لدينا",
                        isEligibleForComplaint = false
                    )
                )
            }
        }

        PartnerOverlapAuditResult(
            fileName = fileName,
            partnerUniqueIdsCount = partnerIds.size,
            unservedByBoth = unservedList,
            servedByPartnerOnly = partnerOnlyList,
            servedByUsOnly = usOnlyList,
            servedByBoth = bothList
        )
    }

    /**
     * إدراج الأسر غير المخدومة من الطرفين (والمسجلة لدينا كـ معتمد أو مقيم) في جدول family_complaints بحالة OPEN دون تكرار.
     */
    suspend fun transferUnservedToComplaintsTable(
        database: SupportSQLiteDatabase,
        unservedRows: List<PartnerAuditRow>,
        targetAidCategory: String,
        partnerFileName: String
    ): ComplaintTransferSummary = withContext(Dispatchers.IO) {
        val cleanCategory = AidCategoryCatalog.cleanName(targetAidCategory).ifBlank { "غذائي" }
        val targetCatKey = AidCategoryCatalog.canonicalKey(cleanCategory)
        val eligibleRows = unservedRows.filter {
            it.overlapCategory == OverlapCategory.UNSERVED_BY_BOTH && it.isEligibleForComplaint
        }
        if (eligibleRows.isEmpty()) {
            return@withContext ComplaintTransferSummary(0, 0)
        }

        // قراءة الشكاوى المفتوحة حالياً لمنع التكرار لنفس الهوية ونفس التصنيف
        val existingOpenPairs = HashSet<Pair<String, String>>()
        database.query(
            "SELECT familyId, targetAidCategory FROM family_complaints WHERE status = ?",
            arrayOf(FamilyComplaintEntity.STATUS_OPEN)
        ).use { cursor ->
            while (cursor.moveToNext()) {
                val existingFamId = normalizeAnyDigits(cursor.getString(0).orEmpty())
                val existingCatKey = AidCategoryCatalog.canonicalKey(cursor.getString(1))
                if (existingFamId.isNotBlank()) {
                    existingOpenPairs.add(existingFamId to existingCatKey)
                }
            }
        }

        var inserted = 0
        var skipped = 0
        val now = System.currentTimeMillis()
        val reason = if (partnerFileName.isNotBlank()) {
            "تقاطع كشف المؤسسة الشريكة ($partnerFileName): أسرة غير مخدومة من الطرفين ومستحقة للأولوية"
        } else {
            "تقاطع كشف المؤسسة الشريكة: أسرة غير مخدومة من الطرفين ومستحقة للأولوية"
        }

        database.beginTransaction()
        try {
            for (row in eligibleRows) {
                val cleanNatId = row.nationalId.trim()
                val normKey = normalizeAnyDigits(cleanNatId) to targetCatKey
                if (cleanNatId.isBlank() || normKey in existingOpenPairs) {
                    skipped++
                    continue
                }

                val values = ContentValues().apply {
                    put("familyId", cleanNatId)
                    put("familyName", row.headName)
                    put("localArea", row.currentSubRegion)
                    put("complaintReason", reason)
                    put("targetAidCategory", cleanCategory)
                    put("status", FamilyComplaintEntity.STATUS_OPEN)
                    put("createdAt", now)
                    putNull("nominatedProjectName")
                }
                database.insert("family_complaints", android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE, values)
                existingOpenPairs.add(normKey)
                inserted++
            }
            database.setTransactionSuccessful()
        } finally {
            database.endTransaction()
        }

        ComplaintTransferSummary(insertedCount = inserted, skippedDuplicateCount = skipped)
    }

    /**
     * تصدير كافة نتائج التقاطع كملف CSV بترميز UTF-8 BOM (\uFEFF) جاهز لـ Microsoft Excel.
     */
    suspend fun exportOverlapCsv(
        context: Context,
        rows: List<PartnerAuditRow>
    ): File = withContext(Dispatchers.IO) {
        val reportsDir = File(context.cacheDir, "partner_overlap_reports").apply {
            if (!exists()) mkdirs()
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outFile = File(reportsDir, "partner_overlap_audit_$stamp.csv")

        BufferedWriter(OutputStreamWriter(FileOutputStream(outFile), Charsets.UTF_8)).use { writer ->
            // UTF-8 BOM لضمان ظهور اللغة العربية سليمة في Excel
            writer.write("\uFEFF")
            writer.write(
                listOf(
                    "رقم الهوية",
                    "اسم رب الأسرة",
                    "المنطقة المحلية",
                    "حالة الأسرة في نظامنا",
                    "تصنيف التقاطع",
                    "تفاصيل آخر مساعدة لدينا"
                ).joinToString(",") { escapeCsv(it) }
            )
            writer.newLine()

            for (row in rows) {
                writer.write(
                    listOf(
                        row.nationalId,
                        row.headName,
                        row.currentSubRegion,
                        row.systemStatus,
                        row.overlapCategory.arabicLabel,
                        row.lastAidDetails
                    ).joinToString(",") { escapeCsv(it) }
                )
                writer.newLine()
            }
        }
        outFile
    }

    fun shareCsvFile(
        context: Context,
        csvFile: File,
        fileProviderAuthority: String? = null
    ): Boolean {
        return runCatching {
            val authority = fileProviderAuthority?.takeIf { it.isNotBlank() }
                ?: "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, csvFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "تقرير تقاطع كشف المؤسسة الشريكة")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "تصدير / مشاركة تقرير التقاطع (Excel)").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            true
        }.getOrDefault(false)
    }

    private fun isApprovedOrResident(devApproval: String, residentStatus: String): Boolean {
        val dev = devApproval.trim()
        val res = residentStatus.trim()
        val isApproved = dev.contains("معتمد") &&
            !dev.contains("غير") &&
            !dev.contains("حجب") &&
            !dev.contains("مجمد") &&
            !dev.contains("مرفوض")
        val isResident = res.contains("مقيم") &&
            !res.contains("غير") &&
            !res.contains("مغادر") &&
            !res.contains("متوف")
        return isApproved || isResident
    }

    private fun normalizeNineDigitId(raw: String): String? {
        val digits = ExcelPriorityNominationHelper.normalizeNationalId(raw)
        if (digits.length != 9) return null
        if (digits.all { it == '0' }) return null
        return digits
    }

    private fun normalizeAnyDigits(raw: String): String {
        val normalized = ExcelPriorityNominationHelper.normalizeNationalId(raw)
        return normalized.ifBlank { raw.trim() }
    }

    private fun escapeCsv(raw: String): String {
        val safe = raw.replace("\r", " ").replace("\n", " ").trim().replace("\"", "\"\"")
        return "\"$safe\""
    }
}

/**
 * نافذة تدقيق التقاطع مع كشوفات المؤسسات الشريكة (RTL - Material 3 بدون استخدام Icons).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PartnerOverlapAuditDialog(
    database: SupportSQLiteDatabase,
    onDismiss: () -> Unit,
    availableCategories: List<String> = emptyList(),
    fileProviderAuthority: String? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val filterCategories = remember(availableCategories) {
        listOf(PartnerOverlapAuditEngine.ALL_CATEGORIES_FILTER) +
            AidCategoryCatalog.deduplicateCategoryNames(
                primaryNames = availableCategories,
                includeDefaults = true
            )
    }
    val complaintTargetCategories = remember(availableCategories) {
        AidCategoryCatalog.deduplicateCategoryNames(
            primaryNames = availableCategories,
            includeDefaults = true
        )
    }
    val tabs = remember {
        listOf(
            OverlapCategory.UNSERVED_BY_BOTH,
            OverlapCategory.SERVED_BY_PARTNER_ONLY,
            OverlapCategory.SERVED_BY_US_ONLY,
            OverlapCategory.SERVED_BY_BOTH
        )
    }

    var selectedFileUri by remember { mutableStateOf<Uri?>(null) }
    var selectedFileName by remember { mutableStateOf("") }
    var selectedAidFilter by remember { mutableStateOf(PartnerOverlapAuditEngine.ALL_CATEGORIES_FILTER) }
    var auditResult by remember { mutableStateOf<PartnerOverlapAuditResult?>(null) }
    var isProcessing by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    var isTransferring by remember { mutableStateOf(false) }
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var showTargetCategoryDialog by remember { mutableStateOf(false) }
    var selectedTargetComplaintCategory by remember(complaintTargetCategories) {
        mutableStateOf(complaintTargetCategories.firstOrNull() ?: "غذائي")
    }

    fun executeComparison(uri: Uri, name: String, categoryFilter: String) {
        if (isProcessing) return
        scope.launch {
            isProcessing = true
            runCatching {
                PartnerOverlapAuditEngine.runAudit(
                    context = context,
                    partnerFileUri = uri,
                    fileName = name,
                    database = database,
                    aidCategoryFilter = categoryFilter
                )
            }.onSuccess { res ->
                auditResult = res
            }.onFailure { err ->
                Toast.makeText(
                    context,
                    "تعذر تحليل ملف الشريك: ${err.message ?: "خطأ غير متوقع"}",
                    Toast.LENGTH_LONG
                ).show()
            }
            isProcessing = false
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val resolvedName = resolveFileName(context, uri)
            selectedFileUri = uri
            selectedFileName = resolvedName
            executeComparison(uri, resolvedName, selectedAidFilter)
        }
    }

    val activeCategory = tabs[selectedTabIndex.coerceIn(tabs.indices)]
    val filteredRows = remember(auditResult, activeCategory, searchQuery) {
        val rows = auditResult?.rowsForCategory(activeCategory).orEmpty()
        val cleanQuery = normalizeSearchInput(searchQuery)
        if (cleanQuery.isBlank()) {
            rows
        } else {
            rows.filter { row ->
                normalizeSearchInput(row.headName).contains(cleanQuery) ||
                    normalizeSearchInput(row.nationalId).contains(cleanQuery) ||
                    normalizeSearchInput(row.currentSubRegion).contains(cleanQuery)
            }
        }
    }

    val eligibleUnservedCount = remember(auditResult) {
        auditResult?.unservedByBoth?.count { it.isEligibleForComplaint } ?: 0
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false),
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .padding(vertical = 10.dp),
            title = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تدقيق تقاطع المؤسسات الشريكة",
                            color = OverlapSlateDark,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        TextButton(
                            onClick = onDismiss,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "إغلاق",
                                color = OverlapSlateMuted,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "قارن كشف المؤسسة الشريكة (.xlsx / .csv) بقاعدة بياناتنا لرصد غير المخدومين وازدواجية التوزيع بدقة.",
                        color = OverlapSlateMuted,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // 1) زر استيراد كشف المؤسسة الشريكة
                    Button(
                        onClick = {
                            filePickerLauncher.launch(
                                arrayOf(
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "application/vnd.ms-excel",
                                    "text/csv",
                                    "text/comma-separated-values",
                                    "text/plain",
                                    "*/*"
                                )
                            )
                        },
                        enabled = !isProcessing,
                        colors = ButtonDefaults.buttonColors(containerColor = OverlapEmerald),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (selectedFileName.isBlank()) {
                                "استيراد كشف المؤسسة الشريكة (.xlsx / .csv)"
                            } else {
                                "تغيير ملف الشريك: $selectedFileName"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // 2) فلتر تصنيف المساعدة للمقارنة (كل المساعدات أو تصنيف محدد)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "نطاق مقارنة المساعدات لدينا:",
                            color = OverlapSlateDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(filterCategories) { categoryName ->
                                val selected = selectedAidFilter == categoryName
                                FilterChip(
                                    selected = selected,
                                    onClick = {
                                        if (selectedAidFilter != categoryName) {
                                            selectedAidFilter = categoryName
                                            val uri = selectedFileUri
                                            if (uri != null) {
                                                executeComparison(uri, selectedFileName, categoryName)
                                            }
                                        }
                                    },
                                    label = {
                                        Text(
                                            text = if (selected) "✓ $categoryName" else categoryName,
                                            fontSize = 11.sp,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = OverlapEmerald.copy(alpha = 0.16f),
                                        selectedLabelColor = OverlapEmerald
                                    )
                                )
                            }
                        }
                    }

                    // 3) حالة التحميل أو عرض النتائج
                    if (isProcessing) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(color = OverlapEmerald)
                                Text(
                                    text = "جاري قراءة كشف الشريك ومطابقة الهويات...",
                                    color = OverlapSlateMuted,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    } else if (auditResult == null) {
                        Surface(
                            color = OverlapSurfaceBg,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, OverlapBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "لم يتم استيراد كشف بعد",
                                    color = OverlapSlateDark,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "اضغط على «استيراد كشف المؤسسة الشريكة (.xlsx / .csv)» لاختيار الملف والبدء الفوري بالتدقيق.",
                                    color = OverlapSlateMuted,
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        val result = auditResult!!

                        // ملخص رقمي سريع لملف الشريك
                        Surface(
                            color = OverlapSurfaceBg,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, OverlapBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "هويات الشريك الصالحة: ${result.partnerUniqueIdsCount} • إجمالي السجلات المصنفة: ${result.totalRowsCount} • النطاق: $selectedAidFilter",
                                color = OverlapSlateDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }

                        // 4) التبويبات الأربعة (TabRow) مع العدد الإجمالي لكل فئة
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, OverlapBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            TabRow(
                                selectedTabIndex = selectedTabIndex,
                                containerColor = Color.White,
                                contentColor = OverlapEmerald
                            ) {
                                tabs.forEachIndexed { index, category ->
                                    val count = result.rowsForCategory(category).size
                                    val selected = selectedTabIndex == index
                                    Tab(
                                        selected = selected,
                                        onClick = { selectedTabIndex = index },
                                        text = {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text(
                                                    text = count.toString(),
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = if (selected) categoryAccentColor(category) else OverlapSlateDark
                                                )
                                                Text(
                                                    text = category.shortTabTitle,
                                                    fontSize = 10.sp,
                                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (selected) categoryAccentColor(category) else OverlapSlateMuted,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    )
                                }
                            }
                        }

                        // 5) شريط البحث السريع بالاسم أو الهوية أو المنطقة المحلية
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("بحث سريع بالاسم أو الهوية أو المنطقة المحلية", fontSize = 11.sp) },
                            placeholder = { Text("اكتب الاسم أو الهوية أو المنطقة...", fontSize = 11.sp) },
                            trailingIcon = if (searchQuery.isNotBlank()) {
                                {
                                    TextButton(onClick = { searchQuery = "" }) {
                                        Text("مسح", fontSize = 11.sp, color = OverlapSlateMuted)
                                    }
                                }
                            } else {
                                null
                            }
                        )

                        // 6) قائمة النتائج للتبويب المختار
                        if (filteredRows.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(120.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "لا توجد سجلات في فئة «${activeCategory.shortTabTitle}» مطابقة للبحث الحالي.",
                                    color = OverlapSlateMuted,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 140.dp, max = 260.dp),
                                verticalArrangement = Arrangement.spacedBy(7.dp)
                            ) {
                                items(
                                    items = filteredRows,
                                    key = { "${it.overlapCategory.name}_${it.nationalId}_${it.headName}" }
                                ) { row ->
                                    PartnerAuditRowCard(row = row)
                                }
                            }
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(OverlapBorder)
                        )

                        // 7) أزرار التصدير والتحويل إلى قائمة الشكاوى والأولويات
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            Button(
                                onClick = { showTargetCategoryDialog = true },
                                enabled = eligibleUnservedCount > 0 && !isTransferring,
                                colors = ButtonDefaults.buttonColors(containerColor = OverlapCrimson),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = if (isTransferring) {
                                        "جاري التحويل إلى الشكاوى..."
                                    } else {
                                        "تحويل غير المخدومين إلى قائمة الشكاوى/الأولويات ($eligibleUnservedCount)"
                                    },
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    val allRows = result.allRows()
                                    if (allRows.isEmpty()) return@OutlinedButton
                                    scope.launch {
                                        isExporting = true
                                        runCatching {
                                            val csvFile = PartnerOverlapAuditEngine.exportOverlapCsv(context, allRows)
                                            val shared = PartnerOverlapAuditEngine.shareCsvFile(
                                                context = context,
                                                csvFile = csvFile,
                                                fileProviderAuthority = fileProviderAuthority
                                            )
                                            csvFile to shared
                                        }.onSuccess { (file, shared) ->
                                            Toast.makeText(
                                                context,
                                                if (shared) {
                                                    "تم تجهيز تقرير التقاطع (${file.name}) لفتحه في Excel"
                                                } else {
                                                    "تم حفظ تقرير التقاطع في: ${file.absolutePath}"
                                                },
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }.onFailure { err ->
                                            Toast.makeText(
                                                context,
                                                "تعذر تصدير التقرير: ${err.message}",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                        isExporting = false
                                    }
                                },
                                enabled = result.totalRowsCount > 0 && !isExporting,
                                border = BorderStroke(1.dp, OverlapIndigo),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = if (isExporting) "جاري تصدير التقرير..." else "تصدير تقرير التقاطع (Excel)",
                                    color = OverlapIndigo,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // نافذة اختيار تصنيف المساعدة المستهدفة من AidCategoryCatalog قبل الإدراج في family_complaints
    if (showTargetCategoryDialog && auditResult != null) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = { showTargetCategoryDialog = false },
                title = {
                    Text(
                        text = "اختيار تصنيف المساعدة المستهدفة",
                        color = OverlapSlateDark,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "سيتم إدراج $eligibleUnservedCount أسرة غير مخدومة من الطرفين (معتمدة أو مقيمة) في جدول الشكاوى والأولويات بحالة OPEN دون تكرار:",
                            color = OverlapSlateMuted,
                            fontSize = 12.sp
                        )
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 250.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(complaintTargetCategories) { category ->
                                val isSelected = selectedTargetComplaintCategory == category
                                Surface(
                                    color = if (isSelected) OverlapSelectedBg else Color.White,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) OverlapEmerald else OverlapBorder
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedTargetComplaintCategory = category }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = category,
                                            color = if (isSelected) OverlapEmerald else OverlapSlateDark,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 13.sp
                                        )
                                        if (isSelected) {
                                            Text(
                                                text = "✓ محدد",
                                                color = OverlapEmerald,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val rows = auditResult?.unservedByBoth.orEmpty()
                            showTargetCategoryDialog = false
                            scope.launch {
                                isTransferring = true
                                runCatching {
                                    PartnerOverlapAuditEngine.transferUnservedToComplaintsTable(
                                        database = database,
                                        unservedRows = rows,
                                        targetAidCategory = selectedTargetComplaintCategory,
                                        partnerFileName = selectedFileName
                                    )
                                }.onSuccess { summary ->
                                    val msg = when {
                                        summary.insertedCount > 0 && summary.skippedDuplicateCount > 0 ->
                                            "تم تحويل ${summary.insertedCount} أسرة إلى الشكاوى ($selectedTargetComplaintCategory) وتخطي ${summary.skippedDuplicateCount} مكررة"
                                        summary.insertedCount > 0 ->
                                            "تم إدراج ${summary.insertedCount} أسرة غير مخدومة في قائمة الشكاوى ($selectedTargetComplaintCategory)"
                                        else ->
                                            "جميع الأسر غير المخدومة المؤهلة لديها شكوى مفتوحة مسبقاً لنفس التصنيف"
                                    }
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                }.onFailure { err ->
                                    Toast.makeText(
                                        context,
                                        "تعذر التحويل إلى الشكاوى: ${err.message}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                                isTransferring = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = OverlapEmerald),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("تأكيد التحويل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showTargetCategoryDialog = false }) {
                        Text("إلغاء", color = OverlapSlateMuted, fontSize = 12.sp)
                    }
                }
            )
        }
    }
}

@Composable
private fun PartnerAuditRowCard(row: PartnerAuditRow) {
    val accent = categoryAccentColor(row.overlapCategory)

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = row.headName,
                    color = OverlapSlateDark,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.padding(horizontal = 4.dp))
                Surface(
                    color = accent.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
                ) {
                    Text(
                        text = row.overlapCategory.shortTabTitle,
                        color = accent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Text(
                text = "هوية: ${row.nationalId.ifBlank { "-" }} • المنطقة: ${row.currentSubRegion}",
                color = OverlapSlateMuted,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "الحالة: ${row.systemStatus} • آخر مساعدة: ${row.lastAidDetails}",
                color = OverlapSlateMuted,
                fontSize = 10.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

private fun categoryAccentColor(category: OverlapCategory): Color = when (category) {
    OverlapCategory.UNSERVED_BY_BOTH -> OverlapCrimson
    OverlapCategory.SERVED_BY_PARTNER_ONLY -> OverlapAmber
    OverlapCategory.SERVED_BY_US_ONLY -> OverlapTeal
    OverlapCategory.SERVED_BY_BOTH -> OverlapIndigo
}

private fun resolveFileName(context: Context, uri: Uri): String {
    runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val name = cursor.getString(0)?.trim()
                    if (!name.isNullOrBlank()) return name
                }
            }
    }
    return uri.lastPathSegment?.substringAfterLast('/')?.ifBlank { "partner_list.xlsx" } ?: "partner_list.xlsx"
}

private fun normalizeSearchInput(raw: String): String {
    val trimmed = raw.trim().lowercase(Locale.ROOT)
    if (trimmed.isBlank()) return ""
    val sb = StringBuilder(trimmed.length)
    for (ch in trimmed) {
        when (ch) {
            in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
            in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
            else -> sb.append(ch)
        }
    }
    return sb.toString()
}
