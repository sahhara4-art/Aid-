package com.humanitarian.aidmanagement.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.humanitarian.aidmanagement.data.local.entities.FamilyComplaintEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FamilyComplaintDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComplaint(complaint: FamilyComplaintEntity): Long

    @Query(
        """
        SELECT * FROM family_complaints
        WHERE status = 'OPEN'
        ORDER BY createdAt DESC, id DESC
        """
    )
    fun getAllOpenComplaintsFlow(): Flow<List<FamilyComplaintEntity>>

    @Query(
        """
        SELECT * FROM family_complaints
        WHERE status = 'OPEN'
        ORDER BY createdAt DESC, id DESC
        """
    )
    suspend fun getAllOpenComplaintsSync(): List<FamilyComplaintEntity>

    @Query(
        """
        SELECT * FROM family_complaints
        WHERE familyId = :familyNationalId AND status = 'OPEN'
        ORDER BY createdAt DESC, id DESC
        """
    )
    fun getOpenComplaintsForFamilyFlow(familyNationalId: String): Flow<List<FamilyComplaintEntity>>

    @Query(
        """
        SELECT * FROM family_complaints
        WHERE familyId = :familyNationalId
        ORDER BY createdAt DESC, id DESC
        """
    )
    fun getAllComplaintsForFamilyFlow(familyNationalId: String): Flow<List<FamilyComplaintEntity>>

    @Query(
        """
        SELECT DISTINCT familyId FROM family_complaints
        WHERE status = 'OPEN'
        """
    )
    fun getOpenComplaintFamilyIdsFlow(): Flow<List<String>>

    @Query(
        """
        UPDATE family_complaints
        SET status = 'NOMINATED',
            nominatedProjectName = :projectName
        WHERE familyId IN (:familyNationalIds)
          AND status = 'OPEN'
        """
    )
    suspend fun markComplaintsNominatedByFamilyIds(
        familyNationalIds: List<String>,
        projectName: String
    ): Int

    @Query(
        """
        UPDATE family_complaints
        SET status = :newStatus
        WHERE id = :complaintId
        """
    )
    suspend fun updateComplaintStatus(complaintId: Long, newStatus: String): Int

    @Query("DELETE FROM family_complaints WHERE id = :complaintId")
    suspend fun deleteComplaintById(complaintId: Long): Int
}
