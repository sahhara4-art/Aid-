package com.humanitarian.aidmanagement.ui.screens.nomination

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.engine.ScoringProfileConfig
import com.humanitarian.aidmanagement.engine.ScoringProfileStore
import com.humanitarian.aidmanagement.engine.VulnerabilityCriterionKeys
import kotlin.math.roundToInt

private val CalibEmerald = Color(0xFF0F7B53)
private val CalibSlateDark = Color(0xFF0F172A)
private val CalibSlateMuted = Color(0xFF64748B)
private val CalibRose = Color(0xFFDC2626)
private val CalibBorder = Color(0xFFD6E8DF)
private val CalibSurfaceSoft = Color(0xFFF4F9F6)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScoringCalibrationDialog(
    context: Context,
    onDismiss: () -> Unit,
    onProfileApplied: (ScoringProfileConfig) -> Unit
) {
    var profiles by remember { mutableStateOf(ScoringProfileStore.getAllProfiles(context)) }
    val initialProfile = remember { ScoringProfileStore.getActiveProfile(context) }

    var selectedProfileId by remember { mutableStateOf(initialProfile.profileId) }
    var selectedProfileName by remember { mutableStateOf(initialProfile.profileName) }
    var selectedIsBuiltIn by remember { mutableStateOf(initialProfile.isBuiltIn) }

    var housingDamageWeight by remember { mutableIntStateOf(initialProfile.housingDamageWeight) }
    var childAgeGroupWeight by remember { mutableIntStateOf(initialProfile.childAgeGroupWeight) }
    var familySizeWeight by remember { mutableIntStateOf(initialProfile.familySizeWeight) }
    var employmentIncomeWeight by remember { mutableIntStateOf(initialProfile.employmentIncomeWeight) }
    var daysSinceLastAidWeight by remember { mutableIntStateOf(initialProfile.daysSinceLastAidWeight) }
    var openComplaintWeight by remember { mutableIntStateOf(initialProfile.openComplaintWeight) }

    var minChildAgeText by remember { mutableStateOf(initialProfile.minChildAgeYears.toString()) }
    var maxChildAgeText by remember { mutableStateOf(initialProfile.maxChildAgeYears.toString()) }
    var priorityOrder by remember { mutableStateOf(initialProfile.priorityOrder) }

    var newProfileName by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    fun loadProfileIntoState(profile: ScoringProfileConfig) {
        val norm = profile.normalized()
        selectedProfileId = norm.profileId
        selectedProfileName = norm.profileName
        selectedIsBuiltIn = norm.isBuiltIn
        housingDamageWeight = norm.housingDamageWeight
        childAgeGroupWeight = norm.childAgeGroupWeight
        familySizeWeight = norm.familySizeWeight
        employmentIncomeWeight = norm.employmentIncomeWeight
        daysSinceLastAidWeight = norm.daysSinceLastAidWeight
        openComplaintWeight = norm.openComplaintWeight
        minChildAgeText = norm.minChildAgeYears.toString()
        maxChildAgeText = norm.maxChildAgeYears.toString()
        priorityOrder = norm.priorityOrder
    }

    fun buildCurrentConfig(
        profileId: String = selectedProfileId,
        profileName: String = selectedProfileName,
        isBuiltIn: Boolean = selectedIsBuiltIn
    ): ScoringProfileConfig {
        val minAge = minChildAgeText.toIntOrNull() ?: 0
        val maxAge = maxChildAgeText.toIntOrNull() ?: 2
        return ScoringProfileConfig(
            profileId = profileId,
            profileName = profileName,
            housingDamageWeight = housingDamageWeight,
            childAgeGroupWeight = childAgeGroupWeight,
            familySizeWeight = familySizeWeight,
            employmentIncomeWeight = employmentIncomeWeight,
            daysSinceLastAidWeight = daysSinceLastAidWeight,
            openComplaintWeight = openComplaintWeight,
            minChildAgeYears = minAge,
            maxChildAgeYears = maxAge,
            priorityOrder = priorityOrder,
            isBuiltIn = isBuiltIn
        ).normalized()
    }

    val totalWeights = housingDamageWeight +
        childAgeGroupWeight +
        familySizeWeight +
        employmentIncomeWeight +
        daysSinceLastAidWeight +
        openComplaintWeight

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color.White,
            shape = RoundedCornerShape(22.dp),
            title = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "معايرة مؤشر الهشاشة والاستحقاق",
                        color = CalibSlateDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "مجموع الأوزان الحالية: $totalWeights (يُحسب المؤشر نسبياً من 100)",
                        color = CalibSlateMuted,
                        fontSize = 12.sp
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // 1. اختيار القوالب المحفوظة
                    Text(
                        text = "القوالب الجاهزة والمحفوظة",
                        color = CalibSlateDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 2.dp)
                    ) {
                        items(profiles, key = { it.profileId }) { profile ->
                            val isSelected = profile.profileId == selectedProfileId
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    loadProfileIntoState(profile)
                                    statusMessage = null
                                },
                                label = {
                                    Text(
                                        text = profile.profileName,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CalibEmerald.copy(alpha = 0.14f),
                                    selectedLabelColor = CalibEmerald
                                )
                            )
                        }
                    }

                    // حفظ قالب جديد + حذف القالب المخصص
                    Surface(
                        color = CalibSurfaceSoft,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, CalibBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = newProfileName,
                                onValueChange = {
                                    newProfileName = it
                                    statusMessage = null
                                },
                                label = { Text("اسم القالب الجديد", fontSize = 12.sp) },
                                placeholder = { Text("مثال: أولوية الأسر الأشد حاجة", fontSize = 12.sp) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        val cleanName = newProfileName.trim()
                                        if (cleanName.isEmpty()) {
                                            statusMessage = "يرجى كتابة اسم القالب قبل الحفظ"
                                        } else {
                                            val draft = buildCurrentConfig(
                                                profileId = "",
                                                profileName = cleanName,
                                                isBuiltIn = false
                                            )
                                            val saved = ScoringProfileStore.saveProfile(
                                                context = context,
                                                profile = draft,
                                                setAsActive = true
                                            )
                                            profiles = ScoringProfileStore.getAllProfiles(context)
                                            loadProfileIntoState(saved)
                                            newProfileName = ""
                                            statusMessage = "تم حفظ القالب «${saved.profileName}» بنجاح"
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CalibEmerald),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("حفظ كقالب جديد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                if (!selectedIsBuiltIn) {
                                    TextButton(
                                        onClick = {
                                            val deletedName = selectedProfileName
                                            if (ScoringProfileStore.deleteProfile(context, selectedProfileId)) {
                                                profiles = ScoringProfileStore.getAllProfiles(context)
                                                val fallback = ScoringProfileStore.getActiveProfile(context)
                                                loadProfileIntoState(fallback)
                                                statusMessage = "تم حذف القالب «$deletedName»"
                                            }
                                        },
                                        colors = ButtonDefaults.textButtonColors(contentColor = CalibRose)
                                    ) {
                                        Text("حذف", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            if (!statusMessage.isNullOrBlank()) {
                                Text(
                                    text = statusMessage ?: "",
                                    color = CalibEmerald,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    SectionDivider()

                    // 2. أوزان المؤشرات الستة (0..100)
                    Text(
                        text = "أوزان معايير التقييم (0 إلى 100)",
                        color = CalibSlateDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    WeightSliderItem(
                        label = "ضرر السكن",
                        value = housingDamageWeight,
                        onValueChange = { housingDamageWeight = it }
                    )
                    WeightSliderItem(
                        label = "الفئة العمرية للأبناء",
                        value = childAgeGroupWeight,
                        onValueChange = { childAgeGroupWeight = it }
                    )
                    WeightSliderItem(
                        label = "حجم الأسرة",
                        value = familySizeWeight,
                        onValueChange = { familySizeWeight = it }
                    )
                    WeightSliderItem(
                        label = "حالة العمل والدخل",
                        value = employmentIncomeWeight,
                        onValueChange = { employmentIncomeWeight = it }
                    )
                    WeightSliderItem(
                        label = "مدة الانقطاع منذ آخر استلام",
                        value = daysSinceLastAidWeight,
                        onValueChange = { daysSinceLastAidWeight = it }
                    )
                    WeightSliderItem(
                        label = "وجود شكوى مفتوحة",
                        value = openComplaintWeight,
                        onValueChange = { openComplaintWeight = it }
                    )

                    SectionDivider()

                    // 3. نطاق عمر الأطفال المستهدف
                    Text(
                        text = "النطاق العمري المستهدف للأبناء (بالسنوات)",
                        color = CalibSlateDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = minChildAgeText,
                            onValueChange = { raw ->
                                minChildAgeText = raw.filter { it.isDigit() }.take(3)
                            },
                            label = { Text("من عمر (سنة)", fontSize = 12.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = maxChildAgeText,
                            onValueChange = { raw ->
                                maxChildAgeText = raw.filter { it.isDigit() }.take(3)
                            },
                            label = { Text("إلى عمر (سنة)", fontSize = 12.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    SectionDivider()

                    // 4. ترتيب أولوية كسر التعادل
                    Text(
                        text = "ترتيب أولوية كسر التعادل عند تساوي الدرجة",
                        color = CalibSlateDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        priorityOrder.forEachIndexed { index, criterionKey ->
                            Surface(
                                color = CalibSurfaceSoft,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, CalibBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${index + 1}. ${VulnerabilityCriterionKeys.labelAr(criterionKey)}",
                                        color = CalibSlateDark,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier.weight(1f),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        TextButton(
                                            onClick = {
                                                if (index > 0) {
                                                    val mutable = priorityOrder.toMutableList()
                                                    val temp = mutable[index - 1]
                                                    mutable[index - 1] = mutable[index]
                                                    mutable[index] = temp
                                                    priorityOrder = mutable
                                                }
                                            },
                                            enabled = index > 0,
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("▲ أعلى", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }

                                        TextButton(
                                            onClick = {
                                                if (index < priorityOrder.lastIndex) {
                                                    val mutable = priorityOrder.toMutableList()
                                                    val temp = mutable[index + 1]
                                                    mutable[index + 1] = mutable[index]
                                                    mutable[index] = temp
                                                    priorityOrder = mutable
                                                }
                                            },
                                            enabled = index < priorityOrder.lastIndex,
                                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text("▼ أسفل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val currentConfig = buildCurrentConfig()
                        val existingSelected = profiles.firstOrNull { it.profileId == selectedProfileId }
                        val appliedConfig = if (selectedIsBuiltIn && existingSelected != null && existingSelected.normalized() == currentConfig) {
                            ScoringProfileStore.setActiveProfileId(context, existingSelected.profileId)
                            existingSelected.normalized()
                        } else if (selectedIsBuiltIn) {
                            val customName = newProfileName.trim().ifBlank { "$selectedProfileName (معدل)" }
                            ScoringProfileStore.saveProfile(
                                context = context,
                                profile = currentConfig.copy(
                                    profileId = "",
                                    profileName = customName,
                                    isBuiltIn = false
                                ),
                                setAsActive = true
                            )
                        } else {
                            ScoringProfileStore.saveProfile(
                                context = context,
                                profile = currentConfig.copy(isBuiltIn = false),
                                setAsActive = true
                            )
                        }
                        onProfileApplied(appliedConfig)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CalibEmerald),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("اعتماد وتطبيق", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("إغلاق", color = CalibSlateMuted, fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }
}

@Composable
private fun WeightSliderItem(
    label: String,
    value: Int,
    onValueChange: (Int) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                color = CalibSlateDark,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Surface(
                color = CalibEmerald.copy(alpha = 0.12f),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = "$value",
                    color = CalibEmerald,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Slider(
            value = value.toFloat(),
            onValueChange = { onValueChange(it.roundToInt().coerceIn(0, 100)) },
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = CalibEmerald,
                activeTrackColor = CalibEmerald,
                inactiveTrackColor = CalibBorder
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun SectionDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(CalibBorder)
    )
}
