package com.humanitarian.aidmanagement.civilregistry.bridge

import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryRecord
import com.humanitarian.aidmanagement.civilregistry.security.CivilRegistryPermissionGuard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * جسر الترحيل المؤقت أحادي الاتجاه (Decoupled Draft Transfer Bridge)
 *
 * يفصل وحدة البحث في السجل المدني بالكامل عن قاعدة بيانات المشروع:
 * - يسمح بتجهيز أو استهلاك المسودة فقط إذا كان المستخدم مخوّلاً (canAccessCivilRegistry == true).
 * - عند عدم التخويل: يمسح أي مسودة بصمت دون السماح بتمرير أي بيانات من السجل المدني.
 */
object CivilRegistryDraftBridge {

    private val _pendingDraft = MutableStateFlow<CivilRegistryRecord?>(null)
    val pendingDraft: StateFlow<CivilRegistryRecord?> = _pendingDraft.asStateFlow()

    /**
     * تجهيز سجل من السجل المدني كمسودة مؤقتة للترحيل إلى شاشة الإضافة (للمخوّل فقط)
     */
    fun stageDraft(record: CivilRegistryRecord) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            _pendingDraft.value = null
            return
        }
        _pendingDraft.value = record
    }

    /**
     * استهلاك المسودة مرة واحدة عند فتح صفحة الإضافة (للمخوّل فقط)
     */
    fun consumeDraft(): CivilRegistryRecord? {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            _pendingDraft.value = null
            return null
        }
        val current = _pendingDraft.value
        _pendingDraft.value = null
        return current
    }

    /**
     * إلغاء وتجاهل أي مسودة عالقة
     */
    fun clearDraft() {
        _pendingDraft.value = null
    }
}
