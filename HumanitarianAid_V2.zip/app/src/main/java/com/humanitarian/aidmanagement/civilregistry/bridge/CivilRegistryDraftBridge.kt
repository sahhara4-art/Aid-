package com.humanitarian.aidmanagement.civilregistry.bridge

import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryChildRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryRecord
import com.humanitarian.aidmanagement.civilregistry.security.CivilRegistryPermissionGuard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * جسر الترحيل المؤقت أحادي الاتجاه (Decoupled Draft Transfer Bridge)
 *
 * يفصل وحدة البحث في السجل المدني بالكامل عن قاعدة بيانات المشروع:
 * - يسمح بتجهيز أو استهلاك المسودة (رب الأسرة + الأبناء المرتبطون) فقط إذا كان المستخدم مخوّلاً (canAccessCivilRegistry == true).
 * - عند عدم التخويل: يمسح أي مسودة بصمت دون السماح بتمرير أي بيانات من السجل المدني.
 */
object CivilRegistryDraftBridge {

    private val _pendingDraft = MutableStateFlow<CivilRegistryRecord?>(null)
    val pendingDraft: StateFlow<CivilRegistryRecord?> = _pendingDraft.asStateFlow()

    private val _pendingDraftChildren = MutableStateFlow<List<CivilRegistryChildRecord>>(emptyList())
    val pendingDraftChildren: StateFlow<List<CivilRegistryChildRecord>> = _pendingDraftChildren.asStateFlow()

    /**
     * تجهيز سجل من السجل المدني (مع قائمة أبنائه إن وُجدت) كمسودة مؤقتة للترحيل إلى شاشة الإضافة (للمخوّل فقط)
     */
    fun stageDraft(
        record: CivilRegistryRecord,
        children: List<CivilRegistryChildRecord> = emptyList()
    ) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            clearDraft()
            return
        }
        _pendingDraft.value = record
        _pendingDraftChildren.value = children
    }

    /**
     * استهلاك المسودة مرة واحدة عند فتح صفحة الإضافة (للمخوّل فقط)
     */
    fun consumeDraft(): CivilRegistryRecord? {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            clearDraft()
            return null
        }
        val current = _pendingDraft.value
        _pendingDraft.value = null
        return current
    }

    /**
     * استهلاك مسودة رب الأسرة مع قائمة الأبناء المرتبطين مرة واحدة عند فتح صفحة الإضافة (للمخوّل فقط)
     */
    fun consumeDraftWithChildren(): Pair<CivilRegistryRecord, List<CivilRegistryChildRecord>>? {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            clearDraft()
            return null
        }
        val current = _pendingDraft.value ?: return null
        val children = _pendingDraftChildren.value
        _pendingDraft.value = null
        _pendingDraftChildren.value = emptyList()
        return current to children
    }

    /**
     * إلغاء وتجاهل أي مسودة عالقة (رب الأسرة والأبناء)
     */
    fun clearDraft() {
        _pendingDraft.value = null
        _pendingDraftChildren.value = emptyList()
    }
}
