package com.humanitarian.aidmanagement.civilregistry.bridge

import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * جسر الترحيل المؤقت أحادي الاتجاه (Decoupled Draft Transfer Bridge)
 *
 * يفصل وحدة البحث في السجل المدني بالكامل عن قاعدة بيانات المشروع:
 * - وحدة السجل المدني تضع السجل المختار هنا كمسودة غير محفوظة (Draft / Unsaved State) فقط.
 * - صفحة الإضافة الخاصة بالمشروع تستهلك المسودة لتعبئة حقولها القابلة للتعديل.
 * - قرار الحفظ أو التجاهل يبقى 100% بيد المستخدم دون أي كتابة تلقائية في المشروع أو في civil_registry.db.
 */
object CivilRegistryDraftBridge {

    private val _pendingDraft = MutableStateFlow<CivilRegistryRecord?>(null)
    val pendingDraft: StateFlow<CivilRegistryRecord?> = _pendingDraft.asStateFlow()

    /**
     * تجهيز سجل من السجل المدني كمسودة مؤقتة للترحيل إلى شاشة الإضافة
     */
    fun stageDraft(record: CivilRegistryRecord) {
        _pendingDraft.value = record
    }

    /**
     * استهلاك المسودة مرة واحدة عند فتح صفحة الإضافة
     */
    fun consumeDraft(): CivilRegistryRecord? {
        val current = _pendingDraft.value
        _pendingDraft.value = null
        return current
    }

    /**
     * إلغاء وتجاهل أي مسودة عالقة
     */
    fun clearDraft() {
        _pendingDraft.value = null
    }
}
