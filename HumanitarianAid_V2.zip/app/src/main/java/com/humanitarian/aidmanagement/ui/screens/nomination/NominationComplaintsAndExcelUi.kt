package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.data.local.entities.FamilyComplaintEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.util.ExcelNominationFeedback
import com.humanitarian.aidmanagement.util.ExcelNominationResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val PriorityEmerald = Color(0xFF0F7B53)
private val PriorityEmeraldLight = Color(0xFF10B981)
private val PriorityAmber = Color(0xFFD97706)
private val PriorityRose = Color(0xFFDC2626)
private val PriorityIndigo = Color(0xFF4F46E5)
private val PrioritySlateDark = Color(0xFF0F172A)
private val PrioritySlateMuted = Color(0xFF64748B)
private val PriorityGlassBorder = Color(0xFFD6E8DF)

/**
 * عنصر شكوى مفتوحة بعد التدقيق التلقائي مقابل شروط وفلاتر المشروع الحالي
 */
data class AuditedComplaintItem(
    val complaint: FamilyComplaintEntity,
    val family: FamilyEntity?,
    val isCompliant: Boolean,
    val nonComplianceReasons: List<String>,
    val isAlreadyNominatedInProject: Boolean,
    val isSelectedInBasket: Boolean
) {
    val nonComplianceSummary: String
        get() = nonComplianceReasons.joinToString(" • ")
}

/**
 * شريط التبديل الفرعي داخل الخطوة ٣ للتنقل السلس بين الحصص والترشيح الآلي/اليدوي وبين قائمة الشكاوى والأولويات
 */
@Composable
fun Step2ModeSwitcherBar(
    selectedSubTab: Int,
    openComplaintsCount: Int,
    onSelectSubTab: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFFF1F7F4),
        border = BorderStroke(1.dp, PriorityGlassBorder),
        shadowElevation = 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val isQuotas = selectedSubTab == 0
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onSelectSubTab(0) },
                shape = RoundedCornerShape(10.dp),
                color = if (isQuotas) PriorityEmerald else Color.Transparent
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 9.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PieChart,
                        contentDescription = null,
                        tint = if (isQuotas) Color.White else PrioritySlateDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "الحصص والترشيح",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isQuotas) Color.White else PrioritySlateDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            val isComplaints = selectedSubTab == 1
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onSelectSubTab(1) },
                shape = RoundedCornerShape(10.dp),
                color = if (isComplaints) PriorityAmber else Color.Transparent
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 9.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PriorityHigh,
                        contentDescription = null,
                        tint = if (isComplaints) Color.White else PriorityAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "الشكاوى والأولويات ($openComplaintsCount)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isComplaints) Color.White else PrioritySlateDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/**
 * قسم «قائمة الشكاوى والأولويات» المستقل داخل محرك الترشيح الهجين الذكي V3.0
 */
@Composable
fun ComplaintsPrioritySection(
    auditedComplaints: List<AuditedComplaintItem>,
    availableCategoryFilters: List<String>,
    selectedCategoryFilter: String,
    remainingQuota: Int,
    selectedNomineesCount: Int,
    isReadOnlyMode: Boolean,
    onSelectCategoryFilter: (String) -> Unit,
    onToggleComplaintInBasket: (AuditedComplaintItem) -> Unit,
    onSelectAllFilteredComplaints: () -> Unit,
    onOpenExcelPriorityImport: () -> Unit
) {
    val dateFormatter = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    val filteredItems = remember(auditedComplaints, selectedCategoryFilter) {
        if (selectedCategoryFilter.isBlank() || selectedCategoryFilter == "الكل") {
            auditedComplaints
        } else {
            auditedComplaints.filter {
                it.complaint.targetAidCategory.trim().equals(selectedCategoryFilter.trim(), ignoreCase = true)
            }
        }
    }
    val selectedInComplaintsCount = remember(auditedComplaints) {
        auditedComplaints.count { it.isSelectedInBasket }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // بطاقة الملخص والإجراءات السريعة
        item(key = "complaints_header_card") {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = Color.White.copy(alpha = 0.94f),
                border = BorderStroke(1.dp, PriorityGlassBorder),
                shadowElevation = 0.dp
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "قائمة الشكاوى والأولويات المفتوحة",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = PrioritySlateDark
                            )
                            Text(
                                text = "المفتوحة: ${filteredItems.size} • المضافة للسلة: $selectedInComplaintsCount • المتبقي: ${(remainingQuota - selectedNomineesCount).coerceAtLeast(0)}",
                                fontSize = 11.sp,
                                color = PrioritySlateMuted
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = PriorityEmerald.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "سلة الترشيح: $selectedNomineesCount / $remainingQuota",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PriorityEmerald,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // شريط الفلترة السريعة حسب تصنيف المساعدة المستهدفة
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val chips = listOf("الكل") + availableCategoryFilters
                        chips.forEach { cat ->
                            val isSelected = (selectedCategoryFilter.ifBlank { "الكل" }) == cat
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = if (isSelected) PriorityEmerald else Color(0xFFF1F5F9),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) PriorityEmerald else PriorityGlassBorder
                                ),
                                modifier = Modifier.clickable { onSelectCategoryFilter(cat) }
                            ) {
                                Text(
                                    text = cat,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) Color.White else PrioritySlateDark,
                                    modifier = Modifier.padding(horizontal = 11.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    // أزرار تحديد الكل والترشيح عبر الإكسل
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onSelectAllFilteredComplaints,
                            enabled = !isReadOnlyMode && filteredItems.isNotEmpty() && selectedNomineesCount < remainingQuota,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PriorityAmber)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DoneAll,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text("تحديد الكل للسلة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onOpenExcelPriorityImport,
                            enabled = !isReadOnlyMode,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, PriorityIndigo.copy(alpha = 0.55f))
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.UploadFile,
                                contentDescription = null,
                                tint = PriorityIndigo,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "ترشيح إكسل",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = PriorityIndigo
                            )
                        }
                    }
                }
            }
        }

        if (filteredItems.isEmpty()) {
            item(key = "complaints_empty") {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White.copy(alpha = 0.9f),
                    border = BorderStroke(1.dp, PriorityGlassBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(30.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.MarkEmailRead,
                            contentDescription = null,
                            tint = PriorityEmerald,
                            modifier = Modifier.size(38.dp)
                        )
                        Text(
                            text = "لا توجد شكاوى مفتوحة مطابقة للتصنيف المحدد",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = PrioritySlateDark
                        )
                        Text(
                            text = "يمكن تسجيل شكاوى وأولويات الأسر من داخل شاشة تفاصيل كل أسرة لتظهر هنا تلقائياً.",
                            fontSize = 12.sp,
                            color = PrioritySlateMuted
                        )
                    }
                }
            }
        } else {
            items(filteredItems, key = { it.complaint.id }) { item ->
                val canToggle = !isReadOnlyMode &&
                    item.family != null &&
                    !item.isAlreadyNominatedInProject &&
                    (item.isSelectedInBasket || selectedNomineesCount < remainingQuota)

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = canToggle) { onToggleComplaintInBasket(item) },
                    shape = RoundedCornerShape(16.dp),
                    color = if (item.isSelectedInBasket) {
                        PriorityEmerald.copy(alpha = 0.08f)
                    } else {
                        Color.White.copy(alpha = 0.95f)
                    },
                    border = BorderStroke(
                        width = if (item.isSelectedInBasket) 1.5.dp else 1.dp,
                        color = if (item.isSelectedInBasket) PriorityEmerald else PriorityGlassBorder
                    ),
                    shadowElevation = 0.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Checkbox(
                                    checked = item.isSelectedInBasket,
                                    onCheckedChange = { if (canToggle) onToggleComplaintInBasket(item) },
                                    enabled = canToggle,
                                    colors = CheckboxDefaults.colors(checkedColor = PriorityEmerald)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.complaint.familyName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = PrioritySlateDark
                                    )
                                    Text(
                                        text = "هوية: ${item.complaint.familyId} • المنطقة: ${item.complaint.localArea.ifBlank { "غير محددة" }}",
                                        fontSize = 11.sp,
                                        color = PrioritySlateMuted
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(50),
                                color = PriorityIndigo.copy(alpha = 0.12f),
                                border = BorderStroke(0.8.dp, PriorityIndigo.copy(alpha = 0.25f))
                            ) {
                                Text(
                                    text = item.complaint.targetAidCategory,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PriorityIndigo,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        // سبب الشكوى وتاريخ التسجيل
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "السبب: ${item.complaint.complaintReason}",
                                fontSize = 12.sp,
                                color = PrioritySlateDark,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = dateFormatter.format(Date(item.complaint.createdAt)),
                                fontSize = 10.sp,
                                color = PrioritySlateMuted
                            )
                        }

                        // شارة التقييم التلقائي مقابل شروط المشروع الحالي
                        val badgeColor = when {
                            item.isAlreadyNominatedInProject -> PrioritySlateMuted
                            item.isCompliant -> PriorityEmerald
                            else -> PriorityAmber
                        }
                        val badgeText = when {
                            item.isAlreadyNominatedInProject -> "مرشح مسبقاً في هذا المشروع"
                            item.isCompliant -> "مطابق لشروط المشروع"
                            else -> "غير مطابق للشروط: ${item.nonComplianceSummary}"
                        }
                        val badgeIcon = when {
                            item.isAlreadyNominatedInProject -> Icons.Rounded.Verified
                            item.isCompliant -> Icons.Rounded.CheckCircle
                            else -> Icons.Rounded.WarningAmber
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = badgeColor.copy(alpha = 0.12f),
                            border = BorderStroke(0.8.dp, badgeColor.copy(alpha = 0.30f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = badgeIcon,
                                    contentDescription = null,
                                    tint = badgeColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = badgeText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = badgeColor,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        if (!item.isCompliant && !item.isAlreadyNominatedInProject && item.family != null) {
                            Text(
                                text = "يمكنك تحديد الأسرة يدوياً لضمها كاستثناء ميداني مباشر إلى سلة الترشيح.",
                                fontSize = 10.sp,
                                color = PrioritySlateMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * نافذة عرض نتائج وتغذية راجعة الترشيح من ملف الإكسل بتصميم Glassmorphism V3.0
 */
@Composable
fun ExcelNominationFeedbackDialog(
    result: ExcelNominationResult,
    onExportCsv: () -> Unit,
    onDismiss: () -> Unit
) {
    var activeFilter by remember { mutableIntStateOf(0) } // 0: الكل، 1: المقبولون، 2: المرفوضون
    val displayedList = remember(result.feedbackList, activeFilter) {
        when (activeFilter) {
            1 -> result.feedbackList.filter { it.isAccepted }
            2 -> result.feedbackList.filter { !it.isAccepted }
            else -> result.feedbackList
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.88f),
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFFF7FBF9).copy(alpha = 0.98f),
                border = BorderStroke(1.2.dp, PriorityGlassBorder),
                shadowElevation = 0.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0xFFECF8F2),
                                    Color(0xFFFFFFFF)
                                )
                            )
                        )
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // الترويسة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "نتائج وتغذية راجعة ترشيح الإكسل",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = PrioritySlateDark
                            )
                            Text(
                                text = "الملف: ${result.fileName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = PrioritySlateMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "إغلاق",
                                tint = PrioritySlateMuted
                            )
                        }
                    }

                    // ملخص رقمي علوي (الإجمالي / المقبولون / المرفوضون)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FeedbackMetricCard(
                            label = "إجمالي الهويات",
                            value = result.totalReadCount.toString(),
                            accent = PriorityIndigo,
                            modifier = Modifier.weight(1f)
                        )
                        FeedbackMetricCard(
                            label = "مقبول ومرشح",
                            value = result.acceptedCount.toString(),
                            accent = PriorityEmerald,
                            modifier = Modifier.weight(1f)
                        )
                        FeedbackMetricCard(
                            label = "مرفوض / مستبعد",
                            value = result.rejectedCount.toString(),
                            accent = PriorityRose,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // شرائح التصفية السريعة (الكل / المقبولون / المرفوضون)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val tabs = listOf(
                            "الكل (${result.totalReadCount})",
                            "المقبولون (${result.acceptedCount})",
                            "المرفوضون (${result.rejectedCount})"
                        )
                        tabs.forEachIndexed { idx, title ->
                            val selected = activeFilter == idx
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { activeFilter = idx },
                                shape = RoundedCornerShape(50),
                                color = if (selected) PriorityEmerald else Color.White,
                                border = BorderStroke(
                                    1.dp,
                                    if (selected) PriorityEmerald else PriorityGlassBorder
                                )
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 7.dp, horizontal = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = title,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selected) Color.White else PrioritySlateDark,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }

                    // قائمة نتائج التدقيق التفصيلية
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(
                            items = displayedList,
                            key = { "${it.rowNumber}_${it.nationalId}" }
                        ) { row ->
                            FeedbackRowCard(row)
                        }
                    }

                    // أزرار التصدير والإغلاق
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(0.9f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("إغلاق", fontWeight = FontWeight.SemiBold)
                        }

                        Button(
                            onClick = onExportCsv,
                            modifier = Modifier.weight(1.6f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PriorityEmerald)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Download,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تصدير التغذية الراجعة (Excel / CSV)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeedbackMetricCard(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = accent.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = accent
            )
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = PrioritySlateDark,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun FeedbackRowCard(item: ExcelNominationFeedback) {
    val accent = if (item.isAccepted) PriorityEmerald else PriorityRose
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.28f)),
        shadowElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.familyName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = PrioritySlateDark
                    )
                    Text(
                        text = "هوية: ${item.nationalId} • المنطقة المحلية: ${item.localArea}",
                        fontSize = 11.sp,
                        color = PrioritySlateMuted
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = accent.copy(alpha = 0.13f)
                ) {
                    Text(
                        text = item.decisionLabel,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = accent,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = "حالة الأسرة: ${item.familyStatus}",
                fontSize = 11.sp,
                color = PrioritySlateMuted
            )

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = accent.copy(alpha = 0.08f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = item.feedbackReason,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = accent,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                )
            }
        }
    }
}
