package com.humanitarian.aidmanagement.security

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * سجل رقابي غير قابل للتعديل مربوط بسلسلة بصمات SHA-256 (Hash-Chained Audit Log).
 */
data class AuditLogRecord(
    val id: String,
    val timestampText: String,
    val actionType: String,
    val targetId: String,
    val details: String,
    val performedBy: String,
    val prevHash: String,
    val entryHash: String
)

/**
 * محرك السجل الرقابي المقاوم للتلاعب (Tamper-Proof Hash Chain Audit Log).
 * يحفظ العمليات الحساسة تسلسلياً في ملف JSONL مستقل داخل التخزين الداخلي،
 * مع ربط كل سجل ببصمة SHA-256 للسجل السابق لاكتشاف أي تعديل أو حذف يدوي.
 */
object TamperProofAuditLog {

    private const val AUDIT_DIR_NAME = "audit_chain"
    private const val AUDIT_FILE_NAME = "immutable_audit.jsonl"
    private const val EXPORT_DIR_NAME = "audit_exports"
    private const val TIMESTAMP_PATTERN = "yyyy-MM-dd HH:mm:ss"
    private const val FILE_TIMESTAMP_PATTERN = "yyyyMMdd_HHmmss"
    private const val HASH_ALGORITHM = "SHA-256"
    private const val UTF8_BOM = "\uFEFF"

    const val GENESIS_HASH = "0000000000000000000000000000000000000000000000000000000000000000"

    private const val KEY_ID = "id"
    private const val KEY_TIMESTAMP = "timestampText"
    private const val KEY_ACTION_TYPE = "actionType"
    private const val KEY_TARGET_ID = "targetId"
    private const val KEY_DETAILS = "details"
    private const val KEY_PERFORMED_BY = "performedBy"
    private const val KEY_PREV_HASH = "prevHash"
    private const val KEY_ENTRY_HASH = "entryHash"

    private val chainLock = Any()

    /**
     * يسجل حدثاً رقابياً جديداً في نهاية السلسلة، مع ربطه ببصمة SHA-256 لآخر سجل مسجل.
     */
    suspend fun logEvent(
        context: Context,
        actionType: String,
        targetId: String,
        details: String,
        performedBy: String
    ): AuditLogRecord = withContext(Dispatchers.IO) {
        synchronized(chainLock) {
            val auditFile = getAuditFile(context)
            auditFile.parentFile?.let { parent ->
                if (!parent.exists()) parent.mkdirs()
            }

            val prevHash = readLastEntryHashLocked(auditFile)
            val now = Date()
            val id = "AUD-${now.time}-${UUID.randomUUID().toString().replace("-", "").take(8).uppercase(Locale.US)}"
            val timestampText = SimpleDateFormat(TIMESTAMP_PATTERN, Locale.US).format(now)
            val cleanAction = actionType.trim().ifBlank { "عملية غير مصنفة" }
            val cleanTarget = targetId.trim().ifBlank { "-" }
            val cleanDetails = details.trim()
            val cleanPerformer = performedBy.trim().ifBlank { "مستخدم النظام" }

            val entryHash = computeEntryHash(
                id = id,
                timestampText = timestampText,
                actionType = cleanAction,
                targetId = cleanTarget,
                details = cleanDetails,
                performedBy = cleanPerformer,
                prevHash = prevHash
            )

            val record = AuditLogRecord(
                id = id,
                timestampText = timestampText,
                actionType = cleanAction,
                targetId = cleanTarget,
                details = cleanDetails,
                performedBy = cleanPerformer,
                prevHash = prevHash,
                entryHash = entryHash
            )

            val jsonLine = serializeRecordToJsonLine(record)
            FileOutputStream(auditFile, true).use { fos ->
                OutputStreamWriter(fos, Charsets.UTF_8).use { writer ->
                    writer.write(jsonLine)
                    writer.write("\n")
                    writer.flush()
                }
            }

            record
        }
    }

    /**
     * يقرأ كافة السجلات الرقابية من ملف السلسلة مرتبة من الأحدث إلى الأقدم.
     */
    suspend fun loadAllLogs(context: Context): List<AuditLogRecord> = withContext(Dispatchers.IO) {
        synchronized(chainLock) {
            val auditFile = getAuditFile(context)
            readAllRecordsChronologicalLocked(auditFile).asReversed()
        }
    }

    /**
     * يتحقق من سلامة تسلسل بصمات SHA-256 لجميع السجلات في الملف.
     * يُرجع true فقط إذا كانت السلسلة سليمة 100% ولم يُعدل أو يُحذف أي سجل يدوياً.
     */
    suspend fun verifyChainIntegrity(context: Context): Boolean = withContext(Dispatchers.IO) {
        synchronized(chainLock) {
            val auditFile = getAuditFile(context)
            if (!auditFile.exists() || !auditFile.isFile || auditFile.length() == 0L) {
                return@withContext true
            }

            var expectedPrevHash = GENESIS_HASH
            var isIntact = true

            runCatching {
                auditFile.bufferedReader(Charsets.UTF_8).useLines { lines ->
                    for (rawLine in lines) {
                        val line = rawLine.trim()
                        if (line.isEmpty()) continue

                        val record = parseRecordFromJsonLine(line)
                        if (record == null) {
                            isIntact = false
                            break
                        }

                        if (!constantTimeEquals(record.prevHash, expectedPrevHash)) {
                            isIntact = false
                            break
                        }

                        val recomputedHash = computeEntryHash(
                            id = record.id,
                            timestampText = record.timestampText,
                            actionType = record.actionType,
                            targetId = record.targetId,
                            details = record.details,
                            performedBy = record.performedBy,
                            prevHash = record.prevHash
                        )

                        if (!constantTimeEquals(record.entryHash, recomputedHash)) {
                            isIntact = false
                            break
                        }

                        expectedPrevHash = record.entryHash
                    }
                }
            }.onFailure {
                isIntact = false
            }

            isIntact
        }
    }

    /**
     * يصدّر السجل الرقابي الكامل إلى ملف CSV بترميز UTF-8 BOM داخل context.cacheDir.
     */
    suspend fun exportLogsToCsvFile(context: Context): File = withContext(Dispatchers.IO) {
        synchronized(chainLock) {
            val auditFile = getAuditFile(context)
            val recordsNewestFirst = readAllRecordsChronologicalLocked(auditFile).asReversed()

            val exportDir = File(context.cacheDir, EXPORT_DIR_NAME).apply {
                if (!exists()) mkdirs()
            }
            val fileStamp = SimpleDateFormat(FILE_TIMESTAMP_PATTERN, Locale.US).format(Date())
            val outFile = File(exportDir, "audit_log_$fileStamp.csv")

            FileOutputStream(outFile, false).use { fos ->
                OutputStreamWriter(fos, Charsets.UTF_8).use { writer ->
                    writer.write(UTF8_BOM)
                    writer.write(
                        listOf(
                            "المعرف",
                            "التاريخ والوقت",
                            "نوع العملية",
                            "رقم الهدف (هوية/مشروع)",
                            "التفاصيل",
                            "المنفذ",
                            "بصمة السجل السابق (prevHash)",
                            "بصمة السجل الحالي (entryHash)"
                        ).joinToString(",") { escapeCsvField(it) }
                    )
                    writer.write("\r\n")

                    for (record in recordsNewestFirst) {
                        writer.write(
                            listOf(
                                record.id,
                                record.timestampText,
                                record.actionType,
                                record.targetId,
                                record.details,
                                record.performedBy,
                                record.prevHash,
                                record.entryHash
                            ).joinToString(",") { escapeCsvField(it) }
                        )
                        writer.write("\r\n")
                    }
                    writer.flush()
                }
            }

            outFile
        }
    }

    private fun getAuditFile(context: Context): File {
        return File(File(context.filesDir, AUDIT_DIR_NAME), AUDIT_FILE_NAME)
    }

    private fun readLastEntryHashLocked(auditFile: File): String {
        if (!auditFile.exists() || !auditFile.isFile || auditFile.length() == 0L) {
            return GENESIS_HASH
        }

        var lastNonEmptyLine: String? = null
        runCatching {
            auditFile.bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (rawLine in lines) {
                    val trimmed = rawLine.trim()
                    if (trimmed.isNotEmpty()) {
                        lastNonEmptyLine = trimmed
                    }
                }
            }
        }

        val lastLine = lastNonEmptyLine ?: return GENESIS_HASH
        val lastRecord = parseRecordFromJsonLine(lastLine)
        return lastRecord?.entryHash?.takeIf { it.isNotBlank() } ?: sha256Hex(lastLine)
    }

    private fun readAllRecordsChronologicalLocked(auditFile: File): List<AuditLogRecord> {
        if (!auditFile.exists() || !auditFile.isFile || auditFile.length() == 0L) {
            return emptyList()
        }

        val records = ArrayList<AuditLogRecord>()
        runCatching {
            auditFile.bufferedReader(Charsets.UTF_8).useLines { lines ->
                for (rawLine in lines) {
                    val line = rawLine.trim()
                    if (line.isEmpty()) continue
                    val record = parseRecordFromJsonLine(line)
                    if (record != null) {
                        records.add(record)
                    }
                }
            }
        }
        return records
    }

    private fun serializeRecordToJsonLine(record: AuditLogRecord): String {
        return JSONObject().apply {
            put(KEY_ID, record.id)
            put(KEY_TIMESTAMP, record.timestampText)
            put(KEY_ACTION_TYPE, record.actionType)
            put(KEY_TARGET_ID, record.targetId)
            put(KEY_DETAILS, record.details)
            put(KEY_PERFORMED_BY, record.performedBy)
            put(KEY_PREV_HASH, record.prevHash)
            put(KEY_ENTRY_HASH, record.entryHash)
        }.toString()
    }

    private fun parseRecordFromJsonLine(line: String): AuditLogRecord? {
        return runCatching {
            val obj = JSONObject(line)
            val id = obj.optString(KEY_ID, "")
            val timestampText = obj.optString(KEY_TIMESTAMP, "")
            val actionType = obj.optString(KEY_ACTION_TYPE, "")
            val targetId = obj.optString(KEY_TARGET_ID, "")
            val details = obj.optString(KEY_DETAILS, "")
            val performedBy = obj.optString(KEY_PERFORMED_BY, "")
            val prevHash = obj.optString(KEY_PREV_HASH, "")
            val entryHash = obj.optString(KEY_ENTRY_HASH, "")

            if (id.isBlank() || timestampText.isBlank() || prevHash.isBlank() || entryHash.isBlank()) {
                return@runCatching null
            }

            AuditLogRecord(
                id = id,
                timestampText = timestampText,
                actionType = actionType,
                targetId = targetId,
                details = details,
                performedBy = performedBy,
                prevHash = prevHash,
                entryHash = entryHash
            )
        }.getOrNull()
    }

    private fun computeEntryHash(
        id: String,
        timestampText: String,
        actionType: String,
        targetId: String,
        details: String,
        performedBy: String,
        prevHash: String
    ): String {
        val canonicalPayload = buildString {
            append(id).append('|')
            append(timestampText).append('|')
            append(actionType).append('|')
            append(targetId).append('|')
            append(details).append('|')
            append(performedBy).append('|')
            append(prevHash)
        }
        return sha256Hex(canonicalPayload)
    }

    private fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance(HASH_ALGORITHM)
            .digest(input.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(digest.size * 2)
        for (b in digest) {
            sb.append(String.format(Locale.US, "%02x", b))
        }
        return sb.toString()
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        return MessageDigest.isEqual(
            a.lowercase(Locale.US).toByteArray(Charsets.UTF_8),
            b.lowercase(Locale.US).toByteArray(Charsets.UTF_8)
        )
    }

    private fun escapeCsvField(raw: String): String {
        val needsQuoting = raw.contains(',') || raw.contains('"') || raw.contains('\n') || raw.contains('\r')
        if (!needsQuoting) return raw
        return "\"${raw.replace("\"", "\"\"")}\""
    }
}
