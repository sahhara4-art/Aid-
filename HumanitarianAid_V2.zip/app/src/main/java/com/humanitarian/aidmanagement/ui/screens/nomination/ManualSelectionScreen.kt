package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManualSelectionScreen(
    repository: AidRepository,
    aidTypeId: Int,
    projectId: Long,
    onNavigateBack: () -> Unit
) {
    var isLoading by remember { mutableStateOf(true) }
    var eligibleFamilies by remember { mutableStateOf<List<FamilyEntity>>(emptyList()) }
    var selectedLocalityId by remember { mutableStateOf<Int?>(null) } // null = كافة المحليات
    var localityDropdownExpanded by remember { mutableStateOf(false) }
    val selectedFamilyIds = remember { mutableStateListOf<Long>() }
    var searchQuery by remember { mutableStateOf("") }
    var isSaving by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val activeProject by produceState<ProjectEntity?>(initialValue = null, projectId) {
        value = repository.getProjectById(projectId)
    }

    // دالة إعادة تحميل الأسر المستحقة للمشروع مع استبعاد المستفيدين السابقين منه
    fun loadEligibleFamilies() {
        scope.launch {
            isLoading = true
            eligibleFamilies = repository.getEligibleFamiliesForManual(null, projectId)
            isLoading = false
        }
    }

    LaunchedEffect(projectId) {
        loadEligibleFamilies()
    }

    // آلية عمل الفلتر: تصفية الأسر وفق المحلية المحددة أو الكل، مع البحث النصي
    val filteredFamilies = remember(eligibleFamilies, selectedLocalityId, searchQuery) {
        eligibleFamilies
            .filter { fam ->
                selectedLocalityId == null || fam.localityID == selectedLocalityId
            }
            .filter { fam ->
                if (searchQuery.isBlank()) true
                else {
                    fam.name.contains(searchQuery, ignoreCase = true) ||
                    fam.nationalID.contains(searchQuery) ||
                    fam.primary_phone.contains(searchQuery) ||
                    fam.currentSubArea.contains(searchQuery, ignoreCase = true)
                }
            }
    }

    val selectedLocalityName = remember(selectedLocalityId, localities) {
        if (selectedLocalityId == null) "كافة المحليات (الكل)"
        else localities.find { it.LocalityID == selectedLocalityId }?.LocalityName ?: "محلية محددة"
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("شاشة الترشيح اليدوي", fontWeight = FontWeight.Bold)
                        val prjName = activeProject?.projectName ?: "المشروع #$projectId"
                        Text(
                            text = "مشروع: $prjName",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { loadEligibleFamilies() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث البيانات")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "المحدد: ${selectedFamilyIds.size} أسرة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "سيتم حصرهم واعتمادهم رسمياً كمرشحين للمشروع",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Button(
                        onClick = {
                            scope.launch {
                                isSaving = true
                                try {
                                    val count = repository.confirmManualNomination(
                                        familyIds = selectedFamilyIds.toList(),
                                        aidTypeId = aidTypeId,
                                        projectId = projectId,
                                        notes = "ترشيح يدوي معتمد للمشروع #$projectId"
                                    )
                                    selectedFamilyIds.clear()
                                    snackbarHostState.showSnackbar("تم اعتماد ترشيح $count أسرة بنجاح في قاعدة البيانات")
                                    // إعادة تحميل القائمة بعد الاستبعاد الصارم
                                    eligibleFamilies = repository.getEligibleFamiliesForManual(null, projectId)
                                } catch (e: Exception) {
                                    snackbarHostState.showSnackbar("خطأ أثناء الاعتماد: ${e.message}")
                                } finally {
                                    isSaving = false
                                }
                            }
                        },
                        enabled = selectedFamilyIds.isNotEmpty() && !isSaving,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                        } else {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اعتماد الترشيح", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // شريط فلتر المحليات والبحث
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // قائمة فلتر المحليات المنسدلة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "فلترة حسب المحلية:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold
                        )

                        Box {
                            OutlinedButton(
                                onClick = { localityDropdownExpanded = true },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(selectedLocalityName, maxLines = 1)
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                            }

                            DropdownMenu(
                                expanded = localityDropdownExpanded,
                                onDismissRequest = { localityDropdownExpanded = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("كافة المحليات (الكل)", fontWeight = if (selectedLocalityId == null) FontWeight.Bold else FontWeight.Normal) },
                                    leadingIcon = {
                                        if (selectedLocalityId == null) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                        }
                                    },
                                    onClick = {
                                        selectedLocalityId = null
                                        localityDropdownExpanded = false
                                    }
                                )
                                Divider()
                                localities.forEach { loc ->
                                    val isSelected = selectedLocalityId == loc.LocalityID
                                    DropdownMenuItem(
                                        text = { Text(loc.LocalityName, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                        leadingIcon = {
                                            if (isSelected) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            }
                                        },
                                        onClick = {
                                            selectedLocalityId = loc.LocalityID
                                            localityDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // حقل البحث
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("بحث بالاسم، رقم الهوية، أو المنطقة الفرعية...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "مسح")
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // شريط إحصائي وخيارات التحديد الجماعي
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "المستحقون: ${filteredFamilies.size} من إجمالي ${eligibleFamilies.size}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (filteredFamilies.isNotEmpty()) {
                        val allFilteredSelected = filteredFamilies.all { selectedFamilyIds.contains(it.familyID) }
                        TextButton(
                            onClick = {
                                if (allFilteredSelected) {
                                    filteredFamilies.forEach { selectedFamilyIds.remove(it.familyID) }
                                } else {
                                    filteredFamilies.forEach {
                                        if (!selectedFamilyIds.contains(it.familyID)) {
                                            selectedFamilyIds.add(it.familyID)
                                        }
                                    }
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(if (allFilteredSelected) "إلغاء تحديد المعروض" else "تحديد كافة المعروض (${filteredFamilies.size})")
                        }
                    }
                    if (selectedFamilyIds.isNotEmpty()) {
                        TextButton(
                            onClick = { selectedFamilyIds.clear() },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("تفريغ التحديد", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (isLoading) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("جاري استخراج الأسر المستحقة للمشروع ومنع التكرار...")
                    }
                }
            } else if (filteredFamilies.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier.padding(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (eligibleFamilies.isEmpty()) "لا توجد أسر غير مستفيدة مؤهلة حالياً لهذا المشروع" else "لا توجد نتائج مطابقة لفلتر البحث المحدد",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "تأكد من اختيار محلية أخرى أو إلغاء البحث النصي",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 20.dp)
                ) {
                    items(filteredFamilies, key = { it.familyID }) { family ->
                        val isChecked = selectedFamilyIds.contains(family.familyID)
                        val locName = localities.find { it.LocalityID == family.localityID }?.LocalityName ?: "المحلية #${family.localityID}"

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (isChecked) selectedFamilyIds.remove(family.familyID)
                                    else selectedFamilyIds.add(family.familyID)
                                },
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                                else MaterialTheme.colorScheme.surface
                            ),
                            border = if (isChecked) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary)
                            else BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        if (checked) selectedFamilyIds.add(family.familyID)
                                        else selectedFamilyIds.remove(family.familyID)
                                    }
                                )

                                Spacer(modifier = Modifier.width(8.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = family.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Surface(
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text(
                                                text = "${family.familyMembersCount} أفراد",
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))

                                    Text(
                                        text = "الهوية: ${family.nationalID} • $locName - ${family.currentSubArea}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                    )

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "• ${family.shelterStatus}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF0284C7)
                                        )
                                        Text(
                                            text = "• ${family.damageType}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFFD97706)
                                        )
                                        Text(
                                            text = "• ${family.developmentApproval}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF10B981)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
