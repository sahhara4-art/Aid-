package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.launch

// باليت الألوان الرسمية للترشيح المعتمد
private val BluePrimary = Color(0xFF1976D2)
private val EmeraldPrimary = Color(0xFF15803D)
private val AmberWarning = Color(0xFFD97706)
private val RedError = Color(0xFFDC2626)
private val Slate50 = Color(0xFFF8FAFC)
private val SlateBorder = Color(0xFFE2E8F0)
private val SlateTextMuted = Color(0xFF64748B)

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun ManualSelectionScreen(
    repository: AidRepository,
    aidTypeId: Int,
    projectId: Long,
    onNavigateBack: () -> Unit,
    nominationViewModel: NominationViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = NominationViewModel.Factory(repository)
    )
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // قراءة البيانات من ViewModel لضمان بقائها وعدم فقدانها (State Persistence)
    val filteredEligibleFamilies by nominationViewModel.filteredEligibleFamilies.collectAsState()
    val isFiltering by nominationViewModel.isFiltering.collectAsState()
    val dbLocalities by nominationViewModel.dbLocalities.collectAsState()

    val localitiesMap = remember(dbLocalities) {
        dbLocalities.associate { it.LocalityID to it.LocalityName }
    }

    val activeProject by produceState<ProjectEntity?>(initialValue = null, projectId) {
        value = repository.getProjectById(projectId)
    }

    var searchQuery by remember { mutableStateOf("") }
    val selectedFamilyIds = remember { mutableStateListOf<Long>() }
    var isSaving by remember { mutableStateOf(false) }

    // التأكد من تشغيل المحرك عند بدء الشاشة إذا كانت القائمة المؤهلة فارغة بعد
    LaunchedEffect(projectId) {
        if (filteredEligibleFamilies.isEmpty()) {
            nominationViewModel.selectedProjectId.value = projectId
            nominationViewModel.selectedAidTypeId.value = aidTypeId
            nominationViewModel.runFilteringEngine()
        }
    }

    // تصفية الأسر المعروضة بناءً على البحث النصي فقط ضمن الأسر التي اجتازت المحرك الصارم
    val displayedFamilies = remember(filteredEligibleFamilies, searchQuery) {
        if (searchQuery.isBlank()) {
            filteredEligibleFamilies
        } else {
            val q = searchQuery.trim().lowercase()
            filteredEligibleFamilies.filter { fam ->
                fam.name.lowercase().contains(q) ||
                fam.nationalID.contains(q) ||
                fam.primary_phone.contains(q) ||
                fam.currentSubArea.lowercase().contains(q) ||
                fam.currentMainArea.lowercase().contains(q)
            }
        }
    }

    // تجميع الأسر المؤهلة حسب المحليات الحية لإنشاء stickyHeaders
    val familiesGroupedByLocality = remember(displayedFamilies, localitiesMap) {
        displayedFamilies.groupBy { fam ->
            localitiesMap[fam.localityID] ?: fam.currentMainArea.ifBlank { "المحلية المعتمدة (#${fam.localityID})" }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Slate50,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    "شاشة الترشيح اليدوي الذكي",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = Color(0xFF0F172A)
                                )
                                Surface(
                                    color = Color(0xFFDCFCE7),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, Color(0xFF86EFAC))
                                ) {
                                    Text(
                                        text = "محرك صارم 100%",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldPrimary,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            val prjName = activeProject?.projectName ?: "المشروع #$projectId"
                            Text(
                                text = "مشروع: $prjName",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextMuted
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = {
                                nominationViewModel.runFilteringEngine()
                            }
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "تحديث الفلترة", tint = BluePrimary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.White,
                        titleContentColor = Color(0xFF0F172A)
                    )
                )
            },
            bottomBar = {
                Surface(
                    color = Color.White,
                    shadowElevation = 16.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "المحدد للاعتماد:",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SlateTextMuted
                                )
                                Text(
                                    text = "${selectedFamilyIds.size} أسرة",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = BluePrimary
                                )
                            }
                            Text(
                                text = "سيتم تسجيلهم واعتمادهم رسمياً كمرشحين للمشروع في قاعدة البيانات",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Button(
                            onClick = {
                                scope.launch {
                                    isSaving = true
                                    try {
                                        val count = repository.confirmManualNomination(
                                            familyIds = selectedFamilyIds.toList(),
                                            aidTypeId = aidTypeId,
                                            projectId = projectId,
                                            notes = "مرشح يدوياً عبر محرك الترشيح الذكي للمشروع #$projectId"
                                        )
                                        selectedFamilyIds.clear()
                                        snackbarHostState.showSnackbar("✓ تم اعتماد ترشيح $count أسرة بنجاح للمشروع")
                                        nominationViewModel.runFilteringEngine()
                                    } catch (e: Exception) {
                                        snackbarHostState.showSnackbar("خطأ أثناء الحفظ: ${e.message}")
                                    } finally {
                                        isSaving = false
                                    }
                                }
                            },
                            enabled = selectedFamilyIds.isNotEmpty() && !isSaving && (activeProject?.isLocked != true),
                            shape = RoundedCornerShape(16.dp),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeProject?.isLocked == true) Color(0xFF94A3B8) else EmeraldPrimary
                            )
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                            } else {
                                Icon(
                                    if (activeProject?.isLocked == true) Icons.Default.Lock else Icons.Default.CheckCircle,
                                    contentDescription = null
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    if (activeProject?.isLocked == true) "المشروع مقفل 🔒" else "اعتماد المرشحين (${selectedFamilyIds.size})",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(10.dp))

                // رسالة قفل المشروع إذا كان مقفلاً
                if (activeProject?.isLocked == true) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFFFEE2E2),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = RedError, modifier = Modifier.size(20.dp))
                            Text(
                                text = "تنبيه: هذا المشروع مقفل (🔒) ومغلق أمام أي ترشيح جديد. تم تعطيل اعتماد المرشحين.",
                                color = Color(0xFF991B1B),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // -------------------------------------------------------------
                // بطاقة الإحصاء الديناميكي والبحث الفوري (MISSION 3 & 4)
                // -------------------------------------------------------------
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // شريط العداد الإجمالي للمستحقين المطابقين للشروط
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(Color(0xFFEFF6FF), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.VerifiedUser,
                                        contentDescription = null,
                                        tint = BluePrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = "إجمالي المستحقين المطابقين للشروط:",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SlateTextMuted
                                    )
                                    Text(
                                        text = "${filteredEligibleFamilies.size} أسرة مؤهلة",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = BluePrimary
                                    )
                                }
                            }

                            // شارة الترتيب الإلزامي
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFF1F5F9),
                                border = BorderStroke(1.dp, Color(0xFFCBD5E1))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.Sort, contentDescription = null, tint = SlateTextMuted, modifier = Modifier.size(14.dp))
                                    Text("الأكبر حجماً أولاً", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // حقل البحث الحي
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("بحث بالاسم، رقم الهوية، أو المنطقة الفرعية...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = BluePrimary) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "مسح")
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = SlateBorder,
                                focusedContainerColor = Slate50,
                                unfocusedContainerColor = Slate50
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // أزرار التحكم الجماعي
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (searchQuery.isBlank()) "المعروض: ${displayedFamilies.size} أسرة"
                                else "نتائج البحث: ${displayedFamilies.size} من أصل ${filteredEligibleFamilies.size}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = SlateTextMuted
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (displayedFamilies.isNotEmpty()) {
                                    val allSelected = displayedFamilies.all { selectedFamilyIds.contains(it.familyID) }
                                    TextButton(
                                        onClick = {
                                            if (allSelected) {
                                                displayedFamilies.forEach { selectedFamilyIds.remove(it.familyID) }
                                            } else {
                                                displayedFamilies.forEach { fam ->
                                                    if (!selectedFamilyIds.contains(fam.familyID)) {
                                                        selectedFamilyIds.add(fam.familyID)
                                                    }
                                                }
                                            }
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            if (allSelected) "إلغاء تحديد الكل" else "تحديد كافة المعروض (${displayedFamilies.size})",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = BluePrimary
                                        )
                                    }
                                }
                                if (selectedFamilyIds.isNotEmpty()) {
                                    TextButton(
                                        onClick = { selectedFamilyIds.clear() },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text("تفريغ التحديد", fontSize = 11.sp, color = RedError, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // -------------------------------------------------------------
                // حالة التحميل أو القائمة الفارغة أو قائمة الأسر المجمعة
                // -------------------------------------------------------------
                if (isFiltering) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = BluePrimary)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "جاري تشغيل محرك الفلترة الصارم واستخراج المستحقين...",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF334155)
                            )
                        }
                    }
                } else if (displayedFamilies.isEmpty()) {
                    // الحالة الذكية عندما تكون النتيجة 0 (Smart Empty State)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, SlateBorder),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .background(Color(0xFFFEF2F2), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FilterListOff,
                                        contentDescription = null,
                                        tint = RedError,
                                        modifier = Modifier.size(40.dp)
                                    )
                                }

                                Text(
                                    text = "لا توجد أسر تطابق هذه الشروط الدقيقة",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )

                                Text(
                                    text = "لم تجتز أي أسرة قيود الأهلية الإلزامية (معتمد ومقيم، عدم التكرار، والنافذة الزمنية المحددة). جرب تعديل المعايير أو خفض فترة الاستثناء.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SlateTextMuted,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )

                                Button(
                                    onClick = {
                                        searchQuery = ""
                                        nominationViewModel.resetFilters()
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                                ) {
                                    Icon(Icons.Default.RestartAlt, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("إعادة ضبط الفلاتر وتوسيع النطاق", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    // -------------------------------------------------------------
                    // LazyColumn مع stickyHeader للمحليات الحية (MISSION 3 & 4)
                    // -------------------------------------------------------------
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        familiesGroupedByLocality.forEach { (localityName, familiesInLocality) ->
                            // ترويسة المحلية المثبتة في أعلى المجموعة (Sticky Header)
                            stickyHeader(key = "locality_header_$localityName") {
                                val allInLocalitySelected = familiesInLocality.isNotEmpty() &&
                                        familiesInLocality.all { selectedFamilyIds.contains(it.familyID) }

                                Surface(
                                    color = Color(0xFFF1F5F9),
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                    shadowElevation = 2.dp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.LocationOn,
                                                contentDescription = null,
                                                tint = BluePrimary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Text(
                                                text = localityName,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 14.sp,
                                                color = Color(0xFF0F172A)
                                            )
                                            Surface(
                                                color = BluePrimary.copy(alpha = 0.12f),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Text(
                                                    text = "${familiesInLocality.size} أسرة",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = BluePrimary,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                                )
                                            }
                                        }

                                        TextButton(
                                            onClick = {
                                                if (allInLocalitySelected) {
                                                    familiesInLocality.forEach { selectedFamilyIds.remove(it.familyID) }
                                                } else {
                                                    familiesInLocality.forEach { fam ->
                                                        if (!selectedFamilyIds.contains(fam.familyID)) {
                                                            selectedFamilyIds.add(fam.familyID)
                                                        }
                                                    }
                                                }
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = if (allInLocalitySelected) "إلغاء تحديد المحلية" else "تحديد كافة المحلية",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (allInLocalitySelected) RedError else EmeraldPrimary
                                            )
                                        }
                                    }
                                }
                            }

                            // بطاقات الأسر المؤهلة
                            items(familiesInLocality, key = { it.familyID }) { family ->
                                val isSelected = selectedFamilyIds.contains(family.familyID)
                                val cardElevation by animateDpAsState(
                                    targetValue = if (isSelected) 8.dp else 2.dp,
                                    label = "cardElevation"
                                )

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(24.dp))
                                        .clickable {
                                            if (isSelected) selectedFamilyIds.remove(family.familyID)
                                            else selectedFamilyIds.add(family.familyID)
                                        },
                                    shape = RoundedCornerShape(24.dp),
                                    elevation = CardDefaults.cardElevation(defaultElevation = cardElevation),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) Color(0xFFF0FDF4) else Color.White
                                    ),
                                    border = if (isSelected) BorderStroke(2.dp, EmeraldPrimary)
                                    else BorderStroke(1.dp, SlateBorder)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = isSelected,
                                            onCheckedChange = { checked ->
                                                if (checked) selectedFamilyIds.add(family.familyID)
                                                else selectedFamilyIds.remove(family.familyID)
                                            },
                                            colors = CheckboxDefaults.colors(
                                                checkedColor = EmeraldPrimary,
                                                checkmarkColor = Color.White
                                            )
                                        )

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = family.name,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF0F172A)
                                                )

                                                // شارة حجم الأسرة (المعيار الأساسي للترتيب)
                                                Surface(
                                                    color = if (isSelected) EmeraldPrimary else Color(0xFFEFF6FF),
                                                    shape = RoundedCornerShape(12.dp)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(
                                                            Icons.Default.Group,
                                                            contentDescription = null,
                                                            tint = if (isSelected) Color.White else BluePrimary,
                                                            modifier = Modifier.size(14.dp)
                                                        )
                                                        Text(
                                                            text = "${family.familyMembersCount} أفراد",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            color = if (isSelected) Color.White else BluePrimary
                                                        )
                                                    }
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(4.dp))

                                            Text(
                                                text = "الهوية: ${family.nationalID} • ${family.currentSubArea.ifBlank { family.currentMainArea }}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = SlateTextMuted
                                            )

                                            Spacer(modifier = Modifier.height(6.dp))

                                            // شارات معايير الأهلية المحققة
                                            Row(
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Surface(
                                                    color = Color(0xFFECFDF5),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Text(
                                                        text = "✓ ${family.socialAffairsStatus} ومقيم",
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = EmeraldPrimary,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }

                                                if (family.shelterStatus.isNotBlank()) {
                                                    Surface(
                                                        color = Color(0xFFF0F9FF),
                                                        shape = RoundedCornerShape(8.dp)
                                                    ) {
                                                        Text(
                                                            text = family.shelterStatus,
                                                            fontSize = 10.sp,
                                                            color = Color(0xFF0284C7),
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }

                                                if (family.damageType.isNotBlank()) {
                                                    Surface(
                                                        color = Color(0xFFFFFBEB),
                                                        shape = RoundedCornerShape(8.dp)
                                                    ) {
                                                        Text(
                                                            text = family.damageType,
                                                            fontSize = 10.sp,
                                                            color = AmberWarning,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
