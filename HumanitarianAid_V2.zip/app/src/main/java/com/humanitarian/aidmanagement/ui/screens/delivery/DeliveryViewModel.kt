package com.humanitarian.aidmanagement.ui.screens.delivery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.sync.SyncUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * حالة واجهة المستخدم لشاشة التسليم
 */
data class DeliveryUiState(
    val selectedProjectId: Long? = null,
    val searchQuery: String = "",
    val selectedStatusFilter: String = "الكل", // "الكل", "بانتظار التسليم", "تم التسليم", "تم التراجع عنه"
    val actionMessage: String? = null,
    val errorMessage: String? = null
)

/**
 * ViewModel لإدارة عمليات تسليم وصرف المساعدات والتراجع الرقابي الموثق
 */
class DeliveryViewModel(
    private val repository: AidRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DeliveryUiState())
    val uiState: StateFlow<DeliveryUiState> = _uiState.asStateFlow()

    val currentUser: StateFlow<UserEntity?> = repository.currentUserFlow

    /**
     * عزل وسكوب المساعدات بناءً على المشروع المختار (project_id)
     * لمنع تجميد التطبيق وتحميل 130 ألف سجل دفعة واحدة في الذاكرة
     */
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val rawAidRecords: StateFlow<List<AidRecordEntity>> = _uiState
        .map { it.selectedProjectId }
        .distinctUntilChanged()
        .flatMapLatest { prjId ->
            if (prjId != null && prjId > 0) {
                repository.getAidRecordsForProject(prjId)
            } else {
                flowOf(emptyList())
            }
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val projectFamilies: StateFlow<Map<Long, FamilyEntity>> = _uiState
        .map { it.selectedProjectId }
        .distinctUntilChanged()
        .flatMapLatest { prjId ->
            if (prjId != null && prjId > 0) {
                flow {
                    val fams = repository.getFamiliesForProject(prjId)
                    emit(fams.associateBy { it.familyID })
                }.flowOn(Dispatchers.IO)
            } else {
                flowOf(emptyMap())
            }
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val aidTypes: StateFlow<List<AidTypeEntity>> = repository.getActiveAidTypes()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val projects: StateFlow<List<ProjectEntity>> = repository.getActiveProjects()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val syncState: StateFlow<SyncUiState> = repository.getSyncState()

    fun selectProject(projectId: Long?) {
        _uiState.update { it.copy(selectedProjectId = projectId) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setStatusFilter(filter: String) {
        _uiState.update { it.copy(selectedStatusFilter = filter) }
    }

    fun clearActionMessage() {
        _uiState.update { it.copy(actionMessage = null, errorMessage = null) }
    }

    /**
     * تأكيد تسليم وصرف المساعدة مع التوثيق الآلي لتاريخ ووقت التسليم الفعلي
     * وحفظ ملاحظات التسليم واسم المستلم الفعلي وصفته
     */
    fun deliverAid(
        recordId: Long,
        recipientName: String,
        recipientRelation: String,
        deliveryNotes: String,
        citizenName: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                val cleanDeliveryNotes = deliveryNotes.trim()
                val fullNotes = buildString {
                    append("المستلم: $recipientName ($recipientRelation)")
                    if (cleanDeliveryNotes.isNotEmpty()) {
                        append(" | ملاحظات التسليم: $cleanDeliveryNotes")
                    }
                }
                repository.deliverAid(
                    recordId = recordId,
                    recipientName = recipientName,
                    notes = fullNotes,
                    deliveryDateTime = now
                )
                _uiState.update {
                    it.copy(
                        actionMessage = "تم تسليم وصرف المساعدة بنجاح للمواطن: $citizenName في $now",
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        errorMessage = e.message ?: "حدث خطأ أثناء تأكيد التسليم",
                        actionMessage = null
                    )
                }
            }
        }
    }

    /**
     * التراجع الصارم عن التسليم:
     * - إعادة حالة السجل recipientStatus إلى 'مرشح'
     * - إلغاء تاريخ التسليم الفعلي
     * - توثيق سبب التراجع الإلزامي في ملاحظات السجل وفي جدول سجلات التراجع
     */
    fun undoDelivery(
        recordId: Long,
        reason: String,
        citizenName: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cleanReason = reason.trim()
                require(cleanReason.isNotBlank()) { "سبب التراجع إلزامي للتوثيق والرقابة" }
                repository.undoDeliveryWithReason(recordId, cleanReason)
                _uiState.update {
                    it.copy(
                        actionMessage = "تم التراجع عن تسليم المساعدة للمواطن ($citizenName) وإرجاع الحالة إلى 'مرشح' بنجاح",
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        errorMessage = e.message ?: "حدث خطأ أثناء التراجع عن التسليم",
                        actionMessage = null
                    )
                }
            }
        }
    }

    fun deleteAidRecord(recordId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.deleteAidRecord(recordId)
                _uiState.update {
                    it.copy(
                        actionMessage = "تم حذف السجل بنجاح",
                        errorMessage = null
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        errorMessage = e.message ?: "حدث خطأ أثناء حذف السجل",
                        actionMessage = null
                    )
                }
            }
        }
    }

    fun isSuperAdmin(): Boolean = repository.isSuperAdmin()

    fun resetFilters() {
        _uiState.update { it.copy(searchQuery = "", selectedStatusFilter = "الكل", actionMessage = null, errorMessage = null) }
    }

    fun clearState() {
        _uiState.value = DeliveryUiState()
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(DeliveryViewModel::class.java)) {
                return DeliveryViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
