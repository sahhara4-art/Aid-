package com.humanitarian.aidmanagement.ui.screens.children

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.GlassButton
import com.humanitarian.aidmanagement.ui.components.GlassCard
import com.humanitarian.aidmanagement.ui.screens.families.GlassDropdownField
import com.humanitarian.aidmanagement.ui.screens.families.GlassOutlinedTextField
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.ExcelParserHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.Period
import java.util.Calendar
import java.util.Locale

/**
 * ViewModel لإدارة إضافة فرد أو ابن مرتبط تلقائياً برب الأسرة مع Dispatchers.IO
 */
class AddChildViewModel(
    private val repository: AidRepository,
    private val familyId: Long,
    private val familyNationalId: String
) : ViewModel() {

    data class State(
        val isSaving: Boolean = false,
        val saveSuccess: Boolean = false,
        val errorMessage: String? = null,
        val childNationalIdError: String? = null,
        val childNameError: String? = null,
        val familyName: String = ""
    )

    private val _state = MutableStateFlow(State())
    val state: StateFlow<State> = _state.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            val family = repository.getFamilyById(familyId).let { flow ->
                var found: com.humanitarian.aidmanagement.data.local.entities.FamilyEntity? = null
                try {
                    found = repository.getFamilyByNationalId(familyNationalId)
                } catch (_: Exception) {}
                found
            }
            if (family != null) {
                _state.update { it.copy(familyName = family.name) }
            }
        }
    }

    fun insertChild(
        childName: String,
        nationalId: String,
        birthDate: String,
        gender: String,
        shelterStatus: String,
        localityId: Int,
        onSuccess: () -> Unit
    ) {
        val cleanNationalId = ExcelParserHelper.normalizeNationalId(nationalId)
        if (cleanNationalId.length < 9) {
            _state.update { it.copy(childNationalIdError = "رقم هوية الابن/الفرد يجب أن يتكون من 9 أرقام") }
            return
        }

        if (childName.trim().length < 3) {
            _state.update { it.copy(childNameError = "يرجى كتابة اسم الابن أو الفرد") }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(isSaving = true, errorMessage = null, childNationalIdError = null, childNameError = null) }
            try {
                // فحص تكرار رقم هوية الطفل
                val existing = repository.getChildByNationalId(cleanNationalId)
                if (existing != null) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            childNationalIdError = "رقم هوية الابن مسجل مسبقاً بالنظام باسم: ${existing.childName}"
                        )
                    }
                    return@launch
                }

                val child = ChildEntity(
                    nationalID = cleanNationalId,
                    childName = childName.trim(),
                    birthDate = birthDate.trim(),
                    gender = gender,
                    familyNationalID = familyNationalId.trim(),
                    localityID = localityId,
                    shelterStatus = shelterStatus
                )

                repository.insertChild(child)

                // تحديث عدد أفراد الأسرة تلقائياً ليعكس الفرد الجديد
                val currentFamily = repository.getFamilyByNationalId(familyNationalId.trim())
                if (currentFamily != null) {
                    val updated = currentFamily.copy(familyMembersCount = currentFamily.familyMembersCount + 1)
                    repository.updateFamily(updated)
                }

                withContext(Dispatchers.Main) {
                    _state.update { it.copy(isSaving = false, saveSuccess = true) }
                    onSuccess()
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            errorMessage = t.localizedMessage ?: "حدث خطأ أثناء حفظ الابن في قاعدة البيانات"
                        )
                    }
                }
            }
        }
    }

    class Factory(
        private val repository: AidRepository,
        private val familyId: Long,
        private val familyNationalId: String
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AddChildViewModel(repository, familyId, familyNationalId) as T
        }
    }
}

/**
 * شاشة إضافة فرد / ابن ذكية تربط الطفل تلقائياً بالأسرة الحالية بالخلفية
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddChildScreen(
    familyId: Long,
    familyNationalId: String,
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    viewModel: AddChildViewModel = viewModel(
        factory = AddChildViewModel.Factory(repository, familyId, familyNationalId)
    )
) {
    val context = LocalContext.current
    val formState by viewModel.state.collectAsState()
    val scrollState = rememberScrollState()

    var childName by remember { mutableStateOf("") }
    var childNationalId by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("2018-01-01") }
    var gender by remember { mutableStateOf("ذكر") }
    var relation by remember { mutableStateOf("ابن/ابنة") }
    var shelterStatus by remember { mutableStateOf("إيواء داخلي") }

    // حساب العمر الذكي
    val ageText = remember(birthDate) {
        try {
            val parts = birthDate.trim().split("-")
            if (parts.size == 3) {
                val b = LocalDate.of(parts[0].toInt(), parts[1].toInt(), parts[2].toInt())
                Period.between(b, LocalDate.now()).years.coerceAtLeast(0).toString()
            } else "6"
        } catch (_: Exception) {
            "6"
        }
    }

    fun openDatePicker() {
        val calendar = Calendar.getInstance()
        val parts = birthDate.split("-")
        val initialYear = parts.getOrNull(0)?.toIntOrNull() ?: (calendar.get(Calendar.YEAR) - 6)
        val initialMonth = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val initialDay = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(
            context,
            { _, y, m, d ->
                birthDate = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
            },
            initialYear,
            initialMonth,
            initialDay
        ).show()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("إضافة فرد / ابن للأسرة", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = if (formState.familyName.isNotBlank()) "رب الأسرة: ${formState.familyName}" else "ربط ذكي تلقائي برقم هوية الأسرة",
                                style = MaterialTheme.typography.bodySmall,
                                color = PalestineGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SlateBackground)
                    .padding(paddingValues)
                    .verticalScroll(scrollState)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // لافتة الربط الذكي بالخلفية
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    surfaceColor = PalestineGreenContainer.copy(alpha = 0.5f),
                    borderColor = PalestineGreen.copy(alpha = 0.3f)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(PalestineGreen.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Link, contentDescription = null, tint = PalestineGreen)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "الربط التلقائي بالأسرة نشط",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = PalestineGreen
                            )
                            Text(
                                text = "سيتم ربط هذا الفرد مباشرة بالأسرة رقم ($familyNationalId) وتحديث عدد أفراد الأسرة تلقائياً.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextSecondary
                            )
                        }
                    }
                }

                // رسالة الخطأ إن وُجدت
                formState.errorMessage?.let { err ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.errorContainer,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Text(err, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                // بطاقة بيانات الابن / الفرد GlassCard
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "بيانات الفرد أو الابن",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = PalestineGreen
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // اسم الابن
                    GlassOutlinedTextField(
                        value = childName,
                        onValueChange = { childName = it },
                        label = "اسم الابن / الفرد *",
                        isError = formState.childNameError != null,
                        errorMessage = formState.childNameError,
                        leadingIcon = Icons.Default.Face
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // رقم هوية الابن
                    GlassOutlinedTextField(
                        value = childNationalId,
                        onValueChange = { childNationalId = ExcelParserHelper.convertEasternToArabicDigits(it).filter { c -> c.isDigit() }.take(9) },
                        label = "رقم هوية الابن (9 أرقام) *",
                        isError = formState.childNationalIdError != null,
                        errorMessage = formState.childNationalIdError,
                        keyboardType = KeyboardType.Number,
                        leadingIcon = Icons.Default.Badge
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // تاريخ الميلاد والعمر المحسوب ديناميكياً
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(modifier = Modifier.weight(0.65f)) {
                            GlassOutlinedTextField(
                                value = birthDate,
                                onValueChange = {},
                                label = "تاريخ الميلاد",
                                readOnly = true,
                                leadingIcon = Icons.Default.CalendarToday,
                                onClick = { openDatePicker() }
                            )
                        }
                        Box(modifier = Modifier.weight(0.35f)) {
                            GlassOutlinedTextField(
                                value = "$ageText سنة",
                                onValueChange = {},
                                label = "العمر",
                                readOnly = true,
                                leadingIcon = Icons.Default.Cake
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // الجنس وصفة القرابة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassDropdownField(
                            value = gender,
                            onValueChange = { gender = it },
                            label = "الجنس",
                            options = listOf("ذكر", "أنثى"),
                            modifier = Modifier.weight(1f)
                        )
                        GlassDropdownField(
                            value = relation,
                            onValueChange = { relation = it },
                            label = "صلة القرابة",
                            options = listOf("ابن/ابنة", "والد/والدة", "أخ/أخت", "حفيد", "مكفول/قريب"),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // حالة الإيواء
                    GlassDropdownField(
                        value = shelterStatus,
                        onValueChange = { shelterStatus = it },
                        label = "حالة الإيواء",
                        options = listOf("إيواء داخلي", "إيواء خارجي", "خيمة", "منزل مضيف", "بيت مستأجر")
                    )
                }

                // زر الحفظ الزجاجي GlassButton
                GlassButton(
                    onClick = {
                        viewModel.insertChild(
                            childName = childName,
                            nationalId = childNationalId,
                            birthDate = birthDate,
                            gender = gender,
                            shelterStatus = shelterStatus,
                            localityId = 1
                        ) {
                            Toast.makeText(context, "تمت إضافة الابن وربطه بالأسرة بنجاح!", Toast.LENGTH_SHORT).show()
                            onNavigateBack()
                        }
                    },
                    enabled = !formState.isSaving && childName.isNotBlank() && childNationalId.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    icon = Icons.Default.PersonAdd,
                    containerColor = PalestineGreen
                ) {
                    if (formState.isSaving) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جاري الحفظ والربط بقاعدة البيانات...", fontWeight = FontWeight.Bold)
                    } else {
                        Text("حفظ وربط الابن بالأسرة", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
