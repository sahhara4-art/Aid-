package com.humanitarian.aidmanagement.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.Selection
import com.humanitarian.aidmanagement.data.local.entities.User
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.CandidateEvaluation
import com.humanitarian.aidmanagement.engine.ChildrenNominationCriteria
import com.humanitarian.aidmanagement.engine.NominationEngine
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NominationScreen(
    database: AidDatabase,
    repository: AidRepository,
    engine: NominationEngine,
    currentUser: User,
    isSuperAdmin: Boolean,
    allowedLocalityIds: List<Int>,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val aidTypes by repository.getAidTypes().collectAsState(initial = emptyList())
    val projects by repository.getProjects().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())

    var selectedAidTypeId by remember { mutableStateOf(1) }
    var selectedProjectId by remember { mutableStateOf(1) }
    var selectedLocalityId by remember { mutableStateOf<Int?>(null) }
    var quotaInput by remember { mutableStateOf("10") }

    var evaluatedCandidates by remember { mutableStateOf<List<CandidateEvaluation>>(emptyList()) }
    var isEvaluating by remember { mutableStateOf(false) }

    val currentSelections by database.selectionDao().getSelections(
        isSuperAdmin,
        allowedLocalityIds,
        selectedAidTypeId,
        selectedProjectId
    ).collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ترشيح المساعدات الإنسانية", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "القائمة")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Nomination Setup Form
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("إعدادات جلسة الترشيح", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2), fontSize = 16.sp)
                        Spacer(Modifier.height(12.dp))

                        // Aid Type Selector
                        Text("نوع المساعدة:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Row(modifier = Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            aidTypes.take(3).forEach { t ->
                                FilterChip(
                                    selected = selectedAidTypeId == t.aidTypeID,
                                    onClick = { selectedAidTypeId = t.aidTypeID },
                                    label = { Text(t.aidTypeName) }
                                )
                            }
                        }

                        // Project & Locality
                        Text("المحلية المستهدفة:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                        Row(modifier = Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(
                                selected = selectedLocalityId == null,
                                onClick = { selectedLocalityId = null },
                                label = { Text("كل المحليات المسموحة") }
                            )
                            localities.take(3).forEach { loc ->
                                if (isSuperAdmin || allowedLocalityIds.contains(loc.localityId)) {
                                    FilterChip(
                                        selected = selectedLocalityId == loc.localityId,
                                        onClick = { selectedLocalityId = loc.localityId },
                                        label = { Text(loc.localityName) }
                                    )
                                }
                            }
                        }

                        // Required Quota Count
                        OutlinedTextField(
                            value = quotaInput,
                            onValueChange = { quotaInput = it },
                            label = { Text("العدد المطلوب ترشيحه (الحصة)") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(Modifier.height(8.dp))

                        // Nomination Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    isEvaluating = true
                                    scope.launch {
                                        try {
                                            val count = quotaInput.toIntOrNull() ?: 10
                                            val results = engine.runAutoNomination(
                                                localityId = selectedLocalityId,
                                                aidTypeId = selectedAidTypeId,
                                                projectId = selectedProjectId,
                                                requiredCount = count,
                                                isSuperAdmin = isSuperAdmin,
                                                allowedLocalityIds = allowedLocalityIds,
                                                userId = currentUser.userId
                                            )
                                            evaluatedCandidates = results

                                            // Save eligible candidates to Selections
                                            val eligibleToSave = results.filter { it.isEligible }.take(count).map {
                                                Selection(
                                                    familyID = it.family.familyID,
                                                    nationalID = it.family.nationalID,
                                                    aidTypeID = selectedAidTypeId,
                                                    projectID = selectedProjectId,
                                                    selectionType = "آلي",
                                                    localityID = it.family.localityID,
                                                    selectedBy = currentUser.userId
                                                )
                                            }
                                            database.selectionDao().insertSelections(eligibleToSave)
                                            Toast.makeText(context, "تم تنفيذ الترشيح الآلي (${eligibleToSave.size} مرشح)", Toast.LENGTH_SHORT).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, e.message ?: "خطأ", Toast.LENGTH_LONG).show()
                                        } finally {
                                            isEvaluating = false
                                        }
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("ترشيح آلي")
                            }

                            Button(
                                onClick = {
                                    isEvaluating = true
                                    scope.launch {
                                        val results = engine.runChildrenBasedNomination(
                                            localityId = selectedLocalityId,
                                            aidTypeId = selectedAidTypeId,
                                            projectId = selectedProjectId,
                                            criteria = ChildrenNominationCriteria(minChildrenCount = 2, maxAgeInYears = 18),
                                            isSuperAdmin = isSuperAdmin,
                                            allowedLocalityIds = allowedLocalityIds
                                        )
                                        evaluatedCandidates = results
                                        isEvaluating = false
                                        Toast.makeText(context, "تم الفرز حسب الأبناء", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("حسب الأبناء")
                            }
                        }
                    }
                }
            }

            // Migration Button ("ترحيل المرشحين")
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("ترحيل المرشحين إلى سجلات الاستلام", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32), fontSize = 14.sp)
                            Text("المرشحون الحاليون: ${currentSelections.size} أسرة", fontSize = 12.sp, color = Color(0xFF475569))
                        }
                        Button(
                            onClick = {
                                if (currentSelections.isEmpty()) {
                                    Toast.makeText(context, "لا يوجد مرشحون حاليون للترحيل", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                scope.launch {
                                    engine.migrateSelectionsToAidRecords(
                                        selections = currentSelections,
                                        warehouse = "المستودع المركزي",
                                        aidValue = 60.0,
                                        currentUserId = currentUser.userId
                                    )
                                    Toast.makeText(context, "تم ترحيل جميع المرشحين إلى سجلات المساعدات بنجاح!", Toast.LENGTH_LONG).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("ترحيل المرشحين")
                        }
                    }
                }
            }

            // Results of Candidate Evaluation with Rejection Reasons
            if (evaluatedCandidates.isNotEmpty()) {
                item {
                    Text("نتائج فحص الأسر واستبعاد التكرار (${evaluatedCandidates.size}):", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                items(evaluatedCandidates) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = if (item.isEligible) Color.White else Color(0xFFFEF2F2)),
                        elevation = CardDefaults.cardElevation(1.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(item.family.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                if (item.isEligible) {
                                    Surface(color = Color(0xFFDCFCE7), shape = RoundedCornerShape(6.dp)) {
                                        Text("مؤهل للترشيح", color = Color(0xFF16A34A), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                                    }
                                } else {
                                    Surface(color = Color(0xFFFEE2E2), shape = RoundedCornerShape(6.dp)) {
                                        Text("مستبعد", color = Color(0xFFDC2626), fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                                    }
                                }
                            }
                            Text("الهوية: ${item.family.nationalID} | الأفراد: ${item.family.familyMembersCount}", fontSize = 12.sp, color = Color(0xFF475569))
                            if (!item.isEligible && item.rejectionReason != null) {
                                Text("سبب الاستبعاد: ${item.rejectionReason}", color = Color(0xFFB91C1C), fontSize = 11.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 2.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
