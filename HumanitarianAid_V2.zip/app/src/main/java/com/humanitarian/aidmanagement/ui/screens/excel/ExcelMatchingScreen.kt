package com.humanitarian.aidmanagement.ui.screens.excel

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.humanitarian.aidmanagement.data.local.dao.FamilyWithLatestAid
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.util.ExcelVerificationHelper
import com.humanitarian.aidmanagement.util.VerificationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * شاشة مطابقة وتدقيق الإكسل المستقلة (ExcelMatchingScreen)
 * تتيح رفع كشوفات الهويات بصيغة Excel ومطابقتها ثلاثياً مع قاعدة البيانات وتصدير التقرير المعتمد.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExcelMatchingScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isProcessing by remember { mutableStateOf(false) }
    var processingStatus by remember { mutableStateOf("") }
    var verificationResult by remember { mutableStateOf<VerificationResult?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0 = مطابق, 1 = غير مطابق, 2 = غير مسجل

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                isProcessing = true
                errorMessage = null
                processingStatus = "جاري فتح الملف واستخراج أرقام الهويات..."

                val ids = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        ExcelVerificationHelper.extractNationalIds(stream)
                    } ?: emptyList()
                }

                if (ids.isEmpty()) {
                    errorMessage = "لم يتم العثور على أي أرقام هويات صالحة في الملف المحدد."
                    isProcessing = false
                    return@launch
                }

                processingStatus = "تم استخراج ${ids.size} هوية. جاري الفحص والمطابقة مع قاعدة البيانات..."
                val result = ExcelVerificationHelper.verifyNationalIds(repository, ids)

                verificationResult = result
                isProcessing = false
            } catch (e: Exception) {
                errorMessage = "حدث خطأ أثناء فحص الملف: ${e.localizedMessage ?: e.message}"
                isProcessing = false
            }
        }
    }

    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri: Uri? ->
        val currentResult = verificationResult ?: return@rememberLauncherForActivityResult
        if (uri == null) return@rememberLauncherForActivityResult

        scope.launch {
            try {
                isProcessing = true
                processingStatus = "جاري إنشاء المصنف وتصدير الأوراق الثلاث بصيغة XLSX..."

                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { outStream ->
                        ExcelVerificationHelper.generateVerificationWorkbook(currentResult, outStream)
                    }
                }

                isProcessing = false
                Toast.makeText(context, "تم تصدير تقرير المطابقة الثلاثي بنجاح!", Toast.LENGTH_LONG).show()
            } catch (t: Throwable) {
                errorMessage = "فشل تصدير الملف: ${t.localizedMessage ?: t.message ?: "خطأ غير متوقع"}"
                isProcessing = false
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "مطابقة وتدقيق الإكسل",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "فحص كشوفات الهويات والتصدير الثلاثي المعتمد",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp)
            ) {
                errorMessage?.let { err ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Text(
                                text = err,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                if (isProcessing) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(24.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(54.dp),
                                color = Color(0xFF107C41),
                                strokeWidth = 4.dp
                            )
                            Text(
                                text = processingStatus,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "تتم المعالجة بنظام الدفعات الآمن لمنع استهلاك الذاكرة وحماية استقرار التطبيق",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else if (verificationResult == null) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(92.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFEAB308).copy(alpha = 0.14f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FactCheck,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = Color(0xFFEAB308)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "اختر ملف إكسل يحتوي على أرقام الهويات الوطنية",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "سيقوم النظام تلقائياً باستخراج الهويات ومطابقتها مع قاعدة البيانات، وحساب سجل المساعدات الأخير، وتصنيف المستفيدين بدقة إلى ثلاثة مسارات.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )
                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = {
                                openDocumentLauncher.launch(
                                    arrayOf(
                                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                        "application/vnd.ms-excel",
                                        "application/octet-stream",
                                        "*/*"
                                    )
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                            contentPadding = PaddingValues(horizontal = 24.dp, vertical = 14.dp)
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("اختيار كشف الإكسل (.xlsx / .xls)", fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    val res = verificationResult!!
                    val summary = res.summary

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MatchingStatCard("إجمالي المفحوصين", summary.totalInputIds, MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                        MatchingStatCard("مطابق للشروط", summary.eligibleCount, Color(0xFF107C41), Modifier.weight(1f))
                        MatchingStatCard("غير مطابق", summary.ineligibleCount, Color(0xFFD97706), Modifier.weight(1f))
                        MatchingStatCard("غير مسجل", summary.notRegisteredCount, Color(0xFFE11D48), Modifier.weight(1f))
                    }

                    if (summary.outOfScopeCount > 0) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFFF59E0B).copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.45f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.GppMaybe, contentDescription = null, tint = Color(0xFFB45309), modifier = Modifier.size(20.dp))
                                Text(
                                    text = "تم حجب ${summary.outOfScopeCount} سجل لأنها تتبع لمحليات أو شعب خارج نطاق صلاحياتك الجغرافية (RLS).",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF92400E)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.clip(RoundedCornerShape(12.dp))
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = {
                                Text(
                                    "مطابق للشروط (${summary.eligibleCount})",
                                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == 0) Color(0xFF107C41) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = {
                                Text(
                                    "غير مطابق (${summary.ineligibleCount})",
                                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == 1) Color(0xFFD97706) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        )
                        Tab(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            text = {
                                Text(
                                    "غير مسجل (${summary.notRegisteredCount})",
                                    fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == 2) Color(0xFFE11D48) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                            .padding(8.dp)
                    ) {
                        when (selectedTab) {
                            0 -> {
                                if (res.eligibleMatched.isEmpty()) {
                                    MatchingEmptyPlaceholder("لا توجد أسر مطابقة للشروط في هذا الكشف")
                                } else {
                                    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        items(res.eligibleMatched) { item ->
                                            MatchingFamilyRow(item, isEligible = true)
                                        }
                                    }
                                }
                            }
                            1 -> {
                                if (res.ineligibleMatched.isEmpty()) {
                                    MatchingEmptyPlaceholder("لا توجد أسر غير مطابقة للشروط")
                                } else {
                                    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        items(res.ineligibleMatched) { item ->
                                            MatchingFamilyRow(item, isEligible = false)
                                        }
                                    }
                                }
                            }
                            2 -> {
                                if (res.notRegisteredIds.isEmpty()) {
                                    MatchingEmptyPlaceholder("جميع أرقام الهويات مسجلة في النظام")
                                } else {
                                    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        items(res.notRegisteredIds) { id ->
                                            MatchingNotRegisteredRow(id)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                verificationResult = null
                                errorMessage = null
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("فحص كشف آخر")
                        }

                        Button(
                            onClick = {
                                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
                                val filename = "تقرير_مطابقة_الهويات_الثلاثي_$timestamp.xlsx"
                                createDocumentLauncher.launch(filename)
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                            modifier = Modifier.weight(1.5f)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير التقرير الثلاثي (Excel)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MatchingStatCard(title: String, count: Int, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = count.toString(), fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium, color = color)
            Text(text = title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun MatchingFamilyRow(item: FamilyWithLatestAid, isEligible: Boolean) {
    val f = item.family
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isEligible) Color(0xFF107C41).copy(alpha = 0.05f) else Color(0xFFD97706).copy(alpha = 0.05f)
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Text(text = f.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    text = "هوية: ${f.nationalID} • ${f.maritalStatus} • ${f.residentStatus} • ${f.developmentApproval}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                )
            }
            Column(modifier = Modifier.weight(0.8f), horizontalAlignment = Alignment.End) {
                Text(
                    text = if (item.totalAidsCount > 0) "${item.totalAidsCount} مساعدات سابقة" else "لا توجد مساعدات",
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (item.totalAidsCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                item.lastAidDate?.let { date ->
                    Text(text = "آخر مساعدة: $date", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            }
        }
    }
}

@Composable
private fun MatchingNotRegisteredRow(nationalId: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE11D48).copy(alpha = 0.05f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.PersonOff, contentDescription = null, tint = Color(0xFFE11D48), modifier = Modifier.size(20.dp))
                Text(text = "رقم الهوية: $nationalId", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            }
            Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFE11D48).copy(alpha = 0.15f)) {
                Text(
                    text = "غير مسجل في النظام",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE11D48),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun MatchingEmptyPlaceholder(message: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            textAlign = TextAlign.Center
        )
    }
}
