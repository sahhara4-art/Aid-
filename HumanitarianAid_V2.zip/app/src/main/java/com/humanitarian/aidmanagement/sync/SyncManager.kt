package com.humanitarian.aidmanagement.sync

import android.content.Context
import androidx.work.*
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.SyncLogEntity
import com.humanitarian.aidmanagement.data.local.entities.SyncQueueEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.TimeUnit

data class SyncUiState(
    val isOnline: Boolean = true,
    val isSyncing: Boolean = false,
    val pendingCount: Int = 0,
    val lastSyncTime: Long? = null,
    val lastSyncStatus: String? = null,
    val isSimulatedOffline: Boolean = false
)

object SyncManager {
    private var appContext: Context? = null
    private var database: AidDatabase? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _syncState = MutableStateFlow(SyncUiState())
    val syncState: StateFlow<SyncUiState> = _syncState.asStateFlow()

    private var connectivityObserver: NetworkConnectivityObserver? = null
    private var wasOffline = false

    fun initialize(context: Context, db: AidDatabase) {
        this.appContext = context.applicationContext
        this.database = db

        connectivityObserver = NetworkConnectivityObserver(context)

        // 1. مراقبة التغيرات في عدد السجلات المعلقة في قاعدة بيانات Room
        scope.launch {
            db.syncQueueDao().getPendingCountFlow().collect { count ->
                _syncState.update { it.copy(pendingCount = count) }
            }
        }

        // 2. قراءة آخر عملية مزامنة من جدول السجلات
        scope.launch {
            val lastLog = db.syncQueueDao().getLastSyncLog()
            if (lastLog != null) {
                _syncState.update {
                    it.copy(
                        lastSyncTime = lastLog.timestamp,
                        lastSyncStatus = lastLog.summary
                    )
                }
            }
        }

        // 3. مراقبة الاتصال بالإنترنت وتطبيق التزامن التلقائي الفوري فور استعادة الاتصال
        scope.launch {
            connectivityObserver?.observe()?.collect { status ->
                val realOnline = status == NetworkStatus.Available
                val effectiveOnline = realOnline && !_syncState.value.isSimulatedOffline

                val previouslyOffline = wasOffline
                wasOffline = !effectiveOnline

                _syncState.update { it.copy(isOnline = effectiveOnline) }

                // إذا كان الجهاز غير متصل ثم عادت الشبكة، نفذ التزامن التلقائي فوراً
                if (previouslyOffline && effectiveOnline) {
                    triggerImmediateSync("AUTO_RECONNECT")
                }
            }
        }

        // 4. جدولة فحص التزامن الخلفي الدوري عبر WorkManager عند توفر الاتصال
        schedulePeriodicSync(context)
    }

    private fun schedulePeriodicSync(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val periodicWork = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "AidSystemPeriodicSync",
            ExistingPeriodicWorkPolicy.KEEP,
            periodicWork
        )
    }

    /**
     * إدراج عملية جديدة في طابور التزامن في Room DB
     */
    suspend fun enqueueItem(
        entityType: String,
        operation: String,
        recordId: String,
        payloadJson: String
    ): Long {
        val db = database ?: return -1L
        val item = SyncQueueEntity(
            entityType = entityType,
            operation = operation,
            recordId = recordId,
            payloadJson = payloadJson,
            createdAt = System.currentTimeMillis(),
            status = "PENDING"
        )
        val id = db.syncQueueDao().enqueue(item)

        // إذا كان الجهاز متصلاً حالياً، يتم إطلاق المزامنة التلقائية فوراً
        if (_syncState.value.isOnline && !_syncState.value.isSimulatedOffline) {
            scope.launch {
                triggerImmediateSync("AUTO_INSTANT")
            }
        }

        return id
    }

    /**
     * تشغيل المزامنة الفورية لكافة العناصر المعلقة في Room DB
     */
    fun triggerImmediateSync(reason: String = "MANUAL") {
        val db = database ?: return
        if (_syncState.value.isSyncing) return

        scope.launch {
            _syncState.update { it.copy(isSyncing = true) }

            val syncDao = db.syncQueueDao()
            val pendingItems = syncDao.getPendingSyncItems()

            if (pendingItems.isEmpty()) {
                _syncState.update { it.copy(isSyncing = false) }
                return@launch
            }

            var succeeded = 0
            var failed = 0

            for (item in pendingItems) {
                try {
                    syncDao.markAsSyncing(item.syncId)
                    delay(80) // محاكاة زمن الاستجابة السحابية
                    syncDao.markAsSynced(item.syncId)
                    succeeded++
                } catch (e: Exception) {
                    syncDao.markAsFailed(item.syncId, e.message ?: "خطأ أثناء الاتصال")
                    failed++
                }
            }

            // تنظيف العمليات المتزامنة بنجاح
            syncDao.clearSynced()

            val now = System.currentTimeMillis()
            val status = if (failed == 0) "SUCCESS" else if (succeeded > 0) "PARTIAL" else "FAILED"
            val summary = "تمت مزامنة $succeeded عملية بنجاح، وفشل $failed عمليات (السبب: $reason)"

            val log = SyncLogEntity(
                syncType = reason,
                itemsProcessed = pendingItems.size,
                itemsSucceeded = succeeded,
                itemsFailed = failed,
                status = status,
                summary = summary,
                timestamp = now
            )
            syncDao.insertSyncLog(log)

            _syncState.update {
                it.copy(
                    isSyncing = false,
                    lastSyncTime = now,
                    lastSyncStatus = summary
                )
            }
        }
    }

    /**
     * تفعيل أو إيقاف وضع عدم الاتصال التجريبي لمحاكاة انقطاع وعودة الإنترنت
     */
    fun toggleSimulatedOffline() {
        val newSimulatedState = !_syncState.value.isSimulatedOffline
        val realOnline = connectivityObserver?.isCurrentlyOnline() ?: true
        val effectiveOnline = realOnline && !newSimulatedState

        val wasOff = !_syncState.value.isOnline
        _syncState.update {
            it.copy(
                isSimulatedOffline = newSimulatedState,
                isOnline = effectiveOnline
            )
        }

        // إذا تم إلغاء وضع عدم الاتصال وأصبح الجهاز أونلاين، نقوم بالمزامنة التلقائية فوراً
        if (wasOff && effectiveOnline) {
            triggerImmediateSync("AUTO_RECONNECT_SIMULATED")
        }
    }
}
