package com.humanitarian.aidmanagement.sync

import android.content.Context
import android.util.Log
import com.humanitarian.aidmanagement.AidApplication
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.SyncLogEntity
import com.humanitarian.aidmanagement.data.local.entities.SyncQueueEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

enum class SyncConnectionStatus(val label: String) {
    ONLINE("متصل بالسحابة"),
    SYNCING("جاري التزامن..."),
    OFFLINE("غير متصل (محلي)")
}

data class SyncUiState(
    val connectionStatus: SyncConnectionStatus = SyncConnectionStatus.ONLINE,
    val isOnline: Boolean = true,
    val isSyncing: Boolean = false,
    val isMasterConnected: Boolean = true,
    val isListening: Boolean = true,
    val pendingCount: Int = 0,
    val totalUploaded: Int = 0,
    val totalMerged: Int = 0,
    val adminOverridesCount: Int = 0,
    val lastSyncTime: Long? = null,
    val lastSyncStatus: String? = null,
    val lastSyncError: String? = null,
    val lastMergedDelta: FirestoreSyncDelta? = null,
    val recentDeltas: List<FirestoreSyncDelta> = emptyList(),
    // توافق مع الكود السابق
    val isSimulatedOffline: Boolean = false,
    val firebaseConnected: Boolean = true,
    val isMasterListenerActive: Boolean = true,
    val totalDeltasUploaded: Int = 0,
    val totalDeltasMerged: Int = 0
)

/**
 * SyncManager - المنسق العام لمنظومة التزامن السحابي المركزي اللحظي (MVI Pattern)
 */
object SyncManager {
    private const val TAG = "SyncManager"

    @Volatile
    private var isInitialized = false

    @Volatile
    private var appContext: Context? = null

    @Volatile
    private var database: AidDatabase? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val flushMutex = Mutex()

    private val _syncState = MutableStateFlow(SyncUiState())
    val syncState: StateFlow<SyncUiState> = _syncState.asStateFlow()

    private var connectivityObserver: NetworkConnectivityObserver? = null
    private var firestoreSyncManager: FirestoreSyncManager? = null

    fun initialize(context: Context, db: AidDatabase) {
        synchronized(this) {
            if (isInitialized && appContext != null && database != null) {
                return
            }
            this.appContext = context.applicationContext
            this.database = db

            // 1. تهيئة مراقب الشبكة
            connectivityObserver = NetworkConnectivityObserver(this.appContext!!)

            // 2. تهيئة محرك Firestore
            val fsManager = FirestoreSyncManager.getInstance(this.appContext!!)
            this.firestoreSyncManager = fsManager
            fsManager.initialize()

            isInitialized = true
        }

        val safeContext = appContext ?: return
        val fsManager = firestoreSyncManager ?: return

        // 3. بدء جدولة WorkManager الخلفية مع قيود الشبكة
        try {
            FirestoreSyncWorker.schedulePeriodicSync(safeContext)
        } catch (e: Throwable) {
            Log.w(TAG, "WorkManager schedule warning: ${e.message}")
        }

        // 4. مراقبة طابور السجلات المعلقة في Room
        scope.launch {
            db.syncQueueDao().getPendingCountFlow().collect { count ->
                _syncState.update { current ->
                    current.copy(
                        pendingCount = count,
                        connectionStatus = if (!current.isOnline) SyncConnectionStatus.OFFLINE
                        else if (current.isSyncing) SyncConnectionStatus.SYNCING
                        else SyncConnectionStatus.ONLINE
                    )
                }
            }
        }

        // 5. مراقبة سجلات المزامنة التاريخية
        scope.launch {
            val lastLog = db.syncQueueDao().getLastSyncLog()
            if (lastLog != null) {
                _syncState.update {
                    it.copy(
                        lastSyncTime = lastLog.timestamp,
                        lastSyncStatus = lastLog.summary
                    )
                }
            }
        }

        // 6. مراقبة حالة اتصال الشبكة الفعلية
        scope.launch {
            connectivityObserver?.observe()?.collect { status ->
                val online = status == NetworkStatus.Available && !_syncState.value.isSimulatedOffline
                _syncState.update { current ->
                    current.copy(
                        isOnline = online,
                        connectionStatus = if (!online) SyncConnectionStatus.OFFLINE
                        else if (current.isSyncing) SyncConnectionStatus.SYNCING
                        else SyncConnectionStatus.ONLINE
                    )
                }

                if (online) {
                    Log.i(TAG, "Network connection restored. Flushing pending Firestore queue...")
                    fsManager.startRealtimeListener(db, resolveCurrentUserLocalityScope())
                    flushPendingQueueInternal()
                    try {
                        FirestoreSyncWorker.triggerImmediateSync(safeContext)
                    } catch (_: Throwable) {}
                }
            }
        }

        // 7. مراقبة اتصال Firestore ومستمعات اللحظية والأخطاء
        scope.launch {
            fsManager.isConnected.collect { connected ->
                _syncState.update { current ->
                    current.copy(
                        isMasterConnected = connected,
                        firebaseConnected = connected
                    )
                }
            }
        }

        scope.launch {
            fsManager.isListening.collect { listening ->
                _syncState.update { it.copy(isListening = listening, isMasterListenerActive = listening) }
            }
        }

        scope.launch {
            fsManager.totalUploadedCount.collect { count ->
                _syncState.update { it.copy(totalUploaded = count, totalDeltasUploaded = count) }
            }
        }

        scope.launch {
            fsManager.totalMergedCount.collect { count ->
                _syncState.update { it.copy(totalMerged = count, totalDeltasMerged = count) }
            }
        }

        scope.launch {
            fsManager.adminOverridesCount.collect { count ->
                _syncState.update { it.copy(adminOverridesCount = count) }
            }
        }

        scope.launch {
            fsManager.lastMergedDelta.collect { delta ->
                _syncState.update { it.copy(lastMergedDelta = delta) }
            }
        }

        scope.launch {
            fsManager.recentDeltas.collect { deltas ->
                _syncState.update { it.copy(recentDeltas = deltas) }
            }
        }

        scope.launch {
            fsManager.lastSyncError.collect { err ->
                _syncState.update { it.copy(lastSyncError = err) }
            }
        }

        // تشغيل مستمع المزامنة الحية وتفريغ أي حركات معلقة فور التهيئة
        scope.launch {
            fsManager.ensureAuthenticated()
            fsManager.startRealtimeListener(db, resolveCurrentUserLocalityScope())
            flushPendingQueueInternal()
        }
        Log.i(TAG, "SyncManager initialized with Google Cloud Firestore Master Node.")
    }

    private fun ensureInitialized() {
        if (isInitialized && database != null && appContext != null) return
        try {
            val app = AidApplication.getInstanceSafely() ?: AidApplication.instance
            initialize(app, app.database)
        } catch (e: Throwable) {
            Log.e(TAG, "Lazy SyncManager initialization failed: ${e.message}", e)
        }
    }

    private fun resolveCurrentUserLocalityScope(): Int {
        return try {
            val user = AidApplication.getInstanceSafely()?.repository?.getCurrentUser()
            if (user == null || user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true)) 0
            else user.AllowedLocalityID
        } catch (_: Throwable) {
            0
        }
    }

    /**
     * تشغيل مستمع المزامنة اللحظية بحسب الصلاحية والمحلية
     */
    fun startRealtimeSync(userLocalityId: Int = 0) {
        scope.launch {
            ensureInitialized()
            val db = database ?: return@launch
            firestoreSyncManager?.startRealtimeListener(db, userLocalityId)
        }
    }

    /**
     * إدراج حركة تعديل في طابور التزامن ومحاولة رفعها فورياً إلى Firestore على Dispatchers.IO
     */
    fun pushChange(
        entityType: String,
        operation: String,
        recordId: String,
        payloadJson: String
    ) {
        scope.launch {
            ensureInitialized()
            val db = database ?: return@launch
            val context = appContext ?: return@launch
            val fsManager = firestoreSyncManager ?: FirestoreSyncManager.getInstance(context).also {
                firestoreSyncManager = it
                it.initialize()
            }

            val syncQueueEntity = SyncQueueEntity(
                entityType = entityType,
                operation = operation,
                recordId = recordId,
                payloadJson = payloadJson,
                createdAt = System.currentTimeMillis(),
                status = "PENDING"
            )

            // 1. الحفظ أولاً في جدول Room DB محلياً (Offline-First Single Source of Truth)
            val syncId = db.syncQueueDao().enqueue(syncQueueEntity)

            // 2. محاولة الرفع المباشر والفوري إلى Cloud Firestore على Dispatchers.IO
            if (_syncState.value.isSimulatedOffline) {
                return@launch
            }

            try {
                val delta = buildDeltaFromQueue(
                    syncId = syncId,
                    entityType = entityType,
                    operation = operation,
                    recordId = recordId,
                    payloadJson = payloadJson,
                    createdAt = syncQueueEntity.createdAt,
                    db = db,
                    deviceId = fsManager.deviceId
                )
                val uploaded = fsManager.pushDelta(delta)
                if (uploaded) {
                    db.syncQueueDao().markAsSynced(syncId)
                    db.syncQueueDao().clearSynced()
                    _syncState.update {
                        it.copy(
                            lastSyncTime = System.currentTimeMillis(),
                            lastSyncStatus = "تمت المزامنة الفورية مع Firestore ($entityType:$operation)",
                            lastSyncError = null
                        )
                    }
                } else {
                    try {
                        FirestoreSyncWorker.triggerImmediateSync(context)
                    } catch (_: Throwable) {}
                }
            } catch (e: Throwable) {
                Log.w(TAG, "Immediate Firestore push deferred to WorkManager: ${e.message}")
                try {
                    FirestoreSyncWorker.triggerImmediateSync(context)
                } catch (_: Throwable) {}
            }
        }
    }

    /**
     * تفريغ الطابور المعلق فورياً عبر Firestore على Dispatchers.IO (مثلاً بعد الإدراج الجماعي)
     */
    fun flushPendingQueueAsync() {
        scope.launch {
            ensureInitialized()
            flushPendingQueueInternal()
            appContext?.let { ctx ->
                try {
                    FirestoreSyncWorker.triggerImmediateSync(ctx)
                } catch (_: Throwable) {}
            }
        }
    }

    private suspend fun buildDeltaFromQueue(
        syncId: Long,
        entityType: String,
        operation: String,
        recordId: String,
        payloadJson: String,
        createdAt: Long,
        db: AidDatabase,
        deviceId: String
    ): FirestoreSyncDelta {
        val currentUser = AidApplication.getInstanceSafely()?.repository?.getCurrentUser()
        val userLocalityId = currentUser?.AllowedLocalityID ?: 0
        val isSuperAdmin = currentUser == null ||
            currentUser.RoleID == 1 ||
            currentUser.UserName.equals("admin", ignoreCase = true)
        val roleStr = if (isSuperAdmin) "SUPER_ADMIN" else "LOCALITY_SUPERVISOR"
        val userName = currentUser?.fullName ?: currentUser?.UserName ?: "مدير النظام"
        val userId = currentUser?.UserID ?: 1
        val localityName = if (userLocalityId > 0) {
            runCatching { db.localityDao().getLocalityById(userLocalityId)?.LocalityName }.getOrNull() ?: "محلية #$userLocalityId"
        } else {
            "الإدارة المركزية"
        }

        return FirestoreSyncDelta(
            deltaId = "sync_${syncId}_$createdAt",
            localityId = userLocalityId,
            localityName = localityName,
            userId = userId,
            userName = userName,
            userRole = roleStr,
            entityType = entityType,
            operation = operation,
            recordId = recordId,
            payloadJson = payloadJson,
            clientTimestamp = createdAt,
            deviceId = deviceId,
            isMasterAdminOverride = isSuperAdmin
        )
    }

    private suspend fun flushPendingQueueInternal(): Pair<Int, Int> = flushMutex.withLock {
        val db = database ?: return@withLock 0 to 0
        val context = appContext ?: return@withLock 0 to 0
        if (_syncState.value.isSimulatedOffline) return@withLock 0 to 0

        val fsManager = firestoreSyncManager ?: FirestoreSyncManager.getInstance(context).also {
            firestoreSyncManager = it
            it.initialize()
        }

        val pendingItems = db.syncQueueDao().getPendingSyncItems()
        if (pendingItems.isEmpty()) return@withLock 0 to 0

        if (!fsManager.ensureAuthenticated()) {
            return@withLock 0 to pendingItems.size
        }

        var succeeded = 0
        var failed = 0

        for (item in pendingItems) {
            try {
                db.syncQueueDao().markAsSyncing(item.syncId)
                val delta = buildDeltaFromQueue(
                    syncId = item.syncId,
                    entityType = item.entityType,
                    operation = item.operation,
                    recordId = item.recordId,
                    payloadJson = item.payloadJson,
                    createdAt = item.createdAt,
                    db = db,
                    deviceId = fsManager.deviceId
                )
                val uploaded = fsManager.pushDelta(delta)
                if (uploaded) {
                    db.syncQueueDao().markAsSynced(item.syncId)
                    succeeded++
                } else {
                    db.syncQueueDao().markAsFailed(item.syncId, fsManager.lastSyncError.value ?: "فشل الرفع إلى Firestore")
                    failed++
                }
            } catch (e: Throwable) {
                db.syncQueueDao().markAsFailed(item.syncId, e.message ?: "خطأ غير متوقع")
                failed++
            }
        }

        if (succeeded > 0) {
            db.syncQueueDao().clearSynced()
        }

        val summary = "تم رفع $succeeded حركة إلى Cloud Firestore، وفشل $failed حركات."
        db.syncQueueDao().insertSyncLog(
            SyncLogEntity(
                syncType = "FIRESTORE_REALTIME_FLUSH",
                itemsProcessed = pendingItems.size,
                itemsSucceeded = succeeded,
                itemsFailed = failed,
                status = if (failed == 0) "SUCCESS" else if (succeeded > 0) "PARTIAL" else "FAILED",
                summary = summary
            )
        )
        _syncState.update {
            it.copy(
                lastSyncTime = System.currentTimeMillis(),
                lastSyncStatus = summary
            )
        }
        succeeded to failed
    }

    /**
     * إدراج حركة تعديل في طابور التزامن (متوافق مع كود AidRepository و WorkManager)
     */
    fun enqueueItem(
        entityType: String,
        operation: String,
        recordId: String,
        payloadJson: String
    ) {
        pushChange(entityType, operation, recordId, payloadJson)
    }

    /**
     * تشغيل مزامنة يدوية فورية بالضغط على الزر
     */
    fun triggerSyncNow() {
        scope.launch {
            ensureInitialized()
            val context = appContext ?: return@launch
            val db = database ?: return@launch
            val fsManager = firestoreSyncManager

            _syncState.update { it.copy(isSyncing = true, connectionStatus = SyncConnectionStatus.SYNCING) }
            try {
                fsManager?.ensureAuthenticated()
                fsManager?.pingFirestore()
                fsManager?.startRealtimeListener(db, resolveCurrentUserLocalityScope())
                flushPendingQueueInternal()
                try {
                    FirestoreSyncWorker.triggerImmediateSync(context)
                } catch (_: Throwable) {}
                delay(600)
            } finally {
                _syncState.update { current ->
                    current.copy(
                        isSyncing = false,
                        connectionStatus = if (current.isOnline) SyncConnectionStatus.ONLINE else SyncConnectionStatus.OFFLINE
                    )
                }
            }
        }
    }

    fun getPendingCountFlow(): Flow<Int> {
        ensureInitialized()
        val db = database ?: return flowOf(0)
        return db.syncQueueDao().getPendingCountFlow()
    }

    /**
     * محاكاة قطع/إعادة اتصال الإنترنت لاختبار قدرات Offline-First ميدانياً
     */
    fun toggleOfflineSimulation() {
        _syncState.update { current ->
            val newSimulated = !current.isSimulatedOffline
            val realOnline = connectivityObserver?.isCurrentlyOnline() ?: true
            val effectiveOnline = if (newSimulated) false else realOnline
            current.copy(
                isSimulatedOffline = newSimulated,
                isOnline = effectiveOnline,
                connectionStatus = if (!effectiveOnline) SyncConnectionStatus.OFFLINE else SyncConnectionStatus.ONLINE
            )
        }
        if (!_syncState.value.isSimulatedOffline) {
            flushPendingQueueAsync()
        }
    }
}
