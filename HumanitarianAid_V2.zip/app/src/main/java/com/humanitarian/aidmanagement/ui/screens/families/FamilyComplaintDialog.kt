package com.humanitarian.aidmanagement.ui.screens.families

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.data.local.entities.FamilyComplaintEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity

private val ComplaintAmber = Color(0xFFD97706)
private val ComplaintAmberSoft = Color(0xFFFEF3C7)
private val ComplaintRose = Color(0xFFE11D48)
private val ComplaintEmerald = Color(0xFF0F7B53)
private val ComplaintSlateDark = Color(0xFF0F172A)
private val ComplaintSlateMuted = Color(0xFF64748B)
private val ComplaintGlassBorder = Color(0xFFD6E8DF)

private val QUICK_COMPLAINT_REASONS = listOf(
    "أسرة مهمشة",
    "لم تستلم منذ فترة طويلة",
    "حالة إنسانية طارئة"
)

/**
 * شارة زجاجية واضحة تعرض وجود شكوى مفتوحة على بطاقة الأسرة مع نوع المساعدة المستهدفة
 */
@Composable
fun OpenFamilyComplaintBadge(
    complaints: List<FamilyComplaintEntity>,
    onResolveComplaint: ((FamilyComplaintEntity) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    if (complaints.isEmpty()) return
    val latest = complaints.first()

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = ComplaintAmberSoft.copy(alpha = 0.72f),
        border = BorderStroke(1.dp, ComplaintAmber.copy(alpha = 0.40f)),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PriorityHigh,
                        contentDescription = null,
                        tint = ComplaintAmber,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (complaints.size == 1) {
                            "شكوى / أولوية مفتوحة"
                        } else {
                            "شكاوى مفتوحة (${complaints.size})"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF92400E)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = ComplaintAmber.copy(alpha = 0.16f),
                    border = BorderStroke(0.8.dp, ComplaintAmber.copy(alpha = 0.35f))
                ) {
                    Text(
                        text = "المستهدف: ${latest.targetAidCategory}",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF92400E),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = "السبب: ${latest.complaintReason}",
                style = MaterialTheme.typography.bodySmall,
                color = ComplaintSlateDark,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (onResolveComplaint != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = { onResolveComplaint(latest) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.TaskAlt,
                            contentDescription = null,
                            tint = ComplaintEmerald,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "إغلاق / معالجة الشكوى",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ComplaintEmerald
                        )
                    }
                }
            }
        }
    }
}

/**
 * نافذة تسجيل / تقييم شكوى للأسرة بتصميم Glassmorphism V3.0
 * تجلب تصنيفات المساعدات ديناميكياً من قاعدة البيانات بدون أي قائمة ثابتة.
 */
@Composable
fun FamilyComplaintDialog(
    family: FamilyEntity,
    dynamicAidCategories: List<String>,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (reason: String, targetAidCategory: String) -> Unit
) {
    var complaintReason by remember { mutableStateOf("") }
    var selectedCategory by remember(dynamicAidCategories) {
        mutableStateOf(dynamicAidCategories.firstOrNull().orEmpty())
    }
    var customCategoryText by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = { if (!isSaving) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.93f)
                    .wrapContentHeight(),
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFFF7FBF9).copy(alpha = 0.97f),
                border = BorderStroke(1.2.dp, ComplaintGlassBorder),
                shadowElevation = 0.dp,
                tonalElevation = 0.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFFECF8F2).copy(alpha = 0.95f),
                                    Color(0xFFFFFFFF).copy(alpha = 0.98f)
                                )
                            )
                        )
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // الترويسة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(ComplaintAmber.copy(alpha = 0.14f))
                                    .border(1.dp, ComplaintAmber.copy(alpha = 0.30f), RoundedCornerShape(12.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ReportProblem,
                                    contentDescription = null,
                                    tint = ComplaintAmber,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "تسجيل / تقييم شكوى وأولوية",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = ComplaintSlateDark
                                )
                                Text(
                                    text = "${family.name} • ${family.nationalID}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ComplaintSlateMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        IconButton(
                            onClick = { if (!isSaving) onDismiss() }
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "إغلاق",
                                tint = ComplaintSlateMuted
                            )
                        }
                    }

                    HorizontalDivider(color = ComplaintGlassBorder)

                    // معلومات المنطقة الحالية
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = ComplaintEmerald.copy(alpha = 0.08f),
                        border = BorderStroke(0.8.dp, ComplaintEmerald.copy(alpha = 0.22f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.LocationOn,
                                contentDescription = null,
                                tint = ComplaintEmerald,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "المنطقة المحلية المسجلة: ${family.currentSubArea.ifBlank { "غير محددة" }}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = ComplaintEmerald
                            )
                        }
                    }

                    // خيارات سريعة لسبب الشكوى
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "أسباب سريعة مقترحة:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = ComplaintSlateDark
                        )
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            QUICK_COMPLAINT_REASONS.forEach { preset ->
                                val isSelected = complaintReason.contains(preset)
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = if (isSelected) ComplaintAmber.copy(alpha = 0.18f) else Color.White,
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) ComplaintAmber else ComplaintGlassBorder
                                    ),
                                    modifier = Modifier.clickable {
                                        complaintReason = when {
                                            complaintReason.isBlank() -> preset
                                            complaintReason.contains(preset) -> complaintReason
                                            else -> "$complaintReason - $preset"
                                        }
                                        validationError = null
                                    }
                                ) {
                                    Text(
                                        text = preset,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) Color(0xFF92400E) else ComplaintSlateDark,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                    )
                                }
                            }
                        }
                    }

                    // حقل نصي لسبب الشكوى
                    OutlinedTextField(
                        value = complaintReason,
                        onValueChange = {
                            complaintReason = it
                            validationError = null
                        },
                        label = { Text("سبب الشكوى / التقييم الميداني") },
                        placeholder = { Text("اكتب تفاصيل الشكوى أو مبرر الأولوية...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 5,
                        shape = RoundedCornerShape(14.dp)
                    )

                    // اختيار تصنيف المساعدة المستهدفة ديناميكياً من قاعدة البيانات
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "تصنيف المساعدة المستهدفة مستقبلاً (ديناميكي):",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = ComplaintSlateDark
                        )

                        if (dynamicAidCategories.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                dynamicAidCategories.forEach { category ->
                                    val isChosen = selectedCategory == category
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = if (isChosen) ComplaintEmerald else Color.White,
                                        border = BorderStroke(
                                            1.dp,
                                            if (isChosen) ComplaintEmerald else ComplaintGlassBorder
                                        ),
                                        modifier = Modifier.clickable {
                                            selectedCategory = category
                                            customCategoryText = ""
                                            validationError = null
                                        }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                                        ) {
                                            if (isChosen) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Check,
                                                    contentDescription = null,
                                                    tint = Color.White,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                            Text(
                                                text = category,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isChosen) Color.White else ComplaintSlateDark
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            OutlinedTextField(
                                value = customCategoryText,
                                onValueChange = {
                                    customCategoryText = it
                                    selectedCategory = it.trim()
                                    validationError = null
                                },
                                label = { Text("اسم تصنيف المساعدة المستهدفة") },
                                placeholder = { Text("لم يتم العثور على تصنيفات مسجلة بعد — أدخل التصنيف") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp)
                            )
                        }
                    }

                    if (!validationError.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = ComplaintRose.copy(alpha = 0.10f),
                            border = BorderStroke(0.8.dp, ComplaintRose.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = validationError!!,
                                style = MaterialTheme.typography.bodySmall,
                                color = ComplaintRose,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }

                    // أزرار الحفظ والإلغاء
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            enabled = !isSaving,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("إلغاء", fontWeight = FontWeight.SemiBold)
                        }

                        Button(
                            onClick = {
                                val cleanReason = complaintReason.trim()
                                val cleanCategory = selectedCategory.trim().ifBlank { customCategoryText.trim() }
                                when {
                                    cleanReason.isEmpty() -> {
                                        validationError = "يرجى كتابة سبب الشكوى أو اختيار أحد الأسباب السريعة."
                                    }
                                    cleanCategory.isEmpty() -> {
                                        validationError = "يرجى اختيار تصنيف المساعدة المستهدفة."
                                    }
                                    else -> onSubmit(cleanReason, cleanCategory)
                                }
                            },
                            enabled = !isSaving,
                            modifier = Modifier.weight(1.4f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ComplaintEmerald)
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("جاري الحفظ...", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.Save,
                                    contentDescription = null,
                                    modifier = Modifier.size(17.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("حفظ الشكوى", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
