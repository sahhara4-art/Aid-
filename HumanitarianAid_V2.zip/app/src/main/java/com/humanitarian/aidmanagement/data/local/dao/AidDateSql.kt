package com.humanitarian.aidmanagement.data.local.dao

/**
 * تعبيرات SQLite الموحدة لتطبيع التواريخ إلى صيغة ISO القياسية (YYYY-MM-DD)
 * متوافقة مع جميع إصدارات Android SQLite (API 21+) و Room بدون تغييرات في مخطط قاعدة البيانات.
 *
 * القاعدة 1 (الإحصائيات والفترات - DELIVERY_EFFECTIVE_CTE):
 * - أولوية لتاريخ الاستلام الفعلي الصالح (`deliveryDate`) للسجلات المصنفة كمستفيدين
 *   ('مستفيد'، 'تم التسليم'، 'مستلم').
 * - عند غياب أو عدم صلاحية `deliveryDate`: الرجوع تلقائياً إلى تاريخ الترشيح
 *   (`actualNominationDate` ثم `selectionDate` ثم `aidDate`).
 * - توحيد الصيغة (بما في ذلك DD/MM/YYYY، YYYY/M/D، التواريخ مع الوقت، والأرقام العربية ٠-٩)
 *   إلى YYYY-MM-DD قبل المقارنة مع نطاق الفترة.
 *
 * القاعدة 2 (فلترة واستثناءات الترشيح - NOMINATION_EFFECTIVE_CTE):
 * - اعتماد تاريخ الترشيح حصراً (`actualNominationDate` ثم `selectionDate` ثم `aidDate`)
 *   مطبّعاً إلى YYYY-MM-DD، وعدم استخدام `deliveryDate` إطلاقاً كمرجع للترشيح.
 */
object AidDateSql {

    private const val DELIVERY_VALID =
        "TRIM(COALESCE(a.recipientStatus, '')) IN ('مستفيد', 'تم التسليم', 'مستلم') " +
        "AND LENGTH(TRIM(COALESCE(a.deliveryDate, ''))) >= 8 " +
        "AND (INSTR(a.deliveryDate, '-') > 0 OR INSTR(a.deliveryDate, '/') > 0 OR INSTR(a.deliveryDate, '.') > 0) " +
        "AND SUBSTR(REPLACE(REPLACE(TRIM(a.deliveryDate), '/', '-'), '.', '-'), 1, 10) NOT IN ('0000-00-00', '1970-01-01', '01-01-1970', '٠٠٠٠-٠٠-٠٠', '١٩٧٠-٠١-٠١', '٠١-٠١-١٩٧٠')"

    private const val ACTUAL_NOM_VALID =
        "LENGTH(TRIM(COALESCE(a.actualNominationDate, ''))) >= 8 " +
        "AND (INSTR(a.actualNominationDate, '-') > 0 OR INSTR(a.actualNominationDate, '/') > 0 OR INSTR(a.actualNominationDate, '.') > 0) " +
        "AND SUBSTR(REPLACE(REPLACE(TRIM(a.actualNominationDate), '/', '-'), '.', '-'), 1, 10) NOT IN ('0000-00-00', '1970-01-01', '01-01-1970', '٠٠٠٠-٠٠-٠٠', '١٩٧٠-٠١-٠١', '٠١-٠١-١٩٧٠')"

    private const val SELECTION_VALID =
        "LENGTH(TRIM(COALESCE(a.selectionDate, ''))) >= 8 " +
        "AND (INSTR(a.selectionDate, '-') > 0 OR INSTR(a.selectionDate, '/') > 0 OR INSTR(a.selectionDate, '.') > 0) " +
        "AND SUBSTR(REPLACE(REPLACE(TRIM(a.selectionDate), '/', '-'), '.', '-'), 1, 10) NOT IN ('0000-00-00', '1970-01-01', '01-01-1970', '٠٠٠٠-٠٠-٠٠', '١٩٧٠-٠١-٠١', '٠١-٠١-١٩٧٠')"

    private const val AID_DATE_VALID =
        "LENGTH(TRIM(COALESCE(a.aidDate, ''))) >= 8 " +
        "AND (INSTR(a.aidDate, '-') > 0 OR INSTR(a.aidDate, '/') > 0 OR INSTR(a.aidDate, '.') > 0) " +
        "AND SUBSTR(REPLACE(REPLACE(TRIM(a.aidDate), '/', '-'), '.', '-'), 1, 10) NOT IN ('0000-00-00', '1970-01-01', '01-01-1970', '٠٠٠٠-٠٠-٠٠', '١٩٧٠-٠١-٠١', '٠١-٠١-١٩٧٠')"

    private const val NORMALIZE_TOKEN_TO_ISO =
        "CASE " +
        "WHEN LENGTH(c) = 10 AND SUBSTR(c, 5, 1) = '-' AND SUBSTR(c, 8, 1) = '-' THEN c " +
        "WHEN INSTR(c, '-') = 5 AND INSTR(SUBSTR(c, 6), '-') > 1 THEN " +
        "SUBSTR(c, 1, 4) || '-' || " +
        "SUBSTR('0' || SUBSTR(SUBSTR(c, 6), 1, INSTR(SUBSTR(c, 6), '-') - 1), -2) || '-' || " +
        "SUBSTR('0' || SUBSTR(SUBSTR(c, 6), INSTR(SUBSTR(c, 6), '-') + 1), -2) " +
        "WHEN INSTR(c, '-') IN (2, 3) AND INSTR(SUBSTR(c, INSTR(c, '-') + 1), '-') IN (2, 3) " +
        "AND LENGTH(SUBSTR(SUBSTR(c, INSTR(c, '-') + 1), INSTR(SUBSTR(c, INSTR(c, '-') + 1), '-') + 1)) = 4 THEN " +
        "SUBSTR(SUBSTR(c, INSTR(c, '-') + 1), INSTR(SUBSTR(c, INSTR(c, '-') + 1), '-') + 1) || '-' || " +
        "CASE WHEN CAST(SUBSTR(SUBSTR(c, INSTR(c, '-') + 1), 1, INSTR(SUBSTR(c, INSTR(c, '-') + 1), '-') - 1) AS INTEGER) > 12 " +
        "AND CAST(SUBSTR(c, 1, INSTR(c, '-') - 1) AS INTEGER) <= 12 " +
        "THEN SUBSTR('0' || SUBSTR(c, 1, INSTR(c, '-') - 1), -2) " +
        "ELSE SUBSTR('0' || SUBSTR(SUBSTR(c, INSTR(c, '-') + 1), 1, INSTR(SUBSTR(c, INSTR(c, '-') + 1), '-') - 1), -2) END || '-' || " +
        "CASE WHEN CAST(SUBSTR(SUBSTR(c, INSTR(c, '-') + 1), 1, INSTR(SUBSTR(c, INSTR(c, '-') + 1), '-') - 1) AS INTEGER) > 12 " +
        "AND CAST(SUBSTR(c, 1, INSTR(c, '-') - 1) AS INTEGER) <= 12 " +
        "THEN SUBSTR('0' || SUBSTR(SUBSTR(c, INSTR(c, '-') + 1), 1, INSTR(SUBSTR(c, INSTR(c, '-') + 1), '-') - 1), -2) " +
        "ELSE SUBSTR('0' || SUBSTR(c, 1, INSTR(c, '-') - 1), -2) END " +
        "ELSE '1970-01-01' END"

    private const val CLEAN_RAW_R_TO_S =
        "REPLACE(REPLACE(REPLACE(" +
        "CASE WHEN r GLOB '*[٠-٩]*' " +
        "THEN REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(r,'٠','0'),'١','1'),'٢','2'),'٣','3'),'٤','4'),'٥','5'),'٦','6'),'٧','7'),'٨','8'),'٩','9') " +
        "ELSE r END, '/', '-'), '.', '-'), 'T', ' ')"

    /**
     * CTE للإحصائيات والفترات:
     * ينتج جدولاً مؤقتاً `eff_aid` بأعمدة:
     * (aidRecordID, familyID, aidTypeID, projectID, recipientStatus, effectiveDate)
     * حيث `effectiveDate` بصيغة `YYYY-MM-DD` (تاريخ الاستلام الفعلي الصالح أولاً، ثم تاريخ الترشيح).
     */
    const val DELIVERY_EFFECTIVE_CTE =
        "WITH eff_raw AS (" +
        "SELECT a.aidRecordID, a.familyID, a.aidTypeID, a.projectID, a.recipientStatus, " +
        "CASE " +
        "WHEN $DELIVERY_VALID THEN TRIM(a.deliveryDate) " +
        "WHEN $ACTUAL_NOM_VALID THEN TRIM(a.actualNominationDate) " +
        "WHEN $SELECTION_VALID THEN TRIM(a.selectionDate) " +
        "WHEN $AID_DATE_VALID THEN TRIM(a.aidDate) " +
        "ELSE '' END AS r " +
        "FROM aid_records a LIMIT -1" +
        "), " +
        "eff_s AS (" +
        "SELECT aidRecordID, familyID, aidTypeID, projectID, recipientStatus, $CLEAN_RAW_R_TO_S AS s " +
        "FROM eff_raw LIMIT -1" +
        "), " +
        "eff_tok AS (" +
        "SELECT aidRecordID, familyID, aidTypeID, projectID, recipientStatus, " +
        "CASE WHEN INSTR(s, ' ') > 0 THEN SUBSTR(s, 1, INSTR(s, ' ') - 1) ELSE s END AS c " +
        "FROM eff_s LIMIT -1" +
        "), " +
        "eff_aid AS (" +
        "SELECT aidRecordID, familyID, aidTypeID, projectID, recipientStatus, $NORMALIZE_TOKEN_TO_ISO AS effectiveDate " +
        "FROM eff_tok LIMIT -1" +
        ") "

    /**
     * CTE لفلترة وترتيب واستثناءات الترشيح حصراً:
     * ينتج جدولاً مؤقتاً `nom_aid` بأعمدة:
     * (aidRecordID, familyID, aidTypeID, projectID, recipientStatus, nominationDate)
     * حيث `nominationDate` بصيغة `YYYY-MM-DD` ومستمد حصراً من تاريخ الترشيح
     * (`actualNominationDate` ثم `selectionDate` ثم `aidDate`) دون أي اعتماد على `deliveryDate`.
     */
    const val NOMINATION_EFFECTIVE_CTE =
        "WITH nom_raw AS (" +
        "SELECT a.aidRecordID, a.familyID, a.aidTypeID, a.projectID, a.recipientStatus, " +
        "CASE " +
        "WHEN $ACTUAL_NOM_VALID THEN TRIM(a.actualNominationDate) " +
        "WHEN $SELECTION_VALID THEN TRIM(a.selectionDate) " +
        "WHEN $AID_DATE_VALID THEN TRIM(a.aidDate) " +
        "ELSE '' END AS r " +
        "FROM aid_records a LIMIT -1" +
        "), " +
        "nom_s AS (" +
        "SELECT aidRecordID, familyID, aidTypeID, projectID, recipientStatus, $CLEAN_RAW_R_TO_S AS s " +
        "FROM nom_raw LIMIT -1" +
        "), " +
        "nom_tok AS (" +
        "SELECT aidRecordID, familyID, aidTypeID, projectID, recipientStatus, " +
        "CASE WHEN INSTR(s, ' ') > 0 THEN SUBSTR(s, 1, INSTR(s, ' ') - 1) ELSE s END AS c " +
        "FROM nom_s LIMIT -1" +
        "), " +
        "nom_aid AS (" +
        "SELECT aidRecordID, familyID, aidTypeID, projectID, recipientStatus, $NORMALIZE_TOKEN_TO_ISO AS nominationDate " +
        "FROM nom_tok LIMIT -1" +
        ") "

    private const val PROJECT_DATE_VALID =
        "LENGTH(TRIM(COALESCE(p.projectDate, ''))) >= 8 " +
        "AND (INSTR(p.projectDate, '-') > 0 OR INSTR(p.projectDate, '/') > 0 OR INSTR(p.projectDate, '.') > 0) " +
        "AND SUBSTR(REPLACE(REPLACE(TRIM(p.projectDate), '/', '-'), '.', '-'), 1, 10) NOT IN ('0000-00-00', '1970-01-01', '01-01-1970', '٠٠٠٠-٠٠-٠٠', '١٩٧٠-٠١-٠١', '٠١-٠١-١٩٧٠')"

    private const val PROJECT_ACTUAL_NOM_VALID =
        "LENGTH(TRIM(COALESCE(p.actualNominationDate, ''))) >= 8 " +
        "AND (INSTR(p.actualNominationDate, '-') > 0 OR INSTR(p.actualNominationDate, '/') > 0 OR INSTR(p.actualNominationDate, '.') > 0) " +
        "AND SUBSTR(REPLACE(REPLACE(TRIM(p.actualNominationDate), '/', '-'), '.', '-'), 1, 10) NOT IN ('0000-00-00', '1970-01-01', '01-01-1970', '٠٠٠٠-٠٠-٠٠', '١٩٧٠-٠١-٠١', '٠١-٠١-١٩٧٠')"

    /**
     * CTE لتوحيد تاريخ المشاريع بصيغة ISO (YYYY-MM-DD) قبل الترتيب من الأحدث إلى الأقدم
     * (`projectDate` أولاً ثم `actualNominationDate` كمرجع احتياطي، مع `projectID DESC` كمرجع ثانوي عند التساوي).
     */
    const val PROJECT_EFFECTIVE_DATE_CTE =
        "WITH prj_raw AS (" +
        "SELECT p.projectID, " +
        "CASE " +
        "WHEN $PROJECT_DATE_VALID THEN TRIM(p.projectDate) " +
        "WHEN $PROJECT_ACTUAL_NOM_VALID THEN TRIM(p.actualNominationDate) " +
        "ELSE '' END AS r " +
        "FROM projects p LIMIT -1" +
        "), " +
        "prj_s AS (" +
        "SELECT projectID, $CLEAN_RAW_R_TO_S AS s " +
        "FROM prj_raw LIMIT -1" +
        "), " +
        "prj_tok AS (" +
        "SELECT projectID, " +
        "CASE WHEN INSTR(s, ' ') > 0 THEN SUBSTR(s, 1, INSTR(s, ' ') - 1) ELSE s END AS c " +
        "FROM prj_s LIMIT -1" +
        "), " +
        "prj_date AS (" +
        "SELECT projectID, $NORMALIZE_TOKEN_TO_ISO AS normalizedProjectDate " +
        "FROM prj_tok LIMIT -1" +
        ") "
}
