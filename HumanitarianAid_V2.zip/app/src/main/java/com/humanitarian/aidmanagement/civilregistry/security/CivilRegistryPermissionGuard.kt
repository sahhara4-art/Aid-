package com.humanitarian.aidmanagement.civilregistry.security

import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.security.AccessControlManager

/**
 * حارس الصلاحيات الخاص بوحدة البحث في السجل المدني (Civil Registry Access Guard)
 *
 * القاعدة الصارمة:
 * - يتحقق من صلاحية الوصول الفعلية `canAccessCivilRegistry` قبل إظهار أي عنصر أو فتح الشاشة أو تنفيذ أي استعلام.
 * - عند عدم التخويل (false): إخفاء تام بدون أي رسائل رفض ومنع كامل لأي استعلام على جدول civil_registry.
 */
object CivilRegistryPermissionGuard {

    private val ALLOWED_TOKENS = setOf(
        AccessControlManager.CAN_SEARCH_CIVIL_REGISTRY,
        "CAN_ACCESS_CIVIL_REGISTRY",
        "CIVIL_REGISTRY",
        "CIVIL_REGISTRY_LOOKUP"
    )

    fun canAccessCivilRegistry(
        user: UserEntity? = AccessControlManager.currentUser.value,
        permissions: Collection<String> = AccessControlManager.permissions
    ): Boolean {
        if (user == null) return false

        val isSuperAdmin = user.UserName.trim().equals("admin", ignoreCase = true) || user.RoleID == 1
        if (isSuperAdmin) return true

        if (AccessControlManager.isAccountValid(user) !is AccessControlManager.AccountValidationResult.Valid) {
            return false
        }

        val combinedTokens = buildSet {
            permissions.forEach { token ->
                val clean = token.trim().uppercase()
                if (clean.isNotEmpty()) add(clean)
            }
            user.actionPermissions.forEach { token ->
                val clean = token.trim().uppercase()
                if (clean.isNotEmpty()) add(clean)
            }
            user.screenPermissions.forEach { token ->
                val clean = token.trim().uppercase()
                if (clean.isNotEmpty()) add(clean)
            }
            user.permissions
                .split(",", ";", "|", "\n")
                .forEach { raw ->
                    val clean = raw.trim().removeSurrounding("\"").removeSurrounding("'").uppercase()
                    if (clean.isNotEmpty()) add(clean)
                }
        }

        return combinedTokens.any { it in ALLOWED_TOKENS }
    }
}
