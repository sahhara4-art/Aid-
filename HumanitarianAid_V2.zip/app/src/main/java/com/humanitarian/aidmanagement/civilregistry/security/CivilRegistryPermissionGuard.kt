package com.humanitarian.aidmanagement.civilregistry.security

import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.security.AccessControlManager

/**
 * حارس الصلاحيات الخاص بوحدة البحث في السجل المدني (Civil Registry Access Guard)
 * يتحقق من صلاحية المستخدم وصحة حسابه قبل السماح بأي استعلام أو عرض للبيانات الحساسة.
 */
object CivilRegistryPermissionGuard {

    data class AccessDecision(
        val isAllowed: Boolean,
        val denialReason: String? = null
    )

    fun evaluate(
        user: UserEntity? = AccessControlManager.currentUser.value,
        permissions: List<String> = AccessControlManager.permissions
    ): AccessDecision {
        if (user == null) {
            return AccessDecision(
                isAllowed = false,
                denialReason = "يرجى تسجيل الدخول بحساب مصرح له قبل الوصول إلى السجل المدني."
            )
        }

        val isSuperAdmin = user.UserName.trim().equals("admin", ignoreCase = true) || user.RoleID == 1
        if (isSuperAdmin) {
            return AccessDecision(isAllowed = true)
        }

        when (val validation = AccessControlManager.isAccountValid(user)) {
            is AccessControlManager.AccountValidationResult.Valid -> Unit
            is AccessControlManager.AccountValidationResult.NotLoggedIn -> {
                return AccessDecision(
                    isAllowed = false,
                    denialReason = "يرجى تسجيل الدخول أولاً للوصول إلى السجل المدني."
                )
            }
            is AccessControlManager.AccountValidationResult.Inactive -> {
                return AccessDecision(isAllowed = false, denialReason = validation.reason)
            }
            is AccessControlManager.AccountValidationResult.Locked -> {
                return AccessDecision(isAllowed = false, denialReason = validation.reason)
            }
            is AccessControlManager.AccountValidationResult.Expired -> {
                return AccessDecision(isAllowed = false, denialReason = validation.reason)
            }
            is AccessControlManager.AccountValidationResult.QuotaExceeded -> {
                return AccessDecision(isAllowed = false, denialReason = validation.reason)
            }
        }

        val normalizedPermissions = permissions.map { it.trim().uppercase() }.toSet()
        val hasLookupPermission = normalizedPermissions.contains(AccessControlManager.CAN_SEARCH_CIVIL_REGISTRY) ||
            normalizedPermissions.contains(AccessControlManager.CAN_VERIFY_IDS) ||
            normalizedPermissions.contains(AccessControlManager.CAN_MANAGE_FAMILIES) ||
            normalizedPermissions.contains(AccessControlManager.ACTION_ADD) ||
            normalizedPermissions.contains("CIVIL_REGISTRY") ||
            normalizedPermissions.contains("FAMILIES")

        return if (hasLookupPermission) {
            AccessDecision(isAllowed = true)
        } else {
            AccessDecision(
                isAllowed = false,
                denialReason = "ليس لديك صلاحية الاستعلام أو الاطلاع على بيانات السجل المدني الحساسة. يرجى مراجعة مدير النظام."
            )
        }
    }
}
