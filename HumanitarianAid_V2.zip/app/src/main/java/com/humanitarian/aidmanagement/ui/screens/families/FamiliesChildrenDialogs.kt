package com.humanitarian.aidmanagement.ui.screens.families

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.util.AgeExportFormat
import com.humanitarian.aidmanagement.util.AgeExportProgress
import com.humanitarian.aidmanagement.util.AgeExportReportType
import com.humanitarian.aidmanagement.util.AgeExportResult
import com.humanitarian.aidmanagement.util.ExactAgeUtil

private data class AgeQuickPreset(
    val label: String,
    val isClear: Boolean = false,
    val minYears: Int = 0,
    val minMonths: Int = 0,
    val maxYears: Int = 18,
    val maxMonths: Int = 0
)

private val QUICK_AGE_PRESETS = listOf(
    AgeQuickPreset("أقل من سنة", minYears = 0, minMonths = 0, maxYears = 1, maxMonths = 0),
    AgeQuickPreset("من 1 إلى 3 سنوات", minYears = 1, minMonths = 0, maxYears = 3, maxMonths = 0),
    AgeQuickPreset("من 3 إلى 6 سنوات", minYears = 3, minMonths = 0, maxYears = 6, maxMonths = 0),
    AgeQuickPreset("من 6 إلى 12 سنة", minYears = 6, minMonths = 0, maxYears = 12, maxMonths = 0),
    AgeQuickPreset("أقل من 18 سنة", minYears = 0, minMonths = 0, maxYears = 18, maxMonths = 0),
    AgeQuickPreset("الكل", isClear = true)
)

/**
 * 1. نافذة الفلترة المتقدمة حسب العمر والجنس (Glassmorphism V3.0 - خفيفة بدون Blur)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AgeFilterDialog(
    initialFilter: AgeFilterState,
    onApply: (AgeFilterState) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    var useAgeRange by remember { mutableStateOf(if (initialFilter.isActive) true else true) }
    var minYearsText by remember { mutableStateOf(initialFilter.minYears.toString()) }
    var minMonthsText by remember { mutableStateOf(initialFilter.minMonths.toString()) }
    var maxYearsText by remember { mutableStateOf(initialFilter.maxYears.toString()) }
    var maxMonthsText by remember { mutableStateOf(initialFilter.maxMonths.toString()) }
    var selectedGender by remember { mutableStateOf(initialFilter.gender.ifBlank { "الكل" }) }
    var selectedPresetLabel by remember { mutableStateOf(initialFilter.presetLabel) }

    val minY = minYearsText.toIntOrNull()?.coerceIn(0, 120) ?: 0
    val minM = minMonthsText.toIntOrNull()?.coerceIn(0, 11) ?: 0
    val maxY = maxYearsText.toIntOrNull()?.coerceIn(0, 120) ?: 0
    val maxM = maxMonthsText.toIntOrNull()?.coerceIn(0, 11) ?: 0

    val previewRange = remember(useAgeRange, minY, minM, maxY, maxM) {
        if (!useAgeRange) null
        else ExactAgeUtil.computeBirthDateRangeForAgeFilter(minY, minM, maxY, maxM)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFFF9FCFB),
                border = BorderStroke(1.dp, Color(0xFFCDE5D9)),
                shadowElevation = 0.dp,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // الرأس
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFFE6F4EA)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.FilterAlt,
                                    contentDescription = null,
                                    tint = Color(0xFF0F7B53),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "فلتر العمر المتقدم للأبناء",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = "استعلام SQLite مفهرس على تاريخ الميلاد والجنس",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color(0xFF475569))
                        }
                    }

                    // اختيارات سريعة جاهزة (Chips)
                    Text(
                        text = "اختيارات سريعة جاهزة",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F5E59)
                    )
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        QUICK_AGE_PRESETS.forEach { preset ->
                            val isSelected = if (preset.isClear) {
                                !useAgeRange
                            } else {
                                useAgeRange &&
                                    minY == preset.minYears &&
                                    minM == preset.minMonths &&
                                    maxY == preset.maxYears &&
                                    maxM == preset.maxMonths
                            }
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    if (preset.isClear) {
                                        useAgeRange = false
                                        selectedPresetLabel = null
                                    } else {
                                        useAgeRange = true
                                        minYearsText = preset.minYears.toString()
                                        minMonthsText = preset.minMonths.toString()
                                        maxYearsText = preset.maxYears.toString()
                                        maxMonthsText = preset.maxMonths.toString()
                                        selectedPresetLabel = preset.label
                                    }
                                },
                                label = {
                                    Text(
                                        text = preset.label,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF0F7B53),
                                    selectedLabelColor = Color.White,
                                    containerColor = Color.White.copy(alpha = 0.85f)
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = Color(0xFFCDE5D9),
                                    selectedBorderColor = Color(0xFF0F7B53)
                                )
                            )
                        }
                    }

                    // نطاق مخصص: من عمر -> إلى عمر
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.90f),
                        border = BorderStroke(1.dp, Color(0xFFD6E8DF)),
                        shadowElevation = 0.dp,
                        tonalElevation = 0.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "تحديد نطاق عمر مخصص",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Switch(
                                    checked = useAgeRange,
                                    onCheckedChange = {
                                        useAgeRange = it
                                        if (!it) selectedPresetLabel = null
                                    }
                                )
                            }

                            if (useAgeRange) {
                                Text(
                                    text = "من عمر:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF0F7B53)
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = minYearsText,
                                        onValueChange = { v ->
                                            minYearsText = v.filter { it.isDigit() }.take(3)
                                            selectedPresetLabel = null
                                        },
                                        label = { Text("سنوات", fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = minMonthsText,
                                        onValueChange = { v ->
                                            val digits = v.filter { it.isDigit() }.take(2)
                                            val num = digits.toIntOrNull()
                                            minMonthsText = if (num != null && num > 11) "11" else digits
                                            selectedPresetLabel = null
                                        },
                                        label = { Text("شهور (0-11)", fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Text(
                                    text = "إلى عمر:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF0F7B53)
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = maxYearsText,
                                        onValueChange = { v ->
                                            maxYearsText = v.filter { it.isDigit() }.take(3)
                                            selectedPresetLabel = null
                                        },
                                        label = { Text("سنوات", fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = maxMonthsText,
                                        onValueChange = { v ->
                                            val digits = v.filter { it.isDigit() }.take(2)
                                            val num = digits.toIntOrNull()
                                            maxMonthsText = if (num != null && num > 11) "11" else digits
                                            selectedPresetLabel = null
                                        },
                                        label = { Text("شهور (0-11)", fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                if (previewRange != null) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color(0xFFE6F4EA),
                                        border = BorderStroke(0.8.dp, Color(0xFF0F7B53).copy(alpha = 0.25f)),
                                        shadowElevation = 0.dp,
                                        tonalElevation = 0.dp,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CalendarMonth,
                                                contentDescription = null,
                                                tint = Color(0xFF0F7B53),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = "نطاق تاريخ الميلاد: ${previewRange.first}  ←  ${previewRange.second}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFF065F46)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // فلتر الجنس
                    Text(
                        text = "الجنس",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F5E59)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("الكل", "ذكر", "أنثى").forEach { genderOption ->
                            val selected = selectedGender == genderOption
                            Surface(
                                onClick = { selectedGender = genderOption },
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) Color(0xFF0F7B53) else Color.White.copy(alpha = 0.9f),
                                border = BorderStroke(
                                    1.dp,
                                    if (selected) Color(0xFF0F7B53) else Color(0xFFD6E8DF)
                                ),
                                shadowElevation = 0.dp,
                                tonalElevation = 0.dp,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = genderOption,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selected) Color.White else Color(0xFF334155)
                                    )
                                }
                            }
                        }
                    }

                    // أزرار التطبيق والمسح
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                onClear()
                                onDismiss()
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(0.42f)
                        ) {
                            Text("إلغاء الفلتر", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                if (!useAgeRange && selectedGender == "الكل") {
                                    onClear()
                                } else {
                                    onApply(
                                        AgeFilterState(
                                            isActive = useAgeRange,
                                            minYears = minY,
                                            minMonths = minM,
                                            maxYears = maxY,
                                            maxMonths = maxM,
                                            gender = selectedGender,
                                            presetLabel = if (useAgeRange) selectedPresetLabel else null
                                        )
                                    )
                                }
                                onDismiss()
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F7B53)),
                            modifier = Modifier.weight(0.58f)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تطبيق الفلتر", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

/**
 * 2. نافذة التصدير المخصص حسب الفلتر الحالي (Excel .xlsx / CSV UTF-8 BOM + فتح ومشاركة عبر FileProvider)
 */
@Composable
fun AgeFilteredExportDialog(
    ageFilter: AgeFilterState,
    matchedFamiliesCount: Int,
    matchedChildrenCount: Int,
    isExporting: Boolean,
    exportProgress: AgeExportProgress?,
    exportResult: AgeExportResult?,
    exportError: String?,
    onStartExport: (AgeExportReportType, AgeExportFormat) -> Unit,
    onOpenFile: (AgeExportResult) -> Unit,
    onShareFile: (AgeExportResult) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedReportType by remember { mutableStateOf(AgeExportReportType.DETAILED_CHILDREN) }
    var selectedFormat by remember { mutableStateOf(AgeExportFormat.XLSX) }

    Dialog(
        onDismissRequest = { if (!isExporting) onDismiss() },
        properties = DialogProperties(
            dismissOnBackPress = !isExporting,
            dismissOnClickOutside = !isExporting,
            usePlatformDefaultWidth = false
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFFF9FCFB),
                border = BorderStroke(1.dp, Color(0xFFCDE5D9)),
                shadowElevation = 0.dp,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // الرأس
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFFE0F2FE)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.FileDownload,
                                    contentDescription = null,
                                    tint = Color(0xFF0369A1),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "تصدير حسب الفلتر الحالي",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = if (ageFilter.isAnyChildFilterActive) {
                                        "${ageFilter.buildSummaryLabel()} • $matchedFamiliesCount أسرة • $matchedChildrenCount ابن"
                                    } else {
                                        "كافة النتائج المطابقة الحالية ($matchedFamiliesCount أسرة)"
                                    },
                                    fontSize = 11.sp,
                                    color = Color(0xFF0F766E),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (!isExporting) {
                            IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color(0xFF475569))
                            }
                        }
                    }

                    when {
                        isExporting -> {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Color.White.copy(alpha = 0.92f),
                                border = BorderStroke(1.dp, Color(0xFFD6E8DF)),
                                shadowElevation = 0.dp,
                                tonalElevation = 0.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(34.dp),
                                        strokeWidth = 3.dp,
                                        color = Color(0xFF0F7B53)
                                    )
                                    Text(
                                        text = "جاري إنشاء ملف التصدير المتدفق...",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = Color(0xFF0F172A)
                                    )
                                    val prog = exportProgress
                                    if (prog != null && prog.totalFamilies > 0) {
                                        val frac = (prog.processedFamilies.toFloat() / prog.totalFamilies.toFloat()).coerceIn(0f, 1f)
                                        LinearProgressIndicator(
                                            progress = { frac },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(8.dp)
                                                .clip(RoundedCornerShape(6.dp)),
                                            color = Color(0xFF0F7B53),
                                            trackColor = Color(0xFFE2E8F0)
                                        )
                                        Text(
                                            text = "تمت معالجة ${prog.processedFamilies} / ${prog.totalFamilies} أسرة (${prog.exportedRows} صف)",
                                            fontSize = 11.sp,
                                            color = Color(0xFF475569)
                                        )
                                    }
                                }
                            }
                        }

                        exportResult != null -> {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Color(0xFFECFDF5),
                                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.4f)),
                                shadowElevation = 0.dp,
                                tonalElevation = 0.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = Color(0xFF059669),
                                            modifier = Modifier.size(22.dp)
                                        )
                                        Text(
                                            text = "تم إنشاء ملف التصدير بنجاح",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFF065F46)
                                        )
                                    }
                                    Text(
                                        text = "اسم الملف: ${exportResult.displayFileName}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF0F172A)
                                    )
                                    Text(
                                        text = "الصفوف المُصدّرة: ${exportResult.exportedRowsCount}  •  الأسر: ${exportResult.familiesCount}  •  الأبناء: ${exportResult.childrenCount}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF334155)
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { onOpenFile(exportResult) },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F7B53)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("فتح الملف", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { onShareFile(exportResult) },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("مشاركة الملف", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            TextButton(
                                onClick = onDismiss,
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text("إغلاق", fontWeight = FontWeight.Bold)
                            }
                        }

                        else -> {
                            if (!exportError.isNullOrBlank()) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFFFEF2F2),
                                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                    shadowElevation = 0.dp,
                                    tonalElevation = 0.dp,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = exportError,
                                        fontSize = 11.sp,
                                        color = Color(0xFFB91C1C),
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }

                            Text(
                                text = "1. نوع التقرير",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F5E59)
                            )

                            SelectableOptionCard(
                                title = "تقرير تفصيلي للأبناء (صف لكل ابن)",
                                subtitle = "هوية واسم وجوال ومنطقة رب الأسرة + هوية واسم وجنس وتاريخ ميلاد وعمر الابن التفصيلي",
                                selected = selectedReportType == AgeExportReportType.DETAILED_CHILDREN,
                                onClick = { selectedReportType = AgeExportReportType.DETAILED_CHILDREN }
                            )

                            SelectableOptionCard(
                                title = "تقرير ملخص للأسر (صف لكل أسرة)",
                                subtitle = "بيانات رب الأسرة الأساسية + عدد الأبناء المطابقين + عمود أسماء الأبناء وأعمارهم التفصيلية",
                                selected = selectedReportType == AgeExportReportType.SUMMARY_FAMILIES,
                                onClick = { selectedReportType = AgeExportReportType.SUMMARY_FAMILIES }
                            )

                            Text(
                                text = "2. صيغة الملف",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F5E59)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                AgeExportFormat.values().forEach { fmt ->
                                    val selected = selectedFormat == fmt
                                    Surface(
                                        onClick = { selectedFormat = fmt },
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (selected) Color(0xFF0F7B53) else Color.White.copy(alpha = 0.9f),
                                        border = BorderStroke(
                                            1.dp,
                                            if (selected) Color(0xFF0F7B53) else Color(0xFFD6E8DF)
                                        ),
                                        shadowElevation = 0.dp,
                                        tonalElevation = 0.dp,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(44.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 8.dp)) {
                                            Text(
                                                text = fmt.labelAr,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (selected) Color.White else Color(0xFF334155),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = onDismiss,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.weight(0.38f)
                                ) {
                                    Text("إلغاء", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { onStartExport(selectedReportType, selectedFormat) },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F7B53)),
                                    modifier = Modifier.weight(0.62f)
                                ) {
                                    Icon(Icons.Rounded.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("بدء التصدير", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 3. نافذة إعداد وتأكيد التحديث الجماعي لأبناء جميع الأسر الرسمية دفعة واحدة
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BulkUpdateChildrenConfigDialog(
    totalOfficialFamilies: Int,
    onStartBulkSync: (
        allAges: Boolean,
        minYears: Int,
        minMonths: Int,
        maxYears: Int,
        maxMonths: Int,
        mode: AidRepository.BulkChildrenUpdateMode
    ) -> Unit,
    onDismiss: () -> Unit
) {
    var allAges by remember { mutableStateOf(true) }
    var minYearsText by remember { mutableStateOf("0") }
    var minMonthsText by remember { mutableStateOf("0") }
    var maxYearsText by remember { mutableStateOf("18") }
    var maxMonthsText by remember { mutableStateOf("0") }
    var selectedMode by remember { mutableStateOf(AidRepository.BulkChildrenUpdateMode.ADD_AND_FILL_MISSING) }

    val minY = minYearsText.toIntOrNull()?.coerceIn(0, 120) ?: 0
    val minM = minMonthsText.toIntOrNull()?.coerceIn(0, 11) ?: 0
    val maxY = maxYearsText.toIntOrNull()?.coerceIn(0, 120) ?: 0
    val maxM = maxMonthsText.toIntOrNull()?.coerceIn(0, 11) ?: 0

    val previewRange = remember(allAges, minY, minM, maxY, maxM) {
        if (allAges) null
        else ExactAgeUtil.computeBirthDateRangeForAgeFilter(minY, minM, maxY, maxM)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFFF9FCFB),
                border = BorderStroke(1.dp, Color(0xFFCDE5D9)),
                shadowElevation = 0.dp,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFFE6F4EA)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Sync,
                                    contentDescription = null,
                                    tint = Color(0xFF0F7B53),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "تحديث جماعي لأبناء الأسر الرسمية",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Text(
                                    text = "سحب مفهرس بدفعات 500 أسرة من children_registry",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                        IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color(0xFF475569))
                        }
                    }

                    // بطاقة توضيحية للسرعة والأمان
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFFEFF6FF),
                        border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                        shadowElevation = 0.dp,
                        tonalElevation = 0.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = Color(0xFF1D4ED8),
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "سيتم فحص جميع الأسر الرسمية المصرح بها (${if (totalOfficialFamilies > 0) totalOfficialFamilies else "الكل"}) بدفعات سريعة مع منع التكرار برقم هوية الابن وعدم حذف أي ابن مسجل سابقاً.",
                                fontSize = 11.sp,
                                color = Color(0xFF1E3A8A),
                                lineHeight = 16.sp
                            )
                        }
                    }

                    // النطاق العمري
                    Text(
                        text = "1. النطاق العمري المطلوب تحديثه",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F5E59)
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = allAges,
                            onClick = { allAges = true },
                            label = { Text("جميع الأعمار", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF0F7B53),
                                selectedLabelColor = Color.White,
                                containerColor = Color.White.copy(alpha = 0.9f)
                            )
                        )
                        QUICK_AGE_PRESETS.filter { !it.isClear }.forEach { preset ->
                            val isSelected = !allAges &&
                                minY == preset.minYears &&
                                minM == preset.minMonths &&
                                maxY == preset.maxYears &&
                                maxM == preset.maxMonths
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    allAges = false
                                    minYearsText = preset.minYears.toString()
                                    minMonthsText = preset.minMonths.toString()
                                    maxYearsText = preset.maxYears.toString()
                                    maxMonthsText = preset.maxMonths.toString()
                                },
                                label = { Text(preset.label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF0F7B53),
                                    selectedLabelColor = Color.White,
                                    containerColor = Color.White.copy(alpha = 0.9f)
                                )
                            )
                        }
                    }

                    if (!allAges) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White.copy(alpha = 0.92f),
                            border = BorderStroke(1.dp, Color(0xFFD6E8DF)),
                            shadowElevation = 0.dp,
                            tonalElevation = 0.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text("من عمر:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F7B53))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = minYearsText,
                                        onValueChange = { minYearsText = it.filter { c -> c.isDigit() }.take(3) },
                                        label = { Text("سنوات", fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = minMonthsText,
                                        onValueChange = { v ->
                                            val d = v.filter { c -> c.isDigit() }.take(2)
                                            minMonthsText = if ((d.toIntOrNull() ?: 0) > 11) "11" else d
                                        },
                                        label = { Text("شهور", fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                Text("إلى عمر:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F7B53))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = maxYearsText,
                                        onValueChange = { maxYearsText = it.filter { c -> c.isDigit() }.take(3) },
                                        label = { Text("سنوات", fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                    OutlinedTextField(
                                        value = maxMonthsText,
                                        onValueChange = { v ->
                                            val d = v.filter { c -> c.isDigit() }.take(2)
                                            maxMonthsText = if ((d.toIntOrNull() ?: 0) > 11) "11" else d
                                        },
                                        label = { Text("شهور", fontSize = 11.sp) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                if (previewRange != null) {
                                    Text(
                                        text = "تواريخ الميلاد المستهدفة: ${previewRange.first}  ←  ${previewRange.second}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF065F46)
                                    )
                                }
                            }
                        }
                    }

                    // وضع التحديث
                    Text(
                        text = "2. وضع التحديث",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F5E59)
                    )

                    SelectableOptionCard(
                        title = "إضافة الجدد + استكمال الحقول الناقصة للمسجّلين",
                        subtitle = "يضيف الأبناء غير المسجلين ويكمل الحقول الفارغة (تاريخ الميلاد، الاسم، المنطقة...) دون حذف أي سجل.",
                        selected = selectedMode == AidRepository.BulkChildrenUpdateMode.ADD_AND_FILL_MISSING,
                        onClick = { selectedMode = AidRepository.BulkChildrenUpdateMode.ADD_AND_FILL_MISSING }
                    )

                    SelectableOptionCard(
                        title = "إضافة الأبناء الجدد فقط",
                        subtitle = "يضيف الأبناء غير المسجلين مسبقاً ويتجاهل تماماً أي سجل موجود بالفعل برقم الهوية.",
                        selected = selectedMode == AidRepository.BulkChildrenUpdateMode.ADD_ONLY,
                        onClick = { selectedMode = AidRepository.BulkChildrenUpdateMode.ADD_ONLY }
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.weight(0.36f)
                        ) {
                            Text("إلغاء", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                onStartBulkSync(allAges, minY, minM, maxY, maxM, selectedMode)
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F7B53)),
                            modifier = Modifier.weight(0.64f)
                        ) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("بدء التحديث الجماعي", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

/**
 * 4. نافذة التقدم الحي غير القابلة للإغلاق العشوائي أثناء التحديث الجماعي للأبناء
 */
@Composable
fun BulkUpdateChildrenProgressDialog(
    progress: AidRepository.BulkChildrenSyncProgress,
    onCancel: () -> Unit
) {
    Dialog(
        onDismissRequest = { /* غير قابلة للإغلاق العشوائي؛ الإيقاف حصراً عبر زر إلغاء العملية */ },
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFFF9FCFB),
                border = BorderStroke(1.dp, Color(0xFFCDE5D9)),
                shadowElevation = 0.dp,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE6F4EA)),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(28.dp),
                            strokeWidth = 3.dp,
                            color = Color(0xFF0F7B53)
                        )
                    }

                    Text(
                        text = "جاري التحديث الجماعي للأبناء...",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )

                    Text(
                        text = progress.stageMessage,
                        fontSize = 12.sp,
                        color = Color(0xFF475569)
                    )

                    if (progress.totalFamilies > 0) {
                        LinearProgressIndicator(
                            progress = { progress.fraction },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(6.dp)),
                            color = Color(0xFF0F7B53),
                            trackColor = Color(0xFFE2E8F0)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "الأسر المفحوصة: ${progress.processedFamilies} / ${progress.totalFamilies}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF334155)
                            )
                            Text(
                                text = "${progress.percent}%",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F7B53)
                            )
                        }
                    } else {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(6.dp)),
                            color = Color(0xFF0F7B53),
                            trackColor = Color(0xFFE2E8F0)
                        )
                    }

                    // عدادات لحظية
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LiveStatMiniBox(
                            label = "أبناء مضافون",
                            value = progress.addedChildren.toString(),
                            color = Color(0xFF059669),
                            bg = Color(0xFFECFDF5),
                            modifier = Modifier.weight(1f)
                        )
                        LiveStatMiniBox(
                            label = "تم تحديثهم",
                            value = progress.updatedChildren.toString(),
                            color = Color(0xFF0284C7),
                            bg = Color(0xFFE0F2FE),
                            modifier = Modifier.weight(1f)
                        )
                        LiveStatMiniBox(
                            label = "أسر محدّثة",
                            value = progress.affectedFamilies.toString(),
                            color = Color(0xFF7C3AED),
                            bg = Color(0xFFF3E8FF),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedButton(
                        onClick = onCancel,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFDC2626)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إلغاء العملية", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * 5. نافذة التقرير النهائي التفصيلي بعد اكتمال أو إيقاف التحديث الجماعي للأبناء
 */
@Composable
fun BulkUpdateChildrenSummaryDialog(
    report: AidRepository.BulkChildrenSyncReport,
    onDismiss: () -> Unit
) {
    val hasError = !report.errorMessage.isNullOrBlank()
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFFF9FCFB),
                border = BorderStroke(1.dp, Color(0xFFCDE5D9)),
                shadowElevation = 0.dp,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    when {
                                        hasError -> Color(0xFFFEE2E2)
                                        report.wasCancelled -> Color(0xFFFEF3C7)
                                        else -> Color(0xFFDCFCE7)
                                    }
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when {
                                    hasError -> Icons.Default.ErrorOutline
                                    report.wasCancelled -> Icons.Default.WarningAmber
                                    else -> Icons.Default.TaskAlt
                                },
                                contentDescription = null,
                                tint = when {
                                    hasError -> Color(0xFFB91C1C)
                                    report.wasCancelled -> Color(0xFFB45309)
                                    else -> Color(0xFF15803D)
                                },
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = when {
                                    hasError -> "تعذر إكمال التحديث الجماعي"
                                    report.wasCancelled -> "تم إيقاف التحديث الجماعي (نتائج جزئية)"
                                    else -> "اكتمل التحديث الجماعي للأبناء"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )
                            if (report.isUsingSampleFallback && !hasError) {
                                Text(
                                    text = "تم الفحص من البيانات التجريبية لعدم ربط civil_registry.db الفعلي",
                                    fontSize = 10.sp,
                                    color = Color(0xFFB45309)
                                )
                            }
                        }
                    }

                    if (hasError) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFFFEF2F2),
                            border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                            shadowElevation = 0.dp,
                            tonalElevation = 0.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = report.errorMessage.orEmpty(),
                                fontSize = 12.sp,
                                color = Color(0xFF991B1B),
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.White.copy(alpha = 0.94f),
                            border = BorderStroke(1.dp, Color(0xFFD6E8DF)),
                            shadowElevation = 0.dp,
                            tonalElevation = 0.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                SummaryMetricRow(
                                    label = "إجمالي الأسر التي تم فحصها",
                                    value = "${report.totalFamiliesChecked} أسرة",
                                    valueColor = Color(0xFF0F172A)
                                )
                                HorizontalDivider(color = Color(0xFFE2E8F0))
                                SummaryMetricRow(
                                    label = "الأسر التي أُضيف أو حُدّث لها أبناء",
                                    value = "${report.affectedFamiliesCount} أسرة",
                                    valueColor = Color(0xFF0F766E)
                                )
                                HorizontalDivider(color = Color(0xFFE2E8F0))
                                SummaryMetricRow(
                                    label = "عدد الأبناء الجدد المضافين",
                                    value = "${report.addedChildrenCount} ابن",
                                    valueColor = Color(0xFF059669)
                                )
                                HorizontalDivider(color = Color(0xFFE2E8F0))
                                SummaryMetricRow(
                                    label = "عدد السجلات التي تم تحديثها",
                                    value = "${report.updatedChildrenCount} سجل",
                                    valueColor = Color(0xFF0284C7)
                                )
                                HorizontalDivider(color = Color(0xFFE2E8F0))
                                SummaryMetricRow(
                                    label = "السجلات المتجاهلة لوجودها مسبقاً",
                                    value = "${report.skippedChildrenCount} سجل",
                                    valueColor = Color(0xFF64748B)
                                )
                            }
                        }
                    }

                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F7B53)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("تم", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SelectableOptionCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = if (selected) Color(0xFFECFDF5) else Color.White.copy(alpha = 0.9f),
        border = BorderStroke(
            width = if (selected) 1.5.dp else 1.dp,
            color = if (selected) Color(0xFF0F7B53) else Color(0xFFD6E8DF)
        ),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RadioButton(
                selected = selected,
                onClick = null,
                colors = RadioButtonDefaults.colors(selectedColor = Color(0xFF0F7B53))
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Text(
                    text = subtitle,
                    fontSize = 10.5.sp,
                    color = Color(0xFF475569),
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
private fun LiveStatMiniBox(
    label: String,
    value: String,
    color: Color,
    bg: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bg,
        shadowElevation = 0.dp,
        tonalElevation = 0.dp,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = color)
            Text(text = label, fontSize = 9.5.sp, color = Color(0xFF334155), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun SummaryMetricRow(
    label: String,
    value: String,
    valueColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color(0xFF475569),
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            fontSize = 13.sp,
            color = valueColor,
            fontWeight = FontWeight.ExtraBold
        )
    }
}
