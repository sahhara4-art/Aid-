package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SyncDetailsDialog(
    onDismiss: () -> Unit,
    onForceSync: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تفاصيل المزامنة السحابية", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("قاعدة البيانات المحلية تعمل بدون إنترنت بنسبة 100%.")
                Text("تتم مزامنة التعديلات السحابية تلقائياً عند توفر الاتصال عبر بروتوكول Delta Sync.")
            }
        },
        confirmButton = {
            Button(onClick = onForceSync) {
                Text("مزامنة فورية الآن")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}
