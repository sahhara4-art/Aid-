package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.local.entities.SyncLogEntity
import com.humanitarian.aidmanagement.data.local.entities.SyncQueueEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun SyncDetailsDialog(
    repository: AidRepository,
    onDismiss: () -> Unit
) {
    val syncState by repository.getSyncState().collectAsStateWithLifecycle()
    val pendingItems by repository.getPendingSyncItems().collectAsStateWithLifecycle(initialValue = emptyList())
    val syncLogs by repository.getRecentSyncLogs().collectAsStateWithLifecycle(initialValue = emptyList())
    val recentMergedDeltas by repository.getRecentMergedDeltas().collectAsStateWithLifecycle()

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CloudSync,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "محرك التزامن اللحظي (Google Firebase Firestore)",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "بنية Offline-First: قاعدة بيانات Room المحلية هي المصدر الوحيد للحقيقة",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // بطاقة حالة الاتصال السحابي وFirebase
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (syncState.isOnline) Color(0xFF10B981).copy(alpha = 0.12f)
                        else Color(0xFFF59E0B).copy(alpha = 0.12f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(RoundedCornerShape(5.dp))
                                            .background(if (syncState.isOnline) Color(0xFF10B981) else Color(0xFFF59E0B))
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (syncState.isOnline) "متصل بالإنترنت (Online)" else "وضع دون اتصال (Offline)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (syncState.isOnline) Color(0xFF10B981) else Color(0xFFD97706)
                                    )
                                }
                                Text(
                                    text = "حركات معلقة في Room: ${syncState.pendingCount} | مرفوع: ${syncState.totalDeltasUploaded}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )
                            }

                            Button(
                                onClick = { repository.triggerSyncNow() },
                                enabled = syncState.isOnline && !syncState.isSyncing,
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                if (syncState.isSyncing) {
                                    CircularProgressIndicator(
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(14.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("رفع الآن", fontSize = 11.sp)
                                }
                            }
                        }

                        // شريط حالة وسيط Firebase Realtime Database
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.7f))
                                .padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Bolt,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = if (syncState.firebaseConnected) Color(0xFF0284C7) else Color(0xFF64748B)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (syncState.firebaseConnected) "Firebase Realtime: نشط ومتصل" else "Firebase Realtime: قيد الاستعداد/محلي",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                            Text(
                                text = "حركات مدمجة: ${syncState.totalDeltasMerged}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PalestineGreen
                            )
                        }
                    }
                }

                // محاكي انقطاع وعودة الإنترنت للتجربة الفورية
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "محاكاة انقطاع الإنترنت (تجربة أوفلاين):",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "جرّب تسليم مساعدة ثم أعد تشغيله لتشاهد رفع الـ Delta التلقائي فوراً",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                        Switch(
                            checked = syncState.isSimulatedOffline,
                            onCheckedChange = { repository.toggleOfflineSimulation() }
                        )
                    }
                }

                HorizontalDivider()

                // قائمة الحركات المعلقة في قاعدة بيانات Room
                Text(
                    text = "طابور التزامن في Room (${pendingItems.size} حركة معلقة للرفع):",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )

                if (pendingItems.isEmpty()) {
                    Text(
                        text = "لا توجد حركات معلقة. كافة السجلات مرفوعة بالكامل إلى Firebase ✅",
                        fontSize = 11.sp,
                        color = Color(0xFF10B981)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        pendingItems.take(3).forEach { item ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = when (item.entityType) {
                                                "AID_RECORD" -> "صرف مساعدة (${item.operation})"
                                                "FAMILY" -> "سجل أسرة (${item.operation})"
                                                else -> "${item.entityType} (${item.operation})"
                                            },
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                        Text(
                                            text = dateFormat.format(Date(item.createdAt)),
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFFF59E0B).copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = item.status,
                                            color = Color(0xFFD97706),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // الحركات المدمجة تلقائياً (Master Auto-Merge Stream)
                if (recentMergedDeltas.isNotEmpty()) {
                    HorizontalDivider()
                    Text(
                        text = "أحدث الحركات المدمجة تلقائياً في جهازك (Auto-Merged):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = PalestineGreen
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        recentMergedDeltas.take(3).forEach { delta ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFF10B981).copy(alpha = 0.08f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 5.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "${delta.userName} • محلية ${delta.localityName.ifBlank { delta.localityId.toString() }}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${delta.entityType} [${delta.operation}] - سجل #${delta.recordId}",
                                            fontSize = 9.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                        )
                                    }
                                    Text(
                                        text = "مدمج ✅",
                                        fontSize = 9.sp,
                                        color = PalestineGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}

private val PalestineGreen = Color(0xFF007A3D)
