package com.humanitarian.aidmanagement.data.backup

/**
 * حالات متتبع خطوات الاستعادة اللحظي (Restore Progress Tracker)
 */
sealed class RestoreState {
    object IDLE : RestoreState()
    object DOWNLOADING : RestoreState()
    object UNZIPPING : RestoreState()
    object COPYING_FILES : RestoreState()
    object VERIFYING_INTEGRITY : RestoreState()
    object SUCCESS : RestoreState()
    data class ERROR(val message: String, val step: String) : RestoreState()

    val stepIndex: Int
        get() = when (this) {
            is IDLE -> 0
            is DOWNLOADING -> 1
            is UNZIPPING -> 2
            is COPYING_FILES -> 3
            is VERIFYING_INTEGRITY -> 4
            is SUCCESS -> 5
            is ERROR -> -1
        }

    val displayTitle: String
        get() = when (this) {
            is IDLE -> "جاهز للاستعادة"
            is DOWNLOADING -> "1/4: جاري تحميل ملف النسخة الاحتياطية"
            is UNZIPPING -> "2/4: جاري فك ضغط واستخراج ملفات القاعدة"
            is COPYING_FILES -> "3/4: جاري استبدال وكتابة ملف قاعدة البيانات"
            is VERIFYING_INTEGRITY -> "4/4: جاري التحقق من سلامة وصحة الجداول"
            is SUCCESS -> "اكتملت الاستعادة بنجاح"
            is ERROR -> "فشلت الاستعادة في مرحلة: $step"
        }

    val displayDetail: String
        get() = when (this) {
            is IDLE -> "بانتظار بدء عملية الاستعادة..."
            is DOWNLOADING -> "يتم تنزيل حزمة النسخة الاحتياطية تدفقياً عبر الشبكة إلى مجلد العزل المؤقت."
            is UNZIPPING -> "يتم فحص محتويات الحزمة واستخراج ملف قاعدة البيانات SQLite الرئيسي."
            is COPYING_FILES -> "يتم إغلاق اتصالات Room وكتابة الملف الجديد مع إجبار التفريغ العتادي على القرص (fd.sync)."
            is VERIFYING_INTEGRITY -> "يتم فحص ترويسة SQLite وقراءة مخطط الجداول للتأكد من خلوه من التلف."
            is SUCCESS -> "تم استبدال قاعدة البيانات بنجاح والتحقق من جاهزيتها الكاملة."
            is ERROR -> message
        }
}
