package com.humanitarian.aidmanagement.ui.screens.excel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.util.ChildExportColumnRegistry
import com.humanitarian.aidmanagement.util.ExportColumnRegistry
import com.humanitarian.aidmanagement.util.ProjectExportColumnRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream

enum class DynamicEntityType(val label: String, val description: String, val icon: String) {
    FAMILIES("مواطنون / أسر", "سجلات أرباب الأسر، السكن، الأضرار، والدخل", "👨‍👩‍👧"),
    PROJECTS("مشاريع إغاثية", "المشاريع المنفذة، الممولين، وحصص الترشيح", "📦"),
    CHILDREN("أبناء وتابعون", "سجلات الأطفال والتابعين وتواريخ الميلاد", "👶")
}

enum class DynamicExportFormat(val label: String, val extension: String, val mimeType: String) {
    EXCEL("ملف إكسل معتمد (.xlsx / .csv)", "csv", "text/csv"),
    PDF("مستند كشف رسمي (.pdf)", "pdf", "application/pdf")
}

class DynamicExportViewModel(
    private val repository: AidRepository
) : ViewModel() {

    // 1. الكيان المختار
    private val _selectedEntity = MutableStateFlow(DynamicEntityType.FAMILIES)
    val selectedEntity: StateFlow<DynamicEntityType> = _selectedEntity.asStateFlow()

    // 2. الفلاتر الديناميكية للأسر (مع Toggle تفعيل/استثناء)
    var toggleApproval = MutableStateFlow(false)
    var selectedApproval = MutableStateFlow("معتمد")

    var toggleLocality = MutableStateFlow(false)
    var selectedLocalityId = MutableStateFlow(0)
    var selectedLocalityName = MutableStateFlow("")

    var toggleWorks = MutableStateFlow(false)
    var selectedWorks = MutableStateFlow("اعتماد أشغال")

    var toggleDamage = MutableStateFlow(false)
    var selectedDamage = MutableStateFlow("أضرار كلية")

    var toggleMarital = MutableStateFlow(false)
    var selectedMarital = MutableStateFlow("متزوج")

    var toggleMembers = MutableStateFlow(false)
    var minMembers = MutableStateFlow(1)
    var maxMembers = MutableStateFlow(15)

    // فلاتر المشاريع
    var toggleProjectActive = MutableStateFlow(false)
    var selectedProjectActive = MutableStateFlow(true)
    var toggleProjectAidType = MutableStateFlow(false)
    var selectedProjectAidTypeId = MutableStateFlow(0)

    // فلاتر الأطفال
    var toggleChildGender = MutableStateFlow(false)
    var selectedChildGender = MutableStateFlow("ذكر")
    var toggleChildShelter = MutableStateFlow(false)
    var selectedChildShelter = MutableStateFlow("إيواء داخلي")
    var toggleChildLocality = MutableStateFlow(false)
    var selectedChildLocalityId = MutableStateFlow(0)

    // 3. المعاينة الحية (LIMIT 50 & No ANR)
    private val _isLoadingPreview = MutableStateFlow(false)
    val isLoadingPreview: StateFlow<Boolean> = _isLoadingPreview.asStateFlow()

    private val _previewFamilies = MutableStateFlow<List<FamilyEntity>>(emptyList())
    val previewFamilies: StateFlow<List<FamilyEntity>> = _previewFamilies.asStateFlow()

    private val _previewProjects = MutableStateFlow<List<ProjectEntity>>(emptyList())
    val previewProjects: StateFlow<List<ProjectEntity>> = _previewProjects.asStateFlow()

    private val _previewChildren = MutableStateFlow<List<ChildEntity>>(emptyList())
    val previewChildren: StateFlow<List<ChildEntity>> = _previewChildren.asStateFlow()

    private val _totalMatchingCount = MutableStateFlow(0)
    val totalMatchingCount: StateFlow<Int> = _totalMatchingCount.asStateFlow()

    // 4. تخصيص الأعمدة وصيغة التصدير
    private val _selectedColumnKeys = MutableStateFlow<Set<String>>(ExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet())
    val selectedColumnKeys: StateFlow<Set<String>> = _selectedColumnKeys.asStateFlow()

    private val _selectedFormat = MutableStateFlow(DynamicExportFormat.EXCEL)
    val selectedFormat: StateFlow<DynamicExportFormat> = _selectedFormat.asStateFlow()

    // مؤشرات التصدير
    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    private val _exportProgress = MutableStateFlow(0f)
    val exportProgress: StateFlow<Float> = _exportProgress.asStateFlow()

    private val _exportStatusMessage = MutableStateFlow<String?>(null)
    val exportStatusMessage: StateFlow<String?> = _exportStatusMessage.asStateFlow()

    init {
        loadPreview()
    }

    fun selectEntity(entity: DynamicEntityType) {
        _selectedEntity.value = entity
        // تحديث الأعمدة الافتراضية المناسبة للكيان
        when (entity) {
            DynamicEntityType.FAMILIES -> _selectedColumnKeys.value = ExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
            DynamicEntityType.PROJECTS -> _selectedColumnKeys.value = ProjectExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
            DynamicEntityType.CHILDREN -> _selectedColumnKeys.value = ChildExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
        }
        loadPreview()
    }

    fun setFormat(format: DynamicExportFormat) {
        _selectedFormat.value = format
    }

    fun toggleColumnKey(key: String) {
        val current = _selectedColumnKeys.value.toMutableSet()
        if (current.contains(key)) {
            current.remove(key)
        } else {
            current.add(key)
        }
        _selectedColumnKeys.value = current
    }

    fun selectAllColumns() {
        when (_selectedEntity.value) {
            DynamicEntityType.FAMILIES -> _selectedColumnKeys.value = ExportColumnRegistry.ALL_COLUMNS.map { it.key }.toSet()
            DynamicEntityType.PROJECTS -> _selectedColumnKeys.value = ProjectExportColumnRegistry.ALL_COLUMNS.map { it.key }.toSet()
            DynamicEntityType.CHILDREN -> _selectedColumnKeys.value = ChildExportColumnRegistry.ALL_COLUMNS.map { it.key }.toSet()
        }
    }

    fun selectDefaultColumns() {
        when (_selectedEntity.value) {
            DynamicEntityType.FAMILIES -> _selectedColumnKeys.value = ExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
            DynamicEntityType.PROJECTS -> _selectedColumnKeys.value = ProjectExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
            DynamicEntityType.CHILDREN -> _selectedColumnKeys.value = ChildExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
        }
    }

    fun clearAllColumns() {
        _selectedColumnKeys.value = emptySet()
    }

    private var previewJob: Job? = null

    /**
     * تشغيل استعلام المعاينة السريعة (High Performance Preview - LIMIT 50)
     */
    fun loadPreview() {
        previewJob?.cancel()
        previewJob = viewModelScope.launch(Dispatchers.IO) {
            _isLoadingPreview.value = true
            try {
                when (_selectedEntity.value) {
                    DynamicEntityType.FAMILIES -> {
                        val preview = repository.getDynamicFilteredFamiliesPreview(
                            ignoreApproval = !toggleApproval.value,
                            approval = selectedApproval.value,
                            ignoreLocality = !toggleLocality.value,
                            localityId = selectedLocalityId.value,
                            localityName = selectedLocalityName.value,
                            ignoreWorks = !toggleWorks.value,
                            worksApproval = selectedWorks.value,
                            ignoreDamage = !toggleDamage.value,
                            damageType = selectedDamage.value,
                            ignoreMarital = !toggleMarital.value,
                            maritalStatus = selectedMarital.value,
                            ignoreMembers = !toggleMembers.value,
                            minMembers = minMembers.value,
                            maxMembers = maxMembers.value
                        )
                        val total = repository.countDynamicFilteredFamilies(
                            ignoreApproval = !toggleApproval.value,
                            approval = selectedApproval.value,
                            ignoreLocality = !toggleLocality.value,
                            localityId = selectedLocalityId.value,
                            localityName = selectedLocalityName.value,
                            ignoreWorks = !toggleWorks.value,
                            worksApproval = selectedWorks.value,
                            ignoreDamage = !toggleDamage.value,
                            damageType = selectedDamage.value,
                            ignoreMarital = !toggleMarital.value,
                            maritalStatus = selectedMarital.value,
                            ignoreMembers = !toggleMembers.value,
                            minMembers = minMembers.value,
                            maxMembers = maxMembers.value
                        )
                        _previewFamilies.value = preview
                        _totalMatchingCount.value = total
                    }
                    DynamicEntityType.PROJECTS -> {
                        val preview = repository.getDynamicFilteredProjectsPreview(
                            ignoreActive = !toggleProjectActive.value,
                            isActive = selectedProjectActive.value,
                            ignoreAidType = !toggleProjectAidType.value,
                            aidTypeId = selectedProjectAidTypeId.value
                        )
                        val total = repository.countDynamicFilteredProjects(
                            ignoreActive = !toggleProjectActive.value,
                            isActive = selectedProjectActive.value,
                            ignoreAidType = !toggleProjectAidType.value,
                            aidTypeId = selectedProjectAidTypeId.value
                        )
                        _previewProjects.value = preview
                        _totalMatchingCount.value = total
                    }
                    DynamicEntityType.CHILDREN -> {
                        val preview = repository.getDynamicFilteredChildrenPreview(
                            ignoreGender = !toggleChildGender.value,
                            gender = selectedChildGender.value,
                            ignoreShelter = !toggleChildShelter.value,
                            shelterStatus = selectedChildShelter.value,
                            ignoreLocality = !toggleChildLocality.value,
                            localityId = selectedChildLocalityId.value
                        )
                        val total = repository.countDynamicFilteredChildren(
                            ignoreGender = !toggleChildGender.value,
                            gender = selectedChildGender.value,
                            ignoreShelter = !toggleChildShelter.value,
                            shelterStatus = selectedChildShelter.value,
                            ignoreLocality = !toggleChildLocality.value,
                            localityId = selectedChildLocalityId.value
                        )
                        _previewChildren.value = preview
                        _totalMatchingCount.value = total
                    }
                }
            } catch (e: Exception) {
                _totalMatchingCount.value = 0
            } finally {
                _isLoadingPreview.value = false
            }
        }
    }

    /**
     * تنفيذ التصدير الكامل المخصص (Full Data Export without LIMIT)
     */
    suspend fun exportFullDataToUri(
        context: Context,
        uri: Uri,
        title: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        _isExporting.value = true
        _exportProgress.value = 0.1f
        try {
            val selectedKeysList = _selectedColumnKeys.value.toList()
            if (selectedKeysList.isEmpty()) {
                return@withContext Result.failure(Exception("يرجى تحديد عمود واحد على الأقل للتصدير."))
            }

            val format = _selectedFormat.value
            val entity = _selectedEntity.value

            _exportProgress.value = 0.3f

            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مسار الحفظ عبر نظام التخزين."))

            when (entity) {
                DynamicEntityType.FAMILIES -> {
                    val fullList = repository.getDynamicFilteredFamiliesFull(
                        ignoreApproval = !toggleApproval.value,
                        approval = selectedApproval.value,
                        ignoreLocality = !toggleLocality.value,
                        localityId = selectedLocalityId.value,
                        localityName = selectedLocalityName.value,
                        ignoreWorks = !toggleWorks.value,
                        worksApproval = selectedWorks.value,
                        ignoreDamage = !toggleDamage.value,
                        damageType = selectedDamage.value,
                        ignoreMarital = !toggleMarital.value,
                        maritalStatus = selectedMarital.value,
                        ignoreMembers = !toggleMembers.value,
                        minMembers = minMembers.value,
                        maxMembers = maxMembers.value
                    )
                    _exportProgress.value = 0.6f

                    val defs = ExportColumnRegistry.getOrderedDefs(selectedKeysList)
                    val sb = StringBuilder()
                    sb.append("\uFEFF") // UTF-8 BOM
                    sb.append(escapeCsv(title)).append("\n\n")

                    // الترويسة
                    val headerLine = defs.joinToString(",") { escapeCsv(it.label) }
                    sb.append(headerLine).append("\n")

                    // الأسطر
                    fullList.forEachIndexed { idx, fam ->
                        val row = defs.joinToString(",") { def ->
                            escapeCsv(def.valueExtractor(fam, null, idx + 1))
                        }
                        sb.append(row).append("\n")
                    }

                    outputStream.use { os ->
                        os.write(sb.toString().toByteArray(Charsets.UTF_8))
                        os.flush()
                    }
                }
                DynamicEntityType.PROJECTS -> {
                    val fullList = repository.getDynamicFilteredProjectsFull(
                        ignoreActive = !toggleProjectActive.value,
                        isActive = selectedProjectActive.value,
                        ignoreAidType = !toggleProjectAidType.value,
                        aidTypeId = selectedProjectAidTypeId.value
                    )
                    _exportProgress.value = 0.6f

                    val defs = ProjectExportColumnRegistry.getOrderedDefs(selectedKeysList)
                    val sb = StringBuilder()
                    sb.append("\uFEFF")
                    sb.append(escapeCsv(title)).append("\n\n")
                    sb.append(defs.joinToString(",") { escapeCsv(it.label) }).append("\n")

                    fullList.forEachIndexed { idx, prj ->
                        val row = defs.joinToString(",") { def ->
                            escapeCsv(def.valueExtractor(prj, idx + 1))
                        }
                        sb.append(row).append("\n")
                    }

                    outputStream.use { os ->
                        os.write(sb.toString().toByteArray(Charsets.UTF_8))
                        os.flush()
                    }
                }
                DynamicEntityType.CHILDREN -> {
                    val fullList = repository.getDynamicFilteredChildrenFull(
                        ignoreGender = !toggleChildGender.value,
                        gender = selectedChildGender.value,
                        ignoreShelter = !toggleChildShelter.value,
                        shelterStatus = selectedChildShelter.value,
                        ignoreLocality = !toggleChildLocality.value,
                        localityId = selectedChildLocalityId.value
                    )
                    _exportProgress.value = 0.6f

                    val defs = ChildExportColumnRegistry.getOrderedDefs(selectedKeysList)
                    val sb = StringBuilder()
                    sb.append("\uFEFF")
                    sb.append(escapeCsv(title)).append("\n\n")
                    sb.append(defs.joinToString(",") { escapeCsv(it.label) }).append("\n")

                    fullList.forEachIndexed { idx, child ->
                        val row = defs.joinToString(",") { def ->
                            escapeCsv(def.valueExtractor(child, idx + 1))
                        }
                        sb.append(row).append("\n")
                    }

                    outputStream.use { os ->
                        os.write(sb.toString().toByteArray(Charsets.UTF_8))
                        os.flush()
                    }
                }
            }

            _exportProgress.value = 1.0f
            _exportStatusMessage.value = "تم إكمال التصدير بنجاح وحفظ الملف في التخزين المختار."
            Result.success(Unit)
        } catch (t: Throwable) {
            _exportStatusMessage.value = "فشل التصدير: ${t.message}"
            Result.failure(Exception(t.message ?: "حدث خطأ غير متوقع", t))
        } finally {
            _isExporting.value = false
        }
    }

    fun resetFilters() {
        toggleApproval.value = false
        selectedApproval.value = "معتمد"
        toggleLocality.value = false
        selectedLocalityId.value = 0
        selectedLocalityName.value = ""
        toggleWorks.value = false
        selectedWorks.value = "اعتماد أشغال"
        toggleDamage.value = false
        selectedDamage.value = "أضرار كلية"
        toggleMarital.value = false
        selectedMarital.value = "متزوج"
        toggleMembers.value = false
        minMembers.value = 1
        maxMembers.value = 15
        toggleProjectActive.value = false
        selectedProjectActive.value = true
        toggleProjectAidType.value = false
        selectedProjectAidTypeId.value = 0
        toggleChildGender.value = false
        selectedChildGender.value = "ذكر"
        toggleChildShelter.value = false
        selectedChildShelter.value = "إيواء داخلي"
        toggleChildLocality.value = false
        selectedChildLocalityId.value = 0
        selectDefaultColumns()
        _exportStatusMessage.value = null
    }

    fun clearState() {
        previewJob?.cancel()
        _previewFamilies.value = emptyList()
        _previewProjects.value = emptyList()
        _previewChildren.value = emptyList()
        _totalMatchingCount.value = 0
        _isLoadingPreview.value = false
        _isExporting.value = false
        _exportProgress.value = 0f
        resetFilters()
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    private fun escapeCsv(value: String): String {
        var str = value.trim()
        if (str.contains(",") || str.contains("\"") || str.contains("\n") || str.contains("\r")) {
            str = str.replace("\"", "\"\"")
            return "\"$str\""
        }
        return str
    }
}

class DynamicExportViewModelFactory(
    private val repository: AidRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DynamicExportViewModel::class.java)) {
            return DynamicExportViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
