package com.humanitarian.aidmanagement.ui.screens.excel

import android.content.Context
import android.graphics.Color as AndroidGraphicsColor
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.sqlite.db.SimpleSQLiteQuery
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.DynamicExportFilterOptions
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.util.ChildExportColumnRegistry
import com.humanitarian.aidmanagement.util.ExportColumnRegistry
import com.humanitarian.aidmanagement.util.ProjectExportColumnRegistry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.HorizontalAlignment
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.ss.usermodel.VerticalAlignment
import org.apache.poi.xssf.streaming.SXSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class DynamicEntityType(val label: String, val description: String) {
    FAMILIES("مواطنون / أسر", "سجلات أرباب الأسر، السكن، الأضرار، والدخل"),
    PROJECTS("مشاريع إغاثية", "المشاريع المنفذة، الممولين، وحصص الترشيح"),
    CHILDREN("أبناء وتابعون", "سجلات الأطفال والتابعين وتواريخ الميلاد")
}

enum class DynamicExportFormat(val label: String, val extension: String, val mimeType: String) {
    EXCEL_XLSX(
        "تصدير إكسل (.xlsx)",
        "xlsx",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ),
    EXCEL_CSV("تصدير إكسل سريع (.csv)", "csv", "text/csv"),
    PDF("تصدير كشف رسمي (.pdf)", "pdf", "application/pdf")
}

data class MultiSelectFilterState(
    val selected: Set<String> = emptySet(),
    val exclude: Boolean = false
)

data class MembersRangeFilterState(
    val enabled: Boolean = false,
    val minMembers: Int = 1,
    val maxMembers: Int = 15,
    val exclude: Boolean = false
)

class DynamicExportViewModel(
    private val repository: AidRepository
) : ViewModel() {

    // 1. الكيان المختار
    private val _selectedEntity = MutableStateFlow(DynamicEntityType.FAMILIES)
    val selectedEntity: StateFlow<DynamicEntityType> = _selectedEntity.asStateFlow()

    // 2. الخيارات الديناميكية القادمة مباشرة من SQLite (Zero Hardcoded Lists)
    private val _filterOptions = MutableStateFlow(DynamicExportFilterOptions())
    val filterOptions: StateFlow<DynamicExportFilterOptions> = _filterOptions.asStateFlow()

    // 3. حالات الفلاتر متعددة الاختيار مع مفتاح الاستثناء (Auto-Bypass when selected is empty)
    // فلاتر الأسر
    private val _approvalFilter = MutableStateFlow(MultiSelectFilterState())
    val approvalFilter: StateFlow<MultiSelectFilterState> = _approvalFilter.asStateFlow()

    private val _localityApprovalFilter = MutableStateFlow(MultiSelectFilterState())
    val localityApprovalFilter: StateFlow<MultiSelectFilterState> = _localityApprovalFilter.asStateFlow()

    private val _localityFilter = MutableStateFlow(MultiSelectFilterState())
    val localityFilter: StateFlow<MultiSelectFilterState> = _localityFilter.asStateFlow()

    private val _currentMainAreaFilter = MutableStateFlow(MultiSelectFilterState())
    val currentMainAreaFilter: StateFlow<MultiSelectFilterState> = _currentMainAreaFilter.asStateFlow()

    private val _currentSubAreaFilter = MutableStateFlow(MultiSelectFilterState())
    val currentSubAreaFilter: StateFlow<MultiSelectFilterState> = _currentSubAreaFilter.asStateFlow()

    private val _branchFilter = MutableStateFlow(MultiSelectFilterState())
    val branchFilter: StateFlow<MultiSelectFilterState> = _branchFilter.asStateFlow()

    private val _worksFilter = MutableStateFlow(MultiSelectFilterState())
    val worksFilter: StateFlow<MultiSelectFilterState> = _worksFilter.asStateFlow()

    private val _damageFilter = MutableStateFlow(MultiSelectFilterState())
    val damageFilter: StateFlow<MultiSelectFilterState> = _damageFilter.asStateFlow()

    private val _maritalFilter = MutableStateFlow(MultiSelectFilterState())
    val maritalFilter: StateFlow<MultiSelectFilterState> = _maritalFilter.asStateFlow()

    private val _injuryFilter = MutableStateFlow(MultiSelectFilterState())
    val injuryFilter: StateFlow<MultiSelectFilterState> = _injuryFilter.asStateFlow()

    private val _shelterFilter = MutableStateFlow(MultiSelectFilterState())
    val shelterFilter: StateFlow<MultiSelectFilterState> = _shelterFilter.asStateFlow()

    private val _shelterCenterFilter = MutableStateFlow(MultiSelectFilterState())
    val shelterCenterFilter: StateFlow<MultiSelectFilterState> = _shelterCenterFilter.asStateFlow()

    private val _residentFilter = MutableStateFlow(MultiSelectFilterState())
    val residentFilter: StateFlow<MultiSelectFilterState> = _residentFilter.asStateFlow()

    private val _membersRangeFilter = MutableStateFlow(MembersRangeFilterState())
    val membersRangeFilter: StateFlow<MembersRangeFilterState> = _membersRangeFilter.asStateFlow()

    // فلاتر المشاريع
    private val _projectLocalityFilter = MutableStateFlow(MultiSelectFilterState())
    val projectLocalityFilter: StateFlow<MultiSelectFilterState> = _projectLocalityFilter.asStateFlow()

    private val _projectStatusFilter = MutableStateFlow(MultiSelectFilterState())
    val projectStatusFilter: StateFlow<MultiSelectFilterState> = _projectStatusFilter.asStateFlow()

    private val _projectAidTypeFilter = MutableStateFlow(MultiSelectFilterState())
    val projectAidTypeFilter: StateFlow<MultiSelectFilterState> = _projectAidTypeFilter.asStateFlow()

    private val _projectFunderFilter = MutableStateFlow(MultiSelectFilterState())
    val projectFunderFilter: StateFlow<MultiSelectFilterState> = _projectFunderFilter.asStateFlow()

    private val _projectWarehouseFilter = MutableStateFlow(MultiSelectFilterState())
    val projectWarehouseFilter: StateFlow<MultiSelectFilterState> = _projectWarehouseFilter.asStateFlow()

    // فلاتر الأبناء
    private val _childGenderFilter = MutableStateFlow(MultiSelectFilterState())
    val childGenderFilter: StateFlow<MultiSelectFilterState> = _childGenderFilter.asStateFlow()

    private val _childShelterFilter = MutableStateFlow(MultiSelectFilterState())
    val childShelterFilter: StateFlow<MultiSelectFilterState> = _childShelterFilter.asStateFlow()

    private val _childLocalityFilter = MutableStateFlow(MultiSelectFilterState())
    val childLocalityFilter: StateFlow<MultiSelectFilterState> = _childLocalityFilter.asStateFlow()

    private val _childSubAreaFilter = MutableStateFlow(MultiSelectFilterState())
    val childSubAreaFilter: StateFlow<MultiSelectFilterState> = _childSubAreaFilter.asStateFlow()

    // 4. نطاق العزل الجغرافي الصارم (Row-Level Security Scope)
    private val _allowedLocalities = MutableStateFlow<List<LocalityEntity>>(emptyList())
    val allowedLocalities: StateFlow<List<LocalityEntity>> = _allowedLocalities.asStateFlow()

    private val _residenceLocationOptions = MutableStateFlow<List<String>>(emptyList())
    val residenceLocationOptions: StateFlow<List<String>> = _residenceLocationOptions.asStateFlow()

    private val _residentStatusOptions = MutableStateFlow<List<String>>(emptyList())
    val residentStatusOptions: StateFlow<List<String>> = _residentStatusOptions.asStateFlow()

    private val _approvalStatusOptions = MutableStateFlow<List<String>>(emptyList())
    val approvalStatusOptions: StateFlow<List<String>> = _approvalStatusOptions.asStateFlow()

    private val _maritalStatusOptions = MutableStateFlow<List<String>>(emptyList())
    val maritalStatusOptions: StateFlow<List<String>> = _maritalStatusOptions.asStateFlow()

    private val _currentSubAreaOptions = MutableStateFlow<List<String>>(emptyList())
    val currentSubAreaOptions: StateFlow<List<String>> = _currentSubAreaOptions.asStateFlow()

    private val _isLocalityLocked = MutableStateFlow(false)
    val isLocalityLocked: StateFlow<Boolean> = _isLocalityLocked.asStateFlow()

    private val _lockedLocalityName = MutableStateFlow<String?>(null)
    val lockedLocalityName: StateFlow<String?> = _lockedLocalityName.asStateFlow()

    private val _allowedBranches = MutableStateFlow<List<String>>(emptyList())
    val allowedBranches: StateFlow<List<String>> = _allowedBranches.asStateFlow()

    private val _isBranchLocked = MutableStateFlow(false)
    val isBranchLocked: StateFlow<Boolean> = _isBranchLocked.asStateFlow()

    private val _lockedBranchName = MutableStateFlow<String?>(null)
    val lockedBranchName: StateFlow<String?> = _lockedBranchName.asStateFlow()

    // 5. المعاينة الحية (LIMIT 50 & Zero ANR)
    private val _isLoadingPreview = MutableStateFlow(false)
    val isLoadingPreview: StateFlow<Boolean> = _isLoadingPreview.asStateFlow()

    private val _previewFamilies = MutableStateFlow<List<FamilyEntity>>(emptyList())
    val previewFamilies: StateFlow<List<FamilyEntity>> = _previewFamilies.asStateFlow()

    private val _previewProjects = MutableStateFlow<List<ProjectEntity>>(emptyList())
    val previewProjects: StateFlow<List<ProjectEntity>> = _previewProjects.asStateFlow()

    private val _previewChildren = MutableStateFlow<List<ChildEntity>>(emptyList())
    val previewChildren: StateFlow<List<ChildEntity>> = _previewChildren.asStateFlow()

    private val _totalMatchingCount = MutableStateFlow(0)
    val totalMatchingCount: StateFlow<Int> = _totalMatchingCount.asStateFlow()

    // 6. تخصيص الأعمدة وحالة التصدير
    private val _selectedColumnKeys = MutableStateFlow(ExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet())
    val selectedColumnKeys: StateFlow<Set<String>> = _selectedColumnKeys.asStateFlow()

    private val _selectedExcelFormat = MutableStateFlow(DynamicExportFormat.EXCEL_XLSX)
    val selectedExcelFormat: StateFlow<DynamicExportFormat> = _selectedExcelFormat.asStateFlow()

    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    private val _exportProgress = MutableStateFlow(0f)
    val exportProgress: StateFlow<Float> = _exportProgress.asStateFlow()

    private val _exportStatusMessage = MutableStateFlow<String?>(null)
    val exportStatusMessage: StateFlow<String?> = _exportStatusMessage.asStateFlow()

    // ذاكرة مؤقتة لنطاق RLS الفعلي للاستخدام المتزامن داخل بناء الاستعلام
    @Volatile
    private var cachedLocalityScope: Pair<Int, List<String>> = 1 to listOf("__ALL__")

    @Volatile
    private var cachedBranchScope: Pair<Int, List<String>> = 1 to listOf("__ALL__")

    private var previewJob: Job? = null

    init {
        refreshGeographicalScope()
        viewModelScope.launch {
            AccessControlManager.currentUser.drop(1).collect {
                refreshGeographicalScope()
            }
        }
    }

    fun refreshGeographicalScope() {
        viewModelScope.launch(Dispatchers.IO) {
            val loadedOptions = repository.getDynamicExportFilterOptions()
            _filterOptions.value = loadedOptions

            val (ignoreLoc, allowedNames) = repository.getEffectiveLocalityScope()
            cachedLocalityScope = ignoreLoc to allowedNames
            val allowedLocEntities = loadedOptions.allowedLocalities
            _allowedLocalities.value = allowedLocEntities
            _residenceLocationOptions.value = loadedOptions.residenceLocalities
            _residentStatusOptions.value = loadedOptions.residentStatuses
            _approvalStatusOptions.value = loadedOptions.approvals
            _maritalStatusOptions.value = loadedOptions.maritalStatuses
            _currentSubAreaOptions.value = loadedOptions.currentSubAreas

            if (ignoreLoc == 1) {
                _isLocalityLocked.value = false
                _lockedLocalityName.value = null
            } else {
                val validNames = allowedNames.filter { it != "__DENY__" && it != "__ALL__" }
                if (allowedLocEntities.size == 1 || validNames.size == 1) {
                    val singleName = allowedLocEntities.firstOrNull()?.LocalityName
                        ?: validNames.firstOrNull()
                        ?: ""
                    _isLocalityLocked.value = true
                    _lockedLocalityName.value = singleName
                    val lockedSet = if (singleName.isNotBlank()) setOf(singleName) else emptySet()
                    _localityFilter.value = MultiSelectFilterState(selected = lockedSet, exclude = false)
                    _projectLocalityFilter.value = MultiSelectFilterState(selected = lockedSet, exclude = false)
                    _childLocalityFilter.value = MultiSelectFilterState(selected = lockedSet, exclude = false)
                } else {
                    _isLocalityLocked.value = false
                    _lockedLocalityName.value = null
                    val allowedNameSet = allowedLocEntities.map { it.LocalityName.trim() }.toSet() +
                        validNames.map { it.trim() }.toSet()
                    _localityFilter.value = _localityFilter.value.copy(
                        selected = _localityFilter.value.selected.filter { sel ->
                            allowedNameSet.any { it.equals(sel.trim(), ignoreCase = true) }
                        }.toSet()
                    )
                    _projectLocalityFilter.value = _projectLocalityFilter.value.copy(
                        selected = _projectLocalityFilter.value.selected.filter { sel ->
                            allowedNameSet.any { it.equals(sel.trim(), ignoreCase = true) }
                        }.toSet()
                    )
                    _childLocalityFilter.value = _childLocalityFilter.value.copy(
                        selected = _childLocalityFilter.value.selected.filter { sel ->
                            allowedNameSet.any { it.equals(sel.trim(), ignoreCase = true) }
                        }.toSet()
                    )
                }
            }

            val (ignoreBr, allowedBranchNames) = repository.getEffectiveBranchScope()
            cachedBranchScope = ignoreBr to allowedBranchNames
            _allowedBranches.value = loadedOptions.allowedBranches

            if (ignoreBr == 1) {
                _isBranchLocked.value = false
                _lockedBranchName.value = null
            } else {
                val validBranchNames = allowedBranchNames.filter { it != "__DENY__" && it != "__ALL__" }
                if (validBranchNames.size == 1 || loadedOptions.allowedBranches.size == 1) {
                    val singleBr = loadedOptions.allowedBranches.firstOrNull()
                        ?: validBranchNames.firstOrNull()
                        ?: ""
                    _isBranchLocked.value = true
                    _lockedBranchName.value = singleBr
                    val lockedBrSet = if (singleBr.isNotBlank()) setOf(singleBr) else emptySet()
                    _branchFilter.value = MultiSelectFilterState(selected = lockedBrSet, exclude = false)
                } else {
                    _isBranchLocked.value = false
                    _lockedBranchName.value = null
                    val allowedBranchSet = loadedOptions.allowedBranches.toSet() + validBranchNames.toSet()
                    _branchFilter.value = _branchFilter.value.copy(
                        selected = _branchFilter.value.selected.filter { sel ->
                            allowedBranchSet.any { it.equals(sel.trim(), ignoreCase = true) }
                        }.toSet()
                    )
                }
            }

            loadPreview()
        }
    }

    fun selectEntity(entity: DynamicEntityType) {
        _selectedEntity.value = entity
        when (entity) {
            DynamicEntityType.FAMILIES -> _selectedColumnKeys.value = ExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
            DynamicEntityType.PROJECTS -> _selectedColumnKeys.value = ProjectExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
            DynamicEntityType.CHILDREN -> _selectedColumnKeys.value = ChildExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
        }
        loadPreview()
    }

    // =========================================================================
    // دوال تحديث الفلاتر متعددة الاختيار + الاستثناء
    // =========================================================================

    private fun MutableStateFlow<MultiSelectFilterState>.toggleItem(value: String) {
        val current = this.value
        val nextSelected = if (current.selected.contains(value)) {
            current.selected - value
        } else {
            current.selected + value
        }
        this.value = current.copy(selected = nextSelected)
        loadPreview()
    }

    private fun MutableStateFlow<MultiSelectFilterState>.setExcludeMode(exclude: Boolean) {
        this.value = this.value.copy(exclude = exclude)
        if (this.value.selected.isNotEmpty()) {
            loadPreview()
        }
    }

    private fun MutableStateFlow<MultiSelectFilterState>.clearSelection() {
        this.value = MultiSelectFilterState()
        loadPreview()
    }

    // فلاتر الأسر
    fun toggleApprovalValue(value: String) = _approvalFilter.toggleItem(value)
    fun setApprovalExclude(exclude: Boolean) = _approvalFilter.setExcludeMode(exclude)
    fun clearApprovalFilter() = _approvalFilter.clearSelection()

    fun toggleLocalityApprovalValue(value: String) = _localityApprovalFilter.toggleItem(value)
    fun setLocalityApprovalExclude(exclude: Boolean) = _localityApprovalFilter.setExcludeMode(exclude)
    fun clearLocalityApprovalFilter() = _localityApprovalFilter.clearSelection()

    fun toggleLocalityValue(value: String) {
        if (_isLocalityLocked.value) return
        _localityFilter.toggleItem(value)
    }

    fun setLocalityExclude(exclude: Boolean) {
        if (_isLocalityLocked.value) return
        _localityFilter.setExcludeMode(exclude)
    }

    fun clearLocalityFilter() {
        if (_isLocalityLocked.value) return
        _localityFilter.clearSelection()
    }

    fun toggleCurrentMainAreaValue(value: String) = _currentMainAreaFilter.toggleItem(value)
    fun setCurrentMainAreaExclude(exclude: Boolean) = _currentMainAreaFilter.setExcludeMode(exclude)
    fun clearCurrentMainAreaFilter() = _currentMainAreaFilter.clearSelection()

    fun toggleCurrentSubAreaValue(value: String) = _currentSubAreaFilter.toggleItem(value)
    fun setCurrentSubAreaExclude(exclude: Boolean) = _currentSubAreaFilter.setExcludeMode(exclude)
    fun clearCurrentSubAreaFilter() = _currentSubAreaFilter.clearSelection()

    fun toggleBranchValue(value: String) {
        if (_isBranchLocked.value) return
        _branchFilter.toggleItem(value)
    }

    fun setBranchExclude(exclude: Boolean) {
        if (_isBranchLocked.value) return
        _branchFilter.setExcludeMode(exclude)
    }

    fun clearBranchFilter() {
        if (_isBranchLocked.value) return
        _branchFilter.clearSelection()
    }

    fun toggleWorksValue(value: String) = _worksFilter.toggleItem(value)
    fun setWorksExclude(exclude: Boolean) = _worksFilter.setExcludeMode(exclude)
    fun clearWorksFilter() = _worksFilter.clearSelection()

    fun toggleDamageValue(value: String) = _damageFilter.toggleItem(value)
    fun setDamageExclude(exclude: Boolean) = _damageFilter.setExcludeMode(exclude)
    fun clearDamageFilter() = _damageFilter.clearSelection()

    fun toggleMaritalValue(value: String) = _maritalFilter.toggleItem(value)
    fun setMaritalExclude(exclude: Boolean) = _maritalFilter.setExcludeMode(exclude)
    fun clearMaritalFilter() = _maritalFilter.clearSelection()

    fun toggleInjuryValue(value: String) = _injuryFilter.toggleItem(value)
    fun setInjuryExclude(exclude: Boolean) = _injuryFilter.setExcludeMode(exclude)
    fun clearInjuryFilter() = _injuryFilter.clearSelection()

    fun toggleShelterValue(value: String) = _shelterFilter.toggleItem(value)
    fun setShelterExclude(exclude: Boolean) = _shelterFilter.setExcludeMode(exclude)
    fun clearShelterFilter() = _shelterFilter.clearSelection()

    fun toggleShelterCenterValue(value: String) = _shelterCenterFilter.toggleItem(value)
    fun setShelterCenterExclude(exclude: Boolean) = _shelterCenterFilter.setExcludeMode(exclude)
    fun clearShelterCenterFilter() = _shelterCenterFilter.clearSelection()

    fun toggleResidentValue(value: String) = _residentFilter.toggleItem(value)
    fun setResidentExclude(exclude: Boolean) = _residentFilter.setExcludeMode(exclude)
    fun clearResidentFilter() = _residentFilter.clearSelection()

    fun setMembersRangeEnabled(enabled: Boolean) {
        _membersRangeFilter.value = _membersRangeFilter.value.copy(enabled = enabled)
        loadPreview()
    }

    fun setMembersRangeBounds(minMembers: Int, maxMembers: Int) {
        val safeMin = minMembers.coerceAtLeast(1)
        val safeMax = maxMembers.coerceAtLeast(safeMin)
        _membersRangeFilter.value = _membersRangeFilter.value.copy(
            minMembers = safeMin,
            maxMembers = safeMax
        )
        if (_membersRangeFilter.value.enabled) {
            loadPreview()
        }
    }

    fun setMembersRangeExclude(exclude: Boolean) {
        _membersRangeFilter.value = _membersRangeFilter.value.copy(exclude = exclude)
        if (_membersRangeFilter.value.enabled) {
            loadPreview()
        }
    }

    // فلاتر المشاريع
    fun toggleProjectLocalityValue(value: String) {
        if (_isLocalityLocked.value) return
        _projectLocalityFilter.toggleItem(value)
    }

    fun setProjectLocalityExclude(exclude: Boolean) {
        if (_isLocalityLocked.value) return
        _projectLocalityFilter.setExcludeMode(exclude)
    }

    fun clearProjectLocalityFilter() {
        if (_isLocalityLocked.value) return
        _projectLocalityFilter.clearSelection()
    }

    fun toggleProjectStatusValue(value: String) = _projectStatusFilter.toggleItem(value)
    fun setProjectStatusExclude(exclude: Boolean) = _projectStatusFilter.setExcludeMode(exclude)
    fun clearProjectStatusFilter() = _projectStatusFilter.clearSelection()

    fun toggleProjectAidTypeValue(value: String) = _projectAidTypeFilter.toggleItem(value)
    fun setProjectAidTypeExclude(exclude: Boolean) = _projectAidTypeFilter.setExcludeMode(exclude)
    fun clearProjectAidTypeFilter() = _projectAidTypeFilter.clearSelection()

    fun toggleProjectFunderValue(value: String) = _projectFunderFilter.toggleItem(value)
    fun setProjectFunderExclude(exclude: Boolean) = _projectFunderFilter.setExcludeMode(exclude)
    fun clearProjectFunderFilter() = _projectFunderFilter.clearSelection()

    fun toggleProjectWarehouseValue(value: String) = _projectWarehouseFilter.toggleItem(value)
    fun setProjectWarehouseExclude(exclude: Boolean) = _projectWarehouseFilter.setExcludeMode(exclude)
    fun clearProjectWarehouseFilter() = _projectWarehouseFilter.clearSelection()

    // فلاتر الأبناء
    fun toggleChildGenderValue(value: String) = _childGenderFilter.toggleItem(value)
    fun setChildGenderExclude(exclude: Boolean) = _childGenderFilter.setExcludeMode(exclude)
    fun clearChildGenderFilter() = _childGenderFilter.clearSelection()

    fun toggleChildShelterValue(value: String) = _childShelterFilter.toggleItem(value)
    fun setChildShelterExclude(exclude: Boolean) = _childShelterFilter.setExcludeMode(exclude)
    fun clearChildShelterFilter() = _childShelterFilter.clearSelection()

    fun toggleChildLocalityValue(value: String) {
        if (_isLocalityLocked.value) return
        _childLocalityFilter.toggleItem(value)
    }

    fun setChildLocalityExclude(exclude: Boolean) {
        if (_isLocalityLocked.value) return
        _childLocalityFilter.setExcludeMode(exclude)
    }

    fun clearChildLocalityFilter() {
        if (_isLocalityLocked.value) return
        _childLocalityFilter.clearSelection()
    }

    fun toggleChildSubAreaValue(value: String) = _childSubAreaFilter.toggleItem(value)
    fun setChildSubAreaExclude(exclude: Boolean) = _childSubAreaFilter.setExcludeMode(exclude)
    fun clearChildSubAreaFilter() = _childSubAreaFilter.clearSelection()

    fun setExcelFormat(format: DynamicExportFormat) {
        if (format == DynamicExportFormat.EXCEL_XLSX || format == DynamicExportFormat.EXCEL_CSV) {
            _selectedExcelFormat.value = format
        }
    }

    // =========================================================================
    // إدارة الأعمدة المخصصة
    // =========================================================================

    fun toggleColumnKey(key: String) {
        val current = _selectedColumnKeys.value.toMutableSet()
        if (current.contains(key)) {
            current.remove(key)
        } else {
            current.add(key)
        }
        _selectedColumnKeys.value = current
    }

    fun selectAllColumns() {
        when (_selectedEntity.value) {
            DynamicEntityType.FAMILIES -> _selectedColumnKeys.value = ExportColumnRegistry.ALL_COLUMNS.map { it.key }.toSet()
            DynamicEntityType.PROJECTS -> _selectedColumnKeys.value = ProjectExportColumnRegistry.ALL_COLUMNS.map { it.key }.toSet()
            DynamicEntityType.CHILDREN -> _selectedColumnKeys.value = ChildExportColumnRegistry.ALL_COLUMNS.map { it.key }.toSet()
        }
    }

    fun selectDefaultColumns() {
        when (_selectedEntity.value) {
            DynamicEntityType.FAMILIES -> _selectedColumnKeys.value = ExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
            DynamicEntityType.PROJECTS -> _selectedColumnKeys.value = ProjectExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
            DynamicEntityType.CHILDREN -> _selectedColumnKeys.value = ChildExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
        }
    }

    fun clearAllColumns() {
        _selectedColumnKeys.value = emptySet()
    }

    // =========================================================================
    // محرك بناء الاستعلامات الديناميكي 100% (StringBuilder + SimpleSQLiteQuery)
    // يدعم: Auto Bypass عند الفراغ + Multi-Select IN + Exclude NOT IN + Strict RLS
    // =========================================================================

    private fun appendMultiSelectCondition(
        clauses: MutableList<String>,
        args: MutableList<Any>,
        columnExpr: String,
        filter: MultiSelectFilterState
    ) {
        val clean = filter.selected.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (clean.isEmpty()) return // Auto Bypass

        val placeholders = clean.joinToString(",") { "?" }
        if (!filter.exclude) {
            clauses.add("TRIM($columnExpr) IN ($placeholders)")
        } else {
            clauses.add("(TRIM($columnExpr) NOT IN ($placeholders) OR $columnExpr IS NULL OR TRIM($columnExpr) = '')")
        }
        args.addAll(clean)
    }

    private fun appendMultiColumnMultiSelectCondition(
        clauses: MutableList<String>,
        args: MutableList<Any>,
        columns: List<String>,
        filter: MultiSelectFilterState
    ) {
        val clean = filter.selected.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (clean.isEmpty() || columns.isEmpty()) return // Auto Bypass

        val placeholders = clean.joinToString(",") { "?" }
        if (!filter.exclude) {
            val orParts = columns.joinToString(" OR ") { col -> "TRIM($col) IN ($placeholders)" }
            clauses.add("($orParts)")
        } else {
            val andParts = columns.joinToString(" AND ") { col ->
                "(TRIM($col) NOT IN ($placeholders) OR $col IS NULL OR TRIM($col) = '')"
            }
            clauses.add("($andParts)")
        }
        repeat(columns.size) {
            args.addAll(clean)
        }
    }

    private fun appendFamilyRlsClauses(
        clauses: MutableList<String>,
        args: MutableList<Any>,
        locScope: Pair<Int, List<String>>,
        branchScope: Pair<Int, List<String>>,
        tableAlias: String = ""
    ) {
        val p = if (tableAlias.isNotBlank()) "$tableAlias." else ""
        val (ignoreLoc, rawLocs) = locScope
        if (ignoreLoc == 0) {
            val cleanLocs = rawLocs.map { it.trim() }.filter { it.isNotBlank() && it != "__ALL__" }.distinct()
            if (cleanLocs.isEmpty() || cleanLocs.contains("__DENY__")) {
                clauses.add("1 = 0")
            } else {
                val ph = cleanLocs.joinToString(",") { "?" }
                clauses.add(
                    "(TRIM(${p}currentSubArea) IN ($ph) " +
                        "OR TRIM(${p}currentMainArea) IN ($ph) " +
                        "OR ${p}localityID IN (SELECT LocalityID FROM tbl_Localities WHERE TRIM(LocalityName) IN ($ph)))"
                )
                args.addAll(cleanLocs)
                args.addAll(cleanLocs)
                args.addAll(cleanLocs)
            }
        }

        val (ignoreBr, rawBranches) = branchScope
        if (ignoreBr == 0) {
            val cleanBranches = rawBranches.map { it.trim() }.filter { it.isNotBlank() && it != "__ALL__" }.distinct()
            if (cleanBranches.isEmpty() || cleanBranches.contains("__DENY__")) {
                clauses.add("1 = 0")
            } else {
                val ph = cleanBranches.joinToString(",") { "?" }
                clauses.add("TRIM(${p}currentBranch) IN ($ph)")
                args.addAll(cleanBranches)
            }
        }
    }

    private fun buildFamiliesWhereClause(
        locScope: Pair<Int, List<String>>,
        branchScope: Pair<Int, List<String>>
    ): Pair<String, MutableList<Any>> {
        val clauses = mutableListOf<String>()
        val args = mutableListOf<Any>()

        // 1. Strict RLS Scope
        appendFamilyRlsClauses(clauses, args, locScope, branchScope)

        // 2. حالة الاعتماد الحكومي / التنمية واعتماد المحلية
        appendMultiSelectCondition(clauses, args, "developmentApproval", _approvalFilter.value)
        appendMultiSelectCondition(clauses, args, "localityApproval", _localityApprovalFilter.value)

        // 3. المحلية الجغرافية المختارة (متعدد + استثناء)
        val locFilter = _localityFilter.value
        val selectedLocNames = locFilter.selected.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (selectedLocNames.isNotEmpty()) {
            val matchedLocIds = _allowedLocalities.value
                .filter { loc -> selectedLocNames.any { it.equals(loc.LocalityName.trim(), ignoreCase = true) } }
                .map { it.LocalityID }
                .distinct()
            val namePh = selectedLocNames.joinToString(",") { "?" }
            val parts = mutableListOf<String>()
            if (matchedLocIds.isNotEmpty()) {
                val idPh = matchedLocIds.joinToString(",") { "?" }
                parts.add("COALESCE(localityID, -1) IN ($idPh)")
                args.addAll(matchedLocIds)
            }
            parts.add("COALESCE(TRIM(currentSubArea), '') IN ($namePh)")
            args.addAll(selectedLocNames)
            parts.add("COALESCE(TRIM(currentMainArea), '') IN ($namePh)")
            args.addAll(selectedLocNames)
            parts.add("COALESCE(localityID, -1) IN (SELECT LocalityID FROM tbl_Localities WHERE TRIM(LocalityName) IN ($namePh))")
            args.addAll(selectedLocNames)

            val combined = parts.joinToString(" OR ")
            if (!locFilter.exclude) {
                clauses.add("($combined)")
            } else {
                clauses.add("NOT COALESCE(($combined), 0)")
            }
        }

        // 4. مكان الإقامة / النطاق الجغرافي (المنطقة الرئيسية، المنطقة الفرعية، الشعبة، صفة الإقامة، مركز الإيواء)
        appendMultiSelectCondition(clauses, args, "currentMainArea", _currentMainAreaFilter.value)
        appendMultiSelectCondition(clauses, args, "currentSubArea", _currentSubAreaFilter.value)
        appendMultiSelectCondition(clauses, args, "currentBranch", _branchFilter.value)
        appendMultiSelectCondition(clauses, args, "residentStatus", _residentFilter.value)
        appendMultiSelectCondition(clauses, args, "shelter_center_name", _shelterCenterFilter.value)

        // 5. حالة الأشغال / مصدر الدخل
        appendMultiColumnMultiSelectCondition(
            clauses = clauses,
            args = args,
            columns = listOf("worksApproval", "incomeSource1", "income_source_2"),
            filter = _worksFilter.value
        )

        // 6. تصنيف الأضرار وحالة الإصابة
        appendMultiSelectCondition(clauses, args, "damageType", _damageFilter.value)
        appendMultiSelectCondition(clauses, args, "injuryStatus", _injuryFilter.value)

        // 7. الحالة الاجتماعية وحالة الإيواء
        appendMultiSelectCondition(clauses, args, "maritalStatus", _maritalFilter.value)
        appendMultiSelectCondition(clauses, args, "shelterStatus", _shelterFilter.value)

        // 8. عدد أفراد الأسرة (النطاق الاختياري + الاستثناء)
        val members = _membersRangeFilter.value
        if (members.enabled) {
            if (!members.exclude) {
                clauses.add("(familyMembersCount BETWEEN ? AND ?)")
            } else {
                clauses.add("(familyMembersCount < ? OR familyMembersCount > ?)")
            }
            args.add(members.minMembers)
            args.add(members.maxMembers)
        }

        val whereSql = if (clauses.isEmpty()) "" else " WHERE " + clauses.joinToString(" AND ")
        return whereSql to args
    }

    private fun buildProjectsWhereClause(
        locScope: Pair<Int, List<String>>,
        branchScope: Pair<Int, List<String>>
    ): Pair<String, MutableList<Any>> {
        val clauses = mutableListOf<String>()
        val args = mutableListOf<Any>()

        // 1. Strict RLS Scope للمشاريع عبر سجلات الأسر المرتبطة
        val (ignoreLoc, _) = locScope
        val (ignoreBr, _) = branchScope
        if (ignoreLoc == 0 || ignoreBr == 0) {
            val rlsFamilyClauses = mutableListOf<String>()
            appendFamilyRlsClauses(rlsFamilyClauses, args, locScope, branchScope, tableAlias = "f")
            if (rlsFamilyClauses.isNotEmpty()) {
                clauses.add(
                    "projectID IN (SELECT DISTINCT a.projectID FROM aid_records a " +
                        "INNER JOIN families f ON a.familyID = f.familyID " +
                        "WHERE ${rlsFamilyClauses.joinToString(" AND ")})"
                )
            }
        }

        // 2. النطاق الجغرافي / المحلية للمشروع
        val prjLocFilter = _projectLocalityFilter.value
        val selectedLocNames = prjLocFilter.selected.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (selectedLocNames.isNotEmpty()) {
            val matchedLocIds = _allowedLocalities.value
                .filter { loc -> selectedLocNames.any { it.equals(loc.LocalityName.trim(), ignoreCase = true) } }
                .map { it.LocalityID }
                .distinct()
            val namePh = selectedLocNames.joinToString(",") { "?" }
            val famParts = mutableListOf<String>()
            if (matchedLocIds.isNotEmpty()) {
                val idPh = matchedLocIds.joinToString(",") { "?" }
                famParts.add("COALESCE(f.localityID, -1) IN ($idPh)")
                args.addAll(matchedLocIds)
            }
            famParts.add("COALESCE(TRIM(f.currentSubArea), '') IN ($namePh)")
            args.addAll(selectedLocNames)
            famParts.add("COALESCE(TRIM(f.currentMainArea), '') IN ($namePh)")
            args.addAll(selectedLocNames)
            famParts.add("COALESCE(f.localityID, -1) IN (SELECT LocalityID FROM tbl_Localities WHERE TRIM(LocalityName) IN ($namePh))")
            args.addAll(selectedLocNames)

            val subQuery = "projectID IN (SELECT DISTINCT a.projectID FROM aid_records a " +
                "INNER JOIN families f ON a.familyID = f.familyID WHERE ${famParts.joinToString(" OR ")})"
            if (!prjLocFilter.exclude) {
                clauses.add(subQuery)
            } else {
                clauses.add("NOT ($subQuery)")
            }
        }

        // 3. حالة نشاط المشروع (من القيم الفعلية الموجودة)
        val statusFilter = _projectStatusFilter.value
        if (statusFilter.selected.isNotEmpty()) {
            val activeValues = statusFilter.selected.mapNotNull { label ->
                when (label.trim()) {
                    PROJECT_STATUS_ACTIVE_LABEL -> 1
                    PROJECT_STATUS_ARCHIVED_LABEL -> 0
                    else -> null
                }
            }.distinct()
            if (activeValues.isNotEmpty()) {
                val ph = activeValues.joinToString(",") { "?" }
                if (!statusFilter.exclude) {
                    clauses.add("isActive IN ($ph)")
                } else {
                    clauses.add("isActive NOT IN ($ph)")
                }
                args.addAll(activeValues)
            }
        }

        // 4. نوع المعونة
        val aidFilter = _projectAidTypeFilter.value
        if (aidFilter.selected.isNotEmpty()) {
            val selectedIds = _filterOptions.value.projectAidTypes
                .filter { aid -> aidFilter.selected.any { it.trim().equals(aid.aidTypeName.trim(), ignoreCase = true) } }
                .map { it.aidTypeID }
                .distinct()
            if (selectedIds.isNotEmpty()) {
                val ph = selectedIds.joinToString(",") { "?" }
                if (!aidFilter.exclude) {
                    clauses.add("aidTypeID IN ($ph)")
                } else {
                    clauses.add("aidTypeID NOT IN ($ph)")
                }
                args.addAll(selectedIds)
            } else if (!aidFilter.exclude) {
                clauses.add("1 = 0")
            }
        }

        // 5. الجهة الممولة
        appendMultiSelectCondition(clauses, args, "fundingInstitution", _projectFunderFilter.value)

        // 6. المستودع المنفذ
        appendMultiSelectCondition(clauses, args, "warehouseName", _projectWarehouseFilter.value)

        val whereSql = if (clauses.isEmpty()) "" else " WHERE " + clauses.joinToString(" AND ")
        return whereSql to args
    }

    private fun buildChildrenWhereClause(
        locScope: Pair<Int, List<String>>,
        branchScope: Pair<Int, List<String>>
    ): Pair<String, MutableList<Any>> {
        val clauses = mutableListOf<String>()
        val args = mutableListOf<Any>()

        // 1. Strict RLS Scope للأبناء
        val (ignoreLoc, rawLocs) = locScope
        if (ignoreLoc == 0) {
            val cleanLocs = rawLocs.map { it.trim() }.filter { it.isNotBlank() && it != "__ALL__" }.distinct()
            if (cleanLocs.isEmpty() || cleanLocs.contains("__DENY__")) {
                clauses.add("1 = 0")
            } else {
                val ph = cleanLocs.joinToString(",") { "?" }
                clauses.add(
                    "(localityID IN (SELECT LocalityID FROM tbl_Localities WHERE TRIM(LocalityName) IN ($ph)) " +
                        "OR familyNationalID IN (SELECT nationalID FROM families WHERE " +
                        "TRIM(currentSubArea) IN ($ph) OR TRIM(currentMainArea) IN ($ph) " +
                        "OR localityID IN (SELECT LocalityID FROM tbl_Localities WHERE TRIM(LocalityName) IN ($ph))))"
                )
                args.addAll(cleanLocs)
                args.addAll(cleanLocs)
                args.addAll(cleanLocs)
                args.addAll(cleanLocs)
            }
        }

        val (ignoreBr, rawBranches) = branchScope
        if (ignoreBr == 0) {
            val cleanBranches = rawBranches.map { it.trim() }.filter { it.isNotBlank() && it != "__ALL__" }.distinct()
            if (cleanBranches.isEmpty() || cleanBranches.contains("__DENY__")) {
                clauses.add("1 = 0")
            } else {
                val ph = cleanBranches.joinToString(",") { "?" }
                clauses.add("familyNationalID IN (SELECT nationalID FROM families WHERE TRIM(currentBranch) IN ($ph))")
                args.addAll(cleanBranches)
            }
        }

        // 2. جنس الطفل
        appendMultiSelectCondition(clauses, args, "gender", _childGenderFilter.value)

        // 3. حالة الإيواء
        appendMultiSelectCondition(clauses, args, "shelterStatus", _childShelterFilter.value)

        // 4. المحلية المختارة للأبناء
        val locFilter = _childLocalityFilter.value
        val selectedLocNames = locFilter.selected.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (selectedLocNames.isNotEmpty()) {
            val matchedLocIds = _allowedLocalities.value
                .filter { loc -> selectedLocNames.any { it.equals(loc.LocalityName.trim(), ignoreCase = true) } }
                .map { it.LocalityID }
                .distinct()
            val namePh = selectedLocNames.joinToString(",") { "?" }
            val parts = mutableListOf<String>()
            if (matchedLocIds.isNotEmpty()) {
                val idPh = matchedLocIds.joinToString(",") { "?" }
                parts.add("COALESCE(localityID, -1) IN ($idPh)")
                args.addAll(matchedLocIds)
            }
            parts.add("COALESCE(localityID, -1) IN (SELECT LocalityID FROM tbl_Localities WHERE TRIM(LocalityName) IN ($namePh))")
            args.addAll(selectedLocNames)
            parts.add(
                "COALESCE(familyNationalID, '') IN (SELECT nationalID FROM families WHERE " +
                    "COALESCE(TRIM(currentSubArea), '') IN ($namePh) OR COALESCE(TRIM(currentMainArea), '') IN ($namePh))"
            )
            args.addAll(selectedLocNames)
            args.addAll(selectedLocNames)

            val combined = parts.joinToString(" OR ")
            if (!locFilter.exclude) {
                clauses.add("($combined)")
            } else {
                clauses.add("NOT COALESCE(($combined), 0)")
            }
        }

        // 5. مكان الإقامة — المنطقة الفرعية للأبناء (عبر جدول الأسر)
        val subAreaFilter = _childSubAreaFilter.value
        val selectedSubAreas = subAreaFilter.selected.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (selectedSubAreas.isNotEmpty()) {
            val ph = selectedSubAreas.joinToString(",") { "?" }
            val subQuery = "COALESCE(familyNationalID, '') IN (SELECT nationalID FROM families WHERE COALESCE(TRIM(currentSubArea), '') IN ($ph))"
            if (!subAreaFilter.exclude) {
                clauses.add(subQuery)
            } else {
                clauses.add("NOT ($subQuery)")
            }
            args.addAll(selectedSubAreas)
        }

        val whereSql = if (clauses.isEmpty()) "" else " WHERE " + clauses.joinToString(" AND ")
        return whereSql to args
    }

    private fun buildSelectQuery(
        tableName: String,
        whereSql: String,
        baseArgs: List<Any>,
        orderByColumn: String,
        limit: Int? = null,
        offset: Int? = null
    ): SimpleSQLiteQuery {
        val sb = StringBuilder("SELECT * FROM ").append(tableName).append(whereSql)
            .append(" ORDER BY ").append(orderByColumn).append(" DESC")
        val finalArgs = baseArgs.toMutableList()
        if (limit != null) {
            sb.append(" LIMIT ?")
            finalArgs.add(limit)
        }
        if (offset != null) {
            sb.append(" OFFSET ?")
            finalArgs.add(offset)
        }
        return SimpleSQLiteQuery(sb.toString(), finalArgs.toTypedArray())
    }

    private fun buildCountQuery(
        tableName: String,
        whereSql: String,
        baseArgs: List<Any>
    ): SimpleSQLiteQuery {
        val sb = StringBuilder("SELECT COUNT(*) FROM ").append(tableName).append(whereSql)
        return SimpleSQLiteQuery(sb.toString(), baseArgs.toTypedArray())
    }

    /**
     * تشغيل استعلام المعاينة الحية (LIMIT 50 دائماً) وعدد المطابقين بالخلفية (Dispatchers.IO)
     */
    fun loadPreview() {
        previewJob?.cancel()
        previewJob = viewModelScope.launch(Dispatchers.IO) {
            delay(90)
            _isLoadingPreview.value = true
            try {
                val locScope = repository.getEffectiveLocalityScope().also { cachedLocalityScope = it }
                val branchScope = repository.getEffectiveBranchScope().also { cachedBranchScope = it }

                when (_selectedEntity.value) {
                    DynamicEntityType.FAMILIES -> {
                        val (whereSql, args) = buildFamiliesWhereClause(locScope, branchScope)
                        val previewQuery = buildSelectQuery("families", whereSql, args, "familyID", limit = PREVIEW_LIMIT)
                        val countQuery = buildCountQuery("families", whereSql, args)
                        _previewFamilies.value = repository.getFamiliesRaw(previewQuery)
                        _totalMatchingCount.value = repository.countFamiliesRaw(countQuery)
                    }
                    DynamicEntityType.PROJECTS -> {
                        val (whereSql, args) = buildProjectsWhereClause(locScope, branchScope)
                        val previewQuery = buildSelectQuery("projects", whereSql, args, "projectID", limit = PREVIEW_LIMIT)
                        val countQuery = buildCountQuery("projects", whereSql, args)
                        _previewProjects.value = repository.getProjectsRaw(previewQuery)
                        _totalMatchingCount.value = repository.countProjectsRaw(countQuery)
                    }
                    DynamicEntityType.CHILDREN -> {
                        val (whereSql, args) = buildChildrenWhereClause(locScope, branchScope)
                        val previewQuery = buildSelectQuery("children", whereSql, args, "childID", limit = PREVIEW_LIMIT)
                        val countQuery = buildCountQuery("children", whereSql, args)
                        _previewChildren.value = repository.getChildrenRaw(previewQuery)
                        _totalMatchingCount.value = repository.countChildrenRaw(countQuery)
                    }
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (_: Exception) {
                _totalMatchingCount.value = 0
            } finally {
                _isLoadingPreview.value = false
            }
        }
    }

    // =========================================================================
    // التصدير الكامل بدون تجميد (Zero-ANR):
    // 1. Excel (.xlsx via SXSSFWorkbook Streaming + SQLite Cursor row-by-row)
    // 2. Excel Fast (.csv UTF-8 BOM + SQLite Cursor row-by-row)
    // 3. PDF (PdfDocument بالدفعات)
    // =========================================================================

    suspend fun exportFullDataToUri(
        context: Context,
        uri: Uri,
        format: DynamicExportFormat,
        title: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        _isExporting.value = true
        _exportProgress.value = 0.05f
        _exportStatusMessage.value = null
        try {
            val hasExportPerm = when (format) {
                DynamicExportFormat.EXCEL_XLSX,
                DynamicExportFormat.EXCEL_CSV -> AccessControlManager.canExportExcel()
                DynamicExportFormat.PDF -> AccessControlManager.canExportPdf()
            }
            if (!hasExportPerm) {
                return@withContext Result.failure(Exception("ليس لديك صلاحية لتصدير البيانات بصيغة ${format.name}."))
            }

            val selectedKeysList = _selectedColumnKeys.value.toList()
            if (selectedKeysList.isEmpty()) {
                return@withContext Result.failure(Exception("يرجى تحديد عمود واحد على الأقل للتصدير."))
            }

            val locScope = repository.getEffectiveLocalityScope().also { cachedLocalityScope = it }
            val branchScope = repository.getEffectiveBranchScope().also { cachedBranchScope = it }

            val result = when (format) {
                DynamicExportFormat.EXCEL_XLSX -> exportExcelXlsxWithCursor(
                    context = context,
                    uri = uri,
                    title = title,
                    selectedKeysList = selectedKeysList,
                    locScope = locScope,
                    branchScope = branchScope
                )
                DynamicExportFormat.EXCEL_CSV -> exportExcelCsvWithCursor(
                    context = context,
                    uri = uri,
                    title = title,
                    selectedKeysList = selectedKeysList,
                    locScope = locScope,
                    branchScope = branchScope
                )
                DynamicExportFormat.PDF -> exportDynamicPdfDocument(
                    context = context,
                    uri = uri,
                    title = title,
                    selectedKeysList = selectedKeysList,
                    locScope = locScope,
                    branchScope = branchScope
                )
            }

            result.onSuccess {
                _exportProgress.value = 1.0f
                _exportStatusMessage.value = "تم تصدير وحفظ الملف (${format.extension.uppercase(Locale.US)}) بنجاح."
            }.onFailure { err ->
                _exportStatusMessage.value = "فشل التصدير: ${err.message}"
            }
            result
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            val msg = t.message ?: "حدث خطأ غير متوقع أثناء التصدير"
            _exportStatusMessage.value = "فشل التصدير: $msg"
            Result.failure(Exception(msg, t))
        } finally {
            _isExporting.value = false
        }
    }

    private suspend fun exportExcelXlsxWithCursor(
        context: Context,
        uri: Uri,
        title: String,
        selectedKeysList: List<String>,
        locScope: Pair<Int, List<String>>,
        branchScope: Pair<Int, List<String>>
    ): Result<Unit> {
        val entity = _selectedEntity.value
        val totalExpected = _totalMatchingCount.value.coerceAtLeast(1)
        val tempDir = File(context.cacheDir, "dynamic_xlsx").apply { mkdirs() }
        val tempFile = File(tempDir, "export_${System.currentTimeMillis()}.xlsx")
        var workbook: SXSSFWorkbook? = null

        return try {
            val wb = SXSSFWorkbook(100).apply {
                isCompressTempFiles = true
            }
            workbook = wb
            val safeSheetName = entity.label
                .replace(Regex("[\\\\/?*\\[\\]:]"), "-")
                .trim()
                .take(31)
                .ifBlank { "Report" }
            val sheet = wb.createSheet(safeSheetName)
            sheet.isRightToLeft = true

            val headerFont = wb.createFont().apply {
                bold = true
                color = IndexedColors.WHITE.index
                fontHeightInPoints = 11.toShort()
            }
            val headerStyle = wb.createCellStyle().apply {
                setFont(headerFont)
                fillForegroundColor = IndexedColors.DARK_TEAL.index
                fillPattern = FillPatternType.SOLID_FOREGROUND
                alignment = HorizontalAlignment.CENTER
                verticalAlignment = VerticalAlignment.CENTER
            }
            val titleFont = wb.createFont().apply {
                bold = true
                color = IndexedColors.DARK_TEAL.index
                fontHeightInPoints = 13.toShort()
            }
            val titleStyle = wb.createCellStyle().apply {
                setFont(titleFont)
                alignment = HorizontalAlignment.RIGHT
            }

            // صف العنوان
            val titleRow = sheet.createRow(0)
            titleRow.createCell(0).apply {
                setCellValue(title)
                cellStyle = titleStyle
            }

            var currentExcelRow = 2
            var rowIndex = 0

            when (entity) {
                DynamicEntityType.FAMILIES -> {
                    val defs = ExportColumnRegistry.getOrderedDefs(selectedKeysList)
                    if (defs.isEmpty()) return Result.failure(Exception("يرجى اختيار عمود واحد على الأقل."))
                    val headerRow = sheet.createRow(currentExcelRow++)
                    defs.forEachIndexed { colIdx, def ->
                        headerRow.createCell(colIdx).apply {
                            setCellValue(def.label)
                            cellStyle = headerStyle
                        }
                        sheet.setColumnWidth(colIdx, def.excelWidth.coerceAtLeast(2200))
                    }
                    val (whereSql, args) = buildFamiliesWhereClause(locScope, branchScope)
                    val query = buildSelectQuery("families", whereSql, args, "familyID")
                    repository.streamFamiliesCursor(query) { fam ->
                        rowIndex++
                        val dataRow = sheet.createRow(currentExcelRow++)
                        defs.forEachIndexed { colIdx, def ->
                            dataRow.createCell(colIdx).setCellValue(def.valueExtractor(fam, null, rowIndex))
                        }
                        if (rowIndex % 250 == 0) {
                            _exportProgress.value = (0.08f + 0.80f * (rowIndex.toFloat() / totalExpected)).coerceIn(0.08f, 0.88f)
                        }
                    }
                }
                DynamicEntityType.PROJECTS -> {
                    val defs = ProjectExportColumnRegistry.getOrderedDefs(selectedKeysList)
                    if (defs.isEmpty()) return Result.failure(Exception("يرجى اختيار عمود واحد على الأقل."))
                    val headerRow = sheet.createRow(currentExcelRow++)
                    defs.forEachIndexed { colIdx, def ->
                        headerRow.createCell(colIdx).apply {
                            setCellValue(def.label)
                            cellStyle = headerStyle
                        }
                        val colWidth = if (def.key == "row_index") 2000 else if (def.key == "projectName") 8500 else 5000
                        sheet.setColumnWidth(colIdx, colWidth)
                    }
                    val (whereSql, args) = buildProjectsWhereClause(locScope, branchScope)
                    val query = buildSelectQuery("projects", whereSql, args, "projectID")
                    repository.streamProjectsCursor(query) { prj ->
                        rowIndex++
                        val dataRow = sheet.createRow(currentExcelRow++)
                        defs.forEachIndexed { colIdx, def ->
                            dataRow.createCell(colIdx).setCellValue(def.valueExtractor(prj, rowIndex))
                        }
                        if (rowIndex % 250 == 0) {
                            _exportProgress.value = (0.08f + 0.80f * (rowIndex.toFloat() / totalExpected)).coerceIn(0.08f, 0.88f)
                        }
                    }
                }
                DynamicEntityType.CHILDREN -> {
                    val defs = ChildExportColumnRegistry.getOrderedDefs(selectedKeysList)
                    if (defs.isEmpty()) return Result.failure(Exception("يرجى اختيار عمود واحد على الأقل."))
                    val headerRow = sheet.createRow(currentExcelRow++)
                    defs.forEachIndexed { colIdx, def ->
                        headerRow.createCell(colIdx).apply {
                            setCellValue(def.label)
                            cellStyle = headerStyle
                        }
                        val colWidth = if (def.key == "row_index") 2000 else if (def.key == "childName") 8500 else 5000
                        sheet.setColumnWidth(colIdx, colWidth)
                    }
                    val (whereSql, args) = buildChildrenWhereClause(locScope, branchScope)
                    val query = buildSelectQuery("children", whereSql, args, "childID")
                    repository.streamChildrenCursor(query) { child ->
                        rowIndex++
                        val dataRow = sheet.createRow(currentExcelRow++)
                        defs.forEachIndexed { colIdx, def ->
                            dataRow.createCell(colIdx).setCellValue(def.valueExtractor(child, rowIndex))
                        }
                        if (rowIndex % 250 == 0) {
                            _exportProgress.value = (0.08f + 0.80f * (rowIndex.toFloat() / totalExpected)).coerceIn(0.08f, 0.88f)
                        }
                    }
                }
            }

            _exportProgress.value = 0.92f
            FileOutputStream(tempFile).use { fos ->
                wb.write(fos)
                fos.flush()
            }
            try { wb.dispose() } catch (_: Throwable) {}
            try { wb.close() } catch (_: Throwable) {}
            workbook = null

            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return Result.failure(Exception("تعذر فتح مسار الحفظ عبر نظام التخزين."))
            tempFile.inputStream().use { input ->
                outputStream.use { out ->
                    input.copyTo(out)
                    out.flush()
                }
            }
            Result.success(Unit)
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            Result.failure(
                Exception(
                    "تعذر إنشاء ملف XLSX (${t.message ?: "خطأ تقني"}). يُرجى تجربة خيار CSV السريع.",
                    t
                )
            )
        } finally {
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            try { if (tempFile.exists()) tempFile.delete() } catch (_: Throwable) {}
        }
    }

    private suspend fun exportExcelCsvWithCursor(
        context: Context,
        uri: Uri,
        title: String,
        selectedKeysList: List<String>,
        locScope: Pair<Int, List<String>>,
        branchScope: Pair<Int, List<String>>
    ): Result<Unit> {
        val entity = _selectedEntity.value
        val totalExpected = _totalMatchingCount.value.coerceAtLeast(1)

        val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
            ?: return Result.failure(Exception("تعذر فتح مسار الحفظ عبر نظام التخزين."))

        outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
            writer.write("\uFEFF") // UTF-8 BOM
            writer.write(escapeCsv(title) + "\n\n")

            var rowIndex = 0
            val lineBuilder = StringBuilder(256)

            when (entity) {
                DynamicEntityType.FAMILIES -> {
                    val defs = ExportColumnRegistry.getOrderedDefs(selectedKeysList)
                    if (defs.isEmpty()) return Result.failure(Exception("يرجى اختيار عمود واحد على الأقل."))
                    writer.write(defs.joinToString(",") { escapeCsv(it.label) } + "\n")
                    val (whereSql, args) = buildFamiliesWhereClause(locScope, branchScope)
                    val query = buildSelectQuery("families", whereSql, args, "familyID")
                    repository.streamFamiliesCursor(query) { fam ->
                        rowIndex++
                        lineBuilder.setLength(0)
                        for (i in defs.indices) {
                            if (i > 0) lineBuilder.append(',')
                            lineBuilder.append(escapeCsv(defs[i].valueExtractor(fam, null, rowIndex)))
                        }
                        lineBuilder.append('\n')
                        writer.write(lineBuilder.toString())
                        if (rowIndex % 500 == 0) {
                            writer.flush()
                            _exportProgress.value = (0.1f + 0.85f * (rowIndex.toFloat() / totalExpected)).coerceIn(0.1f, 0.95f)
                        }
                    }
                }
                DynamicEntityType.PROJECTS -> {
                    val defs = ProjectExportColumnRegistry.getOrderedDefs(selectedKeysList)
                    if (defs.isEmpty()) return Result.failure(Exception("يرجى اختيار عمود واحد على الأقل."))
                    writer.write(defs.joinToString(",") { escapeCsv(it.label) } + "\n")
                    val (whereSql, args) = buildProjectsWhereClause(locScope, branchScope)
                    val query = buildSelectQuery("projects", whereSql, args, "projectID")
                    repository.streamProjectsCursor(query) { prj ->
                        rowIndex++
                        lineBuilder.setLength(0)
                        for (i in defs.indices) {
                            if (i > 0) lineBuilder.append(',')
                            lineBuilder.append(escapeCsv(defs[i].valueExtractor(prj, rowIndex)))
                        }
                        lineBuilder.append('\n')
                        writer.write(lineBuilder.toString())
                        if (rowIndex % 500 == 0) {
                            writer.flush()
                            _exportProgress.value = (0.1f + 0.85f * (rowIndex.toFloat() / totalExpected)).coerceIn(0.1f, 0.95f)
                        }
                    }
                }
                DynamicEntityType.CHILDREN -> {
                    val defs = ChildExportColumnRegistry.getOrderedDefs(selectedKeysList)
                    if (defs.isEmpty()) return Result.failure(Exception("يرجى اختيار عمود واحد على الأقل."))
                    writer.write(defs.joinToString(",") { escapeCsv(it.label) } + "\n")
                    val (whereSql, args) = buildChildrenWhereClause(locScope, branchScope)
                    val query = buildSelectQuery("children", whereSql, args, "childID")
                    repository.streamChildrenCursor(query) { child ->
                        rowIndex++
                        lineBuilder.setLength(0)
                        for (i in defs.indices) {
                            if (i > 0) lineBuilder.append(',')
                            lineBuilder.append(escapeCsv(defs[i].valueExtractor(child, rowIndex)))
                        }
                        lineBuilder.append('\n')
                        writer.write(lineBuilder.toString())
                        if (rowIndex % 500 == 0) {
                            writer.flush()
                            _exportProgress.value = (0.1f + 0.85f * (rowIndex.toFloat() / totalExpected)).coerceIn(0.1f, 0.95f)
                        }
                    }
                }
            }
            writer.flush()
        }
        return Result.success(Unit)
    }

    private suspend fun exportDynamicPdfDocument(
        context: Context,
        uri: Uri,
        title: String,
        selectedKeysList: List<String>,
        locScope: Pair<Int, List<String>>,
        branchScope: Pair<Int, List<String>>
    ): Result<Unit> {
        val entity = _selectedEntity.value

        data class PdfColumn(val label: String, val weight: Float)

        val columns: List<PdfColumn>
        val rowProvider: suspend (limit: Int, offset: Int, startIndex: Int) -> List<List<String>>

        when (entity) {
            DynamicEntityType.FAMILIES -> {
                val defs = ExportColumnRegistry.getOrderedDefs(selectedKeysList)
                if (defs.isEmpty()) return Result.failure(Exception("يرجى اختيار عمود واحد على الأقل."))
                columns = defs.map { PdfColumn(it.label, it.pdfWeight) }
                val (whereSql, args) = buildFamiliesWhereClause(locScope, branchScope)
                rowProvider = { limit, offset, startIdx ->
                    val chunk = repository.getFamiliesRaw(
                        buildSelectQuery("families", whereSql, args, "familyID", limit, offset)
                    )
                    chunk.mapIndexed { i, fam ->
                        val globalIdx = startIdx + i + 1
                        defs.map { def -> def.valueExtractor(fam, null, globalIdx) }
                    }
                }
            }
            DynamicEntityType.PROJECTS -> {
                val defs = ProjectExportColumnRegistry.getOrderedDefs(selectedKeysList)
                if (defs.isEmpty()) return Result.failure(Exception("يرجى اختيار عمود واحد على الأقل."))
                columns = defs.map {
                    val w = if (it.key == "row_index") 0.5f else if (it.key == "projectName") 2.0f else 1.2f
                    PdfColumn(it.label, w)
                }
                val (whereSql, args) = buildProjectsWhereClause(locScope, branchScope)
                rowProvider = { limit, offset, startIdx ->
                    val chunk = repository.getProjectsRaw(
                        buildSelectQuery("projects", whereSql, args, "projectID", limit, offset)
                    )
                    chunk.mapIndexed { i, prj ->
                        val globalIdx = startIdx + i + 1
                        defs.map { def -> def.valueExtractor(prj, globalIdx) }
                    }
                }
            }
            DynamicEntityType.CHILDREN -> {
                val defs = ChildExportColumnRegistry.getOrderedDefs(selectedKeysList)
                if (defs.isEmpty()) return Result.failure(Exception("يرجى اختيار عمود واحد على الأقل."))
                columns = defs.map {
                    val w = if (it.key == "row_index") 0.5f else if (it.key == "childName") 2.2f else 1.2f
                    PdfColumn(it.label, w)
                }
                val (whereSql, args) = buildChildrenWhereClause(locScope, branchScope)
                rowProvider = { limit, offset, startIdx ->
                    val chunk = repository.getChildrenRaw(
                        buildSelectQuery("children", whereSql, args, "childID", limit, offset)
                    )
                    chunk.mapIndexed { i, child ->
                        val globalIdx = startIdx + i + 1
                        defs.map { def -> def.valueExtractor(child, globalIdx) }
                    }
                }
            }
        }

        val totalMatching = _totalMatchingCount.value.coerceAtLeast(0)
        // حماية الذاكرة عند تصدير PDF من السجلات الضخمة جداً (مع دعم التصدير المتدفق عبر CSV للأحجام غير المحدودة)
        val maxPdfRows = 5000
        val effectiveTotal = totalMatching.coerceAtMost(maxPdfRows)

        val tempDir = File(context.cacheDir, "dynamic_pdf").apply { mkdirs() }
        val tempFile = File(tempDir, "report_${System.currentTimeMillis()}.pdf")
        var pdfDocument: PdfDocument? = null

        try {
            val doc = PdfDocument()
            pdfDocument = doc
            val useLandscape = columns.size > 6
            val pageWidth = if (useLandscape) 842 else 595
            val pageHeight = if (useLandscape) 595 else 842
            val marginH = 24f
            val availableWidth = pageWidth - (marginH * 2)
            val totalWeight = columns.sumOf { it.weight.toDouble() }.toFloat().coerceAtLeast(1f)
            val colWidths = columns.map { (it.weight / totalWeight) * availableWidth }

            val itemsPerPage = if (useLandscape) 18 else 24
            val totalPagesEst = if (effectiveTotal == 0) 1 else ((effectiveTotal - 1) / itemsPerPage) + 1
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
            val userDisplayName = AccessControlManager.getCurrentUser()?.fullName ?: "المستخدم"

            val fillPaint = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
            val strokePaint = Paint().apply { isAntiAlias = true; style = Paint.Style.STROKE; strokeWidth = 0.6f }
            val topBarPaint = Paint().apply { color = AndroidGraphicsColor.rgb(13, 148, 136) }
            val accentBarPaint = Paint().apply { color = AndroidGraphicsColor.rgb(245, 158, 11) }
            val orgPaint = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.rgb(15, 23, 42)
                textSize = 13f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val titlePaint = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.rgb(13, 148, 136)
                textSize = 14f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val metaPaint = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.rgb(51, 65, 85)
                textSize = 8.5f
                textAlign = Paint.Align.RIGHT
            }
            val datePaint = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.rgb(100, 116, 139)
                textSize = 8f
                textAlign = Paint.Align.LEFT
            }
            val headerTextPaint = Paint().apply {
                isAntiAlias = true
                textSize = if (columns.size > 8) 7.8f else 8.8f
                color = AndroidGraphicsColor.WHITE
                isFakeBoldText = true
            }
            val cellTextPaint = Paint().apply {
                isAntiAlias = true
                textSize = if (columns.size > 8) 7.3f else 8.2f
                color = AndroidGraphicsColor.rgb(15, 23, 42)
                typeface = Typeface.DEFAULT
            }
            val footerPaint = Paint().apply {
                isAntiAlias = true
                textSize = 8f
                color = AndroidGraphicsColor.GRAY
            }

            val batchRowsPerFetch = itemsPerPage * 10 // ~180-240 rows per DB roundtrip
            var globalOffset = 0
            var pageNumber = 0
            var exportedRows = 0

            while (exportedRows < maxPdfRows) {
                val batchLimit = minOf(batchRowsPerFetch, maxPdfRows - exportedRows)
                val rowsBatch = rowProvider(batchLimit, globalOffset, globalOffset)
                if (rowsBatch.isEmpty()) {
                    if (pageNumber == 0) {
                        pageNumber = 1
                        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                        val page = doc.startPage(pageInfo)
                        val canvas = page.canvas
                        val tableStartY = drawPdfHeaderAndMeta(
                            canvas = canvas,
                            title = title,
                            subtitle = "${entity.label} • المستخدم: $userDisplayName",
                            filterNote = "إجمالي السجلات: $totalMatching سجل",
                            dateStr = dateStr,
                            pageWidth = pageWidth,
                            marginH = marginH,
                            topBarPaint = topBarPaint,
                            accentBarPaint = accentBarPaint,
                            orgPaint = orgPaint,
                            titlePaint = titlePaint,
                            metaPaint = metaPaint,
                            datePaint = datePaint
                        )
                        val emptyPaint = Paint(cellTextPaint).apply { textAlign = Paint.Align.CENTER }
                        canvas.drawText("لا توجد سجلات مطابقة للفلاتر المحددة", pageWidth / 2f, tableStartY + 40f, emptyPaint)
                        doc.finishPage(page)
                    }
                    break
                }

                val subPages = rowsBatch.chunked(itemsPerPage)
                for (pageRows in subPages) {
                    pageNumber++
                    val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                    val page = doc.startPage(pageInfo)
                    val canvas = page.canvas

                    var currentY = drawPdfHeaderAndMeta(
                        canvas = canvas,
                        title = title,
                        subtitle = "${entity.label} • المستخدم: $userDisplayName",
                        filterNote = "السجلات المشمولة بالتقرير: ${minOf(totalMatching, maxPdfRows)} من أصل $totalMatching",
                        dateStr = dateStr,
                        pageWidth = pageWidth,
                        marginH = marginH,
                        topBarPaint = topBarPaint,
                        accentBarPaint = accentBarPaint,
                        orgPaint = orgPaint,
                        titlePaint = titlePaint,
                        metaPaint = metaPaint,
                        datePaint = datePaint
                    )

                    val headerHeight = 22f
                    val rowHeight = 19f
                    fillPaint.color = AndroidGraphicsColor.rgb(15, 23, 42)
                    canvas.drawRect(marginH, currentY, pageWidth - marginH, currentY + headerHeight, fillPaint)

                    var tableX = pageWidth - marginH
                    strokePaint.color = AndroidGraphicsColor.rgb(51, 65, 85)
                    columns.forEachIndexed { colIdx, col ->
                        val w = colWidths[colIdx]
                        val cellLeft = tableX - w
                        tableX -= w
                        canvas.drawLine(cellLeft, currentY, cellLeft, currentY + headerHeight, strokePaint)
                        var hText = col.label
                        val maxHeaderW = w - 4f
                        if (headerTextPaint.measureText(hText) > maxHeaderW && maxHeaderW > 8f) {
                            while (hText.isNotEmpty() && headerTextPaint.measureText("$hText…") > maxHeaderW) {
                                hText = hText.dropLast(1)
                            }
                            hText = "$hText…"
                        }
                        val tw = headerTextPaint.measureText(hText)
                        val tx = cellLeft + (w - tw) / 2f
                        val ty = currentY + (headerHeight / 2f) - ((headerTextPaint.descent() + headerTextPaint.ascent()) / 2f)
                        canvas.drawText(hText, tx, ty, headerTextPaint)
                    }
                    currentY += headerHeight

                    pageRows.forEachIndexed { rIdx, rowCells ->
                        val isEven = rIdx % 2 == 0
                        fillPaint.color = if (isEven) AndroidGraphicsColor.WHITE else AndroidGraphicsColor.rgb(241, 245, 249)
                        canvas.drawRect(marginH, currentY, pageWidth - marginH, currentY + rowHeight, fillPaint)

                        strokePaint.color = AndroidGraphicsColor.rgb(226, 232, 240)
                        canvas.drawLine(marginH, currentY + rowHeight, pageWidth - marginH, currentY + rowHeight, strokePaint)

                        var cellX = pageWidth - marginH
                        columns.forEachIndexed { colIdx, _ ->
                            val w = colWidths[colIdx]
                            val cellLeft = cellX - w
                            cellX -= w
                            canvas.drawLine(cellLeft, currentY, cellLeft, currentY + rowHeight, strokePaint)

                            val rawValue = rowCells.getOrNull(colIdx) ?: "-"
                            val maxTextW = w - 6f
                            var displayText = rawValue
                            if (cellTextPaint.measureText(displayText) > maxTextW && maxTextW > 10f) {
                                while (displayText.isNotEmpty() && cellTextPaint.measureText("$displayText…") > maxTextW) {
                                    displayText = displayText.dropLast(1)
                                }
                                displayText = "$displayText…"
                            }
                            val tw = cellTextPaint.measureText(displayText)
                            val tx = cellLeft + (w - tw) / 2f
                            val ty = currentY + (rowHeight / 2f) - ((cellTextPaint.descent() + cellTextPaint.ascent()) / 2f)
                            canvas.drawText(displayText, tx, ty, cellTextPaint)
                        }
                        currentY += rowHeight
                    }

                    val footerText = "صفحة $pageNumber من $totalPagesEst • مركز التقارير والمعاينة الديناميكي"
                    val fw = footerPaint.measureText(footerText)
                    canvas.drawText(footerText, (pageWidth - fw) / 2f, pageHeight - 16f, footerPaint)

                    doc.finishPage(page)
                    exportedRows += pageRows.size
                    _exportProgress.value = (0.1f + 0.8f * (exportedRows.toFloat() / effectiveTotal.coerceAtLeast(1))).coerceIn(0.1f, 0.9f)
                }

                globalOffset += rowsBatch.size
                if (rowsBatch.size < batchLimit) break
            }

            FileOutputStream(tempFile).use { fos ->
                doc.writeTo(fos)
                fos.flush()
            }
            doc.close()
            pdfDocument = null

            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return Result.failure(Exception("تعذر فتح مجرى التخزين لحفظ ملف PDF."))
            tempFile.inputStream().use { input ->
                outputStream.use { out ->
                    input.copyTo(out)
                    out.flush()
                }
            }
            return Result.success(Unit)
        } catch (oom: OutOfMemoryError) {
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            return Result.failure(Exception("نفدت الذاكرة أثناء توليد PDF. يُرجى استخدام تصدير Excel للسجلات الضخمة.", oom))
        } catch (t: Throwable) {
            try { pdfDocument?.close() } catch (_: Throwable) {}
            return Result.failure(Exception(t.message ?: "تعذر إنشاء مستند PDF", t))
        } finally {
            try {
                if (tempFile.exists()) tempFile.delete()
            } catch (_: Throwable) {}
        }
    }

    private fun drawPdfHeaderAndMeta(
        canvas: android.graphics.Canvas,
        title: String,
        subtitle: String,
        filterNote: String,
        dateStr: String,
        pageWidth: Int,
        marginH: Float,
        topBarPaint: Paint,
        accentBarPaint: Paint,
        orgPaint: Paint,
        titlePaint: Paint,
        metaPaint: Paint,
        datePaint: Paint
    ): Float {
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 10f, topBarPaint)
        canvas.drawRect(0f, 10f, pageWidth.toFloat(), 13f, accentBarPaint)

        var y = 34f
        canvas.drawText("نظام إدارة المساعدات الإنسانية والعمليات الميدانية المعتمد", pageWidth - marginH, y, orgPaint)
        y += 17f
        canvas.drawText(title, pageWidth - marginH, y, titlePaint)
        y += 8f

        val boxHeight = 38f
        val boxRect = RectF(marginH, y, pageWidth - marginH, y + boxHeight)
        val boxBg = Paint().apply { color = AndroidGraphicsColor.rgb(248, 250, 252) }
        val boxStroke = Paint().apply {
            color = AndroidGraphicsColor.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(boxRect, 6f, 6f, boxBg)
        canvas.drawRoundRect(boxRect, 6f, 6f, boxStroke)

        canvas.drawText(subtitle, pageWidth - marginH - 10f, y + 14f, metaPaint)
        canvas.drawText(filterNote, pageWidth - marginH - 10f, y + 29f, metaPaint)
        canvas.drawText("تاريخ الإصدار: $dateStr", marginH + 10f, y + 14f, datePaint)
        canvas.drawText("كشف ديناميكي مخصص", marginH + 10f, y + 29f, datePaint)

        return y + boxHeight + 8f
    }

    fun resetFilters() {
        _approvalFilter.value = MultiSelectFilterState()
        _localityApprovalFilter.value = MultiSelectFilterState()
        _currentMainAreaFilter.value = MultiSelectFilterState()
        _currentSubAreaFilter.value = MultiSelectFilterState()
        _worksFilter.value = MultiSelectFilterState()
        _damageFilter.value = MultiSelectFilterState()
        _maritalFilter.value = MultiSelectFilterState()
        _injuryFilter.value = MultiSelectFilterState()
        _shelterFilter.value = MultiSelectFilterState()
        _shelterCenterFilter.value = MultiSelectFilterState()
        _residentFilter.value = MultiSelectFilterState()
        _membersRangeFilter.value = MembersRangeFilterState()

        _projectStatusFilter.value = MultiSelectFilterState()
        _projectAidTypeFilter.value = MultiSelectFilterState()
        _projectFunderFilter.value = MultiSelectFilterState()
        _projectWarehouseFilter.value = MultiSelectFilterState()

        _childGenderFilter.value = MultiSelectFilterState()
        _childShelterFilter.value = MultiSelectFilterState()
        _childSubAreaFilter.value = MultiSelectFilterState()

        if (_isLocalityLocked.value) {
            val singleName = _lockedLocalityName.value
                ?: _allowedLocalities.value.firstOrNull()?.LocalityName
                ?: ""
            val lockedSet = if (singleName.isNotBlank()) setOf(singleName) else emptySet()
            _localityFilter.value = MultiSelectFilterState(selected = lockedSet, exclude = false)
            _projectLocalityFilter.value = MultiSelectFilterState(selected = lockedSet, exclude = false)
            _childLocalityFilter.value = MultiSelectFilterState(selected = lockedSet, exclude = false)
        } else {
            _localityFilter.value = MultiSelectFilterState()
            _projectLocalityFilter.value = MultiSelectFilterState()
            _childLocalityFilter.value = MultiSelectFilterState()
        }

        if (_isBranchLocked.value) {
            val singleBr = _lockedBranchName.value
                ?: _allowedBranches.value.firstOrNull()
                ?: ""
            val lockedBrSet = if (singleBr.isNotBlank()) setOf(singleBr) else emptySet()
            _branchFilter.value = MultiSelectFilterState(selected = lockedBrSet, exclude = false)
        } else {
            _branchFilter.value = MultiSelectFilterState()
        }

        selectDefaultColumns()
        _exportStatusMessage.value = null
        loadPreview()
    }

    fun clearState() {
        previewJob?.cancel()
        _previewFamilies.value = emptyList()
        _previewProjects.value = emptyList()
        _previewChildren.value = emptyList()
        _totalMatchingCount.value = 0
        _isLoadingPreview.value = false
        _isExporting.value = false
        _exportProgress.value = 0f
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    private fun escapeCsv(value: String): String {
        var str = value.trim()
        if (str.contains(",") || str.contains("\"") || str.contains("\n") || str.contains("\r")) {
            str = str.replace("\"", "\"\"")
            return "\"$str\""
        }
        return str
    }

    companion object {
        const val PREVIEW_LIMIT = 50
        const val PROJECT_STATUS_ACTIVE_LABEL = "نشط"
        const val PROJECT_STATUS_ARCHIVED_LABEL = "مؤرشف / مغلق"
    }
}

class DynamicExportViewModelFactory(
    private val repository: AidRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DynamicExportViewModel::class.java)) {
            return DynamicExportViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
