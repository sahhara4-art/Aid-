package com.humanitarian.aidmanagement.data.local.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * كيان نظام الشكاوى والأولويات (family_complaints)
 * يربط الشكاوى برقم هوية رب الأسرة مع فهرسة على familyId و status لأداء لحظي خفيف.
 */
@Entity(
    tableName = "family_complaints",
    indices = [
        Index(value = ["familyId"]),
        Index(value = ["status"])
    ]
)
data class FamilyComplaintEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val familyId: String,
    val familyName: String,
    val localArea: String,
    val complaintReason: String,
    val targetAidCategory: String,
    val status: String = STATUS_OPEN,
    val createdAt: Long = System.currentTimeMillis(),
    val nominatedProjectName: String? = null
) {
    companion object {
        const val STATUS_OPEN = "OPEN"
        const val STATUS_NOMINATED = "NOMINATED"
        const val STATUS_RESOLVED = "RESOLVED"
    }
}
