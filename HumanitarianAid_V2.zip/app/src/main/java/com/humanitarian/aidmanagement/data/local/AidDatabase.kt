package com.humanitarian.aidmanagement.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.humanitarian.aidmanagement.data.local.dao.*
import com.humanitarian.aidmanagement.data.local.entities.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Database(
    entities = [
        UserEntity::class,
        RoleEntity::class,
        LocalityEntity::class,
        UserLocalityEntity::class,
        FamilyEntity::class,
        ChildEntity::class,
        AidTypeEntity::class,
        ProjectEntity::class,
        AidRecordEntity::class,
        ManualSelectionEntity::class,
        SelectedCitizenEntity::class,
        LocalityDistributionEntity::class,
        SystemSettingEntity::class,
        SyncQueueEntity::class,
        SyncLogEntity::class,
        UserPermissionEntity::class,
        UserAccessLogEntity::class,
        AuditLogEntity::class,
        NominationWorkflowEntity::class,
        ProjectQuotaEntity::class,
        DeliveryUndoLogEntity::class
    ],
    views = [
        EligibleFamiliesView::class
    ],
    version = 11,
    exportSchema = false
)
abstract class AidDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun familyDao(): FamilyDao
    abstract fun childDao(): ChildDao
    abstract fun aidTypeDao(): AidTypeDao
    abstract fun projectDao(): ProjectDao
    abstract fun aidRecordDao(): AidRecordDao
    abstract fun nominationDao(): NominationDao
    abstract fun localityDao(): LocalityDao
    abstract fun systemSettingDao(): SystemSettingDao
    abstract fun syncQueueDao(): SyncQueueDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun nominationWorkflowDao(): NominationWorkflowDao
    abstract fun projectQuotaDao(): ProjectQuotaDao
    abstract fun eligibleFamiliesDao(): EligibleFamiliesDao
    abstract fun deliveryUndoLogDao(): DeliveryUndoLogDao

    companion object {
        private const val TAG = "AidDatabase"
        const val DATABASE_NAME = "humanitarian_aid_database.db"

        // =========================================================================
        // MIGRATION PATHS (1 -> 11): تغطية شاملة لمنع فقدان البيانات أو الانهيار
        // =========================================================================

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("CREATE TABLE IF NOT EXISTS tbl_User_Permissions (PermissionID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, UserID INTEGER NOT NULL, PermissionKey TEXT NOT NULL, Category TEXT NOT NULL, Description TEXT NOT NULL, IsGranted INTEGER NOT NULL DEFAULT 1)")
                    db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_tbl_User_Permissions_UserID_PermissionKey ON tbl_User_Permissions(UserID, PermissionKey)")
                } catch (e: Exception) {
                    android.util.Log.w(TAG, "MIGRATION_1_2: ${e.message}")
                }
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("CREATE TABLE IF NOT EXISTS tbl_User_Access_Logs (LogID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, UserID INTEGER NOT NULL, UserName TEXT NOT NULL, ActionType TEXT NOT NULL, Timestamp TEXT NOT NULL, IPAddress TEXT NOT NULL DEFAULT '192.168.1.100', DeviceName TEXT NOT NULL DEFAULT 'Android Mobile Terminal', Status TEXT NOT NULL DEFAULT 'ناجح', Details TEXT NOT NULL)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_User_Access_Logs_UserID ON tbl_User_Access_Logs(UserID)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_User_Access_Logs_Timestamp ON tbl_User_Access_Logs(Timestamp)")
                } catch (e: Exception) {
                    android.util.Log.w(TAG, "MIGRATION_2_3: ${e.message}")
                }
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("CREATE TABLE IF NOT EXISTS sync_queue (syncId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, entityType TEXT NOT NULL, operation TEXT NOT NULL, recordId TEXT NOT NULL, payloadJson TEXT NOT NULL, createdAt INTEGER NOT NULL, status TEXT NOT NULL, retryCount INTEGER NOT NULL, errorMessage TEXT)")
                    db.execSQL("CREATE TABLE IF NOT EXISTS sync_log (logId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, timestamp INTEGER NOT NULL, syncType TEXT NOT NULL, itemsProcessed INTEGER NOT NULL, itemsSucceeded INTEGER NOT NULL, itemsFailed INTEGER NOT NULL, details TEXT NOT NULL)")
                } catch (e: Exception) {
                    android.util.Log.w(TAG, "MIGRATION_3_4: ${e.message}")
                }
            }
        }

        val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("CREATE TABLE IF NOT EXISTS tbl_Audit_Logs (logId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, userId INTEGER NOT NULL, userName TEXT NOT NULL, userFullName TEXT NOT NULL, operationType TEXT NOT NULL, targetTable TEXT NOT NULL, recordId TEXT NOT NULL, description TEXT NOT NULL, timestamp INTEGER NOT NULL, formattedDate TEXT NOT NULL)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_Audit_Logs_userId ON tbl_Audit_Logs(userId)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_Audit_Logs_timestamp ON tbl_Audit_Logs(timestamp)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_Audit_Logs_operationType ON tbl_Audit_Logs(operationType)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_Audit_Logs_targetTable ON tbl_Audit_Logs(targetTable)")
                } catch (e: Exception) {
                    android.util.Log.w(TAG, "MIGRATION_4_5: ${e.message}")
                }
            }
        }

        val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("CREATE TABLE IF NOT EXISTS tbl_Nomination_Workflows (workflowId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, projectId INTEGER NOT NULL, aidTypeId INTEGER NOT NULL, workflowTitle TEXT NOT NULL, targetQuota INTEGER NOT NULL, approvedCount INTEGER NOT NULL, status TEXT NOT NULL, createdDate INTEGER NOT NULL, notes TEXT)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_Nomination_Workflows_projectId ON tbl_Nomination_Workflows(projectId)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_Nomination_Workflows_aidTypeId ON tbl_Nomination_Workflows(aidTypeId)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_Nomination_Workflows_status ON tbl_Nomination_Workflows(status)")
                } catch (e: Exception) {
                    android.util.Log.w(TAG, "MIGRATION_5_6: ${e.message}")
                }
            }
        }

        val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("CREATE TABLE IF NOT EXISTS tbl_Project_Quotas (quotaId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, projectId INTEGER NOT NULL, localityId INTEGER NOT NULL, localityName TEXT NOT NULL, allocatedCount INTEGER NOT NULL, fulfilledCount INTEGER NOT NULL, quotaPercentage REAL NOT NULL, isActive INTEGER NOT NULL)")
                    db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_tbl_Project_Quotas_projectId_localityId ON tbl_Project_Quotas(projectId, localityId)")
                } catch (e: Exception) {
                    android.util.Log.w(TAG, "MIGRATION_6_7: ${e.message}")
                }
            }
        }

        val MIGRATION_7_8 = object : Migration(7, 8) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("ALTER TABLE families ADD COLUMN incomeSource2 TEXT DEFAULT NULL")
                } catch (e: Exception) {
                    android.util.Log.w(TAG, "Column incomeSource2 may already exist: ${e.message}")
                }
            }
        }

        val MIGRATION_8_9 = object : Migration(8, 9) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val columnsToAdd = listOf(
                    "ALTER TABLE families ADD COLUMN shelter_center_name TEXT DEFAULT NULL",
                    "ALTER TABLE families ADD COLUMN date_of_birth TEXT DEFAULT '1985-01-01'",
                    "ALTER TABLE families ADD COLUMN primary_phone TEXT DEFAULT ''",
                    "ALTER TABLE families ADD COLUMN alternative_phone_1 TEXT DEFAULT NULL",
                    "ALTER TABLE families ADD COLUMN alternative_phone_2 TEXT DEFAULT NULL",
                    "ALTER TABLE families ADD COLUMN income_source_2 TEXT DEFAULT NULL"
                )
                columnsToAdd.forEach { sql ->
                    try {
                        db.execSQL(sql)
                    } catch (e: Exception) {
                        android.util.Log.w(TAG, "MIGRATION_8_9 sql ($sql): ${e.message}")
                    }
                }
            }
        }

        val MIGRATION_9_10 = object : Migration(9, 10) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("""
                        CREATE TABLE IF NOT EXISTS tbl_Delivery_Undo_Logs (
                            logId INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            projectID INTEGER NOT NULL,
                            familyID INTEGER NOT NULL,
                            aidRecordID INTEGER NOT NULL,
                            recipientName TEXT,
                            undoReason TEXT NOT NULL,
                            undoByUserId INTEGER NOT NULL,
                            undoByUserName TEXT NOT NULL,
                            timestamp INTEGER NOT NULL,
                            formattedDate TEXT NOT NULL
                        )
                    """)
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_Delivery_Undo_Logs_projectID ON tbl_Delivery_Undo_Logs(projectID)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_Delivery_Undo_Logs_familyID ON tbl_Delivery_Undo_Logs(familyID)")
                    db.execSQL("CREATE INDEX IF NOT EXISTS index_tbl_Delivery_Undo_Logs_aidRecordID ON tbl_Delivery_Undo_Logs(aidRecordID)")
                } catch (e: Exception) {
                    android.util.Log.w(TAG, "tbl_Delivery_Undo_Logs migration: ${e.message}")
                }
            }
        }

        val MIGRATION_10_11 = object : Migration(10, 11) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("ALTER TABLE projects ADD COLUMN isLocked INTEGER NOT NULL DEFAULT 0")
                } catch (e: Exception) {
                    android.util.Log.w(TAG, "Column isLocked migration: ${e.message}")
                }
            }
        }

        val ALL_MIGRATIONS = arrayOf(
            MIGRATION_1_2,
            MIGRATION_2_3,
            MIGRATION_3_4,
            MIGRATION_4_5,
            MIGRATION_5_6,
            MIGRATION_6_7,
            MIGRATION_7_8,
            MIGRATION_8_9,
            MIGRATION_9_10,
            MIGRATION_10_11
        )

        @Volatile
        private var INSTANCE: AidDatabase? = null

        /**
         * تفريغ وحفظ كافة عمليات الذاكرة (WAL) إلى الملف الفيزيائي الرئيسي
         */
        fun flushWal(db: AidDatabase? = INSTANCE) {
            try {
                if (db != null && db.isOpen) {
                    val cursor = db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)")
                    cursor.moveToFirst()
                    cursor.close()
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "flushWal error: ${e.message}")
            }
        }

        fun getDatabase(context: Context, scope: CoroutineScope): AidDatabase {
            return INSTANCE ?: synchronized(this) {
                // 1. تحميل مكتبة تشفير SQLCipher قبل تهيئة المصنع
                try {
                    System.loadLibrary("sqlcipher")
                } catch (e: Throwable) {
                    android.util.Log.w(TAG, "SQLCipher System.loadLibrary: ${e.message}")
                }

                // 2. الحصول على مفتاح التشفير وتهيئة SupportOpenHelperFactory
                val passphrase = com.humanitarian.aidmanagement.data.security.DatabaseKeyManager.getOrCreateDatabaseKey(context)
                val factory = SupportOpenHelperFactory(passphrase)

                // 3. بناء قاعدة بيانات Room مع مسارات ترحيل كاملة وبدون هدم عشوائي لقاعدة البيانات
                val builder = Room.databaseBuilder(
                    context.applicationContext,
                    AidDatabase::class.java,
                    DATABASE_NAME
                )
                    .openHelperFactory(factory)
                    .addMigrations(*ALL_MIGRATIONS)
                    .addCallback(AidDatabaseCallback(scope))

                val instance = builder.build()
                INSTANCE = instance
                instance
            }
        }

        /**
         * تفريغ الكاش وإعادة بناء الاتصال بقاعدة البيانات (Re-establish DB Connection & Clear Cache)
         * يُستدعى فور الانتهاء من استعادة النسخة الاحتياطية لضمان استمرارية عمل التطبيق ومنع تجمده أو انهياره
         */
        @Synchronized
        fun reestablishConnection(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): AidDatabase {
            try {
                INSTANCE?.let { db ->
                    if (db.isOpen) {
                        try {
                            db.invalidationTracker.refreshVersionsAsync()
                        } catch (_: Exception) {}
                        db.close()
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "Error closing previous database instance: ${e.message}")
            }
            INSTANCE = null
            val newDb = getDatabase(context, scope)
            try {
                newDb.openHelper.writableDatabase.query("SELECT 1").close()
                newDb.invalidationTracker.refreshVersionsAsync()
            } catch (e: Exception) {
                android.util.Log.e(TAG, "Error verifying re-established database connection: ${e.message}")
                throw e
            }
            return newDb
        }

        /**
         * إغلاق وتدمير مرجع قاعدة البيانات بالكامل (Reset Singleton Instance)
         * يُستدعى أثناء عمليات الاستعادة لقطع أي خيط أو اتصال جاري بملفات SQLite
         */
        @Synchronized
        fun resetInstance() {
            try {
                INSTANCE?.let { db ->
                    if (db.isOpen) {
                        try {
                            db.invalidationTracker.refreshVersionsAsync()
                        } catch (_: Exception) {}
                        db.close()
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w(TAG, "Error closing database in resetInstance: ${e.message}")
            }
            INSTANCE = null
        }
    }

    private class AidDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(db: AidDatabase) {
            // 1. الأدوار
            val roles = listOf(
                RoleEntity(1, "مدير النظام", "صلاحيات كاملة لجميع العمليات والمحليات", true),
                RoleEntity(2, "مشرف محليات", "إدارة وترشيح الأسر ضمن محليات محددة", true),
                RoleEntity(3, "باحث ميداني", "عرض وإدخال بيانات الأسر والأطفال", true)
            )
            roles.forEach { db.userDao().insertRole(it) }

            // 2. مستخدم مدير النظام الافتراضي (admin / admin123)
            val adminUser = UserEntity(
                UserID = 1,
                UserName = "admin",
                PasswordHash = "admin123", // في بيئة الإنتاج يتم استخدام bcrypt/argon2
                fullName = "مهندس النظام - إدارة المساعدات",
                RoleID = 1,
                IsActive = true,
                CreatedBy = "النظام الأولي"
            )
            db.userDao().insertUser(adminUser)
            // ربط الأدمن بكل المحليات (0 تعني الكل)
            db.userDao().insertUserLocality(UserLocalityEntity(UserID = 1, LocalityID = 0))

            // 2.2 منح كافة الصلاحيات الإدارية والميدانية الشاملة لحساب الأدمن
            val allAdminPermissions = listOf(
                UserPermissionEntity(UserID = 1, PermissionKey = "families_view", Category = "الأسر", Description = "استعراض وبحث بيانات الأسر والمواطنين"),
                UserPermissionEntity(UserID = 1, PermissionKey = "families_create", Category = "الأسر", Description = "تسجيل وإضافة أسر جديدة"),
                UserPermissionEntity(UserID = 1, PermissionKey = "families_edit", Category = "الأسر", Description = "تعديل بيانات الأسر واعتماد التنمية"),
                UserPermissionEntity(UserID = 1, PermissionKey = "families_delete", Category = "الأسر", Description = "حذف وتجميد ملفات المواطنين"),
                UserPermissionEntity(UserID = 1, PermissionKey = "families_export", Category = "الأسر", Description = "تصدير كشوفات الأسر"),
                UserPermissionEntity(UserID = 1, PermissionKey = "children_view", Category = "الأطفال", Description = "استعراض سجل الأطفال"),
                UserPermissionEntity(UserID = 1, PermissionKey = "children_manage", Category = "الأطفال", Description = "إضافة وتعديل بيانات الأطفال"),
                UserPermissionEntity(UserID = 1, PermissionKey = "nomination_run", Category = "الترشيح", Description = "تشغيل محرك المفاضلة والترشيح الآلي"),
                UserPermissionEntity(UserID = 1, PermissionKey = "nomination_manual", Category = "الترشيح", Description = "الترشيح اليدوي للحالات الخاصة"),
                UserPermissionEntity(UserID = 1, PermissionKey = "nomination_criteria", Category = "الترشيح", Description = "تعديل معايير واشتراطات الأولوية"),
                UserPermissionEntity(UserID = 1, PermissionKey = "nomination_approve", Category = "الترشيح", Description = "اعتماد وترحيل المرشحين للصرف"),
                UserPermissionEntity(UserID = 1, PermissionKey = "delivery_view", Category = "التسليم", Description = "استعراض كشوفات التسليم والصرف"),
                UserPermissionEntity(UserID = 1, PermissionKey = "delivery_handover", Category = "التسليم", Description = "تنفيذ تسليم وصرف المساعدات"),
                UserPermissionEntity(UserID = 1, PermissionKey = "delivery_receipt_print", Category = "التسليم", Description = "طباعة وتصدير سندات الاستلام"),
                UserPermissionEntity(UserID = 1, PermissionKey = "delivery_undo", Category = "التسليم", Description = "التراجع عن تسليم مساعدة وإلغاؤها"),
                UserPermissionEntity(UserID = 1, PermissionKey = "delivery_scanner", Category = "التسليم", Description = "مسح الباركود و QR كود"),
                UserPermissionEntity(UserID = 1, PermissionKey = "projects_manage", Category = "المشاريع", Description = "إدارة المشاريع الإنسانية وأنواع المساعدات"),
                UserPermissionEntity(UserID = 1, PermissionKey = "warehouse_manage", Category = "المستودعات", Description = "إدارة المستودعات وحركات الصرف"),
                UserPermissionEntity(UserID = 1, PermissionKey = "reports_view", Category = "التقارير", Description = "الاطلاع على التقارير والمؤشرات"),
                UserPermissionEntity(UserID = 1, PermissionKey = "reports_pdf_export", Category = "التقارير", Description = "توليد وتصدير كشوفات PDF رسمية"),
                UserPermissionEntity(UserID = 1, PermissionKey = "users_manage", Category = "الأمان", Description = "إنشاء وتعديل وتجميد حسابات المستخدمين"),
                UserPermissionEntity(UserID = 1, PermissionKey = "permissions_edit", Category = "الأمان", Description = "تعريف وتعديل صلاحيات الأدوار والمستخدمين"),
                UserPermissionEntity(UserID = 1, PermissionKey = "security_policies", Category = "الأمان", Description = "ضبط سياسات الأمان وساعات الدوام"),
                UserPermissionEntity(UserID = 1, PermissionKey = "audit_logs_view", Category = "الأمان", Description = "فحص ومراقبة سجل التدقيق الأمني"),
                UserPermissionEntity(UserID = 1, PermissionKey = "backup_restore", Category = "الأمان", Description = "النسخ الاحتياطي واستعادة قاعدة البيانات"),
                UserPermissionEntity(UserID = 1, PermissionKey = "sync_manage", Category = "المزامنة", Description = "إدارة التزامن السحابي والميداني")
            )
            db.userDao().insertPermissions(allAdminPermissions)
            // 3. المحليات الرسمية ونسب التوزيع: تُبنى وتُغذى ديناميكياً من بيانات الأسر المستوردة

            // 5. أنواع المساعدات الإحدى عشرة بالترتيب
            val aidTypes = listOf(
                AidTypeEntity(1, "غذائي", "طرود وسلات غذائية أساسية", defaultExclusionDays = 30),
                AidTypeEntity(2, "خضروات وفواكه", "سلات خضار طازجة ومواد مكملة", defaultExclusionDays = 21),
                AidTypeEntity(3, "لحوم", "معلبات لحوم تنمية ولحوم طازجة", defaultExclusionDays = 45),
                AidTypeEntity(4, "مساعدات نقدية", "مساعدات مالية عاجلة ومباشرة", defaultExclusionDays = 60),
                AidTypeEntity(5, "كسوة", "ملابس شتوية وصيفية للأسر", defaultExclusionDays = 90),
                AidTypeEntity(6, "مساعدات صحية", "قوائم استلام الصحي ومستلزمات النظافة", defaultExclusionDays = 30),
                AidTypeEntity(7, "فرشات وشوادر", "استلام فرشات وشوادر وحرامات للإيواء", defaultExclusionDays = 120),
                AidTypeEntity(8, "أدوات مطبخ", "قائمة استلام أدوات مطبخ وأواني طهي", defaultExclusionDays = 180),
                AidTypeEntity(9, "بامبرز أطفال", "استلام بامبرز وحفاظات أطفال", defaultExclusionDays = 25),
                AidTypeEntity(10, "فارس الشهم", "مساعدات عملية الفارس الشهم المتنوعة", defaultExclusionDays = 30),
                AidTypeEntity(11, "تنمية اجتماعية", "مساعدات التنمية 2025 والتمكين", defaultExclusionDays = 60)
            )
            aidTypes.forEach { db.aidTypeDao().insertAidType(it) }

            // 6. مشاريع أولية
            val initialProjects = listOf(
                ProjectEntity(
                    projectID = 1,
                    projectNumber = "PRJ-2025-001",
                    projectName = "مشروع الإغاثة الغذائية العاجلة",
                    aidTypeID = 1,
                    detailedDescription = "توزيع 500 طرد غذائي عائلي للأسر المتضررة في مراكز الإيواء",
                    projectDate = "2025-02-15",
                    fundingInstitution = "الهيئة الخيرية للإغاثة",
                    quantity = 500,
                    isActive = true
                ),
                ProjectEntity(
                    projectID = 2,
                    projectNumber = "PRJ-2025-002",
                    projectName = "مشروع كسوة الشتاء والفرشات",
                    aidTypeID = 7,
                    detailedDescription = "توفير فرشات وشوادر وحرامات شتوية للأسر النازحة",
                    projectDate = "2025-02-20",
                    fundingInstitution = "صندوق الدعم الإنساني",
                    quantity = 250,
                    isActive = true
                )
            )
            initialProjects.forEach { db.projectDao().insertProject(it) }

            // 7. إعدادات فترات الاستثناء وشروط الترشيح
            val settings = listOf(
                SystemSettingEntity("max_failed_attempts", "5", "الحد الأقصى لمحاولات تسجيل الدخول الفاشلة"),
                SystemSettingEntity("lockout_duration_minutes", "15", "مدة قفل الحساب بالدقائق عند تجاوز المحاولات"),
                SystemSettingEntity("exclusion_aid_1", "30", "فترة استثناء السلة الغذائية (أيام)"),
                SystemSettingEntity("exclusion_aid_2", "21", "فترة استثناء الخضروات (أيام)"),
                SystemSettingEntity("exclusion_aid_3", "45", "فترة استثناء اللحوم (أيام)"),
                SystemSettingEntity("exclusion_aid_4", "60", "فترة استثناء المساعدات النقدية (أيام)"),
                SystemSettingEntity("exclusion_aid_5", "90", "فترة استثناء الكسوة (أيام)"),
                SystemSettingEntity("exclusion_aid_6", "30", "فترة استثناء المساعدات الصحية (أيام)"),
                SystemSettingEntity("exclusion_aid_7", "120", "فترة استثناء الفرشات والشوادر (أيام)"),
                SystemSettingEntity("exclusion_aid_8", "180", "فترة استثناء أدوات المطبخ (أيام)"),
                SystemSettingEntity("exclusion_aid_9", "25", "فترة استثناء بامبرز الأطفال (أيام)"),
                SystemSettingEntity("exclusion_aid_10", "30", "فترة استثناء فارس الشهم (أيام)"),
                SystemSettingEntity("exclusion_aid_11", "60", "فترة استثناء التنمية الاجتماعية (أيام)")
            )
            settings.forEach { db.systemSettingDao().setSetting(it) }

            // 8. بذر أسر أولية نموذجية للاختبار والتشغيل الميداني
            val sampleFamilies = listOf(
                FamilyEntity(
                    name = "أحمد محمود خليل الأسطل",
                    nationalID = "901234561",
                    birthDate = "1978-05-12",
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 8,
                    wifeName = "فاطمة إبراهيم رضوان",
                    wifeNationalID = "901234562",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    worksApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "أضرار كلية",
                    shelterStatus = "إيواء داخلي",
                    localityID = 1,
                    notes = "أسرة مهدم بيتها كلياً تعيش في مركز إيواء"
                ),
                FamilyEntity(
                    name = "محمد سالم عبد الرحمن النجار",
                    nationalID = "902345672",
                    birthDate = "1982-11-20",
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 9,
                    wifeName = "مريم كمال دغمش",
                    wifeNationalID = "902345673",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    worksApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "أضرار كلية",
                    shelterStatus = "إيواء داخلي",
                    localityID = 2,
                    notes = "أولوية قصوى - 7 أطفال صغار"
                ),
                FamilyEntity(
                    name = "خالد سليم حسن بربخ",
                    nationalID = "903456783",
                    birthDate = "1975-02-14",
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 7,
                    wifeName = "سعاد عمر شعت",
                    wifeNationalID = "903456784",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    worksApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "أضرار كلية",
                    shelterStatus = "إيواء داخلي",
                    localityID = 3,
                    notes = "حالة إنسانية عاجلة"
                ),
                FamilyEntity(
                    name = "ياسر مصطفى علي فياض",
                    nationalID = "904567894",
                    birthDate = "1985-09-03",
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 6,
                    wifeName = "أمينة حسن صيام",
                    wifeNationalID = "904567895",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    worksApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "أضرار جزئية بليغة",
                    shelterStatus = "إيواء داخلي",
                    localityID = 4,
                    notes = "معيل مريض"
                ),
                FamilyEntity(
                    name = "عبد الكريم جابر مسعود عابد",
                    nationalID = "905678905",
                    birthDate = "1980-07-25",
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 10,
                    wifeName = "زينب فريد حسونة",
                    wifeNationalID = "905678906",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    worksApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "أضرار كلية",
                    shelterStatus = "إيواء داخلي",
                    localityID = 5,
                    notes = "أسرة كبيرة العدد بدون أي معيل"
                )
            )

            sampleFamilies.forEach { db.familyDao().insertFamily(it) }

            // بذر أطفال
            val sampleChildren = listOf(
                ChildEntity(nationalID = "410111221", childName = "عمر أحمد الأسطل", birthDate = "2018-04-10", gender = "ذكر", familyNationalID = "901234561", localityID = 1),
                ChildEntity(nationalID = "410111222", childName = "سارة أحمد الأسطل", birthDate = "2020-09-15", gender = "أنثى", familyNationalID = "901234561", localityID = 1),
                ChildEntity(nationalID = "410222331", childName = "يوسف محمد النجار", birthDate = "2017-01-22", gender = "ذكر", familyNationalID = "902345672", localityID = 2),
                ChildEntity(nationalID = "410222332", childName = "تسنيم محمد النجار", birthDate = "2021-06-30", gender = "أنثى", familyNationalID = "902345672", localityID = 2)
            )
            sampleChildren.forEach { db.childDao().insertChild(it) }
        }
    }
}
