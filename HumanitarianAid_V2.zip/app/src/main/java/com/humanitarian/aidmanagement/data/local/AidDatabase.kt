package com.humanitarian.aidmanagement.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.humanitarian.aidmanagement.data.local.dao.*
import com.humanitarian.aidmanagement.data.local.entities.*
import com.humanitarian.aidmanagement.data.security.HashUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        User::class,
        Role::class,
        Locality::class,
        UserLocality::class,
        Family::class,
        Child::class,
        AidType::class,
        Project::class,
        AidRecord::class,
        Selection::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AidDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun roleDao(): RoleDao
    abstract fun localityDao(): LocalityDao
    abstract fun familyDao(): FamilyDao
    abstract fun childDao(): ChildDao
    abstract fun aidTypeDao(): AidTypeDao
    abstract fun projectDao(): ProjectDao
    abstract fun aidRecordDao(): AidRecordDao
    abstract fun selectionDao(): SelectionDao

    companion object {
        @Volatile
        private var INSTANCE: AidDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AidDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AidDatabase::class.java,
                    "humanitarian_aid_database.db"
                )
                    .addCallback(DatabaseInitializer(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseInitializer(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            try {
                // 1. Roles
                db.execSQL("INSERT OR IGNORE INTO Roles (roleId, roleName, isActive) VALUES (1, 'مدير النظام', 1)")
                db.execSQL("INSERT OR IGNORE INTO Roles (roleId, roleName, isActive) VALUES (2, 'مشرف', 1)")
                db.execSQL("INSERT OR IGNORE INTO Roles (roleId, roleName, isActive) VALUES (3, 'موظف', 1)")
                db.execSQL("INSERT OR IGNORE INTO Roles (roleId, roleName, isActive) VALUES (4, 'مستخدم', 1)")

                // 2. Localities
                db.execSQL("INSERT OR IGNORE INTO Localities (localityId, localityName, isActive, sortOrder) VALUES (1, 'الرمال الشمالي', 1, 1)")
                db.execSQL("INSERT OR IGNORE INTO Localities (localityId, localityName, isActive, sortOrder) VALUES (2, 'الشيخ رضوان', 1, 2)")
                db.execSQL("INSERT OR IGNORE INTO Localities (localityId, localityName, isActive, sortOrder) VALUES (3, 'الشاطئ الشمالي والنصر', 1, 3)")
                db.execSQL("INSERT OR IGNORE INTO Localities (localityId, localityName, isActive, sortOrder) VALUES (4, 'الشاطئ الجنوبي', 1, 4)")
                db.execSQL("INSERT OR IGNORE INTO Localities (localityId, localityName, isActive, sortOrder) VALUES (5, 'مشروع عامر', 1, 5)")

                // 3. 11 Aid Types
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (1, 'غذائي', 1, 1)")
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (2, 'خضروات وفواكه', 1, 2)")
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (3, 'لحوم', 1, 3)")
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (4, 'مساعدات نقدية', 1, 4)")
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (5, 'كسوة', 1, 5)")
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (6, 'مساعدات صحية', 1, 6)")
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (7, 'فرشات وشوادر', 1, 7)")
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (8, 'أدوات مطبخ', 1, 8)")
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (9, 'بامبرز أطفال', 1, 9)")
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (10, 'فارس الشهم', 1, 10)")
                db.execSQL("INSERT OR IGNORE INTO AidTypes (aidTypeID, aidTypeName, isActive, sortOrder) VALUES (11, 'تنمية اجتماعية', 1, 11)")

                // 4. Default Admin User (admin / admin123)
                val now = System.currentTimeMillis()
                val hash = "\$2a\$10\$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy"
                db.execSQL("INSERT OR IGNORE INTO Users (userId, userName, passwordHash, fullName, roleId, isActive, failedAttempts, createdDate, modifiedDate) VALUES (1, 'admin', '$hash', 'مدير النظام العام', 1, 1, 0, $now, $now)")

                // 5. User Localities
                for (locId in 1..5) {
                    db.execSQL("INSERT OR IGNORE INTO UserLocalities (userId, localityId) VALUES (1, $locId)")
                }
            } catch (e: Exception) {
                // Log or ignore
            }
        }

        private suspend fun populateInitialData(database: AidDatabase) {
            // 1. Seed Roles
            val roles = listOf(
                Role(roleId = 1, roleName = "مدير النظام", isActive = true),
                Role(roleId = 2, roleName = "مشرف", isActive = true),
                Role(roleId = 3, roleName = "موظف", isActive = true),
                Role(roleId = 4, roleName = "مستخدم", isActive = true)
            )
            database.roleDao().insertRoles(roles)

            // 2. Seed 5 Localities in required order
            val localities = listOf(
                Locality(localityId = 1, localityName = "الرمال الشمالي", isActive = true, sortOrder = 1),
                Locality(localityId = 2, localityName = "الشيخ رضوان", isActive = true, sortOrder = 2),
                Locality(localityId = 3, localityName = "الشاطئ الشمالي والنصر", isActive = true, sortOrder = 3),
                Locality(localityId = 4, localityName = "الشاطئ الجنوبي", isActive = true, sortOrder = 4),
                Locality(localityId = 5, localityName = "مشروع عامر", isActive = true, sortOrder = 5)
            )
            database.localityDao().insertLocalities(localities)

            // 3. Seed 11 Aid Types in exact requested order
            val aidTypes = listOf(
                AidType(aidTypeID = 1, aidTypeName = "غذائي", isActive = true, sortOrder = 1),
                AidType(aidTypeID = 2, aidTypeName = "خضروات وفواكه", isActive = true, sortOrder = 2),
                AidType(aidTypeID = 3, aidTypeName = "لحوم", isActive = true, sortOrder = 3),
                AidType(aidTypeID = 4, aidTypeName = "مساعدات نقدية", isActive = true, sortOrder = 4),
                AidType(aidTypeID = 5, aidTypeName = "كسوة", isActive = true, sortOrder = 5),
                AidType(aidTypeID = 6, aidTypeName = "مساعدات صحية", isActive = true, sortOrder = 6),
                AidType(aidTypeID = 7, aidTypeName = "فرشات وشوادر", isActive = true, sortOrder = 7),
                AidType(aidTypeID = 8, aidTypeName = "أدوات مطبخ", isActive = true, sortOrder = 8),
                AidType(aidTypeID = 9, aidTypeName = "بامبرز أطفال", isActive = true, sortOrder = 9),
                AidType(aidTypeID = 10, aidTypeName = "فارس الشهم", isActive = true, sortOrder = 10),
                AidType(aidTypeID = 11, aidTypeName = "تنمية اجتماعية", isActive = true, sortOrder = 11)
            )
            database.aidTypeDao().insertAidTypes(aidTypes)

            // 4. Seed Default Admin User
            val adminUser = User(
                userId = 1,
                userName = "admin",
                passwordHash = HashUtils.hashPassword("admin123"),
                fullName = "مدير النظام العام",
                roleId = 1,
                isActive = true,
                failedAttempts = 0
            )
            database.userDao().insertUser(adminUser)

            // Link admin to all 5 localities (full scope)
            val adminLocalities = localities.map { UserLocality(userId = 1, localityId = it.localityId) }
            database.userDao().assignUserLocalities(adminLocalities)

            // 5. Seed Initial Projects
            val project1 = Project(
                projectID = 1,
                projectName = "مشروع الإغاثة العاجلة والطرود الغذائية",
                projectNumber = "PRJ-2026-001",
                detailedDescription = "توزيع طرود تموينية وخضار للأسر المتضررة والمقيمة",
                fundingOrganization = "برنامج الغذاء العالمي والشركاء",
                startDate = System.currentTimeMillis() - 30L * 24 * 3600 * 1000,
                endDate = null,
                isActive = true
            )
            val project2 = Project(
                projectID = 2,
                projectName = "مشروع الإيواء الشتوي والفرشات",
                projectNumber = "PRJ-2026-002",
                detailedDescription = "تأمين الشوادر والفرشات ومستلزمات العزل للأسر النازحة والمقيمة",
                fundingOrganization = "مفوضية اللاجئين",
                startDate = System.currentTimeMillis() - 15L * 24 * 3600 * 1000,
                endDate = null,
                isActive = true
            )
            database.projectDao().insertProject(project1)
            database.projectDao().insertProject(project2)

            // 6. Seed Sample Families to verify all screens immediately
            val families = listOf(
                Family(
                    familyID = 1,
                    name = "أحمد محمد محمود خليل",
                    nationalID = "901234567",
                    birthDate = 473385600000L, // 1985
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 6,
                    wifeName = "فاطمة إبراهيم علي",
                    wifeNationalID = "902345678",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    workApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "كلي",
                    shelterStatus = "إيواء داخلي",
                    localityID = 1,
                    localityName = "الرمال الشمالي",
                    notes = "الأسرة مؤهلة بكامل المعايير للترشيح المباشر"
                ),
                Family(
                    familyID = 2,
                    name = "محمود حسن عبد الله النجار",
                    nationalID = "903456789",
                    birthDate = 441763200000L, // 1984
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 8,
                    wifeName = "مريم كمال سليم",
                    wifeNationalID = "904567890",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    workApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "جزئي غير صالح",
                    shelterStatus = "إيواء داخلي",
                    localityID = 2,
                    localityName = "الشيخ رضوان",
                    notes = "حالة إنسانية ملحة"
                ),
                Family(
                    familyID = 3,
                    name = "سعاد خليل إبراهيم رضوان",
                    nationalID = "905678901",
                    birthDate = 347155200000L, // 1981
                    gender = "أنثى",
                    maritalStatus = "أرملة",
                    familyMembersCount = 5,
                    deathStatus = true,
                    deathDate = 1698796800000L,
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    workApproval = "غير معتمد",
                    residentStatus = "نازح",
                    damageType = "كلي",
                    shelterStatus = "إيواء خارجي",
                    localityID = 3,
                    localityName = "الشاطئ الشمالي والنصر",
                    notes = "معيلة لأيتام"
                ),
                Family(
                    familyID = 4,
                    name = "عمر عبد الرحمن يوسف الباز",
                    nationalID = "906789012",
                    birthDate = 631152000000L, // 1990
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 4,
                    wifeName = "سارة ناصر العبد",
                    wifeNationalID = "907890123",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    workApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "كلي",
                    shelterStatus = "إيواء داخلي",
                    localityID = 4,
                    localityName = "الشاطئ الجنوبي",
                    notes = "مستوفية لمعايير الترشيح الآلي"
                ),
                Family(
                    familyID = 5,
                    name = "خالد مصطفى حسن شبات",
                    nationalID = "908901234",
                    birthDate = 504489600000L, // 1986
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 7,
                    wifeName = "أمل رفيق منصور",
                    wifeNationalID = "909012345",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    workApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "كلي",
                    shelterStatus = "إيواء داخلي",
                    localityID = 5,
                    localityName = "مشروع عامر",
                    notes = "منطقة مشروع عامر"
                )
            )

            for (f in families) {
                database.familyDao().insertFamily(f)
            }

            // 7. Seed Children
            val children = listOf(
                Child(childID = 1, familyID = 1, childNationalID = "410111222", childName = "يوسف أحمد خليل", birthDate = 1451606400000L, gender = "ذكر", localityID = 1),
                Child(childID = 2, familyID = 1, childNationalID = "410111223", childName = "آية أحمد خليل", birthDate = 1546300800000L, gender = "أنثى", localityID = 1),
                Child(childID = 3, familyID = 1, childNationalID = "410111224", childName = "كريم أحمد خليل", birthDate = 1640995200000L, gender = "ذكر", localityID = 1),
                Child(childID = 4, familyID = 2, childNationalID = "410222333", childName = "هناء محمود النجار", birthDate = 1420070400000L, gender = "أنثى", localityID = 2),
                Child(childID = 5, familyID = 2, childNationalID = "410222334", childName = "طارق محمود النجار", birthDate = 1577836800000L, gender = "ذكر", localityID = 2),
                Child(childID = 6, familyID = 4, childNationalID = "410444555", childName = "براء عمر الباز", birthDate = 1609459200000L, gender = "ذكر", localityID = 4)
            )
            for (c in children) {
                database.childDao().insertChild(c)
            }

            // 8. Seed Initial Aid Records (to test duplicate prevention & reports)
            val record1 = AidRecord(
                aidRecordID = 1,
                familyID = 1,
                nationalID = "901234567",
                aidTypeID = 1, // غذائي
                projectID = 1,
                detailedDescription = "طرد غذائي أساسي رقم 1",
                aidDate = System.currentTimeMillis() - 20L * 24 * 3600 * 1000,
                fundingOrganization = "برنامج الغذاء العالمي",
                aidValue = 75.0,
                localityID = 1,
                createdBy = 1
            )
            database.aidRecordDao().insertAidRecord(record1)
        }
    }
}
