package com.humanitarian.aidmanagement.civilregistry.model

/**
 * ثوابت المخطط الحرفي لقاعدة بيانات السجل المدني (civil_registry.db)
 * يُمنع تعديل أسماء الجدول أو الأعمدة — وحدة قراءة واستعلام فقط (Read-Only Lookup Module).
 */
object CivilRegistrySchema {
    const val DATABASE_FILE_NAME = "civil_registry.db"
    const val TABLE_NAME = "civil_registry"

    // الأعمدة الـ 14 المعتمدة حرفياً في جدول civil_registry
    const val COL_NATIONAL_ID = "رقم الهوية"
    const val COL_NAME = "الاسم"
    const val COL_BIRTH_DATE = "تاريخ_الميلاد"
    const val COL_MARITAL_STATUS = "الحالة الاجتماعية"
    const val COL_DEATH_STATUS = "الوفاة"
    const val COL_DEATH_DATE = "تاريخ_الوفاة"
    const val COL_GENDER = "الجنس"
    const val COL_DEV_PHONE = "جوال تنمية"
    const val COL_MOBILE_PHONE = "رقم الجوال"
    const val COL_MAIN_AREA = "المنطقة الرئيسية"
    const val COL_FAMILY_MEMBERS_COUNT = "عدد افراد الاسرة"
    const val COL_DEV_APPROVAL = "حالة اعتماد التنمية"
    const val COL_WIFE_NAME = "اسم الزوجة"
    const val COL_WIFE_NATIONAL_ID = "هويتها"

    val ALL_COLUMNS_SQL: String = listOf(
        COL_NATIONAL_ID,
        COL_NAME,
        COL_BIRTH_DATE,
        COL_MARITAL_STATUS,
        COL_DEATH_STATUS,
        COL_DEATH_DATE,
        COL_GENDER,
        COL_DEV_PHONE,
        COL_MOBILE_PHONE,
        COL_MAIN_AREA,
        COL_FAMILY_MEMBERS_COUNT,
        COL_DEV_APPROVAL,
        COL_WIFE_NAME,
        COL_WIFE_NATIONAL_ID
    ).joinToString(", ") { "\"$it\"" }
}

/**
 * نموذج سجل مواطن من السجل المدني (للقراءة فقط - Immutable Read-Only Model)
 * يحفظ جميع الأعمدة الـ 14 حرفياً دون حذف أي حقل.
 */
data class CivilRegistryRecord(
    val nationalId: String,
    val name: String,
    val birthDate: String,
    val maritalStatus: String,
    val deathStatus: String,
    val deathDate: String,
    val gender: String,
    val developmentPhone: String,
    val mobilePhone: String,
    val mainArea: String,
    val familyMembersCount: String,
    val developmentApprovalStatus: String,
    val wifeName: String,
    val wifeNationalId: String
) {
    /**
     * مفتاح فريد آمن للاستخدام في LazyColumn
     */
    val stableKey: String
        get() = "${nationalId}_${wifeNationalId}_${name.hashCode()}"
}

/**
 * نطاق البحث السريع في شريط البحث الموحد
 */
enum class CivilRegistrySearchScope(val label: String) {
    ALL("شامل"),
    NAME("الاسم"),
    NATIONAL_ID("رقم الهوية"),
    WIFE_NAME("اسم الزوجة"),
    WIFE_NATIONAL_ID("هوية الزوجة"),
    PHONES("أرقام الجوال")
}

/**
 * معايير البحث (يدعم البحث السريع المنفرد أو البحث المركّب المتزامن عبر الحقول الستة)
 */
data class CivilRegistrySearchQuery(
    val quickQuery: String = "",
    val scope: CivilRegistrySearchScope = CivilRegistrySearchScope.ALL,
    val advancedMode: Boolean = false,
    val nameFilter: String = "",
    val nationalIdFilter: String = "",
    val wifeNameFilter: String = "",
    val wifeNationalIdFilter: String = "",
    val phoneFilter: String = ""
) {
    val hasActiveCriteria: Boolean
        get() = if (advancedMode) {
            nameFilter.isNotBlank() ||
                nationalIdFilter.isNotBlank() ||
                wifeNameFilter.isNotBlank() ||
                wifeNationalIdFilter.isNotBlank() ||
                phoneFilter.isNotBlank()
        } else {
            quickQuery.trim().isNotEmpty()
        }
}

/**
 * نتيجة صفحة بحث مع دعم التحميل التدريجي (Incremental Pagination) دون استعلام COUNT(*) مكلف
 */
data class CivilRegistrySearchPage(
    val records: List<CivilRegistryRecord>,
    val hasMore: Boolean,
    val offset: Int
)

/**
 * حالة توفر قاعدة بيانات civil_registry.db
 */
sealed class CivilRegistryDbStatus {
    data object Checking : CivilRegistryDbStatus()
    data class Ready(val totalRecords: Long, val dbPath: String) : CivilRegistryDbStatus()
    data class Missing(val expectedPath: String) : CivilRegistryDbStatus()
    data class Error(val message: String) : CivilRegistryDbStatus()
}
