package com.humanitarian.aidmanagement.civilregistry.model

/**
 * ثوابت المخطط الحرفي لقاعدة بيانات السجل المدني (civil_registry.db)
 * يُمنع تعديل أسماء الجدول أو الأعمدة — وحدة قراءة واستعلام فقط (Read-Only Lookup Module).
 */
object CivilRegistrySchema {
    const val DATABASE_FILE_NAME = "civil_registry.db"
    const val TABLE_NAME = "civil_registry"

    // الأعمدة الـ 14 المعتمدة حرفياً في جدول civil_registry
    const val COL_NATIONAL_ID = "رقم الهوية"
    const val COL_NAME = "الاسم"
    const val COL_BIRTH_DATE = "تاريخ_الميلاد"
    const val COL_MARITAL_STATUS = "الحالة الاجتماعية"
    const val COL_DEATH_STATUS = "الوفاة"
    const val COL_DEATH_DATE = "تاريخ_الوفاة"
    const val COL_GENDER = "الجنس"
    const val COL_DEV_PHONE = "جوال تنمية"
    const val COL_MOBILE_PHONE = "رقم الجوال"
    const val COL_MAIN_AREA = "المنطقة الرئيسية"
    const val COL_FAMILY_MEMBERS_COUNT = "عدد افراد الاسرة"
    const val COL_DEV_APPROVAL = "حالة اعتماد التنمية"
    const val COL_WIFE_NAME = "اسم الزوجة"
    const val COL_WIFE_NATIONAL_ID = "هويتها"

    val ALL_COLUMNS_SQL: String = listOf(
        COL_NATIONAL_ID,
        COL_NAME,
        COL_BIRTH_DATE,
        COL_MARITAL_STATUS,
        COL_DEATH_STATUS,
        COL_DEATH_DATE,
        COL_GENDER,
        COL_DEV_PHONE,
        COL_MOBILE_PHONE,
        COL_MAIN_AREA,
        COL_FAMILY_MEMBERS_COUNT,
        COL_DEV_APPROVAL,
        COL_WIFE_NAME,
        COL_WIFE_NATIONAL_ID
    ).joinToString(", ") { "\"$it\"" }
}

/**
 * نموذج سجل مواطن من السجل المدني (للقراءة فقط - Immutable Read-Only Model)
 * يحفظ جميع الأعمدة الـ 14 حرفياً دون حذف أي حقل.
 */
data class CivilRegistryRecord(
    val nationalId: String,
    val name: String,
    val birthDate: String,
    val maritalStatus: String,
    val deathStatus: String,
    val deathDate: String,
    val gender: String,
    val developmentPhone: String,
    val mobilePhone: String,
    val mainArea: String,
    val familyMembersCount: String,
    val developmentApprovalStatus: String,
    val wifeName: String,
    val wifeNationalId: String
) {
    /**
     * مفتاح فريد آمن للاستخدام في LazyColumn
     */
    val stableKey: String
        get() = "${nationalId}_${wifeNationalId}_${name.hashCode()}"
}

/**
 * تبديل سريع خفيف لنطاق البحث في السجل المدني: (الكل / رب الأسرة / الابن)
 */
enum class CivilRegistrySearchTarget(val label: String) {
    ALL("الكل"),
    HEAD_OF_FAMILY("رب الأسرة"),
    CHILD("الابن")
}

/**
 * نطاق البحث السريع في شريط البحث الموحد
 */
enum class CivilRegistrySearchScope(val label: String) {
    ALL("شامل"),
    NAME("الاسم"),
    NATIONAL_ID("رقم الهوية"),
    WIFE_NAME("اسم الزوجة"),
    WIFE_NATIONAL_ID("هوية الزوجة"),
    PHONES("أرقام الجوال")
}

/**
 * معايير البحث (يدعم البحث السريع المنفرد أو البحث المركّب المتزامن عبر الحقول الستة + البحث بالابن)
 */
data class CivilRegistrySearchQuery(
    val quickQuery: String = "",
    val target: CivilRegistrySearchTarget = CivilRegistrySearchTarget.ALL,
    val scope: CivilRegistrySearchScope = CivilRegistrySearchScope.ALL,
    val advancedMode: Boolean = false,
    val nameFilter: String = "",
    val nationalIdFilter: String = "",
    val wifeNameFilter: String = "",
    val wifeNationalIdFilter: String = "",
    val phoneFilter: String = ""
) {
    val hasActiveCriteria: Boolean
        get() = if (advancedMode) {
            nameFilter.isNotBlank() ||
                nationalIdFilter.isNotBlank() ||
                wifeNameFilter.isNotBlank() ||
                wifeNationalIdFilter.isNotBlank() ||
                phoneFilter.isNotBlank()
        } else {
            quickQuery.trim().isNotEmpty()
        }
}

/**
 * نتيجة صفحة بحث مع دعم التحميل التدريجي (Incremental Pagination)
 * وإرفاق الأبناء المحمّلين مسبقاً والأبناء المطابقين للبحث عند البحث بالابن
 */
data class CivilRegistrySearchPage(
    val records: List<CivilRegistryRecord>,
    val hasMore: Boolean,
    val offset: Int,
    val preloadedChildrenByParentId: Map<String, List<CivilRegistryChildRecord>> = emptyMap(),
    val matchedChildKeysByParentId: Map<String, Set<String>> = emptyMap(),
    val matchedChildNamesByParentId: Map<String, List<String>> = emptyMap()
)

/**
 * ثوابت جدول الأبناء (children_registry) وجدول البحث النصي الفوري (children_fts) والعرض (v_children_with_age)
 */
object CivilRegistryChildrenSchema {
    const val TABLE_NAME = "children_registry"
    const val VIEW_NAME = "v_children_with_age"
    const val FTS_TABLE_NAME = "children_fts"
    const val FTS_COL_CHILD_NAME_NORM = "child_name_norm"

    const val COL_ID = "id"
    const val COL_PARENT_ID = "parent_id"
    const val COL_PARENT_NAME = "parent_name"
    const val COL_CHILD_ID = "child_id"
    const val COL_CHILD_NAME = "child_name"
    const val COL_GENDER = "gender"
    const val COL_SOCIAL_STATUS = "social_status"
    const val COL_REGION = "region"
    const val COL_CITY = "city"
    const val COL_BIRTH_DATE = "birth_date"
    const val COL_IS_WEST_GAZA = "is_west_gaza"

    val ALL_COLUMNS_SQL: String = listOf(
        COL_ID,
        COL_PARENT_ID,
        COL_PARENT_NAME,
        COL_CHILD_ID,
        COL_CHILD_NAME,
        COL_GENDER,
        COL_SOCIAL_STATUS,
        COL_REGION,
        COL_CITY,
        COL_BIRTH_DATE,
        COL_IS_WEST_GAZA
    ).joinToString(", ") { "\"$it\"" }
}

/**
 * نموذج سجل ابن من جدول children_registry في السجل المدني (للقراءة فقط)
 */
data class CivilRegistryChildRecord(
    val id: Long = 0L,
    val parentId: String,
    val parentName: String = "",
    val childId: String,
    val childName: String,
    val gender: String = "",
    val socialStatus: String = "",
    val region: String = "",
    val city: String = "",
    val birthDate: String = "",
    val isWestGaza: String = ""
) {
    val stableKey: String
        get() = "${parentId}_${childId}_${id}_${childName.hashCode()}"

    val matchIdentifier: String
        get() = childId.trim().ifBlank { "row_$id" }
}

/**
 * تقدم استيراد / نسخ ملف قاعدة بيانات civil_registry.db الكبيرة على Dispatchers.IO
 */
data class CivilRegistryImportProgress(
    val copiedBytes: Long = 0L,
    val totalBytes: Long = -1L,
    val stageMessage: String = "جاري نسخ وربط قاعدة السجل المدني..."
) {
    val fraction: Float?
        get() = if (totalBytes > 0L) (copiedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else null

    val percent: Int?
        get() = fraction?.let { (it * 100f).toInt().coerceIn(0, 100) }
}

/**
 * حالة توفر قاعدة بيانات civil_registry.db
 */
sealed class CivilRegistryDbStatus {
    data object Checking : CivilRegistryDbStatus()
    data class Ready(
        val totalRecords: Long,
        val dbPath: String,
        val hasChildrenRegistry: Boolean = false,
        val totalChildrenRecords: Long = 0L,
        val hasChildrenAgeView: Boolean = false,
        val hasChildrenFts: Boolean = false
    ) : CivilRegistryDbStatus()
    data class Missing(val expectedPath: String) : CivilRegistryDbStatus()
    data class Error(val message: String) : CivilRegistryDbStatus()
}
