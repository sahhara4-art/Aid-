package com.humanitarian.aidmanagement.util

import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * أداة موحدة لتطبيع وحسم تواريخ المساعدات والترشيح بصيغة ISO القياسية (YYYY-MM-DD):
 *
 * 1. قاعدة الإحصائيات والفترات (Delivery / Statistics Effective Date):
 *    - أولوية قصوى لتاريخ الاستلام الفعلي الصالح (`deliveryDate`) للمستفيدين.
 *    - عند عدم توفر تاريخ استلام فعلي صالح: الرجوع تلقائياً إلى تاريخ الترشيح
 *      (`actualNominationDate` ثم `selectionDate` ثم `aidDate`) بدلاً من تجاهل السجل.
 *
 * 2. قاعدة فلترة الترشيح (Nomination Effective Date):
 *    - اعتماد تاريخ الترشيح حصراً (`actualNominationDate` ثم `selectionDate` ثم `aidDate`).
 *    - يمنع استخدام `deliveryDate` نهائياً كمرجع لفلترة أو استثناء الترشيح.
 */
object DateNormalizationUtil {

    private val BENEFICIARY_STATUSES = setOf("مستفيد", "تم التسليم", "مستلم")

    private val INVALID_PLACEHOLDERS = setOf(
        "", "-", "--", "null", "n/a", "na", "none", "غير محدد", "غير مدخل", "لم يستلم",
        "0000-00-00", "1970-01-01", "01-01-1970", "0000/00/00", "1970/01/01", "01/01/1970"
    )

    /**
     * تحويل الأرقام العربية/الفارسية إلى أرقام لاتينية ASCII لضمان دقة المقارنة النصية في SQLite و Kotlin.
     */
    fun toAsciiDigits(input: String): String {
        if (input.isEmpty()) return input
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    /**
     * توحيد أي صيغة تاريخ شائعة (YYYY-MM-DD، YYYY/M/D، DD/MM/YYYY، DD-MM-YYYY، MM/DD/YYYY، YYYYMMDD، مع أو بدون وقت أو أرقام عربية)
     * إلى صيغة ISO الصارمة `YYYY-MM-DD`، أو إرجاع null إذا لم يكن تاريخاً صالحاً.
     */
    fun normalizeToIsoDate(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val ascii = toAsciiDigits(raw.trim())
        val lower = ascii.lowercase(Locale.US)
        if (lower in INVALID_PLACEHOLDERS) return null

        val datePart = ascii
            .replace('T', ' ')
            .substringBefore(' ')
            .trim()
            .replace('/', '-')
            .replace('.', '-')
            .replace('\\', '-')

        if (datePart.isEmpty() || datePart.lowercase(Locale.US) in INVALID_PLACEHOLDERS) return null

        // صيغة 8 أرقام متصلة YYYYMMDD
        if (datePart.length == 8 && datePart.all { it.isDigit() }) {
            val y = datePart.substring(0, 4).toIntOrNull() ?: return null
            val m = datePart.substring(4, 6).toIntOrNull() ?: return null
            val d = datePart.substring(6, 8).toIntOrNull() ?: return null
            return formatValidatedIso(y, m, d)
        }

        val parts = datePart.split('-')
        if (parts.size != 3) return null
        val p0 = parts[0].toIntOrNull() ?: return null
        val p1 = parts[1].toIntOrNull() ?: return null
        val p2 = parts[2].toIntOrNull() ?: return null

        return when {
            // YYYY-M-D أو YYYY-MM-DD
            parts[0].length == 4 -> formatValidatedIso(p0, p1, p2)
            // D-M-YYYY أو DD-MM-YYYY (مع دعم MM-DD-YYYY تلقائياً إذا كان الجزء الأوسط > 12)
            parts[2].length == 4 -> {
                if (p1 > 12 && p0 in 1..12) {
                    formatValidatedIso(p2, p0, p1)
                } else {
                    formatValidatedIso(p2, p1, p0)
                }
            }
            else -> null
        }
    }

    private fun formatValidatedIso(year: Int, month: Int, day: Int): String? {
        if (year !in 1980..2100 || month !in 1..12 || day !in 1..31) return null
        return String.format(Locale.US, "%04d-%02d-%02d", year, month, day)
    }

    /**
     * توحيد حدود نطاق التاريخ الممررة من المستخدم أو الفلاتر إلى YYYY-MM-DD.
     */
    fun normalizeFilterBound(raw: String?, fallback: String = todayIsoDate()): String {
        return normalizeToIsoDate(raw) ?: normalizeToIsoDate(fallback) ?: todayIsoDate()
    }

    /**
     * القاعدة 1 (الإحصائيات والفترات):
     * للمستفيدين: تاريخ الاستلام الفعلي الصالح أولاً، وعند غيابه أو عدم صلاحيته يتم الرجوع إلى تاريخ الترشيح
     * (`actualNominationDate` ثم `selectionDate` ثم `aidDate`).
     */
    fun resolveDeliveryOrNominationDate(record: AidRecordEntity?): String? {
        if (record == null) return null
        val status = record.recipientStatus.trim()
        if (status in BENEFICIARY_STATUSES) {
            normalizeToIsoDate(record.deliveryDate)?.let { return it }
        }
        return resolveNominationDate(record)
    }

    /**
     * القاعدة 2 (فلترة واستثناءات الترشيح):
     * اعتماد تاريخ الترشيح حصراً (`actualNominationDate` ثم `selectionDate` ثم `aidDate`)
     * دون استخدام `deliveryDate` إطلاقاً.
     */
    fun resolveNominationDate(record: AidRecordEntity?): String? {
        if (record == null) return null
        return normalizeToIsoDate(record.actualNominationDate)
            ?: normalizeToIsoDate(record.selectionDate)
            ?: normalizeToIsoDate(record.aidDate)
    }

    fun parseIsoDateMillis(raw: String?): Long? {
        val iso = normalizeToIsoDate(raw) ?: return null
        return try {
            val parts = iso.split('-')
            val cal = Calendar.getInstance(Locale.US).apply {
                clear()
                set(parts[0].toInt(), parts[1].toInt() - 1, parts[2].toInt(), 0, 0, 0)
            }
            cal.timeInMillis
        } catch (_: Exception) {
            null
        }
    }

    fun todayIsoDate(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    fun nowIsoDateTime(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    }

    fun nowIsoDateTimeMinute(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
    }

    /**
     * توحيد تاريخ المشروع بصيغة ISO (YYYY-MM-DD) لأغراض الترتيب الدقيق من الأحدث إلى الأقدم.
     */
    fun resolveProjectSortDate(projectDate: String?, actualNominationDate: String? = null): String {
        return normalizeToIsoDate(projectDate)
            ?: normalizeToIsoDate(actualNominationDate)
            ?: "0000-00-00"
    }

    /**
     * ترتيب قائمة المشاريع دائماً من الأحدث إلى الأقدم حسب التاريخ الموحّد (YYYY-MM-DD)
     * ثم حسب المعرّف الأحدث (projectID DESC) كمرجع ثانوي عند تساوي التاريخ.
     */
    fun List<ProjectEntity>.sortedProjectsNewestFirst(): List<ProjectEntity> {
        return sortedWith(
            compareByDescending<ProjectEntity> { resolveProjectSortDate(it.projectDate, it.actualNominationDate) }
                .thenByDescending { it.projectID }
        )
    }

    inline fun <T> List<T>.sortedByProjectNewestFirst(
        crossinline dateSelector: (T) -> String?,
        crossinline secondaryDateSelector: (T) -> String? = { null },
        crossinline idSelector: (T) -> Long
    ): List<T> {
        return sortedWith(
            compareByDescending<T> { resolveProjectSortDate(dateSelector(it), secondaryDateSelector(it)) }
                .thenByDescending { idSelector(it) }
        )
    }
}
