package com.humanitarian.aidmanagement.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.User
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    database: AidDatabase,
    currentUser: User,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val users by database.userDao().getAllUsers().collectAsState(initial = emptyList())
    val roles by database.roleDao().getActiveRoles().collectAsState(initial = emptyList())
    val localities by database.localityDao().getAllLocalities().collectAsState(initial = emptyList())
    val aidTypes by database.aidTypeDao().getAllActiveAidTypes().collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("المستخدمون", "الأدوار والصلاحيات", "المحليات", "أنواع المساعدات", "قواعد الترشيح")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("إعدادات النظام والتهيئة", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "القائمة")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp,
                containerColor = Color.White
            ) {
                tabTitles.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                when (selectedTab) {
                    0 -> { // Users
                        item {
                            Text("قائمة حسابات المستخدمين النشطة (${users.size})", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
                        }
                        items(users) { user ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(2.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(user.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("اسم الدخول: ${user.userName}", fontSize = 12.sp, color = Color(0xFF64748B))
                                        Text("دور: ${roles.find { it.roleId == user.roleId }?.roleName ?: "دور ${user.roleId}"}", fontSize = 12.sp, color = Color(0xFF2E7D32))
                                    }
                                    Surface(
                                        color = if (user.isActive) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            if (user.isActive) "نشط" else "معطل",
                                            color = if (user.isActive) Color(0xFF16A34A) else Color(0xFFDC2626),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    1 -> { // Roles & Permissions
                        item {
                            Text("الأدوار والصلاحيات المعتمدة", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
                        }
                        items(roles) { r ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(r.roleName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Spacer(Modifier.height(4.dp))
                                    Text("الصلاحيات: مشاهدة، إضافة، تعديل، حذف، ترشيح، تقارير، تصدير", fontSize = 12.sp, color = Color(0xFF64748B))
                                }
                            }
                        }
                    }

                    2 -> { // Localities
                        item {
                            Text("المحليات الميدانية الـ 5 المعتمدة", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
                        }
                        items(localities) { loc ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${loc.sortOrder}. ${loc.localityName}", fontWeight = FontWeight.Bold)
                                    Text("معتمدة", color = Color(0xFF2E7D32), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    3 -> { // Aid Types
                        item {
                            Text("أنواع المساعدات الإنسانية الـ 11", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
                        }
                        items(aidTypes) { type ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${type.sortOrder}. ${type.aidTypeName}", fontWeight = FontWeight.Bold)
                                    Text("نشط", color = Color(0xFF2E7D32), fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    4 -> { // Rules
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                elevation = CardDefaults.cardElevation(2.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("قواعد الترشيح ومنع التكرار المعتمدة", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2), fontSize = 15.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text("1. التحقق من اعتماد التنمية الاجتماعية: معتمد", fontSize = 13.sp)
                                    Text("2. حالة الإقامة الأساسية: مقيم", fontSize = 13.sp)
                                    Text("3. اعتماد الأشغال العامة: معتمد أشغال", fontSize = 13.sp)
                                    Text("4. حالة الإيواء: إيواء داخلي", fontSize = 13.sp)
                                    Text("5. تقييد العمليات بنطاق المحليات الجغرافي للموظف", fontSize = 13.sp)
                                    Text("6. منع ترشيح أي أسرة استلمت نفس نوع المساعدة سابقاً", fontSize = 13.sp)
                                    Text("7. قفل الحساب التلقائي بعد 5 محاولات دخول خاطئة لمدة 15 دقيقة", fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
