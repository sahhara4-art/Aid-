package com.humanitarian.aidmanagement.crash

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.humanitarian.aidmanagement.MainActivity

/**
 * شاشة الصندوق الأسود لالتقاط وعرض تفاصيل أي انهيار مفاجئ في التطبيق.
 * مبنية حصراً بـ Android Native Views البسيطة (بدون Compose أو Hilt أو Room)
 * وتعمل في عملية مستقلة (:crash_report) لضمان عدم انهيارها مع التطبيق أبداً.
 */
class CrashActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            requestWindowFeature(Window.FEATURE_NO_TITLE)
        } catch (_: Throwable) {
        }

        val errorDetails = intent?.getStringExtra(EXTRA_ERROR)
            ?.takeIf { it.isNotBlank() }
            ?: "حدث خطأ غير متوقع، ولكن لم تتوفر تفاصيل إضافية عن الانهيار."

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F172A"))
            fitsSystemWindows = true
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            val padH = dp(16)
            val padV = dp(20)
            setPadding(padH, padV, padH, padV)
        }

        // العنوان الرئيسي التحذيري
        val titleView = TextView(this).apply {
            text = "توقف التطبيق بشكل غير متوقع (الصندوق الأسود)"
            setTextColor(Color.parseColor("#F87171"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.START
            setPadding(0, 0, 0, dp(6))
        }
        rootLayout.addView(titleView)

        val subtitleView = TextView(this).apply {
            text = "يرجى نسخ تفاصيل الخطأ أدناه وإرسالها للدعم الفني لتحديد السبب الجذري فوراً."
            setTextColor(Color.parseColor("#CBD5E1"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.START
            setPadding(0, 0, 0, dp(14))
        }
        rootLayout.addView(subtitleView)

        // شريط الأزرار العلوي: نسخ تفاصيل الخطأ + إعادة تشغيل التطبيق
        val buttonsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(14)
            }
        }

        val copyButton = Button(this).apply {
            text = "نسخ تفاصيل الخطأ"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            background = createRoundedDrawable("#059669", dp(10).toFloat())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            ).apply {
                marginEnd = dp(8)
            }
            setOnClickListener {
                copyErrorToClipboard(errorDetails)
            }
        }

        val restartButton = Button(this).apply {
            text = "إعادة تشغيل التطبيق"
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            background = createRoundedDrawable("#2563EB", dp(10).toFloat())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            ).apply {
                marginStart = dp(8)
            }
            setOnClickListener {
                restartApplication()
            }
        }

        buttonsRow.addView(copyButton)
        buttonsRow.addView(restartButton)
        rootLayout.addView(buttonsRow)

        // حاوية نص الخطأ القابلة للتمرير والنسخ
        val scrollView = ScrollView(this).apply {
            isFillViewport = true
            background = createRoundedDrawable("#1E293B", dp(12).toFloat(), "#334155")
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }

        val stackTraceView = TextView(this).apply {
            text = errorDetails
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.MONOSPACE
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            textDirection = View.TEXT_DIRECTION_LTR
            setTextIsSelectable(true)
            setLineSpacing(dp(2).toFloat(), 1.15f)
        }

        scrollView.addView(stackTraceView)
        rootLayout.addView(scrollView)

        setContentView(rootLayout)
    }

    private fun copyErrorToClipboard(errorText: String) {
        try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            if (clipboard != null) {
                val clip = ClipData.newPlainText("CrashErrorDetails", errorText)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(this, "تم نسخ تفاصيل الخطأ إلى الحافظة", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "تعذر الوصول إلى الحافظة", Toast.LENGTH_SHORT).show()
            }
        } catch (_: Throwable) {
            Toast.makeText(this, "تعذر نسخ النص، يمكنك تحديده يدوياً", Toast.LENGTH_SHORT).show()
        }
    }

    private fun restartApplication() {
        try {
            val restartIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            }
            startActivity(restartIntent)
            finish()
        } catch (_: Throwable) {
            try {
                val launchIntent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
                if (launchIntent != null) {
                    startActivity(launchIntent)
                }
            } catch (_: Throwable) {
            }
            finish()
        }
    }

    private fun createRoundedDrawable(
        fillHex: String,
        radiusPx: Float,
        strokeHex: String? = null
    ): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
            setColor(Color.parseColor(fillHex))
            if (strokeHex != null) {
                setStroke(dp(1), Color.parseColor(strokeHex))
            }
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    companion object {
        const val EXTRA_ERROR = "error"
    }
}
