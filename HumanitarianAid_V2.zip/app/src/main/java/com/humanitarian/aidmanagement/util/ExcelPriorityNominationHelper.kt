package com.humanitarian.aidmanagement.util

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.CellType
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.WorkbookFactory
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.math.BigDecimal
import java.nio.charset.StandardCharsets

/**
 * نموذج التغذية الراجعة التفصيلية لكل صف في ملف الإكسل / CSV
 */
data class ExcelNominationFeedback(
    val rowNumber: Int,
    val nationalId: String,
    val familyName: String,
    val localArea: String,
    val familyStatus: String,
    val isAccepted: Boolean,
    val feedbackReason: String,
    val matchedFamilyId: Long? = null
) {
    val decisionLabel: String
        get() = if (isAccepted) "مقبول ومرشح" else "مرفوض"
}

/**
 * ملخص نتائج عملية الترشيح من ملف إكسل مع قائمة التغذية الراجعة الكاملة
 */
data class ExcelNominationResult(
    val fileName: String,
    val totalReadCount: Int,
    val acceptedCount: Int,
    val rejectedCount: Int,
    val feedbackList: List<ExcelNominationFeedback>
)

data class ParsedExcelNationalIdRow(
    val rowNumber: Int,
    val cleanedNationalId: String
)

/**
 * أداة مساعدة لقراءة ملفات Excel (.xlsx / .xls) و CSV لاستخراج أرقام الهويات تلقائياً
 * وتصدير تقرير التغذية الراجعة بصيغة CSV (UTF-8 مع BOM) جاهزة للفتح المباشر في Microsoft Excel باللغة العربية.
 */
object ExcelPriorityNominationHelper {

    private val HEADER_KEYWORDS = listOf(
        "رقم الهوية", "الهوية", "هوية", "رقم هوية", "هوية رب الأسرة",
        "رقم هوية رب الأسرة", "هوية المستفيد", "رقم المستفيد",
        "nationalid", "national_id", "national id", "id_number", "id number", "id"
    )

    private val ARABIC_DIGITS_MAP = mapOf(
        '٠' to '0', '١' to '1', '٢' to '2', '٣' to '3', '٤' to '4',
        '٥' to '5', '٦' to '6', '٧' to '7', '٨' to '8', '٩' to '9',
        '۰' to '0', '۱' to '1', '۲' to '2', '۳' to '3', '۴' to '4',
        '۵' to '5', '۶' to '6', '۷' to '7', '۸' to '8', '۹' to '9'
    )

    /**
     * تنظيف وتوحيد رقم الهوية من المسافات والأرقام العربية والفواصل العشرية (.0) والترميز العلمي والأصفار الزائدة.
     */
    fun normalizeNationalId(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val trimmed = raw
            .replace("\uFEFF", "")
            .replace("\u00A0", "")
            .trim()
        if (trimmed.isEmpty()) return ""

        // تحويل الأرقام العربية/الفارسية إلى إنجليزية
        val latin = buildString(trimmed.length) {
            for (ch in trimmed) {
                append(ARABIC_DIGITS_MAP[ch] ?: ch)
            }
        }.trim()

        // معالجة الأرقام العلمية من Excel مثل 4.01234567E8 أو الأرقام المنتهية بـ .0
        val plainNumeric = if (latin.contains("E", ignoreCase = true) || latin.contains(".")) {
            runCatching {
                BigDecimal(latin.replace(",", "")).toBigInteger().toString()
            }.getOrElse { latin }
        } else {
            latin
        }

        // الاحتفاظ بالأرقام فقط (إزالة الشرطات والمسافات والرموز الخفية)
        var digits = plainNumeric.filter { it.isDigit() }
        if (digits.isEmpty()) return ""

        // إزالة الأصفار البادئة الزائدة فقط إذا تجاوز الطول 9 خانات (مع الحفاظ على الهويات الفلسطينية ذات الـ 9 خانات مثل 040... أو 40...)
        while (digits.length > 9 && digits.startsWith("0")) {
            digits = digits.drop(1)
        }
        return digits
    }

    /**
     * قراءة ملف إكسل (.xlsx / .xls) أو .csv من URI على Dispatchers.IO واستخراج أرقام الهويات.
     */
    suspend fun parseNationalIdsFromUri(
        context: Context,
        uri: Uri,
        fileName: String
    ): List<ParsedExcelNationalIdRow> = withContext(Dispatchers.IO) {
        val lowerName = fileName.lowercase()
        val mime = context.contentResolver.getType(uri)?.lowercase().orEmpty()
        val isCsv = lowerName.endsWith(".csv") || lowerName.endsWith(".txt") ||
            mime.contains("csv") || mime.contains("text/plain")

        if (isCsv) {
            parseCsv(context, uri)
        } else {
            runCatching { parseExcelWorkbook(context, uri) }
                .getOrElse { parseCsv(context, uri) }
        }
    }

    private fun parseExcelWorkbook(context: Context, uri: Uri): List<ParsedExcelNationalIdRow> {
        val rows = mutableListOf<List<String>>()
        val formatter = DataFormatter()

        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            WorkbookFactory.create(inputStream).use { workbook ->
                val sheet = workbook.getSheetAt(0) ?: return emptyList()
                for (rowIndex in sheet.firstRowNum..sheet.lastRowNum) {
                    val row = sheet.getRow(rowIndex) ?: continue
                    val lastCol = row.lastCellNum.toInt().coerceAtLeast(0)
                    if (lastCol == 0) continue
                    val cells = ArrayList<String>(lastCol)
                    var hasAnyData = false
                    for (col in 0 until lastCol) {
                        val cell = row.getCell(col)
                        val text = extractCellString(cell, formatter)
                        if (text.isNotBlank()) hasAnyData = true
                        cells.add(text)
                    }
                    if (hasAnyData) {
                        rows.add(cells)
                    }
                }
            }
        }
        return extractNationalIdRows(rows)
    }

    private fun extractCellString(cell: Cell?, formatter: DataFormatter): String {
        if (cell == null) return ""
        return when (cell.cellType) {
            CellType.NUMERIC -> {
                val numeric = cell.numericCellValue
                runCatching {
                    BigDecimal.valueOf(numeric).toBigInteger().toString()
                }.getOrElse {
                    formatter.formatCellValue(cell).trim()
                }
            }
            CellType.STRING -> cell.stringCellValue?.trim().orEmpty()
            CellType.FORMULA -> runCatching {
                formatter.formatCellValue(cell).trim()
            }.getOrDefault("")
            else -> formatter.formatCellValue(cell).trim()
        }
    }

    private fun parseCsv(context: Context, uri: Uri): List<ParsedExcelNationalIdRow> {
        val rows = mutableListOf<List<String>>()
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            BufferedReader(InputStreamReader(inputStream, StandardCharsets.UTF_8)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val rawLine = line?.replace("\uFEFF", "").orEmpty()
                    if (rawLine.isBlank()) continue
                    val delimiter = when {
                        rawLine.contains(";") && !rawLine.contains(",") -> ';'
                        rawLine.contains("\t") && !rawLine.contains(",") -> '\t'
                        else -> ','
                    }
                    val parsed = splitCsvLine(rawLine, delimiter)
                    if (parsed.any { it.isNotBlank() }) {
                        rows.add(parsed)
                    }
                }
            }
        }
        return extractNationalIdRows(rows)
    }

    private fun splitCsvLine(line: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                c == '"' -> {
                    if (inQuotes && i + 1 < line.length && line[i + 1] == '"') {
                        current.append('"')
                        i++
                    } else {
                        inQuotes = !inQuotes
                    }
                }
                c == delimiter && !inQuotes -> {
                    result.add(current.toString().trim())
                    current.clear()
                }
                else -> current.append(c)
            }
            i++
        }
        result.add(current.toString().trim())
        return result
    }

    private fun extractNationalIdRows(rows: List<List<String>>): List<ParsedExcelNationalIdRow> {
        if (rows.isEmpty()) return emptyList()

        // 1. البحث عن عمود الهوية في صف العناوين (أول 3 صفوف)
        var detectedCol = -1
        var startRowIdx = 0

        val headerScanLimit = minOf(3, rows.size)
        for (r in 0 until headerScanLimit) {
            val row = rows[r]
            val foundIdx = row.indexOfFirst { cell ->
                val clean = cell.trim().lowercase()
                HEADER_KEYWORDS.any { kw -> clean == kw || clean.contains(kw) }
            }
            if (foundIdx >= 0) {
                detectedCol = foundIdx
                startRowIdx = r + 1
                break
            }
        }

        // 2. إذا لم يوجد صف عنوان صريح، نكتشف العمود الذي يحتوي على أكبر عدد من أرقام الهويات (7-12 خانة)
        if (detectedCol < 0) {
            val maxCols = rows.maxOfOrNull { it.size } ?: 0
            val colScores = IntArray(maxCols)
            val sampleLimit = minOf(30, rows.size)
            for (r in 0 until sampleLimit) {
                val row = rows[r]
                for (c in row.indices) {
                    val norm = normalizeNationalId(row[c])
                    if (norm.length in 7..12) {
                        colScores[c]++
                    }
                }
            }
            val bestCol = colScores.indices.maxByOrNull { colScores[it] } ?: 0
            detectedCol = if (colScores.isNotEmpty() && colScores[bestCol] > 0) bestCol else 0
            // فحص إن كان الصف الأول نصاً (ترويسة غير قياسية)
            val firstCellNorm = normalizeNationalId(rows.first().getOrNull(detectedCol))
            startRowIdx = if (firstCellNorm.isEmpty()) 1 else 0
        }

        val extracted = mutableListOf<ParsedExcelNationalIdRow>()
        for (idx in startRowIdx until rows.size) {
            val row = rows[idx]
            val rawVal = row.getOrNull(detectedCol) ?: continue
            val cleaned = normalizeNationalId(rawVal)
            if (cleaned.isNotEmpty()) {
                extracted.add(
                    ParsedExcelNationalIdRow(
                        rowNumber = idx + 1,
                        cleanedNationalId = cleaned
                    )
                )
            }
        }
        return extracted
    }

    /**
     * تصدير جدول التغذية الراجعة بالكامل بصيغة CSV مع UTF-8 BOM لضمان فتحه باللغة العربية السليمة داخل Microsoft Excel.
     */
    suspend fun exportFeedbackCsvToUri(
        context: Context,
        uri: Uri,
        feedbackList: List<ExcelNominationFeedback>
    ): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val os = context.contentResolver.openOutputStream(uri)
                ?: throw IllegalStateException("تعذر فتح مسار الحفظ المحدد")
            os.use { stream ->
                OutputStreamWriter(stream, StandardCharsets.UTF_8).use { writer ->
                    // UTF-8 BOM لضمان عرض الأحرف العربية بشكل صحيح في Microsoft Excel
                    writer.write("\uFEFF")
                    writer.write(
                        listOf(
                            "رقم الهوية",
                            "اسم رب الأسرة",
                            "المنطقة المحلية",
                            "حالة الأسرة",
                            "قرار الترشيح",
                            "سبب الرفض / ملاحظات التدقيق"
                        ).joinToString(",") { escapeCsv(it) }
                    )
                    writer.write("\r\n")

                    feedbackList.forEach { item ->
                        val line = listOf(
                            item.nationalId,
                            item.familyName,
                            item.localArea,
                            item.familyStatus,
                            item.decisionLabel,
                            item.feedbackReason
                        ).joinToString(",") { escapeCsv(it) }
                        writer.write(line)
                        writer.write("\r\n")
                    }
                    writer.flush()
                }
            }
            feedbackList.size
        }
    }

    private fun escapeCsv(value: String): String {
        val safe = value.replace("\r", " ").replace("\n", " ").trim()
        val escaped = safe.replace("\"", "\"\"")
        return "\"" + escaped + "\""
    }
}
