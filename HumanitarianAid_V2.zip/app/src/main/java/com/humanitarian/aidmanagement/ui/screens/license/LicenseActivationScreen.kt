package com.humanitarian.aidmanagement.ui.screens.license

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.security.DeviceUtils
import com.humanitarian.aidmanagement.security.LicenseManager
import com.humanitarian.aidmanagement.security.LicenseStatus
import com.humanitarian.aidmanagement.ui.theme.*

/**
 * شاشة القفل الإلزامية لتفعيل الترخيص العضوي المرتبط بالعتاد (Hardware-Bound DRM).
 * لا يمكن تخطيها أو العودة منها دون إدخال كود تفعيل AES صالح ومطابق لبصمة الجهاز وغير منتهي الصلاحية.
 */
@Composable
fun LicenseActivationScreen(
    licenseStatus: LicenseStatus,
    onLicenseActivated: () -> Unit
) {
    // منع الخروج من شاشة القفل عبر زر الرجوع في النظام
    BackHandler(enabled = true) { }

    val context = LocalContext.current
    val appContext = remember(context) { context.applicationContext ?: context }
    val clipboardManager = LocalClipboardManager.current
    val hardwareId = remember {
        try {
            DeviceUtils.getHardwareId(appContext)
        } catch (_: Throwable) {
            "HW-0000-0000-0000"
        }
    }
    val deviceSummary = remember {
        try {
            DeviceUtils.getDeviceSummary()
        } catch (_: Throwable) {
            "Android Device"
        }
    }

    var licenseInput by remember { mutableStateOf("") }
    var errorMessage by remember(licenseStatus) {
        mutableStateOf(
            when (licenseStatus) {
                is LicenseStatus.Expired ->
                    "انتهت صلاحية الترخيص السابق بتاريخ ${licenseStatus.expiryDate}. يرجى إدخال كود تجديد."
                is LicenseStatus.HardwareMismatch ->
                    "الترخيص المخزن لا يطابق بصمة هذا الجهاز (${licenseStatus.actualHwId})."
                is LicenseStatus.Invalid -> licenseStatus.reason
                else -> null
            }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF1E293B),
                        Color(0xFF064E3B)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(PalestineGreen.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = null,
                    tint = Color(0xFF34D399),
                    modifier = Modifier.size(40.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "تفعيل الترخيص العضوي للنظام",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "هذا التطبيق محمي بنظام ترخيص مشفر مرتبط ببصمة الجهاز. أرسل رقم الجهاز إلى الإدارة للحصول على كود التفعيل.",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFCBD5E1),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(22.dp))

            // بطاقة عرض البصمة العتادية للجهاز (HW-ID)
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF1E293B).copy(alpha = 0.92f),
                border = BorderStroke(1.dp, Color(0xFF334155)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneAndroid,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "بصمة الجهاز الفريدة (Hardware ID)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    if (deviceSummary.isNotBlank()) {
                        Text(
                            text = deviceSummary,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF0F172A),
                        border = BorderStroke(1.dp, Color(0xFF059669).copy(alpha = 0.55f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = hardwareId,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 6.dp, vertical = 8.dp),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = Color(0xFF34D399),
                                textAlign = TextAlign.Center
                            )
                            IconButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(hardwareId))
                                    Toast.makeText(context, "تم نسخ بصمة الجهاز", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "نسخ بصمة الجهاز",
                                    tint = Color(0xFF38BDF8)
                                )
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(hardwareId))
                            Toast.makeText(context, "تم نسخ بصمة الجهاز", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFF38BDF8)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFF38BDF8)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("نسخ رقم الجهاز (HW-ID)", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // بطاقة إدخال كود التفعيل المشفر
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "إدخال كود التفعيل (Base64)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = SlateTextPrimary
                        )
                        TextButton(
                            onClick = {
                                val pasted = clipboardManager.getText()?.text.orEmpty().trim()
                                if (pasted.isNotEmpty()) {
                                    licenseInput = pasted
                                    errorMessage = null
                                } else {
                                    Toast.makeText(context, "الحافظة فارغة", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("لصق", fontWeight = FontWeight.Bold)
                        }
                    }

                    OutlinedTextField(
                        value = licenseInput,
                        onValueChange = {
                            licenseInput = it
                            errorMessage = null
                        },
                        label = { Text("كود التفعيل المشفر") },
                        placeholder = { Text("الصق كود التفعيل الصادر من الإدارة هنا...") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PalestineGreen,
                            unfocusedBorderColor = SlateBorder
                        )
                    )

                    if (!errorMessage.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = StatusErrorBg,
                            border = BorderStroke(1.dp, StatusErrorBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = null,
                                    tint = StatusError,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = errorMessage.orEmpty(),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PalestineRedDark,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Button(
                        onClick = {
                            val result = LicenseManager.activateLicense(appContext, licenseInput)
                            if (result.isValid) {
                                Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                                onLicenseActivated()
                            } else {
                                errorMessage = result.message
                            }
                        },
                        enabled = licenseInput.isNotBlank(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PalestineGreen,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        Icon(Icons.Default.LockOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تفعيل الترخيص وفتح النظام",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // التوقيع السيادي للمطور (High-Visibility Footer)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = "منظومة القيادة والسيطرة الميدانية.\nتصميم وهندسة: أحمد السحار (أبو محمود).\nللحصول على مفتاح الترخيص، يرجى إرسال بصمة الجهاز عبر واتساب: 0592778856",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
