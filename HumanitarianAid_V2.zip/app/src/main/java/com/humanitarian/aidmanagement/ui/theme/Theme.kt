package com.humanitarian.aidmanagement.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val LightColorScheme = lightColorScheme(
    primary = PalestineGreen,
    onPrimary = PalestineWhite,
    primaryContainer = PalestineGreenContainer,
    onPrimaryContainer = PalestineGreenDark,
    secondary = PalestineRed,
    onSecondary = PalestineWhite,
    secondaryContainer = PalestineRedContainer,
    onSecondaryContainer = PalestineRedDark,
    tertiary = PalestineGold,
    background = SlateBackground,
    surface = SlateSurface,
    surfaceVariant = SlateSurfaceVariant,
    onBackground = SlateTextPrimary,
    onSurface = SlateTextPrimary,
    onSurfaceVariant = SlateTextSecondary,
    outline = SlateBorderSubtle,
    outlineVariant = SlateBorder,
    error = PalestineRed,
    onError = PalestineWhite
)

private val DarkColorScheme = darkColorScheme(
    primary = PalestineGreen,
    onPrimary = PalestineWhite,
    primaryContainer = PalestineGreenDark,
    onPrimaryContainer = PalestineGreenContainer,
    secondary = PalestineRed,
    onSecondary = PalestineWhite,
    background = SlateTextPrimary,
    surface = PalestineBlack,
    surfaceVariant = SlateTextSecondary,
    onBackground = SlateSurfaceVariant,
    onSurface = SlateSurfaceVariant,
    error = PalestineRed
)

@Composable
fun HumanitarianAidTheme(
    darkTheme: Boolean = false, // الوضع الفاتح العصري افتراضياً مع بصمة فلسطين الوطنية
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    // فرض اتجاه اليمين إلى اليسار (RTL) للغة العربية في كافة الشاشات
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
