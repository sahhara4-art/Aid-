package com.humanitarian.aidmanagement.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.coroutines.coroutineContext

enum class AgeExportReportType {
    DETAILED_CHILDREN,
    SUMMARY_FAMILIES
}

enum class AgeExportFormat(
    val extension: String,
    val mimeType: String,
    val labelAr: String
) {
    XLSX(
        extension = "xlsx",
        mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        labelAr = "Excel (.xlsx)"
    ),
    CSV(
        extension = "csv",
        mimeType = "text/csv",
        labelAr = "CSV (UTF-8 مع BOM)"
    )
}

data class AgeExportCriteria(
    val searchQuery: String = "",
    val localityId: Int = 0,
    val localityName: String = "",
    val branchName: String = "",
    val shelterStatus: String = "",
    val ageFilterActive: Boolean = false,
    val minYears: Int = 0,
    val minMonths: Int = 0,
    val maxYears: Int = 18,
    val maxMonths: Int = 0,
    val minBirthDateIso: String? = null,
    val maxBirthDateIso: String? = null,
    val gender: String = "الكل"
) {
    val cleanGender: String?
        get() = gender.trim().takeIf { it.isNotEmpty() && it != "الكل" }

    fun buildAgeFileSlug(): String {
        val agePart = if (!ageFilterActive) {
            "جميع_الاعمار"
        } else {
            val fromPart = formatBoundSlug(minYears, minMonths)
            val toPart = formatBoundSlug(maxYears, maxMonths)
            "من_${fromPart}_الى_${toPart}"
        }
        val genderPart = when (cleanGender) {
            "ذكر" -> "_ذكور"
            "أنثى", "انثى" -> "_اناث"
            else -> ""
        }
        return "$agePart$genderPart"
    }

    private fun formatBoundSlug(years: Int, months: Int): String = when {
        years > 0 && months > 0 -> "${years}_سنة_${months}_شهر"
        years > 0 -> "${years}_سنة"
        months > 0 -> "${months}_شهر"
        else -> "0"
    }
}

data class AgeExportProgress(
    val processedFamilies: Int,
    val totalFamilies: Int,
    val exportedRows: Int
)

data class AgeExportResult(
    val file: File,
    val uri: Uri,
    val mimeType: String,
    val displayFileName: String,
    val reportType: AgeExportReportType,
    val format: AgeExportFormat,
    val exportedRowsCount: Int,
    val familiesCount: Int,
    val childrenCount: Int
)

/**
 * محرك التصدير المخصص المتدفق (Zero-OOM) حسب الفلتر العمري والجغرافي الحالي.
 * - يدعم تصدير Excel (.xlsx) عبر StreamingXlsxWriter (RTL وعرض أعمدة ثابت دون java.awt).
 * - يدعم تصدير CSV بترميز UTF-8 مع BOM (\uFEFF) عبر BufferedWriter سطراً بسطر.
 * - ينفّذ كافة عمليات القراءة والكتابة حصراً على Dispatchers.IO بدفعات 500 أسرة لتفادي استهلاك الذاكرة.
 */
object AgeFilteredChildrenExporter {

    private const val BATCH_SIZE = 500
    private val FILE_DATE_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US)

    private val DETAILED_HEADERS = listOf(
        "رقم هوية رب الأسرة",
        "اسم رب الأسرة",
        "رقم الجوال",
        "المنطقة / المحلية",
        "رقم هوية الابن",
        "اسم الابن",
        "الجنس",
        "تاريخ الميلاد",
        "العمر التفصيلي"
    )

    private val DETAILED_WIDTHS = listOf(18.0, 28.0, 16.0, 22.0, 18.0, 28.0, 10.0, 15.0, 24.0)

    private val SUMMARY_HEADERS = listOf(
        "رقم هوية رب الأسرة",
        "اسم رب الأسرة",
        "رقم الجوال",
        "المنطقة / المحلية",
        "الشعبة",
        "عدد أفراد الأسرة",
        "عدد الأبناء المطابقين",
        "أسماء الأبناء المطابقين وأعمارهم التفصيلية"
    )

    private val SUMMARY_WIDTHS = listOf(18.0, 28.0, 16.0, 22.0, 18.0, 14.0, 16.0, 48.0)

    suspend fun export(
        context: Context,
        repository: AidRepository,
        criteria: AgeExportCriteria,
        reportType: AgeExportReportType,
        format: AgeExportFormat,
        onProgress: (AgeExportProgress) -> Unit = {}
    ): AgeExportResult = withContext(Dispatchers.IO) {
        val today = LocalDate.now()
        val todayIso = today.format(FILE_DATE_FORMATTER)
        val prefix = when (reportType) {
            AgeExportReportType.DETAILED_CHILDREN -> "كشف_الابناء"
            AgeExportReportType.SUMMARY_FAMILIES -> "ملخص_الاسر"
        }
        val slug = criteria.buildAgeFileSlug()
        val fileName = "${prefix}_${slug}_${todayIso}.${format.extension}"

        val exportsDir = resolveExportsDirectory(context)
        val outFile = File(exportsDir, fileName)
        if (outFile.exists()) {
            outFile.delete()
        }

        val localitiesMap = repository.getAllLocalitiesSync().associate { it.LocalityID to it.LocalityName }
        val totalFamilies = repository.getFamiliesCount(
            query = criteria.searchQuery,
            localityId = criteria.localityId,
            shelterStatus = criteria.shelterStatus.ifBlank { null },
            localityName = criteria.localityName.ifBlank { null },
            branchName = criteria.branchName.ifBlank { null },
            childBirthDateMin = if (criteria.ageFilterActive) criteria.minBirthDateIso else null,
            childBirthDateMax = if (criteria.ageFilterActive) criteria.maxBirthDateIso else null,
            childGender = criteria.cleanGender
        )

        var processedFamilies = 0
        var exportedRows = 0
        var exportedFamilies = 0
        var exportedChildren = 0

        onProgress(AgeExportProgress(0, totalFamilies, 0))

        when (format) {
            AgeExportFormat.CSV -> {
                FileOutputStream(outFile).use { fos ->
                    // كتابة UTF-8 BOM لضمان فتح العربية بشكل مثالي في Microsoft Excel
                    fos.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                    BufferedWriter(OutputStreamWriter(fos, StandardCharsets.UTF_8), 32 * 1024).use { writer ->
                        val headers = if (reportType == AgeExportReportType.DETAILED_CHILDREN) {
                            DETAILED_HEADERS
                        } else {
                            SUMMARY_HEADERS
                        }
                        writeCsvLine(writer, headers)

                        streamBatches(
                            repository = repository,
                            criteria = criteria,
                            onBatch = { families, childrenByParent ->
                                val counts = writeBatchToCsv(
                                    writer = writer,
                                    families = families,
                                    childrenByParent = childrenByParent,
                                    localitiesMap = localitiesMap,
                                    reportType = reportType,
                                    referenceDate = today
                                )
                                processedFamilies += families.size
                                exportedRows += counts.first
                                exportedFamilies += counts.second
                                exportedChildren += counts.third
                                onProgress(AgeExportProgress(processedFamilies, totalFamilies, exportedRows))
                            }
                        )
                        writer.flush()
                    }
                }
            }

            AgeExportFormat.XLSX -> {
                FileOutputStream(outFile).use { fos ->
                    StreamingXlsxWriter(fos).use { xlsx ->
                        val sheetTitle = when (reportType) {
                            AgeExportReportType.DETAILED_CHILDREN -> "كشف الأبناء"
                            AgeExportReportType.SUMMARY_FAMILIES -> "ملخص الأسر"
                        }
                        val headers = if (reportType == AgeExportReportType.DETAILED_CHILDREN) {
                            DETAILED_HEADERS
                        } else {
                            SUMMARY_HEADERS
                        }
                        val widths = if (reportType == AgeExportReportType.DETAILED_CHILDREN) {
                            DETAILED_WIDTHS
                        } else {
                            SUMMARY_WIDTHS
                        }

                        val parentContext = coroutineContext
                        xlsx.writeSheet(
                            rawSheetName = sheetTitle,
                            columnWidthsChars = widths,
                            freezeTopRow = true,
                            rightToLeft = true
                        ) {
                            writeRow(
                                values = headers,
                                style = StreamingXlsxWriter.Style.HEADER_TEAL,
                                heightPoints = 26f
                            )

                            var rowIndex = 0
                            var offset = 0
                            while (true) {
                                parentContext.ensureActive()
                                val batch = kotlinx.coroutines.runBlocking {
                                    parentContext.ensureActive()
                                    val famBatch = repository.getFilteredFamiliesBatch(
                                        query = criteria.searchQuery,
                                        localityId = criteria.localityId,
                                        shelterStatus = criteria.shelterStatus.ifBlank { null },
                                        localityName = criteria.localityName.ifBlank { null },
                                        branchName = criteria.branchName.ifBlank { null },
                                        childBirthDateMin = if (criteria.ageFilterActive) criteria.minBirthDateIso else null,
                                        childBirthDateMax = if (criteria.ageFilterActive) criteria.maxBirthDateIso else null,
                                        childGender = criteria.cleanGender,
                                        limit = BATCH_SIZE,
                                        offset = offset
                                    )
                                    if (famBatch.isEmpty()) {
                                        Pair(emptyList<FamilyEntity>(), emptyMap<String, List<ChildEntity>>())
                                    } else {
                                        val parentIds = famBatch.map { it.nationalID }.distinct()
                                        val matchedMap = repository.getMatchedChildrenForFamilyIds(
                                            familyNationalIds = parentIds,
                                            minBirthDateIso = if (criteria.ageFilterActive) criteria.minBirthDateIso else null,
                                            maxBirthDateIso = if (criteria.ageFilterActive) criteria.maxBirthDateIso else null,
                                            gender = criteria.cleanGender
                                        )
                                        Pair(famBatch, matchedMap)
                                    }
                                }

                                val families = batch.first
                                val childrenByParent = batch.second
                                if (families.isEmpty()) break

                                when (reportType) {
                                    AgeExportReportType.DETAILED_CHILDREN -> {
                                        for (family in families) {
                                            val kids = childrenByParent[family.nationalID].orEmpty()
                                            if (kids.isEmpty()) continue
                                            exportedFamilies++
                                            val area = resolveAreaLabel(family, localitiesMap)
                                            val phone = resolvePhoneLabel(family)
                                            for (child in kids) {
                                                val normBirth = ExactAgeUtil.normalizeIsoDate(child.birthDate)
                                                val exactAge = ExactAgeUtil.formatArabicAge(normBirth, today, fallback = "غير محدد")
                                                val style = if (rowIndex % 2 == 0) {
                                                    StreamingXlsxWriter.Style.DATA_EVEN
                                                } else {
                                                    StreamingXlsxWriter.Style.DATA_ODD
                                                }
                                                writeRow(
                                                    values = listOf(
                                                        family.nationalID,
                                                        family.name,
                                                        phone,
                                                        area,
                                                        child.nationalID,
                                                        child.childName,
                                                        child.gender,
                                                        normBirth,
                                                        exactAge
                                                    ),
                                                    style = style
                                                )
                                                rowIndex++
                                                exportedRows++
                                                exportedChildren++
                                            }
                                        }
                                    }

                                    AgeExportReportType.SUMMARY_FAMILIES -> {
                                        for (family in families) {
                                            val kids = childrenByParent[family.nationalID].orEmpty()
                                            val area = resolveAreaLabel(family, localitiesMap)
                                            val phone = resolvePhoneLabel(family)
                                            val kidsSummary = kids.joinToString(" | ") { child ->
                                                val age = ExactAgeUtil.formatArabicAge(child.birthDate, today, fallback = "غير محدد")
                                                "${child.childName} ($age)"
                                            }
                                            val style = if (rowIndex % 2 == 0) {
                                                StreamingXlsxWriter.Style.DATA_EVEN
                                            } else {
                                                StreamingXlsxWriter.Style.DATA_ODD
                                            }
                                            writeRow(
                                                values = listOf(
                                                    family.nationalID,
                                                    family.name,
                                                    phone,
                                                    area,
                                                    family.currentBranch,
                                                    family.familyMembersCount.toString(),
                                                    kids.size.toString(),
                                                    kidsSummary
                                                ),
                                                style = style
                                            )
                                            rowIndex++
                                            exportedRows++
                                            exportedFamilies++
                                            exportedChildren += kids.size
                                        }
                                    }
                                }

                                processedFamilies += families.size
                                onProgress(AgeExportProgress(processedFamilies, totalFamilies, exportedRows))

                                if (families.size < BATCH_SIZE) break
                                offset += BATCH_SIZE
                            }
                        }
                    }
                }
            }
        }

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outFile
        )

        AgeExportResult(
            file = outFile,
            uri = uri,
            mimeType = format.mimeType,
            displayFileName = fileName,
            reportType = reportType,
            format = format,
            exportedRowsCount = exportedRows,
            familiesCount = exportedFamilies,
            childrenCount = exportedChildren
        )
    }

    private suspend fun streamBatches(
        repository: AidRepository,
        criteria: AgeExportCriteria,
        onBatch: (List<FamilyEntity>, Map<String, List<ChildEntity>>) -> Unit
    ) {
        var offset = 0
        while (true) {
            coroutineContext.ensureActive()
            val families = repository.getFilteredFamiliesBatch(
                query = criteria.searchQuery,
                localityId = criteria.localityId,
                shelterStatus = criteria.shelterStatus.ifBlank { null },
                localityName = criteria.localityName.ifBlank { null },
                branchName = criteria.branchName.ifBlank { null },
                childBirthDateMin = if (criteria.ageFilterActive) criteria.minBirthDateIso else null,
                childBirthDateMax = if (criteria.ageFilterActive) criteria.maxBirthDateIso else null,
                childGender = criteria.cleanGender,
                limit = BATCH_SIZE,
                offset = offset
            )
            if (families.isEmpty()) break

            val parentIds = families.map { it.nationalID }.distinct()
            val childrenByParent = repository.getMatchedChildrenForFamilyIds(
                familyNationalIds = parentIds,
                minBirthDateIso = if (criteria.ageFilterActive) criteria.minBirthDateIso else null,
                maxBirthDateIso = if (criteria.ageFilterActive) criteria.maxBirthDateIso else null,
                gender = criteria.cleanGender
            )

            onBatch(families, childrenByParent)
            if (families.size < BATCH_SIZE) break
            offset += BATCH_SIZE
        }
    }

    private fun writeBatchToCsv(
        writer: BufferedWriter,
        families: List<FamilyEntity>,
        childrenByParent: Map<String, List<ChildEntity>>,
        localitiesMap: Map<Int, String>,
        reportType: AgeExportReportType,
        referenceDate: LocalDate
    ): Triple<Int, Int, Int> {
        var rows = 0
        var fams = 0
        var kidsTotal = 0

        when (reportType) {
            AgeExportReportType.DETAILED_CHILDREN -> {
                for (family in families) {
                    val kids = childrenByParent[family.nationalID].orEmpty()
                    if (kids.isEmpty()) continue
                    fams++
                    val area = resolveAreaLabel(family, localitiesMap)
                    val phone = resolvePhoneLabel(family)
                    for (child in kids) {
                        val normBirth = ExactAgeUtil.normalizeIsoDate(child.birthDate)
                        val exactAge = ExactAgeUtil.formatArabicAge(normBirth, referenceDate, fallback = "غير محدد")
                        writeCsvLine(
                            writer,
                            listOf(
                                family.nationalID,
                                family.name,
                                phone,
                                area,
                                child.nationalID,
                                child.childName,
                                child.gender,
                                normBirth,
                                exactAge
                            )
                        )
                        rows++
                        kidsTotal++
                    }
                }
            }

            AgeExportReportType.SUMMARY_FAMILIES -> {
                for (family in families) {
                    val kids = childrenByParent[family.nationalID].orEmpty()
                    val area = resolveAreaLabel(family, localitiesMap)
                    val phone = resolvePhoneLabel(family)
                    val kidsSummary = kids.joinToString(" | ") { child ->
                        val age = ExactAgeUtil.formatArabicAge(child.birthDate, referenceDate, fallback = "غير محدد")
                        "${child.childName} ($age)"
                    }
                    writeCsvLine(
                        writer,
                        listOf(
                            family.nationalID,
                            family.name,
                            phone,
                            area,
                            family.currentBranch,
                            family.familyMembersCount.toString(),
                            kids.size.toString(),
                            kidsSummary
                        )
                    )
                    rows++
                    fams++
                    kidsTotal += kids.size
                }
            }
        }
        return Triple(rows, fams, kidsTotal)
    }

    private fun writeCsvLine(writer: BufferedWriter, columns: List<String>) {
        for (i in columns.indices) {
            if (i > 0) writer.write(",")
            writer.write(escapeCsvField(columns[i]))
        }
        writer.write("\r\n")
    }

    private fun escapeCsvField(raw: String): String {
        val cleaned = raw.replace('\r', ' ').replace('\n', ' ')
        val needsQuotes = cleaned.indexOf(',') >= 0 || cleaned.indexOf('"') >= 0
        if (!needsQuotes) return cleaned
        return "\"" + cleaned.replace("\"", "\"\"") + "\""
    }

    private fun resolveAreaLabel(family: FamilyEntity, localitiesMap: Map<Int, String>): String {
        return family.currentSubArea.ifBlank {
            family.currentMainArea.ifBlank {
                localitiesMap[family.localityID].orEmpty()
            }
        }
    }

    private fun resolvePhoneLabel(family: FamilyEntity): String {
        return family.primaryPhone.ifBlank {
            family.alternative_phone_1?.trim().orEmpty().ifBlank {
                family.alternative_phone_2?.trim().orEmpty()
            }
        }
    }

    private fun resolveExportsDirectory(context: Context): File {
        val dir = context.getExternalFilesDir("exports") ?: File(context.cacheDir, "exports")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun openExportedFile(context: Context, result: AgeExportResult): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(result.uri, result.mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "فتح ملف التصدير"))
            true
        } catch (_: Throwable) {
            false
        }
    }

    fun shareExportedFile(context: Context, result: AgeExportResult): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = result.mimeType
                putExtra(Intent.EXTRA_STREAM, result.uri)
                putExtra(Intent.EXTRA_SUBJECT, result.displayFileName)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "مشاركة ملف التصدير").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            true
        } catch (_: Throwable) {
            false
        }
    }
}
