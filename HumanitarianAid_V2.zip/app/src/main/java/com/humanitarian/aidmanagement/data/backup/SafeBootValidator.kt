package com.humanitarian.aidmanagement.data.backup

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * تفاصيل تشخيص خطأ قاعدة البيانات عند الإقلاع
 */
data class DiagnosticErrorInfo(
    val title: String,
    val exceptionType: String,
    val message: String,
    val stackTrace: String,
    val dbPath: String,
    val dbFileSize: Long,
    val exists: Boolean,
    val isSqliteHeaderValid: Boolean,
    val likelyCause: String
)

/**
 * نتيجة فحص الإقلاع الآمن (Safe Boot Result)
 */
sealed class SafeBootResult {
    object Booting : SafeBootResult()
    object Success : SafeBootResult()
    data class Corrupt(val info: DiagnosticErrorInfo) : SafeBootResult()
}

/**
 * فاحص الإقلاع الآمن (Safe Boot Validator)
 * يفحص ملف قاعدة البيانات الخام قبل محاولة Room لفتحه، لمنع الانهيار (Crash Loop)
 */
object SafeBootValidator {
    private const val TAG = "SafeBootValidator"

    suspend fun validateDatabase(context: Context): SafeBootResult = withContext(Dispatchers.IO) {
        val primaryDb = context.getDatabasePath("aid_database")
        val roomDb = context.getDatabasePath(AidDatabase.DATABASE_NAME)
        val candidate = if (primaryDb.exists()) primaryDb else roomDb

        // إذا كان التثبيت جديداً أو الملف غير موجود إطلاقاً، فإن Room ستنشئه بسلاسة تامة
        if (!candidate.exists() || candidate.length() == 0L) {
            return@withContext SafeBootResult.Success
        }

        var isSqliteValid = false
        try {
            // 1. فحص الترويسة العتادية لـ SQLite (Magic Header: "SQLite format 3\u0000")
            val header = ByteArray(16)
            candidate.inputStream().use { input ->
                val read = input.read(header)
                if (read >= 16 && String(header, 0, 15, Charsets.US_ASCII) == "SQLite format 3") {
                    isSqliteValid = true
                } else {
                    throw IllegalStateException("ملف قاعدة البيانات (${candidate.name}) لا يحتوي على ترويسة SQLite صالحة (Code 26: file is not a database). الترويسة لا تبدأ بـ 'SQLite format 3'.")
                }
            }

            // 2. محاولة فتح الملف كقاعدة بيانات SQLite خام بوضع القراءة فقط داخل try-catch
            val rawDb = SQLiteDatabase.openDatabase(
                candidate.absolutePath,
                null,
                SQLiteDatabase.OPEN_READONLY
            )
            rawDb.use { db ->
                // تنفيذ الاستعلام المطلوب بالضبط: SELECT 1 FROM sqlite_schema أو sqlite_master
                val cursor = try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        db.rawQuery("SELECT 1 FROM sqlite_schema LIMIT 1", null)
                    } else {
                        db.rawQuery("SELECT 1 FROM sqlite_master LIMIT 1", null)
                    }
                } catch (_: Throwable) {
                    db.rawQuery("SELECT 1 FROM sqlite_master LIMIT 1", null)
                }
                cursor.use { c ->
                    c.moveToFirst()
                }

                // التأكد من وجود جدول واحد على الأقل
                val tableCheck = db.rawQuery("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'android_%' AND name NOT LIKE 'sqlite_%'", null)
                tableCheck.use { it.moveToFirst() }
            }

            // 3. اختبار فتح قاعدة بيانات Room والتأكد من توافق المخطط
            val room = AidDatabase.getDatabase(context)
            val countCursor = room.openHelper.readableDatabase.query("SELECT COUNT(*) FROM sqlite_master")
            countCursor.use { it.moveToFirst() }

            Log.i(TAG, "SafeBoot: Database passed validation and schema checks!")
            SafeBootResult.Success
        } catch (t: Throwable) {
            Log.e(TAG, "SafeBoot: Database validation caught failure: ${t.message}", t)
            val sw = StringWriter()
            t.printStackTrace(PrintWriter(sw))
            val fullTrace = sw.toString()

            val likelyCause = when {
                !isSqliteValid || t.message?.contains("code 26", ignoreCase = true) == true || t.message?.contains("file is not a database", ignoreCase = true) == true ->
                    "الملف المسترجع تالف أو ليس ملف SQLite خام (مثلاً ملف مضغوط .zip غير مفكوك أو ملف بصيغة أخرى)."
                t.message?.contains("migration", ignoreCase = true) == true || t.message?.contains("version", ignoreCase = true) == true ->
                    "تعارض في إصدارات قاعدة البيانات (Version Mismatch): المخطط في النسخة يختلف عن الإصدار المتوقع من قِبل Room."
                t.message?.contains("no such table", ignoreCase = true) == true ->
                    "نقص في أحد الجداول الأساسية المتوقعة لقاعدة البيانات."
                t.message?.contains("corrupt", ignoreCase = true) == true || t.message?.contains("malformed", ignoreCase = true) == true ->
                    "تلف في صفحات التخزين الخاصة بـ SQLite (Database disk image is malformed)."
                else ->
                    "فشل في استعلام محرك SQLite أو فتح الاتصال بقاعدة البيانات."
            }

            SafeBootResult.Corrupt(
                DiagnosticErrorInfo(
                    title = "فشل التحقق من سلامة قاعدة البيانات عند الإقلاع",
                    exceptionType = t.javaClass.name,
                    message = t.localizedMessage ?: t.message ?: "خطأ غير محدد في قراءة قاعدة البيانات",
                    stackTrace = fullTrace,
                    dbPath = candidate.absolutePath,
                    dbFileSize = candidate.length(),
                    exists = candidate.exists(),
                    isSqliteHeaderValid = isSqliteValid,
                    likelyCause = likelyCause
                )
            )
        }
    }

    /**
     * مسح قاعدة البيانات التالفة وإعادة الضبط لحالة المصنع النظيفة
     */
    fun factoryResetCorruptDatabase(context: Context): Boolean {
        return try {
            try {
                AidDatabase.resetInstance()
            } catch (_: Throwable) {}

            val names = listOf("aid_database", "aid_database.db", AidDatabase.DATABASE_NAME)
            for (name in names) {
                try { context.deleteDatabase(name) } catch (_: Throwable) {}
                val f = context.getDatabasePath(name)
                try { if (f.exists()) f.delete() } catch (_: Throwable) {}
                try { val wal = File(f.path + "-wal"); if (wal.exists()) wal.delete() } catch (_: Throwable) {}
                try { val shm = File(f.path + "-shm"); if (shm.exists()) shm.delete() } catch (_: Throwable) {}
                try { val jrn = File(f.path + "-journal"); if (jrn.exists()) jrn.delete() } catch (_: Throwable) {}
            }
            true
        } catch (e: Throwable) {
            Log.e(TAG, "Factory reset error: ${e.message}", e)
            false
        }
    }
}
