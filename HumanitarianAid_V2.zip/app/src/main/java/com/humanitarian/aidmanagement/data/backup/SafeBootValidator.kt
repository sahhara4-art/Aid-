package com.humanitarian.aidmanagement.data.backup

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * تفاصيل تشخيص خطأ قاعدة البيانات عند الإقلاع
 */
data class DiagnosticErrorInfo(
    val title: String,
    val exceptionType: String,
    val message: String,
    val stackTrace: String,
    val dbPath: String,
    val dbFileSize: Long,
    val exists: Boolean,
    val isSqliteHeaderValid: Boolean,
    val likelyCause: String
)

/**
 * نتيجة فحص الإقلاع الآمن (Safe Boot Result)
 */
sealed class SafeBootResult {
    object Booting : SafeBootResult()
    object Success : SafeBootResult()
    data class Corrupt(val info: DiagnosticErrorInfo) : SafeBootResult()
}

/**
 * فاحص الإقلاع الآمن (Safe Boot Validator)
 * يفحص ملف قاعدة البيانات الخام قبل محاولة Room لفتحه، لمنع الانهيار (Crash Loop)
 */
object SafeBootValidator {
    private const val TAG = "SafeBootValidator"

    suspend fun validateDatabase(context: Context): SafeBootResult {
        // تم إلغاء نظام الإقلاع الآمن كلياً وتمرير الفحص فوراً للسماح بفتح شاشة تسجيل الدخول مباشرة دون أي عوائق
        return SafeBootResult.Success
    }

    fun isDatabaseValid(context: Context): Boolean = true

    /**
     * مسح قاعدة البيانات التالفة وإعادة الضبط لحالة المصنع النظيفة
     */
    fun factoryResetCorruptDatabase(context: Context): Boolean {
        return try {
            try {
                AidDatabase.resetInstance()
            } catch (_: Throwable) {}

            val names = listOf("aid_database", "aid_database.db", AidDatabase.DATABASE_NAME)
            for (name in names) {
                try { context.deleteDatabase(name) } catch (_: Throwable) {}
                val f = context.getDatabasePath(name)
                try { if (f.exists()) f.delete() } catch (_: Throwable) {}
                try { val wal = File(f.path + "-wal"); if (wal.exists()) wal.delete() } catch (_: Throwable) {}
                try { val shm = File(f.path + "-shm"); if (shm.exists()) shm.delete() } catch (_: Throwable) {}
                try { val jrn = File(f.path + "-journal"); if (jrn.exists()) jrn.delete() } catch (_: Throwable) {}
            }
            true
        } catch (e: Throwable) {
            Log.e(TAG, "Factory reset error: ${e.message}", e)
            false
        }
    }
}
