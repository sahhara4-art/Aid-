package com.humanitarian.aidmanagement.ui.screens.diagnostic

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.backup.DatabaseBackupManager
import com.humanitarian.aidmanagement.data.backup.DiagnosticErrorInfo
import com.humanitarian.aidmanagement.ui.theme.PalestineGreen
import com.humanitarian.aidmanagement.ui.theme.PalestineRed
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiagnosticScreen(
    errorInfo: DiagnosticErrorInfo,
    onFactoryReset: () -> Unit,
    onRestoreSuccess: () -> Unit,
    onRetry: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var isRestoringFromPicker by remember { mutableStateOf(false) }
    var showFullTrace by remember { mutableStateOf(false) }

    // مشغل استعادة ملف قاعدة بيانات صالح مباشرة من شاشة التشخيص
    val pickDbLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            isRestoringFromPicker = true
            scope.launch {
                try {
                    val destDb = context.getDatabasePath("aid_database")
                    destDb.parentFile?.mkdirs()
                    val roomDb = context.getDatabasePath(com.humanitarian.aidmanagement.data.local.AidDatabase.DATABASE_NAME)
                    roomDb.parentFile?.mkdirs()

                    val inputStream = context.contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("تعذر قراءة الملف المختار")

                    val tempDest = File(context.cacheDir, "diagnostic_restored.db")
                    inputStream.use { input ->
                        FileOutputStream(tempDest).use { output ->
                            input.copyTo(output)
                            output.flush()
                            output.fd.sync()
                        }
                    }

                    DatabaseBackupManager.copyFileWithSync(tempDest, destDb)
                    DatabaseBackupManager.copyFileWithSync(tempDest, roomDb)
                    tempDest.delete()

                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "تم استبدال قاعدة البيانات بنجاح! جاري فحص الإقلاع...", Toast.LENGTH_SHORT).show()
                        onRestoreSuccess()
                    }
                } catch (e: Throwable) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "فشلت الاستعادة: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                } finally {
                    isRestoringFromPicker = false
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Security,
                            contentDescription = null,
                            tint = PalestineRed
                        )
                        Text(
                            "نظام الإقلاع الآمن (Safe Boot Diagnostics)",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // بطاقة التنبيه الأساسية
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        Icons.Default.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(32.dp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "تم منع الانهيار المفاجئ بنجاح!",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Text(
                            text = "رصد نظام الإقلاع الآمن تعارضاً أو تلفاً في ملف قاعدة البيانات المسترجعة، وتم إيقاف تشغيل Room تلقائياً لحماية التطبيق من الدخول في دوامة انهيار (Crash Loop).",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }

            // بطاقة السبب المرجح (Likely Cause)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = Color(0xFFD97706)
                        )
                        Text(
                            text = "السبب المرجح للمشكلة",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                    }
                    Text(
                        text = errorInfo.likelyCause,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // بطاقة التفاصيل التقنية
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "التفاصيل التقنية للخطأ",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )

                    HorizontalDivider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("نوع الاستثناء:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                        Text(errorInfo.exceptionType.substringAfterLast('.'), style = MaterialTheme.typography.bodySmall)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("مسار الملف:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                        Text(errorInfo.dbPath.substringAfterLast('/'), style = MaterialTheme.typography.bodySmall)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("حجم الملف على القرص:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                        Text("${errorInfo.dbFileSize / 1024} كيلوبايت", style = MaterialTheme.typography.bodySmall)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ترويسة SQLite سليمة؟", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                        Text(
                            text = if (errorInfo.isSqliteHeaderValid) "نعم (SQLite format 3)" else "لا (الملف تالف أو غير مدعوم)",
                            color = if (errorInfo.isSqliteHeaderValid) PalestineGreen else PalestineRed,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("رسالة الخطأ الصادرة:", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(6.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = errorInfo.message,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // زر عرض وإخفاء الـ StackTrace
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { showFullTrace = !showFullTrace }) {
                            Icon(
                                if (showFullTrace) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(if (showFullTrace) "إخفاء التفاصيل العميقة (StackTrace)" else "عرض تقرير التتبع الكامل (StackTrace)")
                        }

                        IconButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("Diagnostic Trace", "${errorInfo.message}\n\n${errorInfo.stackTrace}")
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "تم نسخ التقرير إلى الحافظة بنجاح", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "نسخ التقرير")
                        }
                    }

                    if (showFullTrace) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 240.dp)
                                .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                .padding(8.dp)
                                .verticalScroll(rememberScrollState())
                                .horizontalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = errorInfo.stackTrace,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = Color(0xFFF1F5F9)
                            )
                        }
                    }
                }
            }

            // أزرار المعالجة وحلول الإنقاذ
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. زر إعادة الضبط لمصنع النظيف (Factory Reset)
                Button(
                    onClick = { showResetConfirmDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = PalestineRed),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("مسح قاعدة البيانات التالفة وإعادة الضبط (Factory Reset)", fontWeight = FontWeight.Bold)
                }

                // 2. زر استعادة ملف قاعدة بيانات صالح محلياً
                OutlinedButton(
                    onClick = { pickDbLauncher.launch(arrayOf("*/*")) },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.FileOpen, contentDescription = null, tint = PalestineGreen)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (isRestoringFromPicker) "جاري استبدال القاعدة..." else "استعادة ملف قاعدة بيانات (.db) صالح من الهاتف",
                        color = PalestineGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // 3. زر إعادة المحاولة
                TextButton(
                    onClick = onRetry,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("إعادة فحص الإقلاع (Retry)")
                }
            }
        }
    }

    // نافذة تأكيد إعادة ضبط المصنع
    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmDialog = false },
            icon = { Icon(Icons.Default.WarningAmber, contentDescription = null, tint = PalestineRed) },
            title = { Text("تأكيد مسح قاعدة البيانات التالفة", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "هل أنت متأكد من مسح ملفات قاعدة البيانات التالفة؟\n\n" +
                    "سيتم حذف الملفات المعطوبة وسيقوم التطبيق بإعادة بناء قاعدة بيانات جديدة فارغة ونظيفة بحالة التثبيت الجديد."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showResetConfirmDialog = false
                        onFactoryReset()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PalestineRed)
                ) {
                    Text("نعم، مسح وبدء نظيف")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
