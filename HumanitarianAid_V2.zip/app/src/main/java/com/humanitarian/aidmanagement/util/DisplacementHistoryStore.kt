package com.humanitarian.aidmanagement.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * سجل حركة نزوح أو انتقال أسرة من منطقة فرعية إلى أخرى.
 */
data class DisplacementRecord(
    val fromSubRegion: String,
    val toSubRegion: String,
    val changedAtText: String,
    val changedByUser: String
)

/**
 * مخزن محلي خفيف لتتبع سجل تنقلات ونزوح الأسر في ملفات JSON مستقلة
 * داخل مجلد displacement_logs دون أي تعديل على قاعدة البيانات.
 */
object DisplacementHistoryStore {

    private const val LOGS_DIR_NAME = "displacement_logs"
    private const val DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm"
    private const val MAX_HISTORY_ENTRIES = 200

    private const val KEY_FROM_SUB_REGION = "fromSubRegion"
    private const val KEY_TO_SUB_REGION = "toSubRegion"
    private const val KEY_CHANGED_AT_TEXT = "changedAtText"
    private const val KEY_CHANGED_BY_USER = "changedByUser"

    private val ioLock = Any()

    /**
     * يسجل حركة انتقال جديدة للأسرة في بداية السجل الزمني إذا تغيّرت المنطقة الفرعية
     * وكان أحد الاسمين (القديم أو الجديد) غير فارغ.
     */
    fun recordMoveIfChanged(
        context: Context,
        familyId: String,
        oldSubRegion: String,
        newSubRegion: String,
        userName: String
    ) {
        val cleanFamilyId = sanitizeFamilyId(familyId)
        if (cleanFamilyId.isBlank()) return

        val oldTrimmed = oldSubRegion.trim()
        val newTrimmed = newSubRegion.trim()
        if (oldTrimmed == newTrimmed) return
        if (oldTrimmed.isBlank() && newTrimmed.isBlank()) return

        val cleanUser = userName.trim().ifBlank { "مستخدم النظام" }
        val timestampText = SimpleDateFormat(DATE_TIME_PATTERN, Locale.US).format(Date())

        val newRecord = DisplacementRecord(
            fromSubRegion = oldTrimmed.ifBlank { "غير محدد" },
            toSubRegion = newTrimmed.ifBlank { "غير محدد" },
            changedAtText = timestampText,
            changedByUser = cleanUser
        )

        synchronized(ioLock) {
            runCatching {
                val existing = readRecordsLocked(context, cleanFamilyId)
                val updated = ArrayList<DisplacementRecord>(minOf(existing.size + 1, MAX_HISTORY_ENTRIES))
                updated.add(newRecord)
                for (item in existing) {
                    if (updated.size >= MAX_HISTORY_ENTRIES) break
                    updated.add(item)
                }
                writeRecordsLocked(context, cleanFamilyId, updated)
            }
        }
    }

    /**
     * يقرأ السجل الزمني لتنقلات الأسرة مرتباً من الأحدث إلى الأقدم.
     */
    fun getHistoryForFamily(
        context: Context,
        familyId: String
    ): List<DisplacementRecord> {
        val cleanFamilyId = sanitizeFamilyId(familyId)
        if (cleanFamilyId.isBlank()) return emptyList()

        synchronized(ioLock) {
            return readRecordsLocked(context, cleanFamilyId)
        }
    }

    private fun readRecordsLocked(
        context: Context,
        cleanFamilyId: String
    ): List<DisplacementRecord> {
        val file = getFamilyLogFile(context, cleanFamilyId)
        if (!file.exists() || !file.isFile || file.length() <= 0L) {
            return emptyList()
        }

        return runCatching {
            val rawJson = file.readText(Charsets.UTF_8).trim()
            if (rawJson.isBlank()) return emptyList()

            val jsonArray = JSONArray(rawJson)
            val records = ArrayList<DisplacementRecord>(jsonArray.length())
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.optJSONObject(i) ?: continue
                records.add(
                    DisplacementRecord(
                        fromSubRegion = obj.optString(KEY_FROM_SUB_REGION, "").trim(),
                        toSubRegion = obj.optString(KEY_TO_SUB_REGION, "").trim(),
                        changedAtText = obj.optString(KEY_CHANGED_AT_TEXT, "").trim(),
                        changedByUser = obj.optString(KEY_CHANGED_BY_USER, "").trim()
                    )
                )
            }
            records
        }.getOrElse { emptyList() }
    }

    private fun writeRecordsLocked(
        context: Context,
        cleanFamilyId: String,
        records: List<DisplacementRecord>
    ) {
        val dir = File(context.filesDir, LOGS_DIR_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }

        val jsonArray = JSONArray()
        for (record in records) {
            val obj = JSONObject().apply {
                put(KEY_FROM_SUB_REGION, record.fromSubRegion)
                put(KEY_TO_SUB_REGION, record.toSubRegion)
                put(KEY_CHANGED_AT_TEXT, record.changedAtText)
                put(KEY_CHANGED_BY_USER, record.changedByUser)
            }
            jsonArray.put(obj)
        }

        val targetFile = File(dir, "$cleanFamilyId.json")
        targetFile.writeText(jsonArray.toString(), Charsets.UTF_8)
    }

    private fun getFamilyLogFile(context: Context, cleanFamilyId: String): File {
        return File(File(context.filesDir, LOGS_DIR_NAME), "$cleanFamilyId.json")
    }

    private fun sanitizeFamilyId(rawFamilyId: String): String {
        val trimmed = rawFamilyId.trim()
        if (trimmed.isBlank()) return ""
        val sb = StringBuilder(trimmed.length)
        for (ch in trimmed) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                in '0'..'9', in 'a'..'z', in 'A'..'Z', '_', '-' -> sb.append(ch)
            }
        }
        return sb.toString()
    }
}

/**
 * مؤشر الفجوة الجغرافية والتغطية الإغاثية على مستوى المنطقة الفرعية.
 */
data class SubRegionGapMetric(
    val subRegionName: String,
    val totalRegisteredFamilies: Int,
    val servedFamiliesCount: Int,
    val coveragePercentage: Int,
    val gapScore: Int,
    val statusLabelAr: String
)

/**
 * محلل الفجوات الجغرافية لتحديد المناطق الفرعية الأقل تغطية والأعلى أولوية في التوزيع.
 */
object GeographicGapAnalyzer {

    /**
     * يحسب نسبة التغطية ودرجة الفجوة لكل منطقة فرعية، ويرتّب المناطق
     * من الأعلى فجوة (الأقل استلاماً للمساعدات) إلى الأقل فجوة.
     */
    fun calculateSubRegionGaps(
        subRegionTotals: Map<String, Int>,
        subRegionServed: Map<String, Int>
    ): List<SubRegionGapMetric> {
        val normalizedTotals = LinkedHashMap<String, Int>()
        for ((rawKey, count) in subRegionTotals) {
            val key = rawKey.trim()
            if (key.isBlank()) continue
            val safeCount = count.coerceAtLeast(0)
            normalizedTotals[key] = (normalizedTotals[key] ?: 0) + safeCount
        }

        val normalizedServed = LinkedHashMap<String, Int>()
        for ((rawKey, count) in subRegionServed) {
            val key = rawKey.trim()
            if (key.isBlank()) continue
            val safeCount = count.coerceAtLeast(0)
            normalizedServed[key] = (normalizedServed[key] ?: 0) + safeCount
        }

        val allSubRegions = LinkedHashSet<String>().apply {
            addAll(normalizedTotals.keys)
            addAll(normalizedServed.keys)
        }

        val metrics = ArrayList<SubRegionGapMetric>(allSubRegions.size)
        for (subRegion in allSubRegions) {
            val rawTotal = normalizedTotals[subRegion] ?: 0
            val rawServed = normalizedServed[subRegion] ?: 0
            val effectiveTotal = maxOf(rawTotal, rawServed)
            val effectiveServed = rawServed.coerceIn(0, effectiveTotal)

            val coveragePercentage = if (effectiveTotal > 0) {
                ((effectiveServed * 100.0) / effectiveTotal.toDouble())
                    .toInt()
                    .coerceIn(0, 100)
            } else {
                0
            }

            val gapScore = (100 - coveragePercentage).coerceIn(0, 100)
            val statusLabelAr = when {
                coveragePercentage < 30 -> "فجوة حرجة - أولوية قصوى"
                coveragePercentage <= 65 -> "تغطية متوسطة"
                else -> "تغطية جيدة"
            }

            metrics.add(
                SubRegionGapMetric(
                    subRegionName = subRegion,
                    totalRegisteredFamilies = effectiveTotal,
                    servedFamiliesCount = effectiveServed,
                    coveragePercentage = coveragePercentage,
                    gapScore = gapScore,
                    statusLabelAr = statusLabelAr
                )
            )
        }

        return metrics.sortedWith(
            compareByDescending<SubRegionGapMetric> { it.gapScore }
                .thenByDescending { it.totalRegisteredFamilies - it.servedFamiliesCount }
                .thenByDescending { it.totalRegisteredFamilies }
                .thenBy { it.subRegionName }
        )
    }
}
