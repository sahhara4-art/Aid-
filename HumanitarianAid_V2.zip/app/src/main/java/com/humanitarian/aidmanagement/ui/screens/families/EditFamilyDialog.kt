package com.humanitarian.aidmanagement.ui.screens.families

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.AidApplication
import com.humanitarian.aidmanagement.AidManagementApp
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch

/**
 * شاشة ونافذة حوار إضافة وتعديل بيانات الأسرة المعتمدة بالكامل (AddEditFamilyDialog)
 * تغطي كافة الحقول الـ 36 الفعلية مع حماية العزل الجغرافي الصارم وفحص التكرار (Upsert Guard)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditFamilyDialog(
    family: FamilyEntity? = null,
    localities: List<LocalityEntity>,
    repository: AidRepository,
    onDismiss: () -> Unit,
    onSave: (FamilyEntity) -> Unit
) {
    val isEditMode = family != null
    val scope = rememberCoroutineScope()

    // 1. البيانات الشخصية ورب الأسرة
    var name by remember { mutableStateOf(family?.name ?: "") }
    var nationalID by remember { mutableStateOf(family?.nationalID ?: "") }
    var birthDate by remember { mutableStateOf(family?.birthDate ?: "1985-01-01") }
    var age by remember { mutableStateOf(family?.age?.toString() ?: "40") }
    var gender by remember { mutableStateOf(family?.gender ?: "ذكر") }
    var maritalStatus by remember { mutableStateOf(family?.maritalStatus ?: "متزوج") }
    var deathStatus by remember { mutableStateOf(family?.deathStatus ?: "على قيد الحياة") }
    var deathDate by remember { mutableStateOf(family?.deathDate ?: "") }

    // 2. بيانات الاتصال والتواصل
    var primaryPhone by remember { mutableStateOf(family?.primaryPhone ?: "") }
    var alternativePhone1 by remember { mutableStateOf(family?.alternativePhone1 ?: "") }
    var alternativePhone2 by remember { mutableStateOf(family?.alternativePhone2 ?: "") }

    // 3. بيانات الأسرة والزوجة
    var wifeName by remember { mutableStateOf(family?.wifeName ?: "") }
    var wifeNationalID by remember { mutableStateOf(family?.wifeNationalID ?: "") }
    var familyMembersCount by remember { mutableStateOf(family?.familyMembersCount?.toString() ?: "5") }
    var rationCardNumber by remember { mutableStateOf(family?.rationCardNumber ?: "") }

    // 4. المحليات والموقع الجغرافي (tbl_Localities مصدر الحقيقة الأوحد)
    val allowedLocalities = remember(localities) {
        val filtered = localities.filter { repository.canAccessLocality(it.LocalityID) }
        if (filtered.isNotEmpty()) filtered else localities
    }

    var selectedLocalityId by remember {
        mutableStateOf(
            family?.localityID ?: allowedLocalities.firstOrNull()?.LocalityID ?: 1
        )
    }

    var currentSubArea by remember {
        mutableStateOf(
            family?.currentSubArea?.ifBlank { null }
                ?: allowedLocalities.find { it.LocalityID == selectedLocalityId }?.LocalityName
                ?: "الرمال"
        )
    }

    var localityDropdownExpanded by remember { mutableStateOf(false) }

    var currentMainArea by remember { mutableStateOf(family?.currentMainArea ?: "") }
    var currentBranch by remember { mutableStateOf(family?.currentBranch ?: "") }
    var currentMosque by remember { mutableStateOf(family?.currentMosque ?: "") }
    var campOrCenterName by remember { mutableStateOf(family?.campOrCenterName ?: "") }

    // العناوين الأصلية قبل النزوح
    var originalMainArea by remember { mutableStateOf(family?.originalMainArea ?: "") }
    var originalSubArea by remember { mutableStateOf(family?.originalSubArea ?: "") }
    var originalBranch by remember { mutableStateOf(family?.originalBranch ?: "") }
    var originalMosque by remember { mutableStateOf(family?.originalMosque ?: "") }

    // 5. حالات الاعتماد والتصنيف الإنساني
    var developmentApproval by remember { mutableStateOf(family?.developmentApproval ?: "معتمد") }
    var worksApproval by remember { mutableStateOf(family?.worksApproval ?: "اعتماد أشغال") }
    var localityApproval by remember { mutableStateOf(family?.localityApproval ?: "معتمد") }
    var residentStatus by remember { mutableStateOf(family?.residentStatus ?: "مقيم") }
    var shelterStatus by remember { mutableStateOf(family?.shelterStatus ?: "إيواء داخلي") }

    // 6. الأضرار والإصابات ومصادر الدخل
    var damageType by remember { mutableStateOf(family?.damageType ?: "أضرار كلية") }
    var damageDescription by remember { mutableStateOf(family?.damageDescription ?: "") }
    var injuryStatus by remember { mutableStateOf(family?.injuryStatus ?: "سليم") }
    var injuryDate by remember { mutableStateOf(family?.injuryDate ?: "") }
    var incomeSource1 by remember { mutableStateOf(family?.incomeSource1 ?: "بلا عمل") }
    var incomeSource2 by remember { mutableStateOf(family?.incomeSource2 ?: "") }
    var notes by remember { mutableStateOf(family?.notes ?: "") }

    // تنبيهات الأخطاء والنزاهة
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isCheckingDuplicate by remember { mutableStateOf(false) }
    var showDuplicateConflictDialog by remember { mutableStateOf(false) }
    var duplicateExistingFamily by remember { mutableStateOf<FamilyEntity?>(null) }

    fun buildFamilyObject(targetId: Long, originalCreatedDate: Long): FamilyEntity {
        val parsedMembers = familyMembersCount.toIntOrNull() ?: 5
        val parsedAge = age.toIntOrNull() ?: 40
        return FamilyEntity(
            familyID = targetId,
            nationalID = nationalID.trim(),
            name = name.trim(),
            birthDate = birthDate.trim(),
            age = parsedAge,
            gender = gender.trim(),
            maritalStatus = maritalStatus.trim(),
            deathStatus = deathStatus.trim(),
            deathDate = deathDate.trim().ifEmpty { null },
            familyMembersCount = parsedMembers,
            primaryPhone = primaryPhone.trim(),
            alternativePhone1 = alternativePhone1.trim().ifEmpty { null },
            alternativePhone2 = alternativePhone2.trim().ifEmpty { null },
            wifeName = wifeName.trim().ifEmpty { null },
            wifeNationalID = wifeNationalID.trim().ifEmpty { null },
            rationCardNumber = rationCardNumber.trim().ifEmpty { null },
            localityID = selectedLocalityId,
            originalMainArea = originalMainArea.trim(),
            originalSubArea = originalSubArea.trim(),
            originalBranch = originalBranch.trim(),
            originalMosque = originalMosque.trim(),
            currentMainArea = currentMainArea.trim(),
            currentSubArea = currentSubArea.trim(),
            currentBranch = currentBranch.trim(),
            currentMosque = currentMosque.trim(),
            campOrCenterName = campOrCenterName.trim().ifEmpty { null },
            developmentApproval = developmentApproval.trim(),
            worksApproval = worksApproval.trim(),
            localityApproval = localityApproval.trim(),
            residentStatus = residentStatus.trim(),
            shelterStatus = shelterStatus.trim(),
            damageType = damageType.trim(),
            damageDescription = damageDescription.trim().ifEmpty { null },
            injuryStatus = injuryStatus.trim(),
            injuryDate = injuryDate.trim().ifEmpty { null },
            incomeSource1 = incomeSource1.trim(),
            incomeSource2 = incomeSource2.trim().ifEmpty { null },
            notes = notes.trim().ifEmpty { null },
            createdDate = originalCreatedDate,
            modifiedDate = System.currentTimeMillis()
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.96f)
                    .fillMaxHeight(0.94f)
                    .clip(RoundedCornerShape(20.dp)),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // الترويسة الرئيسية
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = if (isEditMode) "تعديل بيانات الأسرة المعتمدة" else "إضافة أسرة جديدة للمنظومة",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isEditMode) "تحديث سجل: ${family?.name} (${family?.nationalID})" else "تعبئة كافة الحقول الـ 36 المعتمدة مع العزل الجغرافي",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق")
                            }
                        },
                        actions = {
                            Button(
                                onClick = {
                                    val cleanNatId = nationalID.trim().filter { it.isDigit() }
                                    if (name.isBlank()) {
                                        errorMessage = "يرجى كتابة الاسم الرباعي للمواطن"
                                        return@Button
                                    }
                                    if (cleanNatId.length != 9) {
                                        errorMessage = "رقم الهوية الوطنية يجب أن يتكون من 9 أرقام بالضبط"
                                        return@Button
                                    }
                                    if (!repository.canAddFamilyInLocality(selectedLocalityId)) {
                                        errorMessage = "غير مصرح لك بإضافة أو نقل أسر إلى هذه المحلية"
                                        return@Button
                                    }

                                    errorMessage = null
                                    isCheckingDuplicate = true

                                    scope.launch {
                                        try {
                                            val existing = repository.getFamilyByNationalId(cleanNatId)
                                            if (existing != null && (!isEditMode || existing.familyID != family?.familyID)) {
                                                // كشف تكرار رقم الهوية الوطنية
                                                duplicateExistingFamily = existing
                                                showDuplicateConflictDialog = true
                                                isCheckingDuplicate = false
                                            } else {
                                                // الحفظ السليم المباشر
                                                val toSave = buildFamilyObject(
                                                    targetId = family?.familyID ?: 0L,
                                                    originalCreatedDate = family?.createdDate ?: System.currentTimeMillis()
                                                )
                                                isCheckingDuplicate = false
                                                onSave(toSave)
                                            }
                                        } catch (e: Exception) {
                                            isCheckingDuplicate = false
                                            errorMessage = "خطأ أثناء التحقق من الهوية: ${e.message}"
                                        }
                                    }
                                },
                                enabled = !isCheckingDuplicate,
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                if (isCheckingDuplicate) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = PalestineWhite, strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                } else {
                                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                }
                                Text(if (isEditMode) "حفظ التعديلات" else "حفظ الأسرة", fontWeight = FontWeight.Bold)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                    )

                    // شريط الخطأ إن وجد
                    if (errorMessage != null) {
                        Surface(
                            color = Color(0xFFFEE2E2),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = PalestineRed)
                                Text(text = errorMessage!!, color = PalestineRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // الحقول الـ 36 مقسمة في بطاقات Material Design 3 أنيقة
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // ==========================================
                        // البطاقة 1: البيانات الشخصية ورب الأسرة
                        // ==========================================
                        EditFamilySectionCard(title = "البيانات الشخصية ورب الأسرة", icon = Icons.Default.Person) {
                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                label = { Text("الاسم الرباعي الكامل للمستفيد *") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = PalestineGreen) }
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = nationalID,
                                    onValueChange = { nationalID = it },
                                    label = { Text("رقم الهوية الوطنية (9 أرقام) *") },
                                    modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    shape = RoundedCornerShape(10.dp),
                                    leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) }
                                )
                                OutlinedTextField(
                                    value = gender,
                                    onValueChange = { gender = it },
                                    label = { Text("الجنس (ذكر / أنثى)") },
                                    modifier = Modifier.weight(0.7f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = birthDate,
                                    onValueChange = { birthDate = it },
                                    label = { Text("تاريخ الميلاد (YYYY-MM-DD)") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = age,
                                    onValueChange = { age = it },
                                    label = { Text("العمر") },
                                    modifier = Modifier.weight(0.5f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = maritalStatus,
                                    onValueChange = { maritalStatus = it },
                                    label = { Text("الحالة الاجتماعية") },
                                    modifier = Modifier.weight(0.7f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = deathStatus,
                                    onValueChange = { deathStatus = it },
                                    label = { Text("الوفاة (على قيد الحياة / متوفى)") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = deathDate,
                                    onValueChange = { deathDate = it },
                                    label = { Text("تاريخ الوفاة (إن وجد)") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }

                        // ==========================================
                        // البطاقة 2: بيانات الأسرة والزوجة
                        // ==========================================
                        EditFamilySectionCard(title = "بيانات الأسرة والزوجة", icon = Icons.Default.FamilyRestroom) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = wifeName,
                                    onValueChange = { wifeName = it },
                                    label = { Text("اسم الزوج/الزوجة") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = wifeNationalID,
                                    onValueChange = { wifeNationalID = it },
                                    label = { Text("هوية الزوج/الزوجة") },
                                    modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = familyMembersCount,
                                    onValueChange = { familyMembersCount = it },
                                    label = { Text("عدد أفراد الأسرة *") },
                                    modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    shape = RoundedCornerShape(10.dp),
                                    leadingIcon = { Icon(Icons.Default.People, contentDescription = null) }
                                )
                                OutlinedTextField(
                                    value = rationCardNumber,
                                    onValueChange = { rationCardNumber = it },
                                    label = { Text("رقم كرت المؤن / التموين") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }

                        // ==========================================
                        // البطاقة 3: بيانات الاتصال والتواصل
                        // ==========================================
                        EditFamilySectionCard(title = "بيانات الاتصال والتواصل", icon = Icons.Default.Phone) {
                            OutlinedTextField(
                                value = primaryPhone,
                                onValueChange = { primaryPhone = it },
                                label = { Text("رقم الجوال الأساسي *") },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                shape = RoundedCornerShape(10.dp),
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = PalestineGreen) }
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = alternativePhone1,
                                    onValueChange = { alternativePhone1 = it },
                                    label = { Text("جوال بديل 1") },
                                    modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = alternativePhone2,
                                    onValueChange = { alternativePhone2 = it },
                                    label = { Text("جوال بديل 2") },
                                    modifier = Modifier.weight(1f),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }

                        // ==========================================
                        // البطاقة 4: الموقع الجغرافي والمحلية (Locality Source of Truth)
                        // ==========================================
                        EditFamilySectionCard(title = "الموقع الجغرافي والمحلية المعتمدة", icon = Icons.Default.LocationOn) {
                            val selectedLocalityName = allowedLocalities.find { it.LocalityID == selectedLocalityId }?.LocalityName
                                ?: "محلية #$selectedLocalityId"

                            // 1. القائمة المنسدلة الحصرية للمحليات المسموح بها (DropdownMenu)
                            Column {
                                Text(
                                    text = "المحلية المعتمدة (المرجع الوحيد):",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))

                                Box(modifier = Modifier.fillMaxWidth()) {
                                    OutlinedTextField(
                                        value = selectedLocalityName,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("اختر المحلية المصرح بها *") },
                                        trailingIcon = {
                                            IconButton(onClick = { localityDropdownExpanded = !localityDropdownExpanded }) {
                                                Icon(
                                                    if (localityDropdownExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                                    contentDescription = null,
                                                    tint = PalestineGreen
                                                )
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { localityDropdownExpanded = true },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                                            unfocusedContainerColor = MaterialTheme.colorScheme.surface
                                        )
                                    )

                                    DropdownMenu(
                                        expanded = localityDropdownExpanded,
                                        onDismissRequest = { localityDropdownExpanded = false },
                                        modifier = Modifier.fillMaxWidth(0.85f)
                                    ) {
                                        allowedLocalities.forEach { loc ->
                                            DropdownMenuItem(
                                                text = {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(loc.LocalityName, fontWeight = if (selectedLocalityId == loc.LocalityID) FontWeight.Bold else FontWeight.Normal)
                                                        if (selectedLocalityId == loc.LocalityID) {
                                                            Icon(Icons.Default.Check, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                                                        }
                                                    }
                                                },
                                                onClick = {
                                                    selectedLocalityId = loc.LocalityID
                                                    currentSubArea = loc.LocalityName
                                                    localityDropdownExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = currentMainArea,
                                    onValueChange = { currentMainArea = it },
                                    label = { Text("المنطقة الرئيسية الحالية") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = currentSubArea,
                                    onValueChange = { currentSubArea = it },
                                    label = { Text("المنطقة الفرعية الحالية (تلقائي)") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = PalestineGreen) }
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = currentBranch,
                                    onValueChange = { currentBranch = it },
                                    label = { Text("الشعبة الحالية") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = currentMosque,
                                    onValueChange = { currentMosque = it },
                                    label = { Text("المسجد الحالي") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            OutlinedTextField(
                                value = campOrCenterName,
                                onValueChange = { campOrCenterName = it },
                                label = { Text("اسم المخيم / مركز الإيواء (إن وجد)") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )

                            // العناوين الأصلية قبل النزوح
                            Text(
                                text = "العنوان الأصلي قبل النزوح:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = originalMainArea,
                                    onValueChange = { originalMainArea = it },
                                    label = { Text("المنطقة الرئيسية الأصلية") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = originalSubArea,
                                    onValueChange = { originalSubArea = it },
                                    label = { Text("المنطقة الفرعية الأصلية") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = originalBranch,
                                    onValueChange = { originalBranch = it },
                                    label = { Text("الشعبة الأصلية") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = originalMosque,
                                    onValueChange = { originalMosque = it },
                                    label = { Text("المسجد الأصلي") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }

                        // ==========================================
                        // البطاقة 5: الأضرار والإصابات ومصادر الدخل
                        // ==========================================
                        EditFamilySectionCard(title = "الأضرار والإصابات ومصادر الدخل", icon = Icons.Default.MedicalServices) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = damageType,
                                    onValueChange = { damageType = it },
                                    label = { Text("حالة الضرر (أضرار كلية/جزئية)") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = damageDescription,
                                    onValueChange = { damageDescription = it },
                                    label = { Text("وصف الضرر") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = injuryStatus,
                                    onValueChange = { injuryStatus = it },
                                    label = { Text("حالة الإصابة (سليم/مصاب)") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = injuryDate,
                                    onValueChange = { injuryDate = it },
                                    label = { Text("تاريخ الإصابة") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = incomeSource1,
                                    onValueChange = { incomeSource1 = it },
                                    label = { Text("مصدر الدخل 1") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = incomeSource2,
                                    onValueChange = { incomeSource2 = it },
                                    label = { Text("مصدر الدخل 2") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }

                        // ==========================================
                        // البطاقة 6: حالات الاعتماد والإيواء والملاحظات
                        // ==========================================
                        EditFamilySectionCard(title = "حالات الاعتماد والإيواء والملاحظات", icon = Icons.Default.CheckCircle) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = developmentApproval,
                                    onValueChange = { developmentApproval = it },
                                    label = { Text("اعتماد التنمية (معتمد/مجمد/حجب)") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = worksApproval,
                                    onValueChange = { worksApproval = it },
                                    label = { Text("اعتماد الأشغال") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = localityApproval,
                                    onValueChange = { localityApproval = it },
                                    label = { Text("اعتماد المناطق") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                OutlinedTextField(
                                    value = residentStatus,
                                    onValueChange = { residentStatus = it },
                                    label = { Text("الوضع (مقيم / نازح) *") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            OutlinedTextField(
                                value = shelterStatus,
                                onValueChange = { shelterStatus = it },
                                label = { Text("حالة الإيواء (إيواء داخلي / خارج الإيواء)") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )

                            OutlinedTextField(
                                value = notes,
                                onValueChange = { notes = it },
                                label = { Text("ملاحظات إضافية") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2,
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }

        // ==========================================
        // حوار كشف التكرار (Duplicate Conflict Resolution Dialog)
        // ==========================================
        if (showDuplicateConflictDialog && duplicateExistingFamily != null) {
            val existing = duplicateExistingFamily!!
            AlertDialog(
                onDismissRequest = { showDuplicateConflictDialog = false },
                icon = {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = PalestineRed, modifier = Modifier.size(36.dp))
                },
                title = {
                    Text(
                        text = "⚠️ رقم الهوية مسجل مسبقاً!",
                        fontWeight = FontWeight.Bold,
                        color = PalestineRed,
                        fontSize = 16.sp
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "رقم الهوية الوطنية ($nationalID) مسجل مسبقاً في قاعدة البيانات للمواطن:",
                            fontSize = 13.sp
                        )
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SlateSurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("👤 الاسم: ${existing.name}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateTextPrimary)
                                Text("📍 المحلية: محلية #${existing.localityID} - ${existing.currentSubArea}", fontSize = 12.sp, color = SlateTextSecondary)
                                Text("👨‍👩‍👧 أفراد الأسرة: ${existing.familyMembersCount}", fontSize = 12.sp, color = SlateTextSecondary)
                            }
                        }
                        Text(
                            text = "لحماية نزاهة البيانات ومنع التكرار العشوائي، هل ترغب في تحديث بيانات هذا السجل القائم بدلاً من محاولة إضافته كجديد؟",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showDuplicateConflictDialog = false
                            val updated = buildFamilyObject(existing.familyID, existing.createdDate)
                            onSave(updated)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("نعم، تحديث السجل القائم (Upsert)", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = { showDuplicateConflictDialog = false },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إلغاء وتعديل الهوية")
                    }
                }
            )
        }
    }
}

/**
 * غلاف توافقي لـ EditFamilyDialog
 */
/**
 * غلاف توافقي لـ EditFamilyDialog يدعم الاستدعاء الرباعي أو الخماسي مع التزويد التلقائي لـ AidRepository
 */
@Composable
fun EditFamilyDialog(
    family: FamilyEntity,
    localities: List<LocalityEntity>,
    onDismiss: () -> Unit,
    onSave: (FamilyEntity) -> Unit
) {
    val context = LocalContext.current
    val effectiveRepo = (context.applicationContext as? AidApplication)?.repository
        ?: AidApplication.instance.repository

    AddEditFamilyDialog(
        family = family,
        localities = localities,
        repository = effectiveRepo,
        onDismiss = onDismiss,
        onSave = onSave
    )
}

@Composable
fun EditFamilyDialog(
    family: FamilyEntity,
    localities: List<LocalityEntity>,
    repository: AidRepository,
    onDismiss: () -> Unit,
    onSave: (FamilyEntity) -> Unit
) {
    AddEditFamilyDialog(
        family = family,
        localities = localities,
        repository = repository,
        onDismiss = onDismiss,
        onSave = onSave
    )
}

@Composable
private fun EditFamilySectionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 4.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(20.dp))
                Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
            content()
        }
    }
}
