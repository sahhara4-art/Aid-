package com.humanitarian.aidmanagement.ui.screens.families

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.ui.theme.*

/**
 * نافذة حوار تعديل بيانات الأسرة المعتمدة (EditFamilyDialog)
 * تتيح تحديث الحقول التفصيلية للأسرة بالاعتماد على دالة updateFamily
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditFamilyDialog(
    family: FamilyEntity,
    localities: List<LocalityEntity>,
    onDismiss: () -> Unit,
    onSave: (FamilyEntity) -> Unit
) {
    var name by remember { mutableStateOf(family.name) }
    var nationalID by remember { mutableStateOf(family.nationalID) }
    var birthDate by remember { mutableStateOf(family.birthDate) }
    var age by remember { mutableStateOf(family.age.toString()) }
    var gender by remember { mutableStateOf(family.gender) }
    var maritalStatus by remember { mutableStateOf(family.maritalStatus) }
    var deathStatus by remember { mutableStateOf(family.deathStatus) }
    var deathDate by remember { mutableStateOf(family.deathDate ?: "") }
    var familyMembersCount by remember { mutableStateOf(family.familyMembersCount.toString()) }
    var primaryPhone by remember { mutableStateOf(family.primaryPhone) }
    var alternativePhone1 by remember { mutableStateOf(family.alternativePhone1 ?: "") }
    var alternativePhone2 by remember { mutableStateOf(family.alternativePhone2 ?: "") }
    var wifeName by remember { mutableStateOf(family.wifeName ?: "") }
    var wifeNationalID by remember { mutableStateOf(family.wifeNationalID ?: "") }
    var rationCardNumber by remember { mutableStateOf(family.rationCardNumber ?: "") }

    var selectedLocalityId by remember { mutableStateOf(family.localityID) }
    var originalMainArea by remember { mutableStateOf(family.originalMainArea) }
    var originalSubArea by remember { mutableStateOf(family.originalSubArea) }
    var originalBranch by remember { mutableStateOf(family.originalBranch) }
    var originalMosque by remember { mutableStateOf(family.originalMosque) }

    var currentMainArea by remember { mutableStateOf(family.currentMainArea) }
    var currentSubArea by remember { mutableStateOf(family.currentSubArea) }
    var currentBranch by remember { mutableStateOf(family.currentBranch) }
    var currentMosque by remember { mutableStateOf(family.currentMosque) }

    var developmentApproval by remember { mutableStateOf(family.developmentApproval) }
    var worksApproval by remember { mutableStateOf(family.worksApproval) }
    var localityApproval by remember { mutableStateOf(family.localityApproval) }
    var residentStatus by remember { mutableStateOf(family.residentStatus) }
    var shelterStatus by remember { mutableStateOf(family.shelterStatus) }
    var campOrCenterName by remember { mutableStateOf(family.campOrCenterName ?: "") }
    var damageType by remember { mutableStateOf(family.damageType) }
    var damageDescription by remember { mutableStateOf(family.damageDescription ?: "") }
    var injuryStatus by remember { mutableStateOf(family.injuryStatus) }
    var injuryDate by remember { mutableStateOf(family.injuryDate ?: "") }
    var incomeSource1 by remember { mutableStateOf(family.incomeSource1) }
    var incomeSource2 by remember { mutableStateOf(family.incomeSource2 ?: "") }
    var notes by remember { mutableStateOf(family.notes ?: "") }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.92f)
                    .clip(RoundedCornerShape(20.dp)),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // الترويسة
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = "تعديل بيانات الأسرة (كافة الحقول)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "تحديث سجل: ${family.name} - الهوية: ${family.nationalID}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق")
                            }
                        },
                        actions = {
                            Button(
                                onClick = {
                                    if (name.isBlank()) {
                                        errorMessage = "يرجى كتابة الاسم الرباعي للأسرة"
                                        return@Button
                                    }
                                    if (nationalID.isBlank()) {
                                        errorMessage = "يرجى كتابة رقم الهوية الوطنية"
                                        return@Button
                                    }
                                    val parsedMembers = familyMembersCount.toIntOrNull() ?: family.familyMembersCount
                                    val parsedAge = age.toIntOrNull() ?: family.age

                                    val updated = family.copy(
                                        name = name.trim(),
                                        nationalID = nationalID.trim(),
                                        birthDate = birthDate.trim(),
                                        age = parsedAge,
                                        gender = gender,
                                        maritalStatus = maritalStatus,
                                        deathStatus = deathStatus,
                                        deathDate = deathDate.trim().ifEmpty { null },
                                        familyMembersCount = parsedMembers,
                                        primaryPhone = primaryPhone.trim(),
                                        alternativePhone1 = alternativePhone1.trim().ifEmpty { null },
                                        alternativePhone2 = alternativePhone2.trim().ifEmpty { null },
                                        wifeName = wifeName.trim().ifEmpty { null },
                                        wifeNationalID = wifeNationalID.trim().ifEmpty { null },
                                        rationCardNumber = rationCardNumber.trim().ifEmpty { null },
                                        localityID = selectedLocalityId,
                                        originalMainArea = originalMainArea.trim(),
                                        originalSubArea = originalSubArea.trim(),
                                        originalBranch = originalBranch.trim(),
                                        originalMosque = originalMosque.trim(),
                                        currentMainArea = currentMainArea.trim(),
                                        currentSubArea = currentSubArea.trim(),
                                        currentBranch = currentBranch.trim(),
                                        currentMosque = currentMosque.trim(),
                                        developmentApproval = developmentApproval,
                                        worksApproval = worksApproval,
                                        localityApproval = localityApproval,
                                        residentStatus = residentStatus,
                                        shelterStatus = shelterStatus,
                                        campOrCenterName = campOrCenterName.trim().ifEmpty { null },
                                        damageType = damageType,
                                        damageDescription = damageDescription.trim().ifEmpty { null },
                                        injuryStatus = injuryStatus,
                                        injuryDate = injuryDate.trim().ifEmpty { null },
                                        incomeSource1 = incomeSource1.trim(),
                                        incomeSource2 = incomeSource2.trim().ifEmpty { null },
                                        notes = notes.trim().ifEmpty { null },
                                        modifiedDate = System.currentTimeMillis()
                                    )
                                    onSave(updated)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("حفظ التعديلات", fontWeight = FontWeight.Bold)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                    )

                    if (errorMessage != null) {
                        Surface(
                            color = Color(0xFFFEE2E2),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = PalestineRed)
                                Text(text = errorMessage!!, color = PalestineRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // الحقول القابلة للتمرير مقسمة لمجموعات منطقية
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // 1. البيانات الشخصية ورب الأسرة
                        FormGroupHeader(title = "البيانات الشخصية ورب الأسرة", icon = Icons.Default.Person)
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("الاسم الرباعي الكامل *") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = nationalID,
                                onValueChange = { nationalID = it },
                                label = { Text("رقم الهوية الوطنية *") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(10.dp),
                                leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) }
                            )
                            OutlinedTextField(
                                value = primaryPhone,
                                onValueChange = { primaryPhone = it },
                                label = { Text("رقم الجوال الأساسي") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                shape = RoundedCornerShape(10.dp),
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) }
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = birthDate,
                                onValueChange = { birthDate = it },
                                label = { Text("تاريخ الميلاد (YYYY-MM-DD)") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = age,
                                onValueChange = { age = it },
                                label = { Text("العمر") },
                                modifier = Modifier.weight(0.5f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = gender,
                                onValueChange = { gender = it },
                                label = { Text("الجنس") },
                                modifier = Modifier.weight(0.5f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        // أرقام الهواتف الإضافية وحالة الوفاة
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = alternativePhone1,
                                onValueChange = { alternativePhone1 = it },
                                label = { Text("جوال بديل 1") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = alternativePhone2,
                                onValueChange = { alternativePhone2 = it },
                                label = { Text("جوال بديل 2") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = deathStatus,
                                onValueChange = { deathStatus = it },
                                label = { Text("حالة الوفاة (على قيد الحياة / متوفى)") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = deathDate,
                                onValueChange = { deathDate = it },
                                label = { Text("تاريخ الوفاة (إن وجد)") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        // 2. بيانات الزوجة والتركيبة الأسرية
                        FormGroupHeader(title = "بيانات الزوجة وأفراد الأسرة", icon = Icons.Default.FamilyRestroom)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = wifeName,
                                onValueChange = { wifeName = it },
                                label = { Text("اسم الزوجة") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = wifeNationalID,
                                onValueChange = { wifeNationalID = it },
                                label = { Text("هوية الزوجة") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = familyMembersCount,
                                onValueChange = { familyMembersCount = it },
                                label = { Text("إجمالي عدد أفراد الأسرة") },
                                modifier = Modifier.weight(1f),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                shape = RoundedCornerShape(10.dp),
                                leadingIcon = { Icon(Icons.Default.People, contentDescription = null) }
                            )
                            OutlinedTextField(
                                value = rationCardNumber,
                                onValueChange = { rationCardNumber = it },
                                label = { Text("رقم البطاقة التموينية") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        // 3. العنوان الأصلي (قبل النزوح)
                        FormGroupHeader(title = "العنوان الأصلي (قبل النزوح)", icon = Icons.Default.Home)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = originalMainArea,
                                onValueChange = { originalMainArea = it },
                                label = { Text("المنطقة الرئيسية الأصلية") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = originalSubArea,
                                onValueChange = { originalSubArea = it },
                                label = { Text("المنطقة الفرعية الأصلية") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = originalBranch,
                                onValueChange = { originalBranch = it },
                                label = { Text("الشعبة الأصلية") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = originalMosque,
                                onValueChange = { originalMosque = it },
                                label = { Text("المسجد الأصلي") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        // 4. السكن والموقع الجغرافي الحالي
                        FormGroupHeader(title = "بيانات السكن والموقع الجغرافي الحالي", icon = Icons.Default.LocationOn)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = currentMainArea,
                                onValueChange = { currentMainArea = it },
                                label = { Text("المنطقة الرئيسية الحالية") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = currentSubArea,
                                onValueChange = { currentSubArea = it },
                                label = { Text("المنطقة الفرعية الحالية *") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = PalestineGreen) }
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = currentBranch,
                                onValueChange = { currentBranch = it },
                                label = { Text("الشعبة الحالية") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = currentMosque,
                                onValueChange = { currentMosque = it },
                                label = { Text("المسجد الحالي") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        OutlinedTextField(
                            value = campOrCenterName,
                            onValueChange = { campOrCenterName = it },
                            label = { Text("اسم المخيم / مركز الإيواء (إن وجد)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        // 5. حالات الاعتماد والتصنيف الإنساني
                        FormGroupHeader(title = "حالات الاعتماد والتصنيف الإنساني", icon = Icons.Default.CheckCircle)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = developmentApproval,
                                onValueChange = { developmentApproval = it },
                                label = { Text("اعتماد التنمية (معتمد/مجمد/حجب)") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = worksApproval,
                                onValueChange = { worksApproval = it },
                                label = { Text("اعتماد الأشغال") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = localityApproval,
                                onValueChange = { localityApproval = it },
                                label = { Text("اعتماد المناطق") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = residentStatus,
                                onValueChange = { residentStatus = it },
                                label = { Text("الوضع (مقيم / نازح)") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        OutlinedTextField(
                            value = shelterStatus,
                            onValueChange = { shelterStatus = it },
                            label = { Text("حالة الإيواء (إيواء داخلي/خارج الإيواء/خيمة)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        // 6. الأضرار والإصابات ومصادر الدخل
                        FormGroupHeader(title = "الأضرار والإصابات ومصادر الدخل", icon = Icons.Default.MedicalServices)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = damageType,
                                onValueChange = { damageType = it },
                                label = { Text("نوع أضرار السكن (كلي، جزئي...)") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = damageDescription,
                                onValueChange = { damageDescription = it },
                                label = { Text("وصف أضرار المنزل") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = injuryStatus,
                                onValueChange = { injuryStatus = it },
                                label = { Text("حالة الإصابة (سليم، مصاب...)") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = injuryDate,
                                onValueChange = { injuryDate = it },
                                label = { Text("تاريخ الإصابة") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = incomeSource1,
                                onValueChange = { incomeSource1 = it },
                                label = { Text("مصدر الدخل 1") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = incomeSource2,
                                onValueChange = { incomeSource2 = it },
                                label = { Text("مصدر الدخل 2") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        // 7. الملاحظات
                        FormGroupHeader(title = "الملاحظات الإدارية والميدانية", icon = Icons.Default.Notes)
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it },
                            label = { Text("ملاحظات إضافية") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3,
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun FormGroupHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(18.dp))
        Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.primary)
    }
}
