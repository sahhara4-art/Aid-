package com.humanitarian.aidmanagement.ui.screens.families

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.humanitarian.aidmanagement.data.local.entities.Family

@Composable
fun EditFamilyDialog(
    family: Family,
    onDismiss: () -> Unit,
    onSave: (Family) -> Unit
) {
    var name by remember { mutableStateOf(family.name) }
    var membersCount by remember { mutableStateOf(family.familyMembersCount.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل بيانات الأسرة", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم رب الأسرة") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = membersCount,
                    onValueChange = { membersCount = it },
                    label = { Text("عدد أفراد الأسرة") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        family.copy(
                            name = name.trim(),
                            familyMembersCount = membersCount.toIntOrNull() ?: family.familyMembersCount,
                            modifiedDate = System.currentTimeMillis()
                        )
                    )
                }
            ) {
                Text("حفظ التعديلات")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
