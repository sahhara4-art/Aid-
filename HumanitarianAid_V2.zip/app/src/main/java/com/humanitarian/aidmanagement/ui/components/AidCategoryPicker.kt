package com.humanitarian.aidmanagement.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.ui.theme.PalestineGreen
import com.humanitarian.aidmanagement.util.AidCategoryCatalog

/**
 * مكوّن موحّد وديناميكي لاختيار أو إضافة «نوع وتصنيف المساعدة» في شاشات طرح وتعديل المشاريع.
 * يدعم البحث والاختيار من القائمة الديناميكية والشرائح السريعة، ويوفر زراً صريحاً «+ إضافة تصنيف جديد»
 * لحفظ التصنيف الجديد فوراً وتعميمه في كافة أرجاء التطبيق.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AidCategorySelectorField(
    aidTypes: List<AidTypeEntity>,
    selectedAidTypeId: Int,
    categoryInputText: String,
    onCategoryInputChange: (String) -> Unit,
    onSelectAidType: (AidTypeEntity) -> Unit,
    onAddNewCategory: (String) -> Unit,
    isAddingCategory: Boolean = false,
    label: String = "نوع وتصنيف المساعدة *",
    modifier: Modifier = Modifier
) {
    var isDropdownExpanded by remember { mutableStateOf(false) }
    var showInlineAddBox by remember { mutableStateOf(false) }
    var newCategoryDraft by remember { mutableStateOf("") }

    val cleanedInput = remember(categoryInputText) { AidCategoryCatalog.cleanName(categoryInputText) }
    val exactMatchForInput = remember(cleanedInput, aidTypes) {
        AidCategoryCatalog.findMatchingType(aidTypes, cleanedInput)
    }

    val filteredAidTypes = remember(cleanedInput, aidTypes) {
        if (cleanedInput.isBlank()) {
            aidTypes
        } else {
            val qKey = AidCategoryCatalog.canonicalKey(cleanedInput)
            aidTypes.filter { type ->
                type.aidTypeName.contains(cleanedInput, ignoreCase = true) ||
                    AidCategoryCatalog.canonicalKey(type.aidTypeName).contains(qKey)
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // الترويسة + زر الإضافة الصريح
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Category,
                    contentDescription = null,
                    tint = PalestineGreen,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = label,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Surface(
                onClick = {
                    if (!showInlineAddBox && cleanedInput.isNotBlank() && exactMatchForInput == null) {
                        newCategoryDraft = cleanedInput
                    }
                    showInlineAddBox = !showInlineAddBox
                },
                shape = RoundedCornerShape(10.dp),
                color = PalestineGreen.copy(alpha = 0.12f),
                border = BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = if (showInlineAddBox) Icons.Default.Close else Icons.Default.Add,
                        contentDescription = null,
                        tint = PalestineGreen,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = if (showInlineAddBox) "إغلاق" else "+ إضافة تصنيف جديد",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = PalestineGreen
                    )
                }
            }
        }

        // مربع الإضافة الصريح لتصنيف جديد
        AnimatedVisibility(visible = showInlineAddBox) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = PalestineGreen.copy(alpha = 0.06f),
                border = BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "أدخل اسم التصنيف الجديد ليُحفظ فوراً ويظهر في جميع الشاشات والفلاتر:",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = newCategoryDraft,
                            onValueChange = { newCategoryDraft = it },
                            placeholder = { Text("مثال: طرود نظافة، حليب أطفال، قسائم شرائية...", fontSize = 12.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        Button(
                            onClick = {
                                val cleaned = AidCategoryCatalog.cleanName(newCategoryDraft)
                                if (AidCategoryCatalog.isValidCategoryName(cleaned)) {
                                    onAddNewCategory(cleaned)
                                    newCategoryDraft = ""
                                    showInlineAddBox = false
                                }
                            },
                            enabled = !isAddingCategory && AidCategoryCatalog.isValidCategoryName(newCategoryDraft),
                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            if (isAddingCategory) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = Color.White
                                )
                            } else {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("حفظ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // قائمة قابلة للكتابة والاختيار (Editable ComboBox)
        ExposedDropdownMenuBox(
            expanded = isDropdownExpanded,
            onExpandedChange = { isDropdownExpanded = !isDropdownExpanded },
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedTextField(
                value = categoryInputText,
                onValueChange = { input ->
                    onCategoryInputChange(input)
                    isDropdownExpanded = true
                    val match = AidCategoryCatalog.findMatchingType(aidTypes, input)
                    if (match != null) {
                        onSelectAidType(match)
                    }
                },
                readOnly = false,
                singleLine = true,
                placeholder = { Text("اختر تصنيفاً أو اكتب تصنيفاً جديداً...", fontSize = 12.sp) },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isDropdownExpanded) },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            ExposedDropdownMenu(
                expanded = isDropdownExpanded,
                onDismissRequest = { isDropdownExpanded = false }
            ) {
                if (AidCategoryCatalog.isValidCategoryName(cleanedInput) && exactMatchForInput == null) {
                    DropdownMenuItem(
                        leadingIcon = {
                            Icon(Icons.Default.Add, contentDescription = null, tint = PalestineGreen)
                        },
                        text = {
                            Text(
                                text = "إضافة التصنيف الجديد: «$cleanedInput»",
                                color = PalestineGreen,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        onClick = {
                            onAddNewCategory(cleanedInput)
                            isDropdownExpanded = false
                        }
                    )
                }

                filteredAidTypes.forEach { type ->
                    val isSelected = type.aidTypeID == selectedAidTypeId
                    DropdownMenuItem(
                        leadingIcon = if (isSelected) {
                            { Icon(Icons.Default.Check, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(18.dp)) }
                        } else null,
                        text = {
                            Text(
                                text = type.aidTypeName,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) PalestineGreen else MaterialTheme.colorScheme.onSurface
                            )
                        },
                        onClick = {
                            onSelectAidType(type)
                            onCategoryInputChange(type.aidTypeName)
                            isDropdownExpanded = false
                        }
                    )
                }
            }
        }

        // تنبيه تفاعلي فوري عند كتابة تصنيف جديد غير محفوظ بعد
        if (AidCategoryCatalog.isValidCategoryName(cleanedInput) && exactMatchForInput == null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "سيُضاف التصنيف الجديد «$cleanedInput» تلقائياً عند الحفظ",
                    fontSize = 11.sp,
                    color = PalestineGreen,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f)
                )
                TextButton(
                    onClick = { onAddNewCategory(cleanedInput) },
                    enabled = !isAddingCategory,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text("إضافة الآن", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PalestineGreen)
                }
            }
        }

        // شرائح اختيار سريع للتصنيفات الديناميكية
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items(items = aidTypes, key = { it.aidTypeID }) { type ->
                val selected = selectedAidTypeId == type.aidTypeID &&
                    (cleanedInput.isBlank() || AidCategoryCatalog.isSameCategory(cleanedInput, type.aidTypeName))
                FilterChip(
                    selected = selected,
                    onClick = {
                        onSelectAidType(type)
                        onCategoryInputChange(type.aidTypeName)
                        isDropdownExpanded = false
                    },
                    label = {
                        Text(
                            text = type.aidTypeName,
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PalestineGreen,
                        selectedLabelColor = Color.White
                    )
                )
            }
            item(key = "add_new_category_chip") {
                AssistChip(
                    onClick = { showInlineAddBox = true },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            tint = PalestineGreen,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "تصنيف جديد",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = PalestineGreen
                        )
                    },
                    border = BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.5f))
                )
            }
        }
    }
}
