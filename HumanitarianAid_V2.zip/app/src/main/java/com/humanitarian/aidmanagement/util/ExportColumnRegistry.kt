package com.humanitarian.aidmanagement.util

import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity

/**
 * تعريف عمود تصدير ديناميكي لبيانات الأسر والمستفيدين
 */
data class ExportColumnDef(
    val key: String,
    val label: String,
    val category: String,
    val isDefault: Boolean = false,
    val excelWidth: Int = 4500,
    val pdfWeight: Float = 1.0f,
    val valueExtractor: (family: FamilyEntity, record: AidRecordEntity?, index: Int) -> String
)

/**
 * السجل المركزي المعتمد لأعمدة تصدير كشوفات الأسر والمستفيدين (Dynamic Column Registry)
 */
object ExportColumnRegistry {

    const val CATEGORY_PERSONAL = "البيانات الشخصية"
    const val CATEGORY_CONTACT = "بيانات الاتصال"
    const val CATEGORY_FAMILY = "بيانات الأسرة"
    const val CATEGORY_GEO = "المعلومات الجغرافية"
    const val CATEGORY_SHELTER_DAMAGE = "الإيواء وحالة الضرر"
    const val CATEGORY_INCOME = "العمل ومصدر الدخل"
    const val CATEGORY_APPROVALS = "الاعتمادات الرسمية"
    const val CATEGORY_DELIVERY = "الصرف والتسليم"

    val ALL_COLUMNS: List<ExportColumnDef> = listOf(
        // رقم متسلسل
        ExportColumnDef(
            key = "row_index",
            label = "م",
            category = CATEGORY_PERSONAL,
            isDefault = true,
            excelWidth = 1800,
            pdfWeight = 0.5f,
            valueExtractor = { _, _, idx -> idx.toString() }
        ),
        // الاسم الرباعي
        ExportColumnDef(
            key = "name",
            label = "الاسم الرباعي",
            category = CATEGORY_PERSONAL,
            isDefault = true,
            excelWidth = 9000,
            pdfWeight = 2.4f,
            valueExtractor = { f, _, _ -> f.name }
        ),
        // رقم الهوية الوطنية
        ExportColumnDef(
            key = "nationalID",
            label = "رقم الهوية الوطنية",
            category = CATEGORY_PERSONAL,
            isDefault = true,
            excelWidth = 4800,
            pdfWeight = 1.4f,
            valueExtractor = { f, _, _ -> f.nationalID }
        ),
        // رقم الجوال الأساسي
        ExportColumnDef(
            key = "primary_phone",
            label = "رقم الجوال الأساسي",
            category = CATEGORY_CONTACT,
            isDefault = true,
            excelWidth = 4500,
            pdfWeight = 1.3f,
            valueExtractor = { f, _, _ -> f.primary_phone }
        ),
        // المنطقة الفرعية الحالية
        ExportColumnDef(
            key = "currentSubArea",
            label = "المنطقة الفرعية الحالية",
            category = CATEGORY_GEO,
            isDefault = true,
            excelWidth = 6000,
            pdfWeight = 1.6f,
            valueExtractor = { f, _, _ -> f.currentSubArea }
        ),
        // عدد أفراد الأسرة
        ExportColumnDef(
            key = "familyMembersCount",
            label = "أفراد الأسرة",
            category = CATEGORY_FAMILY,
            isDefault = true,
            excelWidth = 3200,
            pdfWeight = 0.8f,
            valueExtractor = { f, _, _ -> f.familyMembersCount.toString() }
        ),
        // حالة الإيواء
        ExportColumnDef(
            key = "shelterStatus",
            label = "حالة الإيواء",
            category = CATEGORY_SHELTER_DAMAGE,
            isDefault = true,
            excelWidth = 4500,
            pdfWeight = 1.2f,
            valueExtractor = { f, _, _ -> f.shelterStatus }
        ),
        // حالة الضرر
        ExportColumnDef(
            key = "damageType",
            label = "حالة الضرر",
            category = CATEGORY_SHELTER_DAMAGE,
            isDefault = true,
            excelWidth = 4800,
            pdfWeight = 1.2f,
            valueExtractor = { f, _, _ -> f.damageType }
        ),
        // مصدر الدخل الأساسي
        ExportColumnDef(
            key = "incomeSource1",
            label = "مصدر الدخل",
            category = CATEGORY_INCOME,
            isDefault = true,
            excelWidth = 4500,
            pdfWeight = 1.2f,
            valueExtractor = { f, _, _ -> f.incomeSource1 }
        ),
        // الجنس
        ExportColumnDef(
            key = "gender",
            label = "الجنس",
            category = CATEGORY_PERSONAL,
            isDefault = false,
            excelWidth = 3000,
            pdfWeight = 0.8f,
            valueExtractor = { f, _, _ -> f.gender }
        ),
        // تاريخ الميلاد
        ExportColumnDef(
            key = "date_of_birth",
            label = "تاريخ الميلاد",
            category = CATEGORY_PERSONAL,
            isDefault = false,
            excelWidth = 3800,
            pdfWeight = 1.1f,
            valueExtractor = { f, _, _ -> f.date_of_birth }
        ),
        // العمر
        ExportColumnDef(
            key = "age",
            label = "العمر",
            category = CATEGORY_PERSONAL,
            isDefault = false,
            excelWidth = 2600,
            pdfWeight = 0.7f,
            valueExtractor = { f, _, _ -> f.age.toString() }
        ),
        // الحالة الاجتماعية
        ExportColumnDef(
            key = "maritalStatus",
            label = "الحالة الاجتماعية",
            category = CATEGORY_PERSONAL,
            isDefault = false,
            excelWidth = 4000,
            pdfWeight = 1.1f,
            valueExtractor = { f, _, _ -> f.maritalStatus }
        ),
        // جوال بديل 1
        ExportColumnDef(
            key = "alternative_phone_1",
            label = "جوال بديل 1",
            category = CATEGORY_CONTACT,
            isDefault = false,
            excelWidth = 4500,
            pdfWeight = 1.2f,
            valueExtractor = { f, _, _ -> f.alternative_phone_1 ?: "-" }
        ),
        // جوال بديل 2
        ExportColumnDef(
            key = "alternative_phone_2",
            label = "جوال بديل 2",
            category = CATEGORY_CONTACT,
            isDefault = false,
            excelWidth = 4500,
            pdfWeight = 1.2f,
            valueExtractor = { f, _, _ -> f.alternative_phone_2 ?: "-" }
        ),
        // اسم الزوج / الزوجة
        ExportColumnDef(
            key = "wifeName",
            label = "اسم الزوج/الزوجة",
            category = CATEGORY_FAMILY,
            isDefault = false,
            excelWidth = 7500,
            pdfWeight = 2.0f,
            valueExtractor = { f, _, _ -> f.wifeName ?: "-" }
        ),
        // هوية الزوج / الزوجة
        ExportColumnDef(
            key = "wifeNationalID",
            label = "هوية الزوج/الزوجة",
            category = CATEGORY_FAMILY,
            isDefault = false,
            excelWidth = 4800,
            pdfWeight = 1.3f,
            valueExtractor = { f, _, _ -> f.wifeNationalID ?: "-" }
        ),
        // المنطقة الرئيسية الحالية
        ExportColumnDef(
            key = "currentMainArea",
            label = "المنطقة الرئيسية الحالية",
            category = CATEGORY_GEO,
            isDefault = false,
            excelWidth = 5500,
            pdfWeight = 1.4f,
            valueExtractor = { f, _, _ -> f.currentMainArea }
        ),
        // الشعبة الحالية
        ExportColumnDef(
            key = "currentBranch",
            label = "الشعبة الحالية",
            category = CATEGORY_GEO,
            isDefault = false,
            excelWidth = 4500,
            pdfWeight = 1.2f,
            valueExtractor = { f, _, _ -> f.currentBranch }
        ),
        // المسجد الحالي
        ExportColumnDef(
            key = "currentMosque",
            label = "المسجد الحالي",
            category = CATEGORY_GEO,
            isDefault = false,
            excelWidth = 4500,
            pdfWeight = 1.2f,
            valueExtractor = { f, _, _ -> f.currentMosque }
        ),
        // مركز الإيواء / المخيم
        ExportColumnDef(
            key = "shelter_center_name",
            label = "اسم مركز الإيواء/المخيم",
            category = CATEGORY_SHELTER_DAMAGE,
            isDefault = false,
            excelWidth = 6500,
            pdfWeight = 1.7f,
            valueExtractor = { f, _, _ -> f.shelter_center_name ?: "-" }
        ),
        // وصف الضرر
        ExportColumnDef(
            key = "damageDescription",
            label = "وصف أضرار المنزل",
            category = CATEGORY_SHELTER_DAMAGE,
            isDefault = false,
            excelWidth = 7500,
            pdfWeight = 2.0f,
            valueExtractor = { f, _, _ -> f.damageDescription ?: "-" }
        ),
        // حالة الإصابة
        ExportColumnDef(
            key = "injuryStatus",
            label = "حالة الإصابة",
            category = CATEGORY_SHELTER_DAMAGE,
            isDefault = false,
            excelWidth = 4000,
            pdfWeight = 1.1f,
            valueExtractor = { f, _, _ -> f.injuryStatus }
        ),
        // مصدر الدخل الثانوي
        ExportColumnDef(
            key = "income_source_2",
            label = "مصدر الدخل الثانوي",
            category = CATEGORY_INCOME,
            isDefault = false,
            excelWidth = 4500,
            pdfWeight = 1.2f,
            valueExtractor = { f, _, _ -> f.income_source_2 ?: "-" }
        ),
        // اعتماد الشؤون / التنمية
        ExportColumnDef(
            key = "developmentApproval",
            label = "اعتماد التنمية / الشؤون",
            category = CATEGORY_APPROVALS,
            isDefault = false,
            excelWidth = 4200,
            pdfWeight = 1.1f,
            valueExtractor = { f, _, _ -> f.developmentApproval }
        ),
        // صفة الإقامة
        ExportColumnDef(
            key = "residentStatus",
            label = "صفة الإقامة",
            category = CATEGORY_APPROVALS,
            isDefault = false,
            excelWidth = 3800,
            pdfWeight = 1.0f,
            valueExtractor = { f, _, _ -> f.residentStatus }
        ),
        // اعتماد الأشغال العامة
        ExportColumnDef(
            key = "worksApproval",
            label = "اعتماد الأشغال العامة",
            category = CATEGORY_APPROVALS,
            isDefault = false,
            excelWidth = 4200,
            pdfWeight = 1.1f,
            valueExtractor = { f, _, _ -> f.worksApproval }
        ),
        // رقم كرت المؤن
        ExportColumnDef(
            key = "rationCardNumber",
            label = "رقم كرت المؤن",
            category = CATEGORY_APPROVALS,
            isDefault = false,
            excelWidth = 4000,
            pdfWeight = 1.1f,
            valueExtractor = { f, _, _ -> f.rationCardNumber ?: "-" }
        ),
        // حالة الاستلام
        ExportColumnDef(
            key = "recipientStatus",
            label = "حالة الاستلام",
            category = CATEGORY_DELIVERY,
            isDefault = false,
            excelWidth = 4200,
            pdfWeight = 1.1f,
            valueExtractor = { _, r, _ -> r?.recipientStatus ?: "-" }
        ),
        // تاريخ التسليم
        ExportColumnDef(
            key = "deliveryDate",
            label = "تاريخ التسليم",
            category = CATEGORY_DELIVERY,
            isDefault = false,
            excelWidth = 4200,
            pdfWeight = 1.1f,
            valueExtractor = { _, r, _ -> r?.deliveryDate ?: r?.aidDate ?: "-" }
        ),
        // ملاحظات السجل
        ExportColumnDef(
            key = "notes",
            label = "الملاحظات",
            category = CATEGORY_DELIVERY,
            isDefault = false,
            excelWidth = 7000,
            pdfWeight = 1.8f,
            valueExtractor = { f, r, _ -> r?.notes ?: f.notes ?: "-" }
        )
    )

    /**
     * الأعمدة الافتراضية المعتمدة (Essential Default Columns)
     */
    val DEFAULT_SELECTED_KEYS: List<String> = ALL_COLUMNS.filter { it.isDefault }.map { it.key }

    /**
     * خريطة بالبحث السريع حسب مفتاح العمود
     */
    val COLUMN_MAP: Map<String, ExportColumnDef> = ALL_COLUMNS.associateBy { it.key }

    /**
     * استرجاع قائمة التعريفات حسب المفاتيح المحددة مع المحافظة على الترتيب
     */
    fun getOrderedDefs(keys: List<String>): List<ExportColumnDef> {
        return keys.mapNotNull { COLUMN_MAP[it] }
    }

    /**
     * استخراج صف نصوص متسلسل حسب المفاتيح المحددة
     */
    fun extractRowValues(
        family: FamilyEntity,
        record: AidRecordEntity?,
        index: Int,
        keys: List<String>
    ): List<String> {
        val defs = getOrderedDefs(keys)
        return defs.map { def -> def.valueExtractor(family, record, index) }
    }
}
