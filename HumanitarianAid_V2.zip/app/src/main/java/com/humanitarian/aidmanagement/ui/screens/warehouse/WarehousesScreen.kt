package com.humanitarian.aidmanagement.ui.screens.warehouse

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.PublicDownloadsExporter
import com.humanitarian.aidmanagement.util.SavedExportResult
import com.humanitarian.aidmanagement.util.WarehouseVoucherPdfGenerator
import com.humanitarian.aidmanagement.warehouse.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs

private enum class WarehouseTab(val title: String, val iconEmoji: String) {
    WAREHOUSES_STAFF("المخازن والطاقم", "🏭"),
    STOCK_MOVEMENTS("المخزون والحركات", "📦"),
    CLIENTS_3PL("التخزين للغير (العملاء)", "🤝"),
    FINANCE_PAYROLL("الموازنة والرواتب", "💰"),
    BLIND_AUDIT("الجرد الأعمى", "🕵️")
}

/**
 * الشاشة المتكاملة لإدارة المخازن والمحاسبة اللوجستية والتخزين للغير (Warehouse ERP & 3PL) بـ 5 تبويبات:
 * 1. المخازن والطاقم
 * 2. المخزون والحركات (جملة/فردي + GRN/GDN/مناقلة/تجميع وتفكيك طرود + PDF)
 * 3. التخزين للغير (العملاء 3PL + فواتير ومطالبات PDF)
 * 4. الموازنة والرواتب والمصروفات التشغيلية
 * 5. الجرد الأعمى الموثّق ببصمة SHA-256
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun WarehousesScreen(
    repository: AidRepository,
    onOpenDrawer: () -> Unit,
    onLogout: () -> Unit,
    isWarehouseOnlyMode: Boolean,
    onOpenDynamicReports: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val warehouseState by WarehouseErpStore.stateFlow.collectAsStateWithLifecycle()
    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val assignedWarehouseId by AccessControlManager.assignedWarehouseIdFlow.collectAsStateWithLifecycle()
    val activePermissions by AccessControlManager.permissionsFlow.collectAsStateWithLifecycle()
    val projects by repository.getActiveProjects().collectAsStateWithLifecycle(initialValue = emptyList())

    LaunchedEffect(Unit) {
        AccessControlManager.initWarehouseAssignments(context)
        withContext(Dispatchers.IO) {
            WarehouseErpStore.ensureLoaded(context)
        }
    }

    val isSuperAdmin = remember(currentUser) { AccessControlManager.isSuperAdmin() }
    val isRestrictedToSingleWarehouse = remember(currentUser, assignedWarehouseId, isSuperAdmin) {
        !isSuperAdmin && AccessControlManager.isRestrictedToSingleWarehouse(currentUser)
    }
    val canManageDef = remember(currentUser, activePermissions, isSuperAdmin) {
        isSuperAdmin || AccessControlManager.canManageWarehousesDef()
    }
    val canRecordMovements = remember(currentUser, activePermissions, isSuperAdmin) {
        isSuperAdmin || AccessControlManager.canRecordWarehouseMovements()
    }
    val canManageClients3pl = remember(currentUser, activePermissions, isSuperAdmin) {
        isSuperAdmin || AccessControlManager.canManageWarehouseClients3pl()
    }
    val canManageFinance = remember(currentUser, activePermissions, isSuperAdmin) {
        isSuperAdmin || AccessControlManager.canManageWarehouseFinance()
    }
    val canPerformAudit = remember(currentUser, activePermissions, isSuperAdmin) {
        isSuperAdmin || AccessControlManager.canPerformWarehouseAudit()
    }
    val canViewWarehouseReports = remember(currentUser, activePermissions, isSuperAdmin) {
        isSuperAdmin || AccessControlManager.canAccessScreen(AccessControlManager.SCREEN_WAREHOUSE_REPORTS)
    }
    val canAddNewWarehouse = canManageDef && !isRestrictedToSingleWarehouse

    val visibleWarehouses = remember(warehouseState.warehouses, assignedWarehouseId, isSuperAdmin) {
        if (isSuperAdmin) warehouseState.warehouses else WarehouseErpStore.getVisibleWarehouses(assignedWarehouseId)
    }

    var selectedWarehouseId by remember { mutableStateOf("") }
    LaunchedEffect(visibleWarehouses) {
        if (visibleWarehouses.isEmpty()) {
            selectedWarehouseId = ""
        } else if (visibleWarehouses.none { it.id == selectedWarehouseId }) {
            selectedWarehouseId = visibleWarehouses.first().id
        }
    }

    val activeWarehouse = remember(visibleWarehouses, selectedWarehouseId) {
        visibleWarehouses.firstOrNull { it.id == selectedWarehouseId } ?: visibleWarehouses.firstOrNull()
    }

    val actorName = remember(currentUser) {
        currentUser?.fullName?.takeIf { it.isNotBlank() }
            ?: currentUser?.UserName?.takeIf { it.isNotBlank() }
            ?: "أمين المخزن"
    }

    var selectedTab by remember { mutableStateOf(WarehouseTab.WAREHOUSES_STAFF) }

    // حالات الحوارات
    var showWarehouseDialog by remember { mutableStateOf(false) }
    var editingWarehouse by remember { mutableStateOf<Warehouse?>(null) }

    var showWorkerDialog by remember { mutableStateOf(false) }
    var editingWorker by remember { mutableStateOf<WarehouseWorker?>(null) }

    var showItemDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<WarehouseItem?>(null) }

    var movementDialogMode by remember { mutableStateOf<StockMovementType?>(null) }
    var showKitDialog by remember { mutableStateOf(false) }

    var showClientDialog by remember { mutableStateOf(false) }
    var editingClient by remember { mutableStateOf<StorageClient?>(null) }
    var clientTxTarget by remember { mutableStateOf<Pair<StorageClient, ClientStorageTxType>?>(null) }

    var showBudgetDialog by remember { mutableStateOf(false) }
    var showExpenseDialog by remember { mutableStateOf(false) }

    // حالات الحوارات المتقدمة (الجزء 4: حجر صحي/إتلاف، تأكيد شحنة، تبريد ومولدات، عُهد نقدية، CSV)
    var quarantineTargetItem by remember { mutableStateOf<WarehouseItem?>(null) }
    var confirmShipmentTarget by remember { mutableStateOf<InTransitShipment?>(null) }
    var showColdChainDialog by remember { mutableStateOf(false) }
    var showOpenPettyCashDialog by remember { mutableStateOf(false) }
    var pettyCashSpendTarget by remember { mutableStateOf<PettyCashAdvance?>(null) }
    var settlePettyCashTarget by remember { mutableStateOf<PettyCashAdvance?>(null) }
    var savedCsvDialogState by remember { mutableStateOf<Pair<String, SavedExportResult>?>(null) }

    // حالة نافذة تأكيد حفظ PDF
    var savedPdfDialogState by remember { mutableStateOf<Pair<String, SavedExportResult>?>(null) }

    // حالة الجرد الأعمى للمخزن النشط
    var blindAuditMajorInputs by remember(activeWarehouse?.id) { mutableStateOf<Map<String, String>>(emptyMap()) }
    var blindAuditMinorInputs by remember(activeWarehouse?.id) { mutableStateOf<Map<String, String>>(emptyMap()) }
    var blindAuditReason by remember(activeWarehouse?.id) { mutableStateOf("") }
    var latestBlindAuditReport by remember(activeWarehouse?.id) { mutableStateOf<BlindAuditBatchReport?>(null) }

    // بيانات المخزن النشط
    val activeWorkers = remember(warehouseState.workers, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.workers.filter { it.warehouseId == activeWarehouse.id }
    }
    val activeItems = remember(warehouseState.items, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.items.filter { it.warehouseId == activeWarehouse.id }
    }
    val activeBatches = remember(warehouseState.batches, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.batches.filter { it.warehouseId == activeWarehouse.id && it.remainingMinorQty > 0L }
    }
    val activeMovements = remember(warehouseState.movements, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.movements.filter { it.warehouseId == activeWarehouse.id || it.targetWarehouseId == activeWarehouse.id }
    }
    val activeInTransitShipments = remember(warehouseState.inTransitShipments, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.inTransitShipments.filter {
            it.status == ShipmentStatus.IN_TRANSIT &&
                (it.toWarehouseId == activeWarehouse.id || it.fromWarehouseId == activeWarehouse.id)
        }
    }
    val activeShortageShipments = remember(warehouseState.inTransitShipments, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.inTransitShipments.filter {
            it.status == ShipmentStatus.SHORTAGE_REPORTED &&
                (it.toWarehouseId == activeWarehouse.id || it.fromWarehouseId == activeWarehouse.id)
        }
    }
    val activeColdChainLogs = remember(warehouseState.coldChainLogs, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.coldChainLogs.filter { it.warehouseId == activeWarehouse.id }
    }
    val activePettyCashAdvances = remember(warehouseState.pettyCashAdvances, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.pettyCashAdvances.filter { it.warehouseId == activeWarehouse.id }
    }
    val activeClients = remember(warehouseState.clients, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.clients.filter { it.warehouseId == activeWarehouse.id }
    }
    val activeClientTxs = remember(warehouseState.clientTransactions, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.clientTransactions.filter { it.warehouseId == activeWarehouse.id }
    }
    val activeBudgets = remember(warehouseState.budgetEntries, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.budgetEntries.filter { it.warehouseId == activeWarehouse.id }
    }
    val activeExpenses = remember(warehouseState.expenses, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.expenses.filter { it.warehouseId == activeWarehouse.id }
    }
    val activePayrolls = remember(warehouseState.payrollRecords, activeWarehouse?.id) {
        if (activeWarehouse == null) emptyList()
        else warehouseState.payrollRecords.filter { it.warehouseId == activeWarehouse.id }
    }
    val activeFinance = remember(warehouseState, activeWarehouse?.id) {
        activeWarehouse?.let { WarehouseErpStore.getWarehouseFinancialSummary(it.id) }
    }

    val occupancyPercent = remember(activeWarehouse, activeItems, activeClients, warehouseState.clientTransactions) {
        if (activeWarehouse == null || activeWarehouse.maxCapacity <= 0L) 0
        else {
            val ownUnits = activeItems.sumOf { it.totalMinorQty }
            val thirdPartyUnits = activeClients.sumOf { WarehouseErpStore.calculateClientBilling(it.id).remainingPieces }
            (((ownUnits + thirdPartyUnits) * 100L) / activeWarehouse.maxCapacity).toInt().coerceIn(0, 100)
        }
    }

    val projectNameById = remember(projects) {
        projects.associate { it.projectID.toString() to it.projectName }
    }
    val warehouseNameById = remember(warehouseState.warehouses) {
        warehouseState.warehouses.associate { it.id to it.name }
    }
    val clientNameById = remember(warehouseState.clients) {
        warehouseState.clients.associate { it.id to it.clientName }
    }

    fun exportMovementPdf(mov: StockMovement) {
        val wh = activeWarehouse ?: return
        scope.launch {
            runCatching {
                val itm = WarehouseErpStore.currentState.items.firstOrNull { it.id == mov.itemId }
                val targetWhName = mov.targetWarehouseId?.let { warehouseNameById[it] }
                WarehouseVoucherPdfGenerator.generateStockMovementVoucherPdf(
                    context = context,
                    warehouse = wh,
                    movement = mov,
                    item = itm,
                    targetWarehouseName = targetWhName
                )
            }.onSuccess { res ->
                savedPdfDialogState = "${mov.type.arabicTitle} (${mov.voucherNo})" to res
            }.onFailure { err ->
                Toast.makeText(context, "تعذر توليد السند: ${err.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = SlateBackground,
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        TextButton(onClick = onOpenDrawer) {
                            Text("☰", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = PalestineGreen)
                        }
                    },
                    title = {
                        Column {
                            Text(
                                text = "إدارة المخازن والمحاسبة اللوجستية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SlateTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (isRestrictedToSingleWarehouse) {
                                    "مخزن مخصص: ${activeWarehouse?.name ?: assignedWarehouseId} • $actorName"
                                } else {
                                    "كافة المخازن المصرحة (${visibleWarehouses.size}) • $actorName"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = PalestineGreenDark,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    actions = {
                        if (canViewWarehouseReports) {
                            Surface(
                                onClick = onOpenDynamicReports,
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFECFDF5),
                                border = BorderStroke(1.dp, Color(0xFF6EE7B7)),
                                modifier = Modifier.padding(end = 4.dp)
                            ) {
                                Text(
                                    text = "📊 التقارير الديناميكية",
                                    color = Color(0xFF065F46),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                )
                            }
                        }
                        if (canAddNewWarehouse) {
                            TextButton(onClick = {
                                editingWarehouse = null
                                showWarehouseDialog = true
                            }) {
                                Text("+ مخزن", color = PalestineGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                        if (isWarehouseOnlyMode) {
                            TextButton(onClick = onLogout) {
                                Text("خروج", color = PalestineRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = PalestineWhite,
                        titleContentColor = SlateTextPrimary
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // ============================================================
                // الشريط العلوي لاختيار المخزن النشط + بطاقة الملخص اللحظي
                // ============================================================
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFF064E3B), Color(0xFF047857))
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (visibleWarehouses.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(visibleWarehouses, key = { it.id }) { wh ->
                                val isSelected = wh.id == activeWarehouse?.id
                                Surface(
                                    onClick = { selectedWarehouseId = wh.id },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.16f),
                                    border = BorderStroke(
                                        1.dp,
                                        if (isSelected) Color.White else Color.White.copy(alpha = 0.35f)
                                    )
                                ) {
                                    Text(
                                        text = "🏭 ${wh.name}",
                                        color = if (isSelected) Color(0xFF064E3B) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (activeWarehouse != null) {
                        val activeStaffCount = activeWorkers.count { it.isActive }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            HeaderKpiMini(
                                label = "أمين المخزن",
                                value = activeWarehouse.keeperName.ifBlank { "غير محدد" },
                                modifier = Modifier.weight(1.25f)
                            )
                            HeaderKpiMini(
                                label = "العاملين",
                                value = "$activeStaffCount",
                                modifier = Modifier.weight(0.75f)
                            )
                            HeaderKpiMini(
                                label = "الإشغال",
                                value = "$occupancyPercent%",
                                modifier = Modifier.weight(0.8f)
                            )
                            if (canManageFinance && activeFinance != null) {
                                HeaderKpiMini(
                                    label = "صافي الرصيد",
                                    value = fmtMoney(activeFinance.netWarehouseBalance),
                                    modifier = Modifier.weight(1.1f)
                                )
                            }
                        }

                        LinearProgressIndicator(
                            progress = { occupancyPercent / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(5.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (occupancyPercent >= 90) Color(0xFFFCA5A5) else Color(0xFF6EE7B7),
                            trackColor = Color.White.copy(alpha = 0.22f)
                        )
                    } else {
                        Text(
                            text = if (canAddNewWarehouse) {
                                "لا توجد مخازن مسجلة بعد — اضغط «+ مخزن» بالأعلى لتعريف أول مخزن."
                            } else {
                                "لم يتم تخصيص مخزن لهذا الحساب بعد."
                            },
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // ============================================================
                // شريط التبويبات الخمسة
                // ============================================================
                ScrollableTabRow(
                    selectedTabIndex = selectedTab.ordinal,
                    containerColor = PalestineWhite,
                    contentColor = PalestineGreen,
                    edgePadding = 8.dp
                ) {
                    WarehouseTab.entries.forEach { tab ->
                        Tab(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            text = {
                                Text(
                                    text = "${tab.iconEmoji} ${tab.title}",
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Medium,
                                    maxLines = 1
                                )
                            }
                        )
                    }
                }

                // ============================================================
                // محتوى التبويب النشط
                // ============================================================
                when (selectedTab) {
                    WarehouseTab.WAREHOUSES_STAFF -> {
                        WarehousesAndStaffTab(
                            activeWarehouse = activeWarehouse,
                            workers = activeWorkers,
                            batches = activeBatches,
                            coldChainLogs = activeColdChainLogs,
                            canManageDef = canManageDef,
                            canRecordMovements = canRecordMovements,
                            canAddNewWarehouse = canAddNewWarehouse,
                            onAddWarehouse = {
                                editingWarehouse = null
                                showWarehouseDialog = true
                            },
                            onEditWarehouse = { wh ->
                                editingWarehouse = wh
                                showWarehouseDialog = true
                            },
                            onAddWorker = {
                                editingWorker = null
                                showWorkerDialog = true
                            },
                            onEditWorker = { w ->
                                editingWorker = w
                                showWorkerDialog = true
                            },
                            onDeleteWorker = { workerId ->
                                scope.launch {
                                    WarehouseErpStore.deleteWorker(context, workerId, actorName)
                                    Toast.makeText(context, "تم حذف العامل من الطاقم", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onAddColdChainLog = { showColdChainDialog = true }
                        )
                    }

                    WarehouseTab.STOCK_MOVEMENTS -> {
                        StockAndMovementsTab(
                            activeWarehouse = activeWarehouse,
                            items = activeItems,
                            batches = activeBatches,
                            movements = activeMovements,
                            inTransitShipments = activeInTransitShipments,
                            shortageShipments = activeShortageShipments,
                            projectNameById = projectNameById,
                            warehouseNameById = warehouseNameById,
                            canManageDef = canManageDef,
                            canRecordMovements = canRecordMovements,
                            onAddItem = {
                                editingItem = null
                                showItemDialog = true
                            },
                            onEditItem = { itm ->
                                editingItem = itm
                                showItemDialog = true
                            },
                            onOpenGrn = { movementDialogMode = StockMovementType.IN },
                            onOpenGdn = { movementDialogMode = StockMovementType.OUT },
                            onOpenTransfer = { movementDialogMode = StockMovementType.TRANSFER },
                            onOpenKit = { showKitDialog = true },
                            onConfirmShipment = { shipment -> confirmShipmentTarget = shipment },
                            onQuarantineOrDispose = { itm -> quarantineTargetItem = itm },
                            onExportStockCardCsv = { itm ->
                                val wh = activeWarehouse ?: return@StockAndMovementsTab
                                scope.launch {
                                    runCatching {
                                        WarehouseErpStore.exportStockCardCsv(context, wh.id, itm.id)
                                    }.onSuccess { res ->
                                        savedCsvDialogState = "بطاقة الصنف (Excel/CSV) — ${itm.name}" to res
                                    }.onFailure { err ->
                                        Toast.makeText(context, "تعذر تصدير بطاقة الصنف: ${err.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            onPrintMovementPdf = { mov -> exportMovementPdf(mov) }
                        )
                    }

                    WarehouseTab.CLIENTS_3PL -> {
                        if (!canManageClients3pl) {
                            PermissionLockedPlaceholder("ليس لديك صلاحية «إدارة التخزين للغير (العملاء)»")
                        } else {
                            Clients3plTab(
                                activeWarehouse = activeWarehouse,
                                clients = activeClients,
                                transactions = activeClientTxs,
                                onAddClient = {
                                    editingClient = null
                                    showClientDialog = true
                                },
                                onEditClient = { cli ->
                                    editingClient = cli
                                    showClientDialog = true
                                },
                                onClientAction = { cli, type ->
                                    clientTxTarget = cli to type
                                },
                                onPrintClientInvoice = { cli ->
                                    val wh = activeWarehouse ?: return@Clients3plTab
                                    scope.launch {
                                        runCatching {
                                            val cliTxs = activeClientTxs.filter { it.clientId == cli.id }
                                            val summary = WarehouseErpStore.calculateClientBilling(cli.id)
                                            WarehouseVoucherPdfGenerator.generateClientInvoicePdf(
                                                context = context,
                                                warehouse = wh,
                                                client = cli,
                                                transactions = cliTxs,
                                                summary = summary
                                            )
                                        }.onSuccess { res ->
                                            savedPdfDialogState = "كشف حساب ومطالبة 3PL: ${cli.clientName}" to res
                                        }.onFailure { err ->
                                            Toast.makeText(context, "تعذر توليد الفاتورة: ${err.message}", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                onPrintTxVoucher = { tx ->
                                    val wh = activeWarehouse ?: return@Clients3plTab
                                    val cli = activeClients.firstOrNull { it.id == tx.clientId } ?: return@Clients3plTab
                                    scope.launch {
                                        runCatching {
                                            val summary = WarehouseErpStore.calculateClientBilling(cli.id)
                                            WarehouseVoucherPdfGenerator.generateClientStorageVoucherPdf(
                                                context = context,
                                                warehouse = wh,
                                                client = cli,
                                                tx = tx,
                                                billingSummary = summary
                                            )
                                        }.onSuccess { res ->
                                            savedPdfDialogState = "${tx.type.arabicLabel} — ${cli.clientName}" to res
                                        }.onFailure { err ->
                                            Toast.makeText(context, "تعذر توليد السند: ${err.message}", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            )
                        }
                    }

                    WarehouseTab.FINANCE_PAYROLL -> {
                        if (!canManageFinance) {
                            PermissionLockedPlaceholder("ليس لديك صلاحية «إدارة الموازنة والمصروفات والرواتب»")
                        } else {
                            FinanceAndPayrollTab(
                                activeWarehouse = activeWarehouse,
                                finance = activeFinance,
                                budgets = activeBudgets,
                                expenses = activeExpenses,
                                payrolls = activePayrolls,
                                pettyCashAdvances = activePettyCashAdvances,
                                projectNameById = projectNameById,
                                clientNameById = clientNameById,
                                onAddBudget = { showBudgetDialog = true },
                                onAddExpense = { showExpenseDialog = true },
                                onOpenPettyCash = { showOpenPettyCashDialog = true },
                                onRecordPettyCashSpend = { adv -> pettyCashSpendTarget = adv },
                                onSettlePettyCash = { adv -> settlePettyCashTarget = adv },
                                onDeleteExpense = { expId ->
                                    scope.launch {
                                        WarehouseErpStore.deleteExpense(context, expId, actorName)
                                        Toast.makeText(context, "تم حذف المصروف", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onGeneratePayroll = { periodLabel ->
                                    val wh = activeWarehouse ?: return@FinanceAndPayrollTab
                                    scope.launch {
                                        val generated = WarehouseErpStore.generatePayrollForPeriod(
                                            context = context,
                                            warehouseId = wh.id,
                                            periodLabel = periodLabel,
                                            performedBy = actorName
                                        )
                                        val msg = if (generated.isEmpty()) {
                                            "تم إصدار مسير الفترة $periodLabel مسبقاً أو لا يوجد طاقم نشط"
                                        } else {
                                            "تم إصدار مسير رواتب $periodLabel لعدد ${generated.size} عامل"
                                        }
                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onUpdateDaysWorked = { payId, days ->
                                    scope.launch {
                                        WarehouseErpStore.updatePayrollDaysWorked(context, payId, days)
                                    }
                                },
                                onApproveSinglePayroll = { payId ->
                                    scope.launch {
                                        WarehouseErpStore.approveAndPayPayroll(context, payId, actorName)
                                        Toast.makeText(context, "تم اعتماد وصرف الراتب وخصمه من الموازنة", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onApproveAllForPeriod = { periodLabel ->
                                    val wh = activeWarehouse ?: return@FinanceAndPayrollTab
                                    scope.launch {
                                        val count = WarehouseErpStore.approveAllPendingPayrollForPeriod(
                                            context = context,
                                            warehouseId = wh.id,
                                            periodLabel = periodLabel,
                                            performedBy = actorName
                                        )
                                        Toast.makeText(
                                            context,
                                            if (count > 0) "تم اعتماد وصرف رواتب $count عامل للفترة $periodLabel" else "لا توجد رواتب معلّقة لهذه الفترة",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                },
                                onExportFinancialPdf = {
                                    val wh = activeWarehouse ?: return@FinanceAndPayrollTab
                                    val fin = activeFinance ?: return@FinanceAndPayrollTab
                                    scope.launch {
                                        runCatching {
                                            WarehouseVoucherPdfGenerator.generateFinancialReportPdf(
                                                context = context,
                                                warehouse = wh,
                                                summary = fin,
                                                budgets = activeBudgets,
                                                expenses = activeExpenses,
                                                payrolls = activePayrolls
                                            )
                                        }.onSuccess { res ->
                                            savedPdfDialogState = "التقرير المالي والميزانية والرواتب — ${wh.name}" to res
                                        }.onFailure { err ->
                                            Toast.makeText(context, "تعذر توليد التقرير المالي: ${err.message}", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            )
                        }
                    }

                    WarehouseTab.BLIND_AUDIT -> {
                        if (!canPerformAudit) {
                            PermissionLockedPlaceholder("ليس لديك صلاحية «إجراء الجرد الأعمى والتسويات»")
                        } else {
                            BlindAuditTab(
                                activeWarehouse = activeWarehouse,
                                items = activeItems,
                                majorInputs = blindAuditMajorInputs,
                                minorInputs = blindAuditMinorInputs,
                                reason = blindAuditReason,
                                latestReport = latestBlindAuditReport,
                                onMajorChange = { itemId, v ->
                                    blindAuditMajorInputs = blindAuditMajorInputs.toMutableMap().apply { put(itemId, v) }
                                },
                                onMinorChange = { itemId, v ->
                                    blindAuditMinorInputs = blindAuditMinorInputs.toMutableMap().apply { put(itemId, v) }
                                },
                                onReasonChange = { blindAuditReason = it },
                                onSubmitBlindAudit = {
                                    val wh = activeWarehouse ?: return@BlindAuditTab
                                    if (activeItems.isEmpty()) return@BlindAuditTab
                                    val inputs = activeItems.map { item ->
                                        BlindAuditItemInput(
                                            itemId = item.id,
                                            countedMajorQty = blindAuditMajorInputs[item.id]?.toLongOrNull() ?: 0L,
                                            countedMinorQty = blindAuditMinorInputs[item.id]?.toLongOrNull() ?: 0L
                                        )
                                    }
                                    scope.launch {
                                        runCatching {
                                            WarehouseErpStore.applyBatchBlindAudit(
                                                context = context,
                                                warehouseId = wh.id,
                                                entries = inputs,
                                                reason = blindAuditReason,
                                                performedBy = actorName
                                            )
                                        }.onSuccess { report ->
                                            latestBlindAuditReport = report
                                            blindAuditMajorInputs = emptyMap()
                                            blindAuditMinorInputs = emptyMap()
                                            Toast.makeText(context, "تم اعتماد الجرد الأعمى وتوثيقه ببصمة SHA-256", Toast.LENGTH_LONG).show()
                                        }.onFailure { err ->
                                            Toast.makeText(context, err.message ?: "تعذر اعتماد الجرد", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                onExportAuditPdf = { report ->
                                    val wh = activeWarehouse ?: return@BlindAuditTab
                                    scope.launch {
                                        runCatching {
                                            WarehouseVoucherPdfGenerator.generateBlindAuditReportPdf(
                                                context = context,
                                                warehouse = wh,
                                                report = report
                                            )
                                        }.onSuccess { res ->
                                            savedPdfDialogState = "محضر الجرد الأعمى — ${wh.name}" to res
                                        }.onFailure { err ->
                                            Toast.makeText(context, "تعذر توليد محضر الجرد: ${err.message}", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        // ====================================================================
        // النوافذ المنبثقة (Dialogs)
        // ====================================================================

        if (showWarehouseDialog && (canAddNewWarehouse || editingWarehouse != null)) {
            WarehouseEditorDialog(
                existing = editingWarehouse,
                onDismiss = { showWarehouseDialog = false; editingWarehouse = null },
                onSave = { wh ->
                    scope.launch {
                        val saved = WarehouseErpStore.saveWarehouse(context, wh, actorName)
                        selectedWarehouseId = saved.id
                        showWarehouseDialog = false
                        editingWarehouse = null
                        Toast.makeText(context, "تم حفظ المخزن «${saved.name}»", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        if (showWorkerDialog && activeWarehouse != null && canManageDef) {
            WorkerEditorDialog(
                warehouseId = activeWarehouse.id,
                existing = editingWorker,
                onDismiss = { showWorkerDialog = false; editingWorker = null },
                onSave = { worker ->
                    scope.launch {
                        WarehouseErpStore.saveWorker(context, worker, actorName)
                        showWorkerDialog = false
                        editingWorker = null
                        Toast.makeText(context, "تم حفظ بيانات العامل", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        if (showItemDialog && activeWarehouse != null && (canManageDef || canRecordMovements)) {
            ItemEditorDialog(
                warehouseId = activeWarehouse.id,
                existing = editingItem,
                projects = projects,
                onDismiss = { showItemDialog = false; editingItem = null },
                onSave = { item ->
                    scope.launch {
                        WarehouseErpStore.saveItem(context, item, actorName)
                        showItemDialog = false
                        editingItem = null
                        Toast.makeText(context, "تم حفظ الصنف «${item.name}»", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        val currentMovMode = movementDialogMode
        if (currentMovMode != null && activeWarehouse != null && canRecordMovements) {
            StockMovementActionDialog(
                mode = currentMovMode,
                items = activeItems,
                allWarehouses = warehouseState.warehouses,
                activeWarehouseId = activeWarehouse.id,
                projects = projects,
                onDismiss = { movementDialogMode = null },
                onSubmitGrn = { itemId, maj, min, supplier, waybill, batch, linkedProj, notes, genPdf ->
                    scope.launch {
                        runCatching {
                            WarehouseErpStore.recordStockIn(
                                context = context,
                                warehouseId = activeWarehouse.id,
                                itemId = itemId,
                                majorQty = maj,
                                minorQty = min,
                                supplierOrDonor = supplier,
                                waybillNo = waybill,
                                batchNo = batch,
                                linkedProjectId = linkedProj,
                                notes = notes,
                                performedBy = actorName
                            )
                        }.onSuccess { mov ->
                            movementDialogMode = null
                            Toast.makeText(context, "تم تسجيل سند الواردات ${mov.voucherNo}", Toast.LENGTH_SHORT).show()
                            if (genPdf) exportMovementPdf(mov)
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "خطأ في تسجيل الوارد", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                onSubmitGdn = { itemId, maj, min, recipient, linkedProj, driver, plate, notes, genPdf ->
                    scope.launch {
                        runCatching {
                            WarehouseErpStore.recordStockOut(
                                context = context,
                                warehouseId = activeWarehouse.id,
                                itemId = itemId,
                                majorQty = maj,
                                minorQty = min,
                                recipientOrProject = recipient,
                                linkedProjectId = linkedProj,
                                driverName = driver,
                                vehiclePlate = plate,
                                notes = notes,
                                performedBy = actorName
                            )
                        }.onSuccess { mov ->
                            movementDialogMode = null
                            Toast.makeText(context, "تم تسجيل سند الصادرات ${mov.voucherNo}", Toast.LENGTH_SHORT).show()
                            if (genPdf) exportMovementPdf(mov)
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "خطأ في تسجيل الصادر", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                onSubmitTransfer = { itemId, targetWhId, maj, min, driver, plate, notes, genPdf ->
                    scope.launch {
                        runCatching {
                            WarehouseErpStore.recordTransfer(
                                context = context,
                                sourceWarehouseId = activeWarehouse.id,
                                targetWarehouseId = targetWhId,
                                sourceItemId = itemId,
                                majorQty = maj,
                                minorQty = min,
                                driverName = driver,
                                vehiclePlate = plate,
                                notes = notes,
                                performedBy = actorName
                            )
                        }.onSuccess { mov ->
                            movementDialogMode = null
                            Toast.makeText(context, "تمت المناقلة بنجاح (${mov.voucherNo})", Toast.LENGTH_SHORT).show()
                            if (genPdf) exportMovementPdf(mov)
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "خطأ في تنفيذ المناقلة", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }

        if (showKitDialog && activeWarehouse != null && canRecordMovements) {
            KitAssemblyDialog(
                items = activeItems,
                onDismiss = { showKitDialog = false },
                onExecute = { isAssemble, kitItemId, kitsCount, specs, notes ->
                    scope.launch {
                        runCatching {
                            if (isAssemble) {
                                WarehouseErpStore.assembleKit(
                                    context = context,
                                    warehouseId = activeWarehouse.id,
                                    targetKitItemId = kitItemId,
                                    kitsCount = kitsCount,
                                    components = specs,
                                    notes = notes,
                                    performedBy = actorName
                                )
                            } else {
                                WarehouseErpStore.unbundleKit(
                                    context = context,
                                    warehouseId = activeWarehouse.id,
                                    sourceKitItemId = kitItemId,
                                    kitsCount = kitsCount,
                                    components = specs,
                                    notes = notes,
                                    performedBy = actorName
                                )
                            }
                        }.onSuccess { mov ->
                            showKitDialog = false
                            Toast.makeText(context, "تم تنفيذ العملية بنجاح (${mov.voucherNo})", Toast.LENGTH_SHORT).show()
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "تعذر تنفيذ التجميع/التفكيك", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }

        if (showClientDialog && activeWarehouse != null && canManageClients3pl) {
            StorageClientEditorDialog(
                warehouseId = activeWarehouse.id,
                existing = editingClient,
                onDismiss = { showClientDialog = false; editingClient = null },
                onSave = { cli ->
                    scope.launch {
                        WarehouseErpStore.saveClient(context, cli, actorName)
                        showClientDialog = false
                        editingClient = null
                        Toast.makeText(context, "تم حفظ عميل التخزين «${cli.clientName}»", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        val currentCliTx = clientTxTarget
        if (currentCliTx != null && activeWarehouse != null && canManageClients3pl) {
            val (cli, txType) = currentCliTx
            ClientTransactionDialog(
                client = cli,
                txType = txType,
                onDismiss = { clientTxTarget = null },
                onSubmit = { qty, payAmt, desc, notes, genPdf ->
                    scope.launch {
                        runCatching {
                            WarehouseErpStore.recordClientTransaction(
                                context = context,
                                clientId = cli.id,
                                type = txType,
                                quantityPieces = qty,
                                paymentAmount = payAmt,
                                itemDescription = desc,
                                notes = notes,
                                performedBy = actorName
                            )
                        }.onSuccess { tx ->
                            clientTxTarget = null
                            Toast.makeText(context, "تم تسجيل حركة العميل بنجاح", Toast.LENGTH_SHORT).show()
                            if (genPdf) {
                                runCatching {
                                    val summary = WarehouseErpStore.calculateClientBilling(cli.id)
                                    WarehouseVoucherPdfGenerator.generateClientStorageVoucherPdf(
                                        context = context,
                                        warehouse = activeWarehouse,
                                        client = cli,
                                        tx = tx,
                                        billingSummary = summary
                                    )
                                }.onSuccess { res ->
                                    savedPdfDialogState = "${tx.type.arabicLabel} — ${cli.clientName}" to res
                                }
                            }
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "خطأ في تسجيل حركة العميل", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }

        if (showBudgetDialog && activeWarehouse != null && canManageFinance) {
            AddBudgetDialog(
                onDismiss = { showBudgetDialog = false },
                onSave = { amount, source, notes ->
                    scope.launch {
                        WarehouseErpStore.addBudgetEntry(
                            context = context,
                            warehouseId = activeWarehouse.id,
                            allocatedAmount = amount,
                            fundingSource = source,
                            notes = notes,
                            performedBy = actorName
                        )
                        showBudgetDialog = false
                        Toast.makeText(context, "تم تخصيص الموازنة بنجاح", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        if (showExpenseDialog && activeWarehouse != null && canManageFinance) {
            AddExpenseWithAllocationDialog(
                projects = projects,
                clients = activeClients,
                onDismiss = { showExpenseDialog = false },
                onSave = { category, amount, invoiceNo, allocatedTarget, notes ->
                    scope.launch {
                        WarehouseErpStore.addExpense(
                            context = context,
                            warehouseId = activeWarehouse.id,
                            category = category,
                            amount = amount,
                            invoiceNo = invoiceNo,
                            notes = notes,
                            performedBy = actorName,
                            allocatedTarget = allocatedTarget
                        )
                        showExpenseDialog = false
                        Toast.makeText(context, "تم تسجيل المصروف التشغيلي وتحميل التكلفة", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        val currentQuarantineItem = quarantineTargetItem
        if (currentQuarantineItem != null && activeWarehouse != null && canRecordMovements) {
            val itemBatches = remember(activeBatches, currentQuarantineItem.id) {
                activeBatches.filter { it.itemId == currentQuarantineItem.id && it.remainingMinorQty > 0L }
            }
            QuarantineOrDisposeDialog(
                item = currentQuarantineItem,
                batches = itemBatches,
                onDismiss = { quarantineTargetItem = null },
                onSubmit = { batchNo, minorQty, reason, isDisposed, genPdf ->
                    scope.launch {
                        runCatching {
                            WarehouseErpStore.moveToQuarantineOrDispose(
                                context = context,
                                itemId = currentQuarantineItem.id,
                                batchNo = batchNo,
                                minorQty = minorQty,
                                reason = reason,
                                isDisposed = isDisposed,
                                performedBy = actorName
                            )
                        }.onSuccess { mov ->
                            quarantineTargetItem = null
                            Toast.makeText(
                                context,
                                if (isDisposed) "تم اعتماد محضر الإتلاف (${mov.voucherNo})" else "تم نقل الكمية إلى الحجر الصحي (${mov.voucherNo})",
                                Toast.LENGTH_LONG
                            ).show()
                            if (genPdf) exportMovementPdf(mov)
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "تعذر تنفيذ الحجر الصحي/الإتلاف", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }

        val currentShipment = confirmShipmentTarget
        if (currentShipment != null && activeWarehouse != null && canRecordMovements) {
            ConfirmShipmentArrivalDialog(
                shipment = currentShipment,
                fromWarehouseName = warehouseNameById[currentShipment.fromWarehouseId] ?: currentShipment.fromWarehouseId,
                toWarehouseName = warehouseNameById[currentShipment.toWarehouseId] ?: currentShipment.toWarehouseId,
                onDismiss = { confirmShipmentTarget = null },
                onConfirm = { actualReceivedQty, notes ->
                    scope.launch {
                        runCatching {
                            WarehouseErpStore.confirmShipmentArrival(
                                context = context,
                                shipmentId = currentShipment.shipmentId,
                                actualReceivedMinorQty = actualReceivedQty,
                                notes = notes,
                                performedBy = actorName
                            )
                        }.onSuccess { confirmed ->
                            confirmShipmentTarget = null
                            val msg = if (confirmed.status == ShipmentStatus.SHORTAGE_REPORTED) {
                                "تم استلام ${confirmed.receivedMinorQty} وإصدار «محضر عجز نقل» (${confirmed.shortageQty}) ببصمة SHA-256"
                            } else {
                                "تم تأكيد استلام الشحنة بالكامل (${confirmed.receivedMinorQty} وحدة)"
                            }
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "تعذر تأكيد الاستلام", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }

        if (showColdChainDialog && activeWarehouse != null && (canManageDef || canRecordMovements)) {
            AddColdChainLogDialog(
                warehouse = activeWarehouse,
                onDismiss = { showColdChainDialog = false },
                onSave = { tempC, genHours, notes ->
                    scope.launch {
                        runCatching {
                            WarehouseErpStore.addColdChainLog(
                                context = context,
                                warehouseId = activeWarehouse.id,
                                temperatureCelsius = tempC,
                                generatorHours = genHours,
                                recordedBy = actorName,
                                notes = notes
                            )
                        }.onSuccess {
                            showColdChainDialog = false
                            Toast.makeText(context, "تم تسجيل قراءة التبريد والمولد بنجاح", Toast.LENGTH_SHORT).show()
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "تعذر حفظ قراءة التبريد", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }

        if (showOpenPettyCashDialog && activeWarehouse != null && canManageFinance) {
            OpenPettyCashDialog(
                defaultKeeperName = activeWarehouse.keeperName.ifBlank { actorName },
                onDismiss = { showOpenPettyCashDialog = false },
                onSave = { keeperName, amount, notes ->
                    scope.launch {
                        runCatching {
                            WarehouseErpStore.openPettyCashAdvance(
                                context = context,
                                warehouseId = activeWarehouse.id,
                                keeperName = keeperName,
                                amount = amount,
                                notes = notes,
                                performedBy = actorName
                            )
                        }.onSuccess {
                            showOpenPettyCashDialog = false
                            Toast.makeText(context, "تم صرف عُهدة تشغيلية جديدة لأمين المخزن", Toast.LENGTH_SHORT).show()
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "تعذر فتح العُهدة", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }

        val currentSpendAdvance = pettyCashSpendTarget
        if (currentSpendAdvance != null && activeWarehouse != null && canManageFinance) {
            PettyCashSpendDialog(
                advance = currentSpendAdvance,
                projects = projects,
                clients = activeClients,
                onDismiss = { pettyCashSpendTarget = null },
                onSave = { amount, category, invoiceNo, allocatedTarget, notes ->
                    scope.launch {
                        runCatching {
                            WarehouseErpStore.recordPettyCashSpend(
                                context = context,
                                advanceId = currentSpendAdvance.id,
                                amount = amount,
                                category = category,
                                invoiceNo = invoiceNo,
                                allocatedTarget = allocatedTarget,
                                notes = notes,
                                performedBy = actorName
                            )
                        }.onSuccess {
                            pettyCashSpendTarget = null
                            Toast.makeText(context, "تم خصم الفاتورة من العُهدة وتسجيلها في المصروفات", Toast.LENGTH_SHORT).show()
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "تعذر الصرف من العُهدة", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }

        val currentSettleAdvance = settlePettyCashTarget
        if (currentSettleAdvance != null && activeWarehouse != null && canManageFinance) {
            SettlePettyCashDialog(
                advance = currentSettleAdvance,
                onDismiss = { settlePettyCashTarget = null },
                onConfirm = { notes ->
                    scope.launch {
                        runCatching {
                            WarehouseErpStore.settlePettyCashAdvance(
                                context = context,
                                advanceId = currentSettleAdvance.id,
                                settlementNotes = notes,
                                performedBy = actorName
                            )
                        }.onSuccess {
                            settlePettyCashTarget = null
                            Toast.makeText(context, "تمت تسوية وإقفال العُهدة النقدية بنجاح", Toast.LENGTH_SHORT).show()
                        }.onFailure { err ->
                            Toast.makeText(context, err.message ?: "تعذر تسوية العُهدة", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }

        val csvModal = savedCsvDialogState
        if (csvModal != null) {
            SavedCsvConfirmDialog(
                title = csvModal.first,
                result = csvModal.second,
                onDismiss = { savedCsvDialogState = null }
            )
        }

        val pdfModal = savedPdfDialogState
        if (pdfModal != null) {
            SavedPdfConfirmDialog(
                result = pdfModal.second,
                title = pdfModal.first,
                onOpenFile = {
                    if (!PublicDownloadsExporter.openSavedPdf(context, pdfModal.second)) {
                        Toast.makeText(context, "لا يوجد تطبيق عارض PDF مثبت على الجهاز", Toast.LENGTH_SHORT).show()
                    }
                },
                onShareFile = {
                    PublicDownloadsExporter.shareSavedPdf(context, pdfModal.second, pdfModal.first)
                },
                onDismiss = { savedPdfDialogState = null }
            )
        }
    }
}

// ============================================================================
// التبويب 1: المخازن والطاقم
// ============================================================================

@Composable
private fun WarehousesAndStaffTab(
    activeWarehouse: Warehouse?,
    workers: List<WarehouseWorker>,
    batches: List<StockBatch>,
    coldChainLogs: List<ColdChainLog>,
    canManageDef: Boolean,
    canRecordMovements: Boolean,
    canAddNewWarehouse: Boolean,
    onAddWarehouse: () -> Unit,
    onEditWarehouse: (Warehouse) -> Unit,
    onAddWorker: () -> Unit,
    onEditWorker: (WarehouseWorker) -> Unit,
    onDeleteWorker: (String) -> Unit,
    onAddColdChainLog: () -> Unit
) {
    val activeWorkers = workers.filter { it.isActive }
    val estimatedMonthlyPayroll = remember(activeWorkers) {
        activeWorkers.sumOf { w ->
            if (w.payType == WorkerPayType.MONTHLY) w.rate else (w.rate * 26.0)
        }
    }
    val zoneTotals = remember(batches) {
        WarehouseConstants.STORAGE_ZONES.associateWith { zone ->
            batches.filter { it.zoneName == zone }.sumOf { it.remainingMinorQty }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (activeWarehouse == null) {
            item {
                EmptyWarehousePromptCard(canAddNewWarehouse, onAddWarehouse)
            }
            return@LazyColumn
        }

        item(key = "wh_details") {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🏭 بطاقة المخزن النشط", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PalestineGreenDark)
                        if (canManageDef) {
                            OutlinedButton(
                                onClick = { onEditWarehouse(activeWarehouse) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("تعديل المخزن", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    InfoLine("الاسم والموقع", "${activeWarehouse.name} • ${activeWarehouse.location.ifBlank { "-" }}")
                    InfoLine("النوع والحالة", "${activeWarehouse.storageType} • ${activeWarehouse.status}")
                    InfoLine("السعة القصوى", "${activeWarehouse.maxCapacity} قطعة")
                    InfoLine("أمين المخزن", "${activeWarehouse.keeperName.ifBlank { "-" }} • هوية: ${activeWarehouse.keeperId.ifBlank { "-" }} • جوال: ${activeWarehouse.keeperPhone.ifBlank { "-" }}")
                    if (activeWarehouse.equipmentNotes.isNotBlank()) {
                        InfoLine("عهدة التجهيزات", activeWarehouse.equipmentNotes)
                    }
                }
            }
        }

        // بطاقة القطاعات المكانية وسجل التبريد والمولدات
        item(key = "zones_and_cold_chain") {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                border = BorderStroke(1.dp, Color(0xFF93C5FD)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "❄️ القطاعات المكانية وسجل التبريد والمولدات",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color(0xFF075985),
                            modifier = Modifier.weight(1f)
                        )
                        if (canManageDef || canRecordMovements) {
                            Button(
                                onClick = onAddColdChainLog,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("+ قراءة تبريد ومولد", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ClientKpiChip("جاف", "${zoneTotals[WarehouseConstants.ZONE_DRY] ?: 0L}", Color(0xFF065F46), Modifier.weight(1f))
                        ClientKpiChip("مبرد", "${zoneTotals[WarehouseConstants.ZONE_COLD] ?: 0L}", Color(0xFF0284C7), Modifier.weight(1f))
                        ClientKpiChip("أمانات", "${zoneTotals[WarehouseConstants.ZONE_CUSTODY] ?: 0L}", Color(0xFF7C3AED), Modifier.weight(1f))
                        ClientKpiChip("حجر صحي", "${zoneTotals[WarehouseConstants.ZONE_QUARANTINE] ?: 0L}", PalestineRed, Modifier.weight(1f))
                    }

                    if (coldChainLogs.isEmpty()) {
                        Text(
                            text = if (activeWarehouse.storageType == "مبرد") {
                                "⚠️ مخزن مبرد — لم يتم تسجيل أي قراءة حرارة أو ساعات مولد بعد."
                            } else {
                                "لا توجد قراءات مسجلة للتبريد والمولدات في هذا المخزن."
                            },
                            fontSize = 11.sp,
                            color = if (activeWarehouse.storageType == "مبرد") Color(0xFFB45309) else SlateTextSecondary
                        )
                    } else {
                        coldChainLogs.take(4).forEach { log ->
                            val tempAlert = activeWarehouse.storageType == "مبرد" && log.temperatureCelsius > 8.0
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (tempAlert) Color(0xFFFEF2F2) else Color(0xFFF0F9FF),
                                border = BorderStroke(1.dp, if (tempAlert) Color(0xFFFCA5A5) else Color(0xFFBAE6FD)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "🌡️ ${log.temperatureCelsius}°C  •  ⚡ المولد: ${log.generatorHours} ساعة",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.5.sp,
                                            color = if (tempAlert) PalestineRed else Color(0xFF075985)
                                        )
                                        Text(log.timestamp, fontSize = 10.sp, color = SlateTextSecondary)
                                    }
                                    Text(
                                        text = "بواسطة: ${log.recordedBy.ifBlank { "أمين المخزن" }}" +
                                            (if (log.notes.isNotBlank()) " • ${log.notes}" else ""),
                                        fontSize = 10.5.sp,
                                        color = SlateTextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item(key = "staff_header") {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                border = BorderStroke(1.dp, Color(0xFF6EE7B7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("👥 طاقم العاملين بالمخزن (${activeWorkers.size} نشط)", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = Color(0xFF065F46))
                        Text(
                            text = "التكلفة الشهرية التقديرية: ${fmtMoney(estimatedMonthlyPayroll)}",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF047857)
                        )
                    }
                    if (canManageDef) {
                        Button(
                            onClick = onAddWorker,
                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("+ إضافة عامل", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (workers.isEmpty()) {
            item {
                Text(
                    text = "لا يوجد عاملون مسجلون في طاقم هذا المخزن بعد.",
                    fontSize = 12.sp,
                    color = SlateTextSecondary,
                    modifier = Modifier.padding(8.dp)
                )
            }
        } else {
            items(workers, key = { it.id }) { worker ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "${worker.name} ${if (!worker.isActive) "(غير نشط)" else ""}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateTextPrimary
                            )
                            Text(
                                text = "${worker.role} • ${worker.payType.arabicLabel}: ${fmtMoney(worker.rate)}",
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }
                        if (canManageDef) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(onClick = { onEditWorker(worker) }) {
                                    Text("تعديل", fontSize = 11.sp, color = PalestineGreen)
                                }
                                TextButton(onClick = { onDeleteWorker(worker.id) }) {
                                    Text("حذف", fontSize = 11.sp, color = PalestineRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// التبويب 2: المخزون والحركات (GRN / GDN / مناقلة / تجميع طرود + PDF)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StockAndMovementsTab(
    activeWarehouse: Warehouse?,
    items: List<WarehouseItem>,
    batches: List<StockBatch>,
    movements: List<StockMovement>,
    inTransitShipments: List<InTransitShipment>,
    shortageShipments: List<InTransitShipment>,
    projectNameById: Map<String, String>,
    warehouseNameById: Map<String, String>,
    canManageDef: Boolean,
    canRecordMovements: Boolean,
    onAddItem: () -> Unit,
    onEditItem: (WarehouseItem) -> Unit,
    onOpenGrn: () -> Unit,
    onOpenGdn: () -> Unit,
    onOpenTransfer: () -> Unit,
    onOpenKit: () -> Unit,
    onConfirmShipment: (InTransitShipment) -> Unit,
    onQuarantineOrDispose: (WarehouseItem) -> Unit,
    onExportStockCardCsv: (WarehouseItem) -> Unit,
    onPrintMovementPdf: (StockMovement) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (activeWarehouse == null) {
            item { Text("يرجى اختيار أو إضافة مخزن أولاً.", fontSize = 12.sp, color = SlateTextSecondary) }
            return@LazyColumn
        }

        // قسم الشحنات قيد النقل بانتظار الاستلام (In-Transit)
        if (inTransitShipments.isNotEmpty() || shortageShipments.isNotEmpty()) {
            item(key = "in_transit_section") {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                    border = BorderStroke(1.2.dp, Color(0xFF3B82F6)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "🚚 شحنات قيد النقل بانتظار الاستلام (In-Transit) (${inTransitShipments.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF1E3A8A)
                        )
                        if (inTransitShipments.isEmpty()) {
                            Text(
                                text = "لا توجد شحنات في الطريق حالياً.",
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        } else {
                            inTransitShipments.forEach { shp ->
                                val fromName = warehouseNameById[shp.fromWarehouseId] ?: shp.fromWarehouseId
                                val toName = warehouseNameById[shp.toWarehouseId] ?: shp.toWarehouseId
                                val isIncomingHere = shp.toWarehouseId == activeWarehouse.id
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${shp.itemName} (${shp.sentMinorQty} ${shp.minorUnitName})",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.5.sp,
                                                color = SlateTextPrimary,
                                                modifier = Modifier.weight(1f)
                                            )
                                            AlertTagChip(
                                                text = if (isIncomingHere) "واردة لهذا المخزن" else "صادرة بالطريق",
                                                bg = if (isIncomingHere) Color(0xFFDBEAFE) else Color(0xFFFEF3C7),
                                                fg = if (isIncomingHere) Color(0xFF1D4ED8) else Color(0xFF92400E)
                                            )
                                        }
                                        Text(
                                            text = "المسار: $fromName ⬅ $toName • تصريح: ${shp.gatePassToken}",
                                            fontSize = 10.5.sp,
                                            color = SlateTextSecondary
                                        )
                                        Text(
                                            text = "السائق: ${shp.driverName.ifBlank { "-" }} (${shp.vehiclePlate.ifBlank { "-" }})" +
                                                (if (shp.batchNo.isNotBlank()) " • تشغيلة: ${shp.batchNo}" else ""),
                                            fontSize = 10.5.sp,
                                            color = SlateTextSecondary
                                        )
                                        if (canRecordMovements) {
                                            Button(
                                                onClick = { onConfirmShipment(shp) },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                                shape = RoundedCornerShape(8.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Text("✅ تأكيد الاستلام الفعلي", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (shortageShipments.isNotEmpty()) {
                            HorizontalDivider(color = Color(0xFFBFDBFE))
                            Text(
                                text = "⚠️ محاضر عجز نقل موثّقة (${shortageShipments.size}):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = PalestineRed
                            )
                            shortageShipments.take(3).forEach { sh ->
                                Text(
                                    text = "• ${sh.itemName}: مرسل ${sh.sentMinorQty} | مستلم ${sh.receivedMinorQty} | عجز ${sh.shortageQty}" +
                                        (if (sh.shortageAuditHash.isNotBlank()) " (SHA-256: ${sh.shortageAuditHash.take(10)}…)" else ""),
                                    fontSize = 10.5.sp,
                                    color = Color(0xFF991B1B)
                                )
                            }
                        }
                    }
                }
            }
        }

        // أزرار الحركات السريعة
        item(key = "quick_actions") {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("⚡ عمليات المخزون السريعة", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PalestineGreenDark)
                        if (canManageDef || canRecordMovements) {
                            OutlinedButton(
                                onClick = onAddItem,
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("+ تعريف صنف", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (canRecordMovements) {
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onOpenGrn,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                            ) { Text("+ سند واردات (GRN)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }

                            Button(
                                onClick = onOpenGdn,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                            ) { Text("- سند صادرات (GDN)", fontSize = 11.sp, fontWeight = FontWeight.Bold) }

                            Button(
                                onClick = onOpenTransfer,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                            ) { Text("⇄ مناقلة بين مخزنين", fontSize = 11.sp, fontWeight = FontWeight.Bold) }

                            Button(
                                onClick = onOpenKit,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                            ) { Text("📦 تجميع/تفكيك طرود", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        }
                    } else {
                        Text(
                            text = "وضع القراءة فقط — لا تملك صلاحية «تسجيل واردات وصادرات ومناقلات».",
                            fontSize = 11.sp,
                            color = SlateTextSecondary
                        )
                    }
                }
            }
        }

        // قائمة الأصناف بالوحدات المزدوجة + FEFO + التنبؤ بالنفاد + حجر صحي + بطاقة الصنف Excel
        item(key = "items_section_title") {
            Text(
                text = "📋 أرصدة الأصناف والتشغيلات (FEFO) (${items.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = SlateTextPrimary
            )
        }

        if (items.isEmpty()) {
            item { Text("لا توجد أصناف معرفة في هذا المخزن بعد.", fontSize = 12.sp, color = SlateTextSecondary) }
        } else {
            items(items, key = { it.id }) { item ->
                val itemBatches = remember(batches, item.id) {
                    WarehouseErpStore.getActiveBatchesForItem(item.id, includeQuarantine = true)
                }
                val healthyBatches = remember(itemBatches) { itemBatches.filter { !it.isQuarantined } }
                val quarantinedQty = remember(itemBatches) { itemBatches.filter { it.isQuarantined }.sumOf { it.remainingMinorQty } }
                val earliestFefoBatch = healthyBatches.firstOrNull()
                val earliestExpiryStr = earliestFefoBatch?.expiryDate?.ifBlank { item.expiryDate } ?: item.expiryDate
                val expiryAlert = remember(earliestExpiryStr) { checkExpiryAlert(earliestExpiryStr) }
                val daysUntilStockout = remember(item.id, item.totalMinorQty, movements.size) {
                    WarehouseErpStore.predictDaysUntilStockout(item.id)
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(
                        1.dp,
                        when {
                            item.isLowStock -> Color(0xFFFCA5A5)
                            daysUntilStockout != null && daysUntilStockout < 7 -> Color(0xFFFDBA74)
                            expiryAlert != null -> Color(0xFFFCD34D)
                            else -> SlateBorder
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.name, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = SlateTextPrimary)
                                Text(
                                    text = "${item.category.ifBlank { "عام" }} • 1 ${item.majorUnitName} = ${item.safeConversionFactor} ${item.minorUnitName}",
                                    fontSize = 10.5.sp,
                                    color = SlateTextSecondary
                                )
                            }
                            if (canManageDef || canRecordMovements) {
                                TextButton(onClick = { onEditItem(item) }) {
                                    Text("تعديل", fontSize = 11.sp, color = PalestineGreen)
                                }
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFECFDF5),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = "الرصيد الصالح: ${item.formatDualQuantity()}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp,
                                    color = Color(0xFF065F46)
                                )
                                if (earliestFefoBatch != null || earliestExpiryStr.isNotBlank()) {
                                    Text(
                                        text = "📅 FEFO (${healthyBatches.size} تشغيلة نشطة) • أقرب انتهاء: ${earliestExpiryStr.ifBlank { "غير محدد" }}" +
                                            (if (earliestFefoBatch != null) " • تشغيلة: ${earliestFefoBatch.batchNo} (${earliestFefoBatch.zoneName})" else ""),
                                        fontSize = 10.5.sp,
                                        color = Color(0xFF047857)
                                    )
                                }
                            }
                        }

                        // مؤشرات التنبؤ بالنفاد والتنبيهات والتشغيلات
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            when {
                                daysUntilStockout != null && daysUntilStockout < 7 -> {
                                    AlertTagChip(
                                        text = "⏳ يكفي لـ $daysUntilStockout أيام",
                                        bg = Color(0xFFFFEDD5),
                                        fg = Color(0xFFC2410C)
                                    )
                                }
                                daysUntilStockout != null -> {
                                    AlertTagChip(
                                        text = "✅ مخزون آمن (يكفي لـ $daysUntilStockout يوم)",
                                        bg = Color(0xFFDCFCE7),
                                        fg = Color(0xFF166534)
                                    )
                                }
                                item.totalMinorQty > 0L && !item.isLowStock -> {
                                    AlertTagChip(
                                        text = "✅ مخزون آمن",
                                        bg = Color(0xFFDCFCE7),
                                        fg = Color(0xFF166534)
                                    )
                                }
                            }
                            if (item.isLowStock) {
                                AlertTagChip("⚠️ حد حرج (≤ ${item.minThreshold})", Color(0xFFFEE2E2), Color(0xFF991B1B))
                            }
                            if (expiryAlert != null) {
                                AlertTagChip("⏳ $expiryAlert", Color(0xFFFEF3C7), Color(0xFF92400E))
                            }
                            if (quarantinedQty > 0L) {
                                AlertTagChip("☣️ حجر صحي: $quarantinedQty ${item.minorUnitName}", Color(0xFFFEE2E2), Color(0xFF991B1B))
                            }
                            if (!item.linkedProjectId.isNullOrBlank()) {
                                val pName = projectNameById[item.linkedProjectId] ?: "مشروع #${item.linkedProjectId}"
                                AlertTagChip("🔗 مربوط بالتسليم: $pName", Color(0xFFE0F2FE), Color(0xFF075985))
                            }
                        }

                        // عرض التشغيلات النشطة والمحجورة باختصار
                        if (itemBatches.isNotEmpty()) {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                itemBatches.take(4).forEach { b ->
                                    AlertTagChip(
                                        text = "${b.batchNo}: ${b.remainingMinorQty} (${b.zoneName}${if (b.expiryDate.isNotBlank()) " • ${b.expiryDate}" else ""})",
                                        bg = if (b.isQuarantined) Color(0xFFFEE2E2) else Color(0xFFF1F5F9),
                                        fg = if (b.isQuarantined) Color(0xFF991B1B) else SlateTextPrimary
                                    )
                                }
                            }
                        }

                        // أزرار الحجر الصحي / الإتلاف وتصدير بطاقة الصنف Excel
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (canRecordMovements) {
                                OutlinedButton(
                                    onClick = { onQuarantineOrDispose(item) },
                                    border = BorderStroke(1.dp, Color(0xFFD97706)),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("⚠️ حجر صحي / محضر إتلاف", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                                }
                            }
                            OutlinedButton(
                                onClick = { onExportStockCardCsv(item) },
                                border = BorderStroke(1.dp, PalestineGreen),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("📊 تصدير بطاقة الصنف (Excel)", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                            }
                        }
                    }
                }
            }
        }

        // سجل آخر الحركات مع طباعة PDF
        item(key = "movements_section_title") {
            Text(
                text = "🧾 سجل آخر حركات المخزون (${movements.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = SlateTextPrimary,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        if (movements.isEmpty()) {
            item { Text("لا توجد حركات مخزنية مسجلة بعد.", fontSize = 12.sp, color = SlateTextSecondary) }
        } else {
            items(movements.take(40), key = { it.id }) { mov ->
                val isPositive = mov.totalMinorDelta >= 0L
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "${mov.type.arabicTitle} • ${mov.itemName}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = SlateTextPrimary
                            )
                            Text(
                                text = "السند: ${mov.voucherNo} • ${mov.date}",
                                fontSize = 10.sp,
                                color = SlateTextSecondary
                            )
                            Text(
                                text = "الكمية: ${if (isPositive) "+" else "-"}${abs(mov.totalMinorDelta)} وحدة صغرى" +
                                    (if (mov.supplierOrDonor.isNotBlank()) " • المورد: ${mov.supplierOrDonor}" else "") +
                                    (if (mov.recipientOrProject.isNotBlank()) " • المستلم: ${mov.recipientOrProject}" else ""),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isPositive) Color(0xFF059669) else Color(0xFFDC2626)
                            )
                        }
                        OutlinedButton(
                            onClick = { onPrintMovementPdf(mov) },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("🧾 PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// التبويب 3: التخزين للغير (العملاء 3PL)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Clients3plTab(
    activeWarehouse: Warehouse?,
    clients: List<StorageClient>,
    transactions: List<ClientStorageTx>,
    onAddClient: () -> Unit,
    onEditClient: (StorageClient) -> Unit,
    onClientAction: (StorageClient, ClientStorageTxType) -> Unit,
    onPrintClientInvoice: (StorageClient) -> Unit,
    onPrintTxVoucher: (ClientStorageTx) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (activeWarehouse == null) {
            item { Text("يرجى اختيار أو إضافة مخزن أولاً.", fontSize = 12.sp, color = SlateTextSecondary) }
            return@LazyColumn
        }

        item(key = "clients_top") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🤝 عملاء التخزين للغير — 3PL (${clients.size})", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                Button(
                    onClick = onAddClient,
                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("+ عميل جديد", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (clients.isEmpty()) {
            item { Text("لا يوجد عملاء تخزين للغير مسجلون في هذا المخزن بعد.", fontSize = 12.sp, color = SlateTextSecondary) }
        } else {
            items(clients, key = { it.id }) { client ->
                val billing = remember(client, transactions) {
                    WarehouseErpStore.calculateClientBilling(client.id)
                }
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(client.clientName, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SlateTextPrimary)
                                Text(
                                    text = "${client.billingModel.arabicLabel}: ${fmtMoney(client.unitRate)} • سماح ${client.freeGraceDays} يوم • ${client.phone.ifBlank { "-" }}",
                                    fontSize = 10.5.sp,
                                    color = SlateTextSecondary
                                )
                            }
                            TextButton(onClick = { onEditClient(client) }) {
                                Text("تعديل", fontSize = 11.sp, color = PalestineGreen)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            ClientKpiChip("القطع الحالية", "${billing.remainingPieces}", Color(0xFF064E3B), Modifier.weight(1f))
                            ClientKpiChip("الأيام", "${billing.totalBillableStorageDays}", SlateTextPrimary, Modifier.weight(0.8f))
                            ClientKpiChip("الأجرة", fmtMoney(billing.totalCharges), Color(0xFFB45309), Modifier.weight(1f))
                            ClientKpiChip("المدفوع", fmtMoney(billing.totalPaid), Color(0xFF059669), Modifier.weight(1f))
                            ClientKpiChip("المتبقي", fmtMoney(billing.netAmountDue), if (billing.netAmountDue > 0.0) PalestineRed else Color(0xFF059669), Modifier.weight(1f))
                        }

                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { onClientAction(client, ClientStorageTxType.DEPOSIT) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) { Text("+ إيداع قطع", fontSize = 11.sp, fontWeight = FontWeight.Bold) }

                            Button(
                                onClick = { onClientAction(client, ClientStorageTxType.WITHDRAWAL) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) { Text("- سحب قطع", fontSize = 11.sp, fontWeight = FontWeight.Bold) }

                            Button(
                                onClick = { onClientAction(client, ClientStorageTxType.PAYMENT) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) { Text("💵 تسجيل دفعة", fontSize = 11.sp, fontWeight = FontWeight.Bold) }

                            OutlinedButton(
                                onClick = { onPrintClientInvoice(client) },
                                border = BorderStroke(1.dp, PalestineGreen),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) { Text("🧾 كشف حساب ومطالبة PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark) }
                        }
                    }
                }
            }
        }

        if (transactions.isNotEmpty()) {
            item(key = "txs_header") {
                Text("📜 آخر حركات التخزين للغير (${transactions.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
            items(transactions.take(25), key = { it.id }) { tx ->
                val cliName = clients.firstOrNull { it.id == tx.clientId }?.clientName ?: tx.clientId
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${tx.type.arabicLabel} • $cliName", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(
                                text = "${tx.date} • " + if (tx.type == ClientStorageTxType.PAYMENT) {
                                    "دفعة: ${fmtMoney(tx.paymentAmount)}"
                                } else {
                                    "${tx.quantityPieces} قطعة (${tx.itemDescription.ifBlank { "بضائع" }})"
                                },
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }
                        OutlinedButton(
                            onClick = { onPrintTxVoucher(tx) },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) { Text("🧾 سند PDF", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark) }
                    }
                }
            }
        }
    }
}

// ============================================================================
// التبويب 4: الموازنة والمصروفات والرواتب
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FinanceAndPayrollTab(
    activeWarehouse: Warehouse?,
    finance: WarehouseFinancialSummary?,
    budgets: List<WarehouseBudgetEntry>,
    expenses: List<WarehouseExpense>,
    payrolls: List<WarehousePayrollRecord>,
    pettyCashAdvances: List<PettyCashAdvance>,
    projectNameById: Map<String, String>,
    clientNameById: Map<String, String>,
    onAddBudget: () -> Unit,
    onAddExpense: () -> Unit,
    onOpenPettyCash: () -> Unit,
    onRecordPettyCashSpend: (PettyCashAdvance) -> Unit,
    onSettlePettyCash: (PettyCashAdvance) -> Unit,
    onDeleteExpense: (String) -> Unit,
    onGeneratePayroll: (String) -> Unit,
    onUpdateDaysWorked: (String, Int) -> Unit,
    onApproveSinglePayroll: (String) -> Unit,
    onApproveAllForPeriod: (String) -> Unit,
    onExportFinancialPdf: () -> Unit
) {
    val defaultPeriod = remember { SimpleDateFormat("yyyy-MM", Locale.US).format(Date()) }
    var periodInput by remember { mutableStateOf(defaultPeriod) }
    val openPettyCash = remember(pettyCashAdvances) {
        pettyCashAdvances.firstOrNull { it.status == PettyCashStatus.OPEN }
    }
    val settledPettyCash = remember(pettyCashAdvances) {
        pettyCashAdvances.filter { it.status == PettyCashStatus.SETTLED }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (activeWarehouse == null || finance == null) {
            item { Text("يرجى اختيار أو إضافة مخزن أولاً.", fontSize = 12.sp, color = SlateTextSecondary) }
            return@LazyColumn
        }

        // بطاقة الأداء المالي للمخزن
        item(key = "finance_card") {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                border = BorderStroke(1.dp, Color(0xFF6EE7B7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("💰 بطاقة الأداء المالي للمخزن", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PalestineGreenDark)
                        OutlinedButton(
                            onClick = onExportFinancialPdf,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("🧾 كشف مالي PDF", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ClientKpiChip("الموازنة", fmtMoney(finance.approvedBudget), Color(0xFF064E3B), Modifier.weight(1f))
                        ClientKpiChip("إيراد 3PL", fmtMoney(finance.thirdPartyStorageRevenue), Color(0xFF059669), Modifier.weight(1f))
                        ClientKpiChip("المصروفات", fmtMoney(finance.totalExpenses), Color(0xFFD97706), Modifier.weight(1f))
                        ClientKpiChip("الرواتب", fmtMoney(finance.totalPayroll), PalestineRed, Modifier.weight(1f))
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFECFDF5),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("صافي الرصيد المالي للمخزن", fontSize = 11.sp, color = SlateTextSecondary)
                                Text(
                                    text = fmtMoney(finance.netWarehouseBalance),
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (finance.netWarehouseBalance >= 0.0) PalestineGreenDark else PalestineRed
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("تكلفة مناولة الوحدة", fontSize = 10.5.sp, color = SlateTextSecondary)
                                Text(
                                    text = "${fmtMoney(finance.avgHandlingCostPerUnit)} / وحدة (${finance.totalHandledUnits})",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )
                            }
                        }
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onAddBudget,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("+ تخصيص موازنة", fontSize = 11.5.sp, fontWeight = FontWeight.Bold) }

                        Button(
                            onClick = onAddExpense,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("+ تسجيل مصروف تشغيلي", fontSize = 11.5.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }

        // قسم العُهد النقدية لأمين المخزن (Petty Cash)
        item(key = "petty_cash_section") {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                border = BorderStroke(1.dp, if (openPettyCash != null) Color(0xFFF59E0B) else SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "💵 العُهد النقدية لأمين المخزن (Petty Cash)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = PalestineGreenDark,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = onOpenPettyCash,
                            enabled = openPettyCash == null,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("+ صرف عُهدة تشغيلية", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (openPettyCash != null) {
                        val ratio = if (openPettyCash.amount > 0.0) {
                            (openPettyCash.spentAmount / openPettyCash.amount).toFloat().coerceIn(0f, 1f)
                        } else 0f
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFFFFBEB),
                            border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "عُهدة مفتوحة: ${openPettyCash.keeperName} (${openPettyCash.date})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = Color(0xFF92400E)
                                    )
                                    AlertTagChip("مفتوحة", Color(0xFFFEF3C7), Color(0xFF92400E))
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    ClientKpiChip("قيمة العُهدة", fmtMoney(openPettyCash.amount), Color(0xFF064E3B), Modifier.weight(1f))
                                    ClientKpiChip("المنصرف", fmtMoney(openPettyCash.spentAmount), Color(0xFFD97706), Modifier.weight(1f))
                                    ClientKpiChip("المتبقي", fmtMoney(openPettyCash.remainingAmount), Color(0xFF059669), Modifier.weight(1f))
                                }
                                LinearProgressIndicator(
                                    progress = { ratio },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = Color(0xFFD97706),
                                    trackColor = Color(0xFFFEF3C7)
                                )
                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = { onRecordPettyCashSpend(openPettyCash) },
                                        border = BorderStroke(1.dp, Color(0xFFD97706)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
                                    ) {
                                        Text("+ صرف فاتورة من العُهدة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB45309))
                                    }
                                    Button(
                                        onClick = { onSettlePettyCash(openPettyCash) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF065F46)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
                                    ) {
                                        Text("🔒 تسوية وإقفال العُهدة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "لا توجد عُهدة نقدية مفتوحة حالياً لهذا المخزن — يمكنك صرف عُهدة تشغيلية جديدة.",
                            fontSize = 11.sp,
                            color = SlateTextSecondary
                        )
                    }

                    if (settledPettyCash.isNotEmpty()) {
                        Text("سجل العُهد المسوّاة (${settledPettyCash.size}):", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = SlateTextSecondary)
                        settledPettyCash.take(3).forEach { adv ->
                            Text(
                                text = "• ${adv.keeperName} (${adv.date} → ${adv.settledDate.ifBlank { "-" }}): مبلغ ${fmtMoney(adv.amount)} | منصرف ${fmtMoney(adv.spentAmount)} | مرتجع ${fmtMoney(adv.remainingAmount)}",
                                fontSize = 10.5.sp,
                                color = SlateTextSecondary
                            )
                        }
                    }
                }
            }
        }

        // قسم إصدار واعتماد مسير رواتب العاملين
        item(key = "payroll_generator") {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("👥 إصدار واعتماد مسير رواتب العاملين", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PalestineGreenDark)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = periodInput,
                            onValueChange = { periodInput = it },
                            label = { Text("الفترة (مثال: 2026-11)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = { onGeneratePayroll(periodInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                            shape = RoundedCornerShape(10.dp)
                        ) { Text("إصدار المسير", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                    if (payrolls.any { !it.isPaid && it.periodLabel.equals(periodInput.trim(), ignoreCase = true) }) {
                        Button(
                            onClick = { onApproveAllForPeriod(periodInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("✓ اعتماد وصرف كافة رواتب الفترة $periodInput (خصم من الموازنة)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (payrolls.isNotEmpty()) {
            item(key = "payrolls_list_title") {
                Text("📑 كشف الرواتب (${payrolls.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            items(payrolls.take(25), key = { it.id }) { pay ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, if (pay.isPaid) Color(0xFF6EE7B7) else SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${pay.workerName} (${pay.role})", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            Text(
                                text = "الفترة: ${pay.periodLabel} • ${pay.payType.arabicLabel} • المستحق: ${fmtMoney(pay.amount)}",
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                            if (pay.payType == WorkerPayType.DAILY && !pay.isPaid) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("أيام العمل: ${pay.daysWorked}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    TextButton(onClick = { onUpdateDaysWorked(pay.id, (pay.daysWorked - 1).coerceAtLeast(1)) }) { Text("−", fontWeight = FontWeight.Bold) }
                                    TextButton(onClick = { onUpdateDaysWorked(pay.id, pay.daysWorked + 1) }) { Text("+", fontWeight = FontWeight.Bold) }
                                }
                            }
                        }
                        if (pay.isPaid) {
                            AlertTagChip("✓ مصروف (${pay.paidDate})", Color(0xFFDCFCE7), Color(0xFF166534))
                        } else {
                            Button(
                                onClick = { onApproveSinglePayroll(pay.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) { Text("اعتماد وصرف", fontSize = 10.5.sp, fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }

        if (expenses.isNotEmpty()) {
            item(key = "expenses_title") {
                Text("🧾 المصروفات التشغيلية (${expenses.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            }
            items(expenses.take(20), key = { it.id }) { exp ->
                val targetLabel = remember(exp.allocatedTarget, projectNameById, clientNameById) {
                    resolveAllocatedTargetLabel(exp.allocatedTarget, projectNameById, clientNameById)
                }
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text("${exp.category} • ${fmtMoney(exp.amount)}", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            Text("${exp.date} • فاتورة: ${exp.invoiceNo.ifBlank { "-" }} • ${exp.notes}", fontSize = 10.5.sp, color = SlateTextSecondary)
                            AlertTagChip(
                                text = "📌 $targetLabel",
                                bg = Color(0xFFE0F2FE),
                                fg = Color(0xFF075985)
                            )
                        }
                        TextButton(onClick = { onDeleteExpense(exp.id) }) {
                            Text("حذف", fontSize = 11.sp, color = PalestineRed)
                        }
                    }
                }
            }
        }

        if (budgets.isNotEmpty()) {
            item(key = "budgets_title") {
                Text("🏦 سجل تخصيصات الموازنة (${budgets.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            }
            items(budgets.take(10), key = { it.id }) { b ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("+ ${fmtMoney(b.allocatedAmount)} • ${b.fundingSource.ifBlank { "موازنة تشغيلية" }}", fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = PalestineGreenDark)
                        Text("${b.date} • ${b.notes}", fontSize = 10.5.sp, color = SlateTextSecondary)
                    }
                }
            }
        }
    }
}

// ============================================================================
// التبويب 5: الجرد الأعمى (إخفاء الرصيد الدفتري تماماً + SHA-256)
// ============================================================================

@Composable
private fun BlindAuditTab(
    activeWarehouse: Warehouse?,
    items: List<WarehouseItem>,
    majorInputs: Map<String, String>,
    minorInputs: Map<String, String>,
    reason: String,
    latestReport: BlindAuditBatchReport?,
    onMajorChange: (String, String) -> Unit,
    onMinorChange: (String, String) -> Unit,
    onReasonChange: (String) -> Unit,
    onSubmitBlindAudit: () -> Unit,
    onExportAuditPdf: (BlindAuditBatchReport) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (activeWarehouse == null) {
            item { Text("يرجى اختيار أو إضافة مخزن أولاً.", fontSize = 12.sp, color = SlateTextSecondary) }
            return@LazyColumn
        }

        item(key = "blind_banner") {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("🕵️ وضع الجرد الأعمى الصارم (Blind Count Audit)", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = Color(0xFF92400E))
                    Text(
                        text = "تم إخفاء الرصيد الدفتري تماماً لضمان نزاهة الجرد الميداني. أدخل الكميات الفعلية الموجودة على الأرفف ثم اضغط «اعتماد الجرد وكشف الفروقات» لتسوية الرصيد وتوثيق المحضر ببصمة SHA-256.",
                        fontSize = 11.sp,
                        color = Color(0xFF78350F)
                    )
                }
            }
        }

        if (items.isEmpty()) {
            item { Text("لا توجد أصناف في هذا المخزن لإجراء الجرد الأعمى.", fontSize = 12.sp, color = SlateTextSecondary) }
        } else {
            items(items, key = { "blind_${it.id}" }) { item ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(item.name, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = SlateTextPrimary)
                        Text(
                            text = "الوحدات: ${item.majorUnitName} (= ${item.safeConversionFactor} ${item.minorUnitName}) • الرصيد الدفتري: [مخفي أثناء الجرد]",
                            fontSize = 10.5.sp,
                            color = SlateTextSecondary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = majorInputs[item.id] ?: "",
                                onValueChange = { onMajorChange(item.id, it.filter { c -> c.isDigit() }) },
                                label = { Text("العد الفعلي (${item.majorUnitName})") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = minorInputs[item.id] ?: "",
                                onValueChange = { onMinorChange(item.id, it.filter { c -> c.isDigit() }) },
                                label = { Text("العد الفعلي (${item.minorUnitName})") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            item(key = "blind_submit") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = reason,
                        onValueChange = onReasonChange,
                        label = { Text("ملاحظات محضر الجرد / سبب التسوية") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = onSubmitBlindAudit,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF064E3B)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("🛡️ اعتماد الجرد وكشف الفروقات (توثيق SHA-256)", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    }
                }
            }
        }

        // عرض نتائج الفروقات بعد الاعتماد + بصمة SHA-256 + زر PDF
        if (latestReport != null) {
            item(key = "blind_result_card") {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                    border = BorderStroke(1.2.dp, Color(0xFF059669)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("✅ نتيجة الجرد الأعمى المعتمدة", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF065F46))
                            OutlinedButton(
                                onClick = { onExportAuditPdf(latestReport) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("🧾 محضر الجرد PDF", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                            }
                        }

                        if (latestReport.auditEntryHash.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White,
                                border = BorderStroke(1.dp, Color(0xFFA7F3D0)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "🔐 بصمة التوثيق (SHA-256):\n${latestReport.auditEntryHash}",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF064E3B),
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                        }

                        latestReport.results.forEach { res ->
                            val statusText = when {
                                res.varianceMinorQty == 0L -> "مطابق"
                                res.varianceMinorQty < 0L -> "عجز (${res.varianceMinorQty})"
                                else -> "زيادة (+${res.varianceMinorQty})"
                            }
                            val statusColor = when {
                                res.varianceMinorQty == 0L -> Color(0xFF059669)
                                res.varianceMinorQty < 0L -> PalestineRed
                                else -> Color(0xFF0284C7)
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(res.itemName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("دفتري: ${res.systemMinorQty}  |  فعلي: ${res.countedMinorQty}", fontSize = 11.sp, color = SlateTextSecondary)
                                }
                                Text(statusText, fontWeight = FontWeight.Bold, fontSize = 11.5.sp, color = statusColor)
                            }
                            HorizontalDivider(color = Color(0xFFA7F3D0))
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// مكونات مساعدة داخلية
// ============================================================================

@Composable
private fun HeaderKpiMini(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = Color.White.copy(alpha = 0.14f),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = label,
                color = Color.White.copy(alpha = 0.82f),
                fontSize = 9.5.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ClientKpiChip(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFFF8FAFC),
        border = BorderStroke(1.dp, SlateBorder),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = color, maxLines = 1)
            Text(label, fontSize = 9.sp, color = SlateTextSecondary, maxLines = 1)
        }
    }
}

@Composable
private fun AlertTagChip(text: String, bg: Color, fg: Color) {
    Surface(shape = RoundedCornerShape(6.dp), color = bg) {
        Text(
            text = text,
            color = fg,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
        )
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("$label:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = SlateTextSecondary)
        Text(value, fontSize = 11.5.sp, color = SlateTextPrimary, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun EmptyWarehousePromptCard(canAddNewWarehouse: Boolean, onAddWarehouse: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = PalestineWhite),
        border = BorderStroke(1.dp, SlateBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("🏭", fontSize = 36.sp)
            Text("لا توجد مخازن متاحة حالياً", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (canAddNewWarehouse) {
                Button(
                    onClick = onAddWarehouse,
                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                ) {
                    Text("+ إضافة أول مخزن", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PermissionLockedPlaceholder(message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
            border = BorderStroke(1.dp, Color(0xFFFCA5A5))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("🔒", fontSize = 32.sp)
                Text(message, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PalestineRed)
            }
        }
    }
}

private fun resolveAllocatedTargetLabel(
    allocatedTarget: String,
    projectNameById: Map<String, String>,
    clientNameById: Map<String, String>
): String {
    val clean = allocatedTarget.trim()
    return when {
        clean.startsWith("PROJECT:", ignoreCase = true) -> {
            val pid = clean.substringAfter(":")
            "مشروع: ${projectNameById[pid] ?: "#$pid"}"
        }
        clean.startsWith("CLIENT:", ignoreCase = true) -> {
            val cid = clean.substringAfter(":")
            "عميل 3PL: ${clientNameById[cid] ?: cid}"
        }
        else -> "تحميل عام (تشغيلي)"
    }
}

private fun fmtMoney(amount: Double): String = String.format(Locale.US, "%.2f", amount)

private fun checkExpiryAlert(expiryDateStr: String): String? {
    val clean = expiryDateStr.trim()
    if (clean.isBlank()) return null
    val parsed = runCatching {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(clean)
    }.getOrNull() ?: return null
    val diffDays = TimeUnit.MILLISECONDS.toDays(parsed.time - System.currentTimeMillis())
    return when {
        diffDays < 0L -> "منتهي الصلاحية ($clean)"
        diffDays <= 30L -> "قريب الانتهاء: متبقي $diffDays يوم ($clean)"
        else -> null
    }
}

// ============================================================================
// نوافذ الميزات المتقدمة (حجر صحي/إتلاف، تأكيد شحنة، تبريد، عُهد نقدية، تحميل تكاليف)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun QuarantineOrDisposeDialog(
    item: WarehouseItem,
    batches: List<StockBatch>,
    onDismiss: () -> Unit,
    onSubmit: (batchNo: String, minorQty: Long, reason: String, isDisposed: Boolean, genPdf: Boolean) -> Unit
) {
    var isDisposed by remember { mutableStateOf(false) }
    var selectedBatchNo by remember { mutableStateOf(batches.firstOrNull { !it.isQuarantined }?.batchNo ?: "") }
    var qtyText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var genPdf by remember { mutableStateOf(true) }

    val selectableBatches = remember(batches, isDisposed) {
        if (isDisposed) batches else batches.filter { !it.isQuarantined }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("⚠️ حجر صحي / محضر إتلاف — ${item.name}", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = !isDisposed,
                        onClick = { isDisposed = false },
                        label = { Text("نقل للحجر الصحي", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = isDisposed,
                        onClick = { isDisposed = true },
                        label = { Text("محضر إتلاف نهائي", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (selectableBatches.isNotEmpty()) {
                    Text("اختر التشغيلة (أو اتركه تلقائياً لـ FEFO):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(
                            selected = selectedBatchNo.isBlank(),
                            onClick = { selectedBatchNo = "" },
                            label = { Text("تلقائي FEFO", fontSize = 10.5.sp) }
                        )
                        selectableBatches.forEach { b ->
                            FilterChip(
                                selected = selectedBatchNo.equals(b.batchNo, ignoreCase = true),
                                onClick = { selectedBatchNo = b.batchNo },
                                label = { Text("${b.batchNo} (${b.remainingMinorQty} • ${b.zoneName})", fontSize = 10.5.sp) }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it.filter { c -> c.isDigit() } },
                    label = { Text("الكمية بالوحدة الصغرى (${item.minorUnitName})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("سبب النقل للحجر الصحي / الإتلاف (إلزامي)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = genPdf, onCheckedChange = { genPdf = it })
                    Text("طباعة وحفظ محضر PDF تلقائياً", fontSize = 11.5.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = qtyText.toLongOrNull() ?: 0L
                    if (qty > 0L && reason.isNotBlank()) {
                        onSubmit(selectedBatchNo, qty, reason, isDisposed, genPdf)
                    }
                },
                enabled = (qtyText.toLongOrNull() ?: 0L) > 0L && reason.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = if (isDisposed) PalestineRed else Color(0xFFD97706))
            ) {
                Text(if (isDisposed) "اعتماد محضر الإتلاف" else "نقل للحجر الصحي", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun ConfirmShipmentArrivalDialog(
    shipment: InTransitShipment,
    fromWarehouseName: String,
    toWarehouseName: String,
    onDismiss: () -> Unit,
    onConfirm: (actualReceivedMinorQty: Long, notes: String) -> Unit
) {
    var receivedText by remember { mutableStateOf(shipment.sentMinorQty.toString()) }
    var notes by remember { mutableStateOf("") }
    val parsedReceived = receivedText.toLongOrNull() ?: -1L
    val isValid = parsedReceived in 0L..shipment.sentMinorQty
    val shortagePreview = if (isValid) (shipment.sentMinorQty - parsedReceived) else 0L

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("✅ تأكيد الاستلام الفعلي للشحنة", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الصنف: ${shipment.itemName}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("من: $fromWarehouseName ⬅ إلى: $toWarehouseName", fontSize = 11.5.sp, color = SlateTextSecondary)
                Text("الكمية المرسلة: ${shipment.sentMinorQty} ${shipment.minorUnitName} • تصريح: ${shipment.gatePassToken}", fontSize = 11.5.sp, color = PalestineGreenDark)

                OutlinedTextField(
                    value = receivedText,
                    onValueChange = { receivedText = it.filter { c -> c.isDigit() } },
                    label = { Text("الكمية المستلمة فعلياً (${shipment.minorUnitName})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (isValid && shortagePreview > 0L) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEF2F2),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "⚠️ يوجد عجز قدره $shortagePreview ${shipment.minorUnitName} — سيتم إصدار «محضر عجز نقل» مختوم بـ SHA-256 تلقائياً في سجل الرقابة.",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PalestineRed,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات الاستلام أو سبب العجز (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (isValid) onConfirm(parsedReceived, notes) },
                enabled = isValid,
                colors = ButtonDefaults.buttonColors(containerColor = if (shortagePreview > 0L) PalestineRed else PalestineGreen)
            ) {
                Text(if (shortagePreview > 0L) "تأكيد وإصدار محضر عجز" else "تأكيد الاستلام الكامل", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun AddColdChainLogDialog(
    warehouse: Warehouse,
    onDismiss: () -> Unit,
    onSave: (temperatureCelsius: Double, generatorHours: Double, notes: String) -> Unit
) {
    var tempText by remember { mutableStateOf("") }
    var genHoursText by remember { mutableStateOf("0") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("❄️ تسجيل قراءة التبريد والمولد — ${warehouse.name}", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = tempText,
                    onValueChange = { tempText = it.filter { c -> c.isDigit() || c == '.' || c == '-' } },
                    label = { Text("درجة الحرارة (°C)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = genHoursText,
                    onValueChange = { genHoursText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("ساعات تشغيل المولد") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات فنية (السولار / الصيانة)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val temp = tempText.toDoubleOrNull()
                    val hours = genHoursText.toDoubleOrNull() ?: 0.0
                    if (temp != null && hours >= 0.0) {
                        onSave(temp, hours, notes)
                    }
                },
                enabled = tempText.toDoubleOrNull() != null,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Text("حفظ القراءة", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun OpenPettyCashDialog(
    defaultKeeperName: String,
    onDismiss: () -> Unit,
    onSave: (keeperName: String, amount: Double, notes: String) -> Unit
) {
    var keeperName by remember { mutableStateOf(defaultKeeperName) }
    var amountText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("💵 صرف عُهدة تشغيلية جديدة", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = keeperName,
                    onValueChange = { keeperName = it },
                    label = { Text("اسم أمين المخزن المستلم للعُهدة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("مبلغ العُهدة النقدية") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("الغرض / ملاحظات (اختياري)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt > 0.0) onSave(keeperName, amt, notes)
                },
                enabled = (amountText.toDoubleOrNull() ?: 0.0) > 0.0,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) { Text("صرف العُهدة", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ExpenseAllocationSelector(
    projects: List<ProjectEntity>,
    clients: List<StorageClient>,
    selectedTarget: String,
    onSelectTarget: (String) -> Unit
) {
    val mode = remember(selectedTarget) {
        when {
            selectedTarget.startsWith("PROJECT:", ignoreCase = true) -> "PROJECT"
            selectedTarget.startsWith("CLIENT:", ignoreCase = true) -> "CLIENT"
            else -> "GENERAL"
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("تحميل المصروف على (مشروع / عميل / عام):", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(
                selected = mode == "GENERAL",
                onClick = { onSelectTarget("GENERAL") },
                label = { Text("عام", fontSize = 11.sp) },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = mode == "PROJECT",
                onClick = {
                    val firstProj = projects.firstOrNull()
                    onSelectTarget(if (firstProj != null) "PROJECT:${firstProj.projectID}" else "GENERAL")
                },
                enabled = projects.isNotEmpty(),
                label = { Text("مشروع", fontSize = 11.sp) },
                modifier = Modifier.weight(1f)
            )
            FilterChip(
                selected = mode == "CLIENT",
                onClick = {
                    val firstCli = clients.firstOrNull()
                    onSelectTarget(if (firstCli != null) "CLIENT:${firstCli.id}" else "GENERAL")
                },
                enabled = clients.isNotEmpty(),
                label = { Text("عميل 3PL", fontSize = 11.sp) },
                modifier = Modifier.weight(1f)
            )
        }
        if (mode == "PROJECT" && projects.isNotEmpty()) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                projects.take(8).forEach { p ->
                    val tag = "PROJECT:${p.projectID}"
                    FilterChip(
                        selected = selectedTarget == tag,
                        onClick = { onSelectTarget(tag) },
                        label = { Text(p.projectName, fontSize = 10.5.sp, maxLines = 1) }
                    )
                }
            }
        } else if (mode == "CLIENT" && clients.isNotEmpty()) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                clients.take(8).forEach { c ->
                    val tag = "CLIENT:${c.id}"
                    FilterChip(
                        selected = selectedTarget == tag,
                        onClick = { onSelectTarget(tag) },
                        label = { Text(c.clientName, fontSize = 10.5.sp, maxLines = 1) }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddExpenseWithAllocationDialog(
    projects: List<ProjectEntity>,
    clients: List<StorageClient>,
    onDismiss: () -> Unit,
    onSave: (category: String, amount: Double, invoiceNo: String, allocatedTarget: String, notes: String) -> Unit
) {
    var category by remember { mutableStateOf(WarehouseConstants.EXPENSE_CATEGORIES.first()) }
    var amountText by remember { mutableStateOf("") }
    var invoiceNo by remember { mutableStateOf("") }
    var allocatedTarget by remember { mutableStateOf("GENERAL") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🧾 تسجيل مصروف تشغيلي وتحميل التكلفة", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("بند المصروف:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    WarehouseConstants.EXPENSE_CATEGORIES.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 10.5.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("قيمة المصروف") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = invoiceNo,
                    onValueChange = { invoiceNo = it },
                    label = { Text("رقم الفاتورة / الإيصال") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                ExpenseAllocationSelector(
                    projects = projects,
                    clients = clients,
                    selectedTarget = allocatedTarget,
                    onSelectTarget = { allocatedTarget = it }
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt > 0.0) onSave(category, amt, invoiceNo, allocatedTarget, notes)
                },
                enabled = (amountText.toDoubleOrNull() ?: 0.0) > 0.0,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
            ) { Text("حفظ المصروف", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PettyCashSpendDialog(
    advance: PettyCashAdvance,
    projects: List<ProjectEntity>,
    clients: List<StorageClient>,
    onDismiss: () -> Unit,
    onSave: (amount: Double, category: String, invoiceNo: String, allocatedTarget: String, notes: String) -> Unit
) {
    var category by remember { mutableStateOf(WarehouseConstants.EXPENSE_CATEGORIES.first()) }
    var amountText by remember { mutableStateOf("") }
    var invoiceNo by remember { mutableStateOf("") }
    var allocatedTarget by remember { mutableStateOf("GENERAL") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("💵 صرف فاتورة من العُهدة المفتوحة", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("الرصيد المتبقي بالعُهدة: ${fmtMoney(advance.remainingAmount)}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PalestineGreenDark)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    WarehouseConstants.EXPENSE_CATEGORIES.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 10.5.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text("مبلغ الفاتورة") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = invoiceNo,
                    onValueChange = { invoiceNo = it },
                    label = { Text("رقم الفاتورة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                ExpenseAllocationSelector(
                    projects = projects,
                    clients = clients,
                    selectedTarget = allocatedTarget,
                    onSelectTarget = { allocatedTarget = it }
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("بيان الصرف") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt > 0.0) onSave(amt, category, invoiceNo, allocatedTarget, notes)
                },
                enabled = (amountText.toDoubleOrNull() ?: 0.0) > 0.0,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706))
            ) { Text("خصم من العُهدة", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun SettlePettyCashDialog(
    advance: PettyCashAdvance,
    onDismiss: () -> Unit,
    onConfirm: (notes: String) -> Unit
) {
    var notes by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("🔒 تسوية وإقفال العُهدة النقدية", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("أمين المخزن: ${advance.keeperName}", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                Text("إجمالي العُهدة: ${fmtMoney(advance.amount)} • المنصرف: ${fmtMoney(advance.spentAmount)} • المتبقي للإرجاع: ${fmtMoney(advance.remainingAmount)}", fontSize = 11.5.sp, color = PalestineGreenDark)
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات التسوية والإقفال") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(notes) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF065F46))
            ) { Text("تأكيد التسوية والإقفال", fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun SavedCsvConfirmDialog(
    title: String,
    result: SavedExportResult,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("✅ تم حفظ بطاقة الصنف بنجاح", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PalestineGreenDark) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                Text("اسم الملف: ${result.fileName}", fontSize = 11.5.sp, color = SlateTextPrimary)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFECFDF5),
                    border = BorderStroke(1.dp, Color(0xFFA7F3D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "مكان الحفظ:\n${result.humanReadablePath}",
                        fontSize = 11.sp,
                        color = Color(0xFF065F46),
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) { Text("تم", fontWeight = FontWeight.Bold) }
        }
    )
}
