package com.humanitarian.aidmanagement.security

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.security.MessageDigest
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

sealed class LicenseStatus {
    data class Valid(
        val hwId: String,
        val expiryDate: String,
        val remainingDays: Long
    ) : LicenseStatus()

    object NotActivated : LicenseStatus()
    data class Expired(val expiryDate: String) : LicenseStatus()
    data class HardwareMismatch(val expectedHwId: String, val actualHwId: String) : LicenseStatus()
    data class Invalid(val reason: String) : LicenseStatus()
}

data class LicenseValidationResult(
    val isValid: Boolean,
    val status: LicenseStatus,
    val message: String
)

/**
 * مدير منظومة الترخيص العضوي المرتبط بالعتاد (Hardware-Bound DRM).
 * يعمل كغلاف حماية خارجي (Wrapper) مستقل كلياً عن قواعد البيانات والصلاحيات.
 * محصن بالكامل بكتل try-catch لمنع أي انهيار عند الإقلاع، ويستخدم applicationContext حصراً.
 */
object LicenseManager {

    private const val SECRET_KEY = "MySuperSecretKey123!"
    private const val PREFS_NAME_ENCRYPTED = "drm_license_secure_prefs"
    private const val PREFS_NAME_FALLBACK = "drm_license_fallback_prefs"
    private const val KEY_LICENSE_TOKEN = "hardware_bound_license_token"

    private val _licenseStatusFlow = MutableStateFlow<LicenseStatus>(LicenseStatus.NotActivated)
    val licenseStatusFlow: StateFlow<LicenseStatus> = _licenseStatusFlow.asStateFlow()

    fun refreshStatus(context: Context): LicenseStatus {
        return try {
            val appContext = context.applicationContext ?: context
            isLicenseValid(appContext)
            _licenseStatusFlow.value
        } catch (_: Throwable) {
            _licenseStatusFlow.value = LicenseStatus.NotActivated
            LicenseStatus.NotActivated
        }
    }

    fun isLicenseValid(context: Context): Boolean {
        return try {
            val appContext = context.applicationContext ?: context
            val storedToken = try {
                getPrefs(appContext)?.getString(KEY_LICENSE_TOKEN, null)?.trim()
            } catch (_: Throwable) {
                try {
                    appContext.getSharedPreferences(PREFS_NAME_FALLBACK, Context.MODE_PRIVATE)
                        .getString(KEY_LICENSE_TOKEN, null)?.trim()
                } catch (_: Throwable) {
                    null
                }
            }

            if (storedToken.isNullOrBlank()) {
                _licenseStatusFlow.value = LicenseStatus.NotActivated
                return false
            }

            val result = decryptAndValidate(appContext, storedToken)
            _licenseStatusFlow.value = result.status
            result.isValid
        } catch (_: Throwable) {
            _licenseStatusFlow.value = LicenseStatus.NotActivated
            false
        }
    }

    fun activateLicense(context: Context, rawLicenseCode: String): LicenseValidationResult {
        return try {
            val appContext = context.applicationContext ?: context
            val cleaned = rawLicenseCode.replace("\\s+".toRegex(), "").trim()
            val result = decryptAndValidate(appContext, cleaned)
            if (result.isValid) {
                try {
                    getPrefs(appContext)?.edit()?.putString(KEY_LICENSE_TOKEN, cleaned)?.apply()
                } catch (_: Throwable) {
                    try {
                        appContext.getSharedPreferences(PREFS_NAME_FALLBACK, Context.MODE_PRIVATE)
                            .edit().putString(KEY_LICENSE_TOKEN, cleaned).apply()
                    } catch (_: Throwable) {
                    }
                }
                _licenseStatusFlow.value = result.status
            }
            result
        } catch (_: Throwable) {
            val msg = "تعذر تفعيل الترخيص، يرجى المحاولة مرة أخرى."
            LicenseValidationResult(false, LicenseStatus.Invalid(msg), msg)
        }
    }

    fun clearLicense(context: Context) {
        try {
            val appContext = context.applicationContext ?: context
            try {
                getPrefs(appContext)?.edit()?.remove(KEY_LICENSE_TOKEN)?.apply()
            } catch (_: Throwable) {
            }
            try {
                appContext.getSharedPreferences(PREFS_NAME_FALLBACK, Context.MODE_PRIVATE)
                    .edit().remove(KEY_LICENSE_TOKEN).apply()
            } catch (_: Throwable) {
            }
            _licenseStatusFlow.value = LicenseStatus.NotActivated
        } catch (_: Throwable) {
            _licenseStatusFlow.value = LicenseStatus.NotActivated
        }
    }

    fun decryptAndValidate(context: Context, base64Code: String): LicenseValidationResult {
        return try {
            val appContext = context.applicationContext ?: context
            val cleaned = base64Code.replace("\\s+".toRegex(), "").trim()
            if (cleaned.isBlank()) {
                return LicenseValidationResult(
                    isValid = false,
                    status = LicenseStatus.Invalid("يرجى إدخال كود التفعيل أولاً."),
                    message = "يرجى إدخال كود التفعيل أولاً."
                )
            }

            val jsonText = try {
                decryptPayload(cleaned)
            } catch (_: Throwable) {
                return LicenseValidationResult(
                    isValid = false,
                    status = LicenseStatus.Invalid("كود التفعيل غير صالح أو تالف أو تم تعديله."),
                    message = "كود التفعيل غير صالح أو تالف أو تم تعديله."
                )
            }

            val json = JSONObject(jsonText)
            val tokenHwId = json.optString("hw_id", "").trim()
            val tokenExpiryRaw = json.optString("expiry_date", "")
                .ifBlank { json.optString("expiry", "") }
                .trim()

            if (tokenHwId.isBlank() || tokenExpiryRaw.isBlank()) {
                val msg = "بيانات الترخيص ناقصة (رقم الجهاز أو تاريخ الصلاحية مفقود)."
                return LicenseValidationResult(false, LicenseStatus.Invalid(msg), msg)
            }

            val currentHwId = DeviceUtils.getHardwareId(appContext)
            if (!tokenHwId.equals(currentHwId, ignoreCase = true)) {
                val msg = "هذا الترخيص مخصص لجهاز آخر ولا يطابق بصمة هذا الجهاز."
                return LicenseValidationResult(
                    isValid = false,
                    status = LicenseStatus.HardwareMismatch(tokenHwId, currentHwId),
                    message = msg
                )
            }

            val expiryDate = parseExpiryDate(tokenExpiryRaw)
                ?: return LicenseValidationResult(
                    isValid = false,
                    status = LicenseStatus.Invalid("صيغة تاريخ الانتهاء غير صالحة في الترخيص."),
                    message = "صيغة تاريخ الانتهاء غير صالحة في الترخيص."
                )

            val today = LocalDate.now()
            if (today.isAfter(expiryDate)) {
                val msg = "انتهت صلاحية الترخيص بتاريخ $expiryDate. يرجى التواصل مع الإدارة لتجديد التفعيل."
                return LicenseValidationResult(
                    isValid = false,
                    status = LicenseStatus.Expired(expiryDate.toString()),
                    message = msg
                )
            }

            val remainingDays = ChronoUnit.DAYS.between(today, expiryDate).coerceAtLeast(0L)
            val validStatus = LicenseStatus.Valid(
                hwId = currentHwId,
                expiryDate = expiryDate.toString(),
                remainingDays = remainingDays
            )
            LicenseValidationResult(
                isValid = true,
                status = validStatus,
                message = "تم تفعيل الترخيص بنجاح. صالح حتى $expiryDate."
            )
        } catch (_: Throwable) {
            val msg = "تعذر قراءة محتوى الترخيص المشفر."
            LicenseValidationResult(false, LicenseStatus.Invalid(msg), msg)
        }
    }

    /**
     * يدعم فك تشفير صيغتين متوافقتين مع CryptoJS:
     * 1) صيغة IV (16 بايت) + النص المشفر باستخدام مفتاح SHA-256(SECRET_KEY)
     * 2) صيغة CryptoJS الافتراضية المملحة (Salted__ + Salt 8 بايت) عبر EVP_BytesToKey
     */
    private fun decryptPayload(base64Input: String): String {
        val rawBytes = Base64.decode(base64Input, Base64.DEFAULT)
        if (rawBytes.size < 32) {
            throw IllegalArgumentException("Ciphertext too short")
        }

        val saltedPrefix = "Salted__".toByteArray(Charsets.US_ASCII)
        val isOpenSslSalted = rawBytes.size > 16 &&
            rawBytes.copyOfRange(0, 8).contentEquals(saltedPrefix)

        val plainBytes = if (isOpenSslSalted) {
            val salt = rawBytes.copyOfRange(8, 16)
            val cipherBytes = rawBytes.copyOfRange(16, rawBytes.size)
            val (keyBytes, ivBytes) = evpBytesToKeyMd5(
                password = SECRET_KEY.toByteArray(Charsets.UTF_8),
                salt = salt,
                keyLen = 32,
                ivLen = 16
            )
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                SecretKeySpec(keyBytes, "AES"),
                IvParameterSpec(ivBytes)
            )
            cipher.doFinal(cipherBytes)
        } else {
            val ivBytes = rawBytes.copyOfRange(0, 16)
            val cipherBytes = rawBytes.copyOfRange(16, rawBytes.size)
            val keyBytes = MessageDigest.getInstance("SHA-256")
                .digest(SECRET_KEY.toByteArray(Charsets.UTF_8))
            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
            cipher.init(
                Cipher.DECRYPT_MODE,
                SecretKeySpec(keyBytes, "AES"),
                IvParameterSpec(ivBytes)
            )
            cipher.doFinal(cipherBytes)
        }

        return String(plainBytes, Charsets.UTF_8)
    }

    private fun evpBytesToKeyMd5(
        password: ByteArray,
        salt: ByteArray,
        keyLen: Int,
        ivLen: Int
    ): Pair<ByteArray, ByteArray> {
        val totalLen = keyLen + ivLen
        val derived = ByteArray(totalLen)
        var offset = 0
        var prevBlock = ByteArray(0)
        val md5 = MessageDigest.getInstance("MD5")

        while (offset < totalLen) {
            md5.reset()
            if (prevBlock.isNotEmpty()) {
                md5.update(prevBlock)
            }
            md5.update(password)
            md5.update(salt)
            prevBlock = md5.digest()
            val copyLen = minOf(prevBlock.size, totalLen - offset)
            System.arraycopy(prevBlock, 0, derived, offset, copyLen)
            offset += copyLen
        }

        val key = derived.copyOfRange(0, keyLen)
        val iv = derived.copyOfRange(keyLen, totalLen)
        return Pair(key, iv)
    }

    private fun parseExpiryDate(raw: String): LocalDate? {
        return try {
            val normalized = raw.trim().take(10).replace('/', '-')
            val formatters = listOf(
                DateTimeFormatter.ISO_LOCAL_DATE,
                DateTimeFormatter.ofPattern("dd-MM-yyyy")
            )
            for (formatter in formatters) {
                try {
                    return LocalDate.parse(normalized, formatter)
                } catch (_: Throwable) {
                }
            }
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun getPrefs(context: Context): SharedPreferences? {
        val appContext = context.applicationContext ?: context
        return try {
            val masterKey = MasterKey.Builder(appContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                appContext,
                PREFS_NAME_ENCRYPTED,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (_: Throwable) {
            try {
                appContext.getSharedPreferences(PREFS_NAME_FALLBACK, Context.MODE_PRIVATE)
            } catch (_: Throwable) {
                null
            }
        }
    }
}
