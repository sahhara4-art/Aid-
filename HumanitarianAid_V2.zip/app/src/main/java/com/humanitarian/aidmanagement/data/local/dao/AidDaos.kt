package com.humanitarian.aidmanagement.data.local.dao

import androidx.room.*
import androidx.sqlite.db.SupportSQLiteQuery
import com.humanitarian.aidmanagement.data.local.entities.*
import kotlinx.coroutines.flow.Flow


@Dao
interface UserDao {
    @Query("SELECT * FROM tbl_Users WHERE UserName = :userName LIMIT 1")
    suspend fun getUserByUsername(userName: String): UserEntity?

    @Query("SELECT * FROM tbl_Users WHERE UserID = :userId LIMIT 1")
    suspend fun getUserById(userId: Int): UserEntity?

    @Query("SELECT * FROM tbl_Users")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM tbl_Users")
    suspend fun getAllUsersSync(): List<UserEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE tbl_Users SET FailedAttempts = FailedAttempts + 1 WHERE UserName = :userName")
    suspend fun incrementFailedAttempts(userName: String)

    @Query("UPDATE tbl_Users SET FailedAttempts = 0, LastLogin = :timestamp, LockedUntil = NULL WHERE UserID = :userId")
    suspend fun resetFailedAttempts(userId: Int, timestamp: Long)

    @Query("UPDATE tbl_Users SET FailedAttempts = 0, LastLogin = :timestamp, LockedUntil = NULL WHERE UserID = :userId")
    suspend fun resetLockoutAndSetLogin(userId: Int, timestamp: Long)

    @Query("UPDATE tbl_Users SET LockedUntil = :lockedUntil WHERE UserName = :userName")
    suspend fun lockUser(userName: String, lockedUntil: Long)

    @Query("SELECT LocalityID FROM tbl_UserLocalities WHERE UserID = :userId")
    suspend fun getUserLocalityIds(userId: Int): List<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserLocality(userLocality: UserLocalityEntity)

    @Query("SELECT * FROM tbl_Roles WHERE RoleID = :roleId LIMIT 1")
    suspend fun getRoleById(roleId: Int): RoleEntity?

    @Query("SELECT * FROM tbl_Roles")
    fun getAllRoles(): Flow<List<RoleEntity>>

    @Query("SELECT * FROM tbl_Roles")
    suspend fun getAllRolesSync(): List<RoleEntity>

    @Query("DELETE FROM tbl_Users WHERE UserID = :userId")
    suspend fun deleteUserById(userId: Int)

    @Query("UPDATE tbl_Users SET IsActive = :isActive WHERE UserID = :userId")
    suspend fun setUserActive(userId: Int, isActive: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRole(role: RoleEntity)

    // صلاحيات المستخدم التفصيلية (tbl_User_Permissions)
    @Query("SELECT * FROM tbl_User_Permissions WHERE UserID = :userId")
    fun getUserPermissions(userId: Int): Flow<List<UserPermissionEntity>>

    @Query("SELECT * FROM tbl_User_Permissions WHERE UserID = :userId")
    suspend fun getUserPermissionsSync(userId: Int): List<UserPermissionEntity>

    @Query("SELECT PermissionKey FROM tbl_User_Permissions WHERE UserID = :userId AND IsGranted = 1")
    suspend fun getGrantedPermissionKeys(userId: Int): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPermissions(permissions: List<UserPermissionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPermission(permission: UserPermissionEntity)

    @Query("DELETE FROM tbl_User_Permissions WHERE UserID = :userId")
    suspend fun clearUserPermissions(userId: Int)
}

@Dao
interface FamilyDao {
    @Query("SELECT * FROM families ORDER BY createdDate DESC")
    fun getAllFamilies(): Flow<List<FamilyEntity>>

    @Query("SELECT * FROM families ORDER BY createdDate DESC")
    suspend fun getAllFamiliesSync(): List<FamilyEntity>

    @Query("SELECT * FROM families WHERE localityID IN (:localityIds) ORDER BY createdDate DESC")
    fun getFamiliesByLocalities(localityIds: List<Int>): Flow<List<FamilyEntity>>

    @Query("SELECT * FROM families WHERE familyID = :id LIMIT 1")
    suspend fun getFamilyById(id: Long): FamilyEntity?

    @Query("SELECT * FROM families WHERE familyID IN (:ids)")
    suspend fun getFamiliesByIds(ids: List<Long>): List<FamilyEntity>

    @Query("SELECT * FROM families WHERE familyID = :id LIMIT 1")
    fun getFamilyByIdFlow(id: Long): Flow<FamilyEntity?>

    @Query("SELECT * FROM families WHERE nationalID = :nationalId LIMIT 1")
    suspend fun getFamilyByNationalId(nationalId: String): FamilyEntity?

    @Query("""
        SELECT * FROM families 
        WHERE (:query = '' OR 
               name LIKE '%' || :query || '%' OR 
               nationalID LIKE '%' || :query || '%' OR 
               primary_phone LIKE '%' || :query || '%' OR 
               (alternative_phone_1 IS NOT NULL AND alternative_phone_1 LIKE '%' || :query || '%') OR 
               (alternative_phone_2 IS NOT NULL AND alternative_phone_2 LIKE '%' || :query || '%') OR 
               (wifeName IS NOT NULL AND wifeName LIKE '%' || :query || '%') OR 
               (wifeNationalID IS NOT NULL AND wifeNationalID LIKE '%' || :query || '%'))
        AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
        AND (:shelterStatus IS NULL OR :shelterStatus = '' OR shelterStatus = :shelterStatus)
        ORDER BY createdDate DESC
        LIMIT 100
    """)
    fun searchFamilies(query: String, localityId: Int?, shelterStatus: String?): Flow<List<FamilyEntity>>

    @Query("""
        SELECT * FROM families 
        WHERE (:query = '' OR 
               name LIKE '%' || :query || '%' OR 
               nationalID LIKE '%' || :query || '%' OR 
               primary_phone LIKE '%' || :query || '%' OR 
               (alternative_phone_1 IS NOT NULL AND alternative_phone_1 LIKE '%' || :query || '%') OR 
               (alternative_phone_2 IS NOT NULL AND alternative_phone_2 LIKE '%' || :query || '%') OR 
               (wifeName IS NOT NULL AND wifeName LIKE '%' || :query || '%') OR 
               (wifeNationalID IS NOT NULL AND wifeNationalID LIKE '%' || :query || '%'))
        AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
        AND (:localityName IS NULL OR :localityName = '' OR currentMainArea = :localityName OR localityID IN (SELECT LocalityID FROM tbl_Localities WHERE LocalityName = :localityName))
        AND (:shelterStatus IS NULL OR :shelterStatus = '' OR shelterStatus = :shelterStatus)
        ORDER BY createdDate DESC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun searchFamiliesPaged(
        query: String,
        localityId: Int?,
        shelterStatus: String?,
        limit: Int,
        offset: Int,
        localityName: String? = null
    ): List<FamilyEntity>

    @Query("""
        SELECT COUNT(*) FROM families 
        WHERE (:query = '' OR 
               name LIKE '%' || :query || '%' OR 
               nationalID LIKE '%' || :query || '%' OR 
               primary_phone LIKE '%' || :query || '%' OR 
               (alternative_phone_1 IS NOT NULL AND alternative_phone_1 LIKE '%' || :query || '%') OR 
               (alternative_phone_2 IS NOT NULL AND alternative_phone_2 LIKE '%' || :query || '%') OR 
               (wifeName IS NOT NULL AND wifeName LIKE '%' || :query || '%') OR 
               (wifeNationalID IS NOT NULL AND wifeNationalID LIKE '%' || :query || '%'))
        AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
        AND (:localityName IS NULL OR :localityName = '' OR currentMainArea = :localityName OR localityID IN (SELECT LocalityID FROM tbl_Localities WHERE LocalityName = :localityName))
        AND (:shelterStatus IS NULL OR :shelterStatus = '' OR shelterStatus = :shelterStatus)
    """)
    fun countFamiliesSearchFlow(
        query: String,
        localityId: Int?,
        shelterStatus: String?,
        localityName: String? = null
    ): Flow<Int>

    @Query("""
        SELECT COUNT(*) FROM families 
        WHERE (:query = '' OR 
               name LIKE '%' || :query || '%' OR 
               nationalID LIKE '%' || :query || '%' OR 
               primary_phone LIKE '%' || :query || '%' OR 
               (alternative_phone_1 IS NOT NULL AND alternative_phone_1 LIKE '%' || :query || '%') OR 
               (alternative_phone_2 IS NOT NULL AND alternative_phone_2 LIKE '%' || :query || '%') OR 
               (wifeName IS NOT NULL AND wifeName LIKE '%' || :query || '%') OR 
               (wifeNationalID IS NOT NULL AND wifeNationalID LIKE '%' || :query || '%'))
        AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
        AND (:localityName IS NULL OR :localityName = '' OR currentMainArea = :localityName OR localityID IN (SELECT LocalityID FROM tbl_Localities WHERE LocalityName = :localityName))
        AND (:shelterStatus IS NULL OR :shelterStatus = '' OR shelterStatus = :shelterStatus)
    """)
    suspend fun countFamiliesSearch(
        query: String,
        localityId: Int?,
        shelterStatus: String?,
        localityName: String? = null
    ): Int

    @Query("""
        SELECT * FROM families 
        WHERE (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
        AND (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%')
        AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
        ORDER BY familyMembersCount DESC, familyID ASC
    """)
    suspend fun getEligibleFamiliesForNomination(localityId: Int?): List<FamilyEntity>

    /**
     * استعلام الأسر المستحقة للمشروع مع استبعاد تلقائي لمن استلم أو رُشح لنفس المشروع (منع التكرار)
     */
    @Query("""
        SELECT f.* FROM families f 
        WHERE (f.developmentApproval = 'معتمد' OR f.developmentApproval LIKE '%معتمد%')
        AND (f.residentStatus = 'مقيم' OR f.residentStatus LIKE '%مقيم%')
        AND (:localityId IS NULL OR :localityId = 0 OR f.localityID = :localityId)
        AND f.familyID NOT IN (SELECT a.familyID FROM aid_records a WHERE a.projectID = :projectId)
        ORDER BY f.familyMembersCount DESC, f.familyID ASC
    """)
    suspend fun getEligibleFamiliesForProjectNomination(localityId: Int?, projectId: Long): List<FamilyEntity>

    /**
     * استعلام ديناميكي مبني برمجياً عبر SupportSQLiteQuery (@RawQuery)
     * لتشغيل محرك القواعد المرن والترشيح التفاعلي بأمان وكفاءة عالية
     */
    @RawQuery(observedEntities = [FamilyEntity::class])
    suspend fun getFamiliesRaw(query: SupportSQLiteQuery): List<FamilyEntity>

    @RawQuery(observedEntities = [FamilyEntity::class])
    fun getFamiliesRawFlow(query: SupportSQLiteQuery): Flow<List<FamilyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFamily(family: FamilyEntity): Long


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFamilies(families: List<FamilyEntity>): List<Long>

    @Update
    suspend fun updateFamily(family: FamilyEntity)

    @Query("SELECT * FROM families WHERE nationalID IN (:nationalIds)")
    suspend fun getFamiliesByNationalIds(nationalIds: List<String>): List<FamilyEntity>

    @JvmName("getFamiliesByNationalIdsList")
    @Query("SELECT * FROM families WHERE nationalID IN (:ids)")
    suspend fun getFamiliesByIds(ids: List<String>): List<FamilyEntity>

    /**
     * معالجة دفعات الأسر بنظام Upsert داخل معاملة ذرية (@Transaction) لضمان السرعة الفائقة
     * واستخدام الاستعلام المجمّع بالدفعات (Chunking) لمنع استهلاك الذاكرة وتفادي حد SQLite (999 متغير)
     */
    @Transaction
    suspend fun upsertFamiliesChunk(chunk: List<FamilyEntity>): Pair<Int, Int> {
        var inserted = 0
        var updated = 0
        if (chunk.isEmpty()) return Pair(0, 0)

        // تجميع المعرفات الوطنية والبحث عنها بدفعات تصل إلى 500 لتفادي حد SQLite
        val existingMap = mutableMapOf<String, FamilyEntity>()
        val distinctIds = chunk.map { it.nationalID }.filter { it.isNotBlank() }.distinct()
        distinctIds.chunked(500).forEach { idBatch ->
            val found = getFamiliesByNationalIds(idBatch)
            found.forEach { existingMap[it.nationalID] = it }
        }

        chunk.forEach { family ->
            val existing = existingMap[family.nationalID]
            if (existing != null) {
                updateFamily(
                    family.copy(
                        familyID = existing.familyID,
                        createdDate = existing.createdDate,
                        modifiedDate = System.currentTimeMillis()
                    )
                )
                updated++
            } else {
                insertFamily(family)
                inserted++
            }
        }
        return Pair(inserted, updated)
    }

    @Delete
    suspend fun deleteFamily(family: FamilyEntity)

    @Query("UPDATE families SET developmentApproval = :developmentApproval, residentStatus = :residentStatus, shelterStatus = :shelterStatus WHERE familyID = :familyId")
    suspend fun updateFamilyStatus(familyId: Long, developmentApproval: String, residentStatus: String, shelterStatus: String)

    @Query("SELECT COUNT(*) FROM families")
    suspend fun getTotalFamiliesCount(): Int

    @Query("SELECT SUM(familyMembersCount) FROM families")
    suspend fun getTotalBeneficiariesCount(): Int?

    // =========================================================================
    // استعلامات الاستحقاق الدقيقة وحساب النسب (المرحلة الأولى: منطق حساب النسب)
    // =========================================================================

    /**
     * استعلام إجمالي الأسر المستحقة حسب معيار الاستحقاق الصارم: (الوضع = مقيم) و (حالة الاعتماد = معتمد)
     */
    @Query("""
        SELECT COUNT(*) FROM families 
        WHERE (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
    """)
    suspend fun getExactEligibleFamiliesTotal(): Int

    /**
     * استعلام الأسر المستحقة لمنطقة فرعية محددة بدقة: (الوضع = مقيم) و (حالة الاعتماد = معتمد)
     */
    @Query("""
        SELECT COUNT(*) FROM families 
        WHERE (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
          AND currentSubArea = :subArea
    """)
    suspend fun getEligibleFamiliesCountForSubArea(subArea: String): Int

    /**
     * إجمالي كافة الأسر المسجلة في منطقة فرعية محددة
     */
    @Query("SELECT COUNT(*) FROM families WHERE currentSubArea = :subArea")
    suspend fun getTotalFamiliesCountForSubArea(subArea: String): Int

    /**
     * جلب قائمة كافة المناطق الفرعية المسجلة غير الفارغة
     */
    @Query("SELECT DISTINCT currentSubArea FROM families WHERE currentSubArea IS NOT NULL AND currentSubArea != '' ORDER BY currentSubArea ASC")
    suspend fun getAllSubAreasSync(): List<String>

    /**
     * استعلام إجمالي الأسر المستحقة لمحلية محددة: (الوضع = مقيم) و (حالة الاعتماد = معتمد)
     */
    @Query("""
        SELECT COUNT(*) FROM families 
        WHERE (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
          AND localityID = :localityId
    """)
    suspend fun getEligibleFamiliesCountForLocality(localityId: Int): Int

    @Query("""
        SELECT COUNT(*) FROM families 
        WHERE (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
          AND localityID = :localityId
    """)
    suspend fun getEligibleFamiliesCountByLocality(localityId: Int): Int

    /**
     * استعلام إجمالي عدد الأفراد المستفيدين في الأسر المستحقة (معتمد ومقيم)
     */
    @Query("""
        SELECT SUM(familyMembersCount) FROM families 
        WHERE (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
    """)
    suspend fun getEligibleBeneficiariesTotal(): Int?

    /**
     * استعلام تدفق لإجمالي الأسر المستحقة لتحديث الواجهات فورياً
     */
    @Query("""
        SELECT COUNT(*) FROM families 
        WHERE (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
    """)
    fun getEligibleFamiliesCountFlow(): Flow<Int>

    /**
     * استعلام تجميعي فوري وسريع للأسر المستحقة لكل محلية بالكامل عبر SQL
     */
    @Query("""
        SELECT localityID, COUNT(*) AS count 
        FROM families 
        WHERE (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
        GROUP BY localityID
    """)
    suspend fun getEligibleFamiliesCountGroupedByLocality(): List<LocalityCountRecord>

    /**
     * استعلام تجميعي فوري لإجمالي كافة الأسر لكل محلية عبر SQL
     */
    @Query("""
        SELECT localityID, COUNT(*) AS count 
        FROM families 
        GROUP BY localityID
    """)
    suspend fun getTotalFamiliesCountGroupedByLocality(): List<LocalityCountRecord>

    /**
     * إجمالي عدد الأسر في محلية معينة عبر SQL
     */
    @Query("SELECT COUNT(*) FROM families WHERE localityID = :localityId")
    suspend fun getTotalFamiliesCountForLocality(localityId: Int): Int


    /**
     * استعلام جلب الأسر المستحقة (معتمد ومقيم) حسب رقم المحلية
     */
    @Query("""
        SELECT * FROM families 
        WHERE localityID = :localityId 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%') 
          AND (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%')
        ORDER BY createdDate DESC
    """)
    suspend fun getFamiliesByLocalitySync(localityId: Int): List<FamilyEntity>

    /**
     * استعلام جلب الأسر المستحقة (معتمد ومقيم) حسب اسم المنطقة الفرعية
     */
    @Query("""
        SELECT * FROM families 
        WHERE currentSubArea = :locality 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%') 
          AND (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%')
        ORDER BY createdDate DESC
    """)
    suspend fun getFamiliesByLocalitySync(locality: String): List<FamilyEntity>

    /**
     * استعلام حساب النسب بالاعتماد على المنطقة الفرعية الحالية فقط
     * مع تصفية البيانات بحيث تشمل حصراً الأسر المعتمدة والمقيمة
     */
    @Query("""
        SELECT 
            currentSubArea, 
            COUNT(*) AS familyCount,
            ROUND((COUNT(*) * 100.0 / NULLIF((SELECT COUNT(*) FROM families WHERE (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%') AND (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') AND currentSubArea IS NOT NULL AND currentSubArea != ''), 0)), 2) AS ratio
        FROM families
        WHERE (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%') 
          AND (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%')
          AND currentSubArea IS NOT NULL 
          AND currentSubArea != ''
        GROUP BY currentSubArea
        ORDER BY familyCount DESC
    """)
    suspend fun calculateSubAreaDistributionRatios(): List<SubAreaShareRecord>

    @Query("SELECT nationalID FROM families")
    suspend fun getAllFamilyNationalIdsSync(): List<String>

    @Query("SELECT nationalID, familyID, localityID FROM families")
    suspend fun getAllFamilyReferencesSync(): List<FamilyReference>

    /**
     * استعلامات التجميع المتقدمة باستخدام GROUP BY و COUNT لاستخراج التوزيعات الديناميكية بدون بيانات ثابتة
     */
    @Query("""
        SELECT injuryStatus AS keyName, COUNT(*) AS count 
        FROM families 
        WHERE injuryStatus IS NOT NULL AND injuryStatus != '' 
        GROUP BY injuryStatus 
        ORDER BY count DESC
    """)
    suspend fun getInjuryStatusDistribution(): List<KeyCountRecord>

    @Query("""
        SELECT damageType AS keyName, COUNT(*) AS count 
        FROM families 
        WHERE damageType IS NOT NULL AND damageType != '' 
        GROUP BY damageType 
        ORDER BY count DESC
    """)
    suspend fun getWarDamageDistribution(): List<KeyCountRecord>

    @Query("""
        SELECT developmentApproval AS keyName, COUNT(*) AS count 
        FROM families 
        WHERE developmentApproval IS NOT NULL AND developmentApproval != '' 
        GROUP BY developmentApproval 
        ORDER BY count DESC
    """)
    suspend fun getDevelopmentApprovalDistribution(): List<KeyCountRecord>

    @Query("""
        SELECT residentStatus AS keyName, COUNT(*) AS count 
        FROM families 
        WHERE residentStatus IS NOT NULL AND residentStatus != '' 
        GROUP BY residentStatus 
        ORDER BY count DESC
    """)
    suspend fun getResidentStatusDistribution(): List<KeyCountRecord>

    /**
     * استعلامات ديناميكية لجلب خيارات الفلاتر بدون أي قيم ثابتة (Zero Hardcoded Data)
     */
    @Query("SELECT DISTINCT currentMainArea FROM families WHERE currentMainArea IS NOT NULL AND currentMainArea != '' ORDER BY currentMainArea ASC")
    fun getDistinctLocalities(): Flow<List<String>>

    @Query("SELECT DISTINCT currentSubArea FROM families WHERE currentSubArea IS NOT NULL AND currentSubArea != '' ORDER BY currentSubArea ASC")
    fun getDistinctSubAreasFlow(): Flow<List<String>>

    @Query("SELECT DISTINCT damageType FROM families WHERE damageType IS NOT NULL AND damageType != '' ORDER BY damageType ASC")
    fun getDistinctDamageTypesFlow(): Flow<List<String>>

    @Query("SELECT DISTINCT damageType FROM families WHERE damageType IS NOT NULL AND damageType != '' ORDER BY damageType ASC")
    suspend fun getDistinctDamageTypes(): List<String>

    @Query("SELECT DISTINCT worksApproval FROM families WHERE worksApproval IS NOT NULL AND worksApproval != '' ORDER BY worksApproval ASC")
    fun getDistinctWorksApprovalsFlow(): Flow<List<String>>

    @Query("SELECT DISTINCT worksApproval FROM families WHERE worksApproval IS NOT NULL AND worksApproval != '' ORDER BY worksApproval ASC")
    suspend fun getDistinctWorksApprovals(): List<String>

    @Query("SELECT DISTINCT COALESCE(NULLIF(shelterStatus, ''), 'بدون تصنيف') AS shelterStatus FROM families ORDER BY shelterStatus ASC")
    fun getDistinctShelterStatusesFlow(): Flow<List<String>>

    @Query("SELECT DISTINCT COALESCE(NULLIF(shelterStatus, ''), 'بدون تصنيف') AS shelterStatus FROM families ORDER BY shelterStatus ASC")
    suspend fun getDistinctShelterStatuses(): List<String>

    @Query("SELECT DISTINCT residentStatus FROM families WHERE residentStatus IS NOT NULL AND residentStatus != '' ORDER BY residentStatus ASC")
    fun getDistinctResidentStatusesFlow(): Flow<List<String>>

    // =========================================================================
    // محرك البحث الشامل والمتقدم للأسر (Comprehensive Search Engine)
    // =========================================================================
    /**
     * محرك البحث الشامل للأسر باستخدام معيار LIKE '%searchQuery%'
     * يدعم المطابقة الجزئية للأسماء المركبة عبر استبدال المسافات بـ %
     * يبحث بدقة في: الاسم رباعي، اسم الزوجة، رقم الهوية، هوية الزوجة، وأرقام الجوال الثلاثة
     * ويعيد القائمة الافتراضية كاملة عند فراغ حقل البحث
     */
    @Query("""
        SELECT * FROM families 
        WHERE (:searchQuery IS NULL OR TRIM(:searchQuery) = '' OR 
            name LIKE '%' || REPLACE(TRIM(:searchQuery), ' ', '%') || '%' OR 
            name LIKE '%' || TRIM(:searchQuery) || '%' OR 
            (wifeName IS NOT NULL AND (wifeName LIKE '%' || REPLACE(TRIM(:searchQuery), ' ', '%') || '%' OR wifeName LIKE '%' || TRIM(:searchQuery) || '%')) OR 
            nationalID LIKE '%' || TRIM(:searchQuery) || '%' OR 
            (wifeNationalID IS NOT NULL AND wifeNationalID LIKE '%' || TRIM(:searchQuery) || '%') OR 
            (primary_phone IS NOT NULL AND primary_phone LIKE '%' || TRIM(:searchQuery) || '%') OR 
            (alternative_phone_1 IS NOT NULL AND alternative_phone_1 LIKE '%' || TRIM(:searchQuery) || '%') OR 
            (alternative_phone_2 IS NOT NULL AND alternative_phone_2 LIKE '%' || TRIM(:searchQuery) || '%')
        )
        ORDER BY createdDate DESC
    """)
    fun searchFamiliesComprehensive(searchQuery: String): Flow<List<FamilyEntity>>

    @Query("""
        SELECT * FROM families 
        WHERE (:searchQuery IS NULL OR TRIM(:searchQuery) = '' OR 
            name LIKE '%' || REPLACE(TRIM(:searchQuery), ' ', '%') || '%' OR 
            name LIKE '%' || TRIM(:searchQuery) || '%' OR 
            (wifeName IS NOT NULL AND (wifeName LIKE '%' || REPLACE(TRIM(:searchQuery), ' ', '%') || '%' OR wifeName LIKE '%' || TRIM(:searchQuery) || '%')) OR 
            nationalID LIKE '%' || TRIM(:searchQuery) || '%' OR 
            (wifeNationalID IS NOT NULL AND wifeNationalID LIKE '%' || TRIM(:searchQuery) || '%') OR 
            (primary_phone IS NOT NULL AND primary_phone LIKE '%' || TRIM(:searchQuery) || '%') OR 
            (alternative_phone_1 IS NOT NULL AND alternative_phone_1 LIKE '%' || TRIM(:searchQuery) || '%') OR 
            (alternative_phone_2 IS NOT NULL AND alternative_phone_2 LIKE '%' || TRIM(:searchQuery) || '%')
        )
        ORDER BY createdDate DESC
    """)
    suspend fun searchFamiliesComprehensiveSync(searchQuery: String): List<FamilyEntity>

    // =========================================================================
    // استعلامات التجميع الديناميكية للشعب والمحليات (Dynamic Aggregation Queries)
    // =========================================================================
    /**
     * جلب قائمة الشعب (المناطق الفرعية) ديناميكياً بناءً على محلية محددة
     */
    @Query("""
        SELECT DISTINCT currentSubArea 
        FROM families 
        WHERE localityID = :localityId 
          AND currentSubArea IS NOT NULL 
          AND TRIM(currentSubArea) != ''
        ORDER BY currentSubArea ASC
    """)
    suspend fun getSubAreasByLocality(localityId: Int): List<String>

    @Query("""
        SELECT DISTINCT currentSubArea 
        FROM families 
        WHERE localityID = :localityId 
          AND currentSubArea IS NOT NULL 
          AND TRIM(currentSubArea) != ''
        ORDER BY currentSubArea ASC
    """)
    fun getSubAreasByLocalityFlow(localityId: Int): Flow<List<String>>

    /**
     * استعلام إجمالي عدد الأسر الدقيق لكل محلية
     */
    @Query("""
        SELECT 
            l.LocalityID AS localityID, 
            l.LocalityName AS localityName, 
            COUNT(f.familyID) AS familyCount
        FROM tbl_Localities l
        LEFT JOIN families f ON l.LocalityID = f.localityID
        GROUP BY l.LocalityID, l.LocalityName
        ORDER BY familyCount DESC
    """)
    suspend fun getFamilyCountForEachLocality(): List<LocalityFamilyCount>

    @Query("""
        SELECT 
            l.LocalityID AS localityID, 
            l.LocalityName AS localityName, 
            COUNT(f.familyID) AS familyCount
        FROM tbl_Localities l
        LEFT JOIN families f ON l.LocalityID = f.localityID
        GROUP BY l.LocalityID, l.LocalityName
        ORDER BY familyCount DESC
    """)
    fun getFamilyCountForEachLocalityFlow(): Flow<List<LocalityFamilyCount>>

    /**
     * استعلام إجمالي عدد الأسر الدقيق لكل شعبة (منطقة فرعية)
     * مع إمكانية التصفية بحسب رقم المحلية
     */
    @Query("""
        SELECT 
            currentSubArea AS subArea, 
            localityID, 
            COUNT(*) AS familyCount
        FROM families
        WHERE currentSubArea IS NOT NULL AND TRIM(currentSubArea) != ''
          AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
        GROUP BY currentSubArea, localityID
        ORDER BY familyCount DESC
    """)
    suspend fun getFamilyCountForEachSubArea(localityId: Int? = null): List<SubAreaFamilyCount>

    @Query("""
        SELECT 
            currentSubArea AS subArea, 
            localityID, 
            COUNT(*) AS familyCount
        FROM families
        WHERE currentSubArea IS NOT NULL AND TRIM(currentSubArea) != ''
          AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
        GROUP BY currentSubArea, localityID
        ORDER BY familyCount DESC
    """)
    fun getFamilyCountForEachSubAreaFlow(localityId: Int? = null): Flow<List<SubAreaFamilyCount>>

    // =========================================================================
    // استعلامات أضرار الحرب والمنازل المهدمة كلياً المقيدة جغرافياً (War Damage Queries)
    // =========================================================================
    /**
     * استعلام توزيع أضرار الحرب مصنفة حصراً وديناميكياً حسب الشعبة أو المحلية المحددة
     */
    @Query("""
        SELECT 
            damageType, 
            COUNT(*) AS count 
        FROM families 
        WHERE damageType IS NOT NULL AND TRIM(damageType) != ''
          AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
          AND (:subArea IS NULL OR :subArea = '' OR currentSubArea = :subArea)
        GROUP BY damageType 
        ORDER BY count DESC
    """)
    suspend fun getWarDamageDistributionFiltered(
        localityId: Int? = null,
        subArea: String? = null
    ): List<DamageTypeBreakdown>

    @Query("""
        SELECT 
            damageType, 
            COUNT(*) AS count 
        FROM families 
        WHERE damageType IS NOT NULL AND TRIM(damageType) != ''
          AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
          AND (:subArea IS NULL OR :subArea = '' OR currentSubArea = :subArea)
        GROUP BY damageType 
        ORDER BY count DESC
    """)
    fun getWarDamageDistributionFilteredFlow(
        localityId: Int? = null,
        subArea: String? = null
    ): Flow<List<DamageTypeBreakdown>>

    /**
     * استعلام إحصائي مفصل للمنازل المهدمة كلياً وأضرار الحرب حصراً للشعبة أو المحلية المختارة
     */
    @Query("""
        SELECT 
            COUNT(*) AS totalAssessed,
            SUM(CASE WHEN damageType = 'أضرار كلية' OR damageType LIKE '%كلي%' THEN 1 ELSE 0 END) AS completelyDestroyedCount,
            SUM(CASE WHEN damageType LIKE '%بليغ%' OR damageType LIKE '%غير صالح%' THEN 1 ELSE 0 END) AS severePartialDamageCount,
            SUM(CASE WHEN damageType LIKE '%جزئي%' AND damageType NOT LIKE '%بليغ%' AND damageType NOT LIKE '%غير صالح%' THEN 1 ELSE 0 END) AS minorPartialDamageCount,
            SUM(CASE WHEN damageType LIKE '%لا يوجد%' OR damageType = 'سليم' THEN 1 ELSE 0 END) AS noDamageCount
        FROM families
        WHERE (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
          AND (:subArea IS NULL OR :subArea = '' OR currentSubArea = :subArea)
    """)
    suspend fun getWarDamageStatsFiltered(
        localityId: Int? = null,
        subArea: String? = null
    ): WarDamageStats

    /**
     * إجمالي عدد المنازل المهدمة كلياً حصراً لمحلية أو شعبة معينة
     */
    @Query("""
        SELECT COUNT(*) 
        FROM families 
        WHERE (damageType = 'أضرار كلية' OR damageType LIKE '%كلي%')
          AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
          AND (:subArea IS NULL OR :subArea = '' OR currentSubArea = :subArea)
    """)
    suspend fun getCompletelyDestroyedCountFiltered(
        localityId: Int? = null,
        subArea: String? = null
    ): Int
}


data class FamilyReference(
    val nationalID: String,
    val familyID: Long,
    val localityID: Int
)

/**
 * نموذج كائن الأسرة مقترناً بملخص المساعدات الأخير
 * مخصص لعمليات التدقيق والمطابقة مع كشوف الإكسل
 */
data class FamilyWithLatestAid(
    val family: FamilyEntity,
    val totalAidsCount: Int = 0,
    val lastAidDate: String? = null,
    val lastAidType: String? = null,
    val lastAidCategory: String? = null
)

data class SubAreaShareRecord(
    val currentSubArea: String,
    val familyCount: Int,
    val ratio: Double
) {
    val totalFamilies: Int get() = familyCount
    val percentage: String get() = String.format(java.util.Locale.US, "%.2f%%", ratio)

    constructor(currentSubArea: String, totalFamilies: Int, percentage: String) : this(
        currentSubArea = currentSubArea,
        familyCount = totalFamilies,
        ratio = percentage.replace("%", "").trim().toDoubleOrNull() ?: 0.0
    )
}

data class LocalityCountRecord(
    val localityID: Int,
    val count: Int
)

data class LocalityDeliveryRecord(
    val localityID: Int,
    val deliveredCount: Int
)

data class AidTypeDeliveryRecord(
    val aidTypeID: Int,
    val deliveryCount: Int,
    val distinctBeneficiaryCount: Int
)

data class KeyCountRecord(
    val keyName: String,
    val count: Int
)

data class LocalityFamilyCount(
    val localityID: Int,
    val localityName: String,
    val familyCount: Int
)

data class SubAreaFamilyCount(
    val subArea: String,
    val localityID: Int,
    val familyCount: Int
)

data class DamageTypeBreakdown(
    val damageType: String,
    val count: Int
)

data class WarDamageStats(
    val totalAssessed: Int,
    val completelyDestroyedCount: Int,
    val severePartialDamageCount: Int,
    val minorPartialDamageCount: Int,
    val noDamageCount: Int
)

data class ProjectCountsRecord(
    val projectID: Long,
    val candidatesCount: Int,
    val deliveredCount: Int
)


@Dao
interface ChildDao {
    @Query("SELECT * FROM children WHERE familyNationalID = :familyNationalId")
    fun getChildrenByFamilyNationalId(familyNationalId: String): Flow<List<ChildEntity>>

    @Query("SELECT * FROM children WHERE familyNationalID = (SELECT nationalID FROM families WHERE familyID = :familyId LIMIT 1)")
    fun getChildrenByFamilyId(familyId: Long): Flow<List<ChildEntity>>

    @Query("SELECT * FROM children WHERE nationalID = :nationalId LIMIT 1")
    suspend fun getChildByNationalId(nationalId: String): ChildEntity?

    @Query("SELECT * FROM children WHERE (:query = '' OR childName LIKE '%' || :query || '%' OR nationalID LIKE '%' || :query || '%')")
    fun searchChildren(query: String): Flow<List<ChildEntity>>

    @Query("SELECT COUNT(*) FROM children WHERE familyNationalID = :familyNationalId")
    suspend fun getChildrenCountForFamily(familyNationalId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChild(child: ChildEntity): Long

    @Transaction
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChildren(children: List<ChildEntity>): List<Long>

    @Query("SELECT * FROM children")
    suspend fun getAllChildrenSync(): List<ChildEntity>

    @Query("SELECT nationalID FROM children")
    suspend fun getAllChildNationalIdsSync(): List<String>

    @Query("SELECT COUNT(*) FROM children")
    suspend fun getTotalChildrenCount(): Int

    @Delete
    suspend fun deleteChild(child: ChildEntity)
}


@Dao
interface AidTypeDao {
    @Query("SELECT * FROM aid_types WHERE isActive = 1 ORDER BY aidTypeID ASC")
    fun getAllActiveAidTypes(): Flow<List<AidTypeEntity>>

    @Query("SELECT * FROM aid_types ORDER BY aidTypeID ASC")
    fun getAllAidTypes(): Flow<List<AidTypeEntity>>

    @Query("SELECT * FROM aid_types WHERE isActive = 1 ORDER BY aidTypeID ASC")
    suspend fun getAllActiveAidTypesSync(): List<AidTypeEntity>

    @Query("SELECT * FROM aid_types ORDER BY aidTypeID ASC")
    suspend fun getAllAidTypesSync(): List<AidTypeEntity>

    @Query("SELECT * FROM aid_types WHERE aidTypeID = :id LIMIT 1")
    suspend fun getAidTypeById(id: Int): AidTypeEntity?

    /**
     * استعلام يجلب قائمة فريدة ديناميكية بكافة تصنيفات/أنواع المساعدات الحالية في قاعدة البيانات
     */
    @Query("SELECT DISTINCT aidTypeName FROM aid_types WHERE isActive = 1 AND aidTypeName IS NOT NULL AND aidTypeName != '' ORDER BY aidTypeName ASC")
    fun getDistinctAidCategoriesFlow(): Flow<List<String>>

    @Query("SELECT DISTINCT aidTypeName FROM aid_types WHERE isActive = 1 AND aidTypeName IS NOT NULL AND aidTypeName != '' ORDER BY aidTypeName ASC")
    fun getDistinctAidCategories(): Flow<List<String>>

    @Query("SELECT DISTINCT aidTypeName FROM aid_types WHERE isActive = 1 AND aidTypeName IS NOT NULL AND aidTypeName != '' ORDER BY aidTypeName ASC")
    suspend fun getDistinctAidCategoriesSync(): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAidType(aidType: AidTypeEntity)
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE isActive = 1 ORDER BY projectDate DESC")
    fun getAllActiveProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE projectID = :id LIMIT 1")
    suspend fun getProjectById(id: Long): ProjectEntity?

    @Query("SELECT * FROM projects WHERE projectNumber = :projectNumber LIMIT 1")
    suspend fun getProjectByNumber(projectNumber: String): ProjectEntity?

    @Query("SELECT * FROM projects WHERE projectName = :projectName LIMIT 1")
    suspend fun getProjectByName(projectName: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Query("UPDATE projects SET isLocked = :isLocked WHERE projectID = :projectId")
    suspend fun setProjectLocked(projectId: Long, isLocked: Boolean)

    @Query("""
        SELECT p.*
        FROM projects p
        LEFT JOIN aid_records a ON p.projectID = a.projectID
        WHERE p.isActive = 1 AND p.isLocked = 0
        GROUP BY p.projectID
        HAVING COUNT(a.aidRecordID) < p.quantity
        ORDER BY p.projectID DESC
    """)
    fun getOpenProjectsNeedingNomination(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE isActive = 1 ORDER BY projectDate DESC")
    suspend fun getAllActiveProjectsSync(): List<ProjectEntity>

    @Query("SELECT COUNT(*) FROM projects WHERE isActive = 1")
    suspend fun getTotalProjectsCount(): Int

    @Query("UPDATE projects SET isActive = :isActive WHERE projectID = :projectId")
    suspend fun setProjectActive(projectId: Long, isActive: Boolean)

    @Query("DELETE FROM projects WHERE projectID = :projectId")
    suspend fun deleteProjectById(projectId: Long)

    /**
     * استعلام إحصائي تجميعي مباشر وسريع للمشاريع (استبدال الـ N+1 Query وتحميل مئات الآلاف من السجلات للذاكرة)
     */
    @Query("""
        SELECT 
            p.projectID AS projectID,
            COUNT(a.aidRecordID) AS candidatesCount,
            SUM(CASE WHEN a.recipientStatus = 'مستلم' OR a.recipientStatus = 'مستفيد' OR a.deliveryDate IS NOT NULL THEN 1 ELSE 0 END) AS deliveredCount
        FROM projects p
        LEFT JOIN aid_records a ON p.projectID = a.projectID
        WHERE p.isActive = 1
        GROUP BY p.projectID
    """)
    suspend fun getProjectCountsDirect(): List<ProjectCountsRecord>

    /**
     * استعلام إحصائي تجميعي مباشر للمشاريع مقيد بمحلية محددة للمستخدم
     */
    @Query("""
        SELECT 
            p.projectID AS projectID,
            COUNT(a.aidRecordID) AS candidatesCount,
            SUM(CASE WHEN a.recipientStatus = 'مستلم' OR a.recipientStatus = 'مستفيد' OR a.deliveryDate IS NOT NULL THEN 1 ELSE 0 END) AS deliveredCount
        FROM projects p
        INNER JOIN aid_records a ON p.projectID = a.projectID
        INNER JOIN families f ON a.familyID = f.familyID
        WHERE p.isActive = 1 AND f.localityID = :allowedLoc
        GROUP BY p.projectID
    """)
    suspend fun getProjectCountsDirectForLocality(allowedLoc: Int): List<ProjectCountsRecord>
}

@Dao
interface AidRecordDao {
    @Query("SELECT * FROM aid_records ORDER BY aidDate DESC")
    fun getAllAidRecords(): Flow<List<AidRecordEntity>>

    @Query("SELECT * FROM aid_records WHERE familyID = :familyId ORDER BY aidDate DESC")
    suspend fun getAidRecordsForFamily(familyId: Long): List<AidRecordEntity>

    @Query("SELECT * FROM aid_records WHERE familyID IN (:familyIds) ORDER BY aidDate DESC")
    suspend fun getAidRecordsForFamilies(familyIds: List<Long>): List<AidRecordEntity>

    @Query("SELECT * FROM aid_records WHERE familyID = :familyId ORDER BY aidDate DESC")
    fun getAidRecordsForFamilyFlow(familyId: Long): Flow<List<AidRecordEntity>>

    @Query("SELECT * FROM aid_records WHERE familyID = :familyId ORDER BY aidDate DESC LIMIT 1")
    suspend fun getLastAidForFamily(familyId: Long): AidRecordEntity?

    @Query("""
        SELECT * FROM aid_records 
        WHERE familyID = :familyId 
        AND aidTypeID = :aidTypeId 
        ORDER BY aidDate DESC 
        LIMIT 1
    """)
    suspend fun getLatestAidForFamilyAndType(familyId: Long, aidTypeId: Int): AidRecordEntity?

    @Query("SELECT * FROM aid_records WHERE aidRecordID = :recordId LIMIT 1")
    suspend fun getAidRecordById(recordId: Long): AidRecordEntity?

    /**
     * فحص عدم تكرار المساعدة لنفس الأسرة ونفس المشروع لمنع تكرار الصرف والترشيح
     */
    @Query("SELECT COUNT(*) > 0 FROM aid_records WHERE familyID = :familyId AND projectID = :projectId")
    suspend fun checkIfAidExists(familyId: Long, projectId: Long): Boolean

    @Query("SELECT COUNT(*) FROM aid_records WHERE familyID = :familyId AND projectID = :projectId")
    suspend fun countAidRecordsForFamilyAndProject(familyId: Long, projectId: Long): Int

    @Query("SELECT COUNT(*) > 0 FROM aid_records a INNER JOIN families f ON a.familyID = f.familyID WHERE f.nationalID = :nationalId AND a.projectID = :projectId")
    suspend fun checkIfAidExistsByNationalId(nationalId: String, projectId: Long): Boolean

    @Query("SELECT * FROM aid_records WHERE familyID = :familyId AND projectID = :projectId LIMIT 1")
    suspend fun getAidRecordForFamilyAndProject(familyId: Long, projectId: Long): AidRecordEntity?

    @Query("SELECT familyID FROM aid_records WHERE projectID = :projectId")
    suspend fun getFamilyIdsForProjectSync(projectId: Long): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAidRecord(record: AidRecordEntity): Long

    @Transaction
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAidRecords(records: List<AidRecordEntity>): List<Long>

    @Update
    suspend fun updateAidRecord(record: AidRecordEntity)

    @Query("UPDATE aid_records SET recipientStatus = :status, deliveryDate = :deliveryDate, notes = :notes WHERE aidRecordID = :recordId")
    suspend fun updateDeliveryStatus(recordId: Long, status: String, deliveryDate: String?, notes: String?)

    @Query("DELETE FROM aid_records WHERE aidRecordID = :recordId")
    suspend fun deleteAidRecord(recordId: Long)

    @Query("DELETE FROM aid_records WHERE projectID = :projectId")
    suspend fun deleteRecordsByProjectId(projectId: Long)

    @Query("SELECT COUNT(*) FROM aid_records")
    suspend fun getTotalAidRecordsCount(): Int

    @Query("SELECT * FROM aid_records")
    suspend fun getAllAidRecordsSync(): List<AidRecordEntity>

    @Query("SELECT COUNT(DISTINCT familyID) FROM aid_records WHERE recipientStatus = 'مستلم' OR recipientStatus = 'مستفيد'")
    suspend fun getDistinctBeneficiariesCount(): Int

    // =========================================================================
    // استعلامات أعداد المستفيدين الدقيقة لحساب نسب الاستفادة
    // =========================================================================

    /**
     * استعلام عدد الأسر المستفيدة فعلياً في منطقة فرعية محددة (التي استلمت معونة)
     */
    @Query("""
        SELECT COUNT(DISTINCT a.familyID) 
        FROM aid_records a 
        INNER JOIN families f ON a.familyID = f.familyID 
        WHERE f.currentSubArea = :subArea 
          AND (a.recipientStatus = 'مستلم' OR a.recipientStatus = 'مستفيد' OR a.recipientStatus LIKE '%تسليم%')
    """)
    suspend fun getDeliveredBeneficiariesCountForSubArea(subArea: String): Int

    /**
     * استعلام عدد الأسر المستفيدة فعلياً في محلية محددة
     */
    @Query("""
        SELECT COUNT(DISTINCT a.familyID) 
        FROM aid_records a 
        INNER JOIN families f ON a.familyID = f.familyID 
        WHERE f.localityID = :localityId 
          AND (a.recipientStatus = 'مستلم' OR a.recipientStatus = 'مستفيد' OR a.recipientStatus LIKE '%تسليم%')
    """)
    suspend fun getDeliveredBeneficiariesCountForLocality(localityId: Int): Int

    /**
     * استعلام تجميعي فوري لكافة المساعدات المسلمة لكل محلية عبر SQL
     * مع تصفية أسر المساعدة لتكون حصراً (معتمد ومقيم)
     */
    @Query("""
        SELECT 
            f.localityID AS localityID, 
            COUNT(DISTINCT a.familyID) AS deliveredCount
        FROM aid_records a
        INNER JOIN families f ON a.familyID = f.familyID
        WHERE (f.developmentApproval = 'معتمد' OR f.developmentApproval LIKE '%معتمد%')
          AND (f.residentStatus = 'مقيم' OR f.residentStatus LIKE '%مقيم%')
          AND (a.recipientStatus = 'مستلم' OR a.recipientStatus = 'مستفيد' OR a.recipientStatus LIKE '%تسليم%')
        GROUP BY f.localityID
    """)
    suspend fun getEligibleDeliveredCountGroupedByLocality(): List<LocalityDeliveryRecord>

    /**
     * استعلام عدد المستفيدين في محلية محددة مع تطبيق شرط الاستحقاق الصارم (معتمد ومقيم)
     */
    @Query("""
        SELECT COUNT(DISTINCT a.familyID) 
        FROM aid_records a 
        INNER JOIN families f ON a.familyID = f.familyID 
        WHERE f.localityID = :localityId 
          AND (f.developmentApproval = 'معتمد' OR f.developmentApproval LIKE '%معتمد%')
          AND (f.residentStatus = 'مقيم' OR f.residentStatus LIKE '%مقيم%')
          AND (a.recipientStatus = 'مستلم' OR a.recipientStatus = 'مستفيد' OR a.recipientStatus LIKE '%تسليم%')
    """)
    suspend fun getEligibleDeliveredCountForLocality(localityId: Int): Int

    /**
     * استعلام تجميعي فوري للمساعدات المسلمة حسب نوع المساعدة عبر SQL
     * مع تصفية أسر المساعدة لتكون حصراً (معتمد ومقيم)
     */
    @Query("""
        SELECT 
            a.aidTypeID AS aidTypeID, 
            COUNT(a.aidRecordID) AS deliveryCount,
            COUNT(DISTINCT a.familyID) AS distinctBeneficiaryCount
        FROM aid_records a
        INNER JOIN families f ON a.familyID = f.familyID
        WHERE (f.developmentApproval = 'معتمد' OR f.developmentApproval LIKE '%معتمد%')
          AND (f.residentStatus = 'مقيم' OR f.residentStatus LIKE '%مقيم%')
        GROUP BY a.aidTypeID
    """)
    suspend fun getEligibleDeliveriesGroupedByAidType(): List<AidTypeDeliveryRecord>

    /**
     * إجمالي المستفيدين المميزين الذين استلموا مساعدات وهم مستحقون (معتمد ومقيم)
     */
    @Query("""
        SELECT COUNT(DISTINCT a.familyID) 
        FROM aid_records a
        INNER JOIN families f ON a.familyID = f.familyID
        WHERE (f.developmentApproval = 'معتمد' OR f.developmentApproval LIKE '%معتمد%')
          AND (f.residentStatus = 'مقيم' OR f.residentStatus LIKE '%مقيم%')
          AND (a.recipientStatus = 'مستلم' OR a.recipientStatus = 'مستفيد' OR a.recipientStatus LIKE '%تسليم%')
    """)
    suspend fun getDistinctEligibleBeneficiariesCount(): Int

    /**
     * إجمالي عدد سجلات المساعدة للأسر المستحقة (معتمد ومقيم)
     */
    @Query("""
        SELECT COUNT(a.aidRecordID) 
        FROM aid_records a
        INNER JOIN families f ON a.familyID = f.familyID
        WHERE (f.developmentApproval = 'معتمد' OR f.developmentApproval LIKE '%معتمد%')
          AND (f.residentStatus = 'مقيم' OR f.residentStatus LIKE '%مقيم%')
    """)
    suspend fun getTotalEligibleAidRecordsCount(): Int


    @Query("SELECT * FROM aid_records WHERE projectID = :projectId ORDER BY aidRecordID DESC")
    fun getAidRecordsForProject(projectId: Long): Flow<List<AidRecordEntity>>

    @Query("SELECT * FROM aid_records WHERE projectID = :projectId ORDER BY aidRecordID DESC")
    suspend fun getAidRecordsForProjectSync(projectId: Long): List<AidRecordEntity>

    @Query("SELECT COUNT(*) FROM aid_records WHERE projectID = :projectId")
    suspend fun getProjectCandidatesCount(projectId: Long): Int

    @Query("SELECT COUNT(*) FROM aid_records WHERE projectID = :projectId AND (recipientStatus = 'مستلم' OR recipientStatus = 'مستفيد' OR deliveryDate IS NOT NULL)")
    suspend fun getProjectDeliveredCount(projectId: Long): Int

    /**
     * استعلام تسليم المساعدات مصنفة بنوع المساعدة خلال فترة زمنية محددة
     */
    @Query("""
        SELECT 
            a.aidTypeID AS aidTypeID, 
            COUNT(a.aidRecordID) AS deliveryCount,
            COUNT(DISTINCT a.familyID) AS distinctBeneficiaryCount
        FROM aid_records a
        INNER JOIN families f ON a.familyID = f.familyID
        WHERE (f.developmentApproval = 'معتمد' OR f.developmentApproval LIKE '%معتمد%')
          AND (f.residentStatus = 'مقيم' OR f.residentStatus LIKE '%مقيم%')
          AND (COALESCE(a.deliveryDate, a.aidDate) >= :fromDate AND COALESCE(a.deliveryDate, a.aidDate) <= :toDate)
        GROUP BY a.aidTypeID
    """)
    suspend fun getEligibleDeliveriesGroupedByAidTypeInDateRange(fromDate: String, toDate: String): List<AidTypeDeliveryRecord>

    @Query("""
        SELECT COUNT(a.aidRecordID) 
        FROM aid_records a
        WHERE (COALESCE(a.deliveryDate, a.aidDate) >= :fromDate AND COALESCE(a.deliveryDate, a.aidDate) <= :toDate)
          AND (a.recipientStatus = 'مستلم' OR a.recipientStatus = 'مستفيد' OR a.recipientStatus LIKE '%تسليم%')
    """)
    suspend fun getDeliveredCountInDateRange(fromDate: String, toDate: String): Int
}

@Dao
interface NominationDao {
    @Query("SELECT * FROM tbl_Manual_Selection WHERE AidTypeID = :aidTypeId AND ProjectID = :projectId")
    suspend fun getManualSelections(aidTypeId: Int, projectId: Long): List<ManualSelectionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertManualSelection(selection: ManualSelectionEntity): Long

    @Query("DELETE FROM tbl_Manual_Selection WHERE CitizenID = :citizenId AND AidTypeID = :aidTypeId AND ProjectID = :projectId")
    suspend fun removeManualSelection(citizenId: Long, aidTypeId: Int, projectId: Long)

    @Query("DELETE FROM tbl_Manual_Selection WHERE AidTypeID = :aidTypeId AND ProjectID = :projectId")
    suspend fun clearManualSelections(aidTypeId: Int, projectId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSelectedCitizens(citizens: List<SelectedCitizenEntity>)

    @Query("""
        SELECT * FROM tbl_Selected_Citizens 
        WHERE (:aidTypeId = 0 OR AidTypeID = :aidTypeId) 
        AND (:projectId = 0 OR ProjectID = :projectId)
        ORDER BY ID DESC
    """)
    fun getSelectedCitizens(aidTypeId: Int, projectId: Long): Flow<List<SelectedCitizenEntity>>

    @Query("SELECT COUNT(*) FROM tbl_Selected_Citizens")
    suspend fun getTotalSelectedCount(): Int
}

@Dao
interface LocalityDao {
    @Query("SELECT * FROM tbl_Localities WHERE IsActive = 1 ORDER BY LocalityID ASC")
    fun getAllLocalities(): Flow<List<LocalityEntity>>

    @Query("SELECT * FROM tbl_Localities WHERE LocalityID = :id LIMIT 1")
    suspend fun getLocalityById(id: Int): LocalityEntity?

    @Query("SELECT * FROM tbl_Localities WHERE LocalityName = :name LIMIT 1")
    suspend fun getLocalityByName(name: String): LocalityEntity?

    @Query("SELECT * FROM tbl_Localities WHERE IsActive = 1 ORDER BY LocalityID ASC")
    suspend fun getAllLocalitiesSync(): List<LocalityEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocality(locality: LocalityEntity): Long

    @Query("SELECT * FROM locality_distribution WHERE isActive = 1 ORDER BY localityID ASC")
    fun getDistributions(): Flow<List<LocalityDistributionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDistributions(distributions: List<LocalityDistributionEntity>)

    @Query("DELETE FROM locality_distribution")
    suspend fun clearDistributions()
}

@Dao
interface SystemSettingDao {
    @Query("SELECT * FROM system_settings WHERE key = :key LIMIT 1")
    suspend fun getSetting(key: String): SystemSettingEntity?

    @Query("SELECT * FROM system_settings")
    fun getAllSettings(): Flow<List<SystemSettingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSetting(setting: SystemSettingEntity)
}

@Dao
interface SyncQueueDao {
    @Query("SELECT * FROM sync_queue WHERE status = 'PENDING' OR status = 'FAILED' ORDER BY createdAt ASC")
    fun getPendingSyncItemsFlow(): Flow<List<SyncQueueEntity>>

    @Query("SELECT * FROM sync_queue WHERE status = 'PENDING' OR status = 'FAILED' ORDER BY createdAt ASC")
    suspend fun getPendingSyncItems(): List<SyncQueueEntity>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status = 'PENDING' OR status = 'FAILED'")
    fun getPendingCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status = 'PENDING' OR status = 'FAILED'")
    suspend fun getPendingCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(item: SyncQueueEntity): Long

    @Query("UPDATE sync_queue SET status = 'SYNCING' WHERE syncId = :id")
    suspend fun markAsSyncing(id: Long)

    @Query("UPDATE sync_queue SET status = 'SYNCED' WHERE syncId = :id")
    suspend fun markAsSynced(id: Long)

    @Query("UPDATE sync_queue SET status = 'FAILED', retryCount = retryCount + 1, errorMessage = :error WHERE syncId = :id")
    suspend fun markAsFailed(id: Long, error: String)

    @Query("DELETE FROM sync_queue WHERE status = 'SYNCED'")
    suspend fun clearSynced()

    @Query("DELETE FROM sync_queue WHERE syncId = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM sync_queue")
    suspend fun clearAll()

    // سجلات المزامنة
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSyncLog(log: SyncLogEntity)

    @Query("SELECT * FROM sync_log ORDER BY timestamp DESC LIMIT 20")
    fun getRecentSyncLogs(): Flow<List<SyncLogEntity>>

    @Query("SELECT * FROM sync_log ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLastSyncLog(): SyncLogEntity?
}

@Dao
interface AuditLogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity): Long

    @Query("SELECT * FROM tbl_Audit_Logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM tbl_Audit_Logs WHERE userId = :userId ORDER BY timestamp DESC")
    fun getLogsByUserId(userId: Int): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM tbl_Audit_Logs WHERE targetTable = :tableName ORDER BY timestamp DESC")
    fun getLogsByTable(tableName: String): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM tbl_Audit_Logs ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentLogsSync(limit: Int = 100): List<AuditLogEntity>

    @Query("DELETE FROM tbl_Audit_Logs")
    suspend fun clearLogs()
}

@Dao
interface NominationWorkflowDao {
    @Query("SELECT * FROM tbl_Nomination_Workflows WHERE status = 'ACTIVE' ORDER BY createdDate DESC")
    fun getActiveWorkflows(): Flow<List<NominationWorkflowEntity>>

    @Query("SELECT * FROM tbl_Nomination_Workflows WHERE projectId = :projectId")
    suspend fun getWorkflowByProject(projectId: Long): NominationWorkflowEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkflow(workflow: NominationWorkflowEntity): Long

    @Update
    suspend fun updateWorkflow(workflow: NominationWorkflowEntity)

    @Query("DELETE FROM tbl_Nomination_Workflows WHERE workflowId = :id")
    suspend fun deleteWorkflow(id: Long)
}

@Dao
interface ProjectQuotaDao {
    @Query("SELECT * FROM tbl_Project_Quotas WHERE projectId = :projectId ORDER BY allocatedCount DESC")
    fun getQuotasByProject(projectId: Long): Flow<List<ProjectQuotaEntity>>

    @Query("SELECT * FROM tbl_Project_Quotas WHERE projectId = :projectId ORDER BY allocatedCount DESC")
    suspend fun getQuotasByProjectSync(projectId: Long): List<ProjectQuotaEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuotas(quotas: List<ProjectQuotaEntity>)

    @Query("DELETE FROM tbl_Project_Quotas WHERE projectId = :projectId")
    suspend fun deleteQuotasByProject(projectId: Long)
}

data class SubAreaEligibleStat(
    val currentSubArea: String = "",
    val count: Int = 0
) {
    val subArea: String get() = currentSubArea
}

/**
 * =========================================================================
 * EligibleFamiliesDao
 * معالجة كافة العمليات والإحصائيات والترشيح عبر EligibleFamiliesView
 * يُمنع منعاً باتاً قراءة الإحصائيات أو عرض التوزيع الجغرافي من الجدول الرئيسي
 * =========================================================================
 */
@Dao
interface EligibleFamiliesDao {

    @Query("SELECT * FROM EligibleFamiliesView ORDER BY familyMembersCount DESC, date_of_birth ASC")
    fun getAllEligibleFamilies(): Flow<List<EligibleFamiliesView>>

    @Query("SELECT * FROM EligibleFamiliesView ORDER BY familyMembersCount DESC, date_of_birth ASC")
    suspend fun getAllEligibleFamiliesSync(): List<EligibleFamiliesView>

    @Query("SELECT * FROM EligibleFamiliesView WHERE familyID = :id LIMIT 1")
    suspend fun getEligibleFamilyById(id: Long): EligibleFamiliesView?

    @Query("SELECT * FROM EligibleFamiliesView WHERE nationalID = :nationalId LIMIT 1")
    suspend fun getEligibleFamilyByNationalId(nationalId: String): EligibleFamiliesView?

    @Query("SELECT COUNT(*) FROM EligibleFamiliesView")
    fun countSystemEligibleFamilies(): Flow<Int>

    @Query("SELECT COUNT(*) FROM EligibleFamiliesView")
    suspend fun countSystemEligibleFamiliesSync(): Int

    @Query("SELECT COUNT(*) FROM EligibleFamiliesView WHERE localityID = :localityId")
    fun countEligibleByLocality(localityId: Int): Flow<Int>

    @Query("SELECT COUNT(*) FROM EligibleFamiliesView WHERE localityID = :localityId")
    suspend fun countEligibleByLocalitySync(localityId: Int): Int

    // حساب حصة ونسبة كل محلية ديناميكياً بناءً على الـ View كالتالي: (COUNT(المحلية) / إجمالي الأسر في EligibleFamiliesView) * 100
    @Query("""
        SELECT 
            l.LocalityID AS localityId, 
            l.LocalityName AS localityName, 
            COUNT(v.familyID) AS eligibleFamiliesCount, 
            (SELECT COUNT(*) FROM EligibleFamiliesView) AS totalEligibleSystemWide, 
            CASE 
                WHEN (SELECT COUNT(*) FROM EligibleFamiliesView) > 0 
                THEN (COUNT(v.familyID) * 100.0 / (SELECT COUNT(*) FROM EligibleFamiliesView)) 
                ELSE 0.0 
            END AS percentage 
        FROM tbl_Localities l 
        LEFT JOIN EligibleFamiliesView v ON l.LocalityID = v.localityID 
        GROUP BY l.LocalityID, l.LocalityName 
        HAVING COUNT(v.familyID) > 0
        ORDER BY eligibleFamiliesCount DESC
    """)
    fun getLocalityShares(): Flow<List<LocalityQuotaShare>>

    @Query("""
        SELECT 
            l.LocalityID AS localityId, 
            l.LocalityName AS localityName, 
            COUNT(v.familyID) AS eligibleFamiliesCount, 
            (SELECT COUNT(*) FROM EligibleFamiliesView) AS totalEligibleSystemWide, 
            CASE 
                WHEN (SELECT COUNT(*) FROM EligibleFamiliesView) > 0 
                THEN (COUNT(v.familyID) * 100.0 / (SELECT COUNT(*) FROM EligibleFamiliesView)) 
                ELSE 0.0 
            END AS percentage 
        FROM tbl_Localities l 
        LEFT JOIN EligibleFamiliesView v ON l.LocalityID = v.localityID 
        GROUP BY l.LocalityID, l.LocalityName 
        HAVING COUNT(v.familyID) > 0
        ORDER BY eligibleFamiliesCount DESC
    """)
    suspend fun getLocalitySharesSync(): List<LocalityQuotaShare>

    // توزيع المناطق الفرعية بناءً على الأسر المؤهلة حصراً
    @Query("""
        SELECT currentSubArea, COUNT(familyID) AS count 
        FROM EligibleFamiliesView 
        WHERE currentSubArea IS NOT NULL AND currentSubArea != '' 
        GROUP BY currentSubArea 
        ORDER BY count DESC
    """)
    fun getEligibleCountBySubArea(): Flow<List<SubAreaEligibleStat>>

    @Query("""
        SELECT currentSubArea, COUNT(familyID) AS count 
        FROM EligibleFamiliesView 
        WHERE currentSubArea IS NOT NULL AND currentSubArea != '' 
        GROUP BY currentSubArea 
        ORDER BY count DESC
    """)
    suspend fun getEligibleCountBySubAreaSync(): List<SubAreaEligibleStat>

    // -------------------------------------------------------------
    // استعلامات جلب التصنيفات ديناميكياً (SELECT DISTINCT) من قاعدة البيانات
    // -------------------------------------------------------------
    @Query("SELECT DISTINCT damageType FROM families WHERE damageType IS NOT NULL AND damageType != '' ORDER BY damageType ASC")
    fun getDistinctDamageTypes(): Flow<List<String>>

    @Query("SELECT DISTINCT damageType FROM families WHERE damageType IS NOT NULL AND damageType != '' ORDER BY damageType ASC")
    suspend fun getDistinctDamageTypesSync(): List<String>

    @Query("SELECT DISTINCT maritalStatus FROM families WHERE maritalStatus IS NOT NULL AND maritalStatus != '' ORDER BY maritalStatus ASC")
    fun getDistinctMaritalStatuses(): Flow<List<String>>

    @Query("SELECT DISTINCT maritalStatus FROM families WHERE maritalStatus IS NOT NULL AND maritalStatus != '' ORDER BY maritalStatus ASC")
    suspend fun getDistinctMaritalStatusesSync(): List<String>

    @Query("SELECT DISTINCT worksApproval FROM families WHERE worksApproval IS NOT NULL AND worksApproval != '' ORDER BY worksApproval ASC")
    fun getDistinctWorksApprovals(): Flow<List<String>>

    @Query("SELECT DISTINCT worksApproval FROM families WHERE worksApproval IS NOT NULL AND worksApproval != '' ORDER BY worksApproval ASC")
    suspend fun getDistinctWorksApprovalsSync(): List<String>

    @Query("SELECT DISTINCT shelterStatus FROM families WHERE shelterStatus IS NOT NULL AND shelterStatus != '' ORDER BY shelterStatus ASC")
    fun getDistinctShelterStatuses(): Flow<List<String>>

    @Query("SELECT DISTINCT shelterStatus FROM families WHERE shelterStatus IS NOT NULL AND shelterStatus != '' ORDER BY shelterStatus ASC")
    suspend fun getDistinctShelterStatusesSync(): List<String>

    @Query("SELECT DISTINCT incomeSource1 FROM families WHERE incomeSource1 IS NOT NULL AND incomeSource1 != '' ORDER BY incomeSource1 ASC")
    fun getDistinctIncomeSources(): Flow<List<String>>

    @Query("SELECT DISTINCT incomeSource1 FROM families WHERE incomeSource1 IS NOT NULL AND incomeSource1 != '' ORDER BY incomeSource1 ASC")
    suspend fun getDistinctIncomeSourcesSync(): List<String>

    @Query("SELECT DISTINCT injuryStatus FROM families WHERE injuryStatus IS NOT NULL AND injuryStatus != '' ORDER BY injuryStatus ASC")
    fun getDistinctInjuryStatuses(): Flow<List<String>>

    @Query("SELECT DISTINCT injuryStatus FROM families WHERE injuryStatus IS NOT NULL AND injuryStatus != '' ORDER BY injuryStatus ASC")
    suspend fun getDistinctInjuryStatusesSync(): List<String>

    @Query("SELECT DISTINCT currentSubArea FROM families WHERE currentSubArea IS NOT NULL AND currentSubArea != '' ORDER BY currentSubArea ASC")
    fun getDistinctCurrentSubAreas(): Flow<List<String>>

    @Query("SELECT DISTINCT currentSubArea FROM families WHERE currentSubArea IS NOT NULL AND currentSubArea != '' ORDER BY currentSubArea ASC")
    suspend fun getDistinctCurrentSubAreasSync(): List<String>

    // -------------------------------------------------------------
    // محرك الترشيح المعقد عبر @RawQuery ضد EligibleFamiliesView
    // -------------------------------------------------------------
    @RawQuery(observedEntities = [FamilyEntity::class])
    fun queryEligibleFamiliesRaw(query: SupportSQLiteQuery): Flow<List<EligibleFamiliesView>>

    @RawQuery(observedEntities = [FamilyEntity::class])
    suspend fun queryEligibleFamiliesRawSync(query: SupportSQLiteQuery): List<EligibleFamiliesView>
}

@Dao
interface DeliveryUndoLogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUndoLog(log: DeliveryUndoLogEntity): Long

    @Query("SELECT * FROM tbl_Delivery_Undo_Logs WHERE projectID = :projectId ORDER BY timestamp DESC")
    fun getUndoLogsForProject(projectId: Long): Flow<List<DeliveryUndoLogEntity>>

    @Query("SELECT * FROM tbl_Delivery_Undo_Logs WHERE familyID = :familyId ORDER BY timestamp DESC")
    fun getUndoLogsForFamily(familyId: Long): Flow<List<DeliveryUndoLogEntity>>

    @Query("SELECT * FROM tbl_Delivery_Undo_Logs ORDER BY timestamp DESC LIMIT :limit")
    fun getRecentUndoLogs(limit: Int = 100): Flow<List<DeliveryUndoLogEntity>>

    @Query("SELECT * FROM tbl_Delivery_Undo_Logs ORDER BY timestamp DESC")
    suspend fun getAllUndoLogsSync(): List<DeliveryUndoLogEntity>
}

