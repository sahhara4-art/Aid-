package com.humanitarian.aidmanagement.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import com.humanitarian.aidmanagement.ui.theme.PalestineGreen
import java.util.concurrent.Executors

/**
 * تعبير نمطي صارم لمطابقة رقم الهوية الوطني (9 أرقام متتالية حصراً)
 */
private val NATIONAL_ID_REGEX = Regex("""\b\d{9}\b""")

/**
 * فلترة واستخراج رقم الهوية الوطني من النصوص المقروءة عبر OCR:
 * 1. يتجاهل أي أسطر تحتوي على فواصل أو رموز تواريخ مثل (/) أو (-).
 * 2. يبحث عن 9 أرقام متتالية فقط مطابقة للتعبير النمطي \b\d{9}\b.
 * 3. يمنع التقاط تواريخ الميلاد أو أرقام الجوال أو الأرقام العشوائية.
 */
fun extractNationalIdFromText(text: String): String? {
    if (text.isBlank()) return null
    
    // تقسيم النص إلى أسطر لمعالجة كل سطر بشكل منفصل ومنع التصاق التواريخ بأرقام الهوية
    val lines = text.split("\n", "\r").map { it.trim() }.filter { it.isNotEmpty() }
    
    for (line in lines) {
        // إذا كان السطر يحتوي على فاصلة تواريخ (مثل 15/04/1990 أو 2024/01/10) نتجاهله فوراً
        if (line.contains("/") || line.contains("-") || line.contains(".")) {
            continue
        }
        val match = NATIONAL_ID_REGEX.find(line)
        if (match != null) {
            return match.value
        }
    }
    
    // فحص إضافي: استبعاد التواريخ الصريحة ثم البحث في باقي النص عن 9 أرقام متتالية
    val textWithoutDates = text.replace(Regex("""\b\d{1,4}[/.-]\d{1,2}[/.-]\d{1,4}\b"""), " ")
    val fallbackMatch = NATIONAL_ID_REGEX.find(textWithoutDates)
    return fallbackMatch?.value
}

/**
 * استخراج رقم الهوية الوطني من بيانات الباركود المقروءة:
 * يتحقق من احتواء الباركود على 9 أرقام متتالية حصراً.
 */
fun extractNationalIdFromBarcode(raw: String): String? {
    if (raw.isBlank()) return null
    val match = NATIONAL_ID_REGEX.find(raw)
    if (match != null) return match.value
    
    val digitsOnly = raw.filter { it.isDigit() }
    if (digitsOnly.length == 9) return digitsOnly
    
    return null
}

/**
 * ماسح ذكي متقدم بالكاميرا مدعوم بـ Google ML Kit (TextRecognition v2 & BarcodeScanner)
 * يلتقط باركود بطاقات الهوية، ورموز QR، والأرقام الوطنية المطبوعة تلقائياً مع اهتزاز لمسي (Haptic Feedback)
 */
@Composable
fun CameraScannerDialog(
    onIdScanned: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    var manualInputText by remember { mutableStateOf("") }
    var isTorchEnabled by remember { mutableStateOf(false) }
    var cameraControl: CameraControl? by remember { mutableStateOf(null) }
    var scanStatusMessage by remember { mutableStateOf("جاري توجيه الكاميرا للمسح...") }
    var isCapturing by remember { mutableStateOf(false) }

    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .build()
    }

    val textRecognizer = remember {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    val barcodeScanner = remember {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder()
                .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                .build()
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // حركة خط الليزر الأحمر الممسوح
    val infiniteTransition = rememberInfiniteTransition(label = "scannerLine")
    val laserOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laserOffset"
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.88f)
                    .padding(8.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // الترويسة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "الماسح الضوئي الذكي (ML Kit)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "التقاط الباركود والنصوص الرقمية للهوية",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (!hasCameraPermission) {
                        // طلب إذن الكاميرا
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "يلزم منح إذن الكاميرا لتشغيل الماسح الضوئي",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "يستخدم التطبيق الكاميرا محلياً لمسح باركود البطاقات دون إرسال أي صور خارج الجهاز",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("منح إذن الكاميرا")
                            }
                        }
                    } else {
                        // نافذة معاينة الكاميرا الحية مع طبقة المسح الذكية
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    val previewView = PreviewView(ctx).apply {
                                        scaleType = PreviewView.ScaleType.FILL_CENTER
                                    }
                                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                    cameraProviderFuture.addListener({
                                        try {
                                            val cameraProvider = cameraProviderFuture.get()
                                            val preview = Preview.Builder().build().also {
                                                it.setSurfaceProvider(previewView.surfaceProvider)
                                            }

                                            val cameraExecutor = Executors.newSingleThreadExecutor()
                                            var isDetected = false

                                            val onSuccess: (String) -> Unit = { numbersOnly ->
                                                if (!isDetected) {
                                                    isDetected = true
                                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                    onIdScanned(numbersOnly)
                                                    onDismiss()
                                                }
                                            }

                                            val imageAnalysis = ImageAnalysis.Builder()
                                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                                .build()

                                            imageAnalysis.setAnalyzer(cameraExecutor, object : ImageAnalysis.Analyzer {
                                                @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
                                                override fun analyze(imageProxy: ImageProxy) {
                                                    if (isDetected) {
                                                        imageProxy.close()
                                                        return
                                                    }
                                                    try {
                                                        // 1. تحويل الصورة إلى Bitmap يراعي التدوير التلقائي
                                                        val fullBitmap = imageProxy.toBitmap()

                                                        // 2. حساب إحداثيات مربع الاستهداف المركزي (Region of Interest - ROI)
                                                        val cropWidth = (fullBitmap.width * 0.75f).toInt().coerceAtLeast(100)
                                                        val cropHeight = (fullBitmap.height * 0.35f).toInt().coerceAtLeast(100)
                                                        val left = ((fullBitmap.width - cropWidth) / 2).coerceAtLeast(0)
                                                        val top = ((fullBitmap.height - cropHeight) / 2).coerceAtLeast(0)
                                                        val safeWidth = cropWidth.coerceAtMost(fullBitmap.width - left)
                                                        val safeHeight = cropHeight.coerceAtMost(fullBitmap.height - top)

                                                        // 3. تقييد القراءة جغرافياً بقص الصورة إلى مربع الاستهداف فقط (Coordinate Filtering)
                                                        val croppedBitmap = android.graphics.Bitmap.createBitmap(
                                                            fullBitmap, left, top, safeWidth, safeHeight
                                                        )

                                                        // 4. إرسال الصورة المقصوصة إلى ML Kit
                                                        val image = com.google.mlkit.vision.common.InputImage.fromBitmap(croppedBitmap, 0)

                                                        // 5. فحص الباركود داخل المربع
                                                        barcodeScanner.process(image)
                                                            .addOnSuccessListener { barcodes ->
                                                                if (barcodes.isNotEmpty() && !isDetected) {
                                                                    for (barcode in barcodes) {
                                                                        val raw = barcode.rawValue?.trim() ?: ""
                                                                        val validId = extractNationalIdFromBarcode(raw)
                                                                        if (validId != null) {
                                                                            onSuccess(validId)
                                                                            break
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            .addOnCompleteListener {
                                                                // 6. تشغيل التعرف الضوئي OCR مع فلتر Regex الصارم للهوية (9 أرقام بدون تواريخ)
                                                                if (!isDetected) {
                                                                    textRecognizer.process(image)
                                                                        .addOnSuccessListener { visionText ->
                                                                            if (!isDetected) {
                                                                                val validId = extractNationalIdFromText(visionText.text)
                                                                                if (validId != null) {
                                                                                    onSuccess(validId)
                                                                                }
                                                                            }
                                                                        }
                                                                        .addOnCompleteListener {
                                                                            imageProxy.close()
                                                                        }
                                                                } else {
                                                                    imageProxy.close()
                                                                }
                                                            }
                                                    } catch (e: Exception) {
                                                        Log.e("CameraScannerDialog", "Analyzer error: ${e.message}", e)
                                                        imageProxy.close()
                                                    }
                                                }
                                            })

                                            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                                            cameraProvider.unbindAll()
                                            val camera = cameraProvider.bindToLifecycle(
                                                lifecycleOwner,
                                                cameraSelector,
                                                preview,
                                                imageAnalysis,
                                                imageCapture
                                            )
                                            cameraControl = camera.cameraControl
                                        } catch (exc: Exception) {
                                            Log.e("CameraScannerDialog", "Use case binding failed", exc)
                                        }
                                    }, ContextCompat.getMainExecutor(ctx))

                                    previewView
                                },
                                modifier = Modifier.fillMaxSize()
                            )

                            // 1. تظليل شبه شفاف لباقي الشاشة مع ترك مربع الاستهداف المركزي مضاءً وواضحاً (ROI Scrim Overlay)
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val boxWidth = 280.dp.toPx()
                                val boxHeight = 180.dp.toPx()
                                val left = (size.width - boxWidth) / 2f
                                val top = (size.height - boxHeight) / 2f
                                val cornerRadius = 16.dp.toPx()

                                // تظليل كامل الشاشة مع استثناء مربع الاستهداف المركزي بتقنية EvenOdd
                                val scrimPath = Path().apply {
                                    addRect(Rect(0f, 0f, size.width, size.height))
                                    addRoundRect(
                                        RoundRect(
                                            rect = Rect(left, top, left + boxWidth, top + boxHeight),
                                            cornerRadius = CornerRadius(cornerRadius, cornerRadius)
                                        )
                                    )
                                    fillType = PathFillType.EvenOdd
                                }
                                drawPath(scrimPath, color = Color.Black.copy(alpha = 0.62f))

                                // رسم زوايا الاستهداف البارزة لمربع التركيز (Corner Targeting Brackets)
                                val cornerLength = 26.dp.toPx()
                                val stroke = 3.5.dp.toPx()
                                val accentColor = Color(0xFF10B981)

                                // الزاوية العلوية اليسرى
                                drawLine(accentColor, Offset(left, top + cornerLength), Offset(left, top), stroke)
                                drawLine(accentColor, Offset(left, top), Offset(left + cornerLength, top), stroke)

                                // الزاوية العلوية اليمنى
                                drawLine(accentColor, Offset(left + boxWidth - cornerLength, top), Offset(left + boxWidth, top), stroke)
                                drawLine(accentColor, Offset(left + boxWidth, top), Offset(left + boxWidth, top + cornerLength), stroke)

                                // الزاوية السفلية اليسرى
                                drawLine(accentColor, Offset(left, top + boxHeight - cornerLength), Offset(left, top + boxHeight), stroke)
                                drawLine(accentColor, Offset(left, top + boxHeight), Offset(left + cornerLength, top + boxHeight), stroke)

                                // الزاوية السفلية اليمنى
                                drawLine(accentColor, Offset(left + boxWidth - cornerLength, top + boxHeight), Offset(left + boxWidth, top + boxHeight), stroke)
                                drawLine(accentColor, Offset(left + boxWidth, top + boxHeight), Offset(left + boxWidth, top + boxHeight - cornerLength), stroke)
                            }

                            // 2. إطار الهدف للمسح مع خط الليزر المتحرك
                            Box(
                                modifier = Modifier
                                    .size(width = 280.dp, height = 180.dp)
                                    .border(1.5.dp, Color(0xFF10B981).copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                            ) {
                                // خط الليزر المتحرك
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(2.dp)
                                        .align(Alignment.TopCenter)
                                        .offset(y = (180.dp * laserOffset))
                                        .background(Color(0xFFEF4444))
                                )
                            }

                            // 3. شارة توجيهية بارزة أعلى مربع التركيز
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color.Black.copy(alpha = 0.75f),
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .offset(y = (-115).dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CropFree,
                                        contentDescription = null,
                                        tint = Color(0xFF10B981),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "مربع التركيز: وجّه رقم الهوية أو الباركود هنا",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            // زر تشغيل الفلاش (الكشاف)
                            IconButton(
                                onClick = {
                                    isTorchEnabled = !isTorchEnabled
                                    cameraControl?.enableTorch(isTorchEnabled)
                                },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(12.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isTorchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                    contentDescription = "الفلاش",
                                    tint = if (isTorchEnabled) Color.Yellow else Color.White
                                )
                            }

                            // تلميح الحالة في الأسفل مع زر الشتر اليدوي (Hybrid Scanner Overlay)
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.Black.copy(alpha = 0.65f)
                                ) {
                                    Text(
                                        text = if (isCapturing) "جاري التقاط وقراءة الصورة..." else "وجّه الكاميرا أو اضغط لالتقاط وقراءة فورية",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                    )
                                }

                                // زر الشتر الدائري البارز (Manual Shutter Button)
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .border(3.5.dp, Color.White, CircleShape)
                                        .padding(4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    FloatingActionButton(
                                        onClick = {
                                            if (!isCapturing) {
                                                isCapturing = true
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                imageCapture.takePicture(
                                                    ContextCompat.getMainExecutor(context),
                                                    object : ImageCapture.OnImageCapturedCallback() {
                                                        override fun onCaptureSuccess(imageProxy: ImageProxy) {
                                                            try {
                                                                val fullBitmap = imageProxy.toBitmap()
                                                                val cropWidth = (fullBitmap.width * 0.75f).toInt().coerceAtLeast(100)
                                                                val cropHeight = (fullBitmap.height * 0.35f).toInt().coerceAtLeast(100)
                                                                val left = ((fullBitmap.width - cropWidth) / 2).coerceAtLeast(0)
                                                                val top = ((fullBitmap.height - cropHeight) / 2).coerceAtLeast(0)
                                                                val safeWidth = cropWidth.coerceAtMost(fullBitmap.width - left)
                                                                val safeHeight = cropHeight.coerceAtMost(fullBitmap.height - top)

                                                                val croppedBitmap = android.graphics.Bitmap.createBitmap(
                                                                    fullBitmap, left, top, safeWidth, safeHeight
                                                                )
                                                                val image = com.google.mlkit.vision.common.InputImage.fromBitmap(croppedBitmap, 0)

                                                                barcodeScanner.process(image)
                                                                    .addOnSuccessListener { barcodes: List<Barcode> ->
                                                                        var foundId: String? = null
                                                                        for (bc in barcodes) {
                                                                            val id = extractNationalIdFromBarcode(bc.rawValue ?: "")
                                                                            if (id != null) {
                                                                                foundId = id
                                                                                break
                                                                            }
                                                                        }

                                                                        if (foundId != null) {
                                                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                                            onIdScanned(foundId)
                                                                            onDismiss()
                                                                        } else {
                                                                            textRecognizer.process(image)
                                                                                .addOnSuccessListener { visionText: com.google.mlkit.vision.text.Text ->
                                                                                    val ocrId = extractNationalIdFromText(visionText.text)
                                                                                    if (ocrId != null) {
                                                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                                                        onIdScanned(ocrId)
                                                                                        onDismiss()
                                                                                    } else {
                                                                                        scanStatusMessage = "لم يتم العثور على رقم هوية صالح (9 أرقام) في المربع المحدد"
                                                                                        android.widget.Toast.makeText(
                                                                                            context,
                                                                                            "لم يتم العثور على رقم هوية صالح (9 أرقام) في المربع المحدد",
                                                                                            android.widget.Toast.LENGTH_SHORT
                                                                                        ).show()
                                                                                    }
                                                                                }
                                                                                .addOnFailureListener { exc ->
                                                                                    Log.e("CameraScannerDialog", "Manual OCR error", exc)
                                                                                    android.widget.Toast.makeText(context, "فشلت قراءة الصورة: ${exc.localizedMessage ?: exc.message}", android.widget.Toast.LENGTH_SHORT).show()
                                                                                }
                                                                        }
                                                                    }
                                                                    .addOnCompleteListener {
                                                                        imageProxy.close()
                                                                        isCapturing = false
                                                                    }
                                                            } catch (e: Exception) {
                                                                imageProxy.close()
                                                                isCapturing = false
                                                            }
                                                        }

                                                        override fun onError(exception: ImageCaptureException) {
                                                            Log.e("CameraScannerDialog", "Manual shutter capture failed", exception)
                                                            android.widget.Toast.makeText(context, "فشل التقاط الصورة: ${exception.message}", android.widget.Toast.LENGTH_SHORT).show()
                                                            isCapturing = false
                                                        }
                                                    }
                                                )
                                            }
                                        },
                                        modifier = Modifier.size(60.dp),
                                        shape = CircleShape,
                                        containerColor = PalestineGreen,
                                        contentColor = Color.White,
                                        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp)
                                    ) {
                                        if (isCapturing) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(28.dp),
                                                strokeWidth = 3.dp,
                                                color = Color.White
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Default.CameraAlt,
                                                contentDescription = "التقاط وقراءة",
                                                modifier = Modifier.size(30.dp),
                                                tint = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // بديل إدخال يدوي أو محاكاة سريعة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = manualInputText,
                            onValueChange = { manualInputText = it },
                            placeholder = { Text("أو أدخل رقم الهوية يدوياً...", fontSize = 12.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                val clean = manualInputText.trim().filter { it.isDigit() }
                                if (clean.isNotBlank()) {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onIdScanned(clean)
                                    onDismiss()
                                }
                            },
                            enabled = manualInputText.isNotBlank(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("اعتماد")
                        }
                    }
                }
            }
        }
    }
}

/**
 * ماسح ذكي هجين فائق السرعة يدعم التحليل اللحظي وزر الشتر اليدوي المباشر
 * Hybrid OCR Scanner (Auto-analysis + Manual Shutter)
 */
@Composable
fun MLScannerDialog(
    onScanSuccess: (String) -> Unit,
    onDismiss: () -> Unit
) {
    CameraScannerDialog(
        onIdScanned = onScanSuccess,
        onDismiss = onDismiss
    )
}
