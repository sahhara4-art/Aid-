package com.humanitarian.aidmanagement.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.humanitarian.aidmanagement.ui.theme.PalestineGreen
import java.util.concurrent.Executors

/**
 * ماسح ذكي متقدم بالكاميرا مدعوم بـ Google ML Kit (TextRecognition v2 & BarcodeScanner)
 * يلتقط باركود بطاقات الهوية، ورموز QR، والأرقام الوطنية المطبوعة تلقائياً مع اهتزاز لمسي (Haptic Feedback)
 */
@Composable
fun CameraScannerDialog(
    onIdScanned: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val haptic = LocalHapticFeedback.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    var manualInputText by remember { mutableStateOf("") }
    var isTorchEnabled by remember { mutableStateOf(false) }
    var cameraControl: CameraControl? by remember { mutableStateOf(null) }
    var scanStatusMessage by remember { mutableStateOf("جاري توجيه الكاميرا للمسح...") }
    var isCapturing by remember { mutableStateOf(false) }

    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .build()
    }

    val textRecognizer = remember {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // حركة خط الليزر الأحمر الممسوح
    val infiniteTransition = rememberInfiniteTransition(label = "scannerLine")
    val laserOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laserOffset"
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.88f)
                    .padding(8.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // الترويسة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "الماسح الضوئي الذكي (ML Kit)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "التقاط الباركود والنصوص الرقمية للهوية",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (!hasCameraPermission) {
                        // طلب إذن الكاميرا
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "يلزم منح إذن الكاميرا لتشغيل الماسح الضوئي",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "يستخدم التطبيق الكاميرا محلياً لمسح باركود البطاقات دون إرسال أي صور خارج الجهاز",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("منح إذن الكاميرا")
                            }
                        }
                    } else {
                        // نافذة معاينة الكاميرا الحية مع طبقة المسح الذكية
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    val previewView = PreviewView(ctx).apply {
                                        scaleType = PreviewView.ScaleType.FILL_CENTER
                                    }
                                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                    cameraProviderFuture.addListener({
                                        try {
                                            val cameraProvider = cameraProviderFuture.get()
                                            val preview = Preview.Builder().build().also {
                                                it.setSurfaceProvider(previewView.surfaceProvider)
                                            }

                                            val barcodeScanner = BarcodeScanning.getClient(
                                                BarcodeScannerOptions.Builder()
                                                    .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                                                    .build()
                                            )

                                            val cameraExecutor = Executors.newSingleThreadExecutor()
                                            var isDetected = false

                                            val imageAnalysis = ImageAnalysis.Builder()
                                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                                .build()

                                            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                                                val mediaImage = imageProxy.image
                                                if (mediaImage != null && !isDetected) {
                                                    val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

                                                    // 1. فحص الباركود أولاً
                                                    barcodeScanner.process(image)
                                                        .addOnSuccessListener { barcodes ->
                                                            if (barcodes.isNotEmpty() && !isDetected) {
                                                                for (barcode in barcodes) {
                                                                    val raw = barcode.rawValue?.trim() ?: ""
                                                                    val digits = raw.filter { it.isDigit() }
                                                                    if (digits.length >= 8) {
                                                                        isDetected = true
                                                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                                        onIdScanned(digits)
                                                                        onDismiss()
                                                                        break
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        .addOnCompleteListener {
                                                            // 2. إذا لم يكن باركود، فحص الأرقام المطبوعة عبر TextRecognition
                                                            if (!isDetected) {
                                                                textRecognizer.process(image)
                                                                    .addOnSuccessListener { visionText ->
                                                                        if (!isDetected) {
                                                                            val fullText = visionText.text
                                                                            val idMatch = Regex("\\b[0-9]{9}\\b").find(fullText)
                                                                            if (idMatch != null) {
                                                                                isDetected = true
                                                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                                                onIdScanned(idMatch.value)
                                                                                onDismiss()
                                                                            }
                                                                        }
                                                                    }
                                                                    .addOnCompleteListener {
                                                                        imageProxy.close()
                                                                    }
                                                            } else {
                                                                imageProxy.close()
                                                            }
                                                        }
                                                } else {
                                                    imageProxy.close()
                                                }
                                            }

                                            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                                            cameraProvider.unbindAll()
                                            val camera = cameraProvider.bindToLifecycle(
                                                lifecycleOwner,
                                                cameraSelector,
                                                preview,
                                                imageAnalysis,
                                                imageCapture
                                            )
                                            cameraControl = camera.cameraControl
                                        } catch (exc: Exception) {
                                            Log.e("CameraScannerDialog", "Use case binding failed", exc)
                                        }
                                    }, ContextCompat.getMainExecutor(ctx))

                                    previewView
                                },
                                modifier = Modifier.fillMaxSize()
                            )

                            // إطار الهدف للمسح
                            Box(
                                modifier = Modifier
                                    .size(width = 280.dp, height = 180.dp)
                                    .border(2.dp, Color(0xFF10B981), RoundedCornerShape(16.dp))
                            ) {
                                // خط الليزر المتحرك
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(2.dp)
                                        .align(Alignment.TopCenter)
                                        .offset(y = (180.dp * laserOffset))
                                        .background(Color(0xFFEF4444))
                                )
                            }

                            // زر تشغيل الفلاش (الكشاف)
                            IconButton(
                                onClick = {
                                    isTorchEnabled = !isTorchEnabled
                                    cameraControl?.enableTorch(isTorchEnabled)
                                },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(12.dp)
                                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isTorchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                    contentDescription = "الفلاش",
                                    tint = if (isTorchEnabled) Color.Yellow else Color.White
                                )
                            }

                            // تلميح الحالة في الأسفل مع زر الشتر اليدوي (Hybrid Scanner Overlay)
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.Black.copy(alpha = 0.65f)
                                ) {
                                    Text(
                                        text = if (isCapturing) "جاري التقاط وقراءة الصورة..." else "وجّه الكاميرا أو اضغط لالتقاط وقراءة فورية",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                    )
                                }

                                // زر الشتر الدائري البارز (Manual Shutter Button)
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .border(3.5.dp, Color.White, CircleShape)
                                        .padding(4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    FloatingActionButton(
                                        onClick = {
                                            if (!isCapturing) {
                                                isCapturing = true
                                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                imageCapture.takePicture(
                                                    ContextCompat.getMainExecutor(context),
                                                    object : ImageCapture.OnImageCapturedCallback() {
                                                        override fun onCaptureSuccess(imageProxy: ImageProxy) {
                                                            val mediaImage = imageProxy.image
                                                            if (mediaImage != null) {
                                                                val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                                                                textRecognizer.process(image)
                                                                    .addOnSuccessListener { text ->
                                                                        val numbersOnly = text.text.replace(Regex("[^0-9]"), "")
                                                                        if (numbersOnly.isNotEmpty()) {
                                                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                                                            onIdScanned(numbersOnly)
                                                                            onDismiss()
                                                                        } else {
                                                                            scanStatusMessage = "لم يتم العثور على أرقام واضحة في الصورة، يرجى المحاولة ثانية"
                                                                            android.widget.Toast.makeText(context, "لم يتم العثور على أرقام واضحة في الصورة", android.widget.Toast.LENGTH_SHORT).show()
                                                                        }
                                                                    }
                                                                    .addOnFailureListener { exc ->
                                                                        Log.e("CameraScannerDialog", "Manual OCR error", exc)
                                                                        android.widget.Toast.makeText(context, "فشلت قراءة الصورة: ${exc.localizedMessage ?: exc.message}", android.widget.Toast.LENGTH_SHORT).show()
                                                                    }
                                                                    .addOnCompleteListener {
                                                                        imageProxy.close()
                                                                        isCapturing = false
                                                                    }
                                                            } else {
                                                                imageProxy.close()
                                                                isCapturing = false
                                                            }
                                                        }

                                                        override fun onError(exception: ImageCaptureException) {
                                                            Log.e("CameraScannerDialog", "Manual shutter capture failed", exception)
                                                            android.widget.Toast.makeText(context, "فشل التقاط الصورة: ${exception.message}", android.widget.Toast.LENGTH_SHORT).show()
                                                            isCapturing = false
                                                        }
                                                    }
                                                )
                                            }
                                        },
                                        modifier = Modifier.size(60.dp),
                                        shape = CircleShape,
                                        containerColor = PalestineGreen,
                                        contentColor = Color.White,
                                        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp)
                                    ) {
                                        if (isCapturing) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(28.dp),
                                                strokeWidth = 3.dp,
                                                color = Color.White
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Default.CameraAlt,
                                                contentDescription = "التقاط وقراءة",
                                                modifier = Modifier.size(30.dp),
                                                tint = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // بديل إدخال يدوي أو محاكاة سريعة
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = manualInputText,
                            onValueChange = { manualInputText = it },
                            placeholder = { Text("أو أدخل رقم الهوية يدوياً...", fontSize = 12.sp) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                val clean = manualInputText.trim().filter { it.isDigit() }
                                if (clean.isNotBlank()) {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    onIdScanned(clean)
                                    onDismiss()
                                }
                            },
                            enabled = manualInputText.isNotBlank(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("اعتماد")
                        }
                    }
                }
            }
        }
    }
}

/**
 * ماسح ذكي هجين فائق السرعة يدعم التحليل اللحظي وزر الشتر اليدوي المباشر
 * Hybrid OCR Scanner (Auto-analysis + Manual Shutter)
 */
@Composable
fun MLScannerDialog(
    onScanSuccess: (String) -> Unit,
    onDismiss: () -> Unit
) {
    CameraScannerDialog(
        onIdScanned = onScanSuccess,
        onDismiss = onDismiss
    )
}
