package com.humanitarian.aidmanagement.civilregistry.data

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.CancellationSignal
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySchema
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchPage
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchScope

/**
 * منفّذ استعلامات القراءة المشترك لجدول civil_registry (Read-Only Query Executor)
 * يُستخدم بنفس الصيغة الحرفية للجدول والأعمدة الـ 14 والفهارس لكل من:
 * - SqliteCivilRegistryDataSource (قاعدة civil_registry.db الفعلية)
 * - SampleCivilRegistryDataSource (البيانات التجريبية الفورية)
 */
internal object CivilRegistryQueryExecutor {

    fun executeSearch(
        db: SQLiteDatabase,
        query: CivilRegistrySearchQuery,
        offset: Int,
        pageSize: Int,
        cancellationSignal: CancellationSignal?
    ): CivilRegistrySearchPage {
        if (!query.hasActiveCriteria) {
            return CivilRegistrySearchPage(emptyList(), hasMore = false, offset = 0)
        }

        val safeOffset = offset.coerceAtLeast(0)
        val fetchLimit = pageSize + 1

        val (sql, args) = if (query.advancedMode) {
            buildAdvancedMultiFieldQuery(query, fetchLimit, safeOffset)
        } else {
            buildQuickSearchQuery(query.quickQuery, query.scope, fetchLimit, safeOffset)
        }

        if (sql.isBlank()) {
            return CivilRegistrySearchPage(emptyList(), hasMore = false, offset = safeOffset)
        }

        val results = ArrayList<CivilRegistryRecord>(pageSize)
        var hasMore = false

        db.rawQuery(sql, args, cancellationSignal).use { cursor ->
            while (cursor.moveToNext()) {
                if (results.size >= pageSize) {
                    hasMore = true
                    break
                }
                results.add(cursor.toCivilRegistryRecord())
            }
        }

        return CivilRegistrySearchPage(
            records = results,
            hasMore = hasMore,
            offset = safeOffset
        )
    }

    fun queryTotalCountFast(db: SQLiteDatabase): Long {
        return try {
            db.rawQuery("SELECT COUNT(*) FROM ${CivilRegistrySchema.TABLE_NAME}", null).use { c ->
                if (c.moveToFirst()) c.getLong(0) else 0L
            }
        } catch (_: Throwable) {
            0L
        }
    }

    private fun buildQuickSearchQuery(
        rawQuery: String,
        scope: CivilRegistrySearchScope,
        fetchLimit: Int,
        offset: Int
    ): Pair<String, Array<String>> {
        val trimmed = rawQuery.trim()
        if (trimmed.isEmpty()) return "" to emptyArray()

        val normalizedDigits = normalizeDigits(trimmed)
        val isPureNumeric = normalizedDigits.isNotEmpty() &&
            trimmed.all { it.isDigit() || it in '٠'..'٩' || it == ' ' || it == '-' || it == '+' }

        val cols = CivilRegistrySchema.ALL_COLUMNS_SQL
        val table = CivilRegistrySchema.TABLE_NAME

        return when (scope) {
            CivilRegistrySearchScope.NATIONAL_ID -> {
                if (normalizedDigits.isEmpty()) return "" to emptyArray()
                val (clause, arg) = idMatchClause(CivilRegistrySchema.COL_NATIONAL_ID, normalizedDigits)
                "SELECT $cols FROM $table WHERE $clause LIMIT ? OFFSET ?" to
                    arrayOf(arg, fetchLimit.toString(), offset.toString())
            }

            CivilRegistrySearchScope.WIFE_NATIONAL_ID -> {
                if (normalizedDigits.isEmpty()) return "" to emptyArray()
                val (clause, arg) = idMatchClause(CivilRegistrySchema.COL_WIFE_NATIONAL_ID, normalizedDigits)
                "SELECT $cols FROM $table WHERE $clause LIMIT ? OFFSET ?" to
                    arrayOf(arg, fetchLimit.toString(), offset.toString())
            }

            CivilRegistrySearchScope.NAME -> {
                val (whereSql, whereArgs) = buildTokenizedNameClause(
                    CivilRegistrySchema.COL_NAME,
                    trimmed,
                    preferPrefixFirst = true
                )
                "SELECT $cols FROM $table WHERE $whereSql LIMIT ? OFFSET ?" to
                    (whereArgs + arrayOf(fetchLimit.toString(), offset.toString()))
            }

            CivilRegistrySearchScope.WIFE_NAME -> {
                val (whereSql, whereArgs) = buildTokenizedNameClause(
                    CivilRegistrySchema.COL_WIFE_NAME,
                    trimmed,
                    preferPrefixFirst = false
                )
                "SELECT $cols FROM $table WHERE $whereSql LIMIT ? OFFSET ?" to
                    (whereArgs + arrayOf(fetchLimit.toString(), offset.toString()))
            }

            CivilRegistrySearchScope.PHONES -> {
                val phoneTokens = buildPhoneSearchVariants(normalizedDigits.ifEmpty { trimmed })
                val (whereSql, whereArgs) = buildPhoneColumnsClause(phoneTokens)
                "SELECT $cols FROM $table WHERE $whereSql LIMIT ? OFFSET ?" to
                    (whereArgs + arrayOf(fetchLimit.toString(), offset.toString()))
            }

            CivilRegistrySearchScope.ALL -> {
                if (isPureNumeric) {
                    val (citizenIdClause, citizenArg) = idMatchClause(CivilRegistrySchema.COL_NATIONAL_ID, normalizedDigits)
                    val (wifeIdClause, wifeArg) = idMatchClause(CivilRegistrySchema.COL_WIFE_NATIONAL_ID, normalizedDigits)
                    val phoneVariants = buildPhoneSearchVariants(normalizedDigits)
                    val (phoneClause, phoneArgs) = buildPhoneColumnsClause(phoneVariants)

                    val sql = """
                        SELECT $cols FROM (
                            SELECT $cols FROM $table WHERE $citizenIdClause
                            UNION
                            SELECT $cols FROM $table WHERE $wifeIdClause
                            UNION
                            SELECT $cols FROM $table WHERE $phoneClause
                        ) LIMIT ? OFFSET ?
                    """.trimIndent()

                    val allArgs = buildList {
                        add(citizenArg)
                        add(wifeArg)
                        addAll(phoneArgs)
                        add(fetchLimit.toString())
                        add(offset.toString())
                    }.toTypedArray()

                    sql to allArgs
                } else {
                    val (nameWhere, nameArgs) = buildTokenizedNameClause(
                        CivilRegistrySchema.COL_NAME,
                        trimmed,
                        preferPrefixFirst = true
                    )
                    val (wifeWhere, wifeArgs) = buildTokenizedNameClause(
                        CivilRegistrySchema.COL_WIFE_NAME,
                        trimmed,
                        preferPrefixFirst = false
                    )

                    val sql = """
                        SELECT $cols FROM (
                            SELECT $cols FROM $table WHERE $nameWhere
                            UNION
                            SELECT $cols FROM $table WHERE $wifeWhere
                        ) LIMIT ? OFFSET ?
                    """.trimIndent()

                    val allArgs = buildList {
                        addAll(nameArgs)
                        addAll(wifeArgs)
                        add(fetchLimit.toString())
                        add(offset.toString())
                    }.toTypedArray()

                    sql to allArgs
                }
            }
        }
    }

    private fun buildAdvancedMultiFieldQuery(
        query: CivilRegistrySearchQuery,
        fetchLimit: Int,
        offset: Int
    ): Pair<String, Array<String>> {
        val clauses = mutableListOf<String>()
        val args = mutableListOf<String>()

        val natDigits = normalizeDigits(query.nationalIdFilter)
        if (natDigits.isNotEmpty()) {
            val (clause, arg) = idMatchClause(CivilRegistrySchema.COL_NATIONAL_ID, natDigits)
            clauses.add(clause)
            args.add(arg)
        }

        val wifeDigits = normalizeDigits(query.wifeNationalIdFilter)
        if (wifeDigits.isNotEmpty()) {
            val (clause, arg) = idMatchClause(CivilRegistrySchema.COL_WIFE_NATIONAL_ID, wifeDigits)
            clauses.add(clause)
            args.add(arg)
        }

        val cleanName = query.nameFilter.trim()
        if (cleanName.isNotEmpty()) {
            val (nameSql, nameArgs) = buildTokenizedNameClause(
                CivilRegistrySchema.COL_NAME,
                cleanName,
                preferPrefixFirst = true
            )
            clauses.add("($nameSql)")
            args.addAll(nameArgs)
        }

        val cleanWifeName = query.wifeNameFilter.trim()
        if (cleanWifeName.isNotEmpty()) {
            val (wifeSql, wifeArgs) = buildTokenizedNameClause(
                CivilRegistrySchema.COL_WIFE_NAME,
                cleanWifeName,
                preferPrefixFirst = false
            )
            clauses.add("($wifeSql)")
            args.addAll(wifeArgs)
        }

        val phoneDigits = normalizeDigits(query.phoneFilter)
        if (phoneDigits.isNotEmpty()) {
            val (phoneSql, phoneArgs) = buildPhoneColumnsClause(buildPhoneSearchVariants(phoneDigits))
            clauses.add("($phoneSql)")
            args.addAll(phoneArgs)
        }

        if (clauses.isEmpty()) return "" to emptyArray()

        val sql = "SELECT ${CivilRegistrySchema.ALL_COLUMNS_SQL} FROM ${CivilRegistrySchema.TABLE_NAME} " +
            "WHERE ${clauses.joinToString(" AND ")} LIMIT ? OFFSET ?"

        args.add(fetchLimit.toString())
        args.add(offset.toString())
        return sql to args.toTypedArray()
    }

    private fun idMatchClause(columnName: String, cleanDigits: String): Pair<String, String> {
        return if (cleanDigits.length >= 9) {
            "\"$columnName\" = ?" to cleanDigits.take(9)
        } else {
            "\"$columnName\" LIKE ?" to "$cleanDigits%"
        }
    }

    private fun buildTokenizedNameClause(
        columnName: String,
        rawInput: String,
        preferPrefixFirst: Boolean
    ): Pair<String, Array<String>> {
        val tokens = rawInput.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.take(5)
        if (tokens.isEmpty()) return "1=0" to emptyArray()

        val sqlParts = mutableListOf<String>()
        val args = mutableListOf<String>()
        tokens.forEachIndexed { index, token ->
            sqlParts.add("\"$columnName\" LIKE ?")
            val pattern = if (index == 0 && preferPrefixFirst) "$token%" else "%$token%"
            args.add(pattern)
        }
        return sqlParts.joinToString(" AND ") to args.toTypedArray()
    }

    private fun buildPhoneSearchVariants(cleanDigits: String): List<String> {
        val trimmed = cleanDigits.removePrefix("970").removePrefix("972")
        val variants = linkedSetOf<String>()
        if (trimmed.isNotEmpty()) {
            variants.add(trimmed)
            if (trimmed.startsWith("0") && trimmed.length > 1) {
                variants.add(trimmed.removePrefix("0"))
            } else if (!trimmed.startsWith("0") && trimmed.length >= 4) {
                variants.add("0$trimmed")
            }
        }
        return variants.toList()
    }

    private fun buildPhoneColumnsClause(variants: List<String>): Pair<String, Array<String>> {
        if (variants.isEmpty()) return "1=0" to emptyArray()
        val parts = mutableListOf<String>()
        val args = mutableListOf<String>()
        val mobileCol = CivilRegistrySchema.COL_MOBILE_PHONE
        val devCol = CivilRegistrySchema.COL_DEV_PHONE

        variants.forEach { token ->
            val pattern = "%$token%"
            parts.add("\"$mobileCol\" LIKE ?")
            args.add(pattern)
            parts.add("\"$devCol\" LIKE ?")
            args.add(pattern)
        }
        return parts.joinToString(" OR ") to args.toTypedArray()
    }

    private fun normalizeDigits(input: String): String {
        val cleaned = input.trim().removeSuffix(".0")
        val sb = StringBuilder(cleaned.length)
        for (ch in cleaned) {
            when (ch) {
                in '0'..'9' -> sb.append(ch)
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
            }
        }
        return sb.toString()
    }

    private fun Cursor.toCivilRegistryRecord(): CivilRegistryRecord {
        fun safeStr(index: Int): String {
            if (index < 0 || isNull(index)) return ""
            return getString(index)?.trim()?.removeSuffix(".0") ?: ""
        }

        fun safeRaw(index: Int): String {
            if (index < 0 || isNull(index)) return ""
            return getString(index)?.trim().orEmpty()
        }

        return CivilRegistryRecord(
            nationalId = safeStr(0),
            name = safeRaw(1),
            birthDate = safeRaw(2),
            maritalStatus = safeRaw(3),
            deathStatus = safeRaw(4),
            deathDate = safeRaw(5),
            gender = safeRaw(6),
            developmentPhone = safeStr(7),
            mobilePhone = safeStr(8),
            mainArea = safeRaw(9),
            familyMembersCount = safeStr(10),
            developmentApprovalStatus = safeRaw(11),
            wifeName = safeRaw(12),
            wifeNationalId = safeStr(13)
        )
    }
}
