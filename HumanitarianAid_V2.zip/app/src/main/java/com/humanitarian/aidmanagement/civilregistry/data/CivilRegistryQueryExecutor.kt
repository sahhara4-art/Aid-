package com.humanitarian.aidmanagement.civilregistry.data

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.os.CancellationSignal
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryChildRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryChildrenSchema
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySchema
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchPage
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchScope
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchTarget
import com.humanitarian.aidmanagement.civilregistry.security.CivilRegistryPermissionGuard

/**
 * منفّذ استعلامات القراءة المشترك لجدول civil_registry (Read-Only Query Executor)
 * يُستخدم بنفس الصيغة الحرفية للجدول والأعمدة الـ 14 والفهارس لكل من:
 * - SqliteCivilRegistryDataSource (قاعدة civil_registry.db الفعلية)
 * - SampleCivilRegistryDataSource (البيانات التجريبية الفورية)
 */
internal object CivilRegistryQueryExecutor {

    private const val MAX_CHILD_MATCH_ROWS = 50
    private const val MAX_CHILD_MATCH_FAMILIES = 30

    private data class ChildHitRow(
        val parentId: String,
        val parentName: String,
        val childId: String,
        val childRowId: Long,
        val childName: String
    ) {
        val matchIdentifier: String
            get() = childId.trim().ifBlank { "row_$childRowId" }
    }

    private data class ChildSearchBundle(
        val families: List<CivilRegistryRecord>,
        val childrenByParentId: Map<String, List<CivilRegistryChildRecord>>,
        val matchedChildKeysByParentId: Map<String, Set<String>>,
        val matchedChildNamesByParentId: Map<String, List<String>>
    )

    fun executeSearch(
        db: SQLiteDatabase,
        query: CivilRegistrySearchQuery,
        offset: Int,
        pageSize: Int,
        cancellationSignal: CancellationSignal?
    ): CivilRegistrySearchPage {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            return CivilRegistrySearchPage(emptyList(), hasMore = false, offset = 0)
        }
        if (!query.hasActiveCriteria) {
            return CivilRegistrySearchPage(emptyList(), hasMore = false, offset = 0)
        }

        val safeOffset = offset.coerceAtLeast(0)

        // مسار البحث المباشر بالابن (الاسم عبر FTS4 أو رقم الهوية عبر idx_children_child_id)
        if (!query.advancedMode && query.target == CivilRegistrySearchTarget.CHILD) {
            if (safeOffset > 0) {
                return CivilRegistrySearchPage(emptyList(), hasMore = false, offset = safeOffset)
            }
            val bundle = executeChildSearchBundle(
                db = db,
                rawQuery = query.quickQuery,
                cancellationSignal = cancellationSignal
            )
            return CivilRegistrySearchPage(
                records = bundle.families,
                hasMore = false,
                offset = 0,
                preloadedChildrenByParentId = bundle.childrenByParentId,
                matchedChildKeysByParentId = bundle.matchedChildKeysByParentId,
                matchedChildNamesByParentId = bundle.matchedChildNamesByParentId
            )
        }

        val fetchLimit = pageSize + 1

        val (sql, args) = if (query.advancedMode) {
            buildAdvancedMultiFieldQuery(query, fetchLimit, safeOffset)
        } else {
            buildQuickSearchQuery(query.quickQuery, query.scope, fetchLimit, safeOffset)
        }

        val headResults = ArrayList<CivilRegistryRecord>(pageSize)
        var hasMore = false

        if (sql.isNotBlank()) {
            db.rawQuery(sql, args, cancellationSignal).use { cursor ->
                while (cursor.moveToNext()) {
                    if (headResults.size >= pageSize) {
                        hasMore = true
                        break
                    }
                    headResults.add(cursor.toCivilRegistryRecord())
                }
            }
        }

        // في وضع "الكل" (الصفحة الأولى): دمج نتائج البحث في الأبناء بدون تكرار أسر مع تمييز الابن المطابق
        if (!query.advancedMode && query.target == CivilRegistrySearchTarget.ALL && safeOffset == 0) {
            val childBundle = executeChildSearchBundle(
                db = db,
                rawQuery = query.quickQuery,
                cancellationSignal = cancellationSignal
            )
            if (childBundle.families.isNotEmpty()) {
                val merged = ArrayList<CivilRegistryRecord>(headResults.size + childBundle.families.size)
                val seenParentIds = HashSet<String>(headResults.size + childBundle.families.size)
                for (rec in headResults) {
                    val key = normalizeDigits(rec.nationalId).ifBlank { rec.stableKey }
                    if (seenParentIds.add(key)) {
                        merged.add(rec)
                    }
                }
                for (rec in childBundle.families) {
                    val key = normalizeDigits(rec.nationalId).ifBlank { rec.stableKey }
                    if (seenParentIds.add(key)) {
                        merged.add(rec)
                    }
                }
                return CivilRegistrySearchPage(
                    records = merged,
                    hasMore = hasMore,
                    offset = 0,
                    preloadedChildrenByParentId = childBundle.childrenByParentId,
                    matchedChildKeysByParentId = childBundle.matchedChildKeysByParentId,
                    matchedChildNamesByParentId = childBundle.matchedChildNamesByParentId
                )
            }
        }

        return CivilRegistrySearchPage(
            records = headResults,
            hasMore = hasMore,
            offset = safeOffset
        )
    }

    /**
     * تطبيع النص العربي ليتطابق حرفياً مع عمود children_fts.child_name_norm:
     * - أ/إ/آ/ٱ -> ا ، ة -> ه ، ى -> ي
     * - إزالة التشكيل والتطويل
     * - تحويل الأرقام العربية/الفارسية إلى 0-9
     * - تنظيف كافة رموز FTS الخاصة (" * - ( ) : ^ ' + / \ % _ ...) لمنع أي خطأ SQLite Syntax Error
     */
    fun normalizeArabicForFts(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return ""
        val sb = StringBuilder(trimmed.length)
        for (ch in trimmed) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                'أ', 'إ', 'آ', 'ٱ' -> sb.append('ا')
                'ة' -> sb.append('ه')
                'ى' -> sb.append('ي')
                'ـ', in '\u064B'..'\u065F', '\u0670' -> Unit
                '"', '*', '-', '(', ')', ':', '^', '\'', '+', '/', '\\', '%', '_', '?', '!', ',', '.', ';', '~', '[', ']', '{', '}', '`', '|', '=', '<', '>', '@', '#', '$', '&' -> sb.append(' ')
                else -> sb.append(ch)
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /**
     * بناء تعبير FTS4 MATCH آمن بصيغة Prefix لكل كلمة (مثلاً: "ريما محمد" -> "ريما* محمد*")
     */
    fun buildFts4MatchExpression(rawQuery: String): String {
        val normalized = normalizeArabicForFts(rawQuery)
        if (normalized.isEmpty()) return ""
        val tokens = normalized
            .split(Regex("\\s+"))
            .map { it.trim() }
            .filter { tok ->
                tok.isNotEmpty() &&
                    !tok.equals("AND", ignoreCase = true) &&
                    !tok.equals("OR", ignoreCase = true) &&
                    !tok.equals("NOT", ignoreCase = true) &&
                    !tok.equals("NEAR", ignoreCase = true)
            }
            .distinct()
            .take(6)
        if (tokens.isEmpty()) return ""
        return tokens.joinToString(" ") { "$it*" }
    }

    private fun executeChildSearchBundle(
        db: SQLiteDatabase,
        rawQuery: String,
        cancellationSignal: CancellationSignal?
    ): ChildSearchBundle {
        if (!hasTable(db, CivilRegistryChildrenSchema.TABLE_NAME)) {
            return ChildSearchBundle(emptyList(), emptyMap(), emptyMap(), emptyMap())
        }

        val trimmed = rawQuery.trim()
        if (trimmed.isEmpty()) {
            return ChildSearchBundle(emptyList(), emptyMap(), emptyMap(), emptyMap())
        }

        val normalizedDigits = normalizeDigits(trimmed)
        val isPureNumeric = normalizedDigits.isNotEmpty() &&
            trimmed.all { it.isDigit() || it in '٠'..'٩' || it in '۰'..'۹' || it == ' ' || it == '-' || it == '+' }

        val hits = if (isPureNumeric) {
            queryChildHitsById(db, normalizedDigits, cancellationSignal)
        } else {
            queryChildHitsByName(db, trimmed, cancellationSignal)
        }

        if (hits.isEmpty()) {
            return ChildSearchBundle(emptyList(), emptyMap(), emptyMap(), emptyMap())
        }

        // استخراج أرقام parent_id الفريدة بحد أقصى 30 أسرة بدون تكرار مع تجميع جميع الأبناء المطابقين لكل أسرة
        val orderedParentIds = ArrayList<String>(MAX_CHILD_MATCH_FAMILIES)
        val parentFallbackNameById = LinkedHashMap<String, String>()
        val matchedKeysByParent = LinkedHashMap<String, LinkedHashSet<String>>()
        val matchedNamesByParent = LinkedHashMap<String, LinkedHashSet<String>>()

        for (hit in hits) {
            val cleanParentId = hit.parentId
            if (cleanParentId.isBlank()) continue
            if (!matchedKeysByParent.containsKey(cleanParentId)) {
                if (orderedParentIds.size >= MAX_CHILD_MATCH_FAMILIES) continue
                orderedParentIds.add(cleanParentId)
                if (hit.parentName.isNotBlank()) {
                    parentFallbackNameById[cleanParentId] = hit.parentName
                }
            }
            matchedKeysByParent.getOrPut(cleanParentId) { LinkedHashSet() }.add(hit.matchIdentifier)
            if (hit.childName.isNotBlank()) {
                matchedNamesByParent.getOrPut(cleanParentId) { LinkedHashSet() }.add(hit.childName)
            }
        }

        if (orderedParentIds.isEmpty()) {
            return ChildSearchBundle(emptyList(), emptyMap(), emptyMap(), emptyMap())
        }

        // 1. جلب بيانات أرباب الأسر دفعة واحدة عبر IN (...)
        val parentsById = queryParentsBatchByIds(db, orderedParentIds, cancellationSignal)

        // 2. جلب جميع أبناء هذه الأسر دفعة واحدة عبر IN (...) ومرتبين بـ birth_date DESC (فهرس idx_children_parent_birth)
        val allChildren = queryChildrenByParentIdsChunk(
            db = db,
            parentIds = orderedParentIds,
            minBirthDateIso = null,
            maxBirthDateIso = null,
            cancellationSignal = cancellationSignal,
            enforceCivilRegistryAccessGuard = true
        )

        val childrenByParent = LinkedHashMap<String, MutableList<CivilRegistryChildRecord>>(orderedParentIds.size)
        for (pid in orderedParentIds) {
            childrenByParent[pid] = ArrayList()
        }
        for (child in allChildren) {
            val pid = normalizeDigits(child.parentId).ifBlank { child.parentId.trim() }
            childrenByParent.getOrPut(pid) { ArrayList() }.add(child)
        }

        // 3. بناء قائمة بطاقات الأسر الكاملة بدون تكرار بالترتيب المطابق
        val families = ArrayList<CivilRegistryRecord>(orderedParentIds.size)
        for (pid in orderedParentIds) {
            val foundParent = parentsById[pid]
            if (foundParent != null) {
                families.add(foundParent)
            } else {
                val fallbackName = parentFallbackNameById[pid].orEmpty()
                val firstChild = childrenByParent[pid]?.firstOrNull()
                families.add(
                    CivilRegistryRecord(
                        nationalId = pid,
                        name = fallbackName.ifBlank { firstChild?.parentName.orEmpty().ifBlank { "رب أسرة ($pid)" } },
                        birthDate = "",
                        maritalStatus = "",
                        deathStatus = "",
                        deathDate = "",
                        gender = "",
                        developmentPhone = "",
                        mobilePhone = "",
                        mainArea = firstChild?.region.orEmpty(),
                        familyMembersCount = "",
                        developmentApprovalStatus = "",
                        wifeName = "",
                        wifeNationalId = ""
                    )
                )
            }
        }

        return ChildSearchBundle(
            families = families,
            childrenByParentId = childrenByParent,
            matchedChildKeysByParentId = matchedKeysByParent,
            matchedChildNamesByParentId = matchedNamesByParent.mapValues { it.value.toList() }
        )
    }

    private fun queryChildHitsById(
        db: SQLiteDatabase,
        normalizedDigits: String,
        cancellationSignal: CancellationSignal?
    ): List<ChildHitRow> {
        val table = CivilRegistryChildrenSchema.TABLE_NAME
        val colParentId = CivilRegistryChildrenSchema.COL_PARENT_ID
        val colParentName = CivilRegistryChildrenSchema.COL_PARENT_NAME
        val colChildId = CivilRegistryChildrenSchema.COL_CHILD_ID
        val colId = CivilRegistryChildrenSchema.COL_ID
        val colChildName = CivilRegistryChildrenSchema.COL_CHILD_NAME

        val (whereClause, arg) = if (normalizedDigits.length >= 9) {
            "\"$colChildId\" = ?" to normalizedDigits.take(9)
        } else {
            "\"$colChildId\" LIKE ?" to "$normalizedDigits%"
        }

        val sql = "SELECT \"$colParentId\", \"$colParentName\", \"$colChildId\", \"$colId\", \"$colChildName\" " +
            "FROM \"$table\" WHERE $whereClause LIMIT $MAX_CHILD_MATCH_ROWS"

        val hits = ArrayList<ChildHitRow>(16)
        db.rawQuery(sql, arrayOf(arg), cancellationSignal).use { cursor ->
            while (cursor.moveToNext()) {
                hits.add(cursor.toChildHitRow())
            }
        }
        return hits
    }

    private fun queryChildHitsByName(
        db: SQLiteDatabase,
        rawQuery: String,
        cancellationSignal: CancellationSignal?
    ): List<ChildHitRow> {
        val table = CivilRegistryChildrenSchema.TABLE_NAME
        val ftsTable = CivilRegistryChildrenSchema.FTS_TABLE_NAME
        val ftsCol = CivilRegistryChildrenSchema.FTS_COL_CHILD_NAME_NORM
        val colParentId = CivilRegistryChildrenSchema.COL_PARENT_ID
        val colParentName = CivilRegistryChildrenSchema.COL_PARENT_NAME
        val colChildId = CivilRegistryChildrenSchema.COL_CHILD_ID
        val colId = CivilRegistryChildrenSchema.COL_ID
        val colChildName = CivilRegistryChildrenSchema.COL_CHILD_NAME

        // 1. المسار الفوري عبر FTS4 (children_fts.docid = children_registry.id)
        if (hasTable(db, ftsTable)) {
            val matchExpr = buildFts4MatchExpression(rawQuery)
            if (matchExpr.isNotEmpty()) {
                val ftsSql = """
                    SELECT c."$colParentId", c."$colParentName", c."$colChildId", c."$colId", c."$colChildName"
                    FROM "$ftsTable" AS f
                    JOIN "$table" AS c ON c."$colId" = f.docid
                    WHERE f."$ftsCol" MATCH ?
                    LIMIT $MAX_CHILD_MATCH_ROWS
                """.trimIndent()
                try {
                    val hits = ArrayList<ChildHitRow>(MAX_CHILD_MATCH_ROWS)
                    db.rawQuery(ftsSql, arrayOf(matchExpr), cancellationSignal).use { cursor ->
                        while (cursor.moveToNext()) {
                            hits.add(cursor.toChildHitRow())
                        }
                    }
                    return hits
                } catch (_: android.os.OperationCanceledException) {
                    throw android.os.OperationCanceledException()
                } catch (_: Throwable) {
                    // الرجوع الآمن إلى LIKE إذا كانت نسخة القاعدة تفتقر لتفعيل FTS4 أو بها خطأ في الجدول الافتراضي
                }
            }
        }

        // 2. الرجوع التلقائي الآمن لنسخ civil_registry.db القديمة التي لا تحتوي على children_fts
        val normalized = normalizeArabicForFts(rawQuery)
        val tokens = normalized.split(Regex("\\s+")).filter { it.isNotBlank() }.distinct().take(5)
        if (tokens.isEmpty()) return emptyList()

        val normColSql = "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(" +
            "COALESCE(\"$colChildName\", ''), 'أ', 'ا'), 'إ', 'ا'), 'آ', 'ا'), 'ٱ', 'ا'), 'ة', 'ه'), 'ى', 'ي'), 'ـ', '')"
        val whereClauses = tokens.joinToString(" AND ") { "$normColSql LIKE ?" }
        val args = tokens.map { "%$it%" }.toTypedArray()

        val fallbackSql = "SELECT \"$colParentId\", \"$colParentName\", \"$colChildId\", \"$colId\", \"$colChildName\" " +
            "FROM \"$table\" WHERE $whereClauses LIMIT $MAX_CHILD_MATCH_ROWS"

        val hits = ArrayList<ChildHitRow>(MAX_CHILD_MATCH_ROWS)
        db.rawQuery(fallbackSql, args, cancellationSignal).use { cursor ->
            while (cursor.moveToNext()) {
                hits.add(cursor.toChildHitRow())
            }
        }
        return hits
    }

    private fun queryParentsBatchByIds(
        db: SQLiteDatabase,
        parentIds: List<String>,
        cancellationSignal: CancellationSignal?
    ): Map<String, CivilRegistryRecord> {
        if (parentIds.isEmpty()) return emptyMap()
        val table = CivilRegistrySchema.TABLE_NAME
        val cols = CivilRegistrySchema.ALL_COLUMNS_SQL
        val colNatId = CivilRegistrySchema.COL_NATIONAL_ID
        val placeholders = parentIds.joinToString(",") { "?" }
        val sql = "SELECT $cols FROM \"$table\" WHERE \"$colNatId\" IN ($placeholders)"

        val map = HashMap<String, CivilRegistryRecord>(parentIds.size)
        db.rawQuery(sql, parentIds.toTypedArray(), cancellationSignal).use { cursor ->
            while (cursor.moveToNext()) {
                val rec = cursor.toCivilRegistryRecord()
                val key = normalizeDigits(rec.nationalId).ifBlank { rec.nationalId.trim() }
                if (key.isNotBlank() && !map.containsKey(key)) {
                    map[key] = rec
                }
            }
        }
        return map
    }

    private fun Cursor.toChildHitRow(): ChildHitRow {
        fun safeId(index: Int): String {
            if (index < 0 || isNull(index)) return ""
            val raw = getString(index)?.trim()?.removeSuffix(".0").orEmpty()
            return normalizeDigits(raw).ifBlank { raw }
        }

        fun safeRaw(index: Int): String {
            if (index < 0 || isNull(index)) return ""
            return getString(index)?.trim().orEmpty()
        }

        return ChildHitRow(
            parentId = safeId(0),
            parentName = safeRaw(1),
            childId = safeId(2),
            childRowId = if (!isNull(3)) getLong(3) else 0L,
            childName = safeRaw(4)
        )
    }

    fun queryTotalCountFast(db: SQLiteDatabase): Long {
        return try {
            db.rawQuery("SELECT COUNT(*) FROM ${CivilRegistrySchema.TABLE_NAME}", null).use { c ->
                if (c.moveToFirst()) c.getLong(0) else 0L
            }
        } catch (_: Throwable) {
            0L
        }
    }

    fun hasTable(db: SQLiteDatabase, tableName: String): Boolean {
        return try {
            db.rawQuery(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ? LIMIT 1",
                arrayOf(tableName)
            ).use { it.moveToFirst() }
        } catch (_: Throwable) {
            false
        }
    }

    fun hasView(db: SQLiteDatabase, viewName: String): Boolean {
        return try {
            db.rawQuery(
                "SELECT 1 FROM sqlite_master WHERE type = 'view' AND name = ? LIMIT 1",
                arrayOf(viewName)
            ).use { it.moveToFirst() }
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * قراءة فورية O(log N) لعدد سجلات جدول الأبناء (1.87 مليون سجل) دون مسح كامل للجدول
     */
    fun queryChildrenCountFast(db: SQLiteDatabase): Long {
        if (!hasTable(db, CivilRegistryChildrenSchema.TABLE_NAME)) return 0L
        return try {
            db.rawQuery(
                "SELECT COALESCE(MAX(\"${CivilRegistryChildrenSchema.COL_ID}\"), 0) FROM \"${CivilRegistryChildrenSchema.TABLE_NAME}\"",
                null
            ).use { c ->
                if (c.moveToFirst()) c.getLong(0) else 0L
            }
        } catch (_: Throwable) {
            0L
        }
    }

    /**
     * استعلام مفهرس فائق السرعة لجلب أبناء رب أسرة محدد عبر idx_children_parent_id
     * مع دعم فلترة نطاق تاريخ الميلاد (birth_date BETWEEN ? AND ?) بدون أي Full Table Scan
     */
    fun queryChildrenByParentId(
        db: SQLiteDatabase,
        parentId: String,
        minBirthDateIso: String? = null,
        maxBirthDateIso: String? = null,
        cancellationSignal: CancellationSignal? = null,
        enforceCivilRegistryAccessGuard: Boolean = true
    ): List<CivilRegistryChildRecord> {
        if (enforceCivilRegistryAccessGuard && !CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            return emptyList()
        }
        if (!hasTable(db, CivilRegistryChildrenSchema.TABLE_NAME)) {
            return emptyList()
        }

        val cleanParentId = normalizeDigits(parentId).ifBlank { parentId.trim() }
        if (cleanParentId.isBlank()) return emptyList()

        val table = CivilRegistryChildrenSchema.TABLE_NAME
        val cols = CivilRegistryChildrenSchema.ALL_COLUMNS_SQL
        val colParent = CivilRegistryChildrenSchema.COL_PARENT_ID
        val colBirth = CivilRegistryChildrenSchema.COL_BIRTH_DATE
        val colId = CivilRegistryChildrenSchema.COL_ID

        val hasDateRange = !minBirthDateIso.isNullOrBlank() && !maxBirthDateIso.isNullOrBlank()
        val sql: String
        val args: Array<String>
        if (hasDateRange) {
            sql = "SELECT $cols FROM \"$table\" WHERE \"$colParent\" = ? AND \"$colBirth\" BETWEEN ? AND ? " +
                "ORDER BY \"$colBirth\" DESC, \"$colId\" DESC"
            args = arrayOf(cleanParentId, minBirthDateIso.orEmpty().trim(), maxBirthDateIso.orEmpty().trim())
        } else {
            sql = "SELECT $cols FROM \"$table\" WHERE \"$colParent\" = ? " +
                "ORDER BY \"$colBirth\" DESC, \"$colId\" DESC"
            args = arrayOf(cleanParentId)
        }

        val results = ArrayList<CivilRegistryChildRecord>(8)
        try {
            db.rawQuery(sql, args, cancellationSignal).use { cursor ->
                while (cursor.moveToNext()) {
                    results.add(cursor.toCivilRegistryChildRecord())
                }
            }
        } catch (_: Throwable) {
            return emptyList()
        }
        return results
    }

    /**
     * استعلام دفعي مفهرس فائق السرعة عبر idx_children_parent_id لجلب أبناء دفعة أسر (حتى 500 أسرة في الاستعلام الواحد)
     * يتجنب N+1 queries ويحترم حد معاملات SQLite (999) مع دعم فلترة نطاق تاريخ الميلاد المفهرس.
     */
    fun queryChildrenByParentIdsChunk(
        db: SQLiteDatabase,
        parentIds: List<String>,
        minBirthDateIso: String? = null,
        maxBirthDateIso: String? = null,
        cancellationSignal: CancellationSignal? = null,
        enforceCivilRegistryAccessGuard: Boolean = false
    ): List<CivilRegistryChildRecord> {
        if (enforceCivilRegistryAccessGuard && !CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            return emptyList()
        }
        if (!hasTable(db, CivilRegistryChildrenSchema.TABLE_NAME)) {
            return emptyList()
        }

        val cleanParentIds = parentIds
            .map { normalizeDigits(it).ifBlank { it.trim() } }
            .filter { it.isNotBlank() }
            .distinct()
        if (cleanParentIds.isEmpty()) return emptyList()

        val table = CivilRegistryChildrenSchema.TABLE_NAME
        val cols = CivilRegistryChildrenSchema.ALL_COLUMNS_SQL
        val colParent = CivilRegistryChildrenSchema.COL_PARENT_ID
        val colBirth = CivilRegistryChildrenSchema.COL_BIRTH_DATE
        val colId = CivilRegistryChildrenSchema.COL_ID

        val hasDateRange = !minBirthDateIso.isNullOrBlank() && !maxBirthDateIso.isNullOrBlank()
        val placeholders = cleanParentIds.joinToString(",") { "?" }
        val argsList = ArrayList<String>(cleanParentIds.size + 2)
        argsList.addAll(cleanParentIds)

        val sql = if (hasDateRange) {
            argsList.add(minBirthDateIso.orEmpty().trim())
            argsList.add(maxBirthDateIso.orEmpty().trim())
            "SELECT $cols FROM \"$table\" WHERE \"$colParent\" IN ($placeholders) AND \"$colBirth\" BETWEEN ? AND ? " +
                "ORDER BY \"$colParent\" ASC, \"$colBirth\" DESC, \"$colId\" DESC"
        } else {
            "SELECT $cols FROM \"$table\" WHERE \"$colParent\" IN ($placeholders) " +
                "ORDER BY \"$colParent\" ASC, \"$colBirth\" DESC, \"$colId\" DESC"
        }

        val results = ArrayList<CivilRegistryChildRecord>(cleanParentIds.size * 2)
        try {
            db.rawQuery(sql, argsList.toTypedArray(), cancellationSignal).use { cursor ->
                while (cursor.moveToNext()) {
                    results.add(cursor.toCivilRegistryChildRecord())
                }
            }
        } catch (_: Throwable) {
            return emptyList()
        }
        return results
    }

    private fun buildQuickSearchQuery(
        rawQuery: String,
        scope: CivilRegistrySearchScope,
        fetchLimit: Int,
        offset: Int
    ): Pair<String, Array<String>> {
        val trimmed = rawQuery.trim()
        if (trimmed.isEmpty()) return "" to emptyArray()

        val normalizedDigits = normalizeDigits(trimmed)
        val isPureNumeric = normalizedDigits.isNotEmpty() &&
            trimmed.all { it.isDigit() || it in '٠'..'٩' || it == ' ' || it == '-' || it == '+' }

        val cols = CivilRegistrySchema.ALL_COLUMNS_SQL
        val table = CivilRegistrySchema.TABLE_NAME

        return when (scope) {
            CivilRegistrySearchScope.NATIONAL_ID -> {
                if (normalizedDigits.isEmpty()) return "" to emptyArray()
                val (clause, arg) = idMatchClause(CivilRegistrySchema.COL_NATIONAL_ID, normalizedDigits)
                "SELECT $cols FROM $table WHERE $clause LIMIT ? OFFSET ?" to
                    arrayOf(arg, fetchLimit.toString(), offset.toString())
            }

            CivilRegistrySearchScope.WIFE_NATIONAL_ID -> {
                if (normalizedDigits.isEmpty()) return "" to emptyArray()
                val (clause, arg) = idMatchClause(CivilRegistrySchema.COL_WIFE_NATIONAL_ID, normalizedDigits)
                "SELECT $cols FROM $table WHERE $clause LIMIT ? OFFSET ?" to
                    arrayOf(arg, fetchLimit.toString(), offset.toString())
            }

            CivilRegistrySearchScope.NAME -> {
                val (whereSql, whereArgs) = buildTokenizedNameClause(
                    CivilRegistrySchema.COL_NAME,
                    trimmed,
                    preferPrefixFirst = true
                )
                "SELECT $cols FROM $table WHERE $whereSql LIMIT ? OFFSET ?" to
                    (whereArgs + arrayOf(fetchLimit.toString(), offset.toString()))
            }

            CivilRegistrySearchScope.WIFE_NAME -> {
                val (whereSql, whereArgs) = buildTokenizedNameClause(
                    CivilRegistrySchema.COL_WIFE_NAME,
                    trimmed,
                    preferPrefixFirst = false
                )
                "SELECT $cols FROM $table WHERE $whereSql LIMIT ? OFFSET ?" to
                    (whereArgs + arrayOf(fetchLimit.toString(), offset.toString()))
            }

            CivilRegistrySearchScope.PHONES -> {
                val phoneTokens = buildPhoneSearchVariants(normalizedDigits.ifEmpty { trimmed })
                val (whereSql, whereArgs) = buildPhoneColumnsClause(phoneTokens)
                "SELECT $cols FROM $table WHERE $whereSql LIMIT ? OFFSET ?" to
                    (whereArgs + arrayOf(fetchLimit.toString(), offset.toString()))
            }

            CivilRegistrySearchScope.ALL -> {
                if (isPureNumeric) {
                    val (citizenIdClause, citizenArg) = idMatchClause(CivilRegistrySchema.COL_NATIONAL_ID, normalizedDigits)
                    val (wifeIdClause, wifeArg) = idMatchClause(CivilRegistrySchema.COL_WIFE_NATIONAL_ID, normalizedDigits)
                    val phoneVariants = buildPhoneSearchVariants(normalizedDigits)
                    val (phoneClause, phoneArgs) = buildPhoneColumnsClause(phoneVariants)

                    val sql = """
                        SELECT $cols FROM (
                            SELECT $cols FROM $table WHERE $citizenIdClause
                            UNION
                            SELECT $cols FROM $table WHERE $wifeIdClause
                            UNION
                            SELECT $cols FROM $table WHERE $phoneClause
                        ) LIMIT ? OFFSET ?
                    """.trimIndent()

                    val allArgs = buildList {
                        add(citizenArg)
                        add(wifeArg)
                        addAll(phoneArgs)
                        add(fetchLimit.toString())
                        add(offset.toString())
                    }.toTypedArray()

                    sql to allArgs
                } else {
                    val (nameWhere, nameArgs) = buildTokenizedNameClause(
                        CivilRegistrySchema.COL_NAME,
                        trimmed,
                        preferPrefixFirst = true
                    )
                    val (wifeWhere, wifeArgs) = buildTokenizedNameClause(
                        CivilRegistrySchema.COL_WIFE_NAME,
                        trimmed,
                        preferPrefixFirst = false
                    )

                    val sql = """
                        SELECT $cols FROM (
                            SELECT $cols FROM $table WHERE $nameWhere
                            UNION
                            SELECT $cols FROM $table WHERE $wifeWhere
                        ) LIMIT ? OFFSET ?
                    """.trimIndent()

                    val allArgs = buildList {
                        addAll(nameArgs)
                        addAll(wifeArgs)
                        add(fetchLimit.toString())
                        add(offset.toString())
                    }.toTypedArray()

                    sql to allArgs
                }
            }
        }
    }

    private fun buildAdvancedMultiFieldQuery(
        query: CivilRegistrySearchQuery,
        fetchLimit: Int,
        offset: Int
    ): Pair<String, Array<String>> {
        val clauses = mutableListOf<String>()
        val args = mutableListOf<String>()

        val natDigits = normalizeDigits(query.nationalIdFilter)
        if (natDigits.isNotEmpty()) {
            val (clause, arg) = idMatchClause(CivilRegistrySchema.COL_NATIONAL_ID, natDigits)
            clauses.add(clause)
            args.add(arg)
        }

        val wifeDigits = normalizeDigits(query.wifeNationalIdFilter)
        if (wifeDigits.isNotEmpty()) {
            val (clause, arg) = idMatchClause(CivilRegistrySchema.COL_WIFE_NATIONAL_ID, wifeDigits)
            clauses.add(clause)
            args.add(arg)
        }

        val cleanName = query.nameFilter.trim()
        if (cleanName.isNotEmpty()) {
            val (nameSql, nameArgs) = buildTokenizedNameClause(
                CivilRegistrySchema.COL_NAME,
                cleanName,
                preferPrefixFirst = true
            )
            clauses.add("($nameSql)")
            args.addAll(nameArgs)
        }

        val cleanWifeName = query.wifeNameFilter.trim()
        if (cleanWifeName.isNotEmpty()) {
            val (wifeSql, wifeArgs) = buildTokenizedNameClause(
                CivilRegistrySchema.COL_WIFE_NAME,
                cleanWifeName,
                preferPrefixFirst = false
            )
            clauses.add("($wifeSql)")
            args.addAll(wifeArgs)
        }

        val phoneDigits = normalizeDigits(query.phoneFilter)
        if (phoneDigits.isNotEmpty()) {
            val (phoneSql, phoneArgs) = buildPhoneColumnsClause(buildPhoneSearchVariants(phoneDigits))
            clauses.add("($phoneSql)")
            args.addAll(phoneArgs)
        }

        if (clauses.isEmpty()) return "" to emptyArray()

        val sql = "SELECT ${CivilRegistrySchema.ALL_COLUMNS_SQL} FROM ${CivilRegistrySchema.TABLE_NAME} " +
            "WHERE ${clauses.joinToString(" AND ")} LIMIT ? OFFSET ?"

        args.add(fetchLimit.toString())
        args.add(offset.toString())
        return sql to args.toTypedArray()
    }

    private fun idMatchClause(columnName: String, cleanDigits: String): Pair<String, String> {
        return if (cleanDigits.length >= 9) {
            "\"$columnName\" = ?" to cleanDigits.take(9)
        } else {
            "\"$columnName\" LIKE ?" to "$cleanDigits%"
        }
    }

    private fun buildTokenizedNameClause(
        columnName: String,
        rawInput: String,
        preferPrefixFirst: Boolean
    ): Pair<String, Array<String>> {
        val tokens = rawInput.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.take(5)
        if (tokens.isEmpty()) return "1=0" to emptyArray()

        val sqlParts = mutableListOf<String>()
        val args = mutableListOf<String>()
        tokens.forEachIndexed { index, token ->
            sqlParts.add("\"$columnName\" LIKE ?")
            val pattern = if (index == 0 && preferPrefixFirst) "$token%" else "%$token%"
            args.add(pattern)
        }
        return sqlParts.joinToString(" AND ") to args.toTypedArray()
    }

    private fun buildPhoneSearchVariants(cleanDigits: String): List<String> {
        val trimmed = cleanDigits.removePrefix("970").removePrefix("972")
        val variants = linkedSetOf<String>()
        if (trimmed.isNotEmpty()) {
            variants.add(trimmed)
            if (trimmed.startsWith("0") && trimmed.length > 1) {
                variants.add(trimmed.removePrefix("0"))
            } else if (!trimmed.startsWith("0") && trimmed.length >= 4) {
                variants.add("0$trimmed")
            }
        }
        return variants.toList()
    }

    private fun buildPhoneColumnsClause(variants: List<String>): Pair<String, Array<String>> {
        if (variants.isEmpty()) return "1=0" to emptyArray()
        val parts = mutableListOf<String>()
        val args = mutableListOf<String>()
        val mobileCol = CivilRegistrySchema.COL_MOBILE_PHONE
        val devCol = CivilRegistrySchema.COL_DEV_PHONE

        variants.forEach { token ->
            val pattern = "%$token%"
            parts.add("\"$mobileCol\" LIKE ?")
            args.add(pattern)
            parts.add("\"$devCol\" LIKE ?")
            args.add(pattern)
        }
        return parts.joinToString(" OR ") to args.toTypedArray()
    }

    private fun normalizeDigits(input: String): String {
        val cleaned = input.trim().removeSuffix(".0")
        val sb = StringBuilder(cleaned.length)
        for (ch in cleaned) {
            when (ch) {
                in '0'..'9' -> sb.append(ch)
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
            }
        }
        return sb.toString()
    }

    private fun Cursor.toCivilRegistryRecord(): CivilRegistryRecord {
        fun safeStr(index: Int): String {
            if (index < 0 || isNull(index)) return ""
            return getString(index)?.trim()?.removeSuffix(".0") ?: ""
        }

        fun safeRaw(index: Int): String {
            if (index < 0 || isNull(index)) return ""
            return getString(index)?.trim().orEmpty()
        }

        return CivilRegistryRecord(
            nationalId = safeStr(0),
            name = safeRaw(1),
            birthDate = safeRaw(2),
            maritalStatus = safeRaw(3),
            deathStatus = safeRaw(4),
            deathDate = safeRaw(5),
            gender = safeRaw(6),
            developmentPhone = safeStr(7),
            mobilePhone = safeStr(8),
            mainArea = safeRaw(9),
            familyMembersCount = safeStr(10),
            developmentApprovalStatus = safeRaw(11),
            wifeName = safeRaw(12),
            wifeNationalId = safeStr(13)
        )
    }

    private fun Cursor.toCivilRegistryChildRecord(): CivilRegistryChildRecord {
        fun safeId(index: Int): String {
            if (index < 0 || isNull(index)) return ""
            return normalizeDigits(getString(index)?.trim()?.removeSuffix(".0").orEmpty())
                .ifBlank { getString(index)?.trim()?.removeSuffix(".0").orEmpty() }
        }

        fun safeRaw(index: Int): String {
            if (index < 0 || isNull(index)) return ""
            return getString(index)?.trim().orEmpty()
        }

        val rowId = if (!isNull(0)) getLong(0) else 0L
        return CivilRegistryChildRecord(
            id = rowId,
            parentId = safeId(1),
            parentName = safeRaw(2),
            childId = safeId(3),
            childName = safeRaw(4),
            gender = safeRaw(5),
            socialStatus = safeRaw(6),
            region = safeRaw(7),
            city = safeRaw(8),
            birthDate = safeRaw(9),
            isWestGaza = safeRaw(10)
        )
    }
}
