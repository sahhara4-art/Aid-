package com.humanitarian.aidmanagement.ui.screens.delivery

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.util.AidCategoryCatalog
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.BulkA4VouchersDialog
import com.humanitarian.aidmanagement.ui.components.CameraScannerDialog
import com.humanitarian.aidmanagement.ui.components.SignaturePadDialog
import com.humanitarian.aidmanagement.ui.components.SignatureStorageHelper
import com.humanitarian.aidmanagement.ui.components.SyncDetailsDialog
import com.humanitarian.aidmanagement.ui.components.SyncStatusBanner
import com.humanitarian.aidmanagement.util.BulkVoucherBeneficiaryItem
import com.humanitarian.aidmanagement.util.OfflineVoucherCrypto
import com.humanitarian.aidmanagement.util.WhatsAppVoucherCardGenerator
import com.humanitarian.aidmanagement.warehouse.WarehouseErpStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeliveryScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    viewModel: DeliveryViewModel = viewModel(
        factory = DeliveryViewModel.Factory(repository)
    )
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val canDeliver by viewModel.canDeliver.collectAsStateWithLifecycle()
    val canDeleteRecord by viewModel.canDeleteRecord.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val warehouseSyncScope = rememberCoroutineScope()
    val warehouseActorName = remember(currentUser) {
        currentUser?.fullName?.takeIf { it.isNotBlank() }
            ?: currentUser?.UserName?.takeIf { it.isNotBlank() }
            ?: "موظف التسليم"
    }

    val rawAidRecords by viewModel.rawAidRecords.collectAsStateWithLifecycle()
    val projectFamiliesMap by viewModel.projectFamilies.collectAsStateWithLifecycle()
    val aidTypes: List<AidTypeEntity> by viewModel.aidTypes.collectAsStateWithLifecycle()
    val projects: List<ProjectEntity> by viewModel.projects.collectAsStateWithLifecycle()
    val localities by repository.getLocalities().collectAsStateWithLifecycle(initialValue = emptyList())
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()
    val statusFilterOptions by viewModel.statusFilterOptions.collectAsStateWithLifecycle()

    val familyMap: Map<Long, FamilyEntity> = projectFamiliesMap
    val aidTypeMap: Map<Int, AidTypeEntity> = remember(aidTypes) { aidTypes.associateBy { aidType: AidTypeEntity -> aidType.aidTypeID } }
    val projectMap: Map<Long, ProjectEntity> = remember(projects) { projects.associateBy { prj: ProjectEntity -> prj.projectID } }
    val localitiesMap = remember(localities) { localities.associate { it.LocalityID to it.LocalityName } }

    // عزل سجلات المساعدات جغرافياً: المستخدم المقيد بالمحلية أو الشعبة يرى حصراً مستفيدي نطاقه
    val aidRecords = remember(rawAidRecords, familyMap, currentUser, localitiesMap) {
        val extraLocIds = repository.getCurrentUserLocalityIds()
        rawAidRecords.filter { record ->
            val fam = familyMap[record.familyID]
            fam != null && com.humanitarian.aidmanagement.security.AccessControlManager.isFamilyAllowed(
                family = fam,
                localitiesMap = localitiesMap,
                extraAllowedLocalityIds = extraLocIds
            )
        }
    }

    var isProjectDropdownExpanded by remember { mutableStateOf(false) }

    // تحديد المشروع النشط الافتراضي تلقائياً عند تحميل قائمة المشاريع
    LaunchedEffect(projects) {
        if (projects.isNotEmpty() && (uiState.selectedProjectId == null || projects.none { it.projectID == uiState.selectedProjectId })) {
            viewModel.selectProject(projects.first().projectID)
        }
    }

    // تصفية السجلات حصراً للمشروع المحدد حالياً (نظام تسليم مرتبط بمشروع واحد)
    val projectAidRecords = remember(aidRecords, uiState.selectedProjectId) {
        if (uiState.selectedProjectId == null) emptyList()
        else aidRecords.filter { it.projectID == uiState.selectedProjectId }
    }

    val pendingProjectRecords = remember(projectAidRecords) {
        projectAidRecords.filter {
            it.recipientStatus.trim() !in setOf("مستفيد", "تم التسليم", "مستلم")
        }
    }

    // حوارات التسليم، سند الاستلام، التراجع الصارم، التسليم الجماعي، والمسح
    var recordToDeliver by remember { mutableStateOf<AidRecordEntity?>(null) }
    var recordForReceipt by remember { mutableStateOf<AidRecordEntity?>(null) }
    var recordToUndo by remember { mutableStateOf<AidRecordEntity?>(null) }
    var undoReasonText by remember { mutableStateOf("") }
    var undoReasonError by remember { mutableStateOf(false) }

    var showBulkDeliverDialog by remember { mutableStateOf(false) }
    var bulkDirectReason by remember { mutableStateOf("") }
    var bulkReasonError by remember { mutableStateOf(false) }

    var showScannerDialog by remember { mutableStateOf(false) }
    var showSyncDialog by remember { mutableStateOf(false) }
    var showBulkA4VouchersDialog by remember { mutableStateOf(false) }
    var isRapidScanMode by remember { mutableStateOf(false) }
    var showSignaturePadForDelivery by remember { mutableStateOf(false) }
    var pendingSignedDelivery by remember { mutableStateOf<PendingSignedDelivery?>(null) }
    var recordToEditSignature by remember { mutableStateOf<AidRecordEntity?>(null) }
    var signatureRefreshVersion by remember { mutableStateOf(0) }
    var lastRapidScannedText by remember { mutableStateOf("") }
    var lastRapidScanTimestamp by remember { mutableStateOf(0L) }
    val rapidScanToneGenerator = remember {
        runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100) }.getOrNull()
    }
    DisposableEffect(Unit) {
        onDispose {
            runCatching { rapidScanToneGenerator?.release() }
        }
    }

    val scope = rememberCoroutineScope()

    // تصفية السجلات المعروضة للمشروع المحدد بالاعتماد البارز على الاسم الرباعي ورقم الهوية الوطنية
    val filteredRecords = remember(projectAidRecords, uiState.searchQuery, uiState.selectedStatusFilter, familyMap, aidTypeMap, projectMap) {
        val query = uiState.searchQuery.trim()
        projectAidRecords.filter { record ->
            val family = familyMap[record.familyID]
            val fullName = family?.name ?: ""
            val nationalId = family?.nationalID ?: ""
            val primaryPhone = family?.primary_phone ?: ""
            val altPhone1 = family?.alternative_phone_1 ?: ""
            val altPhone2 = family?.alternative_phone_2 ?: ""
            val wifeName = family?.wifeName ?: ""
            val wifeNationalId = family?.wifeNationalID ?: ""
            val resolvedCategoryName = AidCategoryCatalog.resolveDisplayName(
                aidTypeId = record.aidTypeID,
                aidTypeMap = aidTypeMap,
                projectAidTypeId = projectMap[record.projectID]?.aidTypeID,
                fallbackLabel = ""
            )

            // البحث الشامل: الاسم، الهوية، الجوال، بيانات الزوجة، ونوع المساعدة
            val matchesSearch = query.isBlank() ||
                fullName.contains(query, ignoreCase = true) ||
                nationalId.contains(query) ||
                primaryPhone.contains(query) ||
                altPhone1.contains(query) ||
                altPhone2.contains(query) ||
                wifeName.contains(query, ignoreCase = true) ||
                wifeNationalId.contains(query) ||
                resolvedCategoryName.contains(query, ignoreCase = true)

            // تصنيف الحالات وفق الدلالات المعتمدة ('مرشح' مقابل 'مستفيد'/'تم التسليم'/'مستلم')
            val isDelivered = record.recipientStatus.trim() in setOf("مستفيد", "تم التسليم", "مستلم")
            val isReverted = record.recipientStatus.trim() == "مرشح" &&
                (record.notes?.contains("تم التراجع عن التسليم") == true || record.notes?.contains("سبب التراجع") == true)

            val matchesStatus = if (uiState.selectedStatusFilter == "الكل" || uiState.selectedStatusFilter.isBlank()) {
                true
            } else {
                record.recipientStatus.trim() == uiState.selectedStatusFilter.trim()
            }

            matchesSearch && matchesStatus
        }
    }

    // مؤشرات الإنجاز الدقيقة الخاصة بالمشروع المحدد حصراً
    val totalCount = projectAidRecords.size
    val deliveredCount = projectAidRecords.count {
        it.recipientStatus.trim() in setOf("مستفيد", "تم التسليم", "مستلم")
    }
    val revertedCount = projectAidRecords.count {
        it.recipientStatus.trim() == "مرشح" && (it.notes?.contains("تم التراجع عن التسليم") == true || it.notes?.contains("سبب التراجع") == true)
    }
    val pendingCount = totalCount - deliveredCount
    val deliveryRate = if (totalCount > 0) (deliveredCount * 100 / totalCount) else 0

    // مراقبة التمرير للطي التلقائي للرأس (Collapsible Header)
    val listState = rememberLazyListState()
    val isHeaderVisible by remember { derivedStateOf { listState.firstVisibleItemIndex == 0 } }

    val glassBackgroundBrush = remember {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFFE6F4EE),
                Color(0xFFEDF6FC),
                Color(0xFFF6F9FC)
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "تسليم وصرف المساعدات الميدانية",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "نقطة التوزيع وتوثيق الاستلام بالباركود",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        viewModel.resetFilters()
                        onNavigateBack()
                    }) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { showSyncDialog = true }) {
                        Icon(
                            imageVector = if (syncState.isOnline) Icons.Default.CloudSync else Icons.Default.CloudOff,
                            contentDescription = "التزامن والعمل دون اتصال",
                            tint = if (syncState.isOnline) MaterialTheme.colorScheme.primary else Color(0xFFF59E0B)
                        )
                    }
                    IconButton(onClick = { showScannerDialog = true }) {
                        Icon(Icons.Default.Search, contentDescription = "مسح باركود الهوية", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White.copy(alpha = 0.85f),
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(glassBackgroundBrush)
                .padding(paddingValues)
                .padding(horizontal = 8.dp)
        ) {
            // شريط حالة المزامنة والعمل دون اتصال
            SyncStatusBanner(
                repository = repository,
                onOpenSyncDetails = { showSyncDialog = true }
            )

            Spacer(modifier = Modifier.height(6.dp))

            // ==================== القسم القابل للطي التلقائي (بطاقة المشروع + الإحصائيات) ====================
            AnimatedVisibility(
                visible = isHeaderVisible,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // 1. بطاقة اختيار المشروع الزجاجية المضغوطة
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.7f))
                            .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Assignment,
                                        contentDescription = null,
                                        tint = Color(0xFF047857),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = "المشروع الإنساني النشط:",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0F172A)
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFDCFCE7)
                                ) {
                                    Text(
                                        text = "مشروع محدد حصراً",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF065F46),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Box(modifier = Modifier.fillMaxWidth()) {
                                val currentProject = projects.firstOrNull { it.projectID == uiState.selectedProjectId }
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { isProjectDropdownExpanded = true },
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.White.copy(alpha = 0.65f),
                                    border = BorderStroke(1.dp, Color(0xFFCBD5E1).copy(alpha = 0.6f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 7.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = currentProject?.projectName ?: "اضغط لاختيار المشروع الإنساني",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = Color(0xFF0F172A),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )
                                            if (currentProject != null) {
                                                Text(
                                                    text = "• #${currentProject.projectNumber}",
                                                    fontSize = 11.sp,
                                                    color = Color(0xFF475569),
                                                    maxLines = 1
                                                )
                                            }
                                        }
                                        Icon(
                                            Icons.Default.ArrowDropDown,
                                            contentDescription = null,
                                            tint = Color(0xFF047857),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                DropdownMenu(
                                    expanded = isProjectDropdownExpanded,
                                    onDismissRequest = { isProjectDropdownExpanded = false },
                                    modifier = Modifier.fillMaxWidth(0.9f)
                                ) {
                                    for (prj: ProjectEntity in projects) {
                                        DropdownMenuItem(
                                            text = {
                                                Column {
                                                    Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                    Text(
                                                        "${prj.projectNumber} - ${prj.fundingInstitution}",
                                                        fontSize = 10.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            },
                                            onClick = {
                                                viewModel.selectProject(prj.projectID)
                                                isProjectDropdownExpanded = false
                                            },
                                            leadingIcon = {
                                                Icon(
                                                    imageVector = if (prj.projectID == uiState.selectedProjectId) Icons.Default.CheckCircle else Icons.Default.Folder,
                                                    contentDescription = null,
                                                    tint = if (prj.projectID == uiState.selectedProjectId) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 2. صف الإحصائيات السريعة الزجاجي المضغوط (KPIs)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.7f))
                            .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp, vertical = 7.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CompactKpiItem("الإجمالي", "$totalCount", Color(0xFF0F172A))
                            VerticalDivider(modifier = Modifier.height(22.dp), color = Color(0xFFCBD5E1).copy(alpha = 0.6f))
                            CompactKpiItem("تم التسليم", "$deliveredCount", Color(0xFF059669))
                            VerticalDivider(modifier = Modifier.height(22.dp), color = Color(0xFFCBD5E1).copy(alpha = 0.6f))
                            CompactKpiItem("بانتظار", "$pendingCount", Color(0xFFD97706))
                            VerticalDivider(modifier = Modifier.height(22.dp), color = Color(0xFFCBD5E1).copy(alpha = 0.6f))
                            CompactKpiItem("تراجع", "$revertedCount", Color(0xFFDC2626))
                            VerticalDivider(modifier = Modifier.height(22.dp), color = Color(0xFFCBD5E1).copy(alpha = 0.6f))
                            CompactKpiItem("الإنجاز", "$deliveryRate%", Color(0xFF0284C7))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // ==================== شريط البحث المعلق (Pinned) بالنمط الزجاجي المضغوط ====================
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.7f))
                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = uiState.searchQuery,
                        onValueChange = { viewModel.setSearchQuery(it) },
                        placeholder = {
                            Text(
                                "ابحث بالاسم، الهوية، الجوال، أو بيانات الزوجة...",
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Search,
                                contentDescription = null,
                                tint = Color(0xFF059669),
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (uiState.searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { viewModel.setSearchQuery("") },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "مسح", modifier = Modifier.size(16.dp))
                                    }
                                }
                                IconButton(
                                    onClick = { showScannerDialog = true },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        Icons.Default.CameraAlt,
                                        contentDescription = "مسح الكاميرا",
                                        tint = Color(0xFF059669),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White.copy(alpha = 0.75f),
                            unfocusedContainerColor = Color.White.copy(alpha = 0.55f),
                            focusedBorderColor = Color(0xFF10B981).copy(alpha = 0.7f),
                            unfocusedBorderColor = Color.White.copy(alpha = 0.6f)
                        )
                    )

                    // أزرار تصفية الحالة الديناميكية + عداد النتائج في سطر مضغوط
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        LazyRow(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(statusFilterOptions, key = { it }) { filterLabel ->
                                val selected = uiState.selectedStatusFilter == filterLabel
                                FilterChip(
                                    selected = selected,
                                    onClick = { viewModel.setStatusFilter(filterLabel) },
                                    label = {
                                        Text(
                                            text = filterLabel,
                                            fontSize = 11.sp,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFDCFCE7),
                                        selectedLabelColor = Color(0xFF065F46),
                                        containerColor = Color.White.copy(alpha = 0.55f)
                                    ),
                                    modifier = Modifier.height(30.dp)
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF0F172A).copy(alpha = 0.06f)
                        ) {
                            Text(
                                text = "${filteredRecords.size} سجل",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF334155),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // مفتاح تبديل وضع المسح السريع المتتالي للتحقق الفوري من القسائم المشفّرة
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isRapidScanMode) Color(0xFFDCFCE7) else Color.White.copy(alpha = 0.6f))
                            .border(
                                1.dp,
                                if (isRapidScanMode) Color(0xFF10B981) else Color(0xFFCBD5E1).copy(alpha = 0.6f),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "وضع المسح السريع المتتالي",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isRapidScanMode) Color(0xFF065F46) else Color(0xFF0F172A)
                            )
                            Text(
                                text = if (isRapidScanMode) {
                                    "مفعّل: تحقق فوري من قسيمة QR وتسليم تلقائي متتالي"
                                } else {
                                    "عند التفعيل يتم التسليم تلقائياً مع صوت تأكيد وإبقاء الماسح جاهزاً"
                                },
                                fontSize = 10.sp,
                                color = if (isRapidScanMode) Color(0xFF047857) else Color(0xFF64748B),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Switch(
                            checked = isRapidScanMode,
                            onCheckedChange = { isRapidScanMode = it }
                        )
                    }

                    if (canDeliver && uiState.selectedProjectId != null && pendingProjectRecords.isNotEmpty()) {
                        Button(
                            onClick = {
                                bulkDirectReason = ""
                                bulkReasonError = false
                                showBulkDeliverDialog = true
                            },
                            enabled = !uiState.isBulkDelivering,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF059669),
                                contentColor = Color.White,
                                disabledContainerColor = Color(0xFF059669).copy(alpha = 0.45f)
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 7.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(38.dp)
                        ) {
                            if (uiState.isBulkDelivering) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "جاري تسليم المرشحين...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.DoneAll,
                                    contentDescription = null,
                                    modifier = Modifier.size(17.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تسليم جميع المرشحين (${pendingProjectRecords.size})",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    if (uiState.selectedProjectId != null && projectAidRecords.isNotEmpty()) {
                        OutlinedButton(
                            onClick = { showBulkA4VouchersDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFF059669)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color(0xFFECFDF5),
                                contentColor = Color(0xFF065F46)
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(36.dp)
                        ) {
                            Text(
                                text = "🪪 طباعة بطاقات A4",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            if (uiState.actionMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFDCFCE7).copy(alpha = 0.9f)),
                    border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = uiState.actionMessage ?: "", color = Color(0xFF065F46), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        IconButton(onClick = { viewModel.clearActionMessage() }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color(0xFF065F46), modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            if (uiState.errorMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2).copy(alpha = 0.95f)),
                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = uiState.errorMessage ?: "", color = Color(0xFF991B1B), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        IconButton(onClick = { viewModel.clearActionMessage() }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (filteredRecords.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (uiState.selectedProjectId == null) "الرجاء اختيار مشروع نشط أولاً" else "لا توجد سجلات تسليم أو ترشيح تطابق البحث الحالي",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredRecords, key = { it.aidRecordID }) { record ->
                        val family = familyMap[record.familyID]
                        val project = projectMap[record.projectID]
                        val aidTypeName = AidCategoryCatalog.resolveDisplayName(
                            aidTypeId = record.aidTypeID,
                            aidTypeMap = aidTypeMap,
                            projectAidTypeId = project?.aidTypeID,
                            fallbackLabel = "مساعدة إغاثية"
                        )
                        val projectNumber = project?.projectNumber ?: "مشروع #${record.projectID}"
                        val isDelivered = record.recipientStatus.trim() in setOf("مستفيد", "تم التسليم", "مستلم")
                        val isReverted = record.recipientStatus.trim() == "مرشح" &&
                            (record.notes?.contains("تم التراجع عن التسليم") == true || record.notes?.contains("سبب التراجع") == true)
                        val familyNationalId = family?.nationalID?.trim() ?: ""
                        val hasSavedSignature = remember(record.projectID, familyNationalId, signatureRefreshVersion) {
                            familyNationalId.isNotBlank() &&
                                SignatureStorageHelper.getSignatureFile(
                                    context = context,
                                    projectId = record.projectID.toString(),
                                    nationalId = familyNationalId
                                ) != null
                        }

                        DeliveryCardItem(
                            record = record,
                            family = family,
                            aidTypeName = aidTypeName,
                            projectNumber = projectNumber,
                            isDelivered = isDelivered,
                            isReverted = isReverted,
                            hasSavedSignature = hasSavedSignature,
                            canDeliver = canDeliver,
                            canDelete = canDeleteRecord,
                            onDeliverClick = {
                                showSignaturePadForDelivery = false
                                recordToDeliver = record
                            },
                            onShareWhatsAppVoucher = {
                                if (familyNationalId.isBlank()) {
                                    Toast.makeText(
                                        context,
                                        "لا يمكن إصدار البطاقة لعدم توفر رقم هوية للمستفيد",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    scope.launch {
                                        val shareResult = withContext(Dispatchers.IO) {
                                            WhatsAppVoucherCardGenerator.shareVoucherCardViaWhatsApp(
                                                context = context,
                                                projectId = record.projectID.toString(),
                                                projectName = project?.projectName ?: "مشروع #${record.projectID}",
                                                pickupLocation = record.warehouse.ifBlank { "المستودع الرئيسي" },
                                                familyNationalId = familyNationalId,
                                                beneficiaryName = family?.name ?: ""
                                            )
                                        }
                                        shareResult.onFailure { err ->
                                            Toast.makeText(
                                                context,
                                                "تعذر إنشاء أو مشاركة بطاقة واتساب: ${err.message ?: "خطأ غير متوقع"}",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                                }
                            },
                            onReceiptClick = { recordForReceipt = record },
                            onEditSignatureClick = {
                                if (familyNationalId.isBlank()) {
                                    Toast.makeText(
                                        context,
                                        "لا يمكن إضافة توقيع لعدم توفر رقم هوية للمستفيد",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    recordToEditSignature = record
                                }
                            },
                            onUndoClick = {
                                recordToUndo = record
                                undoReasonText = ""
                                undoReasonError = false
                            },
                            onDeleteClick = {
                                viewModel.deleteAidRecord(record.aidRecordID)
                            }
                        )
                    }
                }
            }
        }
    }

    // ==================== حوار تأكيد التسليم والصرف والتعبئة التلقائية ====================
    if (recordToDeliver != null) {
        val targetRecord = recordToDeliver!!
        val targetFamily = familyMap[targetRecord.familyID]
        val headName = targetFamily?.name ?: ""
        val wifeName = targetFamily?.wifeName ?: ""
        val targetNationalId = targetFamily?.nationalID?.trim() ?: ""
        val targetProjectIdStr = targetRecord.projectID.toString()
        val hasExistingSignature = remember(targetProjectIdStr, targetNationalId, signatureRefreshVersion) {
            targetNationalId.isNotBlank() &&
                SignatureStorageHelper.getSignatureFile(
                    context = context,
                    projectId = targetProjectIdStr,
                    nationalId = targetNationalId
                ) != null
        }

        var recipientRelation by remember { mutableStateOf("رب الأسرة (نفسه)") }
        var recipientName by remember { mutableStateOf(headName) }
        var deliveryNotes by remember { mutableStateOf("") }

        // وقت التسليم الفعلي المتوقع توثيقه لحظياً
        val currentDateTimeStr = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()) }

        AlertDialog(
            onDismissRequest = {
                showSignaturePadForDelivery = false
                recordToDeliver = null
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981))
                    Text("تأكيد تسليم وصرف المساعدة", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "المستفيد الأساسي (الاسم الرباعي): $headName",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Badge, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "رقم الهوية الوطنية: ${targetFamily?.nationalID ?: "-"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            if (wifeName.isNotBlank()) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.FamilyRestroom, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(16.dp))
                                    Text(
                                        text = "اسم الزوجة المسجل: $wifeName",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF0284C7)
                                    )
                                }
                            }
                        }
                    }

                    HorizontalDivider()

                    Text("صلة القرابة للمستلم الفعلي:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("رب الأسرة (نفسه)", "الزوجة", "ابن بالغ", "وكيل").forEach { rel ->
                            FilterChip(
                                selected = recipientRelation == rel,
                                onClick = {
                                    recipientRelation = rel
                                    when (rel) {
                                        "رب الأسرة (نفسه)" -> recipientName = headName
                                        "الزوجة" -> recipientName = wifeName
                                        "ابن بالغ" -> recipientName = ""
                                        "وكيل" -> recipientName = ""
                                    }
                                },
                                label = { Text(rel, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = recipientName,
                        onValueChange = { recipientName = it },
                        label = { Text("اسم المستلم الفعلي (الاسم الرباعي)") },
                        supportingText = {
                            if (recipientRelation == "الزوجة" && wifeName.isBlank()) {
                                Text("تنبيه: اسم الزوجة غير مسجل مسبقاً، يرجى كتابته يدوياً", color = MaterialTheme.colorScheme.error, fontSize = 10.sp)
                            } else {
                                Text("تتم التعبئة التلقائية عند اختيار صفة المستلم مع إمكانية التعديل", fontSize = 10.sp)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = deliveryNotes,
                        onValueChange = { deliveryNotes = it },
                        label = { Text("ملاحظات التسليم (Delivery Notes)") },
                        placeholder = { Text("أدخل أي ملاحظات ميدانية حول عملية التسليم وحالة الطرد...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    // خياران واضحان لإتمام التسليم: بالتوقيع الإلكتروني وإصدار السند أو بدون توقيع
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                val cleanRecipient = recipientName.trim().ifEmpty { headName }
                                if (targetNationalId.isBlank()) {
                                    Toast.makeText(
                                        context,
                                        "لا يتوفر رقم هوية لحفظ التوقيع الإلكتروني؛ استخدم التسليم بدون توقيع",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    pendingSignedDelivery = PendingSignedDelivery(
                                        record = targetRecord,
                                        recipientName = cleanRecipient,
                                        recipientRelation = recipientRelation,
                                        deliveryNotes = deliveryNotes,
                                        citizenName = headName
                                    )
                                    showSignaturePadForDelivery = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF047857)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (hasExistingSignature) {
                                    "تعديل التوقيع على الشاشة وإصدار السند"
                                } else {
                                    "توقيع المستفيد على الشاشة وإصدار السند"
                                },
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                val cleanRecipient = recipientName.trim().ifEmpty { headName }
                                viewModel.deliverAid(
                                    recordId = targetRecord.aidRecordID,
                                    recipientName = cleanRecipient,
                                    recipientRelation = recipientRelation,
                                    deliveryNotes = deliveryNotes,
                                    citizenName = headName,
                                    nationalId = targetNationalId,
                                    projectName = projectMap[targetRecord.projectID]?.projectName ?: "مشروع #${targetRecord.projectID}"
                                )
                                warehouseSyncScope.launch {
                                    runCatching {
                                        WarehouseErpStore.deductForDelivery(
                                            context = context,
                                            projectId = targetRecord.projectID.toString(),
                                            unitsCount = 1L,
                                            beneficiaryRef = "$cleanRecipient ($targetNationalId)",
                                            performedBy = warehouseActorName
                                        )
                                    }
                                }
                                pendingSignedDelivery = null
                                showSignaturePadForDelivery = false
                                recordToDeliver = null
                            },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFF10B981)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color(0xFFECFDF5),
                                contentColor = Color(0xFF065F46)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "تسليم بدون توقيع إلكتروني",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تاريخ ووقت التسليم الفعلي: $currentDateTimeStr (يُسجل آلياً بالثواني عند التأكيد)",
                                fontSize = 11.sp,
                                color = Color(0xFF047857),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = {
                    pendingSignedDelivery = null
                    showSignaturePadForDelivery = false
                    recordToDeliver = null
                }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showSignaturePadForDelivery && recordToDeliver != null) {
        val signRecord = recordToDeliver!!
        val signFamily = familyMap[signRecord.familyID]
        val signNationalId = signFamily?.nationalID?.trim() ?: ""
        val signHeadName = signFamily?.name?.trim().orEmpty()
        SignaturePadDialog(
            context = context,
            projectId = signRecord.projectID.toString(),
            nationalId = signNationalId,
            beneficiaryName = signHeadName,
            onSignatureSaved = {
                signatureRefreshVersion += 1
                val pending = pendingSignedDelivery
                if (pending != null) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.deliverAid(
                        recordId = pending.record.aidRecordID,
                        recipientName = pending.recipientName,
                        recipientRelation = pending.recipientRelation,
                        deliveryNotes = pending.deliveryNotes,
                        citizenName = pending.citizenName,
                        nationalId = signNationalId,
                        projectName = projectMap[pending.record.projectID]?.projectName ?: "مشروع #${pending.record.projectID}"
                    )
                    warehouseSyncScope.launch {
                        runCatching {
                            WarehouseErpStore.deductForDelivery(
                                context = context,
                                projectId = pending.record.projectID.toString(),
                                unitsCount = 1L,
                                beneficiaryRef = "${pending.recipientName} ($signNationalId)",
                                performedBy = warehouseActorName
                            )
                        }
                    }
                    val deliveredTimestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                    val deliveredPreview = pending.record.copy(
                        recipientStatus = "مستفيد",
                        deliveryDate = deliveredTimestamp,
                        notes = pending.deliveryNotes.trim().ifBlank { pending.record.notes }
                    )
                    val prj = projectMap[deliveredPreview.projectID]
                    val aidName = AidCategoryCatalog.resolveDisplayName(
                        aidTypeId = deliveredPreview.aidTypeID,
                        aidTypeMap = aidTypeMap,
                        projectAidTypeId = prj?.aidTypeID,
                        fallbackLabel = "مساعدة إغاثية"
                    )
                    val prjNum = prj?.projectNumber ?: "PRJ-2025"
                    val receiptNum = "REC-${deliveredPreview.aidRecordID}"
                    val receiptLinesNow = buildDeliveryReceiptLines(
                        record = deliveredPreview,
                        family = signFamily,
                        aidName = aidName,
                        projectName = prj?.projectName,
                        projectNumber = prjNum
                    )
                    pendingSignedDelivery = null
                    showSignaturePadForDelivery = false
                    recordToDeliver = null
                    recordForReceipt = deliveredPreview
                    Toast.makeText(context, "✓ تم حفظ التوقيع وتأكيد التسليم", Toast.LENGTH_SHORT).show()
                    printDeliveryReceiptPdf(
                        context = context,
                        receiptNumber = receiptNum,
                        receiptLines = receiptLinesNow,
                        projectId = deliveredPreview.projectID.toString(),
                        nationalId = signNationalId
                    )
                } else {
                    showSignaturePadForDelivery = false
                    Toast.makeText(context, "✓ تم حفظ توقيع المستفيد بنجاح", Toast.LENGTH_SHORT).show()
                }
            },
            onDismiss = {
                pendingSignedDelivery = null
                showSignaturePadForDelivery = false
            }
        )
    }

    // ==================== حوار تعديل / إضافة توقيع لمستفيد تم تسليمه مسبقاً ====================
    if (recordToEditSignature != null) {
        val editRecord = recordToEditSignature!!
        val editFamily = familyMap[editRecord.familyID]
        val editNationalId = editFamily?.nationalID?.trim() ?: ""
        val editHeadName = editFamily?.name?.trim().orEmpty()
        SignaturePadDialog(
            context = context,
            projectId = editRecord.projectID.toString(),
            nationalId = editNationalId,
            beneficiaryName = editHeadName,
            onSignatureSaved = {
                signatureRefreshVersion += 1
                recordToEditSignature = null
                recordForReceipt = editRecord
                Toast.makeText(context, "✓ تم حفظ التوقيع بنجاح ويمكنك الآن طباعة السند", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { recordToEditSignature = null }
        )
    }

    // ==================== حوار تأكيد تسليم جميع المرشحين مع سبب التسليم المباشر ====================
    if (showBulkDeliverDialog) {
        val selectedProjectIdForBulk = uiState.selectedProjectId
        val selectedProjectForBulk = selectedProjectIdForBulk?.let { projectMap[it] }
        val bulkProjectName = selectedProjectForBulk?.projectName ?: "المشروع المحدد"
        val bulkProjectNumber = selectedProjectForBulk?.projectNumber ?: ""
        val bulkCount = pendingProjectRecords.size
        val bulkTimestampPreview = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()) }
        val quickDirectDeliveryReasons = remember {
            listOf(
                "تسليم ميداني جماعي معتمد",
                "توزيع مباشر عبر نقطة التوزيع",
                "تسليم كامل الحصة في نفس اليوم",
                "تسليم طارئ بإشراف المشرف الميداني",
                "توثيق ورقي مسبق"
            )
        }

        AlertDialog(
            onDismissRequest = {
                if (!uiState.isBulkDelivering) {
                    showBulkDeliverDialog = false
                }
            },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DoneAll,
                        contentDescription = null,
                        tint = Color(0xFF059669)
                    )
                    Text(
                        text = "تسليم جميع المرشحين",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFECFDF5),
                        border = BorderStroke(1.dp, Color(0xFF6EE7B7)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = if (bulkProjectNumber.isNotBlank()) "$bulkProjectName • #$bulkProjectNumber" else bulkProjectName,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF065F46)
                            )
                            Text(
                                text = "عدد المرشحين المشمولين في العملية: $bulkCount مرشح بانتظار التسليم",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF047857)
                            )
                            Text(
                                text = "سيتم تحويل حالة جميع المرشحين المعلّقين في هذا المشروع إلى «تم التسليم» وتحديث الإحصائيات فوراً.",
                                fontSize = 11.sp,
                                color = Color(0xFF065F46).copy(alpha = 0.85f)
                            )
                        }
                    }

                    Text(
                        text = "اختر سبباً سريعاً أو اكتب سبب التسليم المباشر:",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(quickDirectDeliveryReasons, key = { it }) { preset ->
                            val isSelected = bulkDirectReason.trim() == preset
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    bulkDirectReason = preset
                                    bulkReasonError = false
                                },
                                label = {
                                    Text(
                                        text = preset,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFDCFCE7),
                                    selectedLabelColor = Color(0xFF065F46)
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = bulkDirectReason,
                        onValueChange = {
                            bulkDirectReason = it
                            if (bulkReasonError && it.trim().isNotEmpty()) {
                                bulkReasonError = false
                            }
                        },
                        label = { Text("سبب التسليم المباشر *") },
                        placeholder = { Text("اكتب سبب التسليم المباشر لتوثيقه في سجلات التسليم...") },
                        isError = bulkReasonError,
                        supportingText = {
                            if (bulkReasonError) {
                                Text(
                                    text = "سبب التسليم المباشر مطلوب لتأكيد التسليم الجماعي",
                                    color = MaterialTheme.colorScheme.error,
                                    fontSize = 11.sp
                                )
                            } else {
                                Text(
                                    text = "سيتم حفظ سبب التسليم المباشر وتاريخ ووقت التسليم في كل سجل مشمول",
                                    fontSize = 10.sp
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        maxLines = 3
                    )

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = null,
                                tint = Color(0xFF059669),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تاريخ ووقت التسليم: $bulkTimestampPreview",
                                fontSize = 11.sp,
                                color = Color(0xFF047857),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val reason = bulkDirectReason.trim()
                        if (reason.isBlank()) {
                            bulkReasonError = true
                            return@Button
                        }
                        val targetProjectId = selectedProjectIdForBulk ?: return@Button
                        val targetRecordIds = pendingProjectRecords.map { it.aidRecordID }
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        viewModel.deliverAllPendingInProject(
                            projectId = targetProjectId,
                            pendingRecordIds = targetRecordIds,
                            directDeliveryReason = reason,
                            projectName = bulkProjectName
                        )
                        warehouseSyncScope.launch {
                            runCatching {
                                WarehouseErpStore.deductForDelivery(
                                    context = context,
                                    projectId = targetProjectId.toString(),
                                    unitsCount = targetRecordIds.size.toLong(),
                                    beneficiaryRef = "تسليم جماعي ($bulkCount مستفيد)",
                                    performedBy = warehouseActorName
                                )
                            }
                        }
                        showBulkDeliverDialog = false
                    },
                    enabled = !uiState.isBulkDelivering && bulkCount > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669))
                ) {
                    Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تأكيد تسليم الكل ($bulkCount)", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showBulkDeliverDialog = false },
                    enabled = !uiState.isBulkDelivering
                ) {
                    Text("إلغاء")
                }
            }
        )
    }

    // ==================== حوار سند الاستلام الرسمي ====================
    if (recordForReceipt != null) {
        val r = recordForReceipt!!
        val f = familyMap[r.familyID]
        val prj = projectMap[r.projectID]
        val aidName = AidCategoryCatalog.resolveDisplayName(
            aidTypeId = r.aidTypeID,
            aidTypeMap = aidTypeMap,
            projectAidTypeId = prj?.aidTypeID,
            fallbackLabel = "مساعدة إغاثية"
        )
        val prjNum = prj?.projectNumber ?: "PRJ-2025"
        val receiptNumber = "REC-${r.aidRecordID}"
        val receiptText = remember(r, f, aidName, prj, prjNum) {
            buildDeliveryReceiptText(
                record = r,
                family = f,
                aidName = aidName,
                projectName = prj?.projectName,
                projectNumber = prjNum
            )
        }
        val receiptLines = remember(r, f, aidName, prj, prjNum) {
            buildDeliveryReceiptLines(
                record = r,
                family = f,
                aidName = aidName,
                projectName = prj?.projectName,
                projectNumber = prjNum
            )
        }

        AlertDialog(
            onDismissRequest = { recordForReceipt = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("سند استلام مساعدة إنسانية معتمد", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ReceiptRow("رقم السند الميداني:", receiptNumber)
                            ReceiptRow("اسم رب الأسرة (الرباعي):", f?.name ?: "غير محدد")
                            ReceiptRow("رقم الهوية الوطنية:", f?.nationalID ?: "-")
                            ReceiptRow("عدد أفراد الأسرة:", "${f?.familyMembersCount ?: 0} أفراد")
                            ReceiptRow("نوع المساعدة:", aidName)
                            ReceiptRow("المشروع الإغاثي:", prjNum)
                            ReceiptRow("تاريخ ووقت التسليم الفعلي:", r.deliveryDate ?: r.aidDate)
                            ReceiptRow("المستودع:", r.warehouse.ifBlank { "الرئيسي" })
                            ReceiptRow("ملاحظات الصرف والتسليم:", r.notes?.takeIf { it.isNotBlank() } ?: "تم التسليم بحالة جيدة")
                        }
                    }

                    val receiptNationalId = f?.nationalID?.trim().orEmpty()
                    val receiptHasSignature = remember(r.projectID, receiptNationalId, signatureRefreshVersion) {
                        receiptNationalId.isNotBlank() &&
                            SignatureStorageHelper.getSignatureFile(
                                context = context,
                                projectId = r.projectID.toString(),
                                nationalId = receiptNationalId
                            ) != null
                    }

                    if (receiptNationalId.isNotBlank()) {
                        OutlinedButton(
                            onClick = {
                                recordToEditSignature = r
                            },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(
                                1.dp,
                                if (receiptHasSignature) Color(0xFF10B981) else Color(0xFF0284C7)
                            ),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (receiptHasSignature) Color(0xFFECFDF5) else Color(0xFFF0F9FF),
                                contentColor = if (receiptHasSignature) Color(0xFF065F46) else Color(0xFF0369A1)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (receiptHasSignature) "✓ تعديل/إضافة توقيع (موقّع)" else "تعديل/إضافة توقيع",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            printDeliveryReceiptPdf(
                                context = context,
                                receiptNumber = receiptNumber,
                                receiptLines = receiptLines,
                                projectId = r.projectID.toString(),
                                nationalId = receiptNationalId
                            )
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("طباعة السند عبر الطابعة (PDF)", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        shareDeliveryReceiptText(
                            context = context,
                            receiptText = receiptText,
                            receiptNumber = receiptNumber
                        )
                    }
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة / طباعة")
                }
            },
            dismissButton = {
                TextButton(onClick = { recordForReceipt = null }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // ==================== حوار التراجع الصارم عن التسليم مع سبب التراجع الإلزامي ====================
    if (recordToUndo != null) {
        val targetRecord = recordToUndo!!
        val targetFamily = familyMap[targetRecord.familyID]
        val targetProject = projectMap[targetRecord.projectID]

        AlertDialog(
            onDismissRequest = {
                recordToUndo = null
                undoReasonText = ""
                undoReasonError = false
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "تأكيد التراجع عن تسليم المساعدة",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "تحذير رقابي: سيتم إلغاء حالة التسليم وإعادة السجل لحالة 'مرشح' للمستفيد التالي:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "الاسم الرباعي: ${targetFamily?.name ?: "غير محدد"}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "رقم الهوية الوطنية: ${targetFamily?.nationalID ?: "-"}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "المشروع: ${targetProject?.projectName ?: "مشروع #${targetRecord.projectID}"}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "سبب التراجع عن التسليم (إلزامي للتوثيق والرقابة):*",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (undoReasonError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                    )

                    OutlinedTextField(
                        value = undoReasonText,
                        onValueChange = {
                            undoReasonText = it
                            if (it.isNotBlank()) undoReasonError = false
                        },
                        placeholder = { Text("مثال: خطأ في مطابقة الهوية، عدم استلام الطرد فعلياً، استرجاع للمستودع...") },
                        isError = undoReasonError,
                        supportingText = if (undoReasonError) {
                            { Text("سبب التراجع إلزامي ويتم حفظه في ملاحظات المساعدة وسجل الرقابة", color = MaterialTheme.colorScheme.error, fontSize = 10.sp) }
                        } else null,
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmedReason = undoReasonText.trim()
                        if (trimmedReason.isBlank()) {
                            undoReasonError = true
                        } else {
                            viewModel.undoDelivery(
                                recordId = targetRecord.aidRecordID,
                                reason = trimmedReason,
                                citizenName = targetFamily?.name ?: ""
                            )
                            warehouseSyncScope.launch {
                                runCatching {
                                    WarehouseErpStore.restoreFromDelivery(
                                        context = context,
                                        projectId = targetRecord.projectID.toString(),
                                        unitsCount = 1L,
                                        beneficiaryRef = targetFamily?.name ?: "سجل #${targetRecord.aidRecordID}",
                                        performedBy = warehouseActorName
                                    )
                                }
                            }
                            recordToUndo = null
                            undoReasonText = ""
                            undoReasonError = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تأكيد التراجع والتوثيق", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    recordToUndo = null
                    undoReasonText = ""
                    undoReasonError = false
                }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // ==================== حوار كاميرا مسح الباركود والهويات الذكي ====================
    if (showScannerDialog) {
        CameraScannerDialog(
            onIdScanned = onScan@{ scannedId ->
                val rawScanned = scannedId.trim()
                if (rawScanned.isBlank()) return@onScan

                val nowMs = System.currentTimeMillis()
                if (isRapidScanMode && rawScanned == lastRapidScannedText && (nowMs - lastRapidScanTimestamp) < 1800L) {
                    return@onScan
                }
                lastRapidScannedText = rawScanned
                lastRapidScanTimestamp = nowMs

                val expectedProjectIdStr = uiState.selectedProjectId?.toString() ?: ""
                val verification = OfflineVoucherCrypto.verifyVoucherPayload(
                    context = context,
                    rawQrText = rawScanned,
                    expectedProjectId = expectedProjectIdStr
                )

                if (!verification.isValid) {
                    runCatching { rapidScanToneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 200) }
                    Toast.makeText(
                        context,
                        verification.errorMessageAr.ifBlank { "قسيمة غير صالحة أو مزورة" },
                        Toast.LENGTH_LONG
                    ).show()
                    if (!isRapidScanMode) {
                        showScannerDialog = false
                    }
                    return@onScan
                }

                val matchedRecord = projectAidRecords.firstOrNull { rec ->
                    familyMap[rec.familyID]?.nationalID?.trim() == verification.familyNationalId
                }

                if (matchedRecord == null) {
                    runCatching { rapidScanToneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 200) }
                    Toast.makeText(
                        context,
                        "المستفيد (${verification.familyNationalId}) غير مدرج في كشف المشروع الحالي",
                        Toast.LENGTH_LONG
                    ).show()
                    if (!isRapidScanMode) {
                        viewModel.setSearchQuery(verification.familyNationalId)
                        showScannerDialog = false
                    }
                    return@onScan
                }

                val alreadyDelivered = matchedRecord.recipientStatus.trim() in setOf("مستفيد", "تم التسليم", "مستلم")
                val resolvedHeadName = familyMap[matchedRecord.familyID]?.name
                    ?.takeIf { it.isNotBlank() }
                    ?: verification.beneficiaryName

                if (alreadyDelivered) {
                    runCatching { rapidScanToneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 200) }
                    Toast.makeText(
                        context,
                        "تم تسليم هذه القسيمة مسبقاً للمستفيد: $resolvedHeadName",
                        Toast.LENGTH_SHORT
                    ).show()
                    if (!isRapidScanMode) {
                        viewModel.setSearchQuery(verification.familyNationalId)
                        showScannerDialog = false
                    }
                    return@onScan
                }

                if (isRapidScanMode) {
                    if (!canDeliver) {
                        Toast.makeText(context, "لا تملك صلاحية تأكيد التسليم", Toast.LENGTH_SHORT).show()
                        return@onScan
                    }
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.deliverAid(
                        recordId = matchedRecord.aidRecordID,
                        recipientName = resolvedHeadName,
                        recipientRelation = "رب الأسرة (نفسه)",
                        deliveryNotes = "تسليم فوري عبر وضع المسح السريع المتتالي (قسيمة QR مشفّرة)",
                        citizenName = resolvedHeadName,
                        nationalId = verification.familyNationalId,
                        projectName = projectMap[matchedRecord.projectID]?.projectName ?: "مشروع #${matchedRecord.projectID}"
                    )
                    warehouseSyncScope.launch {
                        runCatching {
                            WarehouseErpStore.deductForDelivery(
                                context = context,
                                projectId = matchedRecord.projectID.toString(),
                                unitsCount = 1L,
                                beneficiaryRef = "$resolvedHeadName (${verification.familyNationalId})",
                                performedBy = warehouseActorName
                            )
                        }
                    }
                    runCatching { rapidScanToneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 180) }
                    Toast.makeText(
                        context,
                        "✓ تم التسليم بنجاح: $resolvedHeadName",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    viewModel.setSearchQuery(verification.familyNationalId)
                    showScannerDialog = false
                    if (canDeliver) {
                        showSignaturePadForDelivery = false
                        recordToDeliver = matchedRecord
                    }
                }
            },
            onDismiss = { showScannerDialog = false }
        )
    }

    if (showSyncDialog) {
        SyncDetailsDialog(
            repository = repository,
            onDismiss = { showSyncDialog = false }
        )
    }

    if (showBulkA4VouchersDialog) {
        val activeProjectId = uiState.selectedProjectId
        val activeProject = activeProjectId?.let { projectMap[it] }
        if (activeProjectId != null && activeProject != null) {
            val resolvedAidTypeName = AidCategoryCatalog.resolveDisplayName(
                aidTypeId = projectAidRecords.firstOrNull()?.aidTypeID ?: activeProject.aidTypeID,
                aidTypeMap = aidTypeMap,
                projectAidTypeId = activeProject.aidTypeID,
                fallbackLabel = "مساعدة إنسانية"
            )
            val voucherItems = remember(projectAidRecords, familyMap) {
                projectAidRecords.mapIndexed { idx, rec ->
                    val fam = familyMap[rec.familyID]
                    val delivered = rec.recipientStatus.trim() in setOf("مستفيد", "تم التسليم", "مستلم")
                    BulkVoucherBeneficiaryItem(
                        serialNumber = idx + 1,
                        familyId = rec.familyID,
                        nationalId = fam?.nationalID?.trim().orEmpty(),
                        beneficiaryName = fam?.name?.trim().orEmpty().ifBlank { "مستفيد #${rec.familyID}" },
                        familySize = fam?.familyMembersCount ?: 0,
                        isDelivered = delivered
                    )
                }
            }
            BulkA4VouchersDialog(
                projectId = activeProject.projectID,
                projectName = activeProject.projectName,
                projectNumber = activeProject.projectNumber,
                aidTypeName = resolvedAidTypeName,
                defaultLocation = activeProject.warehouseName.trim(),
                beneficiaries = voucherItems,
                onDismiss = { showBulkA4VouchersDialog = false }
            )
        } else {
            showBulkA4VouchersDialog = false
        }
    }
}

@Composable
private fun CompactKpiItem(label: String, value: String, color: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 2.dp)
    ) {
        Text(
            text = value,
            fontWeight = FontWeight.Bold,
            fontSize = 13.5.sp,
            color = color
        )
        Text(
            text = label,
            fontSize = 9.5.sp,
            color = Color(0xFF64748B),
            maxLines = 1
        )
    }
}

/**
 * بطاقة عرض سجل الصرف والتسليم لمواطن بتصميم زجاجي مضغوط ومتفاعل (Compact Glassmorphism + animateContentSize)
 */
@Composable
fun DeliveryCardItem(
    record: AidRecordEntity,
    family: FamilyEntity?,
    aidTypeName: String,
    projectNumber: String,
    isDelivered: Boolean,
    isReverted: Boolean,
    hasSavedSignature: Boolean = false,
    canDeliver: Boolean = true,
    canDelete: Boolean = true,
    onDeliverClick: () -> Unit,
    onShareWhatsAppVoucher: () -> Unit = {},
    onReceiptClick: () -> Unit,
    onEditSignatureClick: () -> Unit = {},
    onUndoClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val cardBorderColor = when {
        isDelivered -> Color(0xFF86EFAC)
        isReverted -> Color(0xFFFCA5A5)
        else -> Color.White.copy(alpha = 0.6f)
    }
    val cardBgColor = when {
        isDelivered -> Color(0xFFF0FDF4).copy(alpha = 0.82f)
        isReverted -> Color(0xFFFEF2F2).copy(alpha = 0.80f)
        else -> Color.White.copy(alpha = 0.75f)
    }

    val beneficiaryName = remember(family, record) {
        val nameFromFam = family?.name?.trim()
        if (!nameFromFam.isNullOrBlank()) {
            nameFromFam
        } else {
            val fromNotes = record.notes?.let { n ->
                Regex("(?:المستلم الفعلي|المستلم)\\s*:\\s*([^|\\n]+)").find(n)?.groupValues?.getOrNull(1)?.trim()
            }
            if (!fromNotes.isNullOrBlank()) fromNotes else "المستفيد غير مسجل"
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .clip(RoundedCornerShape(16.dp))
            .background(cardBgColor)
            .border(1.dp, cardBorderColor, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // الصف الأول: الاسم الرباعي + شارة الحالة الأنيقة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = beneficiaryName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(8.dp))

                when {
                    isDelivered -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            if (hasSavedSignature) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFE0F2FE),
                                    border = BorderStroke(1.dp, Color(0xFF7DD3FC))
                                ) {
                                    Text(
                                        text = "✓ موقّع",
                                        color = Color(0xFF0369A1),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFDCFCE7),
                                border = BorderStroke(1.dp, Color(0xFF86EFAC))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(12.dp))
                                    Text("تم التسليم", color = Color(0xFF065F46), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                    isReverted -> {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEE2E2),
                            border = BorderStroke(1.dp, Color(0xFFFCA5A5))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Undo, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(12.dp))
                                Text("تم التراجع", color = Color(0xFF991B1B), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }
                    }
                    else -> {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFEF3C7),
                            border = BorderStroke(1.dp, Color(0xFFFDE68A))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(12.dp))
                                Text("مرشح للصرف", color = Color(0xFF92400E), fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }

            // الصف الثاني: ترتيب أفقي مضغوط للهوية + الأفراد + نوع المساعدة + المخزن
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFE0F2FE)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(Icons.Default.Badge, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(11.dp))
                        Text(
                            text = family?.nationalID ?: "-",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0369A1)
                        )
                    }
                }

                Text(
                    text = "${family?.familyMembersCount ?: 0} أفراد",
                    fontSize = 10.5.sp,
                    color = Color(0xFF475569),
                    fontWeight = FontWeight.Medium
                )

                Text(text = "•", color = Color(0xFFCBD5E1), fontSize = 10.sp)

                Text(
                    text = "$aidTypeName ($projectNumber)",
                    fontSize = 10.5.sp,
                    color = Color(0xFF334155),
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = record.warehouse.ifBlank { "الرئيسي" },
                    fontSize = 10.sp,
                    color = Color(0xFF64748B),
                    maxLines = 1
                )
            }

            // سطر مضغوط لتاريخ التسليم الفعلي أو سبب التراجع / الملاحظات
            if (isDelivered && !record.deliveryDate.isNullOrBlank()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFDCFCE7).copy(alpha = 0.65f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(Icons.Default.AccessTime, contentDescription = null, tint = Color(0xFF047857), modifier = Modifier.size(13.dp))
                    Text(
                        text = "استلام: ${record.deliveryDate}",
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF065F46),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            } else if (isReverted) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFEE2E2).copy(alpha = 0.7f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(13.dp))
                    Text(
                        text = record.notes ?: "تم التراجع عن التسليم وإرجاع الحالة لمرشح",
                        fontSize = 10.5.sp,
                        color = Color(0xFF991B1B),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            } else if (!record.notes.isNullOrBlank()) {
                Text(
                    text = record.notes ?: "",
                    fontSize = 10.5.sp,
                    color = Color(0xFF64748B),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // صف أزرار الإجراءات المضغوطة (Compact Buttons)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (canDelete) {
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = "حذف السجل",
                            tint = Color(0xFFEF4444).copy(alpha = 0.75f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.size(28.dp))
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isDelivered) {
                        OutlinedButton(
                            onClick = onShareWhatsAppVoucher,
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color(0xFFECFDF5),
                                contentColor = Color(0xFF047857)
                            ),
                            border = BorderStroke(1.dp, Color(0xFF6EE7B7)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text(
                                text = "بطاقة واتساب",
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.5.sp
                            )
                        }
                        if (canDeliver) {
                            OutlinedButton(
                                onClick = onDeliverClick,
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = Color(0xFFDCFCE7),
                                    contentColor = Color(0xFF065F46)
                                ),
                                border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isReverted) "إعادة التسليم" else "تسليم المساعدة",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    } else {
                        Column(
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = onEditSignatureClick,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (hasSavedSignature) Color(0xFFE0F2FE) else Color(0xFFF0F9FF),
                                        contentColor = Color(0xFF0369A1)
                                    ),
                                    border = BorderStroke(1.dp, Color(0xFF7DD3FC)),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 9.dp, vertical = 0.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text(
                                        text = "تعديل/إضافة توقيع",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                OutlinedButton(
                                    onClick = onReceiptClick,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = Color.White.copy(alpha = 0.8f),
                                        contentColor = Color(0xFF0F172A)
                                    ),
                                    border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("سند الاستلام", fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }

                            if (canDeliver) {
                                OutlinedButton(
                                    onClick = onUndoClick,
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = Color(0xFFFEF2F2),
                                        contentColor = Color(0xFFDC2626)
                                    ),
                                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                    shape = RoundedCornerShape(10.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تراجع عن التسليم", fontWeight = FontWeight.Bold, fontSize = 10.5.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReceiptRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
        Text(text = value, style = MaterialTheme.typography.bodySmall)
    }
}

private fun buildDeliveryReceiptLines(
    record: AidRecordEntity,
    family: FamilyEntity?,
    aidName: String,
    projectName: String?,
    projectNumber: String
): List<Pair<String, String>> {
    val receiptNumber = "REC-${record.aidRecordID}"
    val headName = family?.name?.takeIf { it.isNotBlank() } ?: "غير محدد"
    val nationalId = family?.nationalID?.takeIf { it.isNotBlank() } ?: "-"
    val membersCount = "${family?.familyMembersCount ?: 0} أفراد"
    val projectDisplay = if (!projectName.isNullOrBlank()) "$projectName ($projectNumber)" else projectNumber
    val deliveryDateTime = record.deliveryDate?.takeIf { it.isNotBlank() } ?: record.aidDate
    val warehouse = record.warehouse.ifBlank { "الرئيسي" }
    val notes = record.notes?.takeIf { it.isNotBlank() } ?: "تم التسليم بحالة جيدة"

    return listOf(
        "رقم السند الميداني" to receiptNumber,
        "اسم رب الأسرة (الرباعي)" to headName,
        "رقم الهوية الوطنية" to nationalId,
        "عدد أفراد الأسرة" to membersCount,
        "نوع المساعدة" to aidName,
        "المشروع الإغاثي" to projectDisplay,
        "تاريخ ووقت التسليم الفعلي" to deliveryDateTime,
        "المستودع" to warehouse,
        "ملاحظات الصرف والتسليم" to notes
    )
}

private fun buildDeliveryReceiptText(
    record: AidRecordEntity,
    family: FamilyEntity?,
    aidName: String,
    projectName: String?,
    projectNumber: String
): String {
    val lines = buildDeliveryReceiptLines(
        record = record,
        family = family,
        aidName = aidName,
        projectName = projectName,
        projectNumber = projectNumber
    )
    return buildString {
        appendLine("══════════════════════════════")
        appendLine("سند استلام مساعدة إنسانية معتمد")
        appendLine("══════════════════════════════")
        lines.forEach { (label, value) ->
            appendLine("$label: $value")
        }
        appendLine("──────────────────────────────")
        append("صادر عن نظام إدارة المساعدات الإنسانية")
    }
}

private fun shareDeliveryReceiptText(
    context: Context,
    receiptText: String,
    receiptNumber: String
) {
    try {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "سند استلام مساعدة إنسانية - $receiptNumber")
            putExtra(Intent.EXTRA_TEXT, receiptText)
        }
        val chooser = Intent.createChooser(sendIntent, "مشاركة سند الاستلام ($receiptNumber)")
        if (context !is android.app.Activity) {
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    } catch (_: Exception) {
        Toast.makeText(context, "تعذر فتح قائمة المشاركة على هذا الجهاز", Toast.LENGTH_SHORT).show()
    }
}

private data class PendingSignedDelivery(
    val record: AidRecordEntity,
    val recipientName: String,
    val recipientRelation: String,
    val deliveryNotes: String,
    val citizenName: String
)

private fun printDeliveryReceiptPdf(
    context: Context,
    receiptNumber: String,
    receiptLines: List<Pair<String, String>>,
    projectId: String = "",
    nationalId: String = ""
) {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
    if (printManager == null) {
        Toast.makeText(context, "خدمة الطباعة غير مدعومة على هذا الجهاز", Toast.LENGTH_SHORT).show()
        return
    }

    val pdfFile = File(context.cacheDir, "delivery_receipt_$receiptNumber.pdf")
    val pdfDocument = PdfDocument()
    try {
        val pageWidth = 595
        val pageHeight = 842
        val margin = 40f
        val contentWidth = (pageWidth - margin * 2).toInt()

        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        val borderPaint = Paint().apply {
            color = AndroidColor.parseColor("#047857")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRect(margin - 12f, margin - 12f, pageWidth - margin + 12f, pageHeight - margin + 12f, borderPaint)

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.parseColor("#065F46")
            textSize = 20f
            isFakeBoldText = true
        }
        val subtitlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.parseColor("#475569")
            textSize = 12f
        }
        val rowPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = AndroidColor.parseColor("#0F172A")
            textSize = 13.5f
        }
        val dividerPaint = Paint().apply {
            color = AndroidColor.parseColor("#CBD5E1")
            strokeWidth = 1f
        }

        var yCursor = margin + 16f

        val titleText = "سند استلام مساعدة إنسانية معتمد"
        val titleLayout = StaticLayout.Builder
            .obtain(titleText, 0, titleText.length, titlePaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .build()
        canvas.save()
        canvas.translate(margin, yCursor)
        titleLayout.draw(canvas)
        canvas.restore()
        yCursor += titleLayout.height + 8f

        val subText = "نظام إدارة المساعدات الإنسانية • رقم السند: $receiptNumber"
        val subLayout = StaticLayout.Builder
            .obtain(subText, 0, subText.length, subtitlePaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .build()
        canvas.save()
        canvas.translate(margin, yCursor)
        subLayout.draw(canvas)
        canvas.restore()
        yCursor += subLayout.height + 16f

        canvas.drawLine(margin, yCursor, pageWidth - margin, yCursor, dividerPaint)
        yCursor += 20f

        receiptLines.forEach { (label, value) ->
            val lineText = "$label: $value"
            val rowLayout = StaticLayout.Builder
                .obtain(lineText, 0, lineText.length, rowPaint, contentWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setLineSpacing(4f, 1.15f)
                .build()
            canvas.save()
            canvas.translate(margin, yCursor)
            rowLayout.draw(canvas)
            canvas.restore()
            yCursor += rowLayout.height + 12f

            canvas.drawLine(margin, yCursor - 4f, pageWidth - margin, yCursor - 4f, dividerPaint)
        }

        val sigFile = if (projectId.isNotBlank() && nationalId.isNotBlank()) {
            SignatureStorageHelper.getSignatureFile(
                context = context,
                projectId = projectId,
                nationalId = nationalId
            )
        } else {
            null
        }

        if (sigFile != null) {
            yCursor += 64f
            val sigBitmap = BitmapFactory.decodeFile(sigFile.absolutePath)
            if (sigBitmap != null) {
                try {
                    val sigWidth = 140f
                    val sigHeight = 55f
                    val sigRight = pageWidth - margin - 122f
                    val sigLeft = sigRight - sigWidth
                    val sigBottom = yCursor - 2f
                    val sigTop = sigBottom - sigHeight
                    val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    canvas.drawBitmap(sigBitmap, null, RectF(sigLeft, sigTop, sigRight, sigBottom), bitmapPaint)
                } finally {
                    if (!sigBitmap.isRecycled) {
                        sigBitmap.recycle()
                    }
                }
            }
        } else {
            yCursor += 28f
        }

        val footerText = "توقيع المستلم: _____________________        ختم واعتماد اللجنة: _____________________"
        val footerLayout = StaticLayout.Builder
            .obtain(footerText, 0, footerText.length, subtitlePaint, contentWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .build()
        canvas.save()
        canvas.translate(margin, yCursor)
        footerLayout.draw(canvas)
        canvas.restore()

        pdfDocument.finishPage(page)
        FileOutputStream(pdfFile).use { out ->
            pdfDocument.writeTo(out)
        }
    } catch (_: Exception) {
        Toast.makeText(context, "تعذر تجهيز ملف السند للطباعة", Toast.LENGTH_SHORT).show()
        return
    } finally {
        pdfDocument.close()
    }

    try {
        val jobName = "سند_استلام_$receiptNumber"
        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder("$jobName.pdf")
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(1)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                val fd = destination?.fileDescriptor
                if (fd == null) {
                    callback?.onWriteFailed("تعذر الوصول إلى ملف وجهة الطباعة")
                    return
                }
                try {
                    FileInputStream(pdfFile).use { input ->
                        FileOutputStream(fd).use { output ->
                            input.copyTo(output)
                        }
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (t: Throwable) {
                    callback?.onWriteFailed(t.message)
                }
            }
        }
        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    } catch (_: Exception) {
        Toast.makeText(context, "تعذر بدء مهمة الطباعة", Toast.LENGTH_SHORT).show()
    }
}

