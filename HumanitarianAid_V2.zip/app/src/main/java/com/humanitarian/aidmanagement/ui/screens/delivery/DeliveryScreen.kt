package com.humanitarian.aidmanagement.ui.screens.delivery

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.SyncDetailsDialog
import com.humanitarian.aidmanagement.ui.components.SyncStatusBanner
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeliveryScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val currentUser by repository.currentUserFlow.collectAsState()
    val allowedLoc = currentUser?.AllowedLocalityID ?: 0
    val isLocRestricted = allowedLoc != 0 && !repository.isSuperAdmin()

    val rawAidRecords by repository.getAllAidRecords().collectAsState(initial = emptyList())
    val families by repository.getFamilies().collectAsState(initial = emptyList())
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val projects by repository.getActiveProjects().collectAsState(initial = emptyList())
    val syncState by repository.getSyncState().collectAsState()

    val familyMap = remember(families) { families.associateBy { it.familyID } }
    val aidTypeMap = remember(aidTypes) { aidTypes.associateBy { it.aidTypeID } }
    val projectMap = remember(projects) { projects.associateBy { it.projectID } }

    val aidRecords = remember(rawAidRecords, familyMap, isLocRestricted, allowedLoc) {
        if (isLocRestricted) {
            rawAidRecords.filter { record ->
                val fam = familyMap[record.familyID]
                fam != null && fam.localityID == allowedLoc
            }
        } else {
            rawAidRecords
        }
    }

    var selectedProjectId by remember { mutableStateOf<Long?>(null) }
    var isProjectDropdownExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(projects) {
        if (projects.isNotEmpty() && (selectedProjectId == null || projects.none { it.projectID == selectedProjectId })) {
            selectedProjectId = projects.first().projectID
        }
    }

    val projectAidRecords = remember(aidRecords, selectedProjectId) {
        if (selectedProjectId == null) emptyList()
        else aidRecords.filter { it.projectID == selectedProjectId }
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf("الكل") }

    var recordToDeliver by remember { mutableStateOf<AidRecordEntity?>(null) }
    var recordForReceipt by remember { mutableStateOf<AidRecordEntity?>(null) }
    var recordToUndo by remember { mutableStateOf<AidRecordEntity?>(null) }
    var undoReasonText by remember { mutableStateOf("") }
    var undoReasonError by remember { mutableStateOf(false) }

    var showScannerDialog by remember { mutableStateOf(false) }
    var showSyncDialog by remember { mutableStateOf(false) }
    var actionMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()

    val filteredRecords = remember(projectAidRecords, searchQuery, selectedStatusFilter, familyMap) {
        projectAidRecords.filter { record ->
            val family = familyMap[record.familyID]
            val familyName = family?.name ?: ""
            val nationalId = family?.nationalID ?: ""
            val projectNumber = projectMap[record.projectID]?.projectNumber ?: ""

            val matchesSearch = searchQuery.isBlank() ||
                    familyName.contains(searchQuery, ignoreCase = true) ||
                    nationalId.contains(searchQuery) ||
                    projectNumber.contains(searchQuery, ignoreCase = true)

            val isDelivered = record.recipientStatus.contains("مستلم") || record.recipientStatus.contains("تم التسليم")
            val matchesStatus = when (selectedStatusFilter) {
                "تم التسليم" -> isDelivered
                "بانتظار التسليم" -> !isDelivered
                else -> true
            }

            matchesSearch && matchesStatus
        }
    }

    val totalCount = projectAidRecords.size
    val deliveredCount = projectAidRecords.count { it.recipientStatus.contains("مستلم") || it.recipientStatus.contains("تم التسليم") }
    val pendingCount = totalCount - deliveredCount
    val deliveryRate = if (totalCount > 0) (deliveredCount * 100 / totalCount) else 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "تسليم وصرف المساعدات الميدانية",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "نقطة التوزيع وتوثيق الاستلام بالباركود",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { showSyncDialog = true }) {
                        Icon(
                            imageVector = if (syncState.isOnline) Icons.Default.CloudSync else Icons.Default.CloudOff,
                            contentDescription = "التزامن والعمل دون اتصال",
                            tint = if (syncState.isOnline) MaterialTheme.colorScheme.primary else Color(0xFFF59E0B)
                        )
                    }
                    IconButton(onClick = { showScannerDialog = true }) {
                        Icon(Icons.Default.Search, contentDescription = "مسح باركود الهوية", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            SyncStatusBanner(
                repository = repository,
                onOpenSyncDetails = { showSyncDialog = true }
            )

            Spacer(modifier = Modifier.height(6.dp))

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Assignment, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Text(
                                text = "المشروع الإنساني النشط للتسليم والصرف:",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "مشروع محدد حصراً",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(modifier = Modifier.fillMaxWidth()) {
                        val currentProject = projects.firstOrNull { it.projectID == selectedProjectId }
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isProjectDropdownExpanded = true },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = currentProject?.projectName ?: if (projects.isEmpty()) "لا توجد مشاريع نشطة" else "اختر المشروع...",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (currentProject != null) {
                                        Text(
                                            text = "رقم المشروع: ${currentProject.projectNumber} | الممول: ${currentProject.fundingInstitution}", // التعديل هنا
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Icon(
                                    imageVector = if (isProjectDropdownExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = isProjectDropdownExpanded,
                            onDismissRequest = { isProjectDropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            projects.forEach { prj ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text("${prj.projectNumber} - ${prj.fundingInstitution}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) // التعديل هنا
                                        }
                                    },
                                    onClick = {
                                        selectedProjectId = prj.projectID
                                        isProjectDropdownExpanded = false
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = if (prj.projectID == selectedProjectId) Icons.Default.CheckCircle else Icons.Default.Folder,
                                            contentDescription = null,
                                            tint = if (prj.projectID == selectedProjectId) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("إجمالي الكشوفات", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$totalCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("تم التسليم", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$deliveredCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color(0xFF10B981))
                    }
                    Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("بانتظار الصرف", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$pendingCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color(0xFFF59E0B))
                    }
                    Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("نسبة الإنجاز", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$deliveryRate%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color(0xFF0284C7))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("بحث برقم الهوية (9 أرقام) أو اسم المواطن...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("الكل", "بانتظار التسليم", "تم التسليم").forEach { filterLabel ->
                    FilterChip(
                        selected = selectedStatusFilter == filterLabel,
                        onClick = { selectedStatusFilter = filterLabel },
                        label = { Text(filterLabel) }
                    )
                }
            }

            if (actionMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981).copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = actionMessage ?: "", color = Color(0xFF10B981), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "سجلات الصرف والتسليم للمشروع (${filteredRecords.size} مستفيد):",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (filteredRecords.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f), modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (selectedProjectId == null) "الرجاء اختيار مشروع نشط أولاً" else "لا توجد سجلات تسليم أو ترشيح لهذا المشروع حالياً",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredRecords, key = { it.aidRecordID }) { record ->
                        val family = familyMap[record.familyID]
                        val aidTypeName = aidTypeMap[record.aidTypeID]?.aidTypeName ?: "مساعدة #${record.aidTypeID}"
                        val projectNumber = projectMap[record.projectID]?.projectNumber ?: "مشروع #${record.projectID}"
                        val isDelivered = record.recipientStatus.contains("مستلم") || record.recipientStatus.contains("تم التسليم")

                        DeliveryCardItem(
                            record = record,
                            family = family,
                            aidTypeName = aidTypeName,
                            projectNumber = projectNumber,
                            isDelivered = isDelivered,
                            onDeliverClick = { recordToDeliver = record },
                            onReceiptClick = { recordForReceipt = record },
                            onUndoClick = {
                                recordToUndo = record
                                undoReasonText = ""
                                undoReasonError = false
                            },
                            onDeleteClick = {
                                scope.launch {
                                    repository.deleteAidRecord(record.aidRecordID)
                                    actionMessage = "تم حذف السجل بنجاح"
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    if (recordToDeliver != null) {
        val targetRecord = recordToDeliver!!
        val targetFamily = familyMap[targetRecord.familyID]
        var recipientName by remember { mutableStateOf(targetFamily?.name ?: "") }
        var recipientRelation by remember { mutableStateOf("نفسه") }
        var notes by remember { mutableStateOf("تم التحقق من الهوية الأصلية وكرت المؤن") }

        AlertDialog(
            onDismissRequest = { recordToDeliver = null },
            title = {
                Text("تأكيد تسليم وصرف المساعدة", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "المستفيد الأساسي: ${targetFamily?.name ?: "غير محدد"}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "رقم الهوية الوطنية: ${targetFamily?.nationalID ?: "-"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    Divider()

                    OutlinedTextField(
                        value = recipientName,
                        onValueChange = { recipientName = it },
                        label = { Text("اسم المستلم الفعلي") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Text("صفة المستلم:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("نفسه", "الزوجة", "ابن بالغ", "وكيل").forEach { rel ->
                            FilterChip(
                                selected = recipientRelation == rel,
                                onClick = {
                                    recipientRelation = rel
                                    if (rel == "نفسه") recipientName = targetFamily?.name ?: ""
                                    else if (rel == "الزوجة" && targetFamily?.wifeName != null) recipientName = targetFamily.wifeName ?: ""
                                },
                                label = { Text(rel, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات الصرف والتحقق") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            val combinedNotes = "المستلم: $recipientName ($recipientRelation) - $notes"
                            repository.deliverAid(targetRecord.aidRecordID, recipientName, combinedNotes)
                            recordToDeliver = null
                            actionMessage = "تم تسليم المساعدة بنجاح للمواطن ${targetFamily?.name ?: ""}"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تأكيد الصرف والتسليم", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToDeliver = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (recordForReceipt != null) {
        val r = recordForReceipt!!
        val f = familyMap[r.familyID]
        val aidName = aidTypeMap[r.aidTypeID]?.aidTypeName ?: "مساعدة إغاثية"
        val prjNum = projectMap[r.projectID]?.projectNumber ?: "PRJ-2025"

        AlertDialog(
            onDismissRequest = { recordForReceipt = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("سند استلام مساعدة إنسانية معتمد", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReceiptRow("رقم السند الميداني:", "REC-${r.aidRecordID}-2025")
                        ReceiptRow("اسم رب الأسرة:", f?.name ?: "غير محدد")
                        ReceiptRow("رقم الهوية الوطنية:", f?.nationalID ?: "-")
                        ReceiptRow("عدد أفراد الأسرة:", "${f?.familyMembersCount ?: 0} أفراد")
                        ReceiptRow("نوع المساعدة:", aidName)
                        ReceiptRow("المشروع الإغاثي:", prjNum)
                        ReceiptRow("تاريخ التسليم:", r.deliveryDate ?: r.aidDate)
                        ReceiptRow("المستودع:", r.warehouse)
                        ReceiptRow("ملاحظات الصرف:", r.notes ?: "تم التسليم بحالة جيدة")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        recordForReceipt = null
                        actionMessage = "تم إرسال أمر طباعة السند REC-${r.aidRecordID}"
                    }
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة / طباعة")
                }
            },
            dismissButton = {
                TextButton(onClick = { recordForReceipt = null }) {
                    Text("إغلاق")
                }
            }
        )
    }

    if (recordToUndo != null) {
        val targetRecord = recordToUndo!!
        val targetFamily = familyMap[targetRecord.familyID]
        val targetProject = projectMap[targetRecord.projectID]

        AlertDialog(
            onDismissRequest = {
                recordToUndo = null
                undoReasonText = ""
                undoReasonError = false
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "تأكيد التراجع عن تسليم المساعدة",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "تحذير رقابي: سيتم إلغاء حالة التسليم وإعادة السجل لكشوفات الانتظار للمستفيد التالي:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "المستفيد: ${targetFamily?.name ?: "غير محدد"}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "رقم الهوية: ${targetFamily?.nationalID ?: "-"}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "المشروع: ${targetProject?.projectName ?: "مشروع #${targetRecord.projectID}"}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "سبب التراجع عن التسليم (إلزامي للتوثيق والرقابة):*",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (undoReasonError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                    )

                    OutlinedTextField(
                        value = undoReasonText,
                        onValueChange = {
                            undoReasonText = it
                            if (it.isNotBlank()) undoReasonError = false
                        },
                        placeholder = { Text("مثال: خطأ في مطابقة الهوية، عدم استلام الطرد فعلياً، تسجيل مكرر...") },
                        isError = undoReasonError,
                        supportingText = if (undoReasonError) {
                            { Text("سبب التراجع إلزامي ويتم حفظه في سجل الرقابة والمطابقة", color = MaterialTheme.colorScheme.error, fontSize = 10.sp) }
                        } else null,
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmedReason = undoReasonText.trim()
                        if (trimmedReason.isBlank()) {
                            undoReasonError = true
                        } else {
                            scope.launch {
                                repository.undoDeliveryWithReason(targetRecord.aidRecordID, trimmedReason)
                                actionMessage = "تم التراجع وتوثيق السبب في سجل الرقابة بنجاح"
                                recordToUndo = null
                                undoReasonText = ""
                                undoReasonError = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تأكيد التراجع والتوثيق", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    recordToUndo = null
                    undoReasonText = ""
                    undoReasonError = false
                }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showScannerDialog) {
        var scannedIdInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showScannerDialog = false },
            title = { Text("مسح باركود الهوية الوطنية / كرت المؤن") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "وجّه الكاميرا نحو باركود الهوية أو أدخل رقم الهوية السريع:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = scannedIdInput,
                        onValueChange = { scannedIdInput = it },
                        label = { Text("رقم الهوية (9 أرقام)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    searchQuery = scannedIdInput
                    showScannerDialog = false
                }) {
                    Text("بحث فوري")
                }
            },
            dismissButton = {
                TextButton(onClick = { showScannerDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showSyncDialog) {
        SyncDetailsDialog(
            repository = repository,
            onDismiss = { showSyncDialog = false }
        )
    }
}

@Composable
fun DeliveryCardItem(
    record: AidRecordEntity,
    family: FamilyEntity?,
    aidTypeName: String,
    projectNumber: String,
    isDelivered: Boolean,
    onDeliverClick: () -> Unit,
    onReceiptClick: () -> Unit,
    onUndoClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = family?.name ?: "مواطن رقم #${record.familyID}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "الهوية: ${family?.nationalID ?: "-"} • الأفراد: ${family?.familyMembersCount ?: 0}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                }

                if (isDelivered) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تم التسليم", color = Color(0xFF10B981), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF59E0B).copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("جاهز للصرف", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = aidTypeName,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = projectNumber,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }

            if (!record.notes.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = record.notes ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isDelivered) {
                    Button(
                        onClick = onDeliverClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تسليم فوري", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                } else {
                    OutlinedButton(
                        onClick = onReceiptClick,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.List, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("سند الاستلام", fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    TextButton(
                        onClick = onUndoClick,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("تراجع", color = Color(0xFFF59E0B), fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))
                IconButton(onClick = onDeleteClick, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun ReceiptRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
        Text(text = value, style = MaterialTheme.typography.bodySmall)
    }
}
