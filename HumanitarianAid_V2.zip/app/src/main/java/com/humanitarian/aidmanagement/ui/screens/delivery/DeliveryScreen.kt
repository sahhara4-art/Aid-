package com.humanitarian.aidmanagement.ui.screens.delivery

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.CameraScannerDialog
import com.humanitarian.aidmanagement.ui.components.SyncDetailsDialog
import com.humanitarian.aidmanagement.ui.components.SyncStatusBanner
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeliveryScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    viewModel: DeliveryViewModel = viewModel(
        factory = DeliveryViewModel.Factory(repository)
    )
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val allowedLoc = currentUser?.AllowedLocalityID ?: 0
    val isLocRestricted = allowedLoc != 0 && !viewModel.isSuperAdmin()
    val haptic = LocalHapticFeedback.current

    val rawAidRecords by viewModel.rawAidRecords.collectAsStateWithLifecycle()
    val projectFamiliesMap by viewModel.projectFamilies.collectAsStateWithLifecycle()
    val aidTypes: List<AidTypeEntity> by viewModel.aidTypes.collectAsStateWithLifecycle()
    val projects: List<ProjectEntity> by viewModel.projects.collectAsStateWithLifecycle()
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()

    val familyMap: Map<Long, FamilyEntity> = projectFamiliesMap
    val aidTypeMap: Map<Int, AidTypeEntity> = remember(aidTypes) { aidTypes.associateBy { aidType: AidTypeEntity -> aidType.aidTypeID } }
    val projectMap: Map<Long, ProjectEntity> = remember(projects) { projects.associateBy { prj: ProjectEntity -> prj.projectID } }

    // عزل سجلات المساعدات جغرافياً: المستخدم المقيد يرى حصراً مستفيدي محليته
    val aidRecords = remember(rawAidRecords, familyMap, isLocRestricted, allowedLoc) {
        if (isLocRestricted) {
            rawAidRecords.filter { record ->
                val fam = familyMap[record.familyID]
                fam != null && fam.localityID == allowedLoc
            }
        } else {
            rawAidRecords
        }
    }

    var isProjectDropdownExpanded by remember { mutableStateOf(false) }

    // تحديد المشروع النشط الافتراضي تلقائياً عند تحميل قائمة المشاريع
    LaunchedEffect(projects) {
        if (projects.isNotEmpty() && (uiState.selectedProjectId == null || projects.none { it.projectID == uiState.selectedProjectId })) {
            viewModel.selectProject(projects.first().projectID)
        }
    }

    // تصفية السجلات حصراً للمشروع المحدد حالياً (نظام تسليم مرتبط بمشروع واحد)
    val projectAidRecords = remember(aidRecords, uiState.selectedProjectId) {
        if (uiState.selectedProjectId == null) emptyList()
        else aidRecords.filter { it.projectID == uiState.selectedProjectId }
    }

    // حوارات التسليم، سند الاستلام، التراجع الصارم، والمسح
    var recordToDeliver by remember { mutableStateOf<AidRecordEntity?>(null) }
    var recordForReceipt by remember { mutableStateOf<AidRecordEntity?>(null) }
    var recordToUndo by remember { mutableStateOf<AidRecordEntity?>(null) }
    var undoReasonText by remember { mutableStateOf("") }
    var undoReasonError by remember { mutableStateOf(false) }

    var showScannerDialog by remember { mutableStateOf(false) }
    var showSyncDialog by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    // تصفية السجلات المعروضة للمشروع المحدد بالاعتماد البارز على الاسم الرباعي ورقم الهوية الوطنية
    val filteredRecords = remember(projectAidRecords, uiState.searchQuery, uiState.selectedStatusFilter, familyMap) {
        val query = uiState.searchQuery.trim()
        projectAidRecords.filter { record ->
            val family = familyMap[record.familyID]
            val fullName = family?.name ?: ""
            val nationalId = family?.nationalID ?: ""
            val primaryPhone = family?.primary_phone ?: ""
            val altPhone1 = family?.alternative_phone_1 ?: ""
            val altPhone2 = family?.alternative_phone_2 ?: ""
            val wifeName = family?.wifeName ?: ""
            val wifeNationalId = family?.wifeNationalID ?: ""

            // البحث الشامل: الاسم، الهوية، الجوال، بيانات الزوجة
            val matchesSearch = query.isBlank() ||
                    fullName.contains(query, ignoreCase = true) ||
                    nationalId.contains(query) ||
                    primaryPhone.contains(query) ||
                    altPhone1.contains(query) ||
                    altPhone2.contains(query) ||
                    wifeName.contains(query, ignoreCase = true) ||
                    wifeNationalId.contains(query)

            // 2. تصنيف الحالات
            val isDelivered = record.recipientStatus.contains("مستلم") ||
                    record.recipientStatus.contains("تم التسليم") ||
                    record.recipientStatus.contains("مستفيد")
            val isReverted = record.recipientStatus == "مرشح" &&
                    (record.notes?.contains("تم التراجع عن التسليم") == true || record.notes?.contains("سبب التراجع") == true)

            val matchesStatus = when (uiState.selectedStatusFilter) {
                "تم التسليم" -> isDelivered
                "بانتظار التسليم" -> !isDelivered && !isReverted
                "تم التراجع عنه" -> isReverted
                else -> true
            }

            matchesSearch && matchesStatus
        }
    }

    // مؤشرات الإنجاز الدقيقة الخاصة بالمشروع المحدد حصراً
    val totalCount = projectAidRecords.size
    val deliveredCount = projectAidRecords.count {
        it.recipientStatus.contains("مستلم") || it.recipientStatus.contains("تم التسليم") || it.recipientStatus.contains("مستفيد")
    }
    val revertedCount = projectAidRecords.count {
        it.recipientStatus == "مرشح" && (it.notes?.contains("تم التراجع عن التسليم") == true || it.notes?.contains("سبب التراجع") == true)
    }
    val pendingCount = totalCount - deliveredCount
    val deliveryRate = if (totalCount > 0) (deliveredCount * 100 / totalCount) else 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "تسليم وصرف المساعدات الميدانية",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "نقطة التوزيع وتوثيق الاستلام بالباركود",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        viewModel.resetFilters()
                        onNavigateBack()
                    }) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { showSyncDialog = true }) {
                        Icon(
                            imageVector = if (syncState.isOnline) Icons.Default.CloudSync else Icons.Default.CloudOff,
                            contentDescription = "التزامن والعمل دون اتصال",
                            tint = if (syncState.isOnline) MaterialTheme.colorScheme.primary else Color(0xFFF59E0B)
                        )
                    }
                    IconButton(onClick = { showScannerDialog = true }) {
                        Icon(Icons.Default.Search, contentDescription = "مسح باركود الهوية", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            // شريط حالة المزامنة والعمل دون اتصال
            SyncStatusBanner(
                repository = repository,
                onOpenSyncDetails = { showSyncDialog = true }
            )

            Spacer(modifier = Modifier.height(6.dp))

            // ==================== محدد المشروع الإنساني النشط للتسليم ====================
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Assignment, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Text(
                                text = "المشروع الإنساني النشط للتسليم والصرف:",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "مشروع محدد حصراً",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(modifier = Modifier.fillMaxWidth()) {
                        val currentProject = projects.firstOrNull { it.projectID == uiState.selectedProjectId }
                        OutlinedCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isProjectDropdownExpanded = true },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = currentProject?.projectName ?: "اضغط لاختيار المشروع الإنساني",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodyMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (currentProject != null) {
                                        Text(
                                            text = "رمز المشروع: ${currentProject.projectNumber} • ${currentProject.fundingInstitution}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            }
                        }

                        DropdownMenu(
                            expanded = isProjectDropdownExpanded,
                            onDismissRequest = { isProjectDropdownExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            for (prj: ProjectEntity in projects) {
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            Text("${prj.projectNumber} - ${prj.fundingInstitution}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    },
                                    onClick = {
                                        viewModel.selectProject(prj.projectID)
                                        isProjectDropdownExpanded = false
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = if (prj.projectID == uiState.selectedProjectId) Icons.Default.CheckCircle else Icons.Default.Folder,
                                            contentDescription = null,
                                            tint = if (prj.projectID == uiState.selectedProjectId) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // شريط إحصائيات التسليم السريعة للمشروع المحدد حصراً (KPIs)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("إجمالي الكشوفات", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$totalCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("تم التسليم", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$deliveredCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color(0xFF10B981))
                    }
                    Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("بانتظار الصرف", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$pendingCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color(0xFFF59E0B))
                    }
                    Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("تراجع عنه", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$revertedCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color(0xFFDC2626))
                    }
                    Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("نسبة الإنجاز", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$deliveryRate%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color(0xFF0284C7))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // مربع البحث الشامل بالاسم، الهوية، الجوال، وبيانات الزوجة
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                label = { Text("بحث بالاسم، الهوية، الجوال، أو بيانات الزوجة...") },
                placeholder = { Text("ابحث بالاسم، الهوية، الجوال، أو بيانات الزوجة...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "مسح")
                            }
                        }
                        IconButton(onClick = { showScannerDialog = true }) {
                            Icon(
                                Icons.Default.CameraAlt,
                                contentDescription = "مسح الكاميرا",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))

            // أزرار تصفية الحالة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("الكل", "بانتظار التسليم", "تم التسليم", "تم التراجع عنه").forEach { filterLabel ->
                    FilterChip(
                        selected = uiState.selectedStatusFilter == filterLabel,
                        onClick = { viewModel.setStatusFilter(filterLabel) },
                        label = { Text(filterLabel, fontSize = 11.sp) }
                    )
                }
            }

            if (uiState.actionMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981).copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = uiState.actionMessage ?: "", color = Color(0xFF047857), style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        IconButton(onClick = { viewModel.clearActionMessage() }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color(0xFF047857), modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            if (uiState.errorMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = uiState.errorMessage ?: "", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                        IconButton(onClick = { viewModel.clearActionMessage() }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "سجلات الصرف والتسليم للمشروع (${filteredRecords.size} مستفيد):",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (filteredRecords.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f), modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (uiState.selectedProjectId == null) "الرجاء اختيار مشروع نشط أولاً" else "لا توجد سجلات تسليم أو ترشيح تطابق البحث الحالي",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredRecords, key = { it.aidRecordID }) { record ->
                        val family = familyMap[record.familyID]
                        val aidTypeName = aidTypeMap[record.aidTypeID]?.aidTypeName ?: "مساعدة #${record.aidTypeID}"
                        val projectNumber = projectMap[record.projectID]?.projectNumber ?: "مشروع #${record.projectID}"
                        val isDelivered = record.recipientStatus.contains("مستلم") ||
                                record.recipientStatus.contains("تم التسليم") ||
                                record.recipientStatus.contains("مستفيد")
                        val isReverted = record.recipientStatus == "مرشح" &&
                                (record.notes?.contains("تم التراجع عن التسليم") == true || record.notes?.contains("سبب التراجع") == true)

                        DeliveryCardItem(
                            record = record,
                            family = family,
                            aidTypeName = aidTypeName,
                            projectNumber = projectNumber,
                            isDelivered = isDelivered,
                            isReverted = isReverted,
                            onDeliverClick = { recordToDeliver = record },
                            onReceiptClick = { recordForReceipt = record },
                            onUndoClick = {
                                recordToUndo = record
                                undoReasonText = ""
                                undoReasonError = false
                            },
                            onDeleteClick = {
                                viewModel.deleteAidRecord(record.aidRecordID)
                            }
                        )
                    }
                }
            }
        }
    }

    // ==================== حوار تأكيد التسليم والصرف والتعبئة التلقائية ====================
    if (recordToDeliver != null) {
        val targetRecord = recordToDeliver!!
        val targetFamily = familyMap[targetRecord.familyID]
        val headName = targetFamily?.name ?: ""
        val wifeName = targetFamily?.wifeName ?: ""

        var recipientRelation by remember { mutableStateOf("رب الأسرة (نفسه)") }
        var recipientName by remember { mutableStateOf(headName) }
        var deliveryNotes by remember { mutableStateOf("") }

        // وقت التسليم الفعلي المتوقع توثيقه لحظياً
        val currentDateTimeStr = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()) }

        AlertDialog(
            onDismissRequest = { recordToDeliver = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981))
                    Text("تأكيد تسليم وصرف المساعدة", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // بيانات المواطن الأساسية المعروضة بشكل بارز (الاسم الرباعي ورقم الهوية الوطنية)
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "المستفيد الأساسي (الاسم الرباعي): $headName",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Badge, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "رقم الهوية الوطنية: ${targetFamily?.nationalID ?: "-"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            if (wifeName.isNotBlank()) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.FamilyRestroom, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(16.dp))
                                    Text(
                                        text = "اسم الزوجة المسجل: $wifeName",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF0284C7)
                                    )
                                }
                            }
                        }
                    }

                    Divider()

                    // اختيار صلة القرابة والتعبئة التلقائية لاسم المستلم
                    Text("صلة القرابة للمستلم الفعلي:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("رب الأسرة (نفسه)", "الزوجة", "ابن بالغ", "وكيل").forEach { rel ->
                            FilterChip(
                                selected = recipientRelation == rel,
                                onClick = {
                                    recipientRelation = rel
                                    when (rel) {
                                        "رب الأسرة (نفسه)" -> recipientName = headName
                                        "الزوجة" -> recipientName = wifeName
                                        "ابن بالغ" -> recipientName = ""
                                        "وكيل" -> recipientName = ""
                                    }
                                },
                                label = { Text(rel, fontSize = 11.sp) }
                            )
                        }
                    }

                    // حقل اسم المستلم الفعلي (معبأ تلقائياً)
                    OutlinedTextField(
                        value = recipientName,
                        onValueChange = { recipientName = it },
                        label = { Text("اسم المستلم الفعلي (الاسم الرباعي)") },
                        supportingText = {
                            if (recipientRelation == "الزوجة" && wifeName.isBlank()) {
                                Text("تنبيه: اسم الزوجة غير مسجل مسبقاً، يرجى كتابته يدوياً", color = MaterialTheme.colorScheme.error, fontSize = 10.sp)
                            } else {
                                Text("تتم التعبئة التلقائية عند اختيار صفة المستلم مع إمكانية التعديل", fontSize = 10.sp)
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // حقل نصي لإدخال ملاحظات التسليم (Delivery Notes)
                    OutlinedTextField(
                        value = deliveryNotes,
                        onValueChange = { deliveryNotes = it },
                        label = { Text("ملاحظات التسليم (Delivery Notes)") },
                        placeholder = { Text("أدخل أي ملاحظات ميدانية حول عملية التسليم وحالة الطرد...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    // إشعار التوثيق الآلي لتاريخ ووقت التسليم الفعلي
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.08f),
                        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.AccessTime, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تاريخ ووقت التسليم الفعلي: $currentDateTimeStr (يُسجل آلياً بالثواني عند التأكيد)",
                                fontSize = 11.sp,
                                color = Color(0xFF047857),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        val cleanRecipient = recipientName.trim().ifEmpty { headName }
                        viewModel.deliverAid(
                            recordId = targetRecord.aidRecordID,
                            recipientName = cleanRecipient,
                            recipientRelation = recipientRelation,
                            deliveryNotes = deliveryNotes,
                            citizenName = headName
                        )
                        recordToDeliver = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تأكيد الصرف والتسليم", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToDeliver = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // ==================== حوار سند الاستلام الرسمي ====================
    if (recordForReceipt != null) {
        val r = recordForReceipt!!
        val f = familyMap[r.familyID]
        val aidName = aidTypeMap[r.aidTypeID]?.aidTypeName ?: "مساعدة إغاثية"
        val prjNum = projectMap[r.projectID]?.projectNumber ?: "PRJ-2025"

        AlertDialog(
            onDismissRequest = { recordForReceipt = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("سند استلام مساعدة إنسانية معتمد", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReceiptRow("رقم السند الميداني:", "REC-${r.aidRecordID}")
                        ReceiptRow("اسم رب الأسرة (الرباعي):", f?.name ?: "غير محدد")
                        ReceiptRow("رقم الهوية الوطنية:", f?.nationalID ?: "-")
                        ReceiptRow("عدد أفراد الأسرة:", "${f?.familyMembersCount ?: 0} أفراد")
                        ReceiptRow("نوع المساعدة:", aidName)
                        ReceiptRow("المشروع الإغاثي:", prjNum)
                        ReceiptRow("تاريخ ووقت التسليم الفعلي:", r.deliveryDate ?: r.aidDate)
                        ReceiptRow("المستودع:", r.warehouse)
                        ReceiptRow("ملاحظات الصرف والتسليم:", r.notes ?: "تم التسليم بحالة جيدة")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        recordForReceipt = null
                    }
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة / طباعة")
                }
            },
            dismissButton = {
                TextButton(onClick = { recordForReceipt = null }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // ==================== حوار التراجع الصارم عن التسليم مع سبب التراجع الإلزامي ====================
    if (recordToUndo != null) {
        val targetRecord = recordToUndo!!
        val targetFamily = familyMap[targetRecord.familyID]
        val targetProject = projectMap[targetRecord.projectID]

        AlertDialog(
            onDismissRequest = {
                recordToUndo = null
                undoReasonText = ""
                undoReasonError = false
            },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "تأكيد التراجع عن تسليم المساعدة",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "تحذير رقابي: سيتم إلغاء حالة التسليم وإعادة السجل لحالة 'مرشح' للمستفيد التالي:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "الاسم الرباعي: ${targetFamily?.name ?: "غير محدد"}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "رقم الهوية الوطنية: ${targetFamily?.nationalID ?: "-"}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "المشروع: ${targetProject?.projectName ?: "مشروع #${targetRecord.projectID}"}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "سبب التراجع عن التسليم (إلزامي للتوثيق والرقابة):*",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (undoReasonError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                    )

                    OutlinedTextField(
                        value = undoReasonText,
                        onValueChange = {
                            undoReasonText = it
                            if (it.isNotBlank()) undoReasonError = false
                        },
                        placeholder = { Text("مثال: خطأ في مطابقة الهوية، عدم استلام الطرد فعلياً، استرجاع للمستودع...") },
                        isError = undoReasonError,
                        supportingText = if (undoReasonError) {
                            { Text("سبب التراجع إلزامي ويتم حفظه في ملاحظات المساعدة وسجل الرقابة", color = MaterialTheme.colorScheme.error, fontSize = 10.sp) }
                        } else null,
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmedReason = undoReasonText.trim()
                        if (trimmedReason.isBlank()) {
                            undoReasonError = true
                        } else {
                            viewModel.undoDelivery(
                                recordId = targetRecord.aidRecordID,
                                reason = trimmedReason,
                                citizenName = targetFamily?.name ?: ""
                            )
                            recordToUndo = null
                            undoReasonText = ""
                            undoReasonError = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Icon(Icons.Default.Undo, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تأكيد التراجع والتوثيق", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    recordToUndo = null
                    undoReasonText = ""
                    undoReasonError = false
                }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // ==================== حوار كاميرا مسح الباركود والهويات الذكي ====================
    if (showScannerDialog) {
        CameraScannerDialog(
            onIdScanned = { scannedId ->
                viewModel.setSearchQuery(scannedId)
                showScannerDialog = false
            },
            onDismiss = { showScannerDialog = false }
        )
    }

    if (showSyncDialog) {
        SyncDetailsDialog(
            repository = repository,
            onDismiss = { showSyncDialog = false }
        )
    }
}

/**
 * بطاقة عرض سجل الصرف والتسليم لمواطن
 * تعرض الاسم الرباعي ورقم الهوية الوطنية بشكل بارز بدلاً من رقم المواطن
 * وتوضح تاريخ ووقت التسليم الفعلي وعلامة التراجع عن التسليم بدقة
 */
@Composable
fun DeliveryCardItem(
    record: AidRecordEntity,
    family: FamilyEntity?,
    aidTypeName: String,
    projectNumber: String,
    isDelivered: Boolean,
    isReverted: Boolean,
    onDeliverClick: () -> Unit,
    onReceiptClick: () -> Unit,
    onUndoClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = if (isReverted) BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.35f)) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        val beneficiaryName = remember(family, record) {
            val nameFromFam = family?.name?.trim()
            if (!nameFromFam.isNullOrBlank()) {
                nameFromFam
            } else {
                val fromNotes = record.notes?.let { n ->
                    Regex("(?:المستلم الفعلي|المستلم)\\s*:\\s*([^|\\n]+)").find(n)?.groupValues?.getOrNull(1)?.trim()
                }
                if (!fromNotes.isNullOrBlank()) fromNotes else "المستفيد غير مسجل"
            }
        }

        Column(modifier = Modifier.padding(14.dp)) {
            // ترويسة البطاقة: الاسم الرباعي ورقم الهوية الوطنية بشكل بارز
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = beneficiaryName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(Icons.Default.Badge, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(13.dp))
                                Text(
                                    text = family?.nationalID ?: "-",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Text(
                            text = "• ${family?.familyMembersCount ?: 0} أفراد",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // شارة حالة السجل
                if (isDelivered) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تم التسليم", color = Color(0xFF047857), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                } else if (isReverted) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFDC2626).copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.4f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Undo, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تم التراجع عن تسليمه", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF59E0B).copy(alpha = 0.15f),
                        border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.35f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مرشح للصرف", color = Color(0xFFB45309), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // تفاصيل نوع المساعدة والمشروع والمخزن بترتيب أفقي متناسق
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = aidTypeName,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = projectNumber,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = record.warehouse.ifBlank { "المستودع الرئيسي" },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // عرض تاريخ ووقت التسليم الفعلي إذا تم التسليم
            if (isDelivered && !record.deliveryDate.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF10B981).copy(alpha = 0.08f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.AccessTime, contentDescription = null, tint = Color(0xFF047857), modifier = Modifier.size(15.dp))
                        Text(
                            text = "تاريخ ووقت التسليم الفعلي: ${record.deliveryDate}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF047857)
                        )
                    }
                }
            }

            // صندوق توثيق سبب التراجع إن وجد
            if (isReverted) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFDC2626).copy(alpha = 0.08f),
                    border = BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "توثيق التراجع الرقابي:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color(0xFFDC2626)
                            )
                            Text(
                                text = record.notes ?: "تم التراجع عن التسليم وإرجاع الحالة لمرشح",
                                fontSize = 11.sp,
                                color = Color(0xFF991B1B)
                            )
                        }
                    }
                }
            } else if (!record.notes.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = record.notes ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // أزرار الإجراءات
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDeleteClick, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف السجل", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isDelivered) {
                        Button(
                            onClick = onDeliverClick,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isReverted) "إعادة التسليم" else "تسليم فوري",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    } else {
                        OutlinedButton(
                            onClick = onReceiptClick,
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("سند الاستلام", fontSize = 11.sp)
                        }

                        Button(
                            onClick = onUndoClick,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626).copy(alpha = 0.12f)),
                            border = BorderStroke(1.dp, Color(0xFFDC2626)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Undo, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تراجع عن التسليم", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReceiptRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
        Text(text = value, style = MaterialTheme.typography.bodySmall)
    }
}
