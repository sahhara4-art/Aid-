package com.humanitarian.aidmanagement.util

import java.io.BufferedWriter
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * كاتب ملفات Excel (.xlsx) متدفق نقي بدون أي اعتماد على java.awt أو Apache POI SXSSFWorkbook.
 * يمنع انهيار Failed resolution of: Ljava/awt/font/FontRenderContext نهائياً على أندرويد،
 * ويستهلك ذاكرة ثابتة (Zero-OOM) مع دعم كامل للغة العربية (RTL) وعرض الأعمدة الثابت/المحدد.
 */
class StreamingXlsxWriter(
    private val outputStream: OutputStream
) : AutoCloseable {

    enum class Style(val index: Int) {
        NORMAL(0),
        HEADER_TEAL(1),
        TITLE_TEAL(2),
        DATA_EVEN(3),
        DATA_ODD(4),
        HEADER_EMERALD(5),
        HEADER_AMBER(6),
        HEADER_SLATE(7),
        DATA_CENTER(8)
    }

    private data class SheetMeta(
        val index: Int,
        val name: String
    )

    private val zipOut = ZipOutputStream(outputStream)
    private val sheets = mutableListOf<SheetMeta>()
    private var closed = false

    fun writeSheet(
        rawSheetName: String,
        columnWidthsChars: List<Double>,
        freezeTopRow: Boolean = false,
        rightToLeft: Boolean = true,
        block: SheetWriter.() -> Unit
    ) {
        val sheetIndex = sheets.size + 1
        val safeName = sanitizeSheetName(rawSheetName, sheetIndex)
        sheets.add(SheetMeta(sheetIndex, safeName))

        zipOut.putNextEntry(ZipEntry("xl/worksheets/sheet$sheetIndex.xml"))
        val writer = BufferedWriter(OutputStreamWriter(zipOut, StandardCharsets.UTF_8), 16 * 1024)
        writer.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        writer.write("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")

        writer.write("<sheetViews>")
        writer.write("<sheetView workbookViewId=\"0\"")
        if (rightToLeft) {
            writer.write(" rightToLeft=\"1\"")
        }
        if (freezeTopRow) {
            writer.write("""><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView>""")
        } else {
            writer.write("/>")
        }
        writer.write("</sheetViews>")

        // تحديد عرض ثابت صريح لكل عمود (بدون autoSizeColumn أو java.awt)
        val effectiveWidths = if (columnWidthsChars.isNotEmpty()) columnWidthsChars else listOf(20.0)
        writer.write("<cols>")
        effectiveWidths.forEachIndexed { colIdx, widthChars ->
            val colNum = colIdx + 1
            val safeWidth = widthChars.coerceIn(6.0, 80.0)
            writer.write("""<col min="$colNum" max="$colNum" width="$safeWidth" customWidth="1"/>""")
        }
        writer.write("</cols>")

        writer.write("<sheetData>")
        val sheetWriter = SheetWriter(writer)
        sheetWriter.block()
        writer.write("</sheetData>")
        writer.write("</worksheet>")
        writer.flush()
        zipOut.closeEntry()
    }

    override fun close() {
        if (closed) return
        closed = true

        if (sheets.isEmpty()) {
            writeSheet("Sheet1", listOf(20.0)) {}
        }

        writeZipEntry("[Content_Types].xml") { w ->
            w.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            w.write("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
            w.write("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
            w.write("""<Default Extension="xml" ContentType="application/xml"/>""")
            w.write("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
            w.write("""<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
            sheets.forEach { s ->
                w.write("""<Override PartName="/xl/worksheets/sheet${s.index}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
            }
            w.write("</Types>")
        }

        writeZipEntry("_rels/.rels") { w ->
            w.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            w.write("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
            w.write("""<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>""")
            w.write("</Relationships>")
        }

        writeZipEntry("xl/_rels/workbook.xml.rels") { w ->
            w.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            w.write("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
            sheets.forEach { s ->
                w.write("""<Relationship Id="rId${s.index}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${s.index}.xml"/>""")
            }
            val stylesRelId = sheets.size + 1
            w.write("""<Relationship Id="rId$stylesRelId" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""")
            w.write("</Relationships>")
        }

        writeZipEntry("xl/workbook.xml") { w ->
            w.write("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
            w.write("""<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""")
            w.write("<sheets>")
            sheets.forEach { s ->
                w.write("""<sheet name="${escapeXmlAttr(s.name)}" sheetId="${s.index}" r:id="rId${s.index}"/>""")
            }
            w.write("</sheets>")
            w.write("</workbook>")
        }

        writeZipEntry("xl/styles.xml") { w ->
            w.write(STYLES_XML)
        }

        zipOut.finish()
        zipOut.flush()
    }

    private fun writeZipEntry(path: String, block: (BufferedWriter) -> Unit) {
        zipOut.putNextEntry(ZipEntry(path))
        val writer = BufferedWriter(OutputStreamWriter(zipOut, StandardCharsets.UTF_8), 8 * 1024)
        block(writer)
        writer.flush()
        zipOut.closeEntry()
    }

    private fun sanitizeSheetName(raw: String, index: Int): String {
        val cleaned = raw
            .replace(Regex("[\\\\/?*\\[\\]:]"), "-")
            .trim()
            .take(28)
            .ifBlank { "Sheet$index" }
        return if (sheets.any { it.name.equals(cleaned, ignoreCase = true) }) {
            "${cleaned.take(24)}_$index"
        } else {
            cleaned
        }
    }

    class SheetWriter(
        private val writer: BufferedWriter
    ) {
        private var currentRowNumber = 0

        fun writeRow(
            values: List<String>,
            style: Style = Style.NORMAL,
            heightPoints: Float? = null,
            explicitRowOneBased: Int? = null
        ) {
            val rowNum = explicitRowOneBased ?: (currentRowNumber + 1)
            currentRowNumber = rowNum

            writer.write("<row r=\"$rowNum\"")
            if (heightPoints != null) {
                writer.write(" ht=\"$heightPoints\" customHeight=\"1\"")
            }
            writer.write(">")

            val styleIdx = style.index
            for (colIdx in values.indices) {
                val colRef = columnIndexToLetter(colIdx)
                val safeText = escapeXmlText(values[colIdx])
                writer.write("""<c r="$colRef$rowNum" s="$styleIdx" t="inlineStr"><is><t xml:space="preserve">$safeText</t></is></c>""")
            }

            writer.write("</row>")
        }
    }

    companion object {
        fun poiUnitsToChars(poiWidth: Int): Double = (poiWidth / 256.0).coerceIn(8.0, 60.0)

        private fun columnIndexToLetter(colIndex: Int): String {
            var n = colIndex
            val sb = StringBuilder(3)
            while (n >= 0) {
                sb.append(('A' + (n % 26)))
                n = (n / 26) - 1
            }
            return sb.reverse().toString()
        }

        private fun escapeXmlText(input: String): String {
            if (input.isEmpty()) return ""
            val sb = StringBuilder(input.length + 8)
            for (ch in input) {
                when (ch) {
                    '&' -> sb.append("&amp;")
                    '<' -> sb.append("&lt;")
                    '>' -> sb.append("&gt;")
                    // تجاهل محارف التحكم المحظورة في XML 1.0
                    in '\u0000'..'\u0008', '\u000B', '\u000C', in '\u000E'..'\u001F' -> Unit
                    else -> sb.append(ch)
                }
            }
            return sb.toString()
        }

        private fun escapeXmlAttr(input: String): String {
            if (input.isEmpty()) return ""
            val sb = StringBuilder(input.length + 8)
            for (ch in input) {
                when (ch) {
                    '&' -> sb.append("&amp;")
                    '<' -> sb.append("&lt;")
                    '>' -> sb.append("&gt;")
                    '"' -> sb.append("&quot;")
                    '\'' -> sb.append("&apos;")
                    in '\u0000'..'\u0008', '\u000B', '\u000C', in '\u000E'..'\u001F' -> Unit
                    else -> sb.append(ch)
                }
            }
            return sb.toString()
        }

        private val STYLES_XML = """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
              <fonts count="3">
                <font><sz val="11"/><color rgb="FF0F172A"/><name val="Arial"/></font>
                <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Arial"/></font>
                <font><b/><sz val="13"/><color rgb="FF0F5E59"/><name val="Arial"/></font>
              </fonts>
              <fills count="7">
                <fill><patternFill patternType="none"/></fill>
                <fill><patternFill patternType="gray125"/></fill>
                <fill><patternFill patternType="solid"><fgColor rgb="FF0F5E59"/></patternFill></fill>
                <fill><patternFill patternType="solid"><fgColor rgb="FF107C41"/></patternFill></fill>
                <fill><patternFill patternType="solid"><fgColor rgb="FFD97706"/></patternFill></fill>
                <fill><patternFill patternType="solid"><fgColor rgb="FF475569"/></patternFill></fill>
                <fill><patternFill patternType="solid"><fgColor rgb="FFF1F5F9"/></patternFill></fill>
              </fills>
              <borders count="3">
                <border><left/><right/><top/><bottom/><diagonal/></border>
                <border>
                  <left style="thin"><color rgb="FFCBD5E1"/></left>
                  <right style="thin"><color rgb="FFCBD5E1"/></right>
                  <top style="thin"><color rgb="FFCBD5E1"/></top>
                  <bottom style="thin"><color rgb="FFCBD5E1"/></bottom>
                  <diagonal/>
                </border>
                <border>
                  <left style="thin"><color rgb="FFFFFFFF"/></left>
                  <right style="thin"><color rgb="FFFFFFFF"/></right>
                  <top style="thin"><color rgb="FFFFFFFF"/></top>
                  <bottom style="medium"><color rgb="FFFFFFFF"/></bottom>
                  <diagonal/>
                </border>
              </borders>
              <cellStyleXfs count="1">
                <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
              </cellStyleXfs>
              <cellXfs count="9">
                <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
                <xf numFmtId="0" fontId="1" fillId="2" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
                <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
                <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
                <xf numFmtId="0" fontId="0" fillId="6" borderId="1" xfId="0" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="right" vertical="center"/></xf>
                <xf numFmtId="0" fontId="1" fillId="3" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
                <xf numFmtId="0" fontId="1" fillId="4" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
                <xf numFmtId="0" fontId="1" fillId="5" borderId="2" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf>
                <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
              </cellXfs>
              <cellStyles count="1">
                <cellStyle name="Normal" xfId="0" builtinId="0"/>
              </cellStyles>
            </styleSheet>
        """.trimIndent().replace(Regex(">\\s+<"), "><")
    }
}
