package com.humanitarian.aidmanagement.data.security

import org.mindrot.jbcrypt.BCrypt
import java.security.MessageDigest

object HashUtils {

    /**
     * Hashes password using BCrypt with salt
     */
    fun hashPassword(password: String): String {
        return try {
            BCrypt.hashpw(password, BCrypt.gensalt(10))
        } catch (e: Exception) {
            // Fallback to SHA-256 with salt if BCrypt encounters platform issues
            sha256(password + "_aid_salt_2026")
        }
    }

    /**
     * Validates raw password against stored hash (supporting both BCrypt and SHA-256)
     */
    fun verifyPassword(password: String, storedHash: String): Boolean {
        return try {
            if (storedHash.startsWith("$2a$") || storedHash.startsWith("$2b$") || storedHash.startsWith("$2y$")) {
                BCrypt.checkpw(password, storedHash)
            } else {
                sha256(password + "_aid_salt_2026") == storedHash
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
