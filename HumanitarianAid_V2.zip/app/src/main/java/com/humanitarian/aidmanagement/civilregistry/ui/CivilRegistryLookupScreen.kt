package com.humanitarian.aidmanagement.civilregistry.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.civilregistry.bridge.CivilRegistryDraftBridge
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryDbStatus
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySchema
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchScope
import com.humanitarian.aidmanagement.civilregistry.security.CivilRegistryPermissionGuard
import com.humanitarian.aidmanagement.civilregistry.viewmodel.CivilRegistrySearchViewModel
import com.humanitarian.aidmanagement.security.AccessControlManager
import java.text.NumberFormat
import java.util.Locale

private val CivilRegistryBackdrop = Brush.verticalGradient(
    colors = listOf(
        Color(0xFFEDF7F2),
        Color(0xFFF6FAF8),
        Color(0xFFEAF4EF)
    )
)

private val GlassBorder = Color(0xFFD6E8DF)
private val SoftDivider = Color(0xFFECF3EF)
private val EmeraldPrimary = Color(0xFF0F7B53)
private val DeepSlate = Color(0xFF0F172A)
private val CalmGray = Color(0xFF5F6E68)
private val SkyAccent = Color(0xFF0284C7)
private val IndigoAccent = Color(0xFF4F46E5)
private val AmberAccent = Color(0xFFD97706)
private val CoralAccent = Color(0xFFC62828)

/**
 * شاشة وحدة البحث في السجل المدني (Read-Only Lookup Module - Glassmorphism V3.0)
 *
 * - مفصولة 100% عن قاعدة بيانات المشروع (لا تعدل أبداً في civil_registry.db)
 * - مصممة بأسلوب زجاجي خفيف بدون Blur أو ظلال ثقيلة لتعمل بسلاسة تامة على الأجهزة المتوسطة
 * - ترحّل السجل المختار فقط كمسودة قابلة للتعديل إلى شاشة الإضافة الخاصة بالمشروع
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CivilRegistryLookupScreen(
    onNavigateBack: () -> Unit,
    onTransferToAddFamily: () -> Unit
) {
    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val currentPermissions by AccessControlManager.permissionsFlow.collectAsStateWithLifecycle()
    val canAccessCivilRegistry = remember(currentUser, currentPermissions) {
        CivilRegistryPermissionGuard.canAccessCivilRegistry(currentUser, currentPermissions)
    }

    // الإخفاء الكامل والمنع الصامت عند عدم التخويل: لا تُعرض أي شاشة أو رسالة رفض ولا يُنشأ ViewModel أو أي استعلام
    if (!canAccessCivilRegistry) {
        LaunchedEffect(Unit) {
            CivilRegistryDraftBridge.clearDraft()
            onNavigateBack()
        }
        return
    }

    val context = LocalContext.current
    val viewModel: CivilRegistrySearchViewModel = viewModel(
        factory = CivilRegistrySearchViewModel.Factory(context.applicationContext)
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    LaunchedEffect(canAccessCivilRegistry) {
        viewModel.refreshPermissionsAndDatabase()
    }

    val dbPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.importDatabaseFromUri(uri)
        }
    }

    val numberFormat = remember { NumberFormat.getIntegerInstance(Locale.US) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CivilRegistryBackdrop)
        ) {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = "البحث في السجل المدني",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = DeepSlate
                                )
                                val subtitle = when (val status = uiState.dbStatus) {
                                    is CivilRegistryDbStatus.Ready ->
                                        "وحدة استعلام للقراءة فقط • ${numberFormat.format(status.totalRecords)} سجل"
                                    is CivilRegistryDbStatus.Checking -> "جاري التحقق من قاعدة السجل المدني..."
                                    is CivilRegistryDbStatus.Missing -> "قاعدة civil_registry.db غير مربوطة بعد"
                                    is CivilRegistryDbStatus.Error -> "تعذر تحميل قاعدة السجل المدني"
                                }
                                Text(
                                    text = subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CalmGray,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onNavigateBack) {
                                Icon(
                                    imageVector = Icons.Rounded.ArrowForward,
                                    contentDescription = "رجوع",
                                    tint = DeepSlate
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = { dbPickerLauncher.launch(arrayOf("*/*")) }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.FolderOpen,
                                    contentDescription = "اختيار ملف civil_registry.db",
                                    tint = EmeraldPrimary
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color(0xFFEDF7F2).copy(alpha = 0.94f),
                            titleContentColor = DeepSlate
                        )
                    )
                }
            ) { paddingValues ->
                when {
                    uiState.dbStatus is CivilRegistryDbStatus.Checking || uiState.isImportingDb -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues),
                            contentAlignment = Alignment.Center
                        ) {
                            LightweightGlassCard(modifier = Modifier.padding(24.dp)) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    CircularProgressIndicator(color = EmeraldPrimary)
                                    Text(
                                        text = if (uiState.isImportingDb) {
                                            "جاري ربط قاعدة البيانات civil_registry.db للقراءة فقط..."
                                        } else {
                                            "جاري تهيئة محرك البحث المفهرس..."
                                        },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = DeepSlate,
                                        fontWeight = FontWeight.SemiBold,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    uiState.dbStatus is CivilRegistryDbStatus.Missing -> {
                        CivilRegistryDatabaseMissingView(
                            expectedPath = (uiState.dbStatus as CivilRegistryDbStatus.Missing).expectedPath,
                            onPickDatabaseFile = { dbPickerLauncher.launch(arrayOf("*/*")) },
                            onRetry = { viewModel.refreshPermissionsAndDatabase() },
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                                .padding(20.dp)
                        )
                    }

                    uiState.dbStatus is CivilRegistryDbStatus.Error -> {
                        CivilRegistryDatabaseErrorView(
                            message = (uiState.dbStatus as CivilRegistryDbStatus.Error).message,
                            onPickDatabaseFile = { dbPickerLauncher.launch(arrayOf("*/*")) },
                            onRetry = { viewModel.refreshPermissionsAndDatabase() },
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                                .padding(20.dp)
                        )
                    }

                    else -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                        ) {
                            // منطقة البحث العلوية (شريط البحث السريع + شرائح النطاق + البحث المركّب)
                            CivilRegistrySearchControls(
                                uiState = uiState,
                                onQuickQueryChange = viewModel::onQuickQueryChange,
                                onScopeSelected = viewModel::onScopeSelected,
                                onToggleAdvanced = viewModel::toggleAdvancedMode,
                                onNameFilterChange = viewModel::onNameFilterChange,
                                onNationalIdFilterChange = viewModel::onNationalIdFilterChange,
                                onWifeNameFilterChange = viewModel::onWifeNameFilterChange,
                                onWifeNationalIdFilterChange = viewModel::onWifeNationalIdFilterChange,
                                onPhoneFilterChange = viewModel::onPhoneFilterChange,
                                onClearFilters = viewModel::clearAllFilters
                            )

                            // قائمة النتائج المفهرسة
                            LazyColumn(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentPadding = PaddingValues(
                                    start = 16.dp,
                                    end = 16.dp,
                                    top = 6.dp,
                                    bottom = 24.dp
                                ),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                if (!uiState.errorMessage.isNullOrBlank()) {
                                    item(key = "search_error") {
                                        Surface(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(14.dp),
                                            color = Color(0xFFFEECEB),
                                            border = BorderStroke(1.dp, Color(0xFFF5B7B1)),
                                            shadowElevation = 0.dp,
                                            tonalElevation = 0.dp
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.ErrorOutline,
                                                    contentDescription = null,
                                                    tint = CoralAccent,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Text(
                                                    text = uiState.errorMessage.orEmpty(),
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = CoralAccent,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }
                                    }
                                }

                                if (uiState.isSearching) {
                                    item(key = "loading_results") {
                                        LightweightGlassCard(modifier = Modifier.fillMaxWidth()) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(18.dp),
                                                horizontalArrangement = Arrangement.Center,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(20.dp),
                                                    strokeWidth = 2.2.dp,
                                                    color = EmeraldPrimary
                                                )
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Text(
                                                    text = "جاري البحث الفوري في السجل المدني...",
                                                    fontSize = 13.sp,
                                                    color = CalmGray,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }
                                    }
                                } else if (!uiState.query.hasActiveCriteria || !uiState.hasSearchedOnce) {
                                    item(key = "idle_prompt") {
                                        CivilRegistryIdleGuideCard(
                                            totalRecords = (uiState.dbStatus as? CivilRegistryDbStatus.Ready)?.totalRecords ?: 0L,
                                            numberFormat = numberFormat
                                        )
                                    }
                                } else if (uiState.results.isEmpty()) {
                                    item(key = "empty_results") {
                                        LightweightGlassCard(modifier = Modifier.fillMaxWidth()) {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(24.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(52.dp)
                                                        .clip(CircleShape)
                                                        .background(Color(0xFFEAF4EF)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.SearchOff,
                                                        contentDescription = null,
                                                        tint = CalmGray,
                                                        modifier = Modifier.size(26.dp)
                                                    )
                                                }
                                                Text(
                                                    text = "لا توجد سجلات مطابقة لمعايير البحث",
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = DeepSlate
                                                )
                                                Text(
                                                    text = "جرّب التحقق من رقم الهوية أو البحث بجزء من الاسم أو رقم الجوال.",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = CalmGray,
                                                    textAlign = TextAlign.Center
                                                )
                                            }
                                        }
                                    }
                                } else {
                                    item(key = "results_count_bar") {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 4.dp, vertical = 2.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = if (uiState.hasMore) {
                                                    "تم عرض ${uiState.results.size} نتيجة (يوجد المزيد)"
                                                } else {
                                                    "إجمالي النتائج المطابقة: ${uiState.results.size}"
                                                },
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = EmeraldPrimary
                                            )
                                            Surface(
                                                shape = RoundedCornerShape(50),
                                                color = Color(0xFFE6F4EA),
                                                border = BorderStroke(0.8.dp, Color(0xFFB7E1CD)),
                                                shadowElevation = 0.dp,
                                                tonalElevation = 0.dp
                                            ) {
                                                Text(
                                                    text = "للقراءة فقط",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = EmeraldPrimary,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }

                                    items(
                                        items = uiState.results,
                                        key = { record -> record.stableKey }
                                    ) { record ->
                                        CivilRegistryResultCard(
                                            record = record,
                                            onPreview = { viewModel.openRecordPreview(record) },
                                            onTransfer = {
                                                viewModel.stageRecordForProjectAdd(record)
                                                onTransferToAddFamily()
                                            }
                                        )
                                    }

                                    if (uiState.hasMore) {
                                        item(key = "load_more_footer") {
                                            Surface(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(14.dp))
                                                    .clickable(enabled = !uiState.isLoadingMore) {
                                                        viewModel.loadMoreResults()
                                                    },
                                                shape = RoundedCornerShape(14.dp),
                                                color = Color.White.copy(alpha = 0.88f),
                                                border = BorderStroke(1.dp, GlassBorder),
                                                shadowElevation = 0.dp,
                                                tonalElevation = 0.dp
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(vertical = 12.dp),
                                                    horizontalArrangement = Arrangement.Center,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    if (uiState.isLoadingMore) {
                                                        CircularProgressIndicator(
                                                            modifier = Modifier.size(16.dp),
                                                            strokeWidth = 2.dp,
                                                            color = EmeraldPrimary
                                                        )
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                        Text(
                                                            text = "جاري تحميل المزيد...",
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = EmeraldPrimary
                                                        )
                                                    } else {
                                                        Icon(
                                                            imageVector = Icons.Rounded.ExpandMore,
                                                            contentDescription = null,
                                                            tint = EmeraldPrimary,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text(
                                                            text = "تحميل المزيد من النتائج",
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = EmeraldPrimary
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // نافذة معاينة جميع الحقول الـ 14 قبل الترحيل
            uiState.selectedRecordForPreview?.let { previewRecord ->
                CivilRegistryFullRecordDialog(
                    record = previewRecord,
                    onDismiss = { viewModel.dismissRecordPreview() },
                    onTransferToProject = {
                        viewModel.stageRecordForProjectAdd(previewRecord)
                        onTransferToAddFamily()
                    }
                )
            }
        }
    }
}

@Composable
private fun LightweightGlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = Color.White.copy(alpha = 0.88f),
        border = BorderStroke(1.dp, GlassBorder),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp
    ) {
        Column(content = content)
    }
}

@Composable
private fun CivilRegistrySearchControls(
    uiState: CivilRegistrySearchViewModel.UiState,
    onQuickQueryChange: (String) -> Unit,
    onScopeSelected: (CivilRegistrySearchScope) -> Unit,
    onToggleAdvanced: () -> Unit,
    onNameFilterChange: (String) -> Unit,
    onNationalIdFilterChange: (String) -> Unit,
    onWifeNameFilterChange: (String) -> Unit,
    onWifeNationalIdFilterChange: (String) -> Unit,
    onPhoneFilterChange: (String) -> Unit,
    onClearFilters: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // صف شريط البحث السريع + زر التبديل للبحث المركّب
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (!uiState.query.advancedMode) {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White.copy(alpha = 0.92f),
                    border = BorderStroke(1.dp, GlassBorder),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "بحث",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Box(
                            modifier = Modifier.weight(1f),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (uiState.query.quickQuery.isEmpty()) {
                                Text(
                                    text = when (uiState.query.scope) {
                                        CivilRegistrySearchScope.ALL -> "ابحث بالاسم، الهوية، الزوجة، أو الجوال..."
                                        CivilRegistrySearchScope.NAME -> "اكتب اسم المواطن..."
                                        CivilRegistrySearchScope.NATIONAL_ID -> "اكتب رقم الهوية الوطنية..."
                                        CivilRegistrySearchScope.WIFE_NAME -> "اكتب اسم الزوجة..."
                                        CivilRegistrySearchScope.WIFE_NATIONAL_ID -> "اكتب رقم هوية الزوجة..."
                                        CivilRegistrySearchScope.PHONES -> "اكتب رقم الجوال أو جوال تنمية..."
                                    },
                                    fontSize = 13.sp,
                                    color = Color(0xFF83968E),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            BasicTextField(
                                value = uiState.query.quickQuery,
                                onValueChange = onQuickQueryChange,
                                singleLine = true,
                                textStyle = TextStyle(
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = DeepSlate
                                ),
                                cursorBrush = SolidColor(EmeraldPrimary),
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = when (uiState.query.scope) {
                                        CivilRegistrySearchScope.NATIONAL_ID,
                                        CivilRegistrySearchScope.WIFE_NATIONAL_ID,
                                        CivilRegistrySearchScope.PHONES -> KeyboardType.Number
                                        else -> KeyboardType.Text
                                    }
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        if (uiState.query.quickQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { onQuickQueryChange("") },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "مسح",
                                    tint = CalmGray,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            } else {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFFE6F4EA),
                    border = BorderStroke(1.dp, Color(0xFFB7E1CD)),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Tune,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "وضع البحث المركّب (متعدد الحقول)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = EmeraldPrimary
                            )
                        }
                        if (uiState.query.hasActiveCriteria) {
                            Text(
                                text = "مسح",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = CoralAccent,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable(onClick = onClearFilters)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // زر التبديل بين البحث الموحد والبحث المركّب
            Surface(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = onToggleAdvanced),
                shape = RoundedCornerShape(16.dp),
                color = if (uiState.query.advancedMode) EmeraldPrimary else Color.White.copy(alpha = 0.92f),
                border = BorderStroke(1.dp, if (uiState.query.advancedMode) EmeraldPrimary else GlassBorder),
                shadowElevation = 0.dp,
                tonalElevation = 0.dp
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (uiState.query.advancedMode) Icons.Rounded.Search else Icons.Rounded.Tune,
                        contentDescription = "تبديل وضع البحث",
                        tint = if (uiState.query.advancedMode) Color.White else EmeraldPrimary,
                        modifier = Modifier.size(21.dp)
                    )
                }
            }
        }

        // شرائح تحديد حقل البحث السريع
        if (!uiState.query.advancedMode) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                CivilRegistrySearchScope.entries.forEach { scope ->
                    val selected = uiState.query.scope == scope
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onScopeSelected(scope) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) EmeraldPrimary else Color.White.copy(alpha = 0.82f),
                        border = BorderStroke(1.dp, if (selected) EmeraldPrimary else GlassBorder),
                        shadowElevation = 0.dp,
                        tonalElevation = 0.dp
                    ) {
                        Text(
                            text = scope.label,
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) Color.White else CalmGray,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
            }
        }

        // بطاقة البحث المركّب المتزامن عبر الحقول الستة
        AnimatedVisibility(visible = uiState.query.advancedMode) {
            LightweightGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CompactGlassFilterInput(
                            value = uiState.query.nameFilter,
                            onValueChange = onNameFilterChange,
                            placeholder = "الاسم",
                            icon = Icons.Rounded.Person,
                            modifier = Modifier.weight(1f)
                        )
                        CompactGlassFilterInput(
                            value = uiState.query.nationalIdFilter,
                            onValueChange = onNationalIdFilterChange,
                            placeholder = "رقم الهوية",
                            icon = Icons.Rounded.CreditCard,
                            keyboardType = KeyboardType.Number,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CompactGlassFilterInput(
                            value = uiState.query.wifeNameFilter,
                            onValueChange = onWifeNameFilterChange,
                            placeholder = "اسم الزوجة",
                            icon = Icons.Rounded.People,
                            modifier = Modifier.weight(1f)
                        )
                        CompactGlassFilterInput(
                            value = uiState.query.wifeNationalIdFilter,
                            onValueChange = onWifeNationalIdFilterChange,
                            placeholder = "هويتها",
                            icon = Icons.Rounded.Badge,
                            keyboardType = KeyboardType.Number,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    CompactGlassFilterInput(
                        value = uiState.query.phoneFilter,
                        onValueChange = onPhoneFilterChange,
                        placeholder = "رقم الجوال أو جوال تنمية",
                        icon = Icons.Rounded.Phone,
                        keyboardType = KeyboardType.Phone,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun CompactGlassFilterInput(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    Surface(
        modifier = modifier.height(42.dp),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF6FAF8),
        border = BorderStroke(1.dp, GlassBorder),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = EmeraldPrimary,
                modifier = Modifier.size(16.dp)
            )
            Box(
                modifier = Modifier.weight(1f),
                contentAlignment = Alignment.CenterStart
            ) {
                if (value.isEmpty()) {
                    Text(
                        text = placeholder,
                        fontSize = 12.sp,
                        color = Color(0xFF83968E),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    singleLine = true,
                    textStyle = TextStyle(
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = DeepSlate
                    ),
                    cursorBrush = SolidColor(EmeraldPrimary),
                    keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (value.isNotEmpty()) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "مسح",
                    tint = CalmGray,
                    modifier = Modifier
                        .size(15.dp)
                        .clickable { onValueChange("") }
                )
            }
        }
    }
}

@Composable
private fun CivilRegistryResultCard(
    record: CivilRegistryRecord,
    onPreview: () -> Unit,
    onTransfer: () -> Unit
) {
    val isDeceased = record.deathStatus.contains("متوف") || record.deathStatus.contains("وفاة")
    val isDevApproved = record.developmentApprovalStatus.contains("معتمد") &&
        !record.developmentApprovalStatus.contains("غير")

    LightweightGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onPreview)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // الترويسة: الاسم + رقم الهوية + شارات الحالة
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(EmeraldPrimary.copy(alpha = 0.12f))
                        .border(1.dp, EmeraldPrimary.copy(alpha = 0.24f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Person,
                        contentDescription = null,
                        tint = EmeraldPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(
                        text = record.name.ifBlank { "بدون اسم مسجل" },
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = DeepSlate,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SmallGlassChip(
                            text = record.nationalId.ifBlank { "—" },
                            bgColor = SkyAccent.copy(alpha = 0.12f),
                            textColor = SkyAccent,
                            icon = Icons.Rounded.CreditCard
                        )
                        if (record.mainArea.isNotBlank()) {
                            SmallGlassChip(
                                text = record.mainArea,
                                bgColor = EmeraldPrimary.copy(alpha = 0.10f),
                                textColor = EmeraldPrimary,
                                icon = Icons.Rounded.LocationOn
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = SoftDivider, thickness = 0.8.dp)

            // ملخص البيانات الأساسية (الزوجة، الجوالات، الأفراد، التنمية، الوفاة)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (record.wifeName.isNotBlank() || record.wifeNationalId.isNotBlank()) {
                    CompactInfoLine(
                        icon = Icons.Rounded.People,
                        iconTint = IndigoAccent,
                        label = "الزوجة",
                        value = listOf(record.wifeName, record.wifeNationalId)
                            .filter { it.isNotBlank() }
                            .joinToString(" • ")
                    )
                }

                val phonesText = listOfNotNull(
                    record.mobilePhone.takeIf { it.isNotBlank() },
                    record.developmentPhone.takeIf { it.isNotBlank() && it != record.mobilePhone }
                        ?.let { "تنمية: $it" }
                ).joinToString(" | ")
                if (phonesText.isNotBlank()) {
                    CompactInfoLine(
                        icon = Icons.Rounded.Phone,
                        iconTint = EmeraldPrimary,
                        label = "الجوال",
                        value = phonesText
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (record.familyMembersCount.isNotBlank()) {
                        SmallGlassChip(
                            text = "${record.familyMembersCount} أفراد",
                            bgColor = IndigoAccent.copy(alpha = 0.10f),
                            textColor = IndigoAccent,
                            icon = Icons.Rounded.Groups
                        )
                    }
                    if (record.developmentApprovalStatus.isNotBlank()) {
                        SmallGlassChip(
                            text = record.developmentApprovalStatus,
                            bgColor = if (isDevApproved) Color(0xFFE6F4EA) else Color(0xFFFFF4E5),
                            textColor = if (isDevApproved) EmeraldPrimary else AmberAccent
                        )
                    }
                    if (isDeceased) {
                        SmallGlassChip(
                            text = record.deathStatus,
                            bgColor = Color(0xFFFEECEB),
                            textColor = CoralAccent
                        )
                    }
                }
            }

            // أزرار الإجراءات: معاينة كاملة أو ترحيل إلى صفحة الإضافة كمسودة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onPreview),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF3F9F6),
                    border = BorderStroke(1.dp, GlassBorder),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Visibility,
                            contentDescription = null,
                            tint = DeepSlate,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "التفاصيل الكاملة",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = DeepSlate
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .weight(1.25f)
                        .height(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(onClick = onTransfer),
                    shape = RoundedCornerShape(12.dp),
                    color = EmeraldPrimary,
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PersonAdd,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "ترحيل لصفحة الإضافة",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CompactInfoLine(
    icon: ImageVector,
    iconTint: Color,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconTint,
            modifier = Modifier.size(15.dp)
        )
        Text(
            text = "$label:",
            fontSize = 12.sp,
            color = CalmGray,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            fontSize = 12.sp,
            color = DeepSlate,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun SmallGlassChip(
    text: String,
    bgColor: Color,
    textColor: Color,
    icon: ImageVector? = null
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = bgColor,
        shadowElevation = 0.dp,
        tonalElevation = 0.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = textColor,
                    modifier = Modifier.size(12.dp)
                )
            }
            Text(
                text = text,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = textColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * نافذة معاينة جميع الحقول الـ 14 الحرفية لسجل السجل المدني قبل الترحيل
 */
@Composable
private fun CivilRegistryFullRecordDialog(
    record: CivilRegistryRecord,
    onDismiss: () -> Unit,
    onTransferToProject: () -> Unit
) {
    val allFourteenFields = listOf(
        Triple(CivilRegistrySchema.COL_NATIONAL_ID, record.nationalId, Icons.Rounded.CreditCard to SkyAccent),
        Triple(CivilRegistrySchema.COL_NAME, record.name, Icons.Rounded.Person to EmeraldPrimary),
        Triple(CivilRegistrySchema.COL_BIRTH_DATE, record.birthDate, Icons.Rounded.CalendarToday to SkyAccent),
        Triple(CivilRegistrySchema.COL_GENDER, record.gender, Icons.Rounded.Wc to IndigoAccent),
        Triple(CivilRegistrySchema.COL_MARITAL_STATUS, record.maritalStatus, Icons.Rounded.Favorite to CoralAccent),
        Triple(CivilRegistrySchema.COL_DEATH_STATUS, record.deathStatus, Icons.Rounded.VerifiedUser to EmeraldPrimary),
        Triple(CivilRegistrySchema.COL_DEATH_DATE, record.deathDate, Icons.Rounded.EventBusy to CoralAccent),
        Triple(CivilRegistrySchema.COL_MOBILE_PHONE, record.mobilePhone, Icons.Rounded.Phone to EmeraldPrimary),
        Triple(CivilRegistrySchema.COL_DEV_PHONE, record.developmentPhone, Icons.Rounded.PhoneIphone to SkyAccent),
        Triple(CivilRegistrySchema.COL_MAIN_AREA, record.mainArea, Icons.Rounded.LocationOn to AmberAccent),
        Triple(CivilRegistrySchema.COL_FAMILY_MEMBERS_COUNT, record.familyMembersCount, Icons.Rounded.Groups to IndigoAccent),
        Triple(CivilRegistrySchema.COL_DEV_APPROVAL, record.developmentApprovalStatus, Icons.Rounded.Verified to EmeraldPrimary),
        Triple(CivilRegistrySchema.COL_WIFE_NAME, record.wifeName, Icons.Rounded.People to IndigoAccent),
        Triple(CivilRegistrySchema.COL_WIFE_NATIONAL_ID, record.wifeNationalId, Icons.Rounded.Badge to SkyAccent)
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 24.dp),
                shape = RoundedCornerShape(22.dp),
                color = Color(0xFFF9FCFA),
                border = BorderStroke(1.dp, GlassBorder),
                shadowElevation = 0.dp,
                tonalElevation = 0.dp
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "بطاقة السجل المدني الكاملة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = DeepSlate
                            )
                            Text(
                                text = "للقراءة فقط — تُرحَّل كمسودة قابلة للتعديل",
                                fontSize = 11.sp,
                                color = CalmGray
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Rounded.Close, contentDescription = "إغلاق", tint = CalmGray)
                        }
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 8.dp),
                        color = SoftDivider,
                        thickness = 0.8.dp
                    )

                    Column(
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .verticalScroll(rememberScrollState())
                    ) {
                        allFourteenFields.forEachIndexed { index, (colLabel, colVal, iconPair) ->
                            if (index > 0) {
                                HorizontalDivider(color = SoftDivider, thickness = 0.8.dp)
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(iconPair.second.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = iconPair.first,
                                        contentDescription = null,
                                        tint = iconPair.second,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = colLabel,
                                    fontSize = 12.sp,
                                    color = CalmGray,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = colVal.ifBlank { "—" },
                                    fontSize = 13.sp,
                                    color = DeepSlate,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.widthIn(max = 185.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, GlassBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إغلاق", color = CalmGray, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = onTransferToProject,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            elevation = ButtonDefaults.buttonElevation(0.dp, 0.dp),
                            modifier = Modifier.weight(1.4f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PersonAdd,
                                contentDescription = null,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ترحيل إلى صفحة الإضافة", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CivilRegistryIdleGuideCard(
    totalRecords: Long,
    numberFormat: NumberFormat
) {
    LightweightGlassCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(EmeraldPrimary.copy(alpha = 0.12f))
                    .border(1.dp, EmeraldPrimary.copy(alpha = 0.24f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.ManageSearch,
                    contentDescription = null,
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(28.dp)
                )
            }
            Text(
                text = "محرك الاستعلام المفهرس جاهز للبحث",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = DeepSlate
            )
            Text(
                text = "ابحث لحظياً ضمن ${numberFormat.format(totalRecords)} سجل عبر الاسم، رقم الهوية، اسم الزوجة، هويتها، رقم الجوال أو جوال التنمية. يمكنك استخدام البحث الموحد أو تفعيل البحث المركّب لدمج عدة حقول معاً.",
                style = MaterialTheme.typography.bodySmall,
                color = CalmGray,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )
        }
    }
}

@Composable
private fun CivilRegistryDatabaseMissingView(
    expectedPath: String,
    onPickDatabaseFile: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        LightweightGlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFFF4E5)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Storage,
                        contentDescription = null,
                        tint = AmberAccent,
                        modifier = Modifier.size(30.dp)
                    )
                }
                Text(
                    text = "ربط قاعدة بيانات السجل المدني",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = DeepSlate
                )
                Text(
                    text = "لم يتم العثور على ملف civil_registry.db في مسار التطبيق بعد. يمكنك اختيار ملف قاعدة البيانات من جهازك لربطه فوراً بوضع القراءة فقط.",
                    style = MaterialTheme.typography.bodySmall,
                    color = CalmGray,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp
                )
                Button(
                    onClick = onPickDatabaseFile,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    elevation = ButtonDefaults.buttonElevation(0.dp, 0.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Rounded.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("اختيار ملف civil_registry.db", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onRetry,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GlassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إعادة الفحص", color = DeepSlate, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun CivilRegistryDatabaseErrorView(
    message: String,
    onPickDatabaseFile: () -> Unit,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        LightweightGlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.ErrorOutline,
                    contentDescription = null,
                    tint = CoralAccent,
                    modifier = Modifier.size(44.dp)
                )
                Text(
                    text = "تعذر فتح قاعدة السجل المدني",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = CoralAccent
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodySmall,
                    color = CalmGray,
                    textAlign = TextAlign.Center
                )
                Button(
                    onClick = onPickDatabaseFile,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    elevation = ButtonDefaults.buttonElevation(0.dp, 0.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("اختيار ملف civil_registry.db آخر", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onRetry,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, GlassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("إعادة المحاولة", color = DeepSlate, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
