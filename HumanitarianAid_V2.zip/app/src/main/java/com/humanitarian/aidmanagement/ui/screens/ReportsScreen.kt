package com.humanitarian.aidmanagement.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    repository: AidRepository,
    database: AidDatabase,
    isSuperAdmin: Boolean,
    allowedLocalityIds: List<Int>,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val dateFormatter = remember { SimpleDateFormat("yyyy/MM/dd", Locale.ENGLISH) }

    val reportTypes = listOf(
        "تقرير الأسر",
        "تقرير المستفيدين",
        "تقرير المرشحين",
        "تقرير المساعدات",
        "تقرير حسب نوع المساعدة",
        "تقرير حسب المحلية",
        "تقرير حسب المشروع",
        "تقرير حسب المؤسسة الممولة",
        "تقرير حسب الفترة"
    )

    var selectedReportType by remember { mutableStateOf(reportTypes[0]) }
    var searchQuery by remember { mutableStateOf("") }

    val families by repository.getFamiliesFiltered(isSuperAdmin, allowedLocalityIds, query = searchQuery).collectAsState(initial = emptyList())
    val aidRecords by repository.getAidRecords(isSuperAdmin, allowedLocalityIds).collectAsState(initial = emptyList())
    val selections by database.selectionDao().getSelections(isSuperAdmin, allowedLocalityIds, null, null).collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مركز التقارير والتصدير", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "القائمة")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
                .padding(16.dp)
        ) {
            // Report Type Selector
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("اختر نوع التقرير:", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2), fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        reportTypes.take(3).forEach { r ->
                            FilterChip(
                                selected = selectedReportType == r,
                                onClick = { selectedReportType = r },
                                label = { Text(r, fontSize = 11.sp) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        reportTypes.drop(3).take(3).forEach { r ->
                            FilterChip(
                                selected = selectedReportType == r,
                                onClick = { selectedReportType = r },
                                label = { Text(r, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // Export Buttons: CSV & Share
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                val csvContent = StringBuilder()
                                csvContent.append("الرقم,الاسم,الهوية,المحلية,الحالة,الأفراد\n")
                                families.forEach { f ->
                                    csvContent.append("${f.familyID},\"${f.name}\",${f.nationalID},${f.localityID},${f.residentStatus},${f.familyMembersCount}\n")
                                }
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, csvContent.toString())
                                    type = "text/csv"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, "مشاركة تقرير CSV")
                                context.startActivity(shareIntent)
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("تصدير CSV")
                        }

                        OutlinedButton(
                            onClick = {
                                val summary = "تقرير نظام المساعدات الإنسانية:\nإجمالي السجلات المعروضة: ${families.size}\nتاريخ التصدير: ${dateFormatter.format(Date())}"
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, summary)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "مشاركة ملخص التقرير"))
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("مشاركة")
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Search in report
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("بحث وتصفية داخل التقرير...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(Modifier.height(12.dp))

            // Table / List of report results
            Text("نتائج التقرير (${families.size} سجل):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(families) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(item.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("الهوية: ${item.nationalID} | الأفراد: ${item.familyMembersCount}", fontSize = 12.sp, color = Color(0xFF64748B))
                            }
                            Text("محلية ${item.localityID}", color = Color(0xFF1976D2), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
