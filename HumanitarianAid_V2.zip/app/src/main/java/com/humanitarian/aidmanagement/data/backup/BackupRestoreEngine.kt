package com.humanitarian.aidmanagement.data.backup

import android.content.Context
import android.content.Intent
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupRestoreEngine {
    private const val DB_NAME = AidDatabase.DATABASE_NAME

    @Throws(Exception::class)
    suspend fun performBackup(context: Context, outputStream: OutputStream) = withContext(Dispatchers.IO) {
        val database = AidDatabase.getDatabase(context)
        try {
            database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)")
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (database.isOpen) database.close()
        }
        val dbFile = context.getDatabasePath(DB_NAME)
        if (!dbFile.exists()) throw Exception("ملف قاعدة البيانات غير موجود")

        ZipOutputStream(outputStream).use { zos ->
            zos.putNextEntry(ZipEntry(DB_NAME))
            dbFile.inputStream().use { it.copyTo(zos) }
            zos.closeEntry()
        }
    }

    @Throws(Exception::class)
    suspend fun performRestore(context: Context, inputStream: InputStream) = withContext(Dispatchers.IO) {
        // 1. إيقاف التزامن اللحظي فوراً لمنعه من تدمير الاستعادة
        androidx.work.WorkManager.getInstance(context).cancelAllWork()

        val database = AidDatabase.getDatabase(context)
        if (database.isOpen) database.close()

        val tempFile = File(context.cacheDir, "temp_restore_atomic.db")
        if (tempFile.exists()) tempFile.delete()

        val bis = BufferedInputStream(inputStream)
        bis.mark(4)
        val magic = ByteArray(4)
        val readCount = bis.read(magic)
        bis.reset()

        val isZip = readCount == 4 && magic[0] == 0x50.toByte() && magic[1] == 0x4B.toByte()
        var fileFound = false

        if (isZip) {
            ZipInputStream(bis).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name.lowercase()
                    if (name.endsWith(".db") || name.contains("aid_database") || name.contains("humanitarian")) {
                        FileOutputStream(tempFile).use { zis.copyTo(it) }
                        fileFound = true
                        break
                    }
                    entry = zis.nextEntry
                }
            }
        } else {
            FileOutputStream(tempFile).use { bis.copyTo(it) }
            fileFound = true
        }

        if (!fileFound || !tempFile.exists() || tempFile.length() < 100L) {
            if (tempFile.exists()) tempFile.delete()
            throw Exception("ملف النسخة غير صالح أو فارغ.")
        }

        val dbFile = context.getDatabasePath(DB_NAME)
        
        // 2. تأمين التثبيت الجديد (Fresh Install) وإنشاء المجلدات
        dbFile.parentFile?.let { if (!it.exists()) it.mkdirs() }

        val walFile = File("${dbFile.path}-wal")
        val shmFile = File("${dbFile.path}-shm")

        if (walFile.exists()) walFile.delete()
        if (shmFile.exists()) shmFile.delete()
        if (dbFile.exists()) dbFile.delete()

        tempFile.copyTo(dbFile, overwrite = true)
        tempFile.delete()

        // 3. إعادة التشغيل الآمن (Graceful Reboot)
        kotlinx.coroutines.delay(2000)
        val packageManager = context.packageManager
        val intent = packageManager.getLaunchIntentForPackage(context.packageName)
        val componentName = intent?.component
        val restartIntent = Intent.makeRestartActivityTask(componentName)
        context.startActivity(restartIntent)
        Runtime.getRuntime().exit(0)
    }
}
