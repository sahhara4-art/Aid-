package com.humanitarian.aidmanagement.data.backup

import android.content.Context
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupRestoreEngine {
    private const val DB_NAME = AidDatabase.DATABASE_NAME

    @Throws(Exception::class)
    suspend fun performBackup(context: Context, outputStream: OutputStream) = withContext(Dispatchers.IO) {
        val database = AidDatabase.getDatabase(context)
        
        try {
            database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)")
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (database.isOpen) database.close()
        }

        val dbFile = context.getDatabasePath(DB_NAME)
        if (!dbFile.exists()) throw Exception("ملف قاعدة البيانات غير موجود")

        ZipOutputStream(outputStream).use { zos ->
            zos.putNextEntry(ZipEntry(DB_NAME))
            dbFile.inputStream().use { it.copyTo(zos) }
            zos.closeEntry()
        }
    }

    @Throws(Exception::class)
    suspend fun performRestore(context: Context, inputStream: InputStream) = withContext(Dispatchers.IO) {
        val database = AidDatabase.getDatabase(context)
        if (database.isOpen) database.close()

        val tempFile = File(context.cacheDir, "temp_restore_atomic.db")
        if (tempFile.exists()) tempFile.delete()

        val bis = BufferedInputStream(inputStream)
        bis.mark(4)
        val magic = ByteArray(4)
        val readCount = bis.read(magic)
        bis.reset()

        val isZip = readCount == 4 && magic[0] == 0x50.toByte() && magic[1] == 0x4B.toByte()
        var fileFound = false

        if (isZip) {
            ZipInputStream(bis).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name.lowercase()
                    if (name.endsWith(".db") || name.contains("aid_database") || name.contains("humanitarian")) {
                        FileOutputStream(tempFile).use { zis.copyTo(it) }
                        fileFound = true
                        break
                    }
                    entry = zis.nextEntry
                }
            }
        } else {
            FileOutputStream(tempFile).use { bis.copyTo(it) }
            fileFound = true
        }

        if (!fileFound || !tempFile.exists() || tempFile.length() < 100L) {
            if (tempFile.exists()) tempFile.delete()
            throw Exception("ملف النسخة غير صالح أو فارغ.")
        }

        val dbFile = context.getDatabasePath(DB_NAME)
        
        // --- الحل الجذري للتثبيت الجديد (Fresh Install) ---
        // تأمين وجود مجلد databases قبل محاولة لصق الملف
        dbFile.parentFile?.let { 
            if (!it.exists()) it.mkdirs() 
        }

        val walFile = File("${dbFile.path}-wal")
        val shmFile = File("${dbFile.path}-shm")

        if (walFile.exists()) walFile.delete()
        if (shmFile.exists()) shmFile.delete()
        if (dbFile.exists()) dbFile.delete()

        tempFile.copyTo(dbFile, overwrite = true)
        tempFile.delete()

        kotlinx.coroutines.delay(1500)
        android.os.Process.killProcess(android.os.Process.myPid())
    }
}
