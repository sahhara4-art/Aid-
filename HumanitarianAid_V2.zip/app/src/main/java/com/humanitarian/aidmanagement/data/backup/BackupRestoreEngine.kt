package com.humanitarian.aidmanagement.data.backup

import android.content.Context
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupRestoreEngine {
    private const val DB_NAME = AidDatabase.DATABASE_NAME

    @Throws(Exception::class)
    suspend fun performBackup(context: Context, outputStream: OutputStream) = withContext(Dispatchers.IO) {
        val database = AidDatabase.getDatabase(context)
        
        // 1. الإجبار على دمج الذاكرة المؤقتة (WAL Checkpoint) ثم إغلاق الاتصال بأمان
        try {
            database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)")
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            if (database.isOpen) database.close()
        }

        val dbFile = context.getDatabasePath(DB_NAME)
        if (!dbFile.exists()) throw Exception("ملف قاعدة البيانات غير موجود")

        // 2. ضغط الملف وتصديره كـ ZIP
        ZipOutputStream(outputStream).use { zos ->
            zos.putNextEntry(ZipEntry(DB_NAME))
            dbFile.inputStream().use { it.copyTo(zos) }
            zos.closeEntry()
        }
    }

    @Throws(Exception::class)
    suspend fun performRestore(context: Context, inputStream: InputStream) = withContext(Dispatchers.IO) {
        val database = AidDatabase.getDatabase(context)
        // 1. إغلاق الاتصال تماماً لكسر قفل Room
        if (database.isOpen) database.close()

        val tempFile = File(context.cacheDir, "temp_restore_atomic.db")
        if (tempFile.exists()) tempFile.delete()

        // 2. الفحص الذكي: هل هو ملف مضغوط أم قاعدة بيانات خام؟
        val bis = BufferedInputStream(inputStream)
        bis.mark(4)
        val magic = ByteArray(4)
        val readCount = bis.read(magic)
        bis.reset()

        val isZip = readCount == 4 && magic[0] == 0x50.toByte() && magic[1] == 0x4B.toByte()
        var fileFound = false

        if (isZip) {
            ZipInputStream(bis).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val name = entry.name.lowercase()
                    if (name.endsWith(".db") || name.contains("aid_database") || name.contains("humanitarian")) {
                        FileOutputStream(tempFile).use { zis.copyTo(it) }
                        fileFound = true
                        break
                    }
                    entry = zis.nextEntry
                }
            }
        } else {
            FileOutputStream(tempFile).use { bis.copyTo(it) }
            fileFound = true
        }

        if (!fileFound || !tempFile.exists() || tempFile.length() < 100L) {
            if (tempFile.exists()) tempFile.delete()
            throw Exception("ملف النسخة الاحتياطية غير صالح أو فارغ.")
        }

        // 3. الاستبدال العنيف والكنس الجذري (Atomic Swap)
        val dbFile = context.getDatabasePath(DB_NAME)
        val walFile = File("${dbFile.path}-wal")
        val shmFile = File("${dbFile.path}-shm")

        if (walFile.exists()) walFile.delete()
        if (shmFile.exists()) shmFile.delete()
        if (dbFile.exists()) dbFile.delete()

        tempFile.copyTo(dbFile, overwrite = true)
        tempFile.delete()

        // 4. مهلة استقرار الأندرويد والقتل الإجباري
        Thread.sleep(1500)
        kotlin.system.exitProcess(0)
    }
}
