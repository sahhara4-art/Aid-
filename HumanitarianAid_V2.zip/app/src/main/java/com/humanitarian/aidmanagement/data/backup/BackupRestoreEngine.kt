package com.humanitarian.aidmanagement.data.backup

import android.content.Context
import android.content.Intent
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.security.DatabaseKeyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupRestoreEngine {
    private const val DB_NAME = AidDatabase.DATABASE_NAME

    @Throws(Exception::class)
    suspend fun performBackup(context: Context, outputStream: OutputStream) = withContext(Dispatchers.IO) {
        val dbFile = context.getDatabasePath(DB_NAME)
        val walFile = File(dbFile.path + "-wal")
        val shmFile = File(dbFile.path + "-shm")

        if (!dbFile.exists()) throw Exception("ملف قاعدة البيانات غير موجود")

        ZipOutputStream(outputStream).use { zos ->
            // ضغط ملفات القاعدة
            zos.putNextEntry(ZipEntry(dbFile.name))
            dbFile.inputStream().use { it.copyTo(zos) }
            zos.closeEntry()

            if (walFile.exists()) {
                zos.putNextEntry(ZipEntry(walFile.name))
                walFile.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }

            if (shmFile.exists()) {
                zos.putNextEntry(ZipEntry(shmFile.name))
                shmFile.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }

            // ضغط مفتاح التشفير داخل النسخة
            val currentKey = DatabaseKeyManager.getOrCreateDatabaseKey(context)
            zos.putNextEntry(ZipEntry("db_key.bin"))
            zos.write(currentKey)
            zos.closeEntry()
        }
    }

    @Throws(Exception::class)
    suspend fun performRestore(context: Context, inputStream: InputStream) = withContext(Dispatchers.IO) {
        try {
            androidx.work.WorkManager.getInstance(context).cancelAllWork()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val database = AidDatabase.getDatabase(context)
        if (database.isOpen) database.close()

        val dbFile = context.getDatabasePath(DB_NAME)
        val walFile = File(dbFile.path + "-wal")
        val shmFile = File(dbFile.path + "-shm")
        val keyFile = File(context.filesDir, "restored_key.bin")

        dbFile.parentFile?.mkdirs()

        if (dbFile.exists()) dbFile.delete()
        if (walFile.exists()) walFile.delete()
        if (shmFile.exists()) shmFile.delete()
        if (keyFile.exists()) keyFile.delete()

        val bis = BufferedInputStream(inputStream)
        bis.mark(4)
        val magic = ByteArray(4)
        val readCount = bis.read(magic)
        bis.reset()

        val isZip = readCount == 4 && magic[0] == 0x50.toByte() && magic[1] == 0x4B.toByte()

        if (isZip) {
            ZipInputStream(bis).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val fileName = entry.name
                    val targetFile = when {
                        fileName == "db_key.bin" -> keyFile
                        fileName.endsWith("-wal") -> walFile
                        fileName.endsWith("-shm") -> shmFile
                        fileName.endsWith(".db") || fileName.contains(DB_NAME) -> dbFile
                        else -> null
                    }
                    
                    targetFile?.let { file ->
                        FileOutputStream(file).use { fos -> zis.copyTo(fos) }
                    }
                    entry = zis.nextEntry
                }
            }
        } else {
            FileOutputStream(dbFile).use { fos -> bis.copyTo(fos) }
        }

        if (!dbFile.exists() || dbFile.length() < 100L) {
            if (dbFile.exists()) dbFile.delete()
            throw Exception("ملف النسخة غير صالح أو فارغ.")
        }

        kotlinx.coroutines.delay(1000)
        
        val packageManager = context.packageManager
        val intent = packageManager.getLaunchIntentForPackage(context.packageName)
        val componentName = intent?.component
        val restartIntent = Intent.makeRestartActivityTask(componentName)
        context.startActivity(restartIntent)
        Runtime.getRuntime().exit(0)
    }
}
