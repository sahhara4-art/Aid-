package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.navigation.Screen
import com.humanitarian.aidmanagement.ui.navigation.canAccessNavRoute
import com.humanitarian.aidmanagement.ui.theme.PalestineGreen
import com.humanitarian.aidmanagement.ui.theme.PalestineRed

private data class GlassDrawerMenuItem(
    val route: String,
    val screenKey: String,
    val label: String,
    val icon: ImageVector? = null,
    val iconTint: Color,
    val textBadge: String = ""
)

/**
 * القائمة الجانبية الزجاجية المتطورة (Glassmorphic Navigation Drawer)
 * طبقة عرض بصرية بحتة تحافظ على كافة ضوابط الصلاحيات (RBAC) دون تعديل أي منطق برمجي.
 */
@Composable
fun GlassNavigationDrawerSheet(
    currentRoute: String?,
    userFullName: String,
    userRoleLabel: String,
    allowedGeographicScope: String,
    isManager: Boolean,
    permissions: List<String>,
    onNavigate: (String) -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val drawerShape = RoundedCornerShape(topEnd = 32.dp, bottomEnd = 32.dp)
    val textShadow = Shadow(
        color = Color.Black.copy(alpha = 0.40f),
        offset = Offset(0f, 1.5f),
        blurRadius = 4f
    )

    val menuItems = listOf(
        GlassDrawerMenuItem(Screen.Dashboard.route, AccessControlManager.SCREEN_DASHBOARD, "الرئيسية (لوحة القيادة)", Icons.Default.Dashboard, Color(0xFF3B82F6)),
        GlassDrawerMenuItem(Screen.Families.route, AccessControlManager.SCREEN_FAMILIES, "سجل الأسر والمستفيدين", Icons.Default.FamilyRestroom, Color(0xFF10B981)),
        GlassDrawerMenuItem(Screen.AddFamily.route, AccessControlManager.SCREEN_ADD_FAMILY, "إضافة أسرة جديدة", Icons.Default.PersonAdd, Color(0xFF10B981)),
        GlassDrawerMenuItem(Screen.CivilRegistryLookup.route, AccessControlManager.SCREEN_CIVIL_REGISTRY, "البحث في السجل المدني", Icons.Default.ManageSearch, Color(0xFF0EA5E9)),
        GlassDrawerMenuItem(Screen.Nomination.route, AccessControlManager.SCREEN_NOMINATION, "محرك الترشيح", Icons.Default.HowToReg, Color(0xFFF59E0B)),
        GlassDrawerMenuItem(Screen.Delivery.route, AccessControlManager.SCREEN_DELIVERY, "تسليم وصرف المساعدات", Icons.Default.CheckCircle, Color(0xFF8B5CF6)),
        GlassDrawerMenuItem(Screen.Projects.route, AccessControlManager.SCREEN_PROJECTS, "المشاريع الإنسانية", Icons.Default.FolderShared, Color(0xFF14B8A6)),
        GlassDrawerMenuItem(Screen.WarehouseErp.route, AccessControlManager.SCREEN_WAREHOUSE_ERP, "إدارة المخازن والمحاسبة اللوجستية", icon = null, iconTint = Color(0xFF059669), textBadge = "مخازن"),
        GlassDrawerMenuItem(Screen.WarehouseDynamicReports.route, AccessControlManager.SCREEN_WAREHOUSE_REPORTS, "تقارير المخازن التفصيلية", icon = null, iconTint = Color(0xFF0EA5E9), textBadge = "تقارير"),
        GlassDrawerMenuItem(Screen.GeographicDistribution.route, AccessControlManager.SCREEN_GEOGRAPHIC, "التوزيع الجغرافي", Icons.Default.Map, Color(0xFFF43F5E)),
        GlassDrawerMenuItem(Screen.Reports.route, AccessControlManager.SCREEN_REPORTS, "التقارير والإحصائيات", Icons.Default.BarChart, Color(0xFF6366F1)),
        GlassDrawerMenuItem(Screen.ExecutiveReports.route, AccessControlManager.SCREEN_EXECUTIVE_REPORTS, "التقرير الإداري التنفيذي", Icons.Default.Assessment, Color(0xFF7E22CE)),
        GlassDrawerMenuItem(Screen.DynamicReportExport.route, AccessControlManager.SCREEN_DYNAMIC_REPORTS, "مركز التقارير الديناميكي", Icons.Default.Insights, Color(0xFFEC4899)),
        GlassDrawerMenuItem(Screen.HouseholdIntegrityAuditor.route, AccessControlManager.SCREEN_INTEGRITY_AUDITOR, "كاشف التداخل والازدواجية", Icons.Default.FactCheck, Color(0xFFDC2626)),
        GlassDrawerMenuItem(Screen.ExcelMatching.route, AccessControlManager.SCREEN_EXCEL_MATCHING, "مطابقة وتدقيق الإكسل (الشركاء)", Icons.Default.FactCheck, Color(0xFFEAB308)),
        GlassDrawerMenuItem(Screen.ExcelImportExport.route, AccessControlManager.SCREEN_EXCEL, "استيراد ملفات الإكسل", Icons.Default.UploadFile, Color(0xFF0EA5E9)),
        GlassDrawerMenuItem(Screen.AuditLog.route, AccessControlManager.SCREEN_AUDIT_LOG, "سجل الرقابة والتدقيق", icon = null, iconTint = Color(0xFF10B981), textBadge = "رقابة"),
        GlassDrawerMenuItem(Screen.BackupRestore.route, AccessControlManager.SCREEN_BACKUP, "النسخ الاحتياطي واستعادة البيانات", Icons.Default.CloudSync, Color(0xFF06B6D4)),
        GlassDrawerMenuItem(Screen.AccountsPermissions.route, AccessControlManager.SCREEN_USERS, "إدارة الحسابات والصلاحيات", Icons.Default.AdminPanelSettings, Color(0xFF64748B))
    ).filter { item ->
        val isAllowedByScreen = AccessControlManager.canAccessScreen(item.screenKey)
        val isAllowedByRoute = canAccessNavRoute(item.route, permissions, isManager)
        isAllowedByScreen && isAllowedByRoute
    }

    ModalDrawerSheet(
        modifier = modifier
            .widthIn(min = 270.dp, max = 312.dp)
            .fillMaxHeight(),
        drawerShape = drawerShape,
        drawerContainerColor = Color.Transparent,
        drawerContentColor = Color.White,
        drawerTonalElevation = 0.dp,
        windowInsets = WindowInsets(0, 0, 0, 0)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(drawerShape)
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.45f),
                            Color.White.copy(alpha = 0.16f),
                            Color.Transparent
                        )
                    ),
                    shape = drawerShape
                )
        ) {
            // 1) طبقة الخلفية الزجاجية الداكنة دون تأثيرات RenderEffect لضمان الاستقرار التام على كافة الإصدارات
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF0F172A).copy(alpha = 0.88f),
                                Color(0xFF1E293B).copy(alpha = 0.82f),
                                Color(0xFF064E3B).copy(alpha = 0.84f)
                            )
                        )
                    )
            )

            // 2) طبقة اللمعة الزجاجية الشفافة (Frosted Glass Sheen)
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.20f),
                                Color.White.copy(alpha = 0.05f),
                                Color.White.copy(alpha = 0.10f)
                            )
                        )
                    )
            )

            // 3) المحتوى التفاعلي للقائمة الجانبية (نصوص وأيقونات واضحة وعالية التباين)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 14.dp, vertical = 14.dp)
            ) {
                // ترويسة زجاجية شفافة تماماً تعرض اسم المستخدم وصلاحياته الجغرافية
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Transparent)
                        .padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.linearGradient(
                                        colors = listOf(
                                            Color.White.copy(alpha = 0.25f),
                                            Color.White.copy(alpha = 0.08f)
                                        )
                                    )
                                )
                                .border(
                                    width = 1.dp,
                                    brush = Brush.linearGradient(
                                        colors = listOf(
                                            Color.White.copy(alpha = 0.55f),
                                            Color.Transparent
                                        )
                                    ),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isManager) Icons.Default.Security else Icons.Default.Person,
                                contentDescription = null,
                                tint = if (isManager) Color(0xFFFCA5A5) else Color(0xFF6EE7B7),
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Text(
                                text = userFullName,
                                style = MaterialTheme.typography.titleMedium.merge(
                                    TextStyle(shadow = textShadow)
                                ),
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isManager) PalestineRed.copy(alpha = 0.28f) else PalestineGreen.copy(alpha = 0.30f),
                                border = androidx.compose.foundation.BorderStroke(
                                    width = 0.8.dp,
                                    color = Color.White.copy(alpha = 0.30f)
                                )
                            ) {
                                Text(
                                    text = userRoleLabel,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    style = TextStyle(shadow = textShadow),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    // شريط النطاق الجغرافي المقيد للمستخدم بوضوح تام
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.10f))
                            .border(
                                width = 0.8.dp,
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.35f),
                                        Color.Transparent
                                    )
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = Color(0xFF6EE7B7),
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "النطاق الجغرافي: $allowedGeographicScope",
                            style = MaterialTheme.typography.labelMedium.merge(
                                TextStyle(shadow = textShadow)
                            ),
                            color = Color.White.copy(alpha = 0.95f),
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 8.dp),
                    color = Color.White.copy(alpha = 0.16f)
                )

                // قائمة عناصر التنقل الزجاجية القابلة للتمرير
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    menuItems.forEach { item ->
                        val isSelected = currentRoute == item.route
                        val itemBorderModifier = if (isSelected) {
                            Modifier.border(
                                width = 1.dp,
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.40f),
                                        Color.Transparent
                                    )
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        } else {
                            Modifier
                        }

                        NavigationDrawerItem(
                            selected = isSelected,
                            onClick = { onNavigate(item.route) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(itemBorderModifier),
                            icon = {
                                if (item.icon != null) {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = item.label,
                                        tint = item.iconTint,
                                        modifier = Modifier.size(21.dp)
                                    )
                                } else {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = item.iconTint.copy(alpha = 0.22f)
                                    ) {
                                        Text(
                                            text = item.textBadge.ifBlank { "✓" },
                                            color = item.iconTint,
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            },
                            label = {
                                Text(
                                    text = item.label,
                                    style = MaterialTheme.typography.bodyMedium.merge(
                                        TextStyle(shadow = textShadow)
                                    ),
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.28f),
                                unselectedContainerColor = Color.Transparent,
                                selectedIconColor = Color(0xFF6EE7B7),
                                unselectedIconColor = Color.White.copy(alpha = 0.86f),
                                selectedTextColor = Color.White,
                                unselectedTextColor = Color.White.copy(alpha = 0.92f)
                            )
                        )
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 8.dp),
                        color = Color.White.copy(alpha = 0.14f)
                    )

                    NavigationDrawerItem(
                        selected = false,
                        onClick = onLogout,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth(),
                        icon = {
                            Icon(
                                imageVector = Icons.Default.ExitToApp,
                                contentDescription = "تسجيل الخروج",
                                modifier = Modifier.size(21.dp)
                            )
                        },
                        label = {
                            Text(
                                text = "تسجيل الخروج",
                                style = MaterialTheme.typography.bodyMedium.merge(
                                    TextStyle(shadow = textShadow)
                                ),
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1
                            )
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = PalestineRed.copy(alpha = 0.25f),
                            unselectedContainerColor = Color.Transparent,
                            selectedIconColor = Color(0xFFFCA5A5),
                            unselectedIconColor = Color(0xFFFCA5A5),
                            selectedTextColor = Color.White,
                            unselectedTextColor = Color(0xFFFEE2E2)
                        )
                    )
                }

                // التذييل السيادي المحفور على الزجاج
                HorizontalDivider(
                    modifier = Modifier.padding(top = 8.dp, bottom = 10.dp),
                    color = Color.White.copy(alpha = 0.14f)
                )
                Text(
                    text = "تصميم وتطوير: أحمد السحار",
                    style = MaterialTheme.typography.labelSmall.merge(
                        TextStyle(
                            shadow = Shadow(
                                color = Color.Black.copy(alpha = 0.30f),
                                offset = Offset(0f, 1f),
                                blurRadius = 2f
                            )
                        )
                    ),
                    color = Color.White.copy(alpha = 0.5f),
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 4.dp)
                )
            }
        }
    }
}
