package com.humanitarian.aidmanagement.util

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

data class SavedExportResult(
    val uri: Uri,
    val fileName: String,
    val humanReadablePath: String
)

object PublicDownloadsExporter {

    private const val SUBFOLDER_NAME = "HumanitarianAid"
    private const val CSV_MIME_TYPE = "text/csv"
    private val UTF8_BOM_BYTES = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())

    /**
     * يحفظ ملف CSV مباشرة في مجلد التنزيلات العام بالجوال:
     * Downloads/HumanitarianAid مع إضافة بايتات UTF-8 BOM لضمان عرض العربية في Excel.
     */
    fun saveCsvToPublicDownloads(
        context: Context,
        fileName: String,
        csvContent: String,
        fileProviderAuthority: String? = null
    ): SavedExportResult {
        val cleanName = fileName
            .substringAfterLast('/')
            .substringAfterLast('\\')
            .trim()
            .ifBlank { "export_report_${System.currentTimeMillis()}.csv" }
            .let { if (it.endsWith(".csv", ignoreCase = true)) it else "$it.csv" }

        val contentWithoutBom = if (csvContent.startsWith("\uFEFF")) {
            csvContent.substring(1)
        } else {
            csvContent
        }
        val payloadBytes = contentWithoutBom.toByteArray(Charsets.UTF_8)
        val humanReadablePath = "وحدة التخزين الداخلية / التنزيلات (Downloads) / $SUBFOLDER_NAME / $cleanName"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/$SUBFOLDER_NAME"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, cleanName)
                put(MediaStore.MediaColumns.MIME_TYPE, CSV_MIME_TYPE)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val insertedUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("تعذر إنشاء ملف التقرير في مجلد التنزيلات العام")

            try {
                resolver.openOutputStream(insertedUri)?.use { outputStream ->
                    outputStream.write(UTF8_BOM_BYTES)
                    outputStream.write(payloadBytes)
                    outputStream.flush()
                } ?: throw IOException("تعذر فتح مسار الكتابة لملف التقرير")

                val publishValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                resolver.update(insertedUri, publishValues, null, null)

                return SavedExportResult(
                    uri = insertedUri,
                    fileName = cleanName,
                    humanReadablePath = humanReadablePath
                )
            } catch (e: Exception) {
                runCatching { resolver.delete(insertedUri, null, null) }
                throw e
            }
        } else {
            @Suppress("DEPRECATION")
            val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val targetDir = File(publicDownloads, SUBFOLDER_NAME).apply {
                if (!exists() && !mkdirs()) {
                    throw IOException("تعذر إنشاء مجلد $SUBFOLDER_NAME داخل التنزيلات")
                }
            }
            val outFile = File(targetDir, cleanName)
            FileOutputStream(outFile).use { outputStream ->
                outputStream.write(UTF8_BOM_BYTES)
                outputStream.write(payloadBytes)
                outputStream.flush()
            }

            runCatching {
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(outFile.absolutePath),
                    arrayOf(CSV_MIME_TYPE),
                    null
                )
            }

            val authority = fileProviderAuthority?.takeIf { it.isNotBlank() }
                ?: "${context.packageName}.fileprovider"
            val fileUri = FileProvider.getUriForFile(context, authority, outFile)

            return SavedExportResult(
                uri = fileUri,
                fileName = cleanName,
                humanReadablePath = humanReadablePath
            )
        }
    }

    /**
     * فتح الملف المحفوظ مباشرة في تطبيق Excel أو قارئ الجداول.
     */
    fun openSavedCsv(context: Context, result: SavedExportResult): Boolean {
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(result.uri, CSV_MIME_TYPE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(viewIntent)
            true
        } catch (_: ActivityNotFoundException) {
            runCatching {
                val chooser = Intent.createChooser(viewIntent, "فتح الملف بواسطة").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
                true
            }.getOrDefault(false)
        } catch (_: Exception) {
            false
        }
    }

    /**
     * حفظ ملف PDF مباشرة في مجلد التنزيلات العام بالجوال (Downloads/HumanitarianAid).
     */
    fun savePdfToPublicDownloads(
        context: Context,
        fileName: String,
        fileProviderAuthority: String? = null,
        writePdfContent: (java.io.OutputStream) -> Unit
    ): SavedExportResult {
        val cleanName = fileName
            .substringAfterLast('/')
            .substringAfterLast('\\')
            .trim()
            .ifBlank { "vouchers_a4_${System.currentTimeMillis()}.pdf" }
            .let { if (it.endsWith(".pdf", ignoreCase = true)) it else "$it.pdf" }

        val pdfMime = "application/pdf"
        val humanReadablePath = "وحدة التخزين الداخلية / التنزيلات (Downloads) / $SUBFOLDER_NAME / $cleanName"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = context.contentResolver
            val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/$SUBFOLDER_NAME"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, cleanName)
                put(MediaStore.MediaColumns.MIME_TYPE, pdfMime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }

            val insertedUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("تعذر إنشاء ملف PDF في مجلد التنزيلات العام")

            try {
                resolver.openOutputStream(insertedUri)?.use { outputStream ->
                    writePdfContent(outputStream)
                    outputStream.flush()
                } ?: throw IOException("تعذر فتح مسار الكتابة لملف PDF")

                val publishValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }
                resolver.update(insertedUri, publishValues, null, null)

                return SavedExportResult(
                    uri = insertedUri,
                    fileName = cleanName,
                    humanReadablePath = humanReadablePath
                )
            } catch (e: Exception) {
                runCatching { resolver.delete(insertedUri, null, null) }
                throw e
            }
        } else {
            @Suppress("DEPRECATION")
            val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val targetDir = File(publicDownloads, SUBFOLDER_NAME).apply {
                if (!exists() && !mkdirs()) {
                    throw IOException("تعذر إنشاء مجلد $SUBFOLDER_NAME داخل التنزيلات")
                }
            }
            val outFile = File(targetDir, cleanName)
            FileOutputStream(outFile).use { outputStream ->
                writePdfContent(outputStream)
                outputStream.flush()
            }

            runCatching {
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(outFile.absolutePath),
                    arrayOf(pdfMime),
                    null
                )
            }

            val authority = fileProviderAuthority?.takeIf { it.isNotBlank() }
                ?: "${context.packageName}.fileprovider"
            val fileUri = FileProvider.getUriForFile(context, authority, outFile)

            return SavedExportResult(
                uri = fileUri,
                fileName = cleanName,
                humanReadablePath = humanReadablePath
            )
        }
    }

    /**
     * فتح ملف PDF المحفوظ مباشرة في عارض PDF.
     */
    fun openSavedPdf(context: Context, result: SavedExportResult): Boolean {
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(result.uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(viewIntent)
            true
        } catch (_: ActivityNotFoundException) {
            runCatching {
                val chooser = Intent.createChooser(viewIntent, "فتح ملف PDF بواسطة").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
                true
            }.getOrDefault(false)
        } catch (_: Exception) {
            false
        }
    }

    /**
     * فتح قائمة مشاركة لملف PDF المحفوظ.
     */
    fun shareSavedPdf(
        context: Context,
        result: SavedExportResult,
        subject: String = "بطاقات توزيع المساعدات (A4)"
    ): Boolean {
        return runCatching {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, result.uri)
                putExtra(Intent.EXTRA_SUBJECT, subject)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(sendIntent, "مشاركة ملف بطاقات التوزيع (PDF)").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            true
        }.getOrDefault(false)
    }

    /**
     * فتح قائمة المشاركة فقط عند طلب المستخدم إرسال الملف.
     */
    fun shareSavedCsv(
        context: Context,
        result: SavedExportResult,
        subject: String = "تقرير تدقيق وتداخل بيانات الأسر"
    ): Boolean {
        return runCatching {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = CSV_MIME_TYPE
                putExtra(Intent.EXTRA_STREAM, result.uri)
                putExtra(Intent.EXTRA_SUBJECT, subject)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(sendIntent, "مشاركة تقرير التداخل (Excel)").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            true
        }.getOrDefault(false)
    }
}
