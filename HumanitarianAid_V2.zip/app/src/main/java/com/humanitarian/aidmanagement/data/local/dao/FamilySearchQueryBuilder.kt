package com.humanitarian.aidmanagement.data.local.dao

import androidx.sqlite.db.SimpleSQLiteQuery
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.util.ArabicTextNormalizer

/**
 * منشئ استعلامات البحث الشامل والمرن في سجل الأسر (`families`).
 *
 * يدعم في آنٍ واحد:
 * 1. اسم رب الأسرة (الرباعي غير المجزأ)، اسم الزوجة، وأسماء الأبناء الرسميين (`children.childName`)
 *    بتقسيم نص البحث إلى مقاطع (Tokens) مستقلة عن الترتيب والموضع مع تطبيع عربي كامل
 *    (أ/إ/آ/ٱ -> ا، ة -> ه، ى -> ي، إزالة التشكيل والتطويل والمسافات الزائدة).
 * 2. رقم هوية رب الأسرة، رقم هوية الزوجة، أرقام هويات الأبناء الرسميين (`children.nationalID`)،
 *    الجوال الأساسي، الجوال البديل 1، والجوال البديل 2 بمطابقة مباشرة أو جزئية مع تحويل الأرقام العربية/الفارسية.
 */
object FamilySearchQueryBuilder {

    private const val MAX_SEARCH_TOKENS = 8

    /**
     * تعبير SQLite لتطبيع الأعمدة النصية العربية (اسم رب الأسرة / اسم الزوجة) قبل المقارنة:
     * توحيد أ/إ/آ/ٱ -> ا، وتوحيد ة -> ه، و ى -> ي، وإزالة التطويل (ـ).
     */
    fun normalizeArabicColumnSql(columnExpr: String): String =
        "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(" +
            "COALESCE($columnExpr, ''), 'أ', 'ا'), 'إ', 'ا'), 'آ', 'ا'), 'ٱ', 'ا'), 'ة', 'ه'), 'ى', 'ي'), 'ـ', '')"

    /**
     * تحويل الأرقام العربية المشرقية والفارسية إلى أرقام إنجليزية (0-9).
     */
    fun toAsciiDigits(input: String): String {
        if (input.isEmpty()) return ""
        return buildString(input.length) {
            for (ch in input) {
                when (ch) {
                    in '٠'..'٩' -> append(('0'.code + (ch.code - '٠'.code)).toChar())
                    in '۰'..'۹' -> append(('0'.code + (ch.code - '۰'.code)).toChar())
                    else -> append(ch)
                }
            }
        }
    }

    /**
     * تطبيع النص العربي:
     * - تحويل الأرقام العربية والفارسية إلى 0-9
     * - إزالة التشكيل والتطويل ورموز % الزائدة
     * - توحيد الألف (أ/إ/آ/ٱ -> ا) والتاء المربوطة/الهاء (ة -> ه) والألف المقصورة/الياء (ى -> ي)
     * - تقليص المسافات الزائدة
     */
    fun normalizeArabicText(raw: String): String {
        if (raw.isBlank()) return ""
        return ArabicTextNormalizer.normalizeArabic(raw.replace('%', ' '))
    }

    /**
     * تقسيم نص البحث إلى مقاطع/كلمات مطبّعة (Tokens) غير مكررة.
     */
    fun tokenizeQuery(rawQuery: String): List<String> {
        val normalized = normalizeArabicText(rawQuery)
        if (normalized.isEmpty()) return emptyList()
        return normalized
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .distinct()
            .take(MAX_SEARCH_TOKENS)
    }

    /**
     * استخراج نص مضغوط للبحث في أرقام الهويات والجوالات (تحويل الأرقام وإزالة الفراغات والشرطات).
     */
    fun extractCompactIdentifierQuery(rawQuery: String): String {
        val ascii = toAsciiDigits(rawQuery.trim())
        if (ascii.isEmpty()) return ""
        return buildString(ascii.length) {
            for (ch in ascii) {
                if (ch != ' ' && ch != '\t' && ch != '\n' && ch != '-' && ch != '%' && ch != '+') {
                    append(ch)
                }
            }
        }
    }

    private fun escapeLikePattern(value: String): String {
        if (value.isEmpty()) return ""
        return buildString(value.length) {
            for (ch in value) {
                when (ch) {
                    '\\', '%', '_' -> {
                        append('\\')
                        append(ch)
                    }
                    else -> append(ch)
                }
            }
        }
    }

    private fun normalizeGenderFilter(childGender: String?): String? {
        val clean = childGender?.trim() ?: return null
        if (clean.isEmpty() || clean == "الكل") return null
        return when (clean) {
            "انثى", "أنثى", "إناث", "اناث" -> "أنثى"
            "ذكر", "ذكور" -> "ذكر"
            else -> clean
        }
    }

    private fun buildChildPredicates(
        childAlias: String,
        childBirthDateMin: String?,
        childBirthDateMax: String?,
        childGender: String?,
        args: MutableList<Any>
    ): List<String> {
        val predicates = mutableListOf<String>()
        val cleanMin = childBirthDateMin?.trim()?.takeIf { it.isNotEmpty() }
        val cleanMax = childBirthDateMax?.trim()?.takeIf { it.isNotEmpty() }
        if (cleanMin != null && cleanMax != null) {
            predicates.add("$childAlias.birthDate BETWEEN ? AND ?")
            args.add(cleanMin)
            args.add(cleanMax)
        }
        val normGender = normalizeGenderFilter(childGender)
        if (normGender != null) {
            if (normGender == "أنثى") {
                predicates.add("TRIM($childAlias.gender) IN (?, ?)")
                args.add("أنثى")
                args.add("انثى")
            } else {
                predicates.add("TRIM($childAlias.gender) = ?")
                args.add(normGender)
            }
        }
        return predicates
    }

    /**
     * بناء شرط WHERE والمعاملات المربوطة بأمان ضد حقن SQL.
     */
    private fun buildWhereClause(
        rawQuery: String,
        localityId: Int?,
        shelterStatus: String?,
        localityName: String?,
        ignoreAllowedLocalities: Int,
        allowedLocalities: List<String>,
        ignoreAllowedBranches: Int,
        allowedBranches: List<String>,
        branchName: String?,
        childBirthDateMin: String? = null,
        childBirthDateMax: String? = null,
        childGender: String? = null
    ): Pair<String, MutableList<Any>> {
        val clauses = mutableListOf<String>()
        val args = mutableListOf<Any>()

        val tokens = tokenizeQuery(rawQuery)
        val compactId = extractCompactIdentifierQuery(rawQuery)
        val corePhone = ArabicTextNormalizer.normalizePhoneCore(rawQuery)
        val isDigitsOnly = compactId.isNotEmpty() &&
            compactId.all { it.isDigit() } &&
            tokens.isNotEmpty() &&
            tokens.all { tok -> tok.all { it.isDigit() || it == '-' || it == '+' || it == '(' || it == ')' } }

        if (tokens.isNotEmpty() || compactId.isNotEmpty() || corePhone.isNotEmpty()) {
            val orBranches = mutableListOf<String>()

            if (!isDigitsOnly && tokens.isNotEmpty()) {
                val normNameCol = normalizeArabicColumnSql("name")
                val normWifeCol = normalizeArabicColumnSql("wifeName")
                val normChildNameCol = normalizeArabicColumnSql("ch.childName")

                // 1. اسم رب الأسرة: يجب أن يحتوي على جميع المقاطع المدخلة بغض النظر عن الترتيب والموضع
                val headNameAnd = tokens.joinToString(" AND ") { "$normNameCol LIKE ? ESCAPE '\\'" }
                orBranches.add("($headNameAnd)")
                tokens.forEach { tok -> args.add("%${escapeLikePattern(tok)}%") }

                // 2. اسم الزوجة: يجب أن يحتوي على جميع المقاطع المدخلة بغض النظر عن الترتيب والموضع
                val wifeNameAnd = tokens.joinToString(" AND ") { "$normWifeCol LIKE ? ESCAPE '\\'" }
                orBranches.add("(wifeName IS NOT NULL AND TRIM(wifeName) != '' AND $wifeNameAnd)")
                tokens.forEach { tok -> args.add("%${escapeLikePattern(tok)}%") }

                // 3. أسماء الأبناء الرسميين (EXISTS بدون تكرار لبطاقة الأسرة)
                val childNameAnd = tokens.joinToString(" AND ") { "$normChildNameCol LIKE ? ESCAPE '\\'" }
                orBranches.add(
                    "EXISTS (SELECT 1 FROM children ch WHERE ch.familyNationalID = families.nationalID AND TRIM(COALESCE(ch.childName, '')) != '' AND $childNameAnd)"
                )
                tokens.forEach { tok -> args.add("%${escapeLikePattern(tok)}%") }
            }

            // 4. أرقام الهويات (رب الأسرة، الزوجة، والأبناء الرسميون)
            if (compactId.isNotEmpty()) {
                val idLike = "%${escapeLikePattern(compactId)}%"
                orBranches.add("REPLACE(REPLACE(COALESCE(nationalID, ''), ' ', ''), '-', '') LIKE ? ESCAPE '\\'")
                args.add(idLike)
                orBranches.add("(wifeNationalID IS NOT NULL AND REPLACE(REPLACE(wifeNationalID, ' ', ''), '-', '') LIKE ? ESCAPE '\\')")
                args.add(idLike)
                orBranches.add(
                    "EXISTS (SELECT 1 FROM children ch WHERE ch.familyNationalID = families.nationalID AND REPLACE(REPLACE(COALESCE(ch.nationalID, ''), ' ', ''), '-', '') LIKE ? ESCAPE '\\')"
                )
                args.add(idLike)
            }

            // 5. أرقام الجوال الثلاثة باستخدام جوهر الرقم (إزالة البادئات الدولية والمحلية والمسافات والشرطات وعلامة +)
            if (corePhone.isNotEmpty()) {
                val phoneLike = "%${escapeLikePattern(corePhone)}%"
                orBranches.add("(primary_phone IS NOT NULL AND REPLACE(REPLACE(REPLACE(primary_phone, ' ', ''), '-', ''), '+', '') LIKE ? ESCAPE '\\')")
                args.add(phoneLike)
                orBranches.add("(alternative_phone_1 IS NOT NULL AND REPLACE(REPLACE(REPLACE(alternative_phone_1, ' ', ''), '-', ''), '+', '') LIKE ? ESCAPE '\\')")
                args.add(phoneLike)
                orBranches.add("(alternative_phone_2 IS NOT NULL AND REPLACE(REPLACE(REPLACE(alternative_phone_2, ' ', ''), '-', ''), '+', '') LIKE ? ESCAPE '\\')")
                args.add(phoneLike)
            }

            if (orBranches.isNotEmpty()) {
                clauses.add("(" + orBranches.joinToString(" OR ") + ")")
            }
        }

        if (localityId != null && localityId != 0) {
            clauses.add("localityID = ?")
            args.add(localityId)
        }

        val cleanLocName = localityName?.trim()?.takeIf { it.isNotEmpty() && it != "الكل" }
        if (cleanLocName != null) {
            clauses.add(
                "(currentSubArea = ? OR currentMainArea = ? OR localityID IN (SELECT LocalityID FROM tbl_Localities WHERE LocalityName = ?))"
            )
            args.add(cleanLocName)
            args.add(cleanLocName)
            args.add(cleanLocName)
        }

        val cleanShelter = shelterStatus?.trim()?.takeIf { it.isNotEmpty() && it != "الكل" }
        if (cleanShelter != null) {
            clauses.add("shelterStatus = ?")
            args.add(cleanShelter)
        }

        if (ignoreAllowedLocalities == 0) {
            val cleanAllowedLocs = allowedLocalities.filter { it.isNotBlank() }
            if (cleanAllowedLocs.isEmpty()) {
                clauses.add("1 = 0")
            } else {
                val ph = cleanAllowedLocs.joinToString(",") { "?" }
                clauses.add(
                    "(currentSubArea IN ($ph) OR currentMainArea IN ($ph) OR localityID IN (SELECT LocalityID FROM tbl_Localities WHERE LocalityName IN ($ph)))"
                )
                args.addAll(cleanAllowedLocs)
                args.addAll(cleanAllowedLocs)
                args.addAll(cleanAllowedLocs)
            }
        }

        if (ignoreAllowedBranches == 0) {
            val cleanAllowedBranches = allowedBranches.map { it.trim() }.filter { it.isNotBlank() }
            if (cleanAllowedBranches.isEmpty()) {
                clauses.add("1 = 0")
            } else {
                val ph = cleanAllowedBranches.joinToString(",") { "?" }
                clauses.add("TRIM(currentBranch) IN ($ph)")
                args.addAll(cleanAllowedBranches)
            }
        }

        val cleanBranch = branchName?.trim()?.takeIf {
            it.isNotEmpty() && it != "الكل" && it != "كافة الشعب"
        }
        if (cleanBranch != null) {
            clauses.add("TRIM(currentBranch) = TRIM(?)")
            args.add(cleanBranch)
        }

        // فلترة مفهرسة على جدول الأبناء (birthDate BETWEEN ? AND ? و/أو الجنس) عبر EXISTS
        val childPredicates = buildChildPredicates(
            childAlias = "c",
            childBirthDateMin = childBirthDateMin,
            childBirthDateMax = childBirthDateMax,
            childGender = childGender,
            args = args
        )
        if (childPredicates.isNotEmpty()) {
            clauses.add(
                "EXISTS (SELECT 1 FROM children c WHERE c.familyNationalID = families.nationalID AND ${childPredicates.joinToString(" AND ")})"
            )
        }

        val whereSql = if (clauses.isEmpty()) "" else " WHERE " + clauses.joinToString(" AND ")
        return whereSql to args
    }

    /**
     * بناء استعلام جلب الأسر (يدعم Paging 3 عند تمرير limit=null و offset=null، كما يدعم LIMIT/OFFSET المباشر).
     */
    fun buildSelectQuery(
        rawQuery: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null,
        localityName: String? = null,
        ignoreAllowedLocalities: Int = 1,
        allowedLocalities: List<String> = listOf("__ALL__"),
        ignoreAllowedBranches: Int = 1,
        allowedBranches: List<String> = listOf("__ALL__"),
        branchName: String? = null,
        limit: Int? = null,
        offset: Int? = null,
        childBirthDateMin: String? = null,
        childBirthDateMax: String? = null,
        childGender: String? = null
    ): SimpleSQLiteQuery {
        val (whereSql, args) = buildWhereClause(
            rawQuery = rawQuery,
            localityId = localityId,
            shelterStatus = shelterStatus,
            localityName = localityName,
            ignoreAllowedLocalities = ignoreAllowedLocalities,
            allowedLocalities = allowedLocalities,
            ignoreAllowedBranches = ignoreAllowedBranches,
            allowedBranches = allowedBranches,
            branchName = branchName,
            childBirthDateMin = childBirthDateMin,
            childBirthDateMax = childBirthDateMax,
            childGender = childGender
        )
        val sql = StringBuilder("SELECT * FROM families")
            .append(whereSql)
            .append(" ORDER BY createdDate DESC, familyID DESC")
        if (limit != null) {
            sql.append(" LIMIT ?")
            args.add(limit)
        }
        if (offset != null) {
            sql.append(" OFFSET ?")
            args.add(offset)
        }
        return SimpleSQLiteQuery(sql.toString(), args.toTypedArray())
    }

    /**
     * بناء استعلام عدّ الأسر المطابقة لنفس معايير البحث والفلترة تماماً.
     */
    fun buildCountQuery(
        rawQuery: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null,
        localityName: String? = null,
        ignoreAllowedLocalities: Int = 1,
        allowedLocalities: List<String> = listOf("__ALL__"),
        ignoreAllowedBranches: Int = 1,
        allowedBranches: List<String> = listOf("__ALL__"),
        branchName: String? = null,
        childBirthDateMin: String? = null,
        childBirthDateMax: String? = null,
        childGender: String? = null
    ): SimpleSQLiteQuery {
        val (whereSql, args) = buildWhereClause(
            rawQuery = rawQuery,
            localityId = localityId,
            shelterStatus = shelterStatus,
            localityName = localityName,
            ignoreAllowedLocalities = ignoreAllowedLocalities,
            allowedLocalities = allowedLocalities,
            ignoreAllowedBranches = ignoreAllowedBranches,
            allowedBranches = allowedBranches,
            branchName = branchName,
            childBirthDateMin = childBirthDateMin,
            childBirthDateMax = childBirthDateMax,
            childGender = childGender
        )
        return SimpleSQLiteQuery("SELECT COUNT(*) FROM families$whereSql", args.toTypedArray())
    }

    /**
     * بناء استعلام عدّ إجمالي الأبناء المطابقين لنطاق العمر والجنس ضمن الأسر المطابقة لجميع الفلاتر الحالية.
     */
    fun buildMatchedChildrenCountQuery(
        rawQuery: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null,
        localityName: String? = null,
        ignoreAllowedLocalities: Int = 1,
        allowedLocalities: List<String> = listOf("__ALL__"),
        ignoreAllowedBranches: Int = 1,
        allowedBranches: List<String> = listOf("__ALL__"),
        branchName: String? = null,
        childBirthDateMin: String? = null,
        childBirthDateMax: String? = null,
        childGender: String? = null
    ): SimpleSQLiteQuery {
        val (familyWhereSql, familyArgs) = buildWhereClause(
            rawQuery = rawQuery,
            localityId = localityId,
            shelterStatus = shelterStatus,
            localityName = localityName,
            ignoreAllowedLocalities = ignoreAllowedLocalities,
            allowedLocalities = allowedLocalities,
            ignoreAllowedBranches = ignoreAllowedBranches,
            allowedBranches = allowedBranches,
            branchName = branchName,
            childBirthDateMin = null,
            childBirthDateMax = null,
            childGender = null
        )

        val allArgs = mutableListOf<Any>()
        val outerPredicates = mutableListOf<String>()
        outerPredicates.add("c.familyNationalID IN (SELECT nationalID FROM families$familyWhereSql)")
        allArgs.addAll(familyArgs)

        val childPredicates = buildChildPredicates(
            childAlias = "c",
            childBirthDateMin = childBirthDateMin,
            childBirthDateMax = childBirthDateMax,
            childGender = childGender,
            args = allArgs
        )
        outerPredicates.addAll(childPredicates)

        val sql = "SELECT COUNT(*) FROM children c WHERE ${outerPredicates.joinToString(" AND ")}"
        return SimpleSQLiteQuery(sql, allArgs.toTypedArray())
    }

    /**
     * مطابقة في الذاكرة بنفس قواعد التطبيع والمقاطع لاستخدامها عند الحاجة دون أي تباين مع SQL.
     */
    fun matchesFamily(family: FamilyEntity, rawQuery: String): Boolean {
        val cleanQuery = rawQuery.replace("%", " ").trim()
        if (cleanQuery.isEmpty()) return true

        val compactId = extractCompactIdentifierQuery(cleanQuery)
        val tokens = tokenizeQuery(cleanQuery)
        val isDigitsOnly = compactId.isNotEmpty() &&
            compactId.all { it.isDigit() } &&
            tokens.all { tok -> tok.all { it.isDigit() || it == '-' || it == '+' || it == '(' || it == ')' } }

        // 1. مطابقة اسم رب الأسرة أو اسم الزوجة بالتطبيع العربي المرن
        if (!isDigitsOnly) {
            if (ArabicTextNormalizer.matchesArabicQuery(family.name, cleanQuery)) return true
            if (!family.wifeName.isNullOrBlank() && ArabicTextNormalizer.matchesArabicQuery(family.wifeName, cleanQuery)) {
                return true
            }
        }

        // 2. مطابقة رقم هوية رب الأسرة أو هوية الزوجة
        if (compactId.isNotEmpty()) {
            val idFields = listOf(family.nationalID, family.wifeNationalID.orEmpty())
            if (idFields.any { field ->
                    field.isNotBlank() && extractCompactIdentifierQuery(field).contains(compactId, ignoreCase = true)
                }
            ) {
                return true
            }
        }

        // 3. مطابقة ذكية لأرقام الجوال الثلاثة عبر جوهر الرقم (تجاهل +970 / 00970 / +972 / 00972 / 0)
        if (ArabicTextNormalizer.matchesPhoneQuery(family.primary_phone, cleanQuery) ||
            ArabicTextNormalizer.matchesPhoneQuery(family.alternative_phone_1, cleanQuery) ||
            ArabicTextNormalizer.matchesPhoneQuery(family.alternative_phone_2, cleanQuery)
        ) {
            return true
        }

        return false
    }

    /**
     * مطابقة ابن رسمي واحد مع نص البحث بنفس قواعد التطبيع العربي والمقاطع ورقم الهوية.
     * تُستخدم لتمييز الابن المطابق داخل بطاقة أسرته في شاشة الأسر الرسمية.
     */
    fun matchesChild(child: ChildEntity, rawQuery: String): Boolean {
        val cleanQuery = rawQuery.replace("%", " ").trim()
        if (cleanQuery.isEmpty()) return false

        val tokens = tokenizeQuery(cleanQuery)
        val compactId = extractCompactIdentifierQuery(cleanQuery)
        val isDigitsOnly = compactId.isNotEmpty() &&
            compactId.all { it.isDigit() } &&
            tokens.isNotEmpty() &&
            tokens.all { tok -> tok.all { it.isDigit() || it == '-' || it == '+' || it == '(' || it == ')' } }

        if (!isDigitsOnly && ArabicTextNormalizer.matchesArabicQuery(child.childName, cleanQuery)) {
            return true
        }

        if (compactId.isNotEmpty() && child.nationalID.isNotBlank()) {
            if (extractCompactIdentifierQuery(child.nationalID).contains(compactId, ignoreCase = true)) {
                return true
            }
        }

        return false
    }
}
