package com.humanitarian.aidmanagement.data.local.dao

import androidx.sqlite.db.SimpleSQLiteQuery
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity

/**
 * منشئ استعلامات البحث الشامل والمرن في سجل الأسر (`families`).
 *
 * يدعم في آنٍ واحد:
 * 1. اسم رب الأسرة (الرباعي غير المجزأ) واسم الزوجة (الرباعي غير المجزأ)
 *    بتقسيم نص البحث إلى مقاطع (Tokens) مستقلة عن الترتيب والموضع مع تطبيع عربي كامل
 *    (أ/إ/آ/ٱ -> ا، ة -> ه، ى -> ي، إزالة التشكيل والتطويل والمسافات الزائدة).
 * 2. رقم هوية رب الأسرة، رقم هوية الزوجة، الجوال الأساسي، الجوال البديل 1، والجوال البديل 2
 *    بمطابقة مباشرة أو جزئية (LIKE '%query%') مع تحويل الأرقام العربية والفارسية إلى إنجليزية.
 */
object FamilySearchQueryBuilder {

    private const val MAX_SEARCH_TOKENS = 8

    /**
     * تعبير SQLite لتطبيع الأعمدة النصية العربية (اسم رب الأسرة / اسم الزوجة) قبل المقارنة:
     * توحيد أ/إ/آ/ٱ -> ا، وتوحيد ة -> ه، و ى -> ي، وإزالة التطويل (ـ).
     */
    fun normalizeArabicColumnSql(columnExpr: String): String =
        "REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(" +
            "COALESCE($columnExpr, ''), 'أ', 'ا'), 'إ', 'ا'), 'آ', 'ا'), 'ٱ', 'ا'), 'ة', 'ه'), 'ى', 'ي'), 'ـ', '')"

    /**
     * تحويل الأرقام العربية المشرقية والفارسية إلى أرقام إنجليزية (0-9).
     */
    fun toAsciiDigits(input: String): String {
        if (input.isEmpty()) return ""
        return buildString(input.length) {
            for (ch in input) {
                when (ch) {
                    in '٠'..'٩' -> append(('0'.code + (ch.code - '٠'.code)).toChar())
                    in '۰'..'۹' -> append(('0'.code + (ch.code - '۰'.code)).toChar())
                    else -> append(ch)
                }
            }
        }
    }

    /**
     * تطبيع النص العربي:
     * - تحويل الأرقام العربية والفارسية إلى 0-9
     * - إزالة التشكيل والتطويل ورموز % الزائدة
     * - توحيد الألف (أ/إ/آ/ٱ -> ا) والتاء المربوطة/الهاء (ة -> ه) والألف المقصورة/الياء (ى -> ي)
     * - تقليص المسافات الزائدة
     */
    fun normalizeArabicText(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return ""
        val sb = StringBuilder(trimmed.length)
        for (ch in trimmed) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                'أ', 'إ', 'آ', 'ٱ' -> sb.append('ا')
                'ة' -> sb.append('ه')
                'ى' -> sb.append('ي')
                'ـ', in '\u064B'..'\u065F', '\u0670' -> Unit // إزالة التطويل والحركات
                '%' -> sb.append(' ')
                else -> sb.append(ch)
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /**
     * تقسيم نص البحث إلى مقاطع/كلمات مطبّعة (Tokens) غير مكررة.
     */
    fun tokenizeQuery(rawQuery: String): List<String> {
        val normalized = normalizeArabicText(rawQuery)
        if (normalized.isEmpty()) return emptyList()
        return normalized
            .split(Regex("\\s+"))
            .filter { it.isNotBlank() }
            .distinct()
            .take(MAX_SEARCH_TOKENS)
    }

    /**
     * استخراج نص مضغوط للبحث في أرقام الهويات والجوالات (تحويل الأرقام وإزالة الفراغات والشرطات).
     */
    fun extractCompactIdentifierQuery(rawQuery: String): String {
        val ascii = toAsciiDigits(rawQuery.trim())
        if (ascii.isEmpty()) return ""
        return buildString(ascii.length) {
            for (ch in ascii) {
                if (ch != ' ' && ch != '\t' && ch != '\n' && ch != '-' && ch != '%' && ch != '+') {
                    append(ch)
                }
            }
        }
    }

    private fun escapeLikePattern(value: String): String {
        if (value.isEmpty()) return ""
        return buildString(value.length) {
            for (ch in value) {
                when (ch) {
                    '\\', '%', '_' -> {
                        append('\\')
                        append(ch)
                    }
                    else -> append(ch)
                }
            }
        }
    }

    /**
     * بناء شرط WHERE والمعاملات المربوطة بأمان ضد حقن SQL.
     */
    private fun buildWhereClause(
        rawQuery: String,
        localityId: Int?,
        shelterStatus: String?,
        localityName: String?,
        ignoreAllowedLocalities: Int,
        allowedLocalities: List<String>,
        ignoreAllowedBranches: Int,
        allowedBranches: List<String>,
        branchName: String?
    ): Pair<String, MutableList<Any>> {
        val clauses = mutableListOf<String>()
        val args = mutableListOf<Any>()

        val tokens = tokenizeQuery(rawQuery)
        val compactId = extractCompactIdentifierQuery(rawQuery)
        val isDigitsOnly = compactId.isNotEmpty() &&
            compactId.all { it.isDigit() } &&
            tokens.isNotEmpty() &&
            tokens.all { tok -> tok.all { it.isDigit() || it == '-' || it == '+' } }

        if (tokens.isNotEmpty() || compactId.isNotEmpty()) {
            val orBranches = mutableListOf<String>()

            if (!isDigitsOnly && tokens.isNotEmpty()) {
                val normNameCol = normalizeArabicColumnSql("name")
                val normWifeCol = normalizeArabicColumnSql("wifeName")

                // 1. اسم رب الأسرة: يجب أن يحتوي على جميع المقاطع المدخلة بغض النظر عن الترتيب والموضع
                val headNameAnd = tokens.joinToString(" AND ") { "$normNameCol LIKE ? ESCAPE '\\'" }
                orBranches.add("($headNameAnd)")
                tokens.forEach { tok -> args.add("%${escapeLikePattern(tok)}%") }

                // 2. اسم الزوجة: يجب أن يحتوي على جميع المقاطع المدخلة بغض النظر عن الترتيب والموضع
                val wifeNameAnd = tokens.joinToString(" AND ") { "$normWifeCol LIKE ? ESCAPE '\\'" }
                orBranches.add("(wifeName IS NOT NULL AND TRIM(wifeName) != '' AND $wifeNameAnd)")
                tokens.forEach { tok -> args.add("%${escapeLikePattern(tok)}%") }
            }

            // 3. أرقام الهويات (رب الأسرة والزوجة) وأرقام الجوال الثلاثة في آنٍ واحد (تطابق مباشر أو جزئي)
            if (compactId.isNotEmpty()) {
                val idLike = "%${escapeLikePattern(compactId)}%"
                orBranches.add("REPLACE(REPLACE(COALESCE(nationalID, ''), ' ', ''), '-', '') LIKE ? ESCAPE '\\'")
                args.add(idLike)
                orBranches.add("(wifeNationalID IS NOT NULL AND REPLACE(REPLACE(wifeNationalID, ' ', ''), '-', '') LIKE ? ESCAPE '\\')")
                args.add(idLike)
                orBranches.add("(primary_phone IS NOT NULL AND REPLACE(REPLACE(primary_phone, ' ', ''), '-', '') LIKE ? ESCAPE '\\')")
                args.add(idLike)
                orBranches.add("(alternative_phone_1 IS NOT NULL AND REPLACE(REPLACE(alternative_phone_1, ' ', ''), '-', '') LIKE ? ESCAPE '\\')")
                args.add(idLike)
                orBranches.add("(alternative_phone_2 IS NOT NULL AND REPLACE(REPLACE(alternative_phone_2, ' ', ''), '-', '') LIKE ? ESCAPE '\\')")
                args.add(idLike)
            }

            if (orBranches.isNotEmpty()) {
                clauses.add("(" + orBranches.joinToString(" OR ") + ")")
            }
        }

        if (localityId != null && localityId != 0) {
            clauses.add("localityID = ?")
            args.add(localityId)
        }

        val cleanLocName = localityName?.trim()?.takeIf { it.isNotEmpty() && it != "الكل" }
        if (cleanLocName != null) {
            clauses.add(
                "(currentSubArea = ? OR currentMainArea = ? OR localityID IN (SELECT LocalityID FROM tbl_Localities WHERE LocalityName = ?))"
            )
            args.add(cleanLocName)
            args.add(cleanLocName)
            args.add(cleanLocName)
        }

        val cleanShelter = shelterStatus?.trim()?.takeIf { it.isNotEmpty() && it != "الكل" }
        if (cleanShelter != null) {
            clauses.add("shelterStatus = ?")
            args.add(cleanShelter)
        }

        if (ignoreAllowedLocalities == 0) {
            val cleanAllowedLocs = allowedLocalities.filter { it.isNotBlank() }
            if (cleanAllowedLocs.isEmpty()) {
                clauses.add("1 = 0")
            } else {
                val ph = cleanAllowedLocs.joinToString(",") { "?" }
                clauses.add(
                    "(currentSubArea IN ($ph) OR currentMainArea IN ($ph) OR localityID IN (SELECT LocalityID FROM tbl_Localities WHERE LocalityName IN ($ph)))"
                )
                args.addAll(cleanAllowedLocs)
                args.addAll(cleanAllowedLocs)
                args.addAll(cleanAllowedLocs)
            }
        }

        if (ignoreAllowedBranches == 0) {
            val cleanAllowedBranches = allowedBranches.map { it.trim() }.filter { it.isNotBlank() }
            if (cleanAllowedBranches.isEmpty()) {
                clauses.add("1 = 0")
            } else {
                val ph = cleanAllowedBranches.joinToString(",") { "?" }
                clauses.add("TRIM(currentBranch) IN ($ph)")
                args.addAll(cleanAllowedBranches)
            }
        }

        val cleanBranch = branchName?.trim()?.takeIf {
            it.isNotEmpty() && it != "الكل" && it != "كافة الشعب"
        }
        if (cleanBranch != null) {
            clauses.add("TRIM(currentBranch) = TRIM(?)")
            args.add(cleanBranch)
        }

        val whereSql = if (clauses.isEmpty()) "" else " WHERE " + clauses.joinToString(" AND ")
        return whereSql to args
    }

    /**
     * بناء استعلام جلب الأسر (يدعم Paging 3 عند تمرير limit=null و offset=null، كما يدعم LIMIT/OFFSET المباشر).
     */
    fun buildSelectQuery(
        rawQuery: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null,
        localityName: String? = null,
        ignoreAllowedLocalities: Int = 1,
        allowedLocalities: List<String> = listOf("__ALL__"),
        ignoreAllowedBranches: Int = 1,
        allowedBranches: List<String> = listOf("__ALL__"),
        branchName: String? = null,
        limit: Int? = null,
        offset: Int? = null
    ): SimpleSQLiteQuery {
        val (whereSql, args) = buildWhereClause(
            rawQuery = rawQuery,
            localityId = localityId,
            shelterStatus = shelterStatus,
            localityName = localityName,
            ignoreAllowedLocalities = ignoreAllowedLocalities,
            allowedLocalities = allowedLocalities,
            ignoreAllowedBranches = ignoreAllowedBranches,
            allowedBranches = allowedBranches,
            branchName = branchName
        )
        val sql = StringBuilder("SELECT * FROM families")
            .append(whereSql)
            .append(" ORDER BY createdDate DESC")
        if (limit != null) {
            sql.append(" LIMIT ?")
            args.add(limit)
        }
        if (offset != null) {
            sql.append(" OFFSET ?")
            args.add(offset)
        }
        return SimpleSQLiteQuery(sql.toString(), args.toTypedArray())
    }

    /**
     * بناء استعلام عدّ الأسر المطابقة لنفس معايير البحث والفلترة تماماً.
     */
    fun buildCountQuery(
        rawQuery: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null,
        localityName: String? = null,
        ignoreAllowedLocalities: Int = 1,
        allowedLocalities: List<String> = listOf("__ALL__"),
        ignoreAllowedBranches: Int = 1,
        allowedBranches: List<String> = listOf("__ALL__"),
        branchName: String? = null
    ): SimpleSQLiteQuery {
        val (whereSql, args) = buildWhereClause(
            rawQuery = rawQuery,
            localityId = localityId,
            shelterStatus = shelterStatus,
            localityName = localityName,
            ignoreAllowedLocalities = ignoreAllowedLocalities,
            allowedLocalities = allowedLocalities,
            ignoreAllowedBranches = ignoreAllowedBranches,
            allowedBranches = allowedBranches,
            branchName = branchName
        )
        return SimpleSQLiteQuery("SELECT COUNT(*) FROM families$whereSql", args.toTypedArray())
    }

    /**
     * مطابقة في الذاكرة بنفس قواعد التطبيع والمقاطع لاستخدامها عند الحاجة دون أي تباين مع SQL.
     */
    fun matchesFamily(family: FamilyEntity, rawQuery: String): Boolean {
        val tokens = tokenizeQuery(rawQuery)
        val compactId = extractCompactIdentifierQuery(rawQuery)
        if (tokens.isEmpty() && compactId.isEmpty()) return true

        val isDigitsOnly = compactId.isNotEmpty() &&
            compactId.all { it.isDigit() } &&
            tokens.all { tok -> tok.all { it.isDigit() || it == '-' || it == '+' } }

        if (!isDigitsOnly && tokens.isNotEmpty()) {
            val normHead = normalizeArabicText(family.name)
            if (tokens.all { normHead.contains(it, ignoreCase = true) }) return true

            val rawWife = family.wifeName
            if (!rawWife.isNullOrBlank()) {
                val normWife = normalizeArabicText(rawWife)
                if (tokens.all { normWife.contains(it, ignoreCase = true) }) return true
            }
        }

        if (compactId.isNotEmpty()) {
            val identifierFields = listOf(
                family.nationalID,
                family.wifeNationalID.orEmpty(),
                family.primary_phone.orEmpty(),
                family.alternative_phone_1.orEmpty(),
                family.alternative_phone_2.orEmpty()
            )
            if (identifierFields.any { field ->
                    field.isNotBlank() && extractCompactIdentifierQuery(field).contains(compactId, ignoreCase = true)
                }
            ) {
                return true
            }
        }

        return false
    }
}
