package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * معايير الفلترة المؤقتة لشاشة الترحيل
 */
data class TransferFilterCriteria(
    val projectId: Long?,
    val query: String
)

/**
 * كائن عرض موحد لمرشح المساعدة مع بيانات الأسرة والمشروع
 */
data class NominatedCandidateItem(
    val record: AidRecordEntity,
    val family: FamilyEntity?,
    val projectName: String,
    val aidTypeName: String
)

/**
 * ViewModel لإدارة دورة حياة بيانات شاشة الترحيل (Migration/Transfer)
 * يضمن التدفق التفاعلي اللحظي بين Room Database وواجهة Jetpack Compose
 */
class TransferViewModel(
    private val repository: AidRepository
) : ViewModel() {

    private val _selectedProjectId = MutableStateFlow<Long?>(null)
    val selectedProjectId: StateFlow<Long?> = _selectedProjectId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val filterCriteria: Flow<TransferFilterCriteria> = combine(_selectedProjectId, _searchQuery) { prjId, query ->
        TransferFilterCriteria(prjId, query)
    }

    private val _isMigrating = MutableStateFlow(false)
    val isMigrating: StateFlow<Boolean> = _isMigrating.asStateFlow()

    private val _migrationSuccessCount = MutableStateFlow<Int?>(null)
    val migrationSuccessCount: StateFlow<Int?> = _migrationSuccessCount.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // 1. استلام الـ Flow من الـ Repository وتحويله إلى StateFlow تفاعلي باستخدام stateIn مع WhileSubscribed
    val nominatedRecords: StateFlow<List<AidRecordEntity>> = repository
        .getNominatedRecordsFlow()
        .flowOn(Dispatchers.IO)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeProjects: StateFlow<List<ProjectEntity>> = repository
        .getActiveProjects()
        .flowOn(Dispatchers.IO)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val activeAidTypes: StateFlow<List<AidTypeEntity>> = repository
        .getActiveAidTypes()
        .flowOn(Dispatchers.IO)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // 2. دمج السجلات المرشحة مع بيانات الأسر والمشاريع لإنتاج قائمة العرض التفاعلية
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val nominatedItems: StateFlow<List<NominatedCandidateItem>> = combine(
        nominatedRecords,
        filterCriteria,
        activeProjects,
        activeAidTypes
    ) { records: List<AidRecordEntity>, criteria: TransferFilterCriteria, projects: List<ProjectEntity>, aidTypes: List<AidTypeEntity> ->
        val projectMap: Map<Long, ProjectEntity> = projects.associateBy { it.projectID }
        val aidTypeMap: Map<Int, AidTypeEntity> = aidTypes.associateBy { it.aidTypeID }

        val prjId = criteria.projectId
        val cleanQuery = criteria.query.trim()

        val filteredByProject = if (prjId == null || prjId == 0L) {
            records
        } else {
            records.filter { it.projectID == prjId }
        }

        val familyIds: List<Long> = filteredByProject.map { it.familyID }.distinct()
        val familiesList: List<FamilyEntity> = if (familyIds.isNotEmpty()) {
            repository.getFamiliesByIdsSync(familyIds)
        } else {
            emptyList()
        }
        val familyMap: Map<Long, FamilyEntity> = familiesList.associateBy { it.familyID }

        filteredByProject.mapNotNull { record: AidRecordEntity ->
            val family: FamilyEntity? = familyMap[record.familyID]
            val item = NominatedCandidateItem(
                record = record,
                family = family,
                projectName = projectMap[record.projectID]?.projectName ?: "مشروع عام #${record.projectID}",
                aidTypeName = aidTypeMap[record.aidTypeID]?.aidTypeName ?: "مساعدة إغاثية"
            )

            if (cleanQuery.isBlank()) {
                item
            } else {
                val matchesName = family?.name?.contains(cleanQuery, ignoreCase = true) == true
                val matchesId = family?.nationalID?.contains(cleanQuery) == true
                val matchesPhone = family?.primary_phone?.contains(cleanQuery) == true
                if (matchesName || matchesId || matchesPhone) item else null
            }
        }
    }.flowOn(Dispatchers.IO).stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun selectProject(projectId: Long?) {
        _selectedProjectId.value = projectId
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearMessages() {
        _migrationSuccessCount.value = null
        _errorMessage.value = null
    }

    /**
     * تنفيذ دالة الترحيل وتحديث حالة السجلات في Room عبر viewModelScope.launch(Dispatchers.IO)
     * لضمان عدم تجميد الشاشة
     */
    fun executeMigration(
        targetStatus: String = "معتمد للترحيل والتسليم",
        customNotes: String? = null
    ) {
        val currentItems = nominatedItems.value
        if (currentItems.isEmpty()) return

        val recordIds = currentItems.map { it.record.aidRecordID }

        viewModelScope.launch(Dispatchers.IO) {
            _isMigrating.value = true
            try {
                val migratedCount = repository.migrateNominatedRecords(
                    recordIds = recordIds,
                    newStatus = targetStatus,
                    notes = customNotes
                )
                _migrationSuccessCount.value = migratedCount
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "حدث خطأ أثناء تنفيذ عملية الترحيل"
            } finally {
                _isMigrating.value = false
            }
        }
    }

    /**
     * إزالة مرشح فردي وحذف سجله من Room
     */
    fun removeNominatedRecord(recordId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.deleteAidRecord(recordId)
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "فشل حذف السجل"
            }
        }
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(TransferViewModel::class.java) ||
                modelClass.isAssignableFrom(MigrationViewModel::class.java)) {
                return TransferViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}

/**
 * أسماء بديلة للتوافق البرمجي التام (Aliases)
 */
typealias MigrationViewModel = TransferViewModel
typealias NominationResultsViewModel = TransferViewModel
