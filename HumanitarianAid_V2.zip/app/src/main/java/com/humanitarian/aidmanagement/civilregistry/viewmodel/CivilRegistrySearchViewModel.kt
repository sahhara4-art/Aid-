package com.humanitarian.aidmanagement.civilregistry.viewmodel

import android.content.Context
import android.net.Uri
import android.os.CancellationSignal
import android.os.OperationCanceledException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.civilregistry.bridge.CivilRegistryDraftBridge
import com.humanitarian.aidmanagement.civilregistry.data.CivilRegistryReadOnlyDataSource
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryChildRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryDbStatus
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryImportProgress
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchScope
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchTarget
import com.humanitarian.aidmanagement.civilregistry.security.CivilRegistryPermissionGuard
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * ViewModel مفصول بالكامل لوحدة البحث في السجل المدني (Read-Only Lookup)
 * - يمنع تنفيذ أي استعلام على civil_registry بالكامل إذا كان canAccessCivilRegistry == false
 * - يدعم البحث الفوري برب الأسرة أو الابن (عبر children_fts FTS4 وفهرس idx_children_parent_birth)
 * - يطبق Debounce ذكي (350ms) وإلغاء فوري للاستعلامات السابقة عبر CancellationSignal
 * - يدعم استيراد قواعد البيانات الضخمة على Dispatchers.IO مع شريط تقدم واضح
 */
@OptIn(FlowPreview::class)
class CivilRegistrySearchViewModel(
    private val dataSource: CivilRegistryReadOnlyDataSource
) : ViewModel() {

    data class UiState(
        val canAccessCivilRegistry: Boolean = false,
        val dbStatus: CivilRegistryDbStatus = CivilRegistryDbStatus.Checking,
        val isImportingDb: Boolean = false,
        val importProgress: CivilRegistryImportProgress? = null,
        val query: CivilRegistrySearchQuery = CivilRegistrySearchQuery(),
        val results: List<CivilRegistryRecord> = emptyList(),
        val isSearching: Boolean = false,
        val isLoadingMore: Boolean = false,
        val hasMore: Boolean = false,
        val hasSearchedOnce: Boolean = false,
        val minCharsHint: String? = null,
        val errorMessage: String? = null,
        val selectedRecordForPreview: CivilRegistryRecord? = null,
        val previewChildren: List<CivilRegistryChildRecord> = emptyList(),
        val isLoadingPreviewChildren: Boolean = false,
        val expandedCardParentIds: Set<String> = emptySet(),
        val childrenByParentId: Map<String, List<CivilRegistryChildRecord>> = emptyMap(),
        val matchedChildKeysByParentId: Map<String, Set<String>> = emptyMap(),
        val matchedChildNamesByParentId: Map<String, List<String>> = emptyMap(),
        val loadingChildrenParentId: String? = null,
        val isStagingTransfer: Boolean = false
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val queryFlow = MutableStateFlow(CivilRegistrySearchQuery())
    private var activeSearchJob: Job? = null
    private var activeCancellationSignal: CancellationSignal? = null
    private var previewChildrenJob: Job? = null

    init {
        refreshPermissionsAndDatabase()
        observeDebouncedSearch()
    }

    fun refreshPermissionsAndDatabase() {
        val allowed = CivilRegistryPermissionGuard.canAccessCivilRegistry()
        _uiState.update { it.copy(canAccessCivilRegistry = allowed) }
        if (!allowed) {
            cancelInFlightSearch()
            previewChildrenJob?.cancel()
            CivilRegistryDraftBridge.clearDraft()
            dataSource.close()
            _uiState.update {
                it.copy(
                    results = emptyList(),
                    hasMore = false,
                    isSearching = false,
                    isLoadingMore = false,
                    minCharsHint = null,
                    selectedRecordForPreview = null,
                    previewChildren = emptyList(),
                    isLoadingPreviewChildren = false,
                    expandedCardParentIds = emptySet(),
                    childrenByParentId = emptyMap(),
                    matchedChildKeysByParentId = emptyMap(),
                    matchedChildNamesByParentId = emptyMap(),
                    loadingChildrenParentId = null,
                    errorMessage = null
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(dbStatus = CivilRegistryDbStatus.Checking, errorMessage = null) }
            val status = dataSource.ensureDatabaseReady()
            _uiState.update {
                it.copy(
                    dbStatus = status,
                    childrenByParentId = emptyMap(),
                    matchedChildKeysByParentId = emptyMap(),
                    matchedChildNamesByParentId = emptyMap(),
                    expandedCardParentIds = emptySet()
                )
            }
            if (status is CivilRegistryDbStatus.Ready && queryFlow.value.hasActiveCriteria && getMinCharsHint(queryFlow.value) == null) {
                executeSearch(queryFlow.value, resetResults = true)
            }
        }
    }

    fun importDatabaseFromUri(uri: Uri) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isImportingDb = true,
                    importProgress = CivilRegistryImportProgress(),
                    errorMessage = null
                )
            }
            val status = dataSource.importExternalDatabase(uri) { progress ->
                _uiState.update { it.copy(importProgress = progress) }
            }
            _uiState.update {
                it.copy(
                    isImportingDb = false,
                    importProgress = null,
                    dbStatus = status,
                    childrenByParentId = emptyMap(),
                    matchedChildKeysByParentId = emptyMap(),
                    matchedChildNamesByParentId = emptyMap(),
                    expandedCardParentIds = emptySet(),
                    previewChildren = emptyList(),
                    errorMessage = (status as? CivilRegistryDbStatus.Error)?.message
                )
            }
            if (status is CivilRegistryDbStatus.Ready && queryFlow.value.hasActiveCriteria && getMinCharsHint(queryFlow.value) == null) {
                executeSearch(queryFlow.value, resetResults = true)
            }
        }
    }

    fun onQuickQueryChange(value: String) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        updateQuery { it.copy(quickQuery = value) }
    }

    fun onTargetSelected(target: CivilRegistrySearchTarget) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        updateQuery { current ->
            current.copy(
                target = target,
                advancedMode = if (target == CivilRegistrySearchTarget.CHILD) false else current.advancedMode
            )
        }
    }

    fun onScopeSelected(scope: CivilRegistrySearchScope) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        updateQuery { it.copy(scope = scope) }
    }

    fun toggleAdvancedMode() {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        updateQuery { current ->
            val nextAdvanced = !current.advancedMode
            current.copy(
                advancedMode = nextAdvanced,
                target = if (nextAdvanced && current.target == CivilRegistrySearchTarget.CHILD) {
                    CivilRegistrySearchTarget.HEAD_OF_FAMILY
                } else {
                    current.target
                }
            )
        }
    }

    fun onNameFilterChange(value: String) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        updateQuery { it.copy(nameFilter = value) }
    }

    fun onNationalIdFilterChange(value: String) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        updateQuery { it.copy(nationalIdFilter = value) }
    }

    fun onWifeNameFilterChange(value: String) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        updateQuery { it.copy(wifeNameFilter = value) }
    }

    fun onWifeNationalIdFilterChange(value: String) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        updateQuery { it.copy(wifeNationalIdFilter = value) }
    }

    fun onPhoneFilterChange(value: String) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        updateQuery { it.copy(phoneFilter = value) }
    }

    fun clearAllFilters() {
        cancelInFlightSearch()
        val currentQuery = _uiState.value.query
        val cleared = CivilRegistrySearchQuery(
            target = currentQuery.target,
            advancedMode = currentQuery.advancedMode
        )
        queryFlow.value = cleared
        _uiState.update {
            it.copy(
                query = cleared,
                results = emptyList(),
                hasMore = false,
                isSearching = false,
                isLoadingMore = false,
                hasSearchedOnce = false,
                minCharsHint = null,
                expandedCardParentIds = emptySet(),
                matchedChildKeysByParentId = emptyMap(),
                matchedChildNamesByParentId = emptyMap(),
                errorMessage = null
            )
        }
    }

    /**
     * توسيع أو طي قسم الأبناء داخل بطاقة النتيجة مع جلب فوري مفهرس لمرة واحدة فقط لكل رب أسرة
     */
    fun toggleCardChildren(parentId: String) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        val cleanId = parentId.trim()
        if (cleanId.isEmpty()) return

        val state = _uiState.value
        if (cleanId in state.expandedCardParentIds) {
            _uiState.update { it.copy(expandedCardParentIds = it.expandedCardParentIds - cleanId) }
            return
        }

        _uiState.update { it.copy(expandedCardParentIds = it.expandedCardParentIds + cleanId) }
        if (state.childrenByParentId.containsKey(cleanId)) return

        viewModelScope.launch {
            _uiState.update { it.copy(loadingChildrenParentId = cleanId) }
            val loaded = try {
                dataSource.getChildrenForParent(cleanId)
            } catch (_: Throwable) {
                emptyList()
            }
            _uiState.update { current ->
                val updatedMap = LinkedHashMap(current.childrenByParentId)
                if (updatedMap.size >= 120) {
                    val oldestKey = updatedMap.keys.firstOrNull()
                    if (oldestKey != null) updatedMap.remove(oldestKey)
                }
                updatedMap[cleanId] = loaded
                current.copy(
                    childrenByParentId = updatedMap,
                    loadingChildrenParentId = if (current.loadingChildrenParentId == cleanId) null else current.loadingChildrenParentId
                )
            }
        }
    }

    fun openRecordPreview(record: CivilRegistryRecord) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        previewChildrenJob?.cancel()

        val parentId = record.nationalId.trim()
        val cached = _uiState.value.childrenByParentId[parentId]
        if (cached != null) {
            _uiState.update {
                it.copy(
                    selectedRecordForPreview = record,
                    previewChildren = cached,
                    isLoadingPreviewChildren = false
                )
            }
            return
        }

        _uiState.update {
            it.copy(
                selectedRecordForPreview = record,
                previewChildren = emptyList(),
                isLoadingPreviewChildren = parentId.isNotEmpty()
            )
        }

        if (parentId.isEmpty()) return

        previewChildrenJob = viewModelScope.launch {
            val loaded = try {
                dataSource.getChildrenForParent(parentId)
            } catch (_: Throwable) {
                emptyList()
            }
            _uiState.update { current ->
                val updatedMap = LinkedHashMap(current.childrenByParentId)
                updatedMap[parentId] = loaded
                current.copy(
                    childrenByParentId = updatedMap,
                    previewChildren = if (current.selectedRecordForPreview?.nationalId?.trim() == parentId) loaded else current.previewChildren,
                    isLoadingPreviewChildren = false
                )
            }
        }
    }

    fun dismissRecordPreview() {
        previewChildrenJob?.cancel()
        _uiState.update {
            it.copy(
                selectedRecordForPreview = null,
                previewChildren = emptyList(),
                isLoadingPreviewChildren = false
            )
        }
    }

    /**
     * ترحيل سجل السجل المدني مع جميع أبنائه المرتبطين كمسودة غير محفوظة عبر الجسر المفصول إلى صفحة الإضافة
     */
    fun stageRecordForProjectAdd(
        record: CivilRegistryRecord,
        onReady: () -> Unit = {}
    ) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) return
        val parentId = record.nationalId.trim()
        val cached = _uiState.value.childrenByParentId[parentId]
        val hasChildrenTable = (_uiState.value.dbStatus as? CivilRegistryDbStatus.Ready)?.hasChildrenRegistry == true

        if (cached != null || parentId.isEmpty() || !hasChildrenTable) {
            CivilRegistryDraftBridge.stageDraft(record, cached.orEmpty())
            _uiState.update { it.copy(selectedRecordForPreview = null, isStagingTransfer = false) }
            onReady()
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isStagingTransfer = true) }
            val loadedChildren = try {
                dataSource.getChildrenForParent(parentId)
            } catch (_: Throwable) {
                emptyList()
            }
            CivilRegistryDraftBridge.stageDraft(record, loadedChildren)
            _uiState.update { current ->
                val updatedMap = LinkedHashMap(current.childrenByParentId)
                updatedMap[parentId] = loadedChildren
                current.copy(
                    childrenByParentId = updatedMap,
                    selectedRecordForPreview = null,
                    isStagingTransfer = false
                )
            }
            onReady()
        }
    }

    fun loadMoreResults() {
        val state = _uiState.value
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry() ||
            !state.canAccessCivilRegistry ||
            state.dbStatus !is CivilRegistryDbStatus.Ready ||
            state.isSearching ||
            state.isLoadingMore ||
            !state.hasMore ||
            !state.query.hasActiveCriteria
        ) {
            return
        }
        executeSearch(state.query, resetResults = false)
    }

    private fun updateQuery(transform: (CivilRegistrySearchQuery) -> CivilRegistrySearchQuery) {
        cancelInFlightSearch()
        val next = transform(_uiState.value.query)
        val hint = if (next.hasActiveCriteria) getMinCharsHint(next) else null
        _uiState.update {
            it.copy(
                query = next,
                minCharsHint = hint,
                errorMessage = null
            )
        }
        queryFlow.value = next
    }

    private fun getMinCharsHint(query: CivilRegistrySearchQuery): String? {
        if (query.advancedMode) return null
        val trimmed = query.quickQuery.trim()
        if (trimmed.isEmpty()) return null
        val asciiCompact = buildString(trimmed.length) {
            for (ch in trimmed) {
                when (ch) {
                    in '٠'..'٩' -> append(('0'.code + (ch.code - '٠'.code)).toChar())
                    in '۰'..'۹' -> append(('0'.code + (ch.code - '۰'.code)).toChar())
                    ' ', '-', '\t' -> Unit
                    else -> append(ch)
                }
            }
        }
        val isDigitsOnly = asciiCompact.isNotEmpty() && asciiCompact.all { it.isDigit() }
        return when {
            isDigitsOnly && asciiCompact.length < 2 ->
                "أدخل رقمين على الأقل للبحث الفوري برقم الهوية أو الجوال."
            !isDigitsOnly && trimmed.length < 3 ->
                "أدخل 3 أحرف على الأقل لبدء البحث الفوري السريع بالاسم."
            else -> null
        }
    }

    private fun observeDebouncedSearch() {
        viewModelScope.launch {
            queryFlow
                .debounce(350L)
                .distinctUntilChanged()
                .collect { nextQuery ->
                    val state = _uiState.value
                    if (!CivilRegistryPermissionGuard.canAccessCivilRegistry() ||
                        !state.canAccessCivilRegistry ||
                        state.dbStatus !is CivilRegistryDbStatus.Ready
                    ) {
                        return@collect
                    }
                    if (!nextQuery.hasActiveCriteria) {
                        cancelInFlightSearch()
                        _uiState.update {
                            it.copy(
                                results = emptyList(),
                                hasMore = false,
                                isSearching = false,
                                isLoadingMore = false,
                                hasSearchedOnce = false,
                                minCharsHint = null,
                                expandedCardParentIds = emptySet(),
                                matchedChildKeysByParentId = emptyMap(),
                                matchedChildNamesByParentId = emptyMap(),
                                errorMessage = null
                            )
                        }
                        return@collect
                    }

                    val hint = getMinCharsHint(nextQuery)
                    if (hint != null) {
                        cancelInFlightSearch()
                        _uiState.update {
                            it.copy(
                                results = emptyList(),
                                hasMore = false,
                                isSearching = false,
                                isLoadingMore = false,
                                hasSearchedOnce = false,
                                minCharsHint = hint,
                                expandedCardParentIds = emptySet(),
                                matchedChildKeysByParentId = emptyMap(),
                                matchedChildNamesByParentId = emptyMap(),
                                errorMessage = null
                            )
                        }
                        return@collect
                    }

                    executeSearch(nextQuery, resetResults = true)
                }
        }
    }

    private fun executeSearch(query: CivilRegistrySearchQuery, resetResults: Boolean) {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            cancelInFlightSearch()
            return
        }

        cancelInFlightSearch()
        val signal = CancellationSignal()
        activeCancellationSignal = signal

        val nextOffset = if (resetResults) 0 else _uiState.value.results.size

        activeSearchJob = viewModelScope.launch {
            _uiState.update {
                if (resetResults) {
                    it.copy(
                        isSearching = true,
                        isLoadingMore = false,
                        minCharsHint = null,
                        expandedCardParentIds = emptySet(),
                        matchedChildKeysByParentId = emptyMap(),
                        matchedChildNamesByParentId = emptyMap(),
                        errorMessage = null
                    )
                } else {
                    it.copy(isLoadingMore = true, errorMessage = null)
                }
            }
            try {
                val page = dataSource.search(
                    query = query,
                    offset = nextOffset,
                    pageSize = CivilRegistryReadOnlyDataSource.DEFAULT_PAGE_SIZE,
                    cancellationSignal = signal
                )
                _uiState.update { current ->
                    val mergedRecords = if (resetResults) {
                        page.records
                    } else {
                        val seenIds = HashSet<String>(current.results.size + page.records.size)
                        val deduped = ArrayList<CivilRegistryRecord>(current.results.size + page.records.size)
                        current.results.forEach { rec ->
                            val key = rec.nationalId.trim().ifBlank { rec.stableKey }
                            if (seenIds.add(key)) deduped.add(rec)
                        }
                        page.records.forEach { rec ->
                            val key = rec.nationalId.trim().ifBlank { rec.stableKey }
                            if (seenIds.add(key)) deduped.add(rec)
                        }
                        deduped
                    }

                    val updatedChildrenMap = LinkedHashMap(current.childrenByParentId)
                    page.preloadedChildrenByParentId.forEach { (parentId, kids) ->
                        if (parentId.isNotBlank()) {
                            if (updatedChildrenMap.size >= 120 && !updatedChildrenMap.containsKey(parentId)) {
                                val oldest = updatedChildrenMap.keys.firstOrNull()
                                if (oldest != null) updatedChildrenMap.remove(oldest)
                            }
                            updatedChildrenMap[parentId] = kids
                        }
                    }

                    val nextMatchedKeys = if (resetResults) {
                        page.matchedChildKeysByParentId
                    } else {
                        current.matchedChildKeysByParentId + page.matchedChildKeysByParentId
                    }

                    val nextMatchedNames = if (resetResults) {
                        page.matchedChildNamesByParentId
                    } else {
                        current.matchedChildNamesByParentId + page.matchedChildNamesByParentId
                    }

                    val autoExpanded = page.matchedChildKeysByParentId.keys
                        .filter { it.isNotBlank() }
                        .toSet()
                    val nextExpanded = if (resetResults) {
                        autoExpanded
                    } else {
                        current.expandedCardParentIds + autoExpanded
                    }

                    current.copy(
                        results = mergedRecords,
                        hasMore = page.hasMore,
                        isSearching = false,
                        isLoadingMore = false,
                        hasSearchedOnce = true,
                        minCharsHint = null,
                        childrenByParentId = updatedChildrenMap,
                        matchedChildKeysByParentId = nextMatchedKeys,
                        matchedChildNamesByParentId = nextMatchedNames,
                        expandedCardParentIds = nextExpanded,
                        errorMessage = null
                    )
                }
            } catch (_: OperationCanceledException) {
                // تم إلغاء الاستعلام السابق تلقائياً لأن المستخدم واصل الكتابة
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                _uiState.update {
                    it.copy(
                        isSearching = false,
                        isLoadingMore = false,
                        errorMessage = t.localizedMessage ?: "تعذر إتمام البحث في السجل المدني."
                    )
                }
            }
        }
    }

    private fun cancelInFlightSearch() {
        try {
            activeCancellationSignal?.cancel()
        } catch (_: Throwable) {
        }
        activeCancellationSignal = null
        activeSearchJob?.cancel()
        activeSearchJob = null
    }

    override fun onCleared() {
        cancelInFlightSearch()
        previewChildrenJob?.cancel()
        dataSource.close()
        super.onCleared()
    }

    class Factory(private val appContext: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return CivilRegistrySearchViewModel(
                CivilRegistryReadOnlyDataSource(appContext.applicationContext)
            ) as T
        }
    }
}
