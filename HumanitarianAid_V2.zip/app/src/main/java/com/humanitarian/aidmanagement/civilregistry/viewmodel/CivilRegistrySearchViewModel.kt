package com.humanitarian.aidmanagement.civilregistry.viewmodel

import android.content.Context
import android.net.Uri
import android.os.CancellationSignal
import android.os.OperationCanceledException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.civilregistry.bridge.CivilRegistryDraftBridge
import com.humanitarian.aidmanagement.civilregistry.data.CivilRegistryReadOnlyDataSource
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryDbStatus
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchScope
import com.humanitarian.aidmanagement.civilregistry.security.CivilRegistryPermissionGuard
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * ViewModel مفصول بالكامل لوحدة البحث في السجل المدني (Read-Only Lookup)
 * - يدير فحص الصلاحيات قبل أي استعلام
 * - يطبق Debounce ذكي (260ms) وإلغاء فوري للاستعلامات السابقة عبر CancellationSignal
 * - يدعم التحميل التدريجي (Incremental Pagination) بصفحات 40 سجل دون تجميد الواجهة
 */
@OptIn(FlowPreview::class)
class CivilRegistrySearchViewModel(
    private val dataSource: CivilRegistryReadOnlyDataSource
) : ViewModel() {

    data class UiState(
        val isAuthorized: Boolean = false,
        val denialReason: String? = null,
        val dbStatus: CivilRegistryDbStatus = CivilRegistryDbStatus.Checking,
        val isImportingDb: Boolean = false,
        val query: CivilRegistrySearchQuery = CivilRegistrySearchQuery(),
        val results: List<CivilRegistryRecord> = emptyList(),
        val isSearching: Boolean = false,
        val isLoadingMore: Boolean = false,
        val hasMore: Boolean = false,
        val hasSearchedOnce: Boolean = false,
        val errorMessage: String? = null,
        val selectedRecordForPreview: CivilRegistryRecord? = null
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val queryFlow = MutableStateFlow(CivilRegistrySearchQuery())
    private var activeSearchJob: Job? = null
    private var activeCancellationSignal: CancellationSignal? = null

    init {
        refreshPermissionsAndDatabase()
        observeDebouncedSearch()
    }

    fun refreshPermissionsAndDatabase() {
        val decision = CivilRegistryPermissionGuard.evaluate()
        _uiState.update {
            it.copy(
                isAuthorized = decision.isAllowed,
                denialReason = decision.denialReason
            )
        }
        if (!decision.isAllowed) {
            cancelInFlightSearch()
            _uiState.update {
                it.copy(
                    results = emptyList(),
                    hasMore = false,
                    isSearching = false,
                    isLoadingMore = false
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(dbStatus = CivilRegistryDbStatus.Checking, errorMessage = null) }
            val status = dataSource.ensureDatabaseReady()
            _uiState.update { it.copy(dbStatus = status) }
            if (status is CivilRegistryDbStatus.Ready && queryFlow.value.hasActiveCriteria) {
                executeSearch(queryFlow.value, resetResults = true)
            }
        }
    }

    fun importDatabaseFromUri(uri: Uri) {
        if (!_uiState.value.isAuthorized) return
        viewModelScope.launch {
            _uiState.update { it.copy(isImportingDb = true, errorMessage = null) }
            val status = dataSource.importExternalDatabase(uri)
            _uiState.update {
                it.copy(
                    isImportingDb = false,
                    dbStatus = status,
                    errorMessage = (status as? CivilRegistryDbStatus.Error)?.message
                )
            }
            if (status is CivilRegistryDbStatus.Ready && queryFlow.value.hasActiveCriteria) {
                executeSearch(queryFlow.value, resetResults = true)
            }
        }
    }

    fun onQuickQueryChange(value: String) {
        updateQuery { it.copy(quickQuery = value) }
    }

    fun onScopeSelected(scope: CivilRegistrySearchScope) {
        updateQuery { it.copy(scope = scope) }
    }

    fun toggleAdvancedMode() {
        updateQuery { it.copy(advancedMode = !it.advancedMode) }
    }

    fun onNameFilterChange(value: String) = updateQuery { it.copy(nameFilter = value) }
    fun onNationalIdFilterChange(value: String) = updateQuery { it.copy(nationalIdFilter = value) }
    fun onWifeNameFilterChange(value: String) = updateQuery { it.copy(wifeNameFilter = value) }
    fun onWifeNationalIdFilterChange(value: String) = updateQuery { it.copy(wifeNationalIdFilter = value) }
    fun onPhoneFilterChange(value: String) = updateQuery { it.copy(phoneFilter = value) }

    fun clearAllFilters() {
        cancelInFlightSearch()
        val cleared = CivilRegistrySearchQuery(advancedMode = _uiState.value.query.advancedMode)
        queryFlow.value = cleared
        _uiState.update {
            it.copy(
                query = cleared,
                results = emptyList(),
                hasMore = false,
                isSearching = false,
                isLoadingMore = false,
                hasSearchedOnce = false,
                errorMessage = null
            )
        }
    }

    fun openRecordPreview(record: CivilRegistryRecord) {
        if (!_uiState.value.isAuthorized) return
        _uiState.update { it.copy(selectedRecordForPreview = record) }
    }

    fun dismissRecordPreview() {
        _uiState.update { it.copy(selectedRecordForPreview = null) }
    }

    /**
     * ترحيل سجل السجل المدني كمسودة غير محفوظة عبر الجسر المفصول إلى صفحة الإضافة
     */
    fun stageRecordForProjectAdd(record: CivilRegistryRecord) {
        if (!_uiState.value.isAuthorized) return
        CivilRegistryDraftBridge.stageDraft(record)
        _uiState.update { it.copy(selectedRecordForPreview = null) }
    }

    fun loadMoreResults() {
        val state = _uiState.value
        if (!state.isAuthorized ||
            state.dbStatus !is CivilRegistryDbStatus.Ready ||
            state.isSearching ||
            state.isLoadingMore ||
            !state.hasMore ||
            !state.query.hasActiveCriteria
        ) {
            return
        }
        executeSearch(state.query, resetResults = false)
    }

    private fun updateQuery(transform: (CivilRegistrySearchQuery) -> CivilRegistrySearchQuery) {
        val next = transform(_uiState.value.query)
        _uiState.update { it.copy(query = next, errorMessage = null) }
        queryFlow.value = next
    }

    private fun observeDebouncedSearch() {
        viewModelScope.launch {
            queryFlow
                .debounce(260L)
                .distinctUntilChanged()
                .collect { nextQuery ->
                    val state = _uiState.value
                    if (!state.isAuthorized || state.dbStatus !is CivilRegistryDbStatus.Ready) {
                        return@collect
                    }
                    if (!nextQuery.hasActiveCriteria) {
                        cancelInFlightSearch()
                        _uiState.update {
                            it.copy(
                                results = emptyList(),
                                hasMore = false,
                                isSearching = false,
                                isLoadingMore = false,
                                hasSearchedOnce = false,
                                errorMessage = null
                            )
                        }
                        return@collect
                    }

                    // منع الاستعلام بحرف واحد فقط عند البحث النصي للحفاظ على الاستجابة اللحظية على 478k سجل
                    val trimmedQuick = nextQuery.quickQuery.trim()
                    if (!nextQuery.advancedMode && trimmedQuick.length < 2) {
                        cancelInFlightSearch()
                        _uiState.update {
                            it.copy(
                                results = emptyList(),
                                hasMore = false,
                                isSearching = false,
                                isLoadingMore = false,
                                hasSearchedOnce = false,
                                errorMessage = null
                            )
                        }
                        return@collect
                    }

                    executeSearch(nextQuery, resetResults = true)
                }
        }
    }

    private fun executeSearch(query: CivilRegistrySearchQuery, resetResults: Boolean) {
        cancelInFlightSearch()
        val signal = CancellationSignal()
        activeCancellationSignal = signal

        val nextOffset = if (resetResults) 0 else _uiState.value.results.size

        activeSearchJob = viewModelScope.launch {
            _uiState.update {
                if (resetResults) {
                    it.copy(isSearching = true, isLoadingMore = false, errorMessage = null)
                } else {
                    it.copy(isLoadingMore = true, errorMessage = null)
                }
            }
            try {
                val page = dataSource.search(
                    query = query,
                    offset = nextOffset,
                    pageSize = CivilRegistryReadOnlyDataSource.DEFAULT_PAGE_SIZE,
                    cancellationSignal = signal
                )
                _uiState.update { current ->
                    val merged = if (resetResults) {
                        page.records
                    } else {
                        current.results + page.records
                    }
                    current.copy(
                        results = merged,
                        hasMore = page.hasMore,
                        isSearching = false,
                        isLoadingMore = false,
                        hasSearchedOnce = true,
                        errorMessage = null
                    )
                }
            } catch (_: OperationCanceledException) {
                // تم إلغاء الاستعلام السابق تلقائياً لأن المستخدم واصل الكتابة
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                _uiState.update {
                    it.copy(
                        isSearching = false,
                        isLoadingMore = false,
                        errorMessage = t.localizedMessage ?: "تعذر إتمام البحث في السجل المدني."
                    )
                }
            }
        }
    }

    private fun cancelInFlightSearch() {
        try {
            activeCancellationSignal?.cancel()
        } catch (_: Throwable) {
        }
        activeCancellationSignal = null
        activeSearchJob?.cancel()
        activeSearchJob = null
    }

    override fun onCleared() {
        cancelInFlightSearch()
        dataSource.close()
        super.onCleared()
    }

    class Factory(private val appContext: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return CivilRegistrySearchViewModel(
                CivilRegistryReadOnlyDataSource(appContext.applicationContext)
            ) as T
        }
    }
}
