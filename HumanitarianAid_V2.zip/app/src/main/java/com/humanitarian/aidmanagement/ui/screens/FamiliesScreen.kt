package com.humanitarian.aidmanagement.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.Family
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamiliesScreen(
    repository: AidRepository,
    isSuperAdmin: Boolean,
    allowedLocalityIds: List<Int>,
    onOpenDrawer: () -> Unit,
    onFamilySelected: (Int) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var searchQuery by remember { mutableStateOf("") }
    var selectedLocalityId by remember { mutableStateOf<Int?>(null) }
    var selectedGender by remember { mutableStateOf<String?>(null) }
    var selectedMaritalStatus by remember { mutableStateOf<String?>(null) }
    var selectedResidentStatus by remember { mutableStateOf<String?>(null) }
    var selectedDevApproval by remember { mutableStateOf<String?>(null) }
    var selectedWorkApproval by remember { mutableStateOf<String?>(null) }
    var selectedShelterStatus by remember { mutableStateOf<String?>(null) }

    var showFilterSheet by remember { mutableStateOf(false) }
    var showAddDialog by remember { mutableStateOf(false) }

    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val families by repository.getFamiliesFiltered(
        isSuperAdmin = isSuperAdmin,
        allowedLocalityIds = allowedLocalityIds,
        query = searchQuery.trim(),
        localityId = selectedLocalityId,
        gender = selectedGender,
        maritalStatus = selectedMaritalStatus,
        residentStatus = selectedResidentStatus,
        devApproval = selectedDevApproval,
        workApproval = selectedWorkApproval,
        shelterStatus = selectedShelterStatus
    ).collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("بيانات الأسر (${families.size})", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "القائمة")
                    }
                },
                actions = {
                    IconButton(onClick = { showFilterSheet = true }) {
                        Badge(
                            containerColor = if (selectedLocalityId != null || selectedGender != null || selectedResidentStatus != null) Color(0xFFD97706) else Color.Transparent
                        ) {
                            Icon(Icons.Default.FilterList, contentDescription = "تصفية")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White,
                    actionIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = Color(0xFF2E7D32),
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة أسرة")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
        ) {
            // Search Bar (Name or National ID)
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("بحث باسم رب الأسرة أو رقم الهوية...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF1976D2)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )

            // Family List (LazyColumn for high performance)
            if (families.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.SearchOff, contentDescription = null, modifier = Modifier.size(64.dp), tint = Color(0xFF94A3B8))
                        Spacer(Modifier.height(8.dp))
                        Text("لا توجد أسر تطابق معايير البحث أو نطاقك الجغرافي", color = Color(0xFF64748B))
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(families, key = { it.familyID }) { family ->
                        val locName = localities.find { it.localityId == family.localityID }?.localityName ?: "محلية ${family.localityID}"
                        FamilyCard(
                            family = family,
                            localityName = locName,
                            onClick = { onFamilySelected(family.familyID) },
                            onDelete = {
                                scope.launch {
                                    val result = repository.deleteFamily(family, isSuperAdmin, allowedLocalityIds)
                                    result.onSuccess {
                                        Toast.makeText(context, "تم حذف الأسرة بنجاح", Toast.LENGTH_SHORT).show()
                                    }.onFailure { ex ->
                                        Toast.makeText(context, ex.message ?: "خطأ في الصلاحيات", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Filter Bottom Sheet (7 Filters)
    if (showFilterSheet) {
        ModalBottomSheet(onDismissRequest = { showFilterSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text("تصفية بيانات الأسر", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(16.dp))

                // Locality filter
                Text("المحلية:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = selectedLocalityId == null,
                        onClick = { selectedLocalityId = null },
                        label = { Text("الكل") }
                    )
                    localities.forEach { loc ->
                        if (isSuperAdmin || allowedLocalityIds.contains(loc.localityId)) {
                            FilterChip(
                                selected = selectedLocalityId == loc.localityId,
                                onClick = { selectedLocalityId = loc.localityId },
                                label = { Text(loc.localityName) }
                            )
                        }
                    }
                }

                // Resident status filter
                Spacer(Modifier.height(8.dp))
                Text("حالة الإقامة:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Row(modifier = Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = selectedResidentStatus == null, onClick = { selectedResidentStatus = null }, label = { Text("الكل") })
                    FilterChip(selected = selectedResidentStatus == "مقيم", onClick = { selectedResidentStatus = "مقيم" }, label = { Text("مقيم") })
                    FilterChip(selected = selectedResidentStatus == "نازح", onClick = { selectedResidentStatus = "نازح" }, label = { Text("نازح") })
                }

                // Development approval filter
                Spacer(Modifier.height(8.dp))
                Text("اعتماد التنمية:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Row(modifier = Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = selectedDevApproval == null, onClick = { selectedDevApproval = null }, label = { Text("الكل") })
                    FilterChip(selected = selectedDevApproval == "معتمد", onClick = { selectedDevApproval = "معتمد" }, label = { Text("معتمد") })
                    FilterChip(selected = selectedDevApproval == "غير معتمد", onClick = { selectedDevApproval = "غير معتمد" }, label = { Text("غير معتمد") })
                }

                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { showFilterSheet = false },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("تطبيق التصفية")
                }
            }
        }
    }

    // Add Family Dialog
    if (showAddDialog) {
        AddFamilyDialog(
            localities = localities.filter { isSuperAdmin || allowedLocalityIds.contains(it.localityId) },
            onDismiss = { showAddDialog = false },
            onSave = { newFamily ->
                scope.launch {
                    val result = repository.addFamily(newFamily, isSuperAdmin, allowedLocalityIds)
                    result.onSuccess {
                        Toast.makeText(context, "تمت إضافة الأسرة بنجاح", Toast.LENGTH_SHORT).show()
                        showAddDialog = false
                    }.onFailure { ex ->
                        Toast.makeText(context, ex.message ?: "خطأ", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
fun FamilyCard(
    family: Family,
    localityName: String,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = family.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color(0xFFDC2626), modifier = Modifier.size(20.dp))
                }
            }

            Spacer(Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("الهوية: ${family.nationalID}", fontSize = 12.sp, color = Color(0xFF475569))
                Text("الأفراد: ${family.familyMembersCount}", fontSize = 12.sp, color = Color(0xFF475569))
                Text("المحلية: $localityName", fontSize = 12.sp, color = Color(0xFF1976D2), fontWeight = FontWeight.SemiBold)
            }

            Spacer(Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StatusTag(label = family.residentStatus, color = if (family.residentStatus == "مقيم") Color(0xFF2E7D32) else Color(0xFFD97706))
                StatusTag(label = "تنمية: ${family.developmentApproval}", color = if (family.developmentApproval == "معتمد") Color(0xFF2E7D32) else Color(0xFF64748B))
                StatusTag(label = family.shelterStatus, color = Color(0xFF0284C7))
            }
        }
    }
}

@Composable
fun StatusTag(label: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = label,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFamilyDialog(
    localities: List<com.humanitarian.aidmanagement.data.local.entities.Locality>,
    onDismiss: () -> Unit,
    onSave: (Family) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var nationalID by remember { mutableStateOf("") }
    var membersCount by remember { mutableStateOf("5") }
    var residentStatus by remember { mutableStateOf("مقيم") }
    var shelterStatus by remember { mutableStateOf("إيواء داخلي") }
    var devApproval by remember { mutableStateOf("معتمد") }
    var workApproval by remember { mutableStateOf("معتمد أشغال") }
    var localityId by remember { mutableStateOf(localities.firstOrNull()?.localityId ?: 1) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة أسرة جديدة", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم رب الأسرة رباعي") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = nationalID,
                    onValueChange = { nationalID = it },
                    label = { Text("رقم الهوية (9 أرقام)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = membersCount,
                    onValueChange = { membersCount = it },
                    label = { Text("عدد أفراد الأسرة") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isBlank() || nationalID.isBlank()) return@Button
                    val family = Family(
                        name = name.trim(),
                        nationalID = nationalID.trim(),
                        birthDate = System.currentTimeMillis() - 30L * 365 * 24 * 3600 * 1000,
                        gender = "ذكر",
                        maritalStatus = "متزوج",
                        familyMembersCount = membersCount.toIntOrNull() ?: 1,
                        residentStatus = residentStatus,
                        shelterStatus = shelterStatus,
                        developmentApproval = devApproval,
                        workApproval = workApproval,
                        localityID = localityId
                    )
                    onSave(family)
                }
            ) {
                Text("حفظ الأسرة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}
