package com.humanitarian.aidmanagement.notifications

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.humanitarian.aidmanagement.MainActivity
import com.humanitarian.aidmanagement.R

object AidNotificationHelper {

    /**
     * إرسال إشعار محلي للتذكير بموعد توزيع إغاثي قادم
     */
    fun notifyUpcomingDistribution(
        context: Context,
        notificationId: Int,
        projectNumber: String,
        projectName: String,
        aidTypeName: String,
        distributionDate: String,
        warehouseName: String,
        beneficiariesCount: Int
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_NAVIGATE_TO", "distributions")
            putExtra("EXTRA_PROJECT_NUM", projectNumber)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val bigText = """
            📅 الموعد: $distributionDate
            📦 نوع المساعدة: $aidTypeName
            🏢 المستودع: $warehouseName
            👥 عدد المستفيدين المرشحين: $beneficiariesCount أسرة
            يرجى التأكد من تجهيز قوائم التسليم وسندات الصرف مسبقاً.
        """.trimIndent()

        val notification = NotificationCompat.Builder(
            context,
            AidNotificationChannels.CHANNEL_UPCOMING_DISTRIBUTIONS
        )
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("تذكير بموعد توزيع قادم: $projectName ($projectNumber)")
            .setContentText("موعد التوزيع: $distributionDate في مستودع $warehouseName ($beneficiariesCount أسرة)")
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_menu_agenda,
                "عرض جدول التوزيع",
                pendingIntent
            )
            .build()

        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (e: SecurityException) {
            // Permission check handled gracefully
        }
    }

    /**
     * إرسال إشعار محلي عند اقتراب انتهاء فترة استثناء أحد المرشحين
     */
    fun notifyExclusionExpiring(
        context: Context,
        notificationId: Int,
        familyName: String,
        nationalId: String,
        aidTypeName: String,
        remainingDays: Int,
        expirationDate: String
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_NAVIGATE_TO", "nomination")
            putExtra("EXTRA_SEARCH_FAMILY", nationalId)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (remainingDays <= 0) {
            "✅ انتهاء فترة الاستثناء: $familyName"
        } else {
            "⏳ اقتراب انتهاء استثناء: $familyName ($remainingDays أيام متبقية)"
        }

        val contentText = if (remainingDays <= 0) {
            "انتهت رسمياً فترة حظر الاستفادة لتصنيف ($aidTypeName) وأصبحت الأسرة مؤهلة للترشيح الفوري."
        } else {
            "تنتهي فترة الاستثناء لتصنيف ($aidTypeName) بتاريخ $expirationDate. ستصبح الأسرة مؤهلة بعد $remainingDays أيام."
        }

        val bigText = """
            👤 الأسرة: $familyName (هوية: $nationalId)
            🏷️ تصنيف المساعدة: $aidTypeName
            📅 تاريخ انتهاء الاستثناء: $expirationDate
            💡 الأثر: بمجرد انتهاء التاريخ المحدد، ستدخل الأسرة تلقائياً ضمن مفاضلة الترشيح الآلي وحساب نقاط الأولوية.
        """.trimIndent()

        val notification = NotificationCompat.Builder(
            context,
            AidNotificationChannels.CHANNEL_EXCLUSION_EXPIRING
        )
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText(contentText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_input_add,
                "إدراج بالترشيح الآن",
                pendingIntent
            )
            .build()

        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (e: SecurityException) {
            // Permission check handled gracefully
        }
    }

    /**
     * إرسال إشعار ترحيل واعتماد مرشحين بنجاح
     */
    fun notifyDispatchCompleted(
        context: Context,
        notificationId: Int,
        projectNumber: String,
        aidTypeName: String,
        count: Int,
        warehouse: String
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_NAVIGATE_TO", "nomination_results")
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(
            context,
            AidNotificationChannels.CHANNEL_URGENT_ALERTS
        )
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("✅ تم ترحيل واعتماد $count مرشحاً لمشروع ($projectNumber)")
            .setContentText("تم تسجيل القيود في قاعدة البيانات لمستودع $warehouse وتحديث فترات الاستثناء بنجاح.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (e: SecurityException) {
            // Permission handled
        }
    }

    /**
     * إرسال إشعار للمستخدمين والفرق الميدانية بطرح مشروع إغاثي جديد للترشيح ضمن الموعد والحصص المحددة
     */
    fun notifyProjectLaunched(
        context: Context,
        notificationId: Int,
        projectNumber: String,
        projectName: String,
        aidTypeName: String,
        targetCount: Int,
        deadline: String,
        quotasSummary: String
    ) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("EXTRA_NAVIGATE_TO", "nomination")
            putExtra("EXTRA_PROJECT_NUM", projectNumber)
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val bigText = """
            📢 أطلق المدير العام مشروعاً إغاثياً جديداً:
            📦 المشروع: $projectName ($projectNumber)
            🏷️ تصنيف المعونة: $aidTypeName
            👥 الحصة الإجمالية: $targetCount أسرة
            📅 الموعد النهائي للترشيح: $deadline
            📊 توزيع الحصص الرسمية للمناطق:
            $quotasSummary
            يرجى من كافة الباحثين الميدانيين البدء بالترشيح والالتزام بالمعايير والحصص المقررة.
        """.trimIndent()

        val notification = NotificationCompat.Builder(
            context,
            AidNotificationChannels.CHANNEL_URGENT_ALERTS
        )
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("📢 طرح مشروع جديد: $projectName ($targetCount حصة)")
            .setContentText("الموعد المحدد للترشيح: $deadline • ضمن حصص المناطق الرسمية")
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_input_add,
                "فتح شاشة الترشيح",
                pendingIntent
            )
            .build()

        try {
            NotificationManagerCompat.from(context).notify(notificationId, notification)
        } catch (e: SecurityException) {
            // Permission handled
        }
    }
}
