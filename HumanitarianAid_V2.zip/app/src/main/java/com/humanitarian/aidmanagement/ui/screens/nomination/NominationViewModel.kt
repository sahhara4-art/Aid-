package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.CandidateStatus
import com.humanitarian.aidmanagement.engine.DynamicCandidateModel
import com.humanitarian.aidmanagement.engine.DynamicNominationCriteria
import com.humanitarian.aidmanagement.engine.DynamicNominationResult
import com.humanitarian.aidmanagement.engine.ExclusionMode
import com.humanitarian.aidmanagement.engine.LocalityQuota
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * خصائص ملحقة بـ FamilyEntity لضمان توافق شروط الأهلية الصارمة دون المساس بـ 42 حقلاً الأصلية
 */
val FamilyEntity.socialAffairsStatus: String get() = developmentApproval
val FamilyEntity.residencyStatus: String get() = residentStatus

/**
 * ViewModel مخصص لشاشة الترشيح ومحرك القواعد الذكي
 * يقوم برفع كافة حالات الفلاتر (State Hoisting) كـ MutableStateFlow لضمان بقائها 100% عند التنقل والعودة
 */
class NominationViewModel(
    val repository: AidRepository
) : ViewModel() {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    // ==========================================
    // 1. القوائم المرجعية الديناميكية المعتمدة على قاعدة البيانات
    // ==========================================
    val localities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { list ->
            val clean = list.filter { it.isNotBlank() }
            if (clean.isEmpty()) emptyList() else listOf("الكل") + clean
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pureLocalities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { list -> list.filter { it.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val pureAidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { list -> list.filter { it.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val shelterStatuses: StateFlow<List<String>> = repository.getDistinctShelterStatusesFlow()
        .map { list ->
            val cleaned = list.filter { it.isNotBlank() }
            val withUnclassified = if (!cleaned.contains("بدون تصنيف")) cleaned + "بدون تصنيف" else cleaned
            listOf("الكل") + withUnclassified
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val worksApprovals: StateFlow<List<String>> = repository.getDistinctWorksApprovalsFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val residentStatuses: StateFlow<List<String>> = repository.getDistinctResidentStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val maritalStatuses: StateFlow<List<String>> = flow {
        emit(listOf("الكل") + repository.getDynamicFilterOptions().maritalStatuses)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val incomeSources: StateFlow<List<String>> = flow {
        emit(listOf("الكل") + repository.getDynamicFilterOptions().incomeSources)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val injuryStatuses: StateFlow<List<String>> = flow {
        emit(listOf("الكل") + repository.getDynamicFilterOptions().injuryStatuses)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val subAreas: StateFlow<List<String>> = flow {
        emit(listOf("الكل") + repository.getDynamicFilterOptions().subAreas)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val activeProjects: StateFlow<List<ProjectEntity>> = repository.getActiveProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAidTypes: StateFlow<List<AidTypeEntity>> = repository.getActiveAidTypes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dbLocalities: StateFlow<List<LocalityEntity>> = repository.getLocalities()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ==========================================
    // 2. حالات الفلاتر المرفوعة (Hoisted Filter States)
    // ==========================================
    val selectedLocalities = MutableStateFlow<Set<String>>(emptySet())
    val excludeLocalities = MutableStateFlow(false)

    val selectedAidCategories = MutableStateFlow<Set<String>>(emptySet())
    val excludeAidCategories = MutableStateFlow(true) // استثناء افتراضياً لمن استلم المعونة المحددة

    val exclusionMode = MutableStateFlow(ExclusionMode.DAYS)
    val exclusionDaysText = MutableStateFlow("30")
    val exclusionDateCutoffText = MutableStateFlow("")

    val hasChildrenOnly = MutableStateFlow(false)
    val minChildAgeText = MutableStateFlow("0")
    val maxChildAgeText = MutableStateFlow("18")

    val selectedDamageTypes = MutableStateFlow<Set<String>>(emptySet())
    val excludeDamageTypes = MutableStateFlow(false)

    val selectedMaritalStatuses = MutableStateFlow<Set<String>>(emptySet())
    val excludeMaritalStatuses = MutableStateFlow(false)

    val selectedWorksApprovals = MutableStateFlow<Set<String>>(emptySet())
    val excludeWorksApprovals = MutableStateFlow(false)

    val selectedShelterStatuses = MutableStateFlow<Set<String>>(emptySet())
    val excludeShelterStatuses = MutableStateFlow(false)

    val selectedIncomeSources = MutableStateFlow<Set<String>>(emptySet())
    val excludeIncomeSources = MutableStateFlow(false)

    val selectedInjuryStatuses = MutableStateFlow<Set<String>>(emptySet())
    val excludeInjuryStatuses = MutableStateFlow(false)

    val selectedSubAreas = MutableStateFlow<Set<String>>(emptySet())
    val excludeSubAreas = MutableStateFlow(false)

    val selectedLocalityId = MutableStateFlow(0) // 0 = كافة المحليات
    val excludeLocality = MutableStateFlow(false)

    val selectedProjectId = MutableStateFlow(1L)
    val selectedAidTypeId = MutableStateFlow(1)
    val targetBeneficiariesText = MutableStateFlow("100")
    val resultLimitText = MutableStateFlow("300")
    val minFamilyMembers = MutableStateFlow(1)

    val searchQuery = MutableStateFlow("")
    val statusFilterTab = MutableStateFlow<CandidateStatus?>(null)
    val customLocalityQuotas = MutableStateFlow<Map<String, String>>(emptyMap())

    // ==========================================
    // 3. نتائج المحرك والأسر المطابقة الصافية (Engine Results)
    // ==========================================
    val isFiltering = MutableStateFlow(false)
    val dynamicNominationResult = MutableStateFlow<DynamicNominationResult?>(null)
    val calculatedQuotas = MutableStateFlow<List<LocalityQuota>>(emptyList())

    // قائمة الأسر المؤهلة الصافية التي اجتازت شروط المحرك الصارمة بالكامل
    val filteredEligibleFamilies = MutableStateFlow<List<FamilyEntity>>(emptyList())

    init {
        // تشغيل أولي لحساب الحصص والفلترة عند بدء الـ ViewModel
        viewModelScope.launch {
            val target = targetBeneficiariesText.value.toIntOrNull() ?: 100
            calculatedQuotas.value = repository.calculateDynamicLocalityQuotas(target)
            runFilteringEngine()
        }
    }

    // ==========================================
    // 4. وظائف تحديث الفلاتر والتبديل (Toggle Helpers)
    // ==========================================
    fun toggleLocality(localityName: String) {
        val current = selectedLocalities.value.toMutableSet()
        if (current.contains(localityName)) current.remove(localityName) else current.add(localityName)
        selectedLocalities.value = current
    }

    fun toggleLocalityExclude(exclude: Boolean) {
        excludeLocalities.value = exclude
    }

    fun toggleCategory(categoryName: String) {
        val current = selectedAidCategories.value.toMutableSet()
        if (current.contains(categoryName)) current.remove(categoryName) else current.add(categoryName)
        selectedAidCategories.value = current
    }

    fun toggleCategoryExclude(exclude: Boolean) {
        excludeAidCategories.value = exclude
    }

    fun toggleDamageType(type: String) {
        val current = selectedDamageTypes.value.toMutableSet()
        if (current.contains(type)) current.remove(type) else current.add(type)
        selectedDamageTypes.value = current
    }

    fun toggleShelterStatus(status: String) {
        val current = selectedShelterStatuses.value.toMutableSet()
        if (current.contains(status)) current.remove(status) else current.add(status)
        selectedShelterStatuses.value = current
    }

    fun toggleWorksApproval(approval: String) {
        val current = selectedWorksApprovals.value.toMutableSet()
        if (current.contains(approval)) current.remove(approval) else current.add(approval)
        selectedWorksApprovals.value = current
    }

    fun toggleMaritalStatus(status: String) {
        val current = selectedMaritalStatuses.value.toMutableSet()
        if (current.contains(status)) current.remove(status) else current.add(status)
        selectedMaritalStatuses.value = current
    }

    fun toggleIncomeSource(source: String) {
        val current = selectedIncomeSources.value.toMutableSet()
        if (current.contains(source)) current.remove(source) else current.add(source)
        selectedIncomeSources.value = current
    }

    fun toggleSubArea(subArea: String) {
        val current = selectedSubAreas.value.toMutableSet()
        if (current.contains(subArea)) current.remove(subArea) else current.add(subArea)
        selectedSubAreas.value = current
    }

    fun toggleInjuryStatus(status: String) {
        val current = selectedInjuryStatuses.value.toMutableSet()
        if (current.contains(status)) current.remove(status) else current.add(status)
        selectedInjuryStatuses.value = current
    }

    fun clearLocalities() { selectedLocalities.value = emptySet() }
    fun clearCategories() { selectedAidCategories.value = emptySet() }
    fun clearDamageTypes() { selectedDamageTypes.value = emptySet() }
    fun clearShelterStatuses() { selectedShelterStatuses.value = emptySet() }
    fun clearWorksApprovals() { selectedWorksApprovals.value = emptySet() }
    fun clearMaritalStatuses() { selectedMaritalStatuses.value = emptySet() }
    fun clearIncomeSources() { selectedIncomeSources.value = emptySet() }
    fun clearInjuryStatuses() { selectedInjuryStatuses.value = emptySet() }
    fun clearSubAreas() { selectedSubAreas.value = emptySet() }

    fun resetFilters() {
        selectedLocalities.value = emptySet()
        excludeLocalities.value = false
        selectedAidCategories.value = emptySet()
        excludeAidCategories.value = true
        exclusionMode.value = ExclusionMode.DAYS
        exclusionDaysText.value = "30"
        exclusionDateCutoffText.value = ""
        hasChildrenOnly.value = false
        selectedDamageTypes.value = emptySet()
        excludeDamageTypes.value = false
        selectedMaritalStatuses.value = emptySet()
        excludeMaritalStatuses.value = false
        selectedWorksApprovals.value = emptySet()
        excludeWorksApprovals.value = false
        selectedShelterStatuses.value = emptySet()
        excludeShelterStatuses.value = false
        selectedIncomeSources.value = emptySet()
        excludeIncomeSources.value = false
        selectedInjuryStatuses.value = emptySet()
        excludeInjuryStatuses.value = false
        selectedSubAreas.value = emptySet()
        excludeSubAreas.value = false
        selectedLocalityId.value = 0
        minFamilyMembers.value = 1
        searchQuery.value = ""
        statusFilterTab.value = null
        runFilteringEngine()
    }

    // ==========================================
    // 5. محرك الفلترة الصارم (Ironclad Dynamic Filtering Engine)
    // ==========================================
    fun runFilteringEngine() {
        viewModelScope.launch {
            isFiltering.value = true
            try {
                withContext(Dispatchers.IO) {
                    val target = targetBeneficiariesText.value.toIntOrNull() ?: 100
                    val exclDays = exclusionDaysText.value.toIntOrNull()
                    val minAge = minChildAgeText.value.toIntOrNull()
                    val maxAge = maxChildAgeText.value.toIntOrNull()
                    val limit = resultLimitText.value.toIntOrNull() ?: 300

                    val allFamilies = repository.getAllFamiliesSync()
                    val allAidRecords = repository.getAllAidRecordsSync()
                    val allAidTypes = repository.getActiveAidTypes().first().associateBy { it.aidTypeID }
                    val localitiesMap = repository.getLocalities().first().associate { it.LocalityID to it.LocalityName }

                    // بناء استعلام محرك الترشيح المباشر
                    val criteria = DynamicNominationCriteria(
                        exclusionMode = exclusionMode.value,
                        exclusionDays = if (exclusionMode.value == ExclusionMode.DAYS && exclDays != null && exclDays > 0) exclDays else null,
                        exclusionDateCutoff = if (exclusionMode.value == ExclusionMode.DATE) exclusionDateCutoffText.value.trim() else null,
                        excludedAidTypeIds = if (excludeAidCategories.value) {
                            allAidTypes.values.filter { selectedAidCategories.value.contains(it.aidTypeName) }.map { it.aidTypeID }.toSet()
                        } else emptySet(),
                        hasChildrenOnly = hasChildrenOnly.value,
                        minChildAge = if (hasChildrenOnly.value) minAge else null,
                        maxChildAge = if (hasChildrenOnly.value) maxAge else null,
                        selectedDamageTypes = selectedDamageTypes.value,
                        excludeDamageTypes = excludeDamageTypes.value,
                        selectedMaritalStatuses = selectedMaritalStatuses.value,
                        excludeMaritalStatuses = excludeMaritalStatuses.value,
                        selectedWorksApprovals = selectedWorksApprovals.value,
                        excludeWorksApprovals = excludeWorksApprovals.value,
                        selectedShelterStatuses = selectedShelterStatuses.value,
                        excludeShelterStatuses = excludeShelterStatuses.value,
                        selectedIncomeSources = selectedIncomeSources.value,
                        excludeIncomeSources = excludeIncomeSources.value,
                        selectedInjuryStatuses = selectedInjuryStatuses.value,
                        excludeInjuryStatuses = excludeInjuryStatuses.value,
                        selectedSubAreas = selectedSubAreas.value,
                        excludeSubAreas = excludeSubAreas.value,
                        selectedLocalityId = if (selectedLocalityId.value > 0) selectedLocalityId.value else null,
                        excludeLocality = excludeLocality.value,
                        selectedAidTypeId = selectedAidTypeId.value,
                        projectId = selectedProjectId.value,
                        limit = limit,
                        targetBeneficiaries = target
                    )

                    // 1. تشغيل المحرك الديناميكي لحساب إحصاءات المطابقة والحصص
                    val dynamicResult = repository.runDynamicNomination(criteria)
                    dynamicNominationResult.value = dynamicResult
                    calculatedQuotas.value = repository.calculateDynamicLocalityQuotas(target)

                    // 2. تطبيق خوارزمية الفلترة الصارمة (Strict Kotlin Sequences)
                    // لتوليد قائمة الأسر المتوافقة 100% مع الشروط وترتيبها حسب حجم الأسرة تنازلياً
                    val eligible = executeStrictSequenceFiltering(
                        families = allFamilies,
                        aidRecords = allAidRecords,
                        aidTypesMap = allAidTypes,
                        localitiesMap = localitiesMap,
                        selectedLocalities = selectedLocalities.value,
                        excludeLocalities = excludeLocalities.value,
                        selectedCategories = selectedAidCategories.value,
                        excludeCategories = excludeAidCategories.value,
                        exclusionMode = exclusionMode.value,
                        exclusionDays = exclDays,
                        exclusionDateCutoff = exclusionDateCutoffText.value.trim(),
                        selectedDamageTypes = selectedDamageTypes.value,
                        excludeDamageTypes = excludeDamageTypes.value,
                        selectedShelterStatuses = selectedShelterStatuses.value,
                        excludeShelterStatuses = excludeShelterStatuses.value,
                        selectedWorksApprovals = selectedWorksApprovals.value,
                        excludeWorksApprovals = excludeWorksApprovals.value,
                        selectedMaritalStatuses = selectedMaritalStatuses.value,
                        excludeMaritalStatuses = excludeMaritalStatuses.value,
                        selectedIncomeSources = selectedIncomeSources.value,
                        excludeIncomeSources = excludeIncomeSources.value,
                        hasChildrenOnly = hasChildrenOnly.value,
                        minFamilyMembers = minFamilyMembers.value,
                        projectId = selectedProjectId.value
                    )

                    filteredEligibleFamilies.value = eligible
                }
            } catch (e: Exception) {
                android.util.Log.e("NominationViewModel", "runFilteringEngine error: ${e.message}", e)
            } finally {
                isFiltering.value = false
            }
        }
    }

    /**
     * تنفيذ الفلترة الصارمة عبر تسلسلات كوتلين (Kotlin Sequences)
     * تلبي حرفياً المعايير الصارمة:
     * 1. Hardcoded Mandatories:
     *    family.socialAffairsStatus == "معتمد" && family.residencyStatus == "مقيم"
     * 2. Dynamic Locality & Category:
     *    الفلترة الديناميكية الدقيقة. وإذا كان التصنيف مستثنى (Exclude)، يتم استبعاد أي أسرة يتضمن تاريخ مساعداتها هذا التصنيف خلال حد الاستثناء الزمني.
     * 3. Priority Sorting:
     *    الترتيب الإلزامي حسب حجم الأسرة (الأكبر أولاً):
     *    .sortedByDescending { it.familyMembersCount }
     */
    private fun executeStrictSequenceFiltering(
        families: List<FamilyEntity>,
        aidRecords: List<AidRecordEntity>,
        aidTypesMap: Map<Int, AidTypeEntity>,
        localitiesMap: Map<Int, String>,
        selectedLocalities: Set<String>,
        excludeLocalities: Boolean,
        selectedCategories: Set<String>,
        excludeCategories: Boolean,
        exclusionMode: ExclusionMode,
        exclusionDays: Int?,
        exclusionDateCutoff: String,
        selectedDamageTypes: Set<String>,
        excludeDamageTypes: Boolean,
        selectedShelterStatuses: Set<String>,
        excludeShelterStatuses: Boolean,
        selectedWorksApprovals: Set<String>,
        excludeWorksApprovals: Boolean,
        selectedMaritalStatuses: Set<String>,
        excludeMaritalStatuses: Boolean,
        selectedIncomeSources: Set<String>,
        excludeIncomeSources: Boolean,
        hasChildrenOnly: Boolean,
        minFamilyMembers: Int,
        projectId: Long
    ): List<FamilyEntity> {
        val now = System.currentTimeMillis()
        val cutoffMillis: Long? = when (exclusionMode) {
            ExclusionMode.DAYS -> {
                if (exclusionDays != null && exclusionDays > 0) {
                    now - (exclusionDays.toLong() * 24L * 60L * 60L * 1000L)
                } else null
            }
            ExclusionMode.DATE -> {
                if (exclusionDateCutoff.isNotBlank()) {
                    try { dateFormat.parse(exclusionDateCutoff)?.time } catch (_: Exception) { null }
                } else null
            }
        }

        val recordsByFamily = aidRecords.groupBy { it.familyID }

        return families.asSequence()
            // 1. الشروط الإلزامية التي لا يمكن تجاوزها قط:
            // family.socialAffairsStatus == "معتمد" && family.residencyStatus == "مقيم"
            .filter { family ->
                val isSocialApproved = family.socialAffairsStatus == "معتمد" || family.socialAffairsStatus.contains("معتمد")
                val isResident = family.residencyStatus == "مقيم" || family.residencyStatus.contains("مقيم")
                isSocialApproved && isResident
            }
            // استبعاد من استلم أو رُشح لنفس المشروع لمنع الازدواجية
            .filter { family ->
                if (projectId > 0) {
                    val fRecords = recordsByFamily[family.familyID] ?: emptyList()
                    fRecords.none { it.projectID == projectId }
                } else true
            }
            // 2. الفلترة الجغرافية بالاعتماد الصارم على المنطقة الفرعية الحالية (المحلية المعتمدة)
            .filter { family ->
                val locName = family.currentSubArea.ifBlank { localitiesMap[family.localityID] ?: family.currentMainArea }
                if (selectedLocalities.isEmpty() || selectedLocalities.contains("الكل")) {
                    true
                } else {
                    val matches = selectedLocalities.contains(family.currentSubArea) || selectedLocalities.contains(locName)
                    if (excludeLocalities) !matches else matches
                }
            }
            // 2. الفلترة الديناميكية لتصنيفات المساعدات وتاريخ الاستفادة (Dynamic Category & Aid History)
            .filter { family ->
                if (selectedCategories.isEmpty() || selectedCategories.contains("الكل")) {
                    true
                } else {
                    val fRecords = recordsByFamily[family.familyID] ?: emptyList()
                    // استخراج التصنيفات التي استلمتها الأسرة خلال النافذة الزمنية المحددة
                    val receivedCategoriesWithinThreshold = fRecords.asSequence()
                        .filter { record ->
                            val dateStr = record.deliveryDate ?: record.aidDate
                            val recTime = try { dateFormat.parse(dateStr)?.time } catch (_: Exception) { null }
                            if (cutoffMillis != null && recTime != null) {
                                recTime >= cutoffMillis
                            } else true
                        }
                        .mapNotNull { record -> aidTypesMap[record.aidTypeID]?.aidTypeName }
                        .toSet()

                    val hasReceivedAny = selectedCategories.any { cat ->
                        receivedCategoriesWithinThreshold.contains(cat)
                    }

                    if (excludeCategories) {
                        // استثناء أي أسرة استلمت أياً من التصنيفات المحددة خلال المدة
                        !hasReceivedAny
                    } else {
                        // تضمين فقط من يطابق
                        hasReceivedAny
                    }
                }
            }
            // فلتر حالة الضرر
            .filter { family ->
                if (selectedDamageTypes.isEmpty() || selectedDamageTypes.contains("الكل")) true
                else {
                    val matches = selectedDamageTypes.contains(family.damageType)
                    if (excludeDamageTypes) !matches else matches
                }
            }
            // فلتر حالة الإيواء
            .filter { family ->
                if (selectedShelterStatuses.isEmpty() || selectedShelterStatuses.contains("الكل")) true
                else {
                    val matches = selectedShelterStatuses.contains(family.shelterStatus) ||
                            (selectedShelterStatuses.contains("بدون تصنيف") && (family.shelterStatus.isBlank() || family.shelterStatus == "بدون تصنيف"))
                    if (excludeShelterStatuses) !matches else matches
                }
            }
            // فلتر اعتماد الأشغال
            .filter { family ->
                if (selectedWorksApprovals.isEmpty() || selectedWorksApprovals.contains("الكل")) true
                else {
                    val matches = selectedWorksApprovals.contains(family.worksApproval)
                    if (excludeWorksApprovals) !matches else matches
                }
            }
            // فلتر الحالة الاجتماعية
            .filter { family ->
                if (selectedMaritalStatuses.isEmpty() || selectedMaritalStatuses.contains("الكل")) true
                else {
                    val matches = selectedMaritalStatuses.contains(family.maritalStatus)
                    if (excludeMaritalStatuses) !matches else matches
                }
            }
            // فلتر مصدر الدخل
            .filter { family ->
                if (selectedIncomeSources.isEmpty() || selectedIncomeSources.contains("الكل")) true
                else {
                    val matches = selectedIncomeSources.contains(family.incomeSource1)
                    if (excludeIncomeSources) !matches else matches
                }
            }
            // الحد الأدنى لعدد أفراد الأسرة
            .filter { family ->
                family.familyMembersCount >= minFamilyMembers
            }
            // 3. الترتيب الأولوية الإلزامي (Priority Sorting): الأكبر حجماً أولاً
            .sortedByDescending { it.familyMembersCount }
            .toList()
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NominationViewModel(repository) as T
        }
    }
}
