package com.humanitarian.aidmanagement.ui.screens.nomination

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyComplaintEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.local.entities.donor
import com.humanitarian.aidmanagement.data.local.entities.isOpen
import com.humanitarian.aidmanagement.data.local.entities.residencyStatus
import com.humanitarian.aidmanagement.data.local.entities.socialAffairsStatus
import com.humanitarian.aidmanagement.data.local.entities.targetQuota
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.CandidateStatus
import com.humanitarian.aidmanagement.engine.DynamicCandidateModel
import com.humanitarian.aidmanagement.engine.DynamicNominationCriteria
import com.humanitarian.aidmanagement.engine.DynamicNominationResult
import com.humanitarian.aidmanagement.engine.ExclusionMode
import com.humanitarian.aidmanagement.engine.LocalityQuota
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.util.AidCategoryCatalog
import com.humanitarian.aidmanagement.util.ExcelNominationFeedback
import com.humanitarian.aidmanagement.util.ExcelNominationResult
import com.humanitarian.aidmanagement.util.ExcelPriorityNominationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * حالة شريحة الفلترة متعددة الحالات (Multi-State FilterChip)
 * 3 حالات: غير محدد، متضمن (أخضر)، مستثنى (أحمر)
 */
enum class ChipFilterState {
    UNSELECTED,
    INCLUDED, // تضمين (Checkmark)
    EXCLUDED  // استثناء (Cross)
}

/**
 * إحصائية حصة المحلية المعتمدة والترشيح الفعلي والعجز/الفائض
 */
data class LocalityQuotaStatsItem(
    val localityName: String,
    val baseX: Int,
    val totalBase: Int,
    val percentage: Double,
    val targetQuota: Int,
    val nominatedCount: Int
) {
    val shortageExcess: Int get() = nominatedCount - targetQuota
    val isComplete: Boolean get() = nominatedCount >= targetQuota && targetQuota > 0
    val formattedPercentage: String get() = String.format(Locale.US, "%.1f%%", percentage)
}

/**
 * MASTER ARCHITECTURE V3.0: THE ULTIMATE HYBRID NOMINATION VIEWMODEL
 * يدمج إدارة الوصول الجغرافي (RBAC)، الحسابات الرياضية للتوزيع النسبي،
 * وفلاتر الشرائح ثلاثية الحالات والاختيار الهجين المحمي بالأقفال.
 */
class NominationViewModel(
    val repository: AidRepository,
    initialAssignedSubRegion: String = "All"
) : ViewModel() {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    // ==========================================
    // MODULE 2: GEOGRAPHICAL RBAC (المنطقة المخصصة)
    // ==========================================
    val assignedSubRegion = MutableStateFlow(initialAssignedSubRegion)

    fun setAssignedSubRegion(region: String) {
        assignedSubRegion.value = region.ifBlank { "All" }
    }

    // ==========================================
    // تدفقات قاعدة البيانات والمشاريع
    // ==========================================
    val allActiveProjects: StateFlow<List<ProjectEntity>> = repository.getActiveProjects()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Step 1: المشاريع المفتوحة حصراً للترشيح (isOpen == true)
    val openProjects: StateFlow<List<ProjectEntity>> = repository.getActiveProjects()
        .map { list -> list.filter { it.isOpen } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAidTypes: StateFlow<List<AidTypeEntity>> = repository.getActiveAidTypes()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dbLocalities: StateFlow<List<LocalityEntity>> = repository.getLocalities()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * تدفق السجلات ذات حالة 'مرشح' التي تنتظر الترحيل والاعتماد الرسمي (تفاعلي من Room)
     */
    val nominatedRecords: StateFlow<List<AidRecordEntity>> = repository.getNominatedRecordsForProjectFlow(0L)
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // المشروع المختار حالياً + الأسر المختارة في المسودة الحالية
    val selectedProject = MutableStateFlow<ProjectEntity?>(null)
    val selectedProjectId = MutableStateFlow(1L)
    val selectedAidTypeId = MutableStateFlow(1)
    val targetBeneficiariesText = MutableStateFlow("100")
    val resultLimitText = MutableStateFlow("300")
    val selectedNominees = MutableStateFlow<Set<FamilyEntity>>(emptySet())
    private val _priorityNomineeSources = MutableStateFlow<Map<Long, String>>(emptyMap())
    val priorityNomineeSources: StateFlow<Map<Long, String>> = _priorityNomineeSources.asStateFlow()

    // ==========================================
    // MODULE 3: PROPORTIONAL DISTRIBUTION MATH (التوزيع النسبي)
    // القاعدة الرياضية: اعتماد التنمية = "معتمد" مع صفة الإقامة المختارة (أو "مقيم" افتراضياً)
    // ==========================================
    val selectedResidencyStatus = MutableStateFlow<String?>(null)

    fun setSelectedResidencyStatus(status: String?) {
        selectedResidencyStatus.value = status?.trim()?.takeIf { it.isNotBlank() }
    }

    // شرط التفعيل الحصري الوحيد: يعتمد حصراً على اختيار صفة الإقامة فقط دون أي حقل آخر
    val isSubmitEnabled: StateFlow<Boolean> = selectedResidencyStatus
        .map { !it.isNullOrBlank() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // ==========================================
    // MODULE 2.5: MICRO-RBAC GEO-FENCING & SCOPED QUOTA ISOLATION
    // ==========================================
    val isGeoRestrictedUser: StateFlow<Boolean> = repository.currentUserFlow
        .map { user ->
            user != null && AccessControlManager.isGeoRestrictedUser()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val effectiveUserRegion: StateFlow<String> = repository.currentUserFlow
        .map { AccessControlManager.effectiveSqlRegion() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "ALL")

    val effectiveUserSubRegion: StateFlow<String> = repository.currentUserFlow
        .map { AccessControlManager.effectiveSqlSubRegion() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "ALL")

    // وضع القراءة فقط (إذا تم فتح مشروع مقفل isOpen == false)
    val isReadOnlyMode: StateFlow<Boolean> = selectedProject.map { project ->
        project != null && !project.isOpen
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val effectiveActiveProjectId: Flow<Long> = combine(selectedProject, selectedProjectId) { prj, pid ->
        prj?.projectID ?: pid
    }.distinctUntilChanged()

    @OptIn(ExperimentalCoroutinesApi::class)
    val alreadyNominatedFamilyIds: StateFlow<Set<Long>> = effectiveActiveProjectId
        .flatMapLatest { pid ->
            if (pid > 0) repository.getNominatedFamilyIdsForProjectFlow(pid) else flowOf(emptySet())
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    @OptIn(ExperimentalCoroutinesApi::class)
    val alreadyNominatedCount: StateFlow<Int> = combine(
        selectedProject,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { prj, restricted, effReg, effSubReg ->
        Triple(prj?.projectID ?: 0L, restricted, effReg to effSubReg)
    }.flatMapLatest { (pid, restricted, scope) ->
        if (pid <= 0) {
            flowOf(0)
        } else if (restricted && (scope.first != "ALL" || scope.second != "ALL")) {
            repository.getProjectScopedNominatedCountFlow(pid, scope.first, scope.second)
        } else if (restricted) {
            val allowedLocs = AccessControlManager.getCleanAllowedLocalities()
            repository.getProjectNominatedCountsBySubAreaFlow(pid).map { byArea ->
                byArea.filterKeys { area -> allowedLocs.any { it.equals(area, ignoreCase = true) } }.values.sum()
            }
        } else {
            repository.getProjectNominatedDistinctCountFlow(pid)
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    @OptIn(ExperimentalCoroutinesApi::class)
    val alreadyNominatedBySubArea: StateFlow<Map<String, Int>> = combine(
        selectedProject,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { prj, restricted, effReg, effSubReg ->
        Triple(prj?.projectID ?: 0L, restricted, effReg to effSubReg)
    }.flatMapLatest { (pid, restricted, scope) ->
        if (pid <= 0) {
            flowOf(emptyMap())
        } else if (restricted && (scope.first != "ALL" || scope.second != "ALL")) {
            repository.getProjectScopedNominatedCountsBySubAreaFlow(pid, scope.first, scope.second)
        } else if (restricted) {
            val allowedLocs = AccessControlManager.getCleanAllowedLocalities()
            repository.getProjectNominatedCountsBySubAreaFlow(pid).map { byArea ->
                byArea.filterKeys { area -> allowedLocs.any { it.equals(area, ignoreCase = true) } }
            }
        } else {
            repository.getProjectNominatedCountsBySubAreaFlow(pid)
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val dynamicSelectedProject: StateFlow<ProjectEntity?> = combine(allActiveProjects, selectedProjectId) { list, pid ->
        list.firstOrNull { it.projectID == pid }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val dynamicAlreadyNominatedFamilyIds: StateFlow<Set<Long>> = selectedProjectId
        .flatMapLatest { pid ->
            if (pid > 0) repository.getNominatedFamilyIdsForProjectFlow(pid) else flowOf(emptySet())
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    @OptIn(ExperimentalCoroutinesApi::class)
    val dynamicAlreadyNominatedCount: StateFlow<Int> = combine(
        selectedProjectId,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { pid, restricted, effReg, effSubReg ->
        Triple(pid, restricted, effReg to effSubReg)
    }.flatMapLatest { (pid, restricted, scope) ->
        if (pid <= 0) {
            flowOf(0)
        } else if (restricted && (scope.first != "ALL" || scope.second != "ALL")) {
            repository.getProjectScopedNominatedCountFlow(pid, scope.first, scope.second)
        } else if (restricted) {
            val allowedLocs = AccessControlManager.getCleanAllowedLocalities()
            repository.getProjectNominatedCountsBySubAreaFlow(pid).map { byArea ->
                byArea.filterKeys { area -> allowedLocs.any { it.equals(area, ignoreCase = true) } }.values.sum()
            }
        } else {
            repository.getProjectNominatedDistinctCountFlow(pid)
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val dynamicTargetQuota: StateFlow<Int> = combine(
        dynamicSelectedProject,
        selectedResidencyStatus,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { prj, residency, restricted, _, _ ->
        if (prj == null || prj.targetQuota <= 0) {
            0
        } else if (!restricted) {
            prj.targetQuota
        } else {
            val targetResidency = residency?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
            repository.computeScopedRegionalQuota(prj.targetQuota, targetResidency)
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val projectRegionalQuotasMap: StateFlow<Map<Long, Int>> = combine(
        openProjects,
        selectedResidencyStatus,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { projects, residency, restricted, _, _ ->
        if (projects.isEmpty()) {
            emptyMap()
        } else if (!restricted) {
            projects.associate { it.projectID to it.targetQuota }
        } else {
            val targetResidency = residency?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
            repository.computeScopedRegionalQuotasForProjects(projects, targetResidency)
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val dynamicRemainingQuota: StateFlow<Int> = combine(
        dynamicSelectedProject,
        dynamicTargetQuota,
        dynamicAlreadyNominatedCount
    ) { prj, scopedTarget, prevCount ->
        if (prj == null || prj.targetQuota <= 0) 0 else (scopedTarget - prevCount).coerceAtLeast(0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private fun syncProjectQuotaLimitOverride(project: ProjectEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            if (project.targetQuota > 0) {
                val targetResidency = selectedResidencyStatus.value?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
                val remCap = repository.computeRemainingQuotaForCurrentUser(project, targetResidency)
                targetBeneficiariesText.value = remCap.toString()
                if (isGeoRestrictedUser.value) {
                    resultLimitText.value = remCap.toString()
                }
            }
        }
    }

    fun selectProject(project: ProjectEntity) {
        val changed = selectedProject.value?.projectID != project.projectID
        selectedProject.value = project
        selectedProjectId.value = project.projectID
        selectedAidTypeId.value = project.aidTypeID
        if (changed) {
            selectedNominees.value = emptySet()
            _priorityNomineeSources.value = emptyMap()
        }
        syncProjectQuotaLimitOverride(project)
    }

    fun syncSelectedProjectById(projectId: Long) {
        selectedProjectId.value = projectId
        val matched = allActiveProjects.value.firstOrNull { it.projectID == projectId }
        if (matched != null) {
            val changed = selectedProject.value?.projectID != projectId
            if (changed) {
                selectedProject.value = matched
                selectedAidTypeId.value = matched.aidTypeID
                selectedNominees.value = emptySet()
                _priorityNomineeSources.value = emptyMap()
            }
            syncProjectQuotaLimitOverride(matched)
        }
    }

    fun setTargetBeneficiariesInput(rawInput: String) {
        val digitsOnly = rawInput.filter { it.isDigit() }
        if (digitsOnly.isEmpty()) {
            targetBeneficiariesText.value = ""
            return
        }
        val activeProject = dynamicSelectedProject.value
        val parsed = digitsOnly.toIntOrNull() ?: 0
        val clamped = if (activeProject != null && activeProject.targetQuota > 0) {
            parsed.coerceAtMost(dynamicRemainingQuota.value)
        } else {
            parsed
        }
        targetBeneficiariesText.value = clamped.toString()
    }

    // ==========================================
    // تدفق الأسر المصفى جغرافياً من المصدر (RBAC Pre-Filtered Master Stream: محليات + شعب)
    // ==========================================
    val rbacFamiliesStream: StateFlow<List<FamilyEntity>> = combine(
        repository.getFamiliesRestrictedFlow(),
        assignedSubRegion,
        repository.currentUserFlow,
        dbLocalities
    ) { families, region, user, locs ->
        if (user == null) return@combine emptyList()
        val localitiesMap = locs.associate { it.LocalityID to it.LocalityName }
        val extraLocIds = repository.getCurrentUserLocalityIds()
        val rlsFiltered = families.filter { fam ->
            AccessControlManager.isFamilyAllowed(fam, localitiesMap, extraLocIds)
        }
        val effectiveRegion = region.trim()
        val isSubRegionRestricted = effectiveRegion.isNotBlank() &&
            !effectiveRegion.equals("All", ignoreCase = true) &&
            effectiveRegion != "الكل" &&
            effectiveRegion != "*"
        if (isSubRegionRestricted) {
            rlsFiltered.filter { fam ->
                fam.currentSubArea.equals(effectiveRegion, ignoreCase = true) ||
                    fam.currentMainArea.equals(effectiveRegion, ignoreCase = true) ||
                    localitiesMap[fam.localityID]?.equals(effectiveRegion, ignoreCase = true) == true
            }
        } else {
            rlsFiltered
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val canViewAllLocalities: StateFlow<Boolean> = combine(
        repository.currentUserFlow,
        assignedSubRegion
    ) { user, region ->
        if (user == null) false
        else {
            val cleanAllowedNames = AccessControlManager.getCleanAllowedLocalities()
            val hasLocIdRestriction = user.AllowedLocalityID > 0 ||
                repository.getCurrentUserLocalityIds().any { it > 0 }
            val hasSubAreaRestriction = region.trim().let {
                it.isNotBlank() && !it.equals("All", ignoreCase = true) && it != "الكل" && it != "*"
            }
            cleanAllowedNames.isEmpty() && !hasLocIdRestriction && !hasSubAreaRestriction
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val lockedLocalityName: StateFlow<String?> = combine(
        repository.currentUserFlow,
        repository.getAllowedLocalitiesFlow(),
        assignedSubRegion
    ) { user, allowedLocEntities, region ->
        if (user == null) {
            null
        } else {
            val cleanAllowedNames = AccessControlManager.getCleanAllowedLocalities()
            val hasLocIdRestriction = user.AllowedLocalityID > 0 ||
                repository.getCurrentUserLocalityIds().any { it > 0 }
            val resolvedNames = cleanAllowedNames.ifEmpty {
                if (hasLocIdRestriction) allowedLocEntities.map { it.LocalityName.trim() }.filter { it.isNotBlank() } else emptyList()
            }.distinct()
            val cleanRegion = region.trim().takeIf {
                it.isNotBlank() && !it.equals("All", ignoreCase = true) && it != "الكل" && it != "*"
            }
            when {
                resolvedNames.size == 1 -> resolvedNames.first()
                resolvedNames.isEmpty() && cleanRegion != null -> cleanRegion
                else -> null
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isLocalityLocked: StateFlow<Boolean> = lockedLocalityName
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val assignedSubArea: StateFlow<String?> = AccessControlManager.assignedSubAreaFlow
    val assignedDivisions: StateFlow<List<String>> = AccessControlManager.assignedDivisionsFlow

    val allowedBranches: StateFlow<List<String>> = combine(
        repository.currentUserFlow,
        assignedDivisions
    ) { _, divs ->
        divs.ifEmpty { AccessControlManager.getCleanAllowedBranches() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lockedBranchName: StateFlow<String?> = combine(
        repository.currentUserFlow,
        allowedBranches
    ) { user, branches ->
        if (user == null) {
            null
        } else {
            if (branches.size == 1) branches.first() else null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isBranchLocked: StateFlow<Boolean> = lockedBranchName
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val canViewAllBranches: StateFlow<Boolean> = combine(
        repository.currentUserFlow,
        allowedBranches
    ) { user, branches ->
        user != null && branches.isEmpty()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val selectedLocalityFilter = MutableStateFlow("")
    val selectedBranchFilter = MutableStateFlow("")
    val selectedLocalitiesFilter = MutableStateFlow<Set<String>>(emptySet())
    val selectedBranchesFilter = MutableStateFlow<Set<String>>(emptySet())

    val availableBranches: StateFlow<List<String>> = combine(
        repository.currentUserFlow,
        selectedLocalitiesFilter,
        selectedLocalityFilter,
        lockedLocalityName,
        allowedBranches
    ) { user, selectedLocs, selectedLocSingle, lockedLoc, allowed ->
        val activeLocalities = when {
            lockedLoc != null -> listOf(lockedLoc)
            selectedLocs.isNotEmpty() -> selectedLocs.toList()
            selectedLocSingle.isNotBlank() -> listOf(selectedLocSingle)
            else -> emptyList()
        }
        val dbBranches = if (activeLocalities.isEmpty()) {
            repository.getDistinctBranchesForLocality("")
        } else {
            activeLocalities.flatMap { loc -> repository.getDistinctBranchesForLocality(loc) }
        }
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
        if (user == null || allowed.isEmpty()) {
            dbBranches.sorted()
        } else {
            val filtered = dbBranches.filter { br -> allowed.any { it.equals(br, ignoreCase = true) } }
            (if (filtered.isNotEmpty()) filtered else allowed).distinct().sorted()
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectLocalityFilter(locality: String) {
        if (isLocalityLocked.value) return
        val clean = if (locality == "الكل" || locality == "جميع المحليات") "" else locality.trim()
        if (!canViewAllLocalities.value && clean.isBlank()) return
        val allowedLocs = AccessControlManager.getCleanAllowedLocalities()
        if (allowedLocs.isNotEmpty() && clean.isNotBlank() && allowedLocs.none { it.equals(clean, ignoreCase = true) }) {
            return
        }
        selectedLocalityFilter.value = clean
        selectedLocalitiesFilter.value = if (clean.isBlank()) emptySet() else setOf(clean)
        if (!isBranchLocked.value) {
            selectedBranchFilter.value = ""
            selectedBranchesFilter.value = emptySet()
        }
    }

    fun toggleLocalityFilterOption(locality: String) {
        if (isLocalityLocked.value) return
        val clean = locality.trim()
        if (clean.isBlank() || clean == "الكل" || clean == "جميع المحليات") {
            clearLocalitiesFilter()
            return
        }
        val allowedLocs = AccessControlManager.getCleanAllowedLocalities()
        if (allowedLocs.isNotEmpty() && allowedLocs.none { it.equals(clean, ignoreCase = true) }) {
            return
        }
        val current = selectedLocalitiesFilter.value.toMutableSet()
        val existing = current.firstOrNull { it.equals(clean, ignoreCase = true) }
        if (existing != null) {
            if (!canViewAllLocalities.value && current.size <= 1) return
            current.remove(existing)
        } else {
            current.add(clean)
        }
        selectedLocalitiesFilter.value = current
        selectedLocalityFilter.value = if (current.size == 1) current.first() else ""
        if (!isBranchLocked.value && current.isNotEmpty()) {
            val validBranches = availableBranches.value
            if (validBranches.isNotEmpty()) {
                selectedBranchesFilter.value = selectedBranchesFilter.value.filter { br ->
                    validBranches.any { it.equals(br, ignoreCase = true) }
                }.toSet()
                selectedBranchFilter.value = if (selectedBranchesFilter.value.size == 1) selectedBranchesFilter.value.first() else ""
            }
        }
    }

    fun clearLocalitiesFilter() {
        if (isLocalityLocked.value) return
        if (!canViewAllLocalities.value) return
        selectedLocalitiesFilter.value = emptySet()
        selectedLocalityFilter.value = ""
        if (!isBranchLocked.value) {
            selectedBranchesFilter.value = emptySet()
            selectedBranchFilter.value = ""
        }
    }

    fun selectBranchFilter(branch: String) {
        if (isBranchLocked.value) return
        val clean = if (branch == "الكل" || branch == "جميع الشعب" || branch == "كافة الشعب المصرح بها") "" else branch.trim()
        val allowed = AccessControlManager.getCleanAllowedBranches()
        if (allowed.isNotEmpty() && clean.isNotBlank() && allowed.none { it.equals(clean, ignoreCase = true) }) {
            return
        }
        selectedBranchFilter.value = clean
        selectedBranchesFilter.value = if (clean.isBlank()) emptySet() else setOf(clean)
    }

    fun toggleBranchFilterOption(branch: String) {
        if (isBranchLocked.value) return
        val clean = branch.trim()
        if (clean.isBlank() || clean == "الكل" || clean == "جميع الشعب" || clean == "كافة الشعب المصرح بها") {
            clearBranchesFilter()
            return
        }
        val allowed = AccessControlManager.getCleanAllowedBranches()
        if (allowed.isNotEmpty() && allowed.none { it.equals(clean, ignoreCase = true) }) {
            return
        }
        val current = selectedBranchesFilter.value.toMutableSet()
        val existing = current.firstOrNull { it.equals(clean, ignoreCase = true) }
        if (existing != null) {
            current.remove(existing)
        } else {
            current.add(clean)
        }
        selectedBranchesFilter.value = current
        selectedBranchFilter.value = if (current.size == 1) current.first() else ""
    }

    fun clearBranchesFilter() {
        if (isBranchLocked.value) return
        selectedBranchesFilter.value = emptySet()
        selectedBranchFilter.value = ""
    }

    val canNominate: StateFlow<Boolean> = repository.currentUserFlow
        .map { user ->
            user != null && (repository.isSuperAdmin() || AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // (تمت تهيئة selectedResidencyStatus و isSubmitEnabled أعلى الكلاس قبل التدفقات المعتمدة عليهما)

    val localityQuotasMap: StateFlow<Map<String, Int>> = combine(
        rbacFamiliesStream,
        selectedProject,
        selectedResidencyStatus,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val families = args[0] as List<FamilyEntity>
        val project = args[1] as ProjectEntity?
        val residency = args[2] as String?
        val restricted = args[3] as Boolean
        val effReg = args[4] as String
        val effSubReg = args[5] as String

        if (project == null || project.targetQuota <= 0) {
            emptyMap()
        } else {
            val targetResidency = residency?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
            // القاعدة الإجمالية الحقيقية على مستوى النظام بالكامل لمنع تضخم حصة المنطقة إلى 100%
            val systemTotalBase = repository.getSystemApprovedCountByResidencySync(targetResidency)
            if (systemTotalBase <= 0) {
                emptyMap()
            } else {
                val baseFamilies = families.filter { fam ->
                    fam.socialAffairsStatus.trim() == "معتمد" &&
                        fam.residencyStatus.trim().equals(targetResidency, ignoreCase = true) &&
                        (!restricted || effReg == "ALL" || fam.currentSubArea.trim().equals(effReg, ignoreCase = true)) &&
                        (!restricted || effSubReg == "ALL" || fam.currentBranch.trim().equals(effSubReg, ignoreCase = true))
                }
                val groups = baseFamilies.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }
                groups.mapValues { (_, list) ->
                    val baseX = list.size
                    Math.round((baseX.toDouble() / systemTotalBase.toDouble()) * project.targetQuota).toInt()
                }
            }
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val visibleTargetQuota: StateFlow<Int> = combine(
        selectedProject,
        selectedResidencyStatus,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { project, residency, restricted, _, _ ->
        if (project == null || project.targetQuota <= 0) {
            0
        } else if (!restricted) {
            project.targetQuota
        } else {
            val targetResidency = residency?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
            repository.computeScopedRegionalQuota(project.targetQuota, targetResidency)
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val remainingQuota: StateFlow<Int> = combine(
        selectedProject,
        visibleTargetQuota,
        alreadyNominatedCount
    ) { prj, scopedTarget, prevCount ->
        if (prj == null || prj.targetQuota <= 0) 0 else (scopedTarget - prevCount).coerceAtLeast(0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // ==========================================
    // MODULE 4: THE SUPER DYNAMIC FILTER ENGINE (100% Data-Driven from DAO DISTINCT Queries)
    // ==========================================
    private val _dynamicShelterOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicShelterOptions: StateFlow<List<String>> = _dynamicShelterOptions.asStateFlow()

    private val _dynamicWorksApprovalOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicWorksApprovalOptions: StateFlow<List<String>> = _dynamicWorksApprovalOptions.asStateFlow()

    private val _dynamicDamageOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicDamageOptions: StateFlow<List<String>> = _dynamicDamageOptions.asStateFlow()

    // تم استبدال القائمة العشوائية (DISTINCT) بفلتر حالة العمل المنطقي الذكي (workStatusFilter)
    val dynamicIncomeOptions: StateFlow<List<String>> = MutableStateFlow<List<String>>(emptyList()).asStateFlow()

    private val _dynamicSubAreaOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicSubAreaOptions: StateFlow<List<String>> = _dynamicSubAreaOptions.asStateFlow()

    private val _dynamicResidencyStatusOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicResidencyStatusOptions: StateFlow<List<String>> = _dynamicResidencyStatusOptions.asStateFlow()

    private val _dynamicMaritalStatusOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicMaritalStatusOptions: StateFlow<List<String>> = _dynamicMaritalStatusOptions.asStateFlow()

    private val _dynamicLocalities = MutableStateFlow<List<String>>(emptyList())
    val dynamicLocalities: StateFlow<List<String>> = _dynamicLocalities.asStateFlow()

    private val _dynamicBranches = MutableStateFlow<List<String>>(emptyList())
    val dynamicBranches: StateFlow<List<String>> = _dynamicBranches.asStateFlow()

    val dynamicAidCategoryOptions: StateFlow<List<String>> =
        repository.getNominationPreviousAidCategoriesFlow()
            .flowOn(Dispatchers.IO)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var refreshOptionsJob: Job? = null

    fun refreshDynamicFilterOptions() {
        refreshOptionsJob?.cancel()
        refreshOptionsJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val allowedLocNames = AccessControlManager.getCleanAllowedLocalities()
                val allowedBranchNames = AccessControlManager.getCleanAllowedBranches()
                val regionFilter = assignedSubRegion.value.trim()
                val hasRegionFilter = regionFilter.isNotBlank() &&
                    !regionFilter.equals("All", ignoreCase = true) &&
                    !regionFilter.equals("ALL", ignoreCase = true) &&
                    regionFilter != "الكل" &&
                    regionFilter != "*"

                val shelter = repository.getDistinctShelterStatusesRestrictedSync()
                val works = repository.getDistinctWorksApprovalsRestrictedSync()
                val damage = repository.getDistinctDamageTypesRestrictedSync()
                val marital = repository.getDistinctMaritalStatusesRestrictedSync()
                val residency = repository.getDistinctResidentStatusesRestrictedSync()

                val dbSubAreas = repository.getDistinctCurrentSubAreasRestrictedSync()
                val intersectedSubAreas = dbSubAreas.filter { sub ->
                    val matchesAllowedLoc = allowedLocNames.isEmpty() ||
                        allowedLocNames.any { it.equals(sub, ignoreCase = true) }
                    val matchesRegion = !hasRegionFilter || sub.equals(regionFilter, ignoreCase = true)
                    matchesAllowedLoc && matchesRegion
                }

                val dbLocalitiesList = repository.getDistinctLocalitiesRestrictedSync()
                val intersectedLocalities = dbLocalitiesList.filter { loc ->
                    val matchesAllowedLoc = allowedLocNames.isEmpty() ||
                        allowedLocNames.any { it.equals(loc, ignoreCase = true) }
                    val matchesRegion = !hasRegionFilter || loc.equals(regionFilter, ignoreCase = true)
                    matchesAllowedLoc && matchesRegion
                }

                val dbBranchesList = repository.getAllDistinctBranches()
                val intersectedBranches = if (allowedBranchNames.isEmpty()) {
                    dbBranchesList
                } else {
                    dbBranchesList.filter { br ->
                        allowedBranchNames.any { it.equals(br, ignoreCase = true) }
                    }
                }

                _dynamicShelterOptions.value = shelter
                _dynamicWorksApprovalOptions.value = works
                _dynamicDamageOptions.value = damage
                _dynamicSubAreaOptions.value = intersectedSubAreas
                _dynamicResidencyStatusOptions.value = residency
                _dynamicMaritalStatusOptions.value = marital
                _dynamicLocalities.value = intersectedLocalities
                _dynamicBranches.value = intersectedBranches
            } catch (_: Exception) {
                // Keep previous valid lists on transient cancellation
            }
        }
    }

    init {
        refreshDynamicFilterOptions()
        viewModelScope.launch(Dispatchers.IO) {
            combine(repository.currentUserFlow, assignedSubRegion) { user, region ->
                user?.UserID to region
            }.distinctUntilChanged().drop(1).collect {
                refreshDynamicFilterOptions()
            }
        }
        viewModelScope.launch {
            combine(lockedLocalityName, lockedBranchName) { lockedLoc, lockedBr ->
                lockedLoc to lockedBr
            }.collect { (lockedLoc, lockedBr) ->
                if (lockedLoc != null) {
                    if (selectedLocalityFilter.value != lockedLoc) {
                        selectedLocalityFilter.value = lockedLoc
                    }
                    if (selectedLocalitiesFilter.value != setOf(lockedLoc)) {
                        selectedLocalitiesFilter.value = setOf(lockedLoc)
                    }
                }
                if (lockedBr != null) {
                    if (selectedBranchFilter.value != lockedBr) {
                        selectedBranchFilter.value = lockedBr
                    }
                    if (selectedBranchesFilter.value != setOf(lockedBr)) {
                        selectedBranchesFilter.value = setOf(lockedBr)
                    }
                }
            }
        }
        viewModelScope.launch {
            alreadyNominatedFamilyIds.collect { nominatedIds ->
                val current = selectedNominees.value
                if (current.any { nominatedIds.contains(it.familyID) }) {
                    selectedNominees.value = current.filterNot { nominatedIds.contains(it.familyID) }.toSet()
                }
            }
        }
        viewModelScope.launch {
            var lastSyncedProjectId = -1L
            combine(dynamicSelectedProject, dynamicRemainingQuota, isGeoRestrictedUser) { prj, rem, restricted ->
                Triple(prj, rem, restricted)
            }.collect { (prj, rem, restricted) ->
                if (prj != null && prj.targetQuota > 0) {
                    val typed = targetBeneficiariesText.value.toIntOrNull()
                    val projectSwitched = lastSyncedProjectId != prj.projectID
                    lastSyncedProjectId = prj.projectID
                    if (restricted) {
                        if (projectSwitched || typed == null || typed > rem) {
                            targetBeneficiariesText.value = rem.toString()
                        }
                        val typedLimit = resultLimitText.value.toIntOrNull()
                        if (projectSwitched || typedLimit == null || typedLimit > rem) {
                            resultLimitText.value = rem.toString()
                        }
                    } else if (typed != null && typed > rem) {
                        targetBeneficiariesText.value = rem.toString()
                    }
                }
            }
        }
    }

    // حالات الشرائح متعددة الحالات (Multi-State Filter Chips)
    val shelterChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val worksApprovalChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val damageChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val localityChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val aidCategoryChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())

    // MISSION 1: WHOLE FILTER BYPASS (TOGGLE SWITCHES)
    val shelterFilterEnabled = MutableStateFlow(true)
    val worksApprovalFilterEnabled = MutableStateFlow(true)
    val damageFilterEnabled = MutableStateFlow(true)
    val incomeFilterEnabled = MutableStateFlow(true)
    val localityFilterEnabled = MutableStateFlow(true)
    val aidCategoryFilterEnabled = MutableStateFlow(true)
    val selectedMaritalStatuses = MutableStateFlow<List<String>>(emptyList())
    val excludeMaritalStatuses = MutableStateFlow(false)
    val maritalStatusFilterEnabled = MutableStateFlow(true)

    // فلتر حالة العمل المنطقي الذكي (الكل / يعمل (لديه دخل) / لا يعمل (بدون دخل))
    private val _workStatusFilter = MutableStateFlow("الكل")
    val workStatusFilter: StateFlow<String> = _workStatusFilter.asStateFlow()

    fun setShelterFilterEnabled(enabled: Boolean) { shelterFilterEnabled.value = enabled }
    fun setWorksApprovalFilterEnabled(enabled: Boolean) { worksApprovalFilterEnabled.value = enabled }
    fun setDamageFilterEnabled(enabled: Boolean) { damageFilterEnabled.value = enabled }
    fun setIncomeFilterEnabled(enabled: Boolean) { incomeFilterEnabled.value = enabled }
    fun setLocalityFilterEnabled(enabled: Boolean) { localityFilterEnabled.value = enabled }
    fun setAidCategoryFilterEnabled(enabled: Boolean) { aidCategoryFilterEnabled.value = enabled }

    fun setWorkStatusFilter(option: String) {
        _workStatusFilter.value = option.ifBlank { "الكل" }
    }

    // فلاتر الاستثناء الزمني وحجم الأسرة وفلترة الأطفال بالأعمار
    val exclusionMode = MutableStateFlow(ExclusionMode.DAYS)
    val exclusionDaysText = MutableStateFlow("30")
    val exclusionDateCutoffText = MutableStateFlow("")
    val hasChildrenOnly = MutableStateFlow(false)
    val minChildAgeText = MutableStateFlow("0")
    val maxChildAgeText = MutableStateFlow("18")
    val minFamilyMembers = MutableStateFlow(1)
    val searchQuery = MutableStateFlow("")

    fun setHasChildrenOnly(enabled: Boolean) { hasChildrenOnly.value = enabled }
    fun setChildAgeRange(min: String, max: String) {
        minChildAgeText.value = min
        maxChildAgeText.value = max
    }

    // استعلام SQL مباشر لأرقام هويات الأسر المطابقة لنطاق عمر الأبناء فقط عند تفعيل الفلتر (بدون تحميل جدول الأبناء في الرام)
    @OptIn(ExperimentalCoroutinesApi::class)
    private val matchingChildAgeFamilyIds: StateFlow<Set<String>> = combine(
        repository.currentUserFlow,
        hasChildrenOnly,
        minChildAgeText,
        maxChildAgeText
    ) { _, enabled, minStr, maxStr ->
        Triple(enabled, minStr.toIntOrNull() ?: 0, maxStr.toIntOrNull() ?: 100)
    }.flatMapLatest { (enabled, minAge, maxAge) ->
        if (!enabled) {
            flowOf(emptySet())
        } else {
            flow { emit(repository.getFamilyNationalIdsWithChildrenInAgeRangeSync(minAge, maxAge)) }
        }
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    private val familyReceivedAidCategoriesMap: StateFlow<Map<Long, Set<String>>> =
        repository.getFamilyReceivedAidCategoriesMapFlow()
            .flowOn(Dispatchers.IO)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // تبديل حالة الشريحة: غير محدد -> متضمن (أخضر) -> مستثنى (أحمر) -> غير محدد
    fun cycleChipState(category: String, key: String) {
        val targetFlow = when (category) {
            "shelter" -> shelterChipStates
            "worksApproval" -> worksApprovalChipStates
            "damage" -> damageChipStates
            "locality" -> localityChipStates
            "aidCategory" -> aidCategoryChipStates
            else -> return
        }
        val current = targetFlow.value.toMutableMap()
        val nextState = when (current[key] ?: ChipFilterState.UNSELECTED) {
            ChipFilterState.UNSELECTED -> ChipFilterState.INCLUDED
            ChipFilterState.INCLUDED -> ChipFilterState.EXCLUDED
            ChipFilterState.EXCLUDED -> ChipFilterState.UNSELECTED
        }
        if (nextState == ChipFilterState.UNSELECTED) {
            current.remove(key)
        } else {
            current[key] = nextState
        }
        targetFlow.value = current
    }

    fun clearAllFilterChips() {
        selectedResidencyStatus.value = null
        shelterChipStates.value = emptyMap()
        worksApprovalChipStates.value = emptyMap()
        damageChipStates.value = emptyMap()
        localityChipStates.value = emptyMap()
        aidCategoryChipStates.value = emptyMap()
        shelterFilterEnabled.value = true
        worksApprovalFilterEnabled.value = true
        damageFilterEnabled.value = true
        incomeFilterEnabled.value = true
        localityFilterEnabled.value = true
        aidCategoryFilterEnabled.value = true
        _workStatusFilter.value = "الكل"
        exclusionMode.value = ExclusionMode.DAYS
        exclusionDaysText.value = "30"
        exclusionDateCutoffText.value = ""
        hasChildrenOnly.value = false
        minChildAgeText.value = "0"
        maxChildAgeText.value = "18"
        minFamilyMembers.value = 1
        searchQuery.value = ""
        selectedMaritalStatuses.value = emptyList()
        excludeMaritalStatuses.value = false
        maritalStatusFilterEnabled.value = true
        selectedLocalitiesFilter.value = lockedLocalityName.value?.let { setOf(it) } ?: emptySet()
        selectedBranchesFilter.value = lockedBranchName.value?.let { setOf(it) } ?: emptySet()
        selectedLocalityFilter.value = lockedLocalityName.value ?: ""
        selectedBranchFilter.value = lockedBranchName.value ?: ""
    }

    // ==========================================
    // MODULE 5: SMART HYBRID SELECTION & DASHBOARD (The Core)
    // ==========================================
    private val geoFilterPair: Flow<Pair<Set<String>, Set<String>>> = combine(
        selectedLocalitiesFilter,
        selectedBranchesFilter,
        lockedLocalityName,
        lockedBranchName,
        dbLocalities
    ) { selLocs, selBrs, lockedLoc, lockedBr, _ ->
        val effLocs = lockedLoc?.let { setOf(it) } ?: selLocs
        val effBrs = lockedBr?.let { setOf(it) } ?: selBrs
        effLocs to effBrs
    }

    private val aidCategoryFilterContext: Flow<Triple<Map<String, ChipFilterState>, Boolean, Map<Long, Set<String>>>> = combine(
        aidCategoryChipStates,
        aidCategoryFilterEnabled,
        familyReceivedAidCategoriesMap
    ) { chips, enabled, familyMap ->
        Triple(chips, enabled, familyMap)
    }

    // تدفق الأسر المطابقة للشروط الصارمة (Filtered Families) مرتبة تنازلياً حسب حجم الأسرة مع استبعاد المرشحين مسبقاً لنفس المشروع
    val filteredFamilies: StateFlow<List<FamilyEntity>> = combine(
        rbacFamiliesStream,
        selectedProject,
        shelterChipStates,
        worksApprovalChipStates,
        damageChipStates,
        workStatusFilter,
        shelterFilterEnabled,
        worksApprovalFilterEnabled,
        damageFilterEnabled,
        incomeFilterEnabled,
        minFamilyMembers,
        hasChildrenOnly,
        minChildAgeText,
        maxChildAgeText,
        matchingChildAgeFamilyIds,
        selectedMaritalStatuses,
        excludeMaritalStatuses,
        maritalStatusFilterEnabled,
        geoFilterPair,
        dbLocalities,
        alreadyNominatedFamilyIds,
        selectedResidencyStatus,
        aidCategoryFilterContext
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val families = args[0] as List<FamilyEntity>
        val project = args[1] as ProjectEntity?
        @Suppress("UNCHECKED_CAST")
        val shelterChips = args[2] as Map<String, ChipFilterState>
        @Suppress("UNCHECKED_CAST")
        val worksChips = args[3] as Map<String, ChipFilterState>
        @Suppress("UNCHECKED_CAST")
        val damageChips = args[4] as Map<String, ChipFilterState>
        val workStatus = args[5] as String
        val shelterEnabled = args[6] as Boolean
        val worksEnabled = args[7] as Boolean
        val damageEnabled = args[8] as Boolean
        val incomeEnabled = args[9] as Boolean
        val minMembers = args[10] as Int
        val childrenEnabled = args[11] as Boolean
        val minAgeStr = args[12] as String
        val maxAgeStr = args[13] as String
        @Suppress("UNCHECKED_CAST")
        val matchingChildFamilyIds = args[14] as Set<String>
        @Suppress("UNCHECKED_CAST")
        val maritalStatuses = args[15] as List<String>
        val excludeMarital = args[16] as Boolean
        val maritalEnabled = args[17] as Boolean
        @Suppress("UNCHECKED_CAST")
        val geoPair = args[18] as Pair<Set<String>, Set<String>>
        @Suppress("UNCHECKED_CAST")
        val locsList = args[19] as List<LocalityEntity>
        @Suppress("UNCHECKED_CAST")
        val excludedFamilyIds = args[20] as Set<Long>
        val selectedResidency = args[21] as String?
        @Suppress("UNCHECKED_CAST")
        val aidCatCtx = args[22] as Triple<Map<String, ChipFilterState>, Boolean, Map<Long, Set<String>>>
        val localitiesMap = locsList.associate { it.LocalityID to it.LocalityName }

        executeCascadingFilter(
            families = families,
            project = project,
            shelterChips = shelterChips,
            worksApprovalChips = worksChips,
            damageChips = damageChips,
            workStatusFilterValue = workStatus,
            shelterEnabled = shelterEnabled,
            worksApprovalEnabled = worksEnabled,
            damageEnabled = damageEnabled,
            incomeEnabled = incomeEnabled,
            minMembers = minMembers,
            childrenFilterEnabled = childrenEnabled,
            minChildAge = minAgeStr.toIntOrNull() ?: 0,
            maxChildAge = maxAgeStr.toIntOrNull() ?: 100,
            matchingChildAgeFamilyIds = matchingChildFamilyIds,
            selectedMaritalStatuses = maritalStatuses,
            excludeMaritalStatuses = excludeMarital,
            maritalStatusEnabled = maritalEnabled,
            selectedLocalityNames = geoPair.first,
            selectedBranchNames = geoPair.second,
            localitiesMap = localitiesMap,
            excludedFamilyIds = excludedFamilyIds,
            selectedResidencyStatus = selectedResidency,
            aidCategoryChips = aidCatCtx.first,
            aidCategoryEnabled = aidCatCtx.second,
            familyReceivedAidCategories = aidCatCtx.third
        )
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // لوحة مراجعة الحصص النسبية مقارنة بالمرشحين الفعليين (معزولة جغرافياً للباحث المقيد وتستخدم المقام العام الحقيقي)
    val localityQuotaStats: StateFlow<List<LocalityQuotaStatsItem>> = combine(
        rbacFamiliesStream,
        selectedProject,
        localityQuotasMap,
        selectedNominees,
        alreadyNominatedBySubArea,
        selectedResidencyStatus,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val families = args[0] as List<FamilyEntity>
        val project = args[1] as ProjectEntity?
        @Suppress("UNCHECKED_CAST")
        val quotasMap = args[2] as Map<String, Int>
        @Suppress("UNCHECKED_CAST")
        val nominees = args[3] as Set<FamilyEntity>
        @Suppress("UNCHECKED_CAST")
        val prevBySubArea = args[4] as Map<String, Int>
        val residency = args[5] as String?
        val restricted = args[6] as Boolean
        val effReg = args[7] as String
        val effSubReg = args[8] as String

        if (project == null) {
            emptyList()
        } else {
            val targetResidency = residency?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
            val systemTotalBase = repository.getSystemApprovedCountByResidencySync(targetResidency)
            val baseFamilies = families.filter { fam ->
                fam.socialAffairsStatus.trim() == "معتمد" &&
                    fam.residencyStatus.trim().equals(targetResidency, ignoreCase = true) &&
                    (!restricted || effReg == "ALL" || fam.currentSubArea.trim().equals(effReg, ignoreCase = true)) &&
                    (!restricted || effSubReg == "ALL" || fam.currentBranch.trim().equals(effSubReg, ignoreCase = true))
            }
            val groups = baseFamilies.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }
            val nomineesByLocality = nominees.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }

            groups.map { (locName, list) ->
                val baseX = list.size
                val quota = quotasMap[locName] ?: 0
                val prevNominated = prevBySubArea[locName] ?: 0
                val draftNominated = nomineesByLocality[locName]?.size ?: 0
                val nominated = prevNominated + draftNominated
                val pct = if (systemTotalBase > 0) (baseX.toDouble() / systemTotalBase.toDouble()) * 100.0 else 0.0
                val displayLabel = if (restricted && effSubReg != "ALL") "$locName — $effSubReg" else locName
                LocalityQuotaStatsItem(
                    localityName = displayLabel,
                    baseX = baseX,
                    totalBase = systemTotalBase,
                    percentage = pct,
                    targetQuota = quota,
                    nominatedCount = nominated
                )
            }.sortedByDescending { it.targetQuota }
        }
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val dummyOrUnemployedWorkValues = setOf(
        "لا يعمل", "بلا عمل", "بدون عمل", "0", "_", "-", ".", "لا يوجد", "لا"
    )

    private fun hasValidWorkIncome(value: String?): Boolean {
        val cleaned = value?.trim().orEmpty()
        return cleaned.isNotEmpty() && cleaned !in dummyOrUnemployedWorkValues
    }

    /**
     * فلترة السلاسل المجمعة (Cascading Filter Execution)
     * مع مفاتيح التجاوز (Bypass Switches) وفلتر حالة العمل المنطقي وتنظيف البيانات الوهمية وفلترة عمر الأبناء
     */
    private fun executeCascadingFilter(
        families: List<FamilyEntity>,
        project: ProjectEntity?,
        shelterChips: Map<String, ChipFilterState>,
        worksApprovalChips: Map<String, ChipFilterState>,
        damageChips: Map<String, ChipFilterState>,
        workStatusFilterValue: String,
        shelterEnabled: Boolean,
        worksApprovalEnabled: Boolean,
        damageEnabled: Boolean,
        incomeEnabled: Boolean,
        minMembers: Int = minFamilyMembers.value,
        childrenFilterEnabled: Boolean = false,
        minChildAge: Int = 0,
        maxChildAge: Int = 100,
        matchingChildAgeFamilyIds: Set<String> = emptySet(),
        selectedMaritalStatuses: List<String> = emptyList(),
        excludeMaritalStatuses: Boolean = false,
        maritalStatusEnabled: Boolean = true,
        selectedLocalityNames: Set<String> = emptySet(),
        selectedBranchNames: Set<String> = emptySet(),
        localitiesMap: Map<Int, String> = emptyMap(),
        excludedFamilyIds: Set<Long> = emptySet(),
        selectedResidencyStatus: String? = null,
        aidCategoryChips: Map<String, ChipFilterState> = emptyMap(),
        aidCategoryEnabled: Boolean = true,
        familyReceivedAidCategories: Map<Long, Set<String>> = emptyMap()
    ): List<FamilyEntity> {
        val cleanLocalities = selectedLocalityNames
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "الكل" && it != "جميع المحليات" }
            .toSet()
        val cleanBranches = selectedBranchNames
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "الكل" && it != "جميع الشعب" && it != "كافة الشعب المصرح بها" }
            .toSet()
        val cleanResidencyFilter = selectedResidencyStatus?.trim()?.takeIf { it.isNotBlank() }
        return families.asSequence()
            // 0. الاستبعاد الصارم للمرشحين مسبقاً لنفس المشروع (الترشيح التراكمي المشترك)
            .filter { fam ->
                !excludedFamilyIds.contains(fam.familyID)
            }
            // 0.5 العزل الجغرافي المتعدد الموحد (تضمين أي محلية أو شعبة مختارة)
            .filter { fam ->
                if (cleanLocalities.isEmpty()) {
                    true
                } else {
                    val subArea = fam.currentSubArea.trim()
                    val mainArea = fam.currentMainArea.trim()
                    val mappedLoc = localitiesMap[fam.localityID]?.trim().orEmpty()
                    cleanLocalities.any { loc ->
                        subArea.equals(loc, ignoreCase = true) ||
                            mainArea.equals(loc, ignoreCase = true) ||
                            (mappedLoc.isNotEmpty() && mappedLoc.equals(loc, ignoreCase = true))
                    }
                }
            }
            .filter { fam ->
                if (cleanBranches.isEmpty()) {
                    true
                } else {
                    val famBranch = fam.currentBranch.trim()
                    cleanBranches.any { br -> famBranch.equals(br, ignoreCase = true) }
                }
            }
            // 1. الشرط الإلزامي المخفي (اعتماد التنمية = معتمد) + شرط صفة الإقامة الإلزامي الوحيد من الواجهة
            .filter { fam ->
                cleanResidencyFilter != null &&
                    fam.socialAffairsStatus.trim() == "معتمد" &&
                    fam.residencyStatus.trim().equals(cleanResidencyFilter, ignoreCase = true)
            }
            // 2. فلتر اعتماد الأشغال مع مفتاح التجاوز (Works Approval Bypass)
            .filter { fam ->
                if (!worksApprovalEnabled) true
                else {
                    val key = fam.worksApproval.trim().ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, worksApprovalChips)
                }
            }
            // 3. فلتر شرائح الإيواء ثلاثية الحالات مع مفتاح التجاوز (Bypass)
            .filter { fam ->
                if (!shelterEnabled) true
                else {
                    val key = fam.shelterStatus.trim().ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, shelterChips)
                }
            }
            // 4. فلتر شرائح الضرر مع مفتاح التجاوز (Bypass)
            .filter { fam ->
                if (!damageEnabled) true
                else {
                    val key = fam.damageType.trim().ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, damageChips)
                }
            }
            // 5. فلتر حالة العمل المنطقي الذكي مع تنظيف البيانات الوهمية عبر العمودين (incomeSource1 & income_source_2)
            .filter { fam ->
                val cleanStatus = workStatusFilterValue.trim()
                if (!incomeEnabled || cleanStatus == "الكل" || cleanStatus.isEmpty()) {
                    true
                } else {
                    val hasIncome = hasValidWorkIncome(fam.incomeSource1) || hasValidWorkIncome(fam.incomeSource2)
                    when (cleanStatus) {
                        "يعمل (لديه دخل)", "يعمل" -> hasIncome
                        "لا يعمل (بدون دخل)", "لا يعمل" -> !hasIncome
                        else -> true
                    }
                }
            }
            // 6. فلتر نوع المساعدة السابقة الديناميكي (تضمين من استلمها / استثناء من استلمها / تجاهل عند التجاوز أو الفراغ)
            .filter { fam ->
                if (!aidCategoryEnabled || aidCategoryChips.isEmpty()) {
                    true
                } else {
                    val receivedCats = familyReceivedAidCategories[fam.familyID] ?: emptySet()
                    evaluateMultiValueChipFilter(receivedCats, aidCategoryChips)
                }
            }
            // 7. شرط وجود الأبناء ونطاق الأعمار مع مفتاح التجاوز (Children & Age Range Filter عبر SQL مباشر)
            .filter { fam ->
                if (!childrenFilterEnabled) true
                else matchingChildAgeFamilyIds.contains(fam.nationalID)
            }
            // 8. فلتر الحالة الاجتماعية (اختيار متعدد + استثناء المحدد)
            .filter { fam ->
                if (!maritalStatusEnabled || selectedMaritalStatuses.isEmpty()) {
                    true
                } else {
                    val statusValue = fam.maritalStatus.trim().ifBlank { "غير مصنف" }
                    val isMatch = selectedMaritalStatuses.any { it.trim() == statusValue }
                    if (excludeMaritalStatuses) !isMatch else isMatch
                }
            }
            // 9. حد أفراد الأسرة المقارن بالقيمة المحددة بدقة (يتجاهل القيمة <= 1)
            .filter { fam ->
                if (minMembers <= 1) true else fam.familyMembersCount >= minMembers
            }
            // 10. الترتيب الأولوية الإلزامي: الأكبر حجماً أولاً
            .sortedByDescending { it.familyMembersCount }
            .toList()
    }

    private fun evaluateChipFilter(value: String, chips: Map<String, ChipFilterState>): Boolean {
        if (chips.isEmpty()) return true
        val included = chips.filter { it.value == ChipFilterState.INCLUDED }.keys
        val excluded = chips.filter { it.value == ChipFilterState.EXCLUDED }.keys

        // إذا كان هناك عناصر مستثناة وتحتوي على القيمة -> استبعاد فوري
        if (excluded.contains(value)) return false
        // إذا كان هناك عناصر متضمنة -> يجب أن تطابق أحدها
        if (included.isNotEmpty() && !included.contains(value)) return false
        return true
    }

    private fun evaluateMultiValueChipFilter(
        familyValues: Set<String>,
        chips: Map<String, ChipFilterState>
    ): Boolean {
        if (chips.isEmpty()) return true
        val included = chips.filterValues { it == ChipFilterState.INCLUDED }.keys
        val excluded = chips.filterValues { it == ChipFilterState.EXCLUDED }.keys

        if (excluded.isNotEmpty() && familyValues.any { value ->
                excluded.any { AidCategoryCatalog.isSameCategory(it, value) || it.equals(value, ignoreCase = true) }
            }
        ) {
            return false
        }
        if (included.isNotEmpty() && familyValues.none { value ->
                included.any { AidCategoryCatalog.isSameCategory(it, value) || it.equals(value, ignoreCase = true) }
            }
        ) {
            return false
        }
        return true
    }

    // ==========================================
    // الترشيح الآلي واليدوي المحمي بالأقفال (Auto-Nominate & Manual Override)
    // ==========================================

    private var autoNominationJob: Job? = null

    /**
     * الترشيح الآلي: يوزع الحصص المتبقية بنزاهة تامة مع احتساب الترشيحات السابقة لكل محلية
     * ويحافظ بالكامل على الأسر المختارة مسبقاً بأولوية (من الشكاوى أو ملف الإكسل أو الإضافة اليدوية)
     * دون تكرارها أو مسحها، ويكمل فقط العدد المتبقي من الحصة.
     */
    fun runAutoNomination() {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return
        val project = selectedProject.value ?: return
        if (!project.isOpen) return // منع التعديل في وضع القراءة فقط

        val quotas = localityQuotasMap.value
        val pool = filteredFamilies.value
        val prevBySubArea = alreadyNominatedBySubArea.value
        val excludedIds = alreadyNominatedFamilyIds.value
        val existingDraft = selectedNominees.value

        autoNominationJob?.cancel()
        autoNominationJob = viewModelScope.launch(Dispatchers.IO) {
            val restricted = isGeoRestrictedUser.value
            val targetResidency = selectedResidencyStatus.value?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
            val remainingCapacity = repository.computeRemainingQuotaForCurrentUser(project, targetResidency)

            if (remainingCapacity <= 0) {
                selectedNominees.value = emptySet()
                _priorityNomineeSources.value = emptyMap()
                return@launch
            }

            // الحفاظ على المرشحين بأولوية الموجودين مسبقاً في السلة (شكاوى / إكسل / يدوي) وعدم تكرارهم
            val preservedPriority = existingDraft
                .filter { !excludedIds.contains(it.familyID) }
                .take(remainingCapacity)
            val result = preservedPriority.toMutableSet()
            val alreadyPickedIds = result.map { it.familyID }.toMutableSet()
            val draftByLocality = result.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }
                .mapValues { it.value.size }

            val eligiblePool = pool.filter {
                !excludedIds.contains(it.familyID) && !alreadyPickedIds.contains(it.familyID)
            }

            // تجميع الأسر المؤهلة حسب المنطقة الفرعية الحالية (currentSubArea)
            val poolByLocality = eligiblePool.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }

            // التوزيع الحصري حتى استيفاء الحصة المتبقية لكل محلية (حصة المحلية - المرشح سابقاً - المرشح بأولوية في السلة)
            quotas.forEach { (locName, totalLocQuota) ->
                if (totalLocQuota > 0 && result.size < remainingCapacity) {
                    val prevInLoc = (prevBySubArea[locName] ?: 0) + (draftByLocality[locName] ?: 0)
                    val remainingInLoc = (totalLocQuota - prevInLoc).coerceAtLeast(0)
                    if (remainingInLoc > 0) {
                        val availableInLoc = poolByLocality[locName] ?: emptyList()
                        val needed = remainingInLoc.coerceAtMost(remainingCapacity - result.size)
                        availableInLoc.take(needed).forEach { fam ->
                            if (alreadyPickedIds.add(fam.familyID)) {
                                result.add(fam)
                            }
                        }
                    }
                }
            }

            // للنظام غير المقيد فقط: ملء أي فجوة متبقية من باقي الأسر المؤهلة
            if (!restricted && result.size < remainingCapacity) {
                val remaining = eligiblePool.filter { !alreadyPickedIds.contains(it.familyID) }
                val needed = remainingCapacity - result.size
                remaining.take(needed).forEach { fam ->
                    if (alreadyPickedIds.add(fam.familyID)) {
                        result.add(fam)
                    }
                }
            }

            selectedNominees.value = result
        }
    }

    /**
     * الإضافة اليدوية لأسرة مع فرض عدم تكرارها وعدم تجاوز الحصة المتبقية للمشروع
     */
    fun addNomineeManually(family: FamilyEntity): Boolean {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return false
        val project = selectedProject.value ?: return false
        if (!project.isOpen) return false
        if (alreadyNominatedFamilyIds.value.contains(family.familyID)) return false
        if (selectedNominees.value.size >= remainingQuota.value) return false

        val current = selectedNominees.value.toMutableSet()
        val added = current.add(family)
        if (added) {
            selectedNominees.value = current
            val sources = _priorityNomineeSources.value.toMutableMap()
            if (!sources.containsKey(family.familyID)) {
                sources[family.familyID] = "يدوي"
                _priorityNomineeSources.value = sources
            }
        }
        return added
    }

    /**
     * الاستبعاد اليدوي (Swipe to Dismiss / Remove)
     */
    fun removeNominee(family: FamilyEntity) {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return
        val project = selectedProject.value ?: return
        if (!project.isOpen) return

        val current = selectedNominees.value.toMutableSet()
        if (current.remove(family)) {
            selectedNominees.value = current
            val sources = _priorityNomineeSources.value.toMutableMap()
            sources.remove(family.familyID)
            _priorityNomineeSources.value = sources
        }
    }

    fun clearNominees() {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return
        val project = selectedProject.value ?: return
        if (!project.isOpen) return
        selectedNominees.value = emptySet()
        _priorityNomineeSources.value = emptyMap()
    }

    /**
     * اعتماد وترحيل الترشيحات رسمياً إلى قاعدة البيانات (إضافة تراكمية بدون مسح السابق)
     * مع التحديث التلقائي لحالة الشكاوى المفتوحة للأسر المعتمدة إلى NOMINATED وحفظ اسم المشروع.
     */
    suspend fun commitNomination(): Result<Int> = withContext(Dispatchers.IO) {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) {
            return@withContext Result.failure(SecurityException("ليس لديك صلاحية اعتماد وترحيل الترشيحات"))
        }
        val project = selectedProject.value
            ?: return@withContext Result.failure(IllegalStateException("لم يتم اختيار أي مشروع"))
        if (!project.isOpen) {
            return@withContext Result.failure(IllegalStateException("المشروع مغلق أو مقفل ولا يمكن اعتماد ترشيحات له"))
        }

        val nominees = selectedNominees.value
        if (nominees.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("قائمة المرشحين فارغة"))
        }

        try {
            val insertedCount = repository.commitNomineesToProject(
                projectId = project.projectID,
                aidTypeId = project.aidTypeID,
                familyIds = nominees.map { it.familyID },
                mechanism = "هجين (آلي/يدوي/أولويات)"
            )
            // تحديث حالة الشكاوى المفتوحة تلقائياً للأسر التي تم اعتماد ترشيحها
            runCatching {
                repository.markComplaintsNominatedByFamilyIds(
                    familyNationalIds = nominees.map { it.nationalID },
                    projectName = project.projectName
                )
            }
            selectedNominees.value = emptySet()
            _priorityNomineeSources.value = emptyMap()
            Result.success(insertedCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // =========================================================================
    // MODULE 6: نظام الشكاوى والأولويات + الترشيح عبر ملف الإكسل مع التغذية الراجعة التفصيلية
    // =========================================================================

    val openComplaintsFlow: StateFlow<List<FamilyComplaintEntity>> = repository.getAllOpenComplaintsFlow()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val complaintCategoryFilter = MutableStateFlow("الكل")

    fun setComplaintCategoryFilter(category: String) {
        complaintCategoryFilter.value = category.ifBlank { "الكل" }
    }

    val availableComplaintCategories: StateFlow<List<String>> = openComplaintsFlow
        .map { list ->
            list.map { it.targetAidCategory.trim() }
                .filter { it.isNotBlank() }
                .distinct()
                .sorted()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _excelImportInProgress = MutableStateFlow(false)
    val excelImportInProgress: StateFlow<Boolean> = _excelImportInProgress.asStateFlow()

    private val _excelFeedbackResult = MutableStateFlow<ExcelNominationResult?>(null)
    val excelFeedbackResult: StateFlow<ExcelNominationResult?> = _excelFeedbackResult.asStateFlow()

    fun clearExcelFeedback() {
        _excelFeedbackResult.value = null
    }

    private fun parseIsoDateMillis(raw: String?): Long? {
        val clean = raw?.trim()?.take(10) ?: return null
        if (clean.length < 8) return null
        return runCatching {
            SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }.parse(clean)?.time
        }.getOrNull()
    }

    /**
     * المدقق الموحد لشروط المشروع والفلاتر النشطة (يُستخدم للشكاوى ولترشيح الإكسل معاً بنفس الدقة)
     */
    private fun evaluateFamilyEligibilityReasons(
        fam: FamilyEntity,
        selectedLocalityNames: Set<String>,
        selectedBranchNames: Set<String>,
        localitiesMap: Map<Int, String>,
        selectedResidency: String?,
        shelterChips: Map<String, ChipFilterState>,
        worksApprovalChips: Map<String, ChipFilterState>,
        damageChips: Map<String, ChipFilterState>,
        workStatus: String,
        shelterEnabled: Boolean,
        worksEnabled: Boolean,
        damageEnabled: Boolean,
        incomeEnabled: Boolean,
        aidCategoryChips: Map<String, ChipFilterState>,
        aidCategoryEnabled: Boolean,
        familyReceivedAidCategories: Map<Long, Set<String>>,
        childrenEnabled: Boolean,
        minChildAge: Int,
        maxChildAge: Int,
        childrenAgesMap: Map<String, List<Int>>,
        maritalStatuses: List<String>,
        excludeMarital: Boolean,
        maritalEnabled: Boolean,
        minMembers: Int,
        exclusionModeValue: ExclusionMode,
        exclusionDaysValue: Int,
        exclusionCutoffDateStr: String,
        latestSameTypeAidDateMap: Map<Long, String>,
        latestDeliveredAidDateMap: Map<Long, String>
    ): List<String> {
        val reasons = mutableListOf<String>()
        val famLocalArea = fam.currentSubArea.trim().ifBlank { fam.currentMainArea.trim() }.ifBlank { "غير محددة" }

        // 1. فحص النطاق الجغرافي المقيد للمستخدم (RBAC) + فلاتر المحليات والشعب المختارة
        val cleanLocalities = selectedLocalityNames
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "الكل" && it != "جميع المحليات" }
            .toSet()
        val allowedLocs = AccessControlManager.getCleanAllowedLocalities()
        val effectiveAllowedLocalities = when {
            cleanLocalities.isNotEmpty() -> cleanLocalities
            allowedLocs.isNotEmpty() -> allowedLocs.toSet()
            else -> emptySet()
        }
        if (effectiveAllowedLocalities.isNotEmpty()) {
            val subArea = fam.currentSubArea.trim()
            val mainArea = fam.currentMainArea.trim()
            val mappedLoc = localitiesMap[fam.localityID]?.trim().orEmpty()
            val matchesLoc = effectiveAllowedLocalities.any { loc ->
                subArea.equals(loc, ignoreCase = true) ||
                    mainArea.equals(loc, ignoreCase = true) ||
                    (mappedLoc.isNotEmpty() && mappedLoc.equals(loc, ignoreCase = true))
            }
            if (!matchesLoc) {
                reasons.add("خارج المنطقة المحلية المستهدفة (منطقته الحالية: $famLocalArea)")
            }
        }

        val cleanBranches = selectedBranchNames
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "الكل" && it != "جميع الشعب" && it != "كافة الشعب المصرح بها" }
            .toSet()
        val allowedBranchesList = AccessControlManager.getCleanAllowedBranches()
        val effectiveAllowedBranches = when {
            cleanBranches.isNotEmpty() -> cleanBranches
            allowedBranchesList.isNotEmpty() -> allowedBranchesList.toSet()
            else -> emptySet()
        }
        if (effectiveAllowedBranches.isNotEmpty()) {
            val famBranch = fam.currentBranch.trim()
            val matchesBranch = effectiveAllowedBranches.any { br -> famBranch.equals(br, ignoreCase = true) }
            if (!matchesBranch) {
                reasons.add("خارج الشعبة المستهدفة (شعبته الحالية: ${famBranch.ifBlank { "غير محددة" }})")
            }
        }

        // 2. شرط الاعتماد وصفة الإقامة
        val cleanResidency = selectedResidency?.trim()?.takeIf { it.isNotBlank() }
        if (fam.socialAffairsStatus.trim() != "معتمد") {
            reasons.add("غير مطابق لشرط الاعتماد (${fam.socialAffairsStatus.ifBlank { "غير معتمد" }})")
        }
        if (cleanResidency != null && !fam.residencyStatus.trim().equals(cleanResidency, ignoreCase = true)) {
            reasons.add("غير مطابق لشرط صفة الإقامة (صفته: ${fam.residencyStatus.ifBlank { "غير محدد" }} والمطلوب: $cleanResidency)")
        }

        // 3. فحص الاستثناء الزمني وتكرار المساعدة (نفس الصنف أو آخر مساعدة)
        val sameTypeDate = latestSameTypeAidDateMap[fam.familyID]
        val anyDeliveredDate = latestDeliveredAidDateMap[fam.familyID]
        val cutoffMillis: Long? = when (exclusionModeValue) {
            ExclusionMode.DAYS -> {
                if (exclusionDaysValue > 0) {
                    System.currentTimeMillis() - (exclusionDaysValue.toLong() * 24L * 60L * 60L * 1000L)
                } else null
            }
            ExclusionMode.SPECIFIC_DATE -> parseIsoDateMillis(exclusionCutoffDateStr)
            else -> null
        }
        if (cutoffMillis != null) {
            val sameTypeMillis = parseIsoDateMillis(sameTypeDate)
            val anyDeliveredMillis = parseIsoDateMillis(anyDeliveredDate)
            if (sameTypeMillis != null && sameTypeMillis >= cutoffMillis) {
                reasons.add("مستبعد بسبب تكرار المساعدة (استلم نفس الصنف بتاريخ ${sameTypeDate?.take(10)})")
            } else if (anyDeliveredMillis != null && anyDeliveredMillis >= cutoffMillis) {
                reasons.add("مستبعد بسبب الاستثناء الزمني (استلم مساعدة مؤخراً بتاريخ ${anyDeliveredDate?.take(10)})")
            }
        }

        // 4. فلتر نوع المساعدة السابقة الديناميكي
        if (aidCategoryEnabled && aidCategoryChips.isNotEmpty()) {
            val receivedCats = familyReceivedAidCategories[fam.familyID] ?: emptySet()
            if (!evaluateMultiValueChipFilter(receivedCats, aidCategoryChips)) {
                val excludedMatched = aidCategoryChips
                    .filterValues { it == ChipFilterState.EXCLUDED }.keys
                    .filter { ex -> receivedCats.any { AidCategoryCatalog.isSameCategory(ex, it) || ex.equals(it, ignoreCase = true) } }
                if (excludedMatched.isNotEmpty()) {
                    reasons.add("مستبعد بسبب تكرار المساعدة السابقة (${excludedMatched.joinToString("، ")})")
                } else {
                    reasons.add("غير مطابق لفلتر نوع المساعدة السابقة")
                }
            }
        }

        // 5. فلتر اعتماد الأشغال
        if (worksEnabled && worksApprovalChips.isNotEmpty()) {
            val key = fam.worksApproval.trim().ifBlank { "غير مصنف" }
            if (!evaluateChipFilter(key, worksApprovalChips)) {
                reasons.add("غير مطابق لشرط اعتماد الأشغال ($key)")
            }
        }

        // 6. فلتر الإيواء
        if (shelterEnabled && shelterChips.isNotEmpty()) {
            val key = fam.shelterStatus.trim().ifBlank { "غير مصنف" }
            if (!evaluateChipFilter(key, shelterChips)) {
                reasons.add("غير مطابق لشرط الإيواء ($key)")
            }
        }

        // 7. فلتر الضرر
        if (damageEnabled && damageChips.isNotEmpty()) {
            val key = fam.damageType.trim().ifBlank { "غير مصنف" }
            if (!evaluateChipFilter(key, damageChips)) {
                reasons.add("غير مطابق لشرط نوع الضرر ($key)")
            }
        }

        // 8. فلتر حالة العمل / الدخل
        val cleanWorkStatus = workStatus.trim()
        if (incomeEnabled && cleanWorkStatus != "الكل" && cleanWorkStatus.isNotEmpty()) {
            val hasIncome = hasValidWorkIncome(fam.incomeSource1) || hasValidWorkIncome(fam.incomeSource2)
            val workPass = when (cleanWorkStatus) {
                "يعمل (لديه دخل)", "يعمل" -> hasIncome
                "لا يعمل (بدون دخل)", "لا يعمل" -> !hasIncome
                else -> true
            }
            if (!workPass) {
                reasons.add("غير مطابق لشرط حالة العمل / الدخل (المطلوب: $cleanWorkStatus)")
            }
        }

        // 9. شرط الأبناء والفئة العمرية
        if (childrenEnabled) {
            val ages = childrenAgesMap[fam.nationalID] ?: emptyList()
            if (ages.none { it in minChildAge..maxChildAge }) {
                reasons.add("غير مطابق لشرط الفئة العمرية للأبناء ($minChildAge - $maxChildAge سنة)")
            }
        }

        // 10. شرط الحالة الاجتماعية
        if (maritalEnabled && maritalStatuses.isNotEmpty()) {
            val statusValue = fam.maritalStatus.trim().ifBlank { "غير مصنف" }
            val isMatch = maritalStatuses.any { it.trim() == statusValue }
            val maritalPass = if (excludeMarital) !isMatch else isMatch
            if (!maritalPass) {
                reasons.add("غير مطابق لشرط الحالة الاجتماعية ($statusValue)")
            }
        }

        // 11. الحد الأدنى لعدد أفراد الأسرة
        if (minMembers > 1 && fam.familyMembersCount < minMembers) {
            reasons.add("عدد أفراد الأسرة (${fam.familyMembersCount}) أقل من الحد الأدنى ($minMembers)")
        }

        return reasons
    }

    /**
     * تدفق الشكاوى المفتوحة مدقّقة تلقائياً مقابل شروط المشروع النشط والفلاتر المختارة وسلة الترشيح الموحدة
     */
    val auditedOpenComplaints: StateFlow<List<AuditedComplaintItem>> = combine(
        openComplaintsFlow,
        selectedProject,
        selectedNominees,
        alreadyNominatedFamilyIds,
        selectedResidencyStatus,
        geoFilterPair,
        dbLocalities,
        shelterChipStates,
        worksApprovalChipStates,
        damageChipStates,
        workStatusFilter,
        shelterFilterEnabled,
        worksApprovalFilterEnabled,
        damageFilterEnabled,
        incomeFilterEnabled,
        aidCategoryFilterContext,
        hasChildrenOnly,
        minChildAgeText,
        maxChildAgeText,
        selectedMaritalStatuses,
        excludeMaritalStatuses,
        maritalStatusFilterEnabled,
        minFamilyMembers,
        exclusionMode,
        exclusionDaysText,
        exclusionDateCutoffText
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val complaints = args[0] as List<FamilyComplaintEntity>
        val project = args[1] as ProjectEntity?
        @Suppress("UNCHECKED_CAST")
        val basket = args[2] as Set<FamilyEntity>
        @Suppress("UNCHECKED_CAST")
        val nominatedIds = args[3] as Set<Long>
        val selectedRes = args[4] as String?
        @Suppress("UNCHECKED_CAST")
        val geoPair = args[5] as Pair<Set<String>, Set<String>>
        @Suppress("UNCHECKED_CAST")
        val locs = args[6] as List<LocalityEntity>
        @Suppress("UNCHECKED_CAST")
        val sChips = args[7] as Map<String, ChipFilterState>
        @Suppress("UNCHECKED_CAST")
        val wChips = args[8] as Map<String, ChipFilterState>
        @Suppress("UNCHECKED_CAST")
        val dChips = args[9] as Map<String, ChipFilterState>
        val workSt = args[10] as String
        val sEn = args[11] as Boolean
        val wEn = args[12] as Boolean
        val dEn = args[13] as Boolean
        val iEn = args[14] as Boolean
        @Suppress("UNCHECKED_CAST")
        val aidCatCtx = args[15] as Triple<Map<String, ChipFilterState>, Boolean, Map<Long, Set<String>>>
        val chEn = args[16] as Boolean
        val minAge = (args[17] as String).toIntOrNull() ?: 0
        val maxAge = (args[18] as String).toIntOrNull() ?: 100
        @Suppress("UNCHECKED_CAST")
        val marStatuses = args[19] as List<String>
        val exMar = args[20] as Boolean
        val marEn = args[21] as Boolean
        val minMem = args[22] as Int
        val exMode = args[23] as ExclusionMode
        val exDays = (args[24] as String).toIntOrNull() ?: 0
        val exCutoff = args[25] as String

        if (complaints.isEmpty()) {
            emptyList()
        } else {
            // استعلام مجزأ (WHERE nationalID IN (...) بحد أقصى 500) لأسر الشكاوى فقط بدلاً من تحميل كامل جدول الأسر
            val complaintNatIds = complaints.map { it.familyId }.distinct()
            val matchedFamiliesByNatId = repository.getFamiliesByNationalIdsMapSync(complaintNatIds)
            val matchedFamilyIds = matchedFamiliesByNatId.values.map { it.familyID }.distinct()
            val matchedFamilyNatIds = matchedFamiliesByNatId.values.map { it.nationalID }.distinct()

            val locsMap = locs.associate { it.LocalityID to it.LocalityName }
            val latestSameTypeMap = project?.aidTypeID?.let {
                repository.getLatestAidDateMapForTypeAndFamiliesSync(it, matchedFamilyIds)
            } ?: emptyMap()
            val latestAnyMap = repository.getLatestDeliveredAidDateMapForFamiliesSync(matchedFamilyIds)
            val chAges = if (chEn) {
                repository.getChildAgesByFamilyNationalIdsSync(matchedFamilyNatIds)
            } else {
                emptyMap()
            }
            val basketFamilyIds = basket.map { it.familyID }.toSet()

            complaints.map { complaint ->
                val normId = ExcelPriorityNominationHelper.normalizeNationalId(complaint.familyId)
                val fam = matchedFamiliesByNatId[normId]
                if (fam == null) {
                    AuditedComplaintItem(
                        complaint = complaint,
                        family = null,
                        isCompliant = false,
                        nonComplianceReasons = listOf("ملف الأسرة غير موجود حالياً في قاعدة بيانات الأسر الرسمية"),
                        isAlreadyNominatedInProject = false,
                        isSelectedInBasket = false
                    )
                } else {
                    val alreadyNom = nominatedIds.contains(fam.familyID)
                    val reasons = if (alreadyNom) {
                        listOf("تم ترشيح الأسرة مسبقاً في هذا المشروع")
                    } else {
                        evaluateFamilyEligibilityReasons(
                            fam = fam,
                            selectedLocalityNames = geoPair.first,
                            selectedBranchNames = geoPair.second,
                            localitiesMap = locsMap,
                            selectedResidency = selectedRes,
                            shelterChips = sChips,
                            worksApprovalChips = wChips,
                            damageChips = dChips,
                            workStatus = workSt,
                            shelterEnabled = sEn,
                            worksEnabled = wEn,
                            damageEnabled = dEn,
                            incomeEnabled = iEn,
                            aidCategoryChips = aidCatCtx.first,
                            aidCategoryEnabled = aidCatCtx.second,
                            familyReceivedAidCategories = aidCatCtx.third,
                            childrenEnabled = chEn,
                            minChildAge = minAge,
                            maxChildAge = maxAge,
                            childrenAgesMap = chAges,
                            maritalStatuses = marStatuses,
                            excludeMarital = exMar,
                            maritalEnabled = marEn,
                            minMembers = minMem,
                            exclusionModeValue = exMode,
                            exclusionDaysValue = exDays,
                            exclusionCutoffDateStr = exCutoff,
                            latestSameTypeAidDateMap = latestSameTypeMap,
                            latestDeliveredAidDateMap = latestAnyMap
                        )
                    }
                    AuditedComplaintItem(
                        complaint = complaint,
                        family = fam,
                        isCompliant = !alreadyNom && reasons.isEmpty(),
                        nonComplianceReasons = reasons,
                        isAlreadyNominatedInProject = alreadyNom,
                        isSelectedInBasket = basketFamilyIds.contains(fam.familyID)
                    )
                }
            }
        }
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * إضافة أو إزالة أسرة من قائمة الشكاوى والأولويات إلى سلة الترشيح الموحدة
     * (يدعم الاستثناء الميداني المباشر حتى لو لم تطابق الأسرة بعض الفلاتر الآلية)
     */
    fun toggleComplaintFamilyInBasket(item: AuditedComplaintItem): Boolean {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return false
        val project = selectedProject.value ?: return false
        if (!project.isOpen) return false
        val fam = item.family ?: return false
        if (alreadyNominatedFamilyIds.value.contains(fam.familyID)) return false

        val current = selectedNominees.value.toMutableSet()
        val sources = _priorityNomineeSources.value.toMutableMap()
        val existing = current.firstOrNull { it.familyID == fam.familyID }
        return if (existing != null) {
            current.remove(existing)
            sources.remove(fam.familyID)
            selectedNominees.value = current
            _priorityNomineeSources.value = sources
            true
        } else {
            if (current.size >= remainingQuota.value) return false
            current.add(fam)
            sources[fam.familyID] = if (item.isCompliant) "شكوى وأولوية" else "شكوى (استثناء ميداني)"
            selectedNominees.value = current
            _priorityNomineeSources.value = sources
            true
        }
    }

    /**
     * تحديد كافة الشكاوى الظاهرة تحت التصنيف الحالي وضمها لسلة الترشيح ضمن السقف المتاح
     */
    fun selectAllFilteredComplaintsToBasket(): Int {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return 0
        val project = selectedProject.value ?: return 0
        if (!project.isOpen) return 0

        val activeCategory = complaintCategoryFilter.value.trim()
        val candidates = auditedOpenComplaints.value.filter { item ->
            (activeCategory.isBlank() || activeCategory == "الكل" ||
                item.complaint.targetAidCategory.trim().equals(activeCategory, ignoreCase = true)) &&
                item.family != null &&
                !item.isAlreadyNominatedInProject
        }
        val current = selectedNominees.value.toMutableSet()
        val currentIds = current.map { it.familyID }.toMutableSet()
        val sources = _priorityNomineeSources.value.toMutableMap()
        val cap = remainingQuota.value
        var addedCount = 0

        for (item in candidates) {
            if (current.size >= cap) break
            val fam = item.family ?: continue
            if (currentIds.add(fam.familyID)) {
                current.add(fam)
                sources[fam.familyID] = if (item.isCompliant) "شكوى وأولوية" else "شكوى (استثناء ميداني)"
                addedCount++
            }
        }
        if (addedCount > 0) {
            selectedNominees.value = current
            _priorityNomineeSources.value = sources
        }
        return addedCount
    }

    /**
     * الترشيح من ملف إكسل / CSV (أولوية) على Dispatchers.IO مع تدقيق شامل وتغذية راجعة تفصيلية لكل صف
     */
    fun processExcelPriorityNomination(
        context: Context,
        uri: Uri,
        fileName: String,
        onError: (String) -> Unit = {}
    ) {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) {
            onError("ليس لديك صلاحية تنفيذ الترشيح")
            return
        }
        val project = selectedProject.value
        if (project == null) {
            onError("يرجى اختيار مشروع مفتوح أولاً قبل استيراد ملف الإكسل")
            return
        }
        if (!project.isOpen) {
            onError("المشروع المختار مغلق ولا يمكن إضافة مرشحين إليه")
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _excelImportInProgress.value = true
            try {
                val parsedRows = ExcelPriorityNominationHelper.parseNationalIdsFromUri(context, uri, fileName)
                if (parsedRows.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        onError("لم يتم العثور على أي أرقام هويات صالحة داخل الملف المختار.")
                    }
                    return@launch
                }

                val locsMap = dbLocalities.value.associate { it.LocalityID to it.LocalityName }
                val alreadyNominatedIds = alreadyNominatedFamilyIds.value

                val effLocs = lockedLocalityName.value?.let { setOf(it) } ?: selectedLocalitiesFilter.value
                val effBrs = lockedBranchName.value?.let { setOf(it) } ?: selectedBranchesFilter.value
                val targetResidency = selectedResidencyStatus.value?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
                val remainingCapacity = repository.computeRemainingQuotaForCurrentUser(project, targetResidency)

                val basket = selectedNominees.value.toMutableSet()
                val basketFamilyIds = basket.map { it.familyID }.toMutableSet()
                val sources = _priorityNomineeSources.value.toMutableMap()

                val seenInFile = HashSet<String>()
                val feedbackList = ArrayList<ExcelNominationFeedback>(parsedRows.size)
                var acceptedCount = 0
                var rejectedCount = 0

                val minAge = minChildAgeText.value.toIntOrNull() ?: 0
                val maxAge = maxChildAgeText.value.toIntOrNull() ?: 100
                val exDays = exclusionDaysText.value.toIntOrNull() ?: 0
                val checkChildrenAges = hasChildrenOnly.value

                // فحص ملف الإكسل على دفعات من 500 رقم هوية بحد أقصى (chunked(500)) لتفادي حد SQLite 999 ومنع امتلاء الرام
                parsedRows.chunked(500).forEach { batchRows ->
                    val batchIds = batchRows.map { it.cleanedNationalId }.distinct()
                    val batchFamiliesByNatId = repository.getFamiliesByNationalIdsMapSync(batchIds)
                    val matchedBatchFamilyIds = batchFamiliesByNatId.values.map { it.familyID }.distinct()
                    val matchedBatchNatIds = batchFamiliesByNatId.values.map { it.nationalID }.distinct()

                    val batchSameTypeMap = repository.getLatestAidDateMapForTypeAndFamiliesSync(
                        aidTypeId = project.aidTypeID,
                        familyIds = matchedBatchFamilyIds
                    )
                    val batchAnyAidMap = repository.getLatestDeliveredAidDateMapForFamiliesSync(matchedBatchFamilyIds)
                    val batchChildAgesMap = if (checkChildrenAges) {
                        repository.getChildAgesByFamilyNationalIdsSync(matchedBatchNatIds)
                    } else {
                        emptyMap()
                    }

                    for (row in batchRows) {
                        val natId = row.cleanedNationalId
                        val fam = batchFamiliesByNatId[natId]
                        val familyName = fam?.name?.ifBlank { "غير مسجل في قاعدة بيانات الأسر" } ?: "غير مسجل في قاعدة بيانات الأسر"
                        val localArea = fam?.currentSubArea?.trim()?.ifBlank { fam.currentMainArea.trim() }?.ifBlank { "غير محدد" } ?: "غير محدد"
                        val familyStatus = if (fam == null) {
                            "غير مسجل"
                        } else {
                            "${fam.socialAffairsStatus.ifBlank { "غير محدد" }} / ${fam.residencyStatus.ifBlank { "غير محدد" }}"
                        }

                        // 1. تكرار داخل ملف الإكسل نفسه
                        if (!seenInFile.add(natId)) {
                            rejectedCount++
                            feedbackList.add(
                                ExcelNominationFeedback(
                                    rowNumber = row.rowNumber,
                                    nationalId = natId,
                                    familyName = familyName,
                                    localArea = localArea,
                                    familyStatus = familyStatus,
                                    isAccepted = false,
                                    feedbackReason = "مكرر داخل ملف الإكسل",
                                    matchedFamilyId = fam?.familyID
                                )
                            )
                            continue
                        }

                        // 2. غير مسجل في قاعدة بيانات الأسر الرسمية
                        if (fam == null) {
                            rejectedCount++
                            feedbackList.add(
                                ExcelNominationFeedback(
                                    rowNumber = row.rowNumber,
                                    nationalId = natId,
                                    familyName = familyName,
                                    localArea = localArea,
                                    familyStatus = familyStatus,
                                    isAccepted = false,
                                    feedbackReason = "غير مسجل في قاعدة بيانات الأسر الرسمية",
                                    matchedFamilyId = null
                                )
                            )
                            continue
                        }

                        // 3. مرشح مسبقاً في قاعدة البيانات لنفس المشروع
                        if (alreadyNominatedIds.contains(fam.familyID)) {
                            rejectedCount++
                            feedbackList.add(
                                ExcelNominationFeedback(
                                    rowNumber = row.rowNumber,
                                    nationalId = natId,
                                    familyName = familyName,
                                    localArea = localArea,
                                    familyStatus = familyStatus,
                                    isAccepted = false,
                                    feedbackReason = "تم ترشيحه مسبقاً في هذا المشروع",
                                    matchedFamilyId = fam.familyID
                                )
                            )
                            continue
                        }

                        // 4. مختار مسبقاً في نفس سلة الترشيح الحالية
                        if (basketFamilyIds.contains(fam.familyID)) {
                            rejectedCount++
                            feedbackList.add(
                                ExcelNominationFeedback(
                                    rowNumber = row.rowNumber,
                                    nationalId = natId,
                                    familyName = familyName,
                                    localArea = localArea,
                                    familyStatus = familyStatus,
                                    isAccepted = false,
                                    feedbackReason = "تم اختياره مسبقاً في نفس كشف الترشيح",
                                    matchedFamilyId = fam.familyID
                                )
                            )
                            continue
                        }

                        // 5. التدقيق الشامل مقابل كافة شروط وفلاتر المشروع النشط
                        val reasons = evaluateFamilyEligibilityReasons(
                            fam = fam,
                            selectedLocalityNames = effLocs,
                            selectedBranchNames = effBrs,
                            localitiesMap = locsMap,
                            selectedResidency = selectedResidencyStatus.value,
                            shelterChips = shelterChipStates.value,
                            worksApprovalChips = worksApprovalChipStates.value,
                            damageChips = damageChipStates.value,
                            workStatus = workStatusFilter.value,
                            shelterEnabled = shelterFilterEnabled.value,
                            worksEnabled = worksApprovalFilterEnabled.value,
                            damageEnabled = damageFilterEnabled.value,
                            incomeEnabled = incomeFilterEnabled.value,
                            aidCategoryChips = aidCategoryChipStates.value,
                            aidCategoryEnabled = aidCategoryFilterEnabled.value,
                            familyReceivedAidCategories = familyReceivedAidCategoriesMap.value,
                            childrenEnabled = checkChildrenAges,
                            minChildAge = minAge,
                            maxChildAge = maxAge,
                            childrenAgesMap = batchChildAgesMap,
                            maritalStatuses = selectedMaritalStatuses.value,
                            excludeMarital = excludeMaritalStatuses.value,
                            maritalEnabled = maritalStatusFilterEnabled.value,
                            minMembers = minFamilyMembers.value,
                            exclusionModeValue = exclusionMode.value,
                            exclusionDaysValue = exDays,
                            exclusionCutoffDateStr = exclusionDateCutoffText.value,
                            latestSameTypeAidDateMap = batchSameTypeMap,
                            latestDeliveredAidDateMap = batchAnyAidMap
                        )

                        if (reasons.isNotEmpty()) {
                            rejectedCount++
                            feedbackList.add(
                                ExcelNominationFeedback(
                                    rowNumber = row.rowNumber,
                                    nationalId = natId,
                                    familyName = familyName,
                                    localArea = localArea,
                                    familyStatus = familyStatus,
                                    isAccepted = false,
                                    feedbackReason = reasons.joinToString(" • "),
                                    matchedFamilyId = fam.familyID
                                )
                            )
                            continue
                        }

                        // 6. فحص السقف المتبقي للحصة
                        if (basket.size >= remainingCapacity) {
                            rejectedCount++
                            feedbackList.add(
                                ExcelNominationFeedback(
                                    rowNumber = row.rowNumber,
                                    nationalId = natId,
                                    familyName = familyName,
                                    localArea = localArea,
                                    familyStatus = familyStatus,
                                    isAccepted = false,
                                    feedbackReason = "تجاوز الحصة المتبقية للمشروع (اكتمل السقف المتاح)",
                                    matchedFamilyId = fam.familyID
                                )
                            )
                            continue
                        }

                        // 7. مقبول ومرشح بأولوية — ضم فوري لسلة الترشيح الموحدة
                        basket.add(fam)
                        basketFamilyIds.add(fam.familyID)
                        sources[fam.familyID] = "ملف إكسل (أولوية)"
                        acceptedCount++
                        feedbackList.add(
                            ExcelNominationFeedback(
                                rowNumber = row.rowNumber,
                                nationalId = natId,
                                familyName = familyName,
                                localArea = localArea,
                                familyStatus = familyStatus,
                                isAccepted = true,
                                feedbackReason = "مطابق لجميع شروط المشروع وتم ضمه للترشيح بأولوية",
                                matchedFamilyId = fam.familyID
                            )
                        )
                    }
                }

                selectedNominees.value = basket
                _priorityNomineeSources.value = sources
                _excelFeedbackResult.value = ExcelNominationResult(
                    fileName = fileName,
                    totalReadCount = parsedRows.size,
                    acceptedCount = acceptedCount,
                    rejectedCount = rejectedCount,
                    feedbackList = feedbackList
                )
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onError("فشل قراءة أو تدقيق ملف الإكسل: ${e.message ?: "خطأ غير متوقع"}")
                }
            } finally {
                _excelImportInProgress.value = false
            }
        }
    }

    // ==========================================
    // حقول ودوال التوافق البرمجي مع الشاشات السابقة
    // ==========================================
    val isFiltering = MutableStateFlow(false)
    val dynamicNominationResult = MutableStateFlow<DynamicNominationResult?>(null)
    val calculatedQuotas = MutableStateFlow<List<LocalityQuota>>(emptyList())
    val filteredEligibleFamilies: StateFlow<List<FamilyEntity>> = filteredFamilies
    val selectedLocalities = MutableStateFlow<Set<String>>(emptySet())
    val excludeLocalities = MutableStateFlow(false)
    val selectedAidCategories = MutableStateFlow<Set<String>>(emptySet())
    val excludeAidCategories = MutableStateFlow(true)
    val selectedDamageTypes = MutableStateFlow<Set<String>>(emptySet())
    val excludeDamageTypes = MutableStateFlow(false)
    val selectedShelterStatuses = MutableStateFlow<Set<String>>(emptySet())
    val excludeShelterStatuses = MutableStateFlow(false)
    val selectedWorksApprovals = MutableStateFlow<Set<String>>(emptySet())
    val excludeWorksApprovals = MutableStateFlow(false)
    val selectedIncomeSources = MutableStateFlow<Set<String>>(emptySet())
    val excludeIncomeSources = MutableStateFlow(false)
    val selectedSubAreas = MutableStateFlow<Set<String>>(emptySet())
    val excludeSubAreas = MutableStateFlow(false)
    val selectedLocalityId = MutableStateFlow(0)
    val excludeLocality = MutableStateFlow(false)
    val statusFilterTab = MutableStateFlow<CandidateStatus?>(null)
    val customLocalityQuotas = MutableStateFlow<Map<String, String>>(emptyMap())

    val localities: StateFlow<List<String>> = combine(
        repository.getDistinctLocalities(),
        canViewAllLocalities
    ) { list, allowAll ->
        val allowedNames = AccessControlManager.getCleanAllowedLocalities()
        val clean = list.map { it.trim() }.filter { it.isNotBlank() }.distinct().let { dbLocs ->
            if (allowedNames.isEmpty()) dbLocs
            else dbLocs.filter { loc -> allowedNames.any { it.equals(loc, ignoreCase = true) } }
        }
        if (allowAll) listOf("الكل") + clean else clean
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pureLocalities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { list ->
            val allowedNames = AccessControlManager.getCleanAllowedLocalities()
            val clean = list.map { it.trim() }.filter { it.isNotBlank() }.distinct()
            if (allowedNames.isEmpty()) clean
            else clean.filter { loc -> allowedNames.any { it.equals(loc, ignoreCase = true) } }
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val pureAidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val shelterStatuses: StateFlow<List<String>> = repository.getDistinctShelterStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val worksApprovals: StateFlow<List<String>> = repository.getDistinctWorksApprovalsFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    fun toggleLocality(name: String) = cycleChipState("locality", name)
    fun toggleCategory(cat: String) {
        val cur = selectedAidCategories.value.toMutableSet()
        if (cur.contains(cat)) cur.remove(cat) else cur.add(cat)
        selectedAidCategories.value = cur
    }
    fun clearCategories() {
        selectedAidCategories.value = emptySet()
    }
    fun toggleDamageType(type: String) {
        val cur = selectedDamageTypes.value.toMutableSet()
        if (cur.contains(type)) cur.remove(type) else cur.add(type)
        selectedDamageTypes.value = cur
        cycleChipState("damage", type)
    }
    fun clearDamageTypes() {
        selectedDamageTypes.value = emptySet()
        damageChipStates.value = emptyMap()
    }
    fun toggleShelterStatus(status: String) {
        val cur = selectedShelterStatuses.value.toMutableSet()
        if (cur.contains(status)) cur.remove(status) else cur.add(status)
        selectedShelterStatuses.value = cur
        cycleChipState("shelter", status)
    }
    fun clearShelterStatuses() {
        selectedShelterStatuses.value = emptySet()
        shelterChipStates.value = emptyMap()
    }
    fun toggleWorksApproval(approval: String) {
        val cur = selectedWorksApprovals.value.toMutableSet()
        if (cur.contains(approval)) cur.remove(approval) else cur.add(approval)
        selectedWorksApprovals.value = cur
    }
    fun clearWorksApprovals() {
        selectedWorksApprovals.value = emptySet()
    }
    fun toggleMaritalStatus(status: String) {
        val clean = status.trim()
        if (clean.isBlank()) return
        val cur = selectedMaritalStatuses.value.toMutableList()
        if (cur.contains(clean)) cur.remove(clean) else cur.add(clean)
        selectedMaritalStatuses.value = cur
    }
    fun clearMaritalStatuses() {
        selectedMaritalStatuses.value = emptyList()
    }
    fun setExcludeMaritalStatuses(exclude: Boolean) {
        excludeMaritalStatuses.value = exclude
    }
    fun setMaritalStatusFilterEnabled(enabled: Boolean) {
        maritalStatusFilterEnabled.value = enabled
    }
    fun toggleIncomeSource(source: String) {
        val cur = selectedIncomeSources.value.toMutableSet()
        if (cur.contains(source)) cur.remove(source) else cur.add(source)
        selectedIncomeSources.value = cur
    }
    fun clearIncomeSources() {
        selectedIncomeSources.value = emptySet()
    }
    fun toggleSubArea(area: String) {
        val cur = selectedSubAreas.value.toMutableSet()
        if (cur.contains(area)) cur.remove(area) else cur.add(area)
        selectedSubAreas.value = cur
    }
    fun clearSubAreas() {
        selectedSubAreas.value = emptySet()
    }
    fun resetFilters() {
        clearAllFilterChips()
        selectedLocalities.value = emptySet()
        excludeLocalities.value = false
        selectedAidCategories.value = emptySet()
        excludeAidCategories.value = true
        selectedDamageTypes.value = emptySet()
        excludeDamageTypes.value = false
        selectedShelterStatuses.value = emptySet()
        excludeShelterStatuses.value = false
        selectedWorksApprovals.value = emptySet()
        excludeWorksApprovals.value = false
        selectedMaritalStatuses.value = emptyList()
        excludeMaritalStatuses.value = false
        maritalStatusFilterEnabled.value = true
        _workStatusFilter.value = "الكل"
        selectedIncomeSources.value = emptySet()
        excludeIncomeSources.value = false
        selectedSubAreas.value = emptySet()
        excludeSubAreas.value = false
        selectedLocalityId.value = 0
        excludeLocality.value = false
        selectedLocalitiesFilter.value = lockedLocalityName.value?.let { setOf(it) } ?: emptySet()
        selectedBranchesFilter.value = lockedBranchName.value?.let { setOf(it) } ?: emptySet()
        selectedLocalityFilter.value = lockedLocalityName.value ?: ""
        selectedBranchFilter.value = lockedBranchName.value ?: ""
        aidCategoryChipStates.value = emptyMap()
        aidCategoryFilterEnabled.value = true
        statusFilterTab.value = null
    }

    private var filteringJob: Job? = null

    fun clearState() {
        refreshOptionsJob?.cancel()
        autoNominationJob?.cancel()
        filteringJob?.cancel()
        selectedNominees.value = emptySet()
        selectedProject.value = null
        dynamicNominationResult.value = null
        calculatedQuotas.value = emptyList()
        customLocalityQuotas.value = emptyMap()
        isFiltering.value = false
        resetFilters()
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    fun runFilteringEngine() {
        filteringJob?.cancel()
        filteringJob = viewModelScope.launch {
            isFiltering.value = true
            try {
                val excludedIds = if (selectedAidCategories.value.isNotEmpty()) {
                    activeAidTypes.value
                        .filter { type ->
                            selectedAidCategories.value.any { sel ->
                                AidCategoryCatalog.isSameCategory(sel, type.aidTypeName) ||
                                    sel.equals(type.aidTypeName, ignoreCase = true)
                            }
                        }
                        .map { it.aidTypeID }
                        .toSet()
                } else {
                    emptySet()
                }
                val requestedTarget = targetBeneficiariesText.value.toIntOrNull() ?: 100
                val requestedLimit = resultLimitText.value.toIntOrNull() ?: 300
                val activeDynProject = dynamicSelectedProject.value
                val effReg = effectiveUserRegion.value
                val effSubReg = effectiveUserSubRegion.value
                val restricted = isGeoRestrictedUser.value
                val targetResidency = selectedResidencyStatus.value?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
                val remQuota = if (activeDynProject != null && activeDynProject.targetQuota > 0) {
                    repository.computeRemainingQuotaForCurrentUser(activeDynProject, targetResidency)
                } else {
                    null
                }
                val effectiveTarget = if (remQuota != null) {
                    if (restricted) requestedTarget.coerceAtMost(remQuota) else requestedTarget.coerceAtMost(remQuota)
                } else {
                    requestedTarget
                }
                val effectiveSqlLimit = if (remQuota != null && restricted) {
                    requestedLimit.coerceAtMost(remQuota)
                } else {
                    requestedLimit
                }
                val criteria = DynamicNominationCriteria(
                    exclusionMode = exclusionMode.value,
                    exclusionDays = exclusionDaysText.value.toIntOrNull(),
                    exclusionDateCutoff = exclusionDateCutoffText.value.takeIf { it.isNotBlank() },
                    excludedAidTypeIds = excludedIds,
                    hasChildrenOnly = hasChildrenOnly.value,
                    minChildAge = minChildAgeText.value.toIntOrNull(),
                    maxChildAge = maxChildAgeText.value.toIntOrNull(),
                    selectedDamageTypes = selectedDamageTypes.value,
                    excludeDamageTypes = excludeDamageTypes.value,
                    selectedMaritalStatuses = if (maritalStatusFilterEnabled.value) selectedMaritalStatuses.value.toSet() else emptySet(),
                    excludeMaritalStatuses = excludeMaritalStatuses.value,
                    selectedWorksApprovals = selectedWorksApprovals.value,
                    excludeWorksApprovals = excludeWorksApprovals.value,
                    selectedShelterStatuses = selectedShelterStatuses.value,
                    excludeShelterStatuses = excludeShelterStatuses.value,
                    workStatusFilter = if (incomeFilterEnabled.value) _workStatusFilter.value else "الكل",
                    selectedIncomeSources = selectedIncomeSources.value,
                    excludeIncomeSources = excludeIncomeSources.value,
                    selectedSubAreas = selectedSubAreas.value,
                    excludeSubAreas = excludeSubAreas.value,
                    selectedLocalityId = selectedLocalityId.value,
                    excludeLocality = excludeLocality.value,
                    selectedAidTypeId = selectedAidTypeId.value,
                    projectId = selectedProjectId.value,
                    minFamilyMembers = minFamilyMembers.value,
                    limit = effectiveSqlLimit,
                    targetBeneficiaries = effectiveTarget,
                    enforceScopeRestriction = restricted,
                    userRegion = effReg,
                    userSubRegion = effSubReg
                )
                val result = repository.runDynamicNomination(criteria)
                dynamicNominationResult.value = result
                if (result.quotas.isNotEmpty()) {
                    calculatedQuotas.value = result.quotas
                }
            } finally {
                isFiltering.value = false
            }
        }
    }

    class Factory(
        private val repository: AidRepository,
        private val initialAssignedSubRegion: String = "All"
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NominationViewModel(repository, initialAssignedSubRegion) as T
        }
    }
}
