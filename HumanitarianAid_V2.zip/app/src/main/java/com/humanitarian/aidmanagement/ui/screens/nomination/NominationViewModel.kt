package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.local.entities.donor
import com.humanitarian.aidmanagement.data.local.entities.isOpen
import com.humanitarian.aidmanagement.data.local.entities.residencyStatus
import com.humanitarian.aidmanagement.data.local.entities.socialAffairsStatus
import com.humanitarian.aidmanagement.data.local.entities.targetQuota
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.CandidateStatus
import com.humanitarian.aidmanagement.engine.DynamicCandidateModel
import com.humanitarian.aidmanagement.engine.DynamicNominationCriteria
import com.humanitarian.aidmanagement.engine.DynamicNominationResult
import com.humanitarian.aidmanagement.engine.ExclusionMode
import com.humanitarian.aidmanagement.engine.LocalityQuota
import com.humanitarian.aidmanagement.security.AccessControlManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * حالة شريحة الفلترة متعددة الحالات (Multi-State FilterChip)
 * 3 حالات: غير محدد، متضمن (أخضر)، مستثنى (أحمر)
 */
enum class ChipFilterState {
    UNSELECTED,
    INCLUDED, // تضمين (Checkmark)
    EXCLUDED  // استثناء (Cross)
}

/**
 * إحصائية حصة المحلية المعتمدة والترشيح الفعلي والعجز/الفائض
 */
data class LocalityQuotaStatsItem(
    val localityName: String,
    val baseX: Int,
    val totalBase: Int,
    val percentage: Double,
    val targetQuota: Int,
    val nominatedCount: Int
) {
    val shortageExcess: Int get() = nominatedCount - targetQuota
    val isComplete: Boolean get() = nominatedCount >= targetQuota && targetQuota > 0
    val formattedPercentage: String get() = String.format(Locale.US, "%.1f%%", percentage)
}

/**
 * MASTER ARCHITECTURE V3.0: THE ULTIMATE HYBRID NOMINATION VIEWMODEL
 * يدمج إدارة الوصول الجغرافي (RBAC)، الحسابات الرياضية للتوزيع النسبي،
 * وفلاتر الشرائح ثلاثية الحالات والاختيار الهجين المحمي بالأقفال.
 */
class NominationViewModel(
    val repository: AidRepository,
    initialAssignedSubRegion: String = "All"
) : ViewModel() {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    // ==========================================
    // MODULE 2: GEOGRAPHICAL RBAC (المنطقة المخصصة)
    // ==========================================
    val assignedSubRegion = MutableStateFlow(initialAssignedSubRegion)

    fun setAssignedSubRegion(region: String) {
        assignedSubRegion.value = region.ifBlank { "All" }
    }

    // ==========================================
    // تدفقات قاعدة البيانات والمشاريع
    // ==========================================
    val allActiveProjects: StateFlow<List<ProjectEntity>> = repository.getActiveProjects()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Step 1: المشاريع المفتوحة حصراً للترشيح (isOpen == true)
    val openProjects: StateFlow<List<ProjectEntity>> = repository.getActiveProjects()
        .map { list -> list.filter { it.isOpen } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAidTypes: StateFlow<List<AidTypeEntity>> = repository.getActiveAidTypes()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dbLocalities: StateFlow<List<LocalityEntity>> = repository.getLocalities()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * تدفق السجلات ذات حالة 'مرشح' التي تنتظر الترحيل والاعتماد الرسمي
     */
    val nominatedRecords: StateFlow<List<AidRecordEntity>> = flow {
        emit(repository.getNominatedRecordsSync())
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // المشروع المختار حالياً
    val selectedProject = MutableStateFlow<ProjectEntity?>(null)

    // وضع القراءة فقط (إذا تم فتح مشروع مقفل isOpen == false)
    val isReadOnlyMode: StateFlow<Boolean> = selectedProject.map { project ->
        project != null && !project.isOpen
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // ==========================================
    // تدفق الأسر المصفى جغرافياً من المصدر (RBAC Pre-Filtered Master Stream: محليات + شعب)
    // ==========================================
    val rbacFamiliesStream: StateFlow<List<FamilyEntity>> = combine(
        repository.getFamiliesRestrictedFlow(),
        assignedSubRegion,
        repository.currentUserFlow,
        dbLocalities
    ) { families, region, user, locs ->
        if (user == null) return@combine emptyList()
        val localitiesMap = locs.associate { it.LocalityID to it.LocalityName }
        val extraLocIds = repository.getCurrentUserLocalityIds()
        val rlsFiltered = if (repository.isSuperAdmin()) {
            families
        } else {
            families.filter { fam ->
                AccessControlManager.isFamilyAllowed(fam, localitiesMap, extraLocIds)
            }
        }
        val effectiveRegion = region.trim()
        val isSubRegionRestricted = !repository.isSuperAdmin() &&
            effectiveRegion.isNotBlank() &&
            !effectiveRegion.equals("All", ignoreCase = true) &&
            effectiveRegion != "الكل" &&
            effectiveRegion != "*"
        if (isSubRegionRestricted) {
            rlsFiltered.filter { fam ->
                fam.currentSubArea.equals(effectiveRegion, ignoreCase = true) ||
                    fam.currentMainArea.equals(effectiveRegion, ignoreCase = true) ||
                    localitiesMap[fam.localityID]?.equals(effectiveRegion, ignoreCase = true) == true
            }
        } else {
            rlsFiltered
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val canViewAllLocalities: StateFlow<Boolean> = combine(
        repository.currentUserFlow,
        assignedSubRegion
    ) { user, region ->
        if (user == null) false
        else if (repository.isSuperAdmin()) true
        else {
            val cleanAllowedNames = AccessControlManager.getCleanAllowedLocalities()
            val hasLocIdRestriction = user.AllowedLocalityID > 0 ||
                repository.getCurrentUserLocalityIds().any { it > 0 }
            val hasSubAreaRestriction = region.trim().let {
                it.isNotBlank() && !it.equals("All", ignoreCase = true) && it != "الكل" && it != "*"
            }
            cleanAllowedNames.isEmpty() && !hasLocIdRestriction && !hasSubAreaRestriction
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val lockedLocalityName: StateFlow<String?> = combine(
        repository.currentUserFlow,
        repository.getAllowedLocalitiesFlow(),
        assignedSubRegion
    ) { user, allowedLocEntities, region ->
        if (user == null || repository.isSuperAdmin()) {
            null
        } else {
            val cleanAllowedNames = AccessControlManager.getCleanAllowedLocalities()
            val hasLocIdRestriction = user.AllowedLocalityID > 0 ||
                repository.getCurrentUserLocalityIds().any { it > 0 }
            val resolvedNames = cleanAllowedNames.ifEmpty {
                if (hasLocIdRestriction) allowedLocEntities.map { it.LocalityName.trim() }.filter { it.isNotBlank() } else emptyList()
            }.distinct()
            val cleanRegion = region.trim().takeIf {
                it.isNotBlank() && !it.equals("All", ignoreCase = true) && it != "الكل" && it != "*"
            }
            when {
                resolvedNames.size == 1 -> resolvedNames.first()
                resolvedNames.isEmpty() && cleanRegion != null -> cleanRegion
                else -> null
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isLocalityLocked: StateFlow<Boolean> = lockedLocalityName
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val allowedBranches: StateFlow<List<String>> = repository.currentUserFlow
        .map { AccessControlManager.getCleanAllowedBranches() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val canNominate: StateFlow<Boolean> = repository.currentUserFlow
        .map { user ->
            user != null && (repository.isSuperAdmin() || AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // ==========================================
    // MODULE 3: PROPORTIONAL DISTRIBUTION MATH (التوزيع النسبي)
    // القاعدة الرياضية الصارمة: (socialAffairsStatus == "معتمد" AND residencyStatus == "مقيم")
    // ==========================================
    val localityQuotasMap: StateFlow<Map<String, Int>> = combine(
        rbacFamiliesStream,
        selectedProject
    ) { families, project ->
        if (project == null || project.targetQuota <= 0) {
            emptyMap()
        } else {
            // تصفية أسر القاعدة الأساسية المؤهلة للحساب النسبي
            val baseFamilies = families.filter { fam ->
                fam.socialAffairsStatus.trim() == "معتمد" && fam.residencyStatus.trim() == "مقيم"
            }
            val totalBase = baseFamilies.size
            if (totalBase == 0) {
                emptyMap()
            } else {
                val groups = baseFamilies.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }
                groups.mapValues { (_, list) ->
                    val baseX = list.size
                    Math.round((baseX.toDouble() / totalBase.toDouble()) * project.targetQuota).toInt()
                }
            }
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // ==========================================
    // MODULE 4: THE SUPER DYNAMIC FILTER ENGINE (100% Data-Driven from DAO DISTINCT Queries)
    // ==========================================
    private val _dynamicShelterOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicShelterOptions: StateFlow<List<String>> = _dynamicShelterOptions.asStateFlow()

    private val _dynamicWorksApprovalOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicWorksApprovalOptions: StateFlow<List<String>> = _dynamicWorksApprovalOptions.asStateFlow()

    private val _dynamicDamageOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicDamageOptions: StateFlow<List<String>> = _dynamicDamageOptions.asStateFlow()

    private val _dynamicIncomeOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicIncomeOptions: StateFlow<List<String>> = _dynamicIncomeOptions.asStateFlow()

    private val _dynamicSubAreaOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicSubAreaOptions: StateFlow<List<String>> = _dynamicSubAreaOptions.asStateFlow()

    private val _dynamicMaritalStatusOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicMaritalStatusOptions: StateFlow<List<String>> = _dynamicMaritalStatusOptions.asStateFlow()

    private val _dynamicLocalities = MutableStateFlow<List<String>>(emptyList())
    val dynamicLocalities: StateFlow<List<String>> = _dynamicLocalities.asStateFlow()

    private val _dynamicBranches = MutableStateFlow<List<String>>(emptyList())
    val dynamicBranches: StateFlow<List<String>> = _dynamicBranches.asStateFlow()

    private var refreshOptionsJob: Job? = null

    fun refreshDynamicFilterOptions() {
        refreshOptionsJob?.cancel()
        refreshOptionsJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val isAdmin = repository.isSuperAdmin()
                val allowedLocNames = AccessControlManager.getCleanAllowedLocalities()
                val allowedBranchNames = AccessControlManager.getCleanAllowedBranches()
                val regionFilter = assignedSubRegion.value.trim()
                val hasRegionFilter = !isAdmin &&
                    regionFilter.isNotBlank() &&
                    !regionFilter.equals("All", ignoreCase = true) &&
                    regionFilter != "الكل" &&
                    regionFilter != "*"

                val shelter = repository.getDistinctShelterStatusesRestrictedSync()
                val works = repository.getDistinctWorksApprovalsRestrictedSync()
                val damage = repository.getDistinctDamageTypesRestrictedSync()
                val income = repository.getDistinctIncomeSourcesRestrictedSync()
                val marital = repository.getDistinctMaritalStatusesRestrictedSync()

                val dbSubAreas = repository.getDistinctCurrentSubAreasRestrictedSync()
                val intersectedSubAreas = dbSubAreas.filter { sub ->
                    val matchesAllowedLoc = isAdmin || allowedLocNames.isEmpty() ||
                        allowedLocNames.any { it.equals(sub, ignoreCase = true) }
                    val matchesRegion = !hasRegionFilter || sub.equals(regionFilter, ignoreCase = true)
                    matchesAllowedLoc && matchesRegion
                }

                val dbLocalitiesList = repository.getDistinctLocalitiesRestrictedSync()
                val intersectedLocalities = dbLocalitiesList.filter { loc ->
                    val matchesAllowedLoc = isAdmin || allowedLocNames.isEmpty() ||
                        allowedLocNames.any { it.equals(loc, ignoreCase = true) }
                    val matchesRegion = !hasRegionFilter || loc.equals(regionFilter, ignoreCase = true)
                    matchesAllowedLoc && matchesRegion
                }

                val dbBranchesList = repository.getAllDistinctBranches()
                val intersectedBranches = if (isAdmin || allowedBranchNames.isEmpty()) {
                    dbBranchesList
                } else {
                    dbBranchesList.filter { br ->
                        allowedBranchNames.any { it.equals(br, ignoreCase = true) }
                    }
                }

                _dynamicShelterOptions.value = shelter
                _dynamicWorksApprovalOptions.value = works
                _dynamicDamageOptions.value = damage
                _dynamicIncomeOptions.value = income
                _dynamicSubAreaOptions.value = intersectedSubAreas
                _dynamicMaritalStatusOptions.value = marital
                _dynamicLocalities.value = intersectedLocalities
                _dynamicBranches.value = intersectedBranches
            } catch (_: Exception) {
                // Keep previous valid lists on transient cancellation
            }
        }
    }

    init {
        refreshDynamicFilterOptions()
        viewModelScope.launch(Dispatchers.IO) {
            combine(repository.currentUserFlow, assignedSubRegion) { user, region ->
                user?.UserID to region
            }.distinctUntilChanged().drop(1).collect {
                refreshDynamicFilterOptions()
            }
        }
    }

    // حالات الشرائح متعددة الحالات (Multi-State Filter Chips)
    val shelterChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val worksApprovalChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val damageChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val incomeChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val localityChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())

    // MISSION 1: WHOLE FILTER BYPASS (TOGGLE SWITCHES)
    val shelterFilterEnabled = MutableStateFlow(true)
    val worksApprovalFilterEnabled = MutableStateFlow(true)
    val damageFilterEnabled = MutableStateFlow(true)
    val incomeFilterEnabled = MutableStateFlow(true)
    val localityFilterEnabled = MutableStateFlow(true)
    val selectedMaritalStatuses = MutableStateFlow<List<String>>(emptyList())
    val excludeMaritalStatuses = MutableStateFlow(false)
    val maritalStatusFilterEnabled = MutableStateFlow(true)

    val binaryIncomeOption = MutableStateFlow<String?>(null)

    fun setShelterFilterEnabled(enabled: Boolean) { shelterFilterEnabled.value = enabled }
    fun setWorksApprovalFilterEnabled(enabled: Boolean) { worksApprovalFilterEnabled.value = enabled }
    fun setDamageFilterEnabled(enabled: Boolean) { damageFilterEnabled.value = enabled }
    fun setIncomeFilterEnabled(enabled: Boolean) { incomeFilterEnabled.value = enabled }
    fun setLocalityFilterEnabled(enabled: Boolean) { localityFilterEnabled.value = enabled }

    fun setBinaryIncomeOption(option: String?) {
        binaryIncomeOption.value = option
    }

    fun toggleBinaryIncomeOption(option: String) {
        binaryIncomeOption.value = if (binaryIncomeOption.value == option) null else option
    }

    // فلاتر الاستثناء الزمني وحجم الأسرة وفلترة الأطفال بالأعمار
    val exclusionMode = MutableStateFlow(ExclusionMode.DAYS)
    val exclusionDaysText = MutableStateFlow("30")
    val exclusionDateCutoffText = MutableStateFlow("")
    val hasChildrenOnly = MutableStateFlow(false)
    val minChildAgeText = MutableStateFlow("0")
    val maxChildAgeText = MutableStateFlow("18")
    val minFamilyMembers = MutableStateFlow(1)
    val searchQuery = MutableStateFlow("")

    fun setHasChildrenOnly(enabled: Boolean) { hasChildrenOnly.value = enabled }
    fun setChildAgeRange(min: String, max: String) {
        minChildAgeText.value = min
        maxChildAgeText.value = max
    }

    // تدفق أعمار الأطفال لكل أسرة لحساب الفلترة العمرية الفورية
    @OptIn(ExperimentalCoroutinesApi::class)
    private val allChildrenFlow: Flow<List<com.humanitarian.aidmanagement.data.local.entities.ChildEntity>> =
        repository.currentUserFlow.flatMapLatest {
            flow { emit(repository.getAllChildrenSync()) }
        }.flowOn(Dispatchers.IO)

    val familyChildrenAgesMap: StateFlow<Map<String, List<Int>>> = allChildrenFlow.map { children ->
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        children.groupBy({ it.familyNationalID }) { child ->
            val birthYear = child.birthDate.take(4).toIntOrNull() ?: currentYear
            (currentYear - birthYear).coerceAtLeast(0)
        }
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // تبديل حالة الشريحة: غير محدد -> متضمن (أخضر) -> مستثنى (أحمر) -> غير محدد
    fun cycleChipState(category: String, key: String) {
        val targetFlow = when (category) {
            "shelter" -> shelterChipStates
            "worksApproval" -> worksApprovalChipStates
            "damage" -> damageChipStates
            "income" -> incomeChipStates
            "locality" -> localityChipStates
            else -> return
        }
        val current = targetFlow.value.toMutableMap()
        val nextState = when (current[key] ?: ChipFilterState.UNSELECTED) {
            ChipFilterState.UNSELECTED -> ChipFilterState.INCLUDED
            ChipFilterState.INCLUDED -> ChipFilterState.EXCLUDED
            ChipFilterState.EXCLUDED -> ChipFilterState.UNSELECTED
        }
        if (nextState == ChipFilterState.UNSELECTED) {
            current.remove(key)
        } else {
            current[key] = nextState
        }
        targetFlow.value = current
    }

    fun clearAllFilterChips() {
        shelterChipStates.value = emptyMap()
        worksApprovalChipStates.value = emptyMap()
        damageChipStates.value = emptyMap()
        incomeChipStates.value = emptyMap()
        localityChipStates.value = emptyMap()
        shelterFilterEnabled.value = true
        worksApprovalFilterEnabled.value = true
        damageFilterEnabled.value = true
        incomeFilterEnabled.value = true
        localityFilterEnabled.value = true
        binaryIncomeOption.value = null
        exclusionMode.value = ExclusionMode.DAYS
        exclusionDaysText.value = "30"
        exclusionDateCutoffText.value = ""
        hasChildrenOnly.value = false
        minChildAgeText.value = "0"
        maxChildAgeText.value = "18"
        minFamilyMembers.value = 1
        searchQuery.value = ""
        selectedMaritalStatuses.value = emptyList()
        excludeMaritalStatuses.value = false
        maritalStatusFilterEnabled.value = true
    }

    // ==========================================
    // MODULE 5: SMART HYBRID SELECTION & DASHBOARD (The Core)
    // ==========================================
    // الأسر المختارة للترشيح الفعلي (Selected Nominees)
    val selectedNominees = MutableStateFlow<Set<FamilyEntity>>(emptySet())

    // تدفق الأسر المطابقة للشروط الصارمة (Filtered Families) مرتبة تنازلياً حسب حجم الأسرة
    val filteredFamilies: StateFlow<List<FamilyEntity>> = combine(
        rbacFamiliesStream,
        selectedProject,
        shelterChipStates,
        worksApprovalChipStates,
        damageChipStates,
        incomeChipStates,
        binaryIncomeOption,
        localityChipStates,
        shelterFilterEnabled,
        worksApprovalFilterEnabled,
        damageFilterEnabled,
        incomeFilterEnabled,
        localityFilterEnabled,
        minFamilyMembers,
        hasChildrenOnly,
        minChildAgeText,
        maxChildAgeText,
        familyChildrenAgesMap,
        selectedMaritalStatuses,
        excludeMaritalStatuses,
        maritalStatusFilterEnabled
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val families = args[0] as List<FamilyEntity>
        val project = args[1] as ProjectEntity?
        val shelterChips = args[2] as Map<String, ChipFilterState>
        val worksChips = args[3] as Map<String, ChipFilterState>
        val damageChips = args[4] as Map<String, ChipFilterState>
        val incomeChips = args[5] as Map<String, ChipFilterState>
        val binaryIncome = args[6] as String?
        val localityChips = args[7] as Map<String, ChipFilterState>
        val shelterEnabled = args[8] as Boolean
        val worksEnabled = args[9] as Boolean
        val damageEnabled = args[10] as Boolean
        val incomeEnabled = args[11] as Boolean
        val localityEnabled = args[12] as Boolean
        val minMembers = args[13] as Int
        val childrenEnabled = args[14] as Boolean
        val minAgeStr = args[15] as String
        val maxAgeStr = args[16] as String
        val childrenAges = args[17] as Map<String, List<Int>>
        val maritalStatuses = args[18] as List<String>
        val excludeMarital = args[19] as Boolean
        val maritalEnabled = args[20] as Boolean

        executeCascadingFilter(
            families = families,
            project = project,
            shelterChips = shelterChips,
            worksApprovalChips = worksChips,
            damageChips = damageChips,
            incomeChips = incomeChips,
            binaryIncome = binaryIncome,
            localityChips = localityChips,
            shelterEnabled = shelterEnabled,
            worksApprovalEnabled = worksEnabled,
            damageEnabled = damageEnabled,
            incomeEnabled = incomeEnabled,
            localityEnabled = localityEnabled,
            minMembers = minMembers,
            childrenFilterEnabled = childrenEnabled,
            minChildAge = minAgeStr.toIntOrNull() ?: 0,
            maxChildAge = maxAgeStr.toIntOrNull() ?: 18,
            childrenAgesMap = childrenAges,
            selectedMaritalStatuses = maritalStatuses,
            excludeMaritalStatuses = excludeMarital,
            maritalStatusEnabled = maritalEnabled
        )
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // لوحة مراجعة الحصص النسبية مقارنة بالمرشحين الفعليين
    val localityQuotaStats: StateFlow<List<LocalityQuotaStatsItem>> = combine(
        rbacFamiliesStream,
        selectedProject,
        localityQuotasMap,
        selectedNominees
    ) { families, project, quotasMap, nominees ->
        if (project == null) {
            emptyList()
        } else {
            val baseFamilies = families.filter { fam ->
                fam.socialAffairsStatus.trim() == "معتمد" && fam.residencyStatus.trim() == "مقيم"
            }
            val totalBase = baseFamilies.size
            val groups = baseFamilies.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }
            val nomineesByLocality = nominees.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }

            groups.map { (locName, list) ->
                val baseX = list.size
                val quota = quotasMap[locName] ?: 0
                val nominated = nomineesByLocality[locName]?.size ?: 0
                val pct = if (totalBase > 0) (baseX.toDouble() / totalBase.toDouble()) * 100.0 else 0.0
                LocalityQuotaStatsItem(
                    localityName = locName,
                    baseX = baseX,
                    totalBase = totalBase,
                    percentage = pct,
                    targetQuota = quota,
                    nominatedCount = nominated
                )
            }.sortedByDescending { it.targetQuota }
        }
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * فلترة السلاسل المجمعة (Cascading Filter Execution)
     * مع مفاتيح التجاوز (Bypass Switches) والفلتر الثنائي للدخل (Binary Income) وفلترة عمر الأبناء
     */
    private fun executeCascadingFilter(
        families: List<FamilyEntity>,
        project: ProjectEntity?,
        shelterChips: Map<String, ChipFilterState>,
        worksApprovalChips: Map<String, ChipFilterState>,
        damageChips: Map<String, ChipFilterState>,
        incomeChips: Map<String, ChipFilterState>,
        binaryIncome: String?,
        localityChips: Map<String, ChipFilterState>,
        shelterEnabled: Boolean,
        worksApprovalEnabled: Boolean,
        damageEnabled: Boolean,
        incomeEnabled: Boolean,
        localityEnabled: Boolean,
        minMembers: Int = minFamilyMembers.value,
        childrenFilterEnabled: Boolean = false,
        minChildAge: Int = 0,
        maxChildAge: Int = 18,
        childrenAgesMap: Map<String, List<Int>> = emptyMap(),
        selectedMaritalStatuses: List<String> = emptyList(),
        excludeMaritalStatuses: Boolean = false,
        maritalStatusEnabled: Boolean = true
    ): List<FamilyEntity> {
        return families.asSequence()
            // 1. الشرط الإلزامي الصارم: (معتمد AND مقيم)
            .filter { fam ->
                fam.socialAffairsStatus.trim() == "معتمد" && fam.residencyStatus.trim() == "مقيم"
            }
            // 2. فلتر اعتماد الأشغال مع مفتاح التجاوز (Works Approval Bypass)
            .filter { fam ->
                if (!worksApprovalEnabled) true
                else {
                    val key = fam.worksApproval.trim().ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, worksApprovalChips)
                }
            }
            // 3. فلتر شرائح الإيواء ثلاثية الحالات مع مفتاح التجاوز (Bypass)
            .filter { fam ->
                if (!shelterEnabled) true
                else {
                    val key = fam.shelterStatus.trim().ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, shelterChips)
                }
            }
            // 4. فلتر شرائح الضرر مع مفتاح التجاوز (Bypass)
            .filter { fam ->
                if (!damageEnabled) true
                else {
                    val key = fam.damageType.trim().ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, damageChips)
                }
            }
            // 5. فلتر مصادر الدخل الديناميكي ثلاثي الحالات مع مفتاح التجاوز (Bypass)
            .filter { fam ->
                if (!incomeEnabled) {
                    true
                } else if (incomeChips.isNotEmpty()) {
                    val values = listOfNotNull(
                        fam.incomeSource1.trim().ifBlank { null },
                        fam.incomeSource2?.trim()?.ifBlank { null }
                    ).ifEmpty { listOf("غير مصنف") }
                    val included = incomeChips.filter { it.value == ChipFilterState.INCLUDED }.keys
                    val excluded = incomeChips.filter { it.value == ChipFilterState.EXCLUDED }.keys
                    if (values.any { excluded.contains(it) }) false
                    else if (included.isNotEmpty() && values.none { included.contains(it) }) false
                    else true
                } else if (!binaryIncome.isNullOrBlank()) {
                    val isEmployed1 = !fam.incomeSource1.isNullOrBlank() &&
                            fam.incomeSource1.trim() != "بلا عمل" &&
                            fam.incomeSource1.trim() != "بدون عمل" &&
                            fam.incomeSource1.trim() != "لا يوجد"
                    val isEmployed2 = !fam.incomeSource2.isNullOrBlank() &&
                            fam.incomeSource2?.trim() != "بلا عمل" &&
                            fam.incomeSource2?.trim() != "بدون عمل" &&
                            fam.incomeSource2?.trim() != "لا يوجد"
                    val hasIncome = isEmployed1 || isEmployed2
                    if (binaryIncome == "يعمل") hasIncome else !hasIncome
                } else {
                    true
                }
            }
            // 6. فلتر شرائح المحليات/المناطق مع مفتاح التجاوز (Bypass) - فحص صارم للمنطقة الفرعية الحالية
            .filter { fam ->
                if (!localityEnabled) true
                else {
                    val key = fam.currentSubArea.ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, localityChips)
                }
            }
            // 7. شرط وجود الأبناء ونطاق الأعمار مع مفتاح التجاوز (Children & Age Range Filter)
            .filter { fam ->
                if (!childrenFilterEnabled) true
                else {
                    val ages = childrenAgesMap[fam.nationalID] ?: emptyList()
                    ages.any { it in minChildAge..maxChildAge }
                }
            }
            // 8. فلتر الحالة الاجتماعية (اختيار متعدد + استثناء المحدد)
            .filter { fam ->
                if (!maritalStatusEnabled || selectedMaritalStatuses.isEmpty()) {
                    true
                } else {
                    val statusValue = fam.maritalStatus.trim().ifBlank { "غير مصنف" }
                    val isMatch = selectedMaritalStatuses.any { it.trim() == statusValue }
                    if (excludeMaritalStatuses) !isMatch else isMatch
                }
            }
            // 9. حد أفراد الأسرة المقارن بالقيمة المحددة بدقة
            .filter { fam ->
                fam.familyMembersCount >= minMembers
            }
            // 10. الترتيب الأولوية الإلزامي: الأكبر حجماً أولاً
            .sortedByDescending { it.familyMembersCount }
            .toList()
    }

    private fun evaluateChipFilter(value: String, chips: Map<String, ChipFilterState>): Boolean {
        if (chips.isEmpty()) return true
        val included = chips.filter { it.value == ChipFilterState.INCLUDED }.keys
        val excluded = chips.filter { it.value == ChipFilterState.EXCLUDED }.keys

        // إذا كان هناك عناصر مستثناة وتحتوي على القيمة -> استبعاد فوري
        if (excluded.contains(value)) return false
        // إذا كان هناك عناصر متضمنة -> يجب أن تطابق أحدها
        if (included.isNotEmpty() && !included.contains(value)) return false
        return true
    }

    // ==========================================
    // الترشيح الآلي واليدوي المحمي بالأقفال (Auto-Nominate & Manual Override)
    // ==========================================

    private var autoNominationJob: Job? = null

    /**
     * الترشيح الآلي: يوزع الحصص بنزاهة تامة ويلتقط أعلى الأسر أولوية حتى سقف حصة كل محلية
     * ولا يتجاوز بأي حال سقف الحصة الكلية للمشروع.
     */
    fun runAutoNomination() {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return
        val project = selectedProject.value ?: return
        if (!project.isOpen) return // منع التعديل في وضع القراءة فقط

        val maxCapacity = project.targetQuota
        val quotas = localityQuotasMap.value
        val pool = filteredFamilies.value

        autoNominationJob?.cancel()
        autoNominationJob = viewModelScope.launch(Dispatchers.IO) {
            val result = mutableSetOf<FamilyEntity>()

            // تجميع الأسر المؤهلة حسب المنطقة الفرعية الحالية (currentSubArea)
            val poolByLocality = pool.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }

            // التوزيع الحصري حتى استيفاء حصة كل محلية
            quotas.forEach { (locName, quota) ->
                if (quota > 0 && result.size < maxCapacity) {
                    val availableInLoc = poolByLocality[locName] ?: emptyList()
                    val needed = (quota).coerceAtMost(maxCapacity - result.size)
                    result.addAll(availableInLoc.take(needed))
                }
            }

            // إذا تبقى عجز ولم يكتمل المشروع، ملء الفارق من باقي الأسر المؤهلة
            if (result.size < maxCapacity) {
                val remaining = pool.filter { !result.contains(it) }
                val needed = maxCapacity - result.size
                result.addAll(remaining.take(needed))
            }

            selectedNominees.value = result
        }
    }

    /**
     * الإضافة اليدوية لأسرة مع فرض عدم تجاوز الحصة الكلية
     */
    fun addNomineeManually(family: FamilyEntity): Boolean {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return false
        val project = selectedProject.value ?: return false
        if (!project.isOpen) return false
        if (selectedNominees.value.size >= project.targetQuota) return false

        val current = selectedNominees.value.toMutableSet()
        val added = current.add(family)
        if (added) {
            selectedNominees.value = current
        }
        return added
    }

    /**
     * الاستبعاد اليدوي (Swipe to Dismiss / Remove)
     */
    fun removeNominee(family: FamilyEntity) {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return
        val project = selectedProject.value ?: return
        if (!project.isOpen) return

        val current = selectedNominees.value.toMutableSet()
        if (current.remove(family)) {
            selectedNominees.value = current
        }
    }

    fun clearNominees() {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return
        val project = selectedProject.value ?: return
        if (!project.isOpen) return
        selectedNominees.value = emptySet()
    }

    /**
     * اعتماد وترحيل الترشيحات رسمياً إلى قاعدة البيانات
     */
    suspend fun commitNomination(): Result<Int> = withContext(Dispatchers.IO) {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) {
            return@withContext Result.failure(SecurityException("ليس لديك صلاحية اعتماد وترحيل الترشيحات"))
        }
        val project = selectedProject.value
            ?: return@withContext Result.failure(IllegalStateException("لم يتم اختيار أي مشروع"))
        if (!project.isOpen) {
            return@withContext Result.failure(IllegalStateException("المشروع مغلق أو مقفل ولا يمكن اعتماد ترشيحات له"))
        }

        val nominees = selectedNominees.value
        if (nominees.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("قائمة المرشحين فارغة"))
        }

        try {
            val insertedCount = repository.commitNomineesToProject(
                projectId = project.projectID,
                aidTypeId = project.aidTypeID,
                familyIds = nominees.map { it.familyID },
                mechanism = "هجين (آلي/يدوي)"
            )
            Result.success(insertedCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // حقول ودوال التوافق البرمجي مع الشاشات السابقة
    // ==========================================
    val isFiltering = MutableStateFlow(false)
    val dynamicNominationResult = MutableStateFlow<DynamicNominationResult?>(null)
    val calculatedQuotas = MutableStateFlow<List<LocalityQuota>>(emptyList())
    val filteredEligibleFamilies: StateFlow<List<FamilyEntity>> = filteredFamilies
    val targetBeneficiariesText = MutableStateFlow("100")
    val resultLimitText = MutableStateFlow("300")
    val selectedLocalities = MutableStateFlow<Set<String>>(emptySet())
    val excludeLocalities = MutableStateFlow(false)
    val selectedAidCategories = MutableStateFlow<Set<String>>(emptySet())
    val excludeAidCategories = MutableStateFlow(true)
    val selectedDamageTypes = MutableStateFlow<Set<String>>(emptySet())
    val excludeDamageTypes = MutableStateFlow(false)
    val selectedShelterStatuses = MutableStateFlow<Set<String>>(emptySet())
    val excludeShelterStatuses = MutableStateFlow(false)
    val selectedWorksApprovals = MutableStateFlow<Set<String>>(emptySet())
    val excludeWorksApprovals = MutableStateFlow(false)
    val selectedIncomeSources = MutableStateFlow<Set<String>>(emptySet())
    val excludeIncomeSources = MutableStateFlow(false)
    val selectedSubAreas = MutableStateFlow<Set<String>>(emptySet())
    val excludeSubAreas = MutableStateFlow(false)
    val selectedLocalityId = MutableStateFlow(0)
    val excludeLocality = MutableStateFlow(false)
    val selectedProjectId = MutableStateFlow(1L)
    val selectedAidTypeId = MutableStateFlow(1)
    val statusFilterTab = MutableStateFlow<CandidateStatus?>(null)
    val customLocalityQuotas = MutableStateFlow<Map<String, String>>(emptyMap())

    val localities: StateFlow<List<String>> = combine(
        repository.getDistinctLocalities(),
        canViewAllLocalities
    ) { list, allowAll ->
        val allowedNames = AccessControlManager.getCleanAllowedLocalities()
        val clean = list.map { it.trim() }.filter { it.isNotBlank() }.distinct().let { dbLocs ->
            if (repository.isSuperAdmin() || allowedNames.isEmpty()) dbLocs
            else dbLocs.filter { loc -> allowedNames.any { it.equals(loc, ignoreCase = true) } }
        }
        if (allowAll) listOf("الكل") + clean else clean
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pureLocalities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { list ->
            val allowedNames = AccessControlManager.getCleanAllowedLocalities()
            val clean = list.map { it.trim() }.filter { it.isNotBlank() }.distinct()
            if (repository.isSuperAdmin() || allowedNames.isEmpty()) clean
            else clean.filter { loc -> allowedNames.any { it.equals(loc, ignoreCase = true) } }
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val pureAidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val shelterStatuses: StateFlow<List<String>> = repository.getDistinctShelterStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val worksApprovals: StateFlow<List<String>> = repository.getDistinctWorksApprovalsFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    fun toggleLocality(name: String) = cycleChipState("locality", name)
    fun toggleCategory(cat: String) {
        val cur = selectedAidCategories.value.toMutableSet()
        if (cur.contains(cat)) cur.remove(cat) else cur.add(cat)
        selectedAidCategories.value = cur
    }
    fun clearCategories() {
        selectedAidCategories.value = emptySet()
    }
    fun toggleDamageType(type: String) {
        val cur = selectedDamageTypes.value.toMutableSet()
        if (cur.contains(type)) cur.remove(type) else cur.add(type)
        selectedDamageTypes.value = cur
        cycleChipState("damage", type)
    }
    fun clearDamageTypes() {
        selectedDamageTypes.value = emptySet()
        damageChipStates.value = emptyMap()
    }
    fun toggleShelterStatus(status: String) {
        val cur = selectedShelterStatuses.value.toMutableSet()
        if (cur.contains(status)) cur.remove(status) else cur.add(status)
        selectedShelterStatuses.value = cur
        cycleChipState("shelter", status)
    }
    fun clearShelterStatuses() {
        selectedShelterStatuses.value = emptySet()
        shelterChipStates.value = emptyMap()
    }
    fun toggleWorksApproval(approval: String) {
        val cur = selectedWorksApprovals.value.toMutableSet()
        if (cur.contains(approval)) cur.remove(approval) else cur.add(approval)
        selectedWorksApprovals.value = cur
    }
    fun clearWorksApprovals() {
        selectedWorksApprovals.value = emptySet()
    }
    fun toggleMaritalStatus(status: String) {
        val clean = status.trim()
        if (clean.isBlank()) return
        val cur = selectedMaritalStatuses.value.toMutableList()
        if (cur.contains(clean)) cur.remove(clean) else cur.add(clean)
        selectedMaritalStatuses.value = cur
    }
    fun clearMaritalStatuses() {
        selectedMaritalStatuses.value = emptyList()
    }
    fun setExcludeMaritalStatuses(exclude: Boolean) {
        excludeMaritalStatuses.value = exclude
    }
    fun setMaritalStatusFilterEnabled(enabled: Boolean) {
        maritalStatusFilterEnabled.value = enabled
    }
    fun toggleIncomeSource(source: String) {
        val cur = selectedIncomeSources.value.toMutableSet()
        if (cur.contains(source)) cur.remove(source) else cur.add(source)
        selectedIncomeSources.value = cur
        cycleChipState("income", source)
    }
    fun clearIncomeSources() {
        selectedIncomeSources.value = emptySet()
        incomeChipStates.value = emptyMap()
    }
    fun toggleSubArea(area: String) {
        val cur = selectedSubAreas.value.toMutableSet()
        if (cur.contains(area)) cur.remove(area) else cur.add(area)
        selectedSubAreas.value = cur
    }
    fun clearSubAreas() {
        selectedSubAreas.value = emptySet()
    }
    fun resetFilters() {
        clearAllFilterChips()
        selectedLocalities.value = emptySet()
        excludeLocalities.value = false
        selectedAidCategories.value = emptySet()
        excludeAidCategories.value = true
        selectedDamageTypes.value = emptySet()
        excludeDamageTypes.value = false
        selectedShelterStatuses.value = emptySet()
        excludeShelterStatuses.value = false
        selectedWorksApprovals.value = emptySet()
        excludeWorksApprovals.value = false
        selectedMaritalStatuses.value = emptyList()
        excludeMaritalStatuses.value = false
        maritalStatusFilterEnabled.value = true
        selectedIncomeSources.value = emptySet()
        excludeIncomeSources.value = false
        selectedSubAreas.value = emptySet()
        excludeSubAreas.value = false
        selectedLocalityId.value = 0
        excludeLocality.value = false
        statusFilterTab.value = null
    }

    private var filteringJob: Job? = null

    fun clearState() {
        refreshOptionsJob?.cancel()
        autoNominationJob?.cancel()
        filteringJob?.cancel()
        selectedNominees.value = emptySet()
        selectedProject.value = null
        dynamicNominationResult.value = null
        calculatedQuotas.value = emptyList()
        customLocalityQuotas.value = emptyMap()
        isFiltering.value = false
        resetFilters()
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    fun runFilteringEngine() {
        filteringJob?.cancel()
        filteringJob = viewModelScope.launch {
            isFiltering.value = true
            try {
                val excludedIds = if (selectedAidCategories.value.isNotEmpty()) {
                    activeAidTypes.value
                        .filter { selectedAidCategories.value.contains(it.aidTypeName) }
                        .map { it.aidTypeID }
                        .toSet()
                } else {
                    emptySet()
                }
                val criteria = DynamicNominationCriteria(
                    exclusionMode = exclusionMode.value,
                    exclusionDays = exclusionDaysText.value.toIntOrNull(),
                    exclusionDateCutoff = exclusionDateCutoffText.value.takeIf { it.isNotBlank() },
                    excludedAidTypeIds = excludedIds,
                    hasChildrenOnly = hasChildrenOnly.value,
                    minChildAge = minChildAgeText.value.toIntOrNull(),
                    maxChildAge = maxChildAgeText.value.toIntOrNull(),
                    selectedDamageTypes = selectedDamageTypes.value,
                    excludeDamageTypes = excludeDamageTypes.value,
                    selectedMaritalStatuses = if (maritalStatusFilterEnabled.value) selectedMaritalStatuses.value.toSet() else emptySet(),
                    excludeMaritalStatuses = excludeMaritalStatuses.value,
                    selectedWorksApprovals = selectedWorksApprovals.value,
                    excludeWorksApprovals = excludeWorksApprovals.value,
                    selectedShelterStatuses = selectedShelterStatuses.value,
                    excludeShelterStatuses = excludeShelterStatuses.value,
                    selectedIncomeSources = selectedIncomeSources.value,
                    excludeIncomeSources = excludeIncomeSources.value,
                    selectedSubAreas = selectedSubAreas.value,
                    excludeSubAreas = excludeSubAreas.value,
                    selectedLocalityId = selectedLocalityId.value,
                    excludeLocality = excludeLocality.value,
                    selectedAidTypeId = selectedAidTypeId.value,
                    projectId = selectedProjectId.value,
                    minFamilyMembers = minFamilyMembers.value,
                    limit = resultLimitText.value.toIntOrNull() ?: 300,
                    targetBeneficiaries = targetBeneficiariesText.value.toIntOrNull() ?: 100
                )
                val result = repository.runDynamicNomination(criteria)
                dynamicNominationResult.value = result
                if (result.quotas.isNotEmpty()) {
                    calculatedQuotas.value = result.quotas
                }
            } finally {
                isFiltering.value = false
            }
        }
    }

    class Factory(
        private val repository: AidRepository,
        private val initialAssignedSubRegion: String = "All"
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NominationViewModel(repository, initialAssignedSubRegion) as T
        }
    }
}
