package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.local.entities.donor
import com.humanitarian.aidmanagement.data.local.entities.isOpen
import com.humanitarian.aidmanagement.data.local.entities.residencyStatus
import com.humanitarian.aidmanagement.data.local.entities.socialAffairsStatus
import com.humanitarian.aidmanagement.data.local.entities.targetQuota
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.CandidateStatus
import com.humanitarian.aidmanagement.engine.DynamicCandidateModel
import com.humanitarian.aidmanagement.engine.DynamicNominationCriteria
import com.humanitarian.aidmanagement.engine.DynamicNominationResult
import com.humanitarian.aidmanagement.engine.ExclusionMode
import com.humanitarian.aidmanagement.engine.LocalityQuota
import com.humanitarian.aidmanagement.security.AccessControlManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * حالة شريحة الفلترة متعددة الحالات (Multi-State FilterChip)
 * 3 حالات: غير محدد، متضمن (أخضر)، مستثنى (أحمر)
 */
enum class ChipFilterState {
    UNSELECTED,
    INCLUDED, // تضمين (Checkmark)
    EXCLUDED  // استثناء (Cross)
}

/**
 * إحصائية حصة المحلية المعتمدة والترشيح الفعلي والعجز/الفائض
 */
data class LocalityQuotaStatsItem(
    val localityName: String,
    val baseX: Int,
    val totalBase: Int,
    val percentage: Double,
    val targetQuota: Int,
    val nominatedCount: Int
) {
    val shortageExcess: Int get() = nominatedCount - targetQuota
    val isComplete: Boolean get() = nominatedCount >= targetQuota && targetQuota > 0
    val formattedPercentage: String get() = String.format(Locale.US, "%.1f%%", percentage)
}

/**
 * MASTER ARCHITECTURE V3.0: THE ULTIMATE HYBRID NOMINATION VIEWMODEL
 * يدمج إدارة الوصول الجغرافي (RBAC)، الحسابات الرياضية للتوزيع النسبي،
 * وفلاتر الشرائح ثلاثية الحالات والاختيار الهجين المحمي بالأقفال.
 */
class NominationViewModel(
    val repository: AidRepository,
    initialAssignedSubRegion: String = "All"
) : ViewModel() {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    // ==========================================
    // MODULE 2: GEOGRAPHICAL RBAC (المنطقة المخصصة)
    // ==========================================
    val assignedSubRegion = MutableStateFlow(initialAssignedSubRegion)

    fun setAssignedSubRegion(region: String) {
        assignedSubRegion.value = region.ifBlank { "All" }
    }

    // ==========================================
    // تدفقات قاعدة البيانات والمشاريع
    // ==========================================
    val allActiveProjects: StateFlow<List<ProjectEntity>> = repository.getActiveProjects()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Step 1: المشاريع المفتوحة حصراً للترشيح (isOpen == true)
    val openProjects: StateFlow<List<ProjectEntity>> = repository.getActiveProjects()
        .map { list -> list.filter { it.isOpen } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAidTypes: StateFlow<List<AidTypeEntity>> = repository.getActiveAidTypes()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dbLocalities: StateFlow<List<LocalityEntity>> = repository.getLocalities()
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * تدفق السجلات ذات حالة 'مرشح' التي تنتظر الترحيل والاعتماد الرسمي (تفاعلي من Room)
     */
    val nominatedRecords: StateFlow<List<AidRecordEntity>> = repository.getNominatedRecordsForProjectFlow(0L)
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // المشروع المختار حالياً + الأسر المختارة في المسودة الحالية
    val selectedProject = MutableStateFlow<ProjectEntity?>(null)
    val selectedProjectId = MutableStateFlow(1L)
    val selectedAidTypeId = MutableStateFlow(1)
    val targetBeneficiariesText = MutableStateFlow("100")
    val selectedNominees = MutableStateFlow<Set<FamilyEntity>>(emptySet())

    // ==========================================
    // MODULE 2.5: MICRO-RBAC GEO-FENCING & SCOPED QUOTA ISOLATION
    // ==========================================
    val isGeoRestrictedUser: StateFlow<Boolean> = repository.currentUserFlow
        .map { user ->
            user != null && AccessControlManager.isGeoRestrictedUser()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val effectiveUserRegion: StateFlow<String> = repository.currentUserFlow
        .map { AccessControlManager.effectiveSqlRegion() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "ALL")

    val effectiveUserSubRegion: StateFlow<String> = repository.currentUserFlow
        .map { AccessControlManager.effectiveSqlSubRegion() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "ALL")

    // وضع القراءة فقط (إذا تم فتح مشروع مقفل isOpen == false)
    val isReadOnlyMode: StateFlow<Boolean> = selectedProject.map { project ->
        project != null && !project.isOpen
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    private val effectiveActiveProjectId: Flow<Long> = combine(selectedProject, selectedProjectId) { prj, pid ->
        prj?.projectID ?: pid
    }.distinctUntilChanged()

    @OptIn(ExperimentalCoroutinesApi::class)
    val alreadyNominatedFamilyIds: StateFlow<Set<Long>> = effectiveActiveProjectId
        .flatMapLatest { pid ->
            if (pid > 0) repository.getNominatedFamilyIdsForProjectFlow(pid) else flowOf(emptySet())
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    @OptIn(ExperimentalCoroutinesApi::class)
    val alreadyNominatedCount: StateFlow<Int> = combine(
        selectedProject,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { prj, restricted, effReg, effSubReg ->
        Triple(prj?.projectID ?: 0L, restricted, effReg to effSubReg)
    }.flatMapLatest { (pid, restricted, scope) ->
        if (pid <= 0) {
            flowOf(0)
        } else if (restricted && (scope.first != "ALL" || scope.second != "ALL")) {
            repository.getProjectScopedNominatedCountFlow(pid, scope.first, scope.second)
        } else if (restricted) {
            val allowedLocs = AccessControlManager.getCleanAllowedLocalities()
            repository.getProjectNominatedCountsBySubAreaFlow(pid).map { byArea ->
                byArea.filterKeys { area -> allowedLocs.any { it.equals(area, ignoreCase = true) } }.values.sum()
            }
        } else {
            repository.getProjectNominatedDistinctCountFlow(pid)
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    @OptIn(ExperimentalCoroutinesApi::class)
    val alreadyNominatedBySubArea: StateFlow<Map<String, Int>> = combine(
        selectedProject,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { prj, restricted, effReg, effSubReg ->
        Triple(prj?.projectID ?: 0L, restricted, effReg to effSubReg)
    }.flatMapLatest { (pid, restricted, scope) ->
        if (pid <= 0) {
            flowOf(emptyMap())
        } else if (restricted && (scope.first != "ALL" || scope.second != "ALL")) {
            repository.getProjectScopedNominatedCountsBySubAreaFlow(pid, scope.first, scope.second)
        } else if (restricted) {
            val allowedLocs = AccessControlManager.getCleanAllowedLocalities()
            repository.getProjectNominatedCountsBySubAreaFlow(pid).map { byArea ->
                byArea.filterKeys { area -> allowedLocs.any { it.equals(area, ignoreCase = true) } }
            }
        } else {
            repository.getProjectNominatedCountsBySubAreaFlow(pid)
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val dynamicSelectedProject: StateFlow<ProjectEntity?> = combine(allActiveProjects, selectedProjectId) { list, pid ->
        list.firstOrNull { it.projectID == pid }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val dynamicAlreadyNominatedFamilyIds: StateFlow<Set<Long>> = selectedProjectId
        .flatMapLatest { pid ->
            if (pid > 0) repository.getNominatedFamilyIdsForProjectFlow(pid) else flowOf(emptySet())
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    @OptIn(ExperimentalCoroutinesApi::class)
    val dynamicAlreadyNominatedCount: StateFlow<Int> = combine(
        selectedProjectId,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { pid, restricted, effReg, effSubReg ->
        Triple(pid, restricted, effReg to effSubReg)
    }.flatMapLatest { (pid, restricted, scope) ->
        if (pid <= 0) {
            flowOf(0)
        } else if (restricted && (scope.first != "ALL" || scope.second != "ALL")) {
            repository.getProjectScopedNominatedCountFlow(pid, scope.first, scope.second)
        } else if (restricted) {
            val allowedLocs = AccessControlManager.getCleanAllowedLocalities()
            repository.getProjectNominatedCountsBySubAreaFlow(pid).map { byArea ->
                byArea.filterKeys { area -> allowedLocs.any { it.equals(area, ignoreCase = true) } }.values.sum()
            }
        } else {
            repository.getProjectNominatedDistinctCountFlow(pid)
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val dynamicTargetQuota: StateFlow<Int> = combine(
        dynamicSelectedProject,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { prj, restricted, effReg, effSubReg ->
        if (prj == null || prj.targetQuota <= 0) {
            0
        } else if (!restricted) {
            prj.targetQuota
        } else {
            val systemTotalBase = repository.getSystemApprovedCountByResidencySync("مقيم")
            val scopedBase = if (effReg != "ALL" || effSubReg != "ALL") {
                repository.getScopedApprovedCountByResidencySync("مقيم", effReg, effSubReg)
            } else {
                repository.countScopedEligibleFamiliesSync(effReg, effSubReg)
            }
            if (systemTotalBase <= 0) 0
            else Math.round((scopedBase.toDouble() / systemTotalBase.toDouble()) * prj.targetQuota).toInt()
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val dynamicRemainingQuota: StateFlow<Int> = combine(
        dynamicSelectedProject,
        dynamicTargetQuota,
        dynamicAlreadyNominatedCount
    ) { prj, scopedTarget, prevCount ->
        if (prj == null || prj.targetQuota <= 0) 0 else (scopedTarget - prevCount).coerceAtLeast(0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun selectProject(project: ProjectEntity) {
        val changed = selectedProject.value?.projectID != project.projectID
        selectedProject.value = project
        selectedProjectId.value = project.projectID
        selectedAidTypeId.value = project.aidTypeID
        if (changed) {
            selectedNominees.value = emptySet()
        }
    }

    fun syncSelectedProjectById(projectId: Long) {
        selectedProjectId.value = projectId
        val matched = allActiveProjects.value.firstOrNull { it.projectID == projectId }
        if (matched != null && selectedProject.value?.projectID != projectId) {
            selectedProject.value = matched
            selectedAidTypeId.value = matched.aidTypeID
            selectedNominees.value = emptySet()
        }
    }

    fun setTargetBeneficiariesInput(rawInput: String) {
        val digitsOnly = rawInput.filter { it.isDigit() }
        if (digitsOnly.isEmpty()) {
            targetBeneficiariesText.value = ""
            return
        }
        val activeProject = dynamicSelectedProject.value
        val parsed = digitsOnly.toIntOrNull() ?: 0
        val clamped = if (activeProject != null && activeProject.targetQuota > 0) {
            parsed.coerceAtMost(dynamicRemainingQuota.value)
        } else {
            parsed
        }
        targetBeneficiariesText.value = clamped.toString()
    }

    // ==========================================
    // تدفق الأسر المصفى جغرافياً من المصدر (RBAC Pre-Filtered Master Stream: محليات + شعب)
    // ==========================================
    val rbacFamiliesStream: StateFlow<List<FamilyEntity>> = combine(
        repository.getFamiliesRestrictedFlow(),
        assignedSubRegion,
        repository.currentUserFlow,
        dbLocalities
    ) { families, region, user, locs ->
        if (user == null) return@combine emptyList()
        val localitiesMap = locs.associate { it.LocalityID to it.LocalityName }
        val extraLocIds = repository.getCurrentUserLocalityIds()
        val rlsFiltered = if (repository.isSuperAdmin()) {
            families
        } else {
            families.filter { fam ->
                AccessControlManager.isFamilyAllowed(fam, localitiesMap, extraLocIds)
            }
        }
        val effectiveRegion = region.trim()
        val isSubRegionRestricted = !repository.isSuperAdmin() &&
            effectiveRegion.isNotBlank() &&
            !effectiveRegion.equals("All", ignoreCase = true) &&
            effectiveRegion != "الكل" &&
            effectiveRegion != "*"
        if (isSubRegionRestricted) {
            rlsFiltered.filter { fam ->
                fam.currentSubArea.equals(effectiveRegion, ignoreCase = true) ||
                    fam.currentMainArea.equals(effectiveRegion, ignoreCase = true) ||
                    localitiesMap[fam.localityID]?.equals(effectiveRegion, ignoreCase = true) == true
            }
        } else {
            rlsFiltered
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val canViewAllLocalities: StateFlow<Boolean> = combine(
        repository.currentUserFlow,
        assignedSubRegion
    ) { user, region ->
        if (user == null) false
        else if (repository.isSuperAdmin()) true
        else {
            val cleanAllowedNames = AccessControlManager.getCleanAllowedLocalities()
            val hasLocIdRestriction = user.AllowedLocalityID > 0 ||
                repository.getCurrentUserLocalityIds().any { it > 0 }
            val hasSubAreaRestriction = region.trim().let {
                it.isNotBlank() && !it.equals("All", ignoreCase = true) && it != "الكل" && it != "*"
            }
            cleanAllowedNames.isEmpty() && !hasLocIdRestriction && !hasSubAreaRestriction
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val lockedLocalityName: StateFlow<String?> = combine(
        repository.currentUserFlow,
        repository.getAllowedLocalitiesFlow(),
        assignedSubRegion
    ) { user, allowedLocEntities, region ->
        if (user == null || repository.isSuperAdmin()) {
            null
        } else {
            val cleanAllowedNames = AccessControlManager.getCleanAllowedLocalities()
            val hasLocIdRestriction = user.AllowedLocalityID > 0 ||
                repository.getCurrentUserLocalityIds().any { it > 0 }
            val resolvedNames = cleanAllowedNames.ifEmpty {
                if (hasLocIdRestriction) allowedLocEntities.map { it.LocalityName.trim() }.filter { it.isNotBlank() } else emptyList()
            }.distinct()
            val cleanRegion = region.trim().takeIf {
                it.isNotBlank() && !it.equals("All", ignoreCase = true) && it != "الكل" && it != "*"
            }
            when {
                resolvedNames.size == 1 -> resolvedNames.first()
                resolvedNames.isEmpty() && cleanRegion != null -> cleanRegion
                else -> null
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isLocalityLocked: StateFlow<Boolean> = lockedLocalityName
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val assignedSubArea: StateFlow<String?> = AccessControlManager.assignedSubAreaFlow
    val assignedDivisions: StateFlow<List<String>> = AccessControlManager.assignedDivisionsFlow

    val allowedBranches: StateFlow<List<String>> = combine(
        repository.currentUserFlow,
        assignedDivisions
    ) { _, divs ->
        divs.ifEmpty { AccessControlManager.getCleanAllowedBranches() }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lockedBranchName: StateFlow<String?> = combine(
        repository.currentUserFlow,
        allowedBranches
    ) { user, branches ->
        if (user == null || repository.isSuperAdmin()) {
            null
        } else {
            if (branches.size == 1) branches.first() else null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isBranchLocked: StateFlow<Boolean> = lockedBranchName
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val canViewAllBranches: StateFlow<Boolean> = combine(
        repository.currentUserFlow,
        allowedBranches
    ) { user, branches ->
        user != null && (repository.isSuperAdmin() || branches.isEmpty())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val selectedLocalityFilter = MutableStateFlow("")
    val selectedBranchFilter = MutableStateFlow("")

    val availableBranches: StateFlow<List<String>> = combine(
        repository.currentUserFlow,
        selectedLocalityFilter,
        lockedLocalityName,
        allowedBranches
    ) { user, selectedLoc, lockedLoc, allowed ->
        val activeLoc = lockedLoc ?: selectedLoc
        val dbBranches = repository.getDistinctBranchesForLocality(activeLoc)
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
        if (user == null || repository.isSuperAdmin() || allowed.isEmpty()) {
            dbBranches.sorted()
        } else {
            val filtered = dbBranches.filter { br -> allowed.any { it.equals(br, ignoreCase = true) } }
            (if (filtered.isNotEmpty()) filtered else allowed).distinct().sorted()
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun selectLocalityFilter(locality: String) {
        if (isLocalityLocked.value) return
        val clean = if (locality == "الكل" || locality == "جميع المحليات") "" else locality.trim()
        if (!canViewAllLocalities.value && clean.isBlank()) return
        val allowedLocs = AccessControlManager.getCleanAllowedLocalities()
        if (!repository.isSuperAdmin() && allowedLocs.isNotEmpty() && clean.isNotBlank() && allowedLocs.none { it.equals(clean, ignoreCase = true) }) {
            return
        }
        selectedLocalityFilter.value = clean
        if (!isBranchLocked.value) {
            selectedBranchFilter.value = ""
        }
    }

    fun selectBranchFilter(branch: String) {
        if (isBranchLocked.value) return
        val clean = if (branch == "الكل" || branch == "جميع الشعب" || branch == "كافة الشعب المصرح بها") "" else branch.trim()
        val allowed = AccessControlManager.getCleanAllowedBranches()
        if (!repository.isSuperAdmin() && allowed.isNotEmpty() && clean.isNotBlank() && allowed.none { it.equals(clean, ignoreCase = true) }) {
            return
        }
        selectedBranchFilter.value = clean
    }

    val canNominate: StateFlow<Boolean> = repository.currentUserFlow
        .map { user ->
            user != null && (repository.isSuperAdmin() || AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // ==========================================
    // MODULE 3: PROPORTIONAL DISTRIBUTION MATH (التوزيع النسبي)
    // القاعدة الرياضية: اعتماد التنمية = "معتمد" مع صفة الإقامة المختارة (أو "مقيم" افتراضياً)
    // ==========================================
    val selectedResidencyStatus = MutableStateFlow<String?>(null)

    fun setSelectedResidencyStatus(status: String?) {
        selectedResidencyStatus.value = status?.trim()?.takeIf { it.isNotBlank() }
    }

    // شرط التفعيل الحصري الوحيد: يعتمد حصراً على اختيار صفة الإقامة فقط دون أي حقل آخر
    val isSubmitEnabled: StateFlow<Boolean> = selectedResidencyStatus
        .map { !it.isNullOrBlank() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val localityQuotasMap: StateFlow<Map<String, Int>> = combine(
        rbacFamiliesStream,
        selectedProject,
        selectedResidencyStatus,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val families = args[0] as List<FamilyEntity>
        val project = args[1] as ProjectEntity?
        val residency = args[2] as String?
        val restricted = args[3] as Boolean
        val effReg = args[4] as String
        val effSubReg = args[5] as String

        if (project == null || project.targetQuota <= 0) {
            emptyMap()
        } else {
            val targetResidency = residency?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
            // القاعدة الإجمالية الحقيقية على مستوى النظام بالكامل لمنع تضخم حصة المنطقة إلى 100%
            val systemTotalBase = repository.getSystemApprovedCountByResidencySync(targetResidency)
            if (systemTotalBase <= 0) {
                emptyMap()
            } else {
                val baseFamilies = families.filter { fam ->
                    fam.socialAffairsStatus.trim() == "معتمد" &&
                        fam.residencyStatus.trim().equals(targetResidency, ignoreCase = true) &&
                        (!restricted || effReg == "ALL" || fam.currentSubArea.trim().equals(effReg, ignoreCase = true)) &&
                        (!restricted || effSubReg == "ALL" || fam.currentBranch.trim().equals(effSubReg, ignoreCase = true))
                }
                val groups = baseFamilies.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }
                groups.mapValues { (_, list) ->
                    val baseX = list.size
                    Math.round((baseX.toDouble() / systemTotalBase.toDouble()) * project.targetQuota).toInt()
                }
            }
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val visibleTargetQuota: StateFlow<Int> = combine(
        selectedProject,
        selectedResidencyStatus,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion,
        localityQuotasMap
    ) { args ->
        val project = args[0] as ProjectEntity?
        val residency = args[1] as String?
        val restricted = args[2] as Boolean
        val effReg = args[3] as String
        val effSubReg = args[4] as String
        @Suppress("UNCHECKED_CAST")
        val quotasMap = args[5] as Map<String, Int>

        if (project == null || project.targetQuota <= 0) {
            0
        } else if (!restricted) {
            project.targetQuota
        } else if (effReg != "ALL" || effSubReg != "ALL") {
            val targetResidency = residency?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
            val systemTotalBase = repository.getSystemApprovedCountByResidencySync(targetResidency)
            val scopedBase = repository.getScopedApprovedCountByResidencySync(targetResidency, effReg, effSubReg)
            if (systemTotalBase <= 0) 0
            else Math.round((scopedBase.toDouble() / systemTotalBase.toDouble()) * project.targetQuota).toInt()
        } else {
            quotasMap.values.sum()
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val remainingQuota: StateFlow<Int> = combine(
        selectedProject,
        visibleTargetQuota,
        alreadyNominatedCount
    ) { prj, scopedTarget, prevCount ->
        if (prj == null || prj.targetQuota <= 0) 0 else (scopedTarget - prevCount).coerceAtLeast(0)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // ==========================================
    // MODULE 4: THE SUPER DYNAMIC FILTER ENGINE (100% Data-Driven from DAO DISTINCT Queries)
    // ==========================================
    private val _dynamicShelterOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicShelterOptions: StateFlow<List<String>> = _dynamicShelterOptions.asStateFlow()

    private val _dynamicWorksApprovalOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicWorksApprovalOptions: StateFlow<List<String>> = _dynamicWorksApprovalOptions.asStateFlow()

    private val _dynamicDamageOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicDamageOptions: StateFlow<List<String>> = _dynamicDamageOptions.asStateFlow()

    // تم استبدال القائمة العشوائية (DISTINCT) بفلتر حالة العمل المنطقي الذكي (workStatusFilter)
    val dynamicIncomeOptions: StateFlow<List<String>> = MutableStateFlow<List<String>>(emptyList()).asStateFlow()

    private val _dynamicSubAreaOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicSubAreaOptions: StateFlow<List<String>> = _dynamicSubAreaOptions.asStateFlow()

    private val _dynamicResidencyStatusOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicResidencyStatusOptions: StateFlow<List<String>> = _dynamicResidencyStatusOptions.asStateFlow()

    private val _dynamicMaritalStatusOptions = MutableStateFlow<List<String>>(emptyList())
    val dynamicMaritalStatusOptions: StateFlow<List<String>> = _dynamicMaritalStatusOptions.asStateFlow()

    private val _dynamicLocalities = MutableStateFlow<List<String>>(emptyList())
    val dynamicLocalities: StateFlow<List<String>> = _dynamicLocalities.asStateFlow()

    private val _dynamicBranches = MutableStateFlow<List<String>>(emptyList())
    val dynamicBranches: StateFlow<List<String>> = _dynamicBranches.asStateFlow()

    private var refreshOptionsJob: Job? = null

    fun refreshDynamicFilterOptions() {
        refreshOptionsJob?.cancel()
        refreshOptionsJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val isAdmin = repository.isSuperAdmin()
                val allowedLocNames = AccessControlManager.getCleanAllowedLocalities()
                val allowedBranchNames = AccessControlManager.getCleanAllowedBranches()
                val regionFilter = assignedSubRegion.value.trim()
                val hasRegionFilter = !isAdmin &&
                    regionFilter.isNotBlank() &&
                    !regionFilter.equals("All", ignoreCase = true) &&
                    regionFilter != "الكل" &&
                    regionFilter != "*"

                val shelter = repository.getDistinctShelterStatusesRestrictedSync()
                val works = repository.getDistinctWorksApprovalsRestrictedSync()
                val damage = repository.getDistinctDamageTypesRestrictedSync()
                val marital = repository.getDistinctMaritalStatusesRestrictedSync()
                val residency = repository.getDistinctResidentStatusesRestrictedSync()

                val dbSubAreas = repository.getDistinctCurrentSubAreasRestrictedSync()
                val intersectedSubAreas = dbSubAreas.filter { sub ->
                    val matchesAllowedLoc = isAdmin || allowedLocNames.isEmpty() ||
                        allowedLocNames.any { it.equals(sub, ignoreCase = true) }
                    val matchesRegion = !hasRegionFilter || sub.equals(regionFilter, ignoreCase = true)
                    matchesAllowedLoc && matchesRegion
                }

                val dbLocalitiesList = repository.getDistinctLocalitiesRestrictedSync()
                val intersectedLocalities = dbLocalitiesList.filter { loc ->
                    val matchesAllowedLoc = isAdmin || allowedLocNames.isEmpty() ||
                        allowedLocNames.any { it.equals(loc, ignoreCase = true) }
                    val matchesRegion = !hasRegionFilter || loc.equals(regionFilter, ignoreCase = true)
                    matchesAllowedLoc && matchesRegion
                }

                val dbBranchesList = repository.getAllDistinctBranches()
                val intersectedBranches = if (isAdmin || allowedBranchNames.isEmpty()) {
                    dbBranchesList
                } else {
                    dbBranchesList.filter { br ->
                        allowedBranchNames.any { it.equals(br, ignoreCase = true) }
                    }
                }

                _dynamicShelterOptions.value = shelter
                _dynamicWorksApprovalOptions.value = works
                _dynamicDamageOptions.value = damage
                _dynamicSubAreaOptions.value = intersectedSubAreas
                _dynamicResidencyStatusOptions.value = residency
                _dynamicMaritalStatusOptions.value = marital
                _dynamicLocalities.value = intersectedLocalities
                _dynamicBranches.value = intersectedBranches
            } catch (_: Exception) {
                // Keep previous valid lists on transient cancellation
            }
        }
    }

    init {
        refreshDynamicFilterOptions()
        viewModelScope.launch(Dispatchers.IO) {
            combine(repository.currentUserFlow, assignedSubRegion) { user, region ->
                user?.UserID to region
            }.distinctUntilChanged().drop(1).collect {
                refreshDynamicFilterOptions()
            }
        }
        viewModelScope.launch {
            combine(lockedLocalityName, lockedBranchName) { lockedLoc, lockedBr ->
                lockedLoc to lockedBr
            }.collect { (lockedLoc, lockedBr) ->
                if (lockedLoc != null && selectedLocalityFilter.value != lockedLoc) {
                    selectedLocalityFilter.value = lockedLoc
                }
                if (lockedBr != null && selectedBranchFilter.value != lockedBr) {
                    selectedBranchFilter.value = lockedBr
                }
            }
        }
        viewModelScope.launch {
            alreadyNominatedFamilyIds.collect { nominatedIds ->
                val current = selectedNominees.value
                if (current.any { nominatedIds.contains(it.familyID) }) {
                    selectedNominees.value = current.filterNot { nominatedIds.contains(it.familyID) }.toSet()
                }
            }
        }
        viewModelScope.launch {
            combine(dynamicSelectedProject, dynamicRemainingQuota) { prj, rem ->
                prj to rem
            }.collect { (prj, rem) ->
                if (prj != null && prj.targetQuota > 0) {
                    val typed = targetBeneficiariesText.value.toIntOrNull()
                    if (typed != null && typed > rem) {
                        targetBeneficiariesText.value = rem.toString()
                    }
                }
            }
        }
    }

    // حالات الشرائح متعددة الحالات (Multi-State Filter Chips)
    val shelterChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val worksApprovalChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val damageChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val localityChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())

    // MISSION 1: WHOLE FILTER BYPASS (TOGGLE SWITCHES)
    val shelterFilterEnabled = MutableStateFlow(true)
    val worksApprovalFilterEnabled = MutableStateFlow(true)
    val damageFilterEnabled = MutableStateFlow(true)
    val incomeFilterEnabled = MutableStateFlow(true)
    val localityFilterEnabled = MutableStateFlow(true)
    val selectedMaritalStatuses = MutableStateFlow<List<String>>(emptyList())
    val excludeMaritalStatuses = MutableStateFlow(false)
    val maritalStatusFilterEnabled = MutableStateFlow(true)

    // فلتر حالة العمل المنطقي الذكي (الكل / يعمل (لديه دخل) / لا يعمل (بدون دخل))
    private val _workStatusFilter = MutableStateFlow("الكل")
    val workStatusFilter: StateFlow<String> = _workStatusFilter.asStateFlow()

    fun setShelterFilterEnabled(enabled: Boolean) { shelterFilterEnabled.value = enabled }
    fun setWorksApprovalFilterEnabled(enabled: Boolean) { worksApprovalFilterEnabled.value = enabled }
    fun setDamageFilterEnabled(enabled: Boolean) { damageFilterEnabled.value = enabled }
    fun setIncomeFilterEnabled(enabled: Boolean) { incomeFilterEnabled.value = enabled }
    fun setLocalityFilterEnabled(enabled: Boolean) { localityFilterEnabled.value = enabled }

    fun setWorkStatusFilter(option: String) {
        _workStatusFilter.value = option.ifBlank { "الكل" }
    }

    // فلاتر الاستثناء الزمني وحجم الأسرة وفلترة الأطفال بالأعمار
    val exclusionMode = MutableStateFlow(ExclusionMode.DAYS)
    val exclusionDaysText = MutableStateFlow("30")
    val exclusionDateCutoffText = MutableStateFlow("")
    val hasChildrenOnly = MutableStateFlow(false)
    val minChildAgeText = MutableStateFlow("0")
    val maxChildAgeText = MutableStateFlow("18")
    val minFamilyMembers = MutableStateFlow(1)
    val searchQuery = MutableStateFlow("")

    fun setHasChildrenOnly(enabled: Boolean) { hasChildrenOnly.value = enabled }
    fun setChildAgeRange(min: String, max: String) {
        minChildAgeText.value = min
        maxChildAgeText.value = max
    }

    // تدفق أعمار الأطفال لكل أسرة لحساب الفلترة العمرية الفورية
    @OptIn(ExperimentalCoroutinesApi::class)
    private val allChildrenFlow: Flow<List<com.humanitarian.aidmanagement.data.local.entities.ChildEntity>> =
        repository.currentUserFlow.flatMapLatest {
            flow { emit(repository.getAllChildrenSync()) }
        }.flowOn(Dispatchers.IO)

    val familyChildrenAgesMap: StateFlow<Map<String, List<Int>>> = allChildrenFlow.map { children ->
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        children.groupBy({ it.familyNationalID }) { child ->
            val birthYear = child.birthDate.take(4).toIntOrNull() ?: currentYear
            (currentYear - birthYear).coerceAtLeast(0)
        }
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // تبديل حالة الشريحة: غير محدد -> متضمن (أخضر) -> مستثنى (أحمر) -> غير محدد
    fun cycleChipState(category: String, key: String) {
        val targetFlow = when (category) {
            "shelter" -> shelterChipStates
            "worksApproval" -> worksApprovalChipStates
            "damage" -> damageChipStates
            "locality" -> localityChipStates
            else -> return
        }
        val current = targetFlow.value.toMutableMap()
        val nextState = when (current[key] ?: ChipFilterState.UNSELECTED) {
            ChipFilterState.UNSELECTED -> ChipFilterState.INCLUDED
            ChipFilterState.INCLUDED -> ChipFilterState.EXCLUDED
            ChipFilterState.EXCLUDED -> ChipFilterState.UNSELECTED
        }
        if (nextState == ChipFilterState.UNSELECTED) {
            current.remove(key)
        } else {
            current[key] = nextState
        }
        targetFlow.value = current
    }

    fun clearAllFilterChips() {
        selectedResidencyStatus.value = null
        shelterChipStates.value = emptyMap()
        worksApprovalChipStates.value = emptyMap()
        damageChipStates.value = emptyMap()
        localityChipStates.value = emptyMap()
        shelterFilterEnabled.value = true
        worksApprovalFilterEnabled.value = true
        damageFilterEnabled.value = true
        incomeFilterEnabled.value = true
        localityFilterEnabled.value = true
        _workStatusFilter.value = "الكل"
        exclusionMode.value = ExclusionMode.DAYS
        exclusionDaysText.value = "30"
        exclusionDateCutoffText.value = ""
        hasChildrenOnly.value = false
        minChildAgeText.value = "0"
        maxChildAgeText.value = "18"
        minFamilyMembers.value = 1
        searchQuery.value = ""
        selectedMaritalStatuses.value = emptyList()
        excludeMaritalStatuses.value = false
        maritalStatusFilterEnabled.value = true
    }

    // ==========================================
    // MODULE 5: SMART HYBRID SELECTION & DASHBOARD (The Core)
    // ==========================================
    private val geoFilterPair: Flow<Pair<String, String>> = combine(
        selectedLocalityFilter,
        selectedBranchFilter,
        lockedLocalityName,
        lockedBranchName,
        dbLocalities
    ) { selLoc, selBr, lockedLoc, lockedBr, _ ->
        val effLoc = lockedLoc ?: selLoc
        val effBr = lockedBr ?: selBr
        effLoc to effBr
    }

    // تدفق الأسر المطابقة للشروط الصارمة (Filtered Families) مرتبة تنازلياً حسب حجم الأسرة مع استبعاد المرشحين مسبقاً لنفس المشروع
    val filteredFamilies: StateFlow<List<FamilyEntity>> = combine(
        rbacFamiliesStream,
        selectedProject,
        shelterChipStates,
        worksApprovalChipStates,
        damageChipStates,
        workStatusFilter,
        localityChipStates,
        shelterFilterEnabled,
        worksApprovalFilterEnabled,
        damageFilterEnabled,
        incomeFilterEnabled,
        localityFilterEnabled,
        minFamilyMembers,
        hasChildrenOnly,
        minChildAgeText,
        maxChildAgeText,
        familyChildrenAgesMap,
        selectedMaritalStatuses,
        excludeMaritalStatuses,
        maritalStatusFilterEnabled,
        geoFilterPair,
        dbLocalities,
        alreadyNominatedFamilyIds,
        selectedResidencyStatus
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val families = args[0] as List<FamilyEntity>
        val project = args[1] as ProjectEntity?
        @Suppress("UNCHECKED_CAST")
        val shelterChips = args[2] as Map<String, ChipFilterState>
        @Suppress("UNCHECKED_CAST")
        val worksChips = args[3] as Map<String, ChipFilterState>
        @Suppress("UNCHECKED_CAST")
        val damageChips = args[4] as Map<String, ChipFilterState>
        val workStatus = args[5] as String
        @Suppress("UNCHECKED_CAST")
        val localityChips = args[6] as Map<String, ChipFilterState>
        val shelterEnabled = args[7] as Boolean
        val worksEnabled = args[8] as Boolean
        val damageEnabled = args[9] as Boolean
        val incomeEnabled = args[10] as Boolean
        val localityEnabled = args[11] as Boolean
        val minMembers = args[12] as Int
        val childrenEnabled = args[13] as Boolean
        val minAgeStr = args[14] as String
        val maxAgeStr = args[15] as String
        @Suppress("UNCHECKED_CAST")
        val childrenAges = args[16] as Map<String, List<Int>>
        @Suppress("UNCHECKED_CAST")
        val maritalStatuses = args[17] as List<String>
        val excludeMarital = args[18] as Boolean
        val maritalEnabled = args[19] as Boolean
        @Suppress("UNCHECKED_CAST")
        val geoPair = args[20] as Pair<String, String>
        @Suppress("UNCHECKED_CAST")
        val locsList = args[21] as List<LocalityEntity>
        @Suppress("UNCHECKED_CAST")
        val excludedFamilyIds = args[22] as Set<Long>
        val selectedResidency = args[23] as String?
        val localitiesMap = locsList.associate { it.LocalityID to it.LocalityName }

        executeCascadingFilter(
            families = families,
            project = project,
            shelterChips = shelterChips,
            worksApprovalChips = worksChips,
            damageChips = damageChips,
            workStatusFilterValue = workStatus,
            localityChips = localityChips,
            shelterEnabled = shelterEnabled,
            worksApprovalEnabled = worksEnabled,
            damageEnabled = damageEnabled,
            incomeEnabled = incomeEnabled,
            localityEnabled = localityEnabled,
            minMembers = minMembers,
            childrenFilterEnabled = childrenEnabled,
            minChildAge = minAgeStr.toIntOrNull() ?: 0,
            maxChildAge = maxAgeStr.toIntOrNull() ?: 100,
            childrenAgesMap = childrenAges,
            selectedMaritalStatuses = maritalStatuses,
            excludeMaritalStatuses = excludeMarital,
            maritalStatusEnabled = maritalEnabled,
            selectedLocalityName = geoPair.first,
            selectedBranchName = geoPair.second,
            localitiesMap = localitiesMap,
            excludedFamilyIds = excludedFamilyIds,
            selectedResidencyStatus = selectedResidency
        )
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // لوحة مراجعة الحصص النسبية مقارنة بالمرشحين الفعليين (معزولة جغرافياً للباحث المقيد وتستخدم المقام العام الحقيقي)
    val localityQuotaStats: StateFlow<List<LocalityQuotaStatsItem>> = combine(
        rbacFamiliesStream,
        selectedProject,
        localityQuotasMap,
        selectedNominees,
        alreadyNominatedBySubArea,
        selectedResidencyStatus,
        isGeoRestrictedUser,
        effectiveUserRegion,
        effectiveUserSubRegion
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val families = args[0] as List<FamilyEntity>
        val project = args[1] as ProjectEntity?
        @Suppress("UNCHECKED_CAST")
        val quotasMap = args[2] as Map<String, Int>
        @Suppress("UNCHECKED_CAST")
        val nominees = args[3] as Set<FamilyEntity>
        @Suppress("UNCHECKED_CAST")
        val prevBySubArea = args[4] as Map<String, Int>
        val residency = args[5] as String?
        val restricted = args[6] as Boolean
        val effReg = args[7] as String
        val effSubReg = args[8] as String

        if (project == null) {
            emptyList()
        } else {
            val targetResidency = residency?.trim()?.takeIf { it.isNotBlank() } ?: "مقيم"
            val systemTotalBase = repository.getSystemApprovedCountByResidencySync(targetResidency)
            val baseFamilies = families.filter { fam ->
                fam.socialAffairsStatus.trim() == "معتمد" &&
                    fam.residencyStatus.trim().equals(targetResidency, ignoreCase = true) &&
                    (!restricted || effReg == "ALL" || fam.currentSubArea.trim().equals(effReg, ignoreCase = true)) &&
                    (!restricted || effSubReg == "ALL" || fam.currentBranch.trim().equals(effSubReg, ignoreCase = true))
            }
            val groups = baseFamilies.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }
            val nomineesByLocality = nominees.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }

            groups.map { (locName, list) ->
                val baseX = list.size
                val quota = quotasMap[locName] ?: 0
                val prevNominated = prevBySubArea[locName] ?: 0
                val draftNominated = nomineesByLocality[locName]?.size ?: 0
                val nominated = prevNominated + draftNominated
                val pct = if (systemTotalBase > 0) (baseX.toDouble() / systemTotalBase.toDouble()) * 100.0 else 0.0
                val displayLabel = if (restricted && effSubReg != "ALL") "$locName — $effSubReg" else locName
                LocalityQuotaStatsItem(
                    localityName = displayLabel,
                    baseX = baseX,
                    totalBase = systemTotalBase,
                    percentage = pct,
                    targetQuota = quota,
                    nominatedCount = nominated
                )
            }.sortedByDescending { it.targetQuota }
        }
    }.flowOn(Dispatchers.IO).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val dummyOrUnemployedWorkValues = setOf(
        "لا يعمل", "بلا عمل", "بدون عمل", "0", "_", "-", ".", "لا يوجد", "لا"
    )

    private fun hasValidWorkIncome(value: String?): Boolean {
        val cleaned = value?.trim().orEmpty()
        return cleaned.isNotEmpty() && cleaned !in dummyOrUnemployedWorkValues
    }

    /**
     * فلترة السلاسل المجمعة (Cascading Filter Execution)
     * مع مفاتيح التجاوز (Bypass Switches) وفلتر حالة العمل المنطقي وتنظيف البيانات الوهمية وفلترة عمر الأبناء
     */
    private fun executeCascadingFilter(
        families: List<FamilyEntity>,
        project: ProjectEntity?,
        shelterChips: Map<String, ChipFilterState>,
        worksApprovalChips: Map<String, ChipFilterState>,
        damageChips: Map<String, ChipFilterState>,
        workStatusFilterValue: String,
        localityChips: Map<String, ChipFilterState>,
        shelterEnabled: Boolean,
        worksApprovalEnabled: Boolean,
        damageEnabled: Boolean,
        incomeEnabled: Boolean,
        localityEnabled: Boolean,
        minMembers: Int = minFamilyMembers.value,
        childrenFilterEnabled: Boolean = false,
        minChildAge: Int = 0,
        maxChildAge: Int = 100,
        childrenAgesMap: Map<String, List<Int>> = emptyMap(),
        selectedMaritalStatuses: List<String> = emptyList(),
        excludeMaritalStatuses: Boolean = false,
        maritalStatusEnabled: Boolean = true,
        selectedLocalityName: String = "",
        selectedBranchName: String = "",
        localitiesMap: Map<Int, String> = emptyMap(),
        excludedFamilyIds: Set<Long> = emptySet(),
        selectedResidencyStatus: String? = null
    ): List<FamilyEntity> {
        val cleanLocFilter = selectedLocalityName.trim()
        val cleanBranchFilter = selectedBranchName.trim()
        val cleanResidencyFilter = selectedResidencyStatus?.trim()?.takeIf { it.isNotBlank() }
        return families.asSequence()
            // 0. الاستبعاد الصارم للمرشحين مسبقاً لنفس المشروع (الترشيح التراكمي المشترك)
            .filter { fam ->
                !excludedFamilyIds.contains(fam.familyID)
            }
            // 0.5 العزل الجغرافي الصارم (المحلية + الشعبة الميدانية)
            .filter { fam ->
                if (cleanLocFilter.isBlank() || cleanLocFilter == "الكل") {
                    true
                } else {
                    fam.currentSubArea.trim().equals(cleanLocFilter, ignoreCase = true) ||
                        fam.currentMainArea.trim().equals(cleanLocFilter, ignoreCase = true) ||
                        localitiesMap[fam.localityID]?.trim()?.equals(cleanLocFilter, ignoreCase = true) == true
                }
            }
            .filter { fam ->
                if (cleanBranchFilter.isBlank() || cleanBranchFilter == "الكل") {
                    true
                } else {
                    fam.currentBranch.trim().equals(cleanBranchFilter, ignoreCase = true)
                }
            }
            // 1. الشرط الإلزامي المخفي (اعتماد التنمية = معتمد) + شرط صفة الإقامة الإلزامي الوحيد من الواجهة
            .filter { fam ->
                cleanResidencyFilter != null &&
                    fam.socialAffairsStatus.trim() == "معتمد" &&
                    fam.residencyStatus.trim().equals(cleanResidencyFilter, ignoreCase = true)
            }
            // 2. فلتر اعتماد الأشغال مع مفتاح التجاوز (Works Approval Bypass)
            .filter { fam ->
                if (!worksApprovalEnabled) true
                else {
                    val key = fam.worksApproval.trim().ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, worksApprovalChips)
                }
            }
            // 3. فلتر شرائح الإيواء ثلاثية الحالات مع مفتاح التجاوز (Bypass)
            .filter { fam ->
                if (!shelterEnabled) true
                else {
                    val key = fam.shelterStatus.trim().ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, shelterChips)
                }
            }
            // 4. فلتر شرائح الضرر مع مفتاح التجاوز (Bypass)
            .filter { fam ->
                if (!damageEnabled) true
                else {
                    val key = fam.damageType.trim().ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, damageChips)
                }
            }
            // 5. فلتر حالة العمل المنطقي الذكي مع تنظيف البيانات الوهمية عبر العمودين (incomeSource1 & income_source_2)
            .filter { fam ->
                val cleanStatus = workStatusFilterValue.trim()
                if (!incomeEnabled || cleanStatus == "الكل" || cleanStatus.isEmpty()) {
                    true
                } else {
                    val hasIncome = hasValidWorkIncome(fam.incomeSource1) || hasValidWorkIncome(fam.incomeSource2)
                    when (cleanStatus) {
                        "يعمل (لديه دخل)", "يعمل" -> hasIncome
                        "لا يعمل (بدون دخل)", "لا يعمل" -> !hasIncome
                        else -> true
                    }
                }
            }
            // 6. فلتر شرائح المحليات/المناطق مع مفتاح التجاوز (Bypass) - فحص صارم للمنطقة الفرعية الحالية
            .filter { fam ->
                if (!localityEnabled) true
                else {
                    val key = fam.currentSubArea.ifBlank { "غير مصنف" }
                    evaluateChipFilter(key, localityChips)
                }
            }
            // 7. شرط وجود الأبناء ونطاق الأعمار مع مفتاح التجاوز (Children & Age Range Filter)
            .filter { fam ->
                if (!childrenFilterEnabled) true
                else {
                    val ages = childrenAgesMap[fam.nationalID] ?: emptyList()
                    ages.any { it in minChildAge..maxChildAge }
                }
            }
            // 8. فلتر الحالة الاجتماعية (اختيار متعدد + استثناء المحدد)
            .filter { fam ->
                if (!maritalStatusEnabled || selectedMaritalStatuses.isEmpty()) {
                    true
                } else {
                    val statusValue = fam.maritalStatus.trim().ifBlank { "غير مصنف" }
                    val isMatch = selectedMaritalStatuses.any { it.trim() == statusValue }
                    if (excludeMaritalStatuses) !isMatch else isMatch
                }
            }
            // 9. حد أفراد الأسرة المقارن بالقيمة المحددة بدقة (يتجاهل القيمة <= 1)
            .filter { fam ->
                if (minMembers <= 1) true else fam.familyMembersCount >= minMembers
            }
            // 10. الترتيب الأولوية الإلزامي: الأكبر حجماً أولاً
            .sortedByDescending { it.familyMembersCount }
            .toList()
    }

    private fun evaluateChipFilter(value: String, chips: Map<String, ChipFilterState>): Boolean {
        if (chips.isEmpty()) return true
        val included = chips.filter { it.value == ChipFilterState.INCLUDED }.keys
        val excluded = chips.filter { it.value == ChipFilterState.EXCLUDED }.keys

        // إذا كان هناك عناصر مستثناة وتحتوي على القيمة -> استبعاد فوري
        if (excluded.contains(value)) return false
        // إذا كان هناك عناصر متضمنة -> يجب أن تطابق أحدها
        if (included.isNotEmpty() && !included.contains(value)) return false
        return true
    }

    // ==========================================
    // الترشيح الآلي واليدوي المحمي بالأقفال (Auto-Nominate & Manual Override)
    // ==========================================

    private var autoNominationJob: Job? = null

    /**
     * الترشيح الآلي: يوزع الحصص المتبقية بنزاهة تامة مع احتساب الترشيحات السابقة لكل محلية
     * ولا يتجاوز بأي حال الحصة المتبقية (المستهدف - المرشح سابقاً).
     */
    fun runAutoNomination() {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return
        val project = selectedProject.value ?: return
        if (!project.isOpen) return // منع التعديل في وضع القراءة فقط

        val quotas = localityQuotasMap.value
        val pool = filteredFamilies.value
        val prevBySubArea = alreadyNominatedBySubArea.value
        val excludedIds = alreadyNominatedFamilyIds.value

        autoNominationJob?.cancel()
        autoNominationJob = viewModelScope.launch(Dispatchers.IO) {
            val restricted = isGeoRestrictedUser.value
            val effReg = effectiveUserRegion.value
            val effSubReg = effectiveUserSubRegion.value

            val remainingCapacity = if (restricted) {
                val scopedTarget = visibleTargetQuota.value
                val scopedAlready = if (effReg != "ALL" || effSubReg != "ALL") {
                    repository.getProjectScopedNominatedCountSync(project.projectID, effReg, effSubReg)
                } else {
                    alreadyNominatedCount.value
                }
                (scopedTarget - scopedAlready).coerceAtLeast(0)
            } else {
                val dbAlreadyCount = repository.getProjectNominatedDistinctCountSync(project.projectID)
                (project.targetQuota - dbAlreadyCount).coerceAtLeast(0)
            }

            if (remainingCapacity <= 0) {
                selectedNominees.value = emptySet()
                return@launch
            }

            val eligiblePool = pool.filter { !excludedIds.contains(it.familyID) }
            val result = mutableSetOf<FamilyEntity>()

            // تجميع الأسر المؤهلة حسب المنطقة الفرعية الحالية (currentSubArea)
            val poolByLocality = eligiblePool.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }

            // التوزيع الحصري حتى استيفاء الحصة المتبقية لكل محلية (حصة المحلية - المرشح سابقاً بها)
            quotas.forEach { (locName, totalLocQuota) ->
                if (totalLocQuota > 0 && result.size < remainingCapacity) {
                    val prevInLoc = prevBySubArea[locName] ?: 0
                    val remainingInLoc = (totalLocQuota - prevInLoc).coerceAtLeast(0)
                    if (remainingInLoc > 0) {
                        val availableInLoc = poolByLocality[locName] ?: emptyList()
                        val needed = remainingInLoc.coerceAtMost(remainingCapacity - result.size)
                        result.addAll(availableInLoc.take(needed))
                    }
                }
            }

            // للنظام غير المقيد فقط: ملء أي فجوة متبقية من باقي الأسر المؤهلة
            if (!restricted && result.size < remainingCapacity) {
                val remaining = eligiblePool.filter { !result.contains(it) }
                val needed = remainingCapacity - result.size
                result.addAll(remaining.take(needed))
            }

            selectedNominees.value = result
        }
    }

    /**
     * الإضافة اليدوية لأسرة مع فرض عدم تكرارها وعدم تجاوز الحصة المتبقية للمشروع
     */
    fun addNomineeManually(family: FamilyEntity): Boolean {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return false
        val project = selectedProject.value ?: return false
        if (!project.isOpen) return false
        if (alreadyNominatedFamilyIds.value.contains(family.familyID)) return false
        if (selectedNominees.value.size >= remainingQuota.value) return false

        val current = selectedNominees.value.toMutableSet()
        val added = current.add(family)
        if (added) {
            selectedNominees.value = current
        }
        return added
    }

    /**
     * الاستبعاد اليدوي (Swipe to Dismiss / Remove)
     */
    fun removeNominee(family: FamilyEntity) {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return
        val project = selectedProject.value ?: return
        if (!project.isOpen) return

        val current = selectedNominees.value.toMutableSet()
        if (current.remove(family)) {
            selectedNominees.value = current
        }
    }

    fun clearNominees() {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) return
        val project = selectedProject.value ?: return
        if (!project.isOpen) return
        selectedNominees.value = emptySet()
    }

    /**
     * اعتماد وترحيل الترشيحات رسمياً إلى قاعدة البيانات (إضافة تراكمية بدون مسح السابق)
     */
    suspend fun commitNomination(): Result<Int> = withContext(Dispatchers.IO) {
        if (!repository.isSuperAdmin() && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_NOMINATE)) {
            return@withContext Result.failure(SecurityException("ليس لديك صلاحية اعتماد وترحيل الترشيحات"))
        }
        val project = selectedProject.value
            ?: return@withContext Result.failure(IllegalStateException("لم يتم اختيار أي مشروع"))
        if (!project.isOpen) {
            return@withContext Result.failure(IllegalStateException("المشروع مغلق أو مقفل ولا يمكن اعتماد ترشيحات له"))
        }

        val nominees = selectedNominees.value
        if (nominees.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("قائمة المرشحين فارغة"))
        }

        try {
            val insertedCount = repository.commitNomineesToProject(
                projectId = project.projectID,
                aidTypeId = project.aidTypeID,
                familyIds = nominees.map { it.familyID },
                mechanism = "هجين (آلي/يدوي)"
            )
            selectedNominees.value = emptySet()
            Result.success(insertedCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // حقول ودوال التوافق البرمجي مع الشاشات السابقة
    // ==========================================
    val isFiltering = MutableStateFlow(false)
    val dynamicNominationResult = MutableStateFlow<DynamicNominationResult?>(null)
    val calculatedQuotas = MutableStateFlow<List<LocalityQuota>>(emptyList())
    val filteredEligibleFamilies: StateFlow<List<FamilyEntity>> = filteredFamilies
    val resultLimitText = MutableStateFlow("300")
    val selectedLocalities = MutableStateFlow<Set<String>>(emptySet())
    val excludeLocalities = MutableStateFlow(false)
    val selectedAidCategories = MutableStateFlow<Set<String>>(emptySet())
    val excludeAidCategories = MutableStateFlow(true)
    val selectedDamageTypes = MutableStateFlow<Set<String>>(emptySet())
    val excludeDamageTypes = MutableStateFlow(false)
    val selectedShelterStatuses = MutableStateFlow<Set<String>>(emptySet())
    val excludeShelterStatuses = MutableStateFlow(false)
    val selectedWorksApprovals = MutableStateFlow<Set<String>>(emptySet())
    val excludeWorksApprovals = MutableStateFlow(false)
    val selectedIncomeSources = MutableStateFlow<Set<String>>(emptySet())
    val excludeIncomeSources = MutableStateFlow(false)
    val selectedSubAreas = MutableStateFlow<Set<String>>(emptySet())
    val excludeSubAreas = MutableStateFlow(false)
    val selectedLocalityId = MutableStateFlow(0)
    val excludeLocality = MutableStateFlow(false)
    val statusFilterTab = MutableStateFlow<CandidateStatus?>(null)
    val customLocalityQuotas = MutableStateFlow<Map<String, String>>(emptyMap())

    val localities: StateFlow<List<String>> = combine(
        repository.getDistinctLocalities(),
        canViewAllLocalities
    ) { list, allowAll ->
        val allowedNames = AccessControlManager.getCleanAllowedLocalities()
        val clean = list.map { it.trim() }.filter { it.isNotBlank() }.distinct().let { dbLocs ->
            if (repository.isSuperAdmin() || allowedNames.isEmpty()) dbLocs
            else dbLocs.filter { loc -> allowedNames.any { it.equals(loc, ignoreCase = true) } }
        }
        if (allowAll) listOf("الكل") + clean else clean
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pureLocalities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { list ->
            val allowedNames = AccessControlManager.getCleanAllowedLocalities()
            val clean = list.map { it.trim() }.filter { it.isNotBlank() }.distinct()
            if (repository.isSuperAdmin() || allowedNames.isEmpty()) clean
            else clean.filter { loc -> allowedNames.any { it.equals(loc, ignoreCase = true) } }
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val pureAidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val shelterStatuses: StateFlow<List<String>> = repository.getDistinctShelterStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val worksApprovals: StateFlow<List<String>> = repository.getDistinctWorksApprovalsFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    fun toggleLocality(name: String) = cycleChipState("locality", name)
    fun toggleCategory(cat: String) {
        val cur = selectedAidCategories.value.toMutableSet()
        if (cur.contains(cat)) cur.remove(cat) else cur.add(cat)
        selectedAidCategories.value = cur
    }
    fun clearCategories() {
        selectedAidCategories.value = emptySet()
    }
    fun toggleDamageType(type: String) {
        val cur = selectedDamageTypes.value.toMutableSet()
        if (cur.contains(type)) cur.remove(type) else cur.add(type)
        selectedDamageTypes.value = cur
        cycleChipState("damage", type)
    }
    fun clearDamageTypes() {
        selectedDamageTypes.value = emptySet()
        damageChipStates.value = emptyMap()
    }
    fun toggleShelterStatus(status: String) {
        val cur = selectedShelterStatuses.value.toMutableSet()
        if (cur.contains(status)) cur.remove(status) else cur.add(status)
        selectedShelterStatuses.value = cur
        cycleChipState("shelter", status)
    }
    fun clearShelterStatuses() {
        selectedShelterStatuses.value = emptySet()
        shelterChipStates.value = emptyMap()
    }
    fun toggleWorksApproval(approval: String) {
        val cur = selectedWorksApprovals.value.toMutableSet()
        if (cur.contains(approval)) cur.remove(approval) else cur.add(approval)
        selectedWorksApprovals.value = cur
    }
    fun clearWorksApprovals() {
        selectedWorksApprovals.value = emptySet()
    }
    fun toggleMaritalStatus(status: String) {
        val clean = status.trim()
        if (clean.isBlank()) return
        val cur = selectedMaritalStatuses.value.toMutableList()
        if (cur.contains(clean)) cur.remove(clean) else cur.add(clean)
        selectedMaritalStatuses.value = cur
    }
    fun clearMaritalStatuses() {
        selectedMaritalStatuses.value = emptyList()
    }
    fun setExcludeMaritalStatuses(exclude: Boolean) {
        excludeMaritalStatuses.value = exclude
    }
    fun setMaritalStatusFilterEnabled(enabled: Boolean) {
        maritalStatusFilterEnabled.value = enabled
    }
    fun toggleIncomeSource(source: String) {
        val cur = selectedIncomeSources.value.toMutableSet()
        if (cur.contains(source)) cur.remove(source) else cur.add(source)
        selectedIncomeSources.value = cur
    }
    fun clearIncomeSources() {
        selectedIncomeSources.value = emptySet()
    }
    fun toggleSubArea(area: String) {
        val cur = selectedSubAreas.value.toMutableSet()
        if (cur.contains(area)) cur.remove(area) else cur.add(area)
        selectedSubAreas.value = cur
    }
    fun clearSubAreas() {
        selectedSubAreas.value = emptySet()
    }
    fun resetFilters() {
        clearAllFilterChips()
        selectedLocalities.value = emptySet()
        excludeLocalities.value = false
        selectedAidCategories.value = emptySet()
        excludeAidCategories.value = true
        selectedDamageTypes.value = emptySet()
        excludeDamageTypes.value = false
        selectedShelterStatuses.value = emptySet()
        excludeShelterStatuses.value = false
        selectedWorksApprovals.value = emptySet()
        excludeWorksApprovals.value = false
        selectedMaritalStatuses.value = emptyList()
        excludeMaritalStatuses.value = false
        maritalStatusFilterEnabled.value = true
        _workStatusFilter.value = "الكل"
        selectedIncomeSources.value = emptySet()
        excludeIncomeSources.value = false
        selectedSubAreas.value = emptySet()
        excludeSubAreas.value = false
        selectedLocalityId.value = 0
        excludeLocality.value = false
        selectedLocalityFilter.value = lockedLocalityName.value ?: ""
        selectedBranchFilter.value = lockedBranchName.value ?: ""
        statusFilterTab.value = null
    }

    private var filteringJob: Job? = null

    fun clearState() {
        refreshOptionsJob?.cancel()
        autoNominationJob?.cancel()
        filteringJob?.cancel()
        selectedNominees.value = emptySet()
        selectedProject.value = null
        dynamicNominationResult.value = null
        calculatedQuotas.value = emptyList()
        customLocalityQuotas.value = emptyMap()
        isFiltering.value = false
        resetFilters()
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    fun runFilteringEngine() {
        filteringJob?.cancel()
        filteringJob = viewModelScope.launch {
            isFiltering.value = true
            try {
                val excludedIds = if (selectedAidCategories.value.isNotEmpty()) {
                    activeAidTypes.value
                        .filter { selectedAidCategories.value.contains(it.aidTypeName) }
                        .map { it.aidTypeID }
                        .toSet()
                } else {
                    emptySet()
                }
                val requestedTarget = targetBeneficiariesText.value.toIntOrNull() ?: 100
                val activeDynProject = dynamicSelectedProject.value
                val effReg = effectiveUserRegion.value
                val effSubReg = effectiveUserSubRegion.value
                val restricted = isGeoRestrictedUser.value
                val effectiveTarget = if (activeDynProject != null && activeDynProject.targetQuota > 0) {
                    val rem = if (restricted) {
                        val scopedAlready = repository.getProjectScopedNominatedCountSync(selectedProjectId.value, effReg, effSubReg)
                        (dynamicTargetQuota.value - scopedAlready).coerceAtLeast(0)
                    } else {
                        val already = repository.getProjectNominatedDistinctCountSync(selectedProjectId.value)
                        (activeDynProject.targetQuota - already).coerceAtLeast(0)
                    }
                    requestedTarget.coerceAtMost(rem)
                } else {
                    requestedTarget
                }
                val criteria = DynamicNominationCriteria(
                    exclusionMode = exclusionMode.value,
                    exclusionDays = exclusionDaysText.value.toIntOrNull(),
                    exclusionDateCutoff = exclusionDateCutoffText.value.takeIf { it.isNotBlank() },
                    excludedAidTypeIds = excludedIds,
                    hasChildrenOnly = hasChildrenOnly.value,
                    minChildAge = minChildAgeText.value.toIntOrNull(),
                    maxChildAge = maxChildAgeText.value.toIntOrNull(),
                    selectedDamageTypes = selectedDamageTypes.value,
                    excludeDamageTypes = excludeDamageTypes.value,
                    selectedMaritalStatuses = if (maritalStatusFilterEnabled.value) selectedMaritalStatuses.value.toSet() else emptySet(),
                    excludeMaritalStatuses = excludeMaritalStatuses.value,
                    selectedWorksApprovals = selectedWorksApprovals.value,
                    excludeWorksApprovals = excludeWorksApprovals.value,
                    selectedShelterStatuses = selectedShelterStatuses.value,
                    excludeShelterStatuses = excludeShelterStatuses.value,
                    workStatusFilter = if (incomeFilterEnabled.value) _workStatusFilter.value else "الكل",
                    selectedIncomeSources = selectedIncomeSources.value,
                    excludeIncomeSources = excludeIncomeSources.value,
                    selectedSubAreas = selectedSubAreas.value,
                    excludeSubAreas = excludeSubAreas.value,
                    selectedLocalityId = selectedLocalityId.value,
                    excludeLocality = excludeLocality.value,
                    selectedAidTypeId = selectedAidTypeId.value,
                    projectId = selectedProjectId.value,
                    minFamilyMembers = minFamilyMembers.value,
                    limit = resultLimitText.value.toIntOrNull() ?: 300,
                    targetBeneficiaries = effectiveTarget,
                    userRegion = effReg,
                    userSubRegion = effSubReg
                )
                val result = repository.runDynamicNomination(criteria)
                dynamicNominationResult.value = result
                if (result.quotas.isNotEmpty()) {
                    calculatedQuotas.value = result.quotas
                }
            } finally {
                isFiltering.value = false
            }
        }
    }

    class Factory(
        private val repository: AidRepository,
        private val initialAssignedSubRegion: String = "All"
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NominationViewModel(repository, initialAssignedSubRegion) as T
        }
    }
}
