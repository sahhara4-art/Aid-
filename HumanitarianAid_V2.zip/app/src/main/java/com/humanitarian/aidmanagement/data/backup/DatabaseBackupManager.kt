package com.humanitarian.aidmanagement.data.backup

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.widget.Toast
import com.humanitarian.aidmanagement.MainActivity
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * معلومات النسخة الاحتياطية
 */
data class BackupMetadata(
    val exportDate: String,
    val timestamp: Long,
    val appVersion: String = "1.0.0",
    val totalFamilies: Int,
    val totalChildren: Int,
    val totalAidRecords: Int,
    val totalProjects: Int
)

data class BackupResult(
    val success: Boolean,
    val message: String,
    val filePath: String? = null,
    val fileSizeKb: Long = 0,
    val metadata: BackupMetadata? = null
)

/**
 * مدير النسخ الاحتياطي لقاعدة بيانات Room محلياً (JSON & SQL)
 */
class DatabaseBackupManager(
    private val context: Context,
    private val database: AidDatabase
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())

    /**
     * حفظ النسخة الاحتياطية في المجلد العام الخارجي المخصص AidManagementBackups
     * باستخدام Scoped Storage (MediaStore API على أندرويد 10+ أو التخزين العام للأنظمة الأقدم)
     * لضمان بقاء النسخ الاحتياطية حتى بعد إلغاء تثبيت التطبيق.
     */
    private fun writeToScopedStorage(
        fileName: String,
        mimeType: String,
        writer: (java.io.OutputStream) -> Unit
    ): Pair<String, Long> {
        val folderName = "AidManagementBackups"

        // 1. الكتابة في المجلد العام الخارجي عبر MediaStore Downloads لنظام Android 10 (Q) وما بعده
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val contentValues = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "${android.os.Environment.DIRECTORY_DOWNLOADS}/$folderName")
                put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                ?: throw IllegalStateException("فشل إنشاء ملف النسخة الاحتياطية في MediaStore")

            resolver.openOutputStream(uri)?.use { os ->
                writer(os)
                os.flush()
            } ?: throw IllegalStateException("تعذر فتح تيار الكتابة لملف النسخة الاحتياطية")

            contentValues.clear()
            contentValues.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, contentValues, null, null)

            // حفظ نسخة مطابقة أيضاً في مجلد التطبيق لتسهيل المعاينة والاسترجاع الفوري السريع
            val localDir = File(context.getExternalFilesDir(null), "backups").apply { mkdirs() }
            val localMirror = File(localDir, fileName)
            try {
                resolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(localMirror).use { output ->
                        input.copyTo(output)
                        output.flush()
                    }
                }
            } catch (e: Exception) { }

            val sizeKb = if (localMirror.exists()) localMirror.length() / 1024 else 0L
            return Pair("Downloads/$folderName/$fileName", sizeKb)
        } else {
            // الأنظمة السابقة لأندرويد 10: حفظ مباشر في مجلد Downloads/AidManagementBackups العام
            val publicDownloads = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            val customFolder = File(publicDownloads, folderName).apply { mkdirs() }
            val targetFile = File(customFolder, fileName)

            FileOutputStream(targetFile).use { fos ->
                writer(fos)
                fos.flush()
            }

            // حفظ نسخة احتياطية محلية
            val localDir = File(context.getExternalFilesDir(null), "backups").apply { mkdirs() }
            val localMirror = File(localDir, fileName)
            try { targetFile.copyTo(localMirror, overwrite = true) } catch (e: Exception) { }

            return Pair(targetFile.absolutePath, targetFile.length() / 1024)
        }
    }

    /**
     * تصدير قاعدة البيانات كاملة إلى ملف JSON منظم
     */
    suspend fun exportToJson(): BackupResult = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject()

            // 1. جلب البيانات من كافة الجداول
            val families = database.familyDao().getAllFamilies().first()
            val children = database.childDao().searchChildren("").first()
            val aidTypes = database.aidTypeDao().getAllActiveAidTypes().first()
            val projects = database.projectDao().getAllActiveProjects().first()
            val aidRecords = database.aidRecordDao().getAllAidRecords().first()
            val localities = database.localityDao().getAllLocalities().first()
            val distributions = database.localityDao().getDistributions().first()
            val settings = database.systemSettingDao().getAllSettings().first()
            val users = database.userDao().getAllUsers().first()

            val now = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now))

            // 2. ترويسة النسخة الاحتياطية
            val metaObj = JSONObject().apply {
                put("systemName", "نظام إدارة المساعدات الإنسانية")
                put("packageName", "com.humanitarian.aidmanagement")
                put("exportDate", dateStr)
                put("timestamp", now)
                put("version", "1.0.0")
                put("familiesCount", families.size)
                put("childrenCount", children.size)
                put("aidRecordsCount", aidRecords.size)
                put("projectsCount", projects.size)
            }
            root.put("metadata", metaObj)

            // 3. جدول الأسر
            val familiesArray = JSONArray()
            families.forEach { f ->
                val obj = JSONObject().apply {
                    put("familyID", f.familyID)
                    put("name", f.name)
                    put("nationalID", f.nationalID)
                    put("birthDate", f.birthDate)
                    put("gender", f.gender)
                    put("maritalStatus", f.maritalStatus)
                    put("familyMembersCount", f.familyMembersCount)
                    put("wifeName", f.wifeName ?: "")
                    put("wifeNationalID", f.wifeNationalID ?: "")
                    put("deathStatus", f.deathStatus)
                    put("developmentApproval", f.developmentApproval)
                    put("localityApproval", f.localityApproval)
                    put("worksApproval", f.worksApproval)
                    put("residentStatus", f.residentStatus)
                    put("damageType", f.damageType)
                    put("shelterStatus", f.shelterStatus)
                    put("localityID", f.localityID)
                    put("notes", f.notes ?: "")
                    put("createdDate", f.createdDate)
                }
                familiesArray.put(obj)
            }
            root.put("families", familiesArray)

            // 4. جدول الأطفال
            val childrenArray = JSONArray()
            children.forEach { c ->
                val obj = JSONObject().apply {
                    put("childID", c.childID)
                    put("nationalID", c.nationalID)
                    put("childName", c.childName)
                    put("birthDate", c.birthDate)
                    put("gender", c.gender)
                    put("familyNationalID", c.familyNationalID)
                    put("localityID", c.localityID)
                    put("shelterStatus", c.shelterStatus)
                }
                childrenArray.put(obj)
            }
            root.put("children", childrenArray)

            // 5. أنواع المساعدات
            val aidTypesArray = JSONArray()
            aidTypes.forEach { a ->
                val obj = JSONObject().apply {
                    put("aidTypeID", a.aidTypeID)
                    put("aidTypeName", a.aidTypeName)
                    put("description", a.description)
                    put("defaultExclusionDays", a.defaultExclusionDays)
                }
                aidTypesArray.put(obj)
            }
            root.put("aid_types", aidTypesArray)

            // 6. المشاريع
            val projectsArray = JSONArray()
            projects.forEach { p ->
                val obj = JSONObject().apply {
                    put("projectID", p.projectID)
                    put("projectNumber", p.projectNumber)
                    put("projectName", p.projectName)
                    put("aidTypeID", p.aidTypeID)
                    put("detailedDescription", p.detailedDescription)
                    put("projectDate", p.projectDate)
                    put("fundingInstitution", p.fundingInstitution)
                    put("quantity", p.quantity)
                }
                projectsArray.put(obj)
            }
            root.put("projects", projectsArray)

            // 7. سجلات المساعدات
            val aidRecordsArray = JSONArray()
            aidRecords.forEach { r ->
                val obj = JSONObject().apply {
                    put("aidRecordID", r.aidRecordID)
                    put("familyID", r.familyID)
                    put("aidTypeID", r.aidTypeID)
                    put("projectID", r.projectID)
                    put("aidDate", r.aidDate)
                    put("selectionDate", r.selectionDate)
                    put("recipientStatus", r.recipientStatus)
                    put("warehouse", r.warehouse)
                    put("aidValue", r.aidValue)
                }
                aidRecordsArray.put(obj)
            }
            root.put("aid_records", aidRecordsArray)

            // 8. حفظ الملف في التخزين الخارجي العام عبر Scoped Storage
            val fileName = "HumanitarianAid_Backup_${dateFormat.format(Date(now))}.json"
            val (savedPath, sizeKb) = writeToScopedStorage(fileName, "application/json") { os ->
                os.write(root.toString(2).toByteArray(Charsets.UTF_8))
            }

            BackupResult(
                success = true,
                message = "تم حفظ النسخة الاحتياطية بنجاح في مجلد التنزيلات (Downloads/AidManagementBackups)",
                filePath = savedPath,
                fileSizeKb = sizeKb,
                metadata = BackupMetadata(
                    exportDate = dateStr,
                    timestamp = now,
                    totalFamilies = families.size,
                    totalChildren = children.size,
                    totalAidRecords = aidRecords.size,
                    totalProjects = projects.size
                )
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "حدث خطأ أثناء تصدير النسخة الاحتياطية: ${e.localizedMessage}"
            )
        }
    }

    /**
     * تصدير قاعدة البيانات كأوامر SQL Dump جاهزة للاستيراد
     */
    suspend fun exportToSql(): BackupResult = withContext(Dispatchers.IO) {
        try {
            val sb = StringBuilder()
            val now = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now))

            sb.append("-- ========================================================\n")
            sb.append("-- نظام إدارة المساعدات الإنسانية - نسخة احتياطية SQL Dump\n")
            sb.append("-- تاريخ التصدير: $dateStr\n")
            sb.append("-- ========================================================\n\n")

            sb.append("BEGIN TRANSACTION;\n\n")

            // الأسر
            val families = database.familyDao().getAllFamilies().first()
            sb.append("-- تفريغ بيانات جدول الأسر (${families.size} أسرة)\n")
            families.forEach { f ->
                val name = f.name.replace("'", "''")
                val notes = (f.notes ?: "").replace("'", "''")
                val wife = (f.wifeName ?: "").replace("'", "''")
                sb.append("INSERT OR REPLACE INTO families (familyID, name, nationalID, birthDate, gender, maritalStatus, familyMembersCount, wifeName, wifeNationalID, deathStatus, developmentApproval, localityApproval, worksApproval, residentStatus, damageType, shelterStatus, localityID, notes, createdDate) ")
                sb.append("VALUES (${f.familyID}, '$name', '${f.nationalID}', '${f.birthDate}', '${f.gender}', '${f.maritalStatus}', ${f.familyMembersCount}, '$wife', '${f.wifeNationalID ?: ""}', '${f.deathStatus}', '${f.developmentApproval}', '${f.localityApproval}', '${f.worksApproval}', '${f.residentStatus}', '${f.damageType}', '${f.shelterStatus}', ${f.localityID}, '$notes', ${f.createdDate});\n")
            }
            sb.append("\n")

            // الأطفال
            val children = database.childDao().searchChildren("").first()
            sb.append("-- تفريغ بيانات جدول الأطفال (${children.size} طفل)\n")
            children.forEach { c ->
                val name = c.childName.replace("'", "''")
                sb.append("INSERT OR REPLACE INTO children (childID, nationalID, childName, birthDate, gender, familyNationalID, localityID, shelterStatus) ")
                sb.append("VALUES (${c.childID}, '${c.nationalID}', '$name', '${c.birthDate}', '${c.gender}', '${c.familyNationalID}', ${c.localityID}, '${c.shelterStatus}');\n")
            }
            sb.append("\n")

            // المشاريع وسجلات المساعدات
            val projects = database.projectDao().getAllActiveProjects().first()
            projects.forEach { p ->
                val pName = p.projectName.replace("'", "''")
                val pDesc = p.detailedDescription.replace("'", "''")
                val pFund = p.fundingInstitution.replace("'", "''")
                sb.append("INSERT OR REPLACE INTO projects (projectID, projectNumber, projectName, aidTypeID, detailedDescription, projectDate, fundingInstitution, quantity, isActive) ")
                sb.append("VALUES (${p.projectID}, '${p.projectNumber}', '$pName', ${p.aidTypeID}, '$pDesc', '${p.projectDate}', '$pFund', ${p.quantity}, 1);\n")
            }

            val records = database.aidRecordDao().getAllAidRecords().first()
            records.forEach { r ->
                sb.append("INSERT OR REPLACE INTO aid_records (aidRecordID, familyID, aidTypeID, projectID, aidDate, selectionDate, recipientStatus, warehouse, aidValue) ")
                sb.append("VALUES (${r.aidRecordID}, ${r.familyID}, ${r.aidTypeID}, ${r.projectID}, '${r.aidDate}', '${r.selectionDate}', '${r.recipientStatus}', '${r.warehouse}', ${r.aidValue});\n")
            }

            sb.append("\nCOMMIT;\n")

            val fileName = "HumanitarianAid_Dump_${dateFormat.format(Date(now))}.sql"
            val (savedPath, sizeKb) = writeToScopedStorage(fileName, "application/sql") { os ->
                os.write(sb.toString().toByteArray(Charsets.UTF_8))
            }

            BackupResult(
                success = true,
                message = "تم إنشاء وحفظ ملف تفريغ SQL بنجاح في مجلد (Downloads/AidManagementBackups)",
                filePath = savedPath,
                fileSizeKb = sizeKb,
                metadata = BackupMetadata(
                    exportDate = dateStr,
                    timestamp = now,
                    totalFamilies = families.size,
                    totalChildren = children.size,
                    totalAidRecords = records.size,
                    totalProjects = projects.size
                )
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "حدث خطأ أثناء تصدير ملف SQL: ${e.localizedMessage}"
            )
        }
    }

    /**
     * استعادة قاعدة البيانات من ملف JSON
     */
    suspend fun restoreFromJson(jsonString: String, clearExisting: Boolean = false): BackupResult = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            val familiesArray = root.optJSONArray("families") ?: JSONArray()
            val childrenArray = root.optJSONArray("children") ?: JSONArray()
            val projectsArray = root.optJSONArray("projects") ?: JSONArray()
            val aidRecordsArray = root.optJSONArray("aid_records") ?: JSONArray()

            var restoredFamilies = 0
            var restoredChildren = 0
            var restoredProjects = 0
            var restoredRecords = 0

            // استعادة الأسر
            for (i in 0 until familiesArray.length()) {
                val obj = familiesArray.getJSONObject(i)
                val family = FamilyEntity(
                    familyID = obj.optLong("familyID", 0),
                    name = obj.getString("name"),
                    nationalID = obj.getString("nationalID"),
                    birthDate = obj.optString("birthDate", "1980-01-01"),
                    gender = obj.optString("gender", "ذكر"),
                    maritalStatus = obj.optString("maritalStatus", "متزوج"),
                    familyMembersCount = obj.optInt("familyMembersCount", 6),
                    wifeName = obj.optString("wifeName").takeIf { it.isNotBlank() },
                    wifeNationalID = obj.optString("wifeNationalID").takeIf { it.isNotBlank() },
                    deathStatus = obj.optString("deathStatus", "على قيد الحياة"),
                    developmentApproval = obj.optString("developmentApproval", "معتمد"),
                    localityApproval = obj.optString("localityApproval", "معتمد"),
                    worksApproval = obj.optString("worksApproval", "معتمد أشغال"),
                    residentStatus = obj.optString("residentStatus", "مقيم"),
                    damageType = obj.optString("damageType", "أضرار كلية"),
                    shelterStatus = obj.optString("shelterStatus", "إيواء داخلي"),
                    localityID = obj.optInt("localityID", 1),
                    notes = obj.optString("notes").takeIf { it.isNotBlank() },
                    createdDate = obj.optLong("createdDate", System.currentTimeMillis())
                )
                database.familyDao().insertFamily(family)
                restoredFamilies++
            }

            // استعادة الأطفال
            for (i in 0 until childrenArray.length()) {
                val obj = childrenArray.getJSONObject(i)
                val child = ChildEntity(
                    childID = obj.optLong("childID", 0),
                    nationalID = obj.getString("nationalID"),
                    childName = obj.getString("childName"),
                    birthDate = obj.optString("birthDate", "2020-01-01"),
                    gender = obj.optString("gender", "ذكر"),
                    familyNationalID = obj.getString("familyNationalID"),
                    localityID = obj.optInt("localityID", 1),
                    shelterStatus = obj.optString("shelterStatus", "إيواء داخلي")
                )
                database.childDao().insertChild(child)
                restoredChildren++
            }

            // استعادة المشاريع
            for (i in 0 until projectsArray.length()) {
                val obj = projectsArray.getJSONObject(i)
                val project = ProjectEntity(
                    projectID = obj.optLong("projectID", 0),
                    projectNumber = obj.getString("projectNumber"),
                    projectName = obj.getString("projectName"),
                    aidTypeID = obj.optInt("aidTypeID", 1),
                    detailedDescription = obj.optString("detailedDescription", ""),
                    projectDate = obj.optString("projectDate", "2025-01-01"),
                    fundingInstitution = obj.optString("fundingInstitution", "منحة إغاثية"),
                    quantity = obj.optInt("quantity", 100),
                    isActive = true
                )
                database.projectDao().insertProject(project)
                restoredProjects++
            }

            // استعادة سجلات المساعدات
            for (i in 0 until aidRecordsArray.length()) {
                val obj = aidRecordsArray.getJSONObject(i)
                val record = AidRecordEntity(
                    aidRecordID = obj.optLong("aidRecordID", 0),
                    familyID = obj.optLong("familyID"),
                    aidTypeID = obj.optInt("aidTypeID", 1),
                    projectID = obj.optLong("projectID", 1),
                    aidDate = obj.optString("aidDate", "2025-01-01"),
                    selectionDate = obj.optString("selectionDate", "2025-01-01"),
                    recipientStatus = obj.optString("recipientStatus", "مرشح"),
                    warehouse = obj.optString("warehouse", "المستودع الرئيسي"),
                    aidValue = obj.optDouble("aidValue", 50.0)
                )
                database.aidRecordDao().insertAidRecord(record)
                restoredRecords++
            }

            try {
                database.invalidationTracker.refreshVersionsAsync()
            } catch (_: Exception) {}

            BackupResult(
                success = true,
                message = "تمت استعادة البيانات بنجاح: $restoredFamilies أسرة، $restoredChildren طفلاً، $restoredProjects مشاريع، $restoredRecords سجل مساعدة.",
                metadata = BackupMetadata(
                    exportDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()),
                    timestamp = System.currentTimeMillis(),
                    totalFamilies = restoredFamilies,
                    totalChildren = restoredChildren,
                    totalAidRecords = restoredRecords,
                    totalProjects = restoredProjects
                )
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "فشلت عملية الاستعادة: ${e.localizedMessage}"
            )
        }
    }

    /**
     * ⚙️ MISSION 1: THE BACKUP PROCESS (Safe Export)
     * - Close the Room Database gracefully: database.close().
     * - Wait 500ms to ensure WAL writes to disk.
     * - Zip the main .db file, .db-wal, and .db-shm (if they exist) from the context.getDatabasePath(DB_NAME).parentFile
     *   into a single exported .zip file.
     * - Re-establish database connection so subsequent queries in the current session succeed.
     */
    suspend fun exportEncryptedDatabaseZip(): BackupResult = withContext(Dispatchers.IO) {
        try {
            val now = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(now))
            val backupFileName = "AidManagement_Encrypted_Backup_${dateStr}.zip"

            val totalFamilies = try { database.familyDao().getTotalFamiliesCount() } catch (_: Exception) { 0 }
            val totalAidRecords = try { database.aidRecordDao().getTotalAidRecordsCount() } catch (_: Exception) { 0 }
            val totalProjects = try { database.projectDao().getTotalProjectsCount() } catch (_: Exception) { 0 }

            val dbName = AidDatabase.DATABASE_NAME
            val dbPath = context.getDatabasePath(dbName)
            val parentDir = dbPath.parentFile ?: File(context.filesDir.parentFile, "databases")

            // 1. إجبار قاعدة البيانات على دمج كافة التعديلات المعلقة من الذاكرة (WAL) إلى الملف الرئيسي
            try {
                database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").close()
            } catch (e: Exception) {
                Log.w(TAG, "wal_checkpoint TRUNCATE: ${e.message}")
            }

            // 2. إغلاق قاعدة بيانات Room بنعومة وقطع مرجع Singleton لضمان تحرير كافة المقابض
            try {
                database.close()
            } catch (e: Exception) {
                Log.w(TAG, "database.close(): ${e.message}")
            }
            AidDatabase.resetInstance()

            // 3. انتظار 500 ميلي ثانية لضمان اكتمال كتابة وتفريغ ملفات WAL بالكامل إلى القرص
            delay(500)

            if (!dbPath.exists()) {
                // محاولة إعادة الاتصال قبل الخروج
                try { AidDatabase.reestablishConnection(context) } catch (_: Exception) {}
                return@withContext BackupResult(
                    success = false,
                    message = "ملف قاعدة البيانات غير موجود على المسار (${dbPath.name})"
                )
            }

            val walFile = File(parentDir, "$dbName-wal")
            val shmFile = File(parentDir, "$dbName-shm")

            val metaObj = JSONObject().apply {
                put("systemName", "نظام إدارة المساعدات الإنسانية - قاعدة مشفرة")
                put("exportDate", dateStr)
                put("timestamp", now)
                put("totalFamilies", totalFamilies)
                put("totalAidRecords", totalAidRecords)
                put("totalProjects", totalProjects)
            }

            // 4. ضغط ملف قاعدة البيانات الرئيسي (.db) وملحقات (WAL & SHM) وبيانات الميتاداتا
            val (savedPath, sizeKb) = writeToScopedStorage(backupFileName, "application/zip") { os ->
                java.util.zip.ZipOutputStream(os).use { zos ->
                    // ملف البيانات الوصفية
                    zos.putNextEntry(java.util.zip.ZipEntry("metadata.json"))
                    zos.write(metaObj.toString(2).toByteArray(Charsets.UTF_8))
                    zos.flush()
                    zos.closeEntry()

                    // ملف قاعدة البيانات الرئيسي .db
                    zos.putNextEntry(java.util.zip.ZipEntry(dbName))
                    FileInputStream(dbPath).use { input ->
                        input.copyTo(zos)
                    }
                    zos.flush()
                    zos.closeEntry()

                    // ملف الكاش .db-wal إن وجد وكان غير فارغ
                    if (walFile.exists() && walFile.length() > 0L) {
                        zos.putNextEntry(java.util.zip.ZipEntry("$dbName-wal"))
                        FileInputStream(walFile).use { input ->
                            input.copyTo(zos)
                        }
                        zos.flush()
                        zos.closeEntry()
                    }

                    // ملف الذاكرة المشتركة .db-shm إن وجد وكان غير فارغ
                    if (shmFile.exists() && shmFile.length() > 0L) {
                        zos.putNextEntry(java.util.zip.ZipEntry("$dbName-shm"))
                        FileInputStream(shmFile).use { input ->
                            input.copyTo(zos)
                        }
                        zos.flush()
                        zos.closeEntry()
                    }
                }
            }

            // 5. إعادة بناء الاتصال فوراً حتى لا تفشل أي عمليات لاحقة في الواجهة للمستخدم
            try {
                AidDatabase.reestablishConnection(context)
            } catch (e: Exception) {
                Log.w(TAG, "reestablishConnection warning: ${e.message}")
            }

            BackupResult(
                success = true,
                message = "تم تصدير وحفظ قاعدة البيانات المشفرة بنجاح إلى ملف ZIP في مجلد (Downloads/AidManagementBackups)",
                filePath = savedPath,
                fileSizeKb = sizeKb,
                metadata = BackupMetadata(
                    exportDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now)),
                    timestamp = now,
                    totalFamilies = totalFamilies,
                    totalChildren = 0,
                    totalAidRecords = totalAidRecords,
                    totalProjects = totalProjects
                )
            )
        } catch (e: Exception) {
            try { AidDatabase.reestablishConnection(context) } catch (_: Exception) {}
            BackupResult(
                success = false,
                message = "فشل تصدير القاعدة المشفرة: ${e.localizedMessage ?: e.message}"
            )
        }
    }

    /**
     * تصدير قاعدة البيانات كأرشيف ZIP مباشرة إلى Uri محدد عبر Storage Access Framework (SAF)
     */
    suspend fun exportEncryptedDatabaseToSafUri(targetUri: Uri): BackupResult = withContext(Dispatchers.IO) {
        try {
            val now = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(now))

            val totalFamilies = try { database.familyDao().getTotalFamiliesCount() } catch (_: Exception) { 0 }
            val totalAidRecords = try { database.aidRecordDao().getTotalAidRecordsCount() } catch (_: Exception) { 0 }
            val totalProjects = try { database.projectDao().getTotalProjectsCount() } catch (_: Exception) { 0 }

            val dbName = AidDatabase.DATABASE_NAME
            val dbPath = context.getDatabasePath(dbName)

            // 1. إجبار قاعدة البيانات على دمج كافة التعديلات المعلقة من الذاكرة (WAL) إلى الملف الرئيسي
            try {
                database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").close()
            } catch (e: Exception) {
                Log.w(TAG, "wal_checkpoint TRUNCATE: ${e.message}")
            }

            // 2. إغلاق قاعدة بيانات Room بنعومة
            try {
                database.close()
            } catch (e: Exception) {
                Log.w(TAG, "database.close(): ${e.message}")
            }
            AidDatabase.resetInstance()

            delay(500)

            if (!dbPath.exists()) {
                try { AidDatabase.reestablishConnection(context) } catch (_: Exception) {}
                return@withContext BackupResult(
                    success = false,
                    message = "ملف قاعدة البيانات غير موجود على المسار (${dbPath.name})"
                )
            }

            val parentDir = dbPath.parentFile ?: File(context.filesDir.parentFile, "databases")
            val walFile = File(parentDir, "$dbName-wal")
            val shmFile = File(parentDir, "$dbName-shm")

            val metaObj = JSONObject().apply {
                put("systemName", "نظام إدارة المساعدات الإنسانية - قاعدة مشفرة")
                put("exportDate", dateStr)
                put("timestamp", now)
                put("totalFamilies", totalFamilies)
                put("totalAidRecords", totalAidRecords)
                put("totalProjects", totalProjects)
            }

            val outputStream = context.contentResolver.openOutputStream(targetUri)
                ?: return@withContext BackupResult(false, "تعذر فتح مسار التخزين المختار عبر منتقي الملفات (SAF)")

            outputStream.use { os ->
                java.util.zip.ZipOutputStream(os).use { zos ->
                    // ملف البيانات الوصفية
                    zos.putNextEntry(java.util.zip.ZipEntry("metadata.json"))
                    zos.write(metaObj.toString(2).toByteArray(Charsets.UTF_8))
                    zos.flush()
                    zos.closeEntry()

                    // ملف قاعدة البيانات الرئيسي .db
                    zos.putNextEntry(java.util.zip.ZipEntry(dbName))
                    FileInputStream(dbPath).use { input ->
                        input.copyTo(zos)
                    }
                    zos.flush()
                    zos.closeEntry()

                    // ملف الكاش .db-wal إن وجد وكان غير فارغ
                    if (walFile.exists() && walFile.length() > 0L) {
                        zos.putNextEntry(java.util.zip.ZipEntry("$dbName-wal"))
                        FileInputStream(walFile).use { input ->
                            input.copyTo(zos)
                        }
                        zos.flush()
                        zos.closeEntry()
                    }

                    // ملف الذاكرة المشتركة .db-shm إن وجد وكان غير فارغ
                    if (shmFile.exists() && shmFile.length() > 0L) {
                        zos.putNextEntry(java.util.zip.ZipEntry("$dbName-shm"))
                        FileInputStream(shmFile).use { input ->
                            input.copyTo(zos)
                        }
                        zos.flush()
                        zos.closeEntry()
                    }
                }
            }

            try {
                AidDatabase.reestablishConnection(context)
            } catch (e: Exception) {
                Log.w(TAG, "reestablishConnection warning: ${e.message}")
            }

            BackupResult(
                success = true,
                message = "تم تصدير وحفظ النسخة الاحتياطية بنجاح عبر منتقي ملفات النظام (SAF)",
                filePath = targetUri.toString(),
                metadata = BackupMetadata(
                    exportDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now)),
                    timestamp = now,
                    totalFamilies = totalFamilies,
                    totalChildren = 0,
                    totalAidRecords = totalAidRecords,
                    totalProjects = totalProjects
                )
            )
        } catch (e: Exception) {
            try { AidDatabase.reestablishConnection(context) } catch (_: Exception) {}
            BackupResult(
                success = false,
                message = "فشل تصدير النسخة عبر SAF: ${e.localizedMessage ?: e.message}"
            )
        }
    }

    /**
     * نظام الاستعادة المحصن (Bulletproof Restore System):
     * 1. فك ضغط واستخراج ملفات النسخة إلى مجلد عزل مؤقت والتحقق من وجود ملف .db سليم
     * 2. الإغلاق الآمن للاتصالات (Kill Connections & Flush WAL):
     *    - استدعاء PRAGMA wal_checkpoint(TRUNCATE) لدمج التعديلات المعلقة
     *    - استدعاء database.close() وإعدام مرجع السنجلتون AidDatabase.resetInstance()
     * 3. النسخ الاحتياطي التراجعي الآمن (Fail-Safe Rollback with Temp Backup):
     *    - أخذ لقطة فورية من ملفات القاعدة الحالية (.db, -wal, -shm) إلى مجلد db_rollback_temp
     * 4. استبدال الملفات الثلاثة معاً مع التطهير الصارم لسجلات WAL/SHM القديمة:
     *    - إذا كانت النسخة تحتوي على -wal و -shm يتم نسخها
     *    - إذا كانت لا تحتوي عليها يتم مسح أي -wal و -shm قديمة فوراً لمنع التلف
     * 5. التحقق الصارم من صحة القاعدة الجديدة عبر ترحيلات Room (بدون هدم Destructive Fallback):
     *    - استدعاء AidDatabase.reestablishConnection(context) وفحص الجداول
     *    - عند حدوث أي خطأ، يتم التراجع الفوري (Rollback) من مجلد db_rollback_temp وحماية البيانات القائمة
     */
    suspend fun restoreDatabaseSafely(inputStream: InputStream): BackupResult = withContext(Dispatchers.IO) {
        val stageDir = File(context.cacheDir, "restore_safe_${System.currentTimeMillis()}")
        val tempPayload = File(context.cacheDir, "temp_restore_payload_${System.currentTimeMillis()}.bin")
        val rollbackDir = File(context.cacheDir, "db_rollback_temp_${System.currentTimeMillis()}")
        val dbName = AidDatabase.DATABASE_NAME
        val targetDbFile = context.getDatabasePath(dbName)
        val targetParentDir = targetDbFile.parentFile ?: File(context.filesDir.parentFile, "databases")

        try {
            if (stageDir.exists()) stageDir.deleteRecursively()
            stageDir.mkdirs()

            // 1. كتابة التدفق في ملف مؤقت
            FileOutputStream(tempPayload).use { fos ->
                inputStream.copyTo(fos)
                fos.flush()
                fos.fd.sync()
            }

            if (!tempPayload.exists() || tempPayload.length() == 0L) {
                return@withContext BackupResult(
                    success = false,
                    message = "ملف النسخة الاحتياطية فارغ أو تعذرت قراءته."
                )
            }

            // 2. فك ضغط واستخراج الملفات الثلاثة (.db, .db-wal, .db-shm) إلى مجلد العزل
            var extractedAny = false
            try {
                FileInputStream(tempPayload).use { fis ->
                    java.util.zip.ZipInputStream(fis).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            val entryPath = entry.name
                            val entryName = entryPath.substringAfterLast('/')
                            val isMacOrHidden = entryPath.contains("__MACOSX") || entryName.startsWith(".")

                            if (!entry.isDirectory && !isMacOrHidden) {
                                val lower = entryName.lowercase()
                                val destFile = when {
                                    lower.endsWith("-wal") || lower.endsWith(".db-wal") -> {
                                        File(stageDir, "$dbName-wal")
                                    }
                                    lower.endsWith("-shm") || lower.endsWith(".db-shm") -> {
                                        File(stageDir, "$dbName-shm")
                                    }
                                    lower.endsWith(".db") || lower.endsWith(".sqlite") || lower == dbName.lowercase() || lower == "aid_database" || lower == "aid_database.db" -> {
                                        File(stageDir, dbName)
                                    }
                                    else -> null
                                }

                                if (destFile != null) {
                                    FileOutputStream(destFile).use { fos ->
                                        zis.copyTo(fos)
                                        fos.flush()
                                        fos.fd.sync()
                                    }
                                    if (destFile.name == dbName) {
                                        extractedAny = true
                                    }
                                }
                            }
                            zis.closeEntry()
                            entry = zis.nextEntry
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "ZipInputStream extraction attempt: ${e.message}")
            }

            // فحص إضافي: إذا لم يتم تحديد الملف الأساسي، نبحث عن أي ملف في مجلد العزل يحتوي ترويسة SQLite
            if (!extractedAny) {
                val candidateDb = stageDir.listFiles()?.firstOrNull { file ->
                    !file.name.endsWith("-wal") && !file.name.endsWith("-shm") && !file.name.endsWith("-journal") && !file.name.endsWith(".json") &&
                    try {
                        FileInputStream(file).use { fis ->
                            val header = ByteArray(16)
                            fis.read(header) >= 16 && String(header, 0, 15, Charsets.US_ASCII) == "SQLite format 3"
                        }
                    } catch (_: Exception) { false }
                }
                if (candidateDb != null) {
                    val destDb = File(stageDir, dbName)
                    if (candidateDb.absolutePath != destDb.absolutePath) {
                        copyFileWithSync(candidateDb, destDb)
                    }
                    extractedAny = true
                }
            }

            // إذا لم يكن ملف ZIP، نتحقق إن كان ملف SQLite خام حصراً
            if (!extractedAny) {
                val isRawSqlite = try {
                    FileInputStream(tempPayload).use { fis ->
                        val header = ByteArray(16)
                        val bytesRead = fis.read(header)
                        bytesRead >= 16 && String(header, 0, 15, Charsets.US_ASCII) == "SQLite format 3"
                    }
                } catch (_: Exception) { false }

                if (isRawSqlite) {
                    val destDb = File(stageDir, dbName)
                    FileInputStream(tempPayload).use { fis ->
                        FileOutputStream(destDb).use { fos ->
                            fis.copyTo(fos)
                            fos.flush()
                            fos.fd.sync()
                        }
                    }
                    extractedAny = true
                }
            }

            val stagedMainDb = File(stageDir, dbName)
            if (!extractedAny || !stagedMainDb.exists() || stagedMainDb.length() == 0L) {
                stageDir.deleteRecursively()
                return@withContext BackupResult(
                    success = false,
                    message = "فشل استخراج ملف قاعدة البيانات: الملف المحدد تالف أو لا يحتوي على قاعدة بيانات SQLite صالحة."
                )
            }

            // 3. الإغلاق الآمن وتفريغ WAL (Kill Connections & Flush WAL)
            try {
                AidDatabase.flushWal(database)
            } catch (e: Exception) {
                Log.w(TAG, "flushWal before restore: ${e.message}")
            }
            try {
                if (database.isOpen) {
                    database.close()
                }
            } catch (e: Exception) {
                Log.w(TAG, "database.close(): ${e.message}")
            }
            AidDatabase.resetInstance()
            delay(400)

            // 4. النسخ الاحتياطي التراجعي الفوري (Fail-Safe Rollback Snapshot)
            // إنشاء نسخة احتياطية فورية من قاعدة البيانات الحية الحالية قبل لمسها
            rollbackDir.mkdirs()
            var hasRollback = false
            try {
                if (targetDbFile.exists()) {
                    copyFileWithSync(targetDbFile, File(rollbackDir, dbName))
                    val curWal = File(targetParentDir, "$dbName-wal")
                    if (curWal.exists()) copyFileWithSync(curWal, File(rollbackDir, "$dbName-wal"))
                    val curShm = File(targetParentDir, "$dbName-shm")
                    if (curShm.exists()) copyFileWithSync(curShm, File(rollbackDir, "$dbName-shm"))
                    hasRollback = true
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed creating rollback snapshot: ${e.message}")
            }

            // 5. استبدال الملفات الثلاثة معاً وتطهير ملفات WAL و SHM القديمة
            targetParentDir.mkdirs()
            val targetWalFile = File(targetParentDir, "$dbName-wal")
            val targetShmFile = File(targetParentDir, "$dbName-shm")
            val targetJournalFile = File(targetParentDir, "$dbName-journal")

            try { targetJournalFile.delete() } catch (_: Exception) {}

            // كتابة الملف الرئيسي لمسار Room المعتمد
            copyFileWithSync(stagedMainDb, targetDbFile)

            // كتابة نسخة مطابقة في مسار aid_database لضمان التوافق مع أي استدعاء صريح
            val aidDbTarget = context.getDatabasePath("aid_database")
            val aidDbTargetExt = context.getDatabasePath("aid_database.db")
            try { copyFileWithSync(stagedMainDb, aidDbTarget) } catch (_: Exception) {}
            try { copyFileWithSync(stagedMainDb, aidDbTargetExt) } catch (_: Exception) {}

            // نسخ ملف WAL المرفق أو حذفه تماماً لمنع ربط سجل قديم بقاعدة بيانات جديدة
            val stagedWal = File(stageDir, "$dbName-wal")
            if (stagedWal.exists() && stagedWal.length() > 0L) {
                copyFileWithSync(stagedWal, targetWalFile)
                try { copyFileWithSync(stagedWal, File(aidDbTarget.path + "-wal")) } catch (_: Exception) {}
                try { copyFileWithSync(stagedWal, File(aidDbTargetExt.path + "-wal")) } catch (_: Exception) {}
            } else {
                try { targetWalFile.delete() } catch (_: Exception) {}
                try { File(targetDbFile.path + "-wal").delete() } catch (_: Exception) {}
                try { File(aidDbTarget.path + "-wal").delete() } catch (_: Exception) {}
                try { File(aidDbTargetExt.path + "-wal").delete() } catch (_: Exception) {}
            }

            // نسخ ملف SHM المرفق أو حذفه تماماً
            val stagedShm = File(stageDir, "$dbName-shm")
            if (stagedShm.exists() && stagedShm.length() > 0L) {
                copyFileWithSync(stagedShm, targetShmFile)
                try { copyFileWithSync(stagedShm, File(aidDbTarget.path + "-shm")) } catch (_: Exception) {}
                try { copyFileWithSync(stagedShm, File(aidDbTargetExt.path + "-shm")) } catch (_: Exception) {}
            } else {
                try { targetShmFile.delete() } catch (_: Exception) {}
                try { File(targetDbFile.path + "-shm").delete() } catch (_: Exception) {}
                try { File(aidDbTarget.path + "-shm").delete() } catch (_: Exception) {}
                try { File(aidDbTargetExt.path + "-shm").delete() } catch (_: Exception) {}
            }

            // 6. التحقق الصارم من سلامة القاعدة الجديدة وتنفيذ ترحيلات Room
            try {
                val newDb = AidDatabase.reestablishConnection(context)
                val cursor = newDb.openHelper.writableDatabase.query("SELECT COUNT(*) FROM sqlite_master")
                cursor.moveToFirst()
                cursor.close()
                Log.i(TAG, "Restored database verified successfully via Room migrations!")
            } catch (verificationError: Throwable) {
                Log.e(TAG, "Integrity check failed: ${verificationError.message}. Executing Rollback!", verificationError)
                
                // خطة الإنقاذ والتراجع الفوري (Safe Rollback)
                if (hasRollback) {
                    try {
                        AidDatabase.resetInstance()
                        val rollbackDb = File(rollbackDir, dbName)
                        if (rollbackDb.exists()) {
                            copyFileWithSync(rollbackDb, targetDbFile)
                            val rbWal = File(rollbackDir, "$dbName-wal")
                            if (rbWal.exists()) copyFileWithSync(rbWal, targetWalFile) else targetWalFile.delete()
                            val rbShm = File(rollbackDir, "$dbName-shm")
                            if (rbShm.exists()) copyFileWithSync(rbShm, targetShmFile) else targetShmFile.delete()
                            AidDatabase.reestablishConnection(context)
                        }
                    } catch (rollbackErr: Exception) {
                        Log.e(TAG, "Critical rollback error: ${rollbackErr.message}")
                    }
                } else {
                    try { AidDatabase.reestablishConnection(context) } catch (_: Exception) {}
                }

                return@withContext BackupResult(
                    success = false,
                    message = "تعذرت استعادة النسخة الاحتياطية لعدم توافق المخطط أو تلف البيانات: ${verificationError.localizedMessage ?: verificationError.message}. تم التراجع واستعادة النسخة الأصلية بنجاح دون أي فقدان للبيانات."
                )
            }

            BackupResult(
                success = true,
                message = "تمت استعادة قاعدة البيانات وملحقاتها (WAL/SHM) بنجاح وترحيل الجداول. يرجى إعادة تشغيل التطبيق لتطبيق كافة التغييرات.",
                filePath = targetDbFile.absolutePath,
                fileSizeKb = targetDbFile.length() / 1024
            )
        } catch (e: Exception) {
            Log.e(TAG, "General exception during restoreDatabaseSafely: ${e.message}", e)
            try { AidDatabase.reestablishConnection(context) } catch (_: Exception) {}
            BackupResult(
                success = false,
                message = "فشلت الاستعادة: ${e.localizedMessage ?: e.message}"
            )
        } finally {
            try { tempPayload.delete() } catch (_: Exception) {}
            try { stageDir.deleteRecursively() } catch (_: Exception) {}
            try { rollbackDir.deleteRecursively() } catch (_: Exception) {}
        }
    }

    /**
     * 🧠 MISSION 2: THE RESTORE STAGING PROCESS (The Quarantine Room)
     * - لا يتم لمس قاعدة البيانات الحية مطلقاً!
     * - تنظيف مجلد الحجر المؤقت cacheDir/restore_stage
     * - فك ضغط النسخة المختارة إلى restore_stage (بما فيها .db و .db-wal و .db-shm)
     * - تعيين علم PENDING_DB_RESTORE = true في SharedPreferences
     * - إرجاع نتيجة النجاح تمهيداً لإشعار المستخدم وإعادة تشغيل التطبيق
     */
    suspend fun stageRestoreFromInputStream(inputStream: InputStream): BackupResult = withContext(Dispatchers.IO) {
        val stageDir = File(context.cacheDir, STAGE_DIR_NAME)
        val tempPayload = File(context.cacheDir, "temp_quarantine_${System.currentTimeMillis()}.bin")
        val dbName = AidDatabase.DATABASE_NAME

        try {
            // 1. تنظيف مجلد الحجر المؤقت كلياً
            if (stageDir.exists()) {
                stageDir.deleteRecursively()
            }
            stageDir.mkdirs()

            // 2. كتابة التدفق بأمان في ملف مؤقت
            FileOutputStream(tempPayload).use { fos ->
                inputStream.copyTo(fos)
                fos.flush()
                fos.fd.sync()
            }

            if (!tempPayload.exists() || tempPayload.length() == 0L) {
                return@withContext BackupResult(
                    success = false,
                    message = "ملف النسخة الاحتياطية فارغ أو غير صالح"
                )
            }

            // 3. فك الضغط في مجلد الحجر المؤقت (restore_stage) مع استخراج .db و .db-wal و .db-shm
            var extractedAny = false
            try {
                FileInputStream(tempPayload).use { fis ->
                    java.util.zip.ZipInputStream(fis).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            val entryPath = entry.name
                            val entryName = entryPath.substringAfterLast('/')
                            val isMacOrHidden = entryPath.contains("__MACOSX") || entryName.startsWith(".")

                            if (!entry.isDirectory && !isMacOrHidden) {
                                val lower = entryName.lowercase()
                                val destFile = when {
                                    lower.endsWith("-wal") || lower.endsWith(".db-wal") -> {
                                        File(stageDir, "$dbName-wal")
                                    }
                                    lower.endsWith("-shm") || lower.endsWith(".db-shm") -> {
                                        File(stageDir, "$dbName-shm")
                                    }
                                    lower.endsWith(".db") || lower.endsWith(".sqlite") || lower == dbName.lowercase() || lower == "aid_database" || lower == "aid_database.db" -> {
                                        File(stageDir, dbName)
                                    }
                                    else -> null
                                }

                                if (destFile != null) {
                                    FileOutputStream(destFile).use { fos ->
                                        zis.copyTo(fos)
                                        fos.flush()
                                        fos.fd.sync()
                                    }
                                    if (destFile.name == dbName) {
                                        extractedAny = true
                                    }
                                }
                            }
                            zis.closeEntry()
                            entry = zis.nextEntry
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "ZipInputStream staging: ${e.message}")
            }

            // فحص إضافي بالترويسة
            if (!extractedAny) {
                val candidateDb = stageDir.listFiles()?.firstOrNull { file ->
                    !file.name.endsWith("-wal") && !file.name.endsWith("-shm") && !file.name.endsWith("-journal") && !file.name.endsWith(".json") &&
                    try {
                        FileInputStream(file).use { fis ->
                            val header = ByteArray(16)
                            fis.read(header) >= 16 && String(header, 0, 15, Charsets.US_ASCII) == "SQLite format 3"
                        }
                    } catch (_: Exception) { false }
                }
                if (candidateDb != null) {
                    val destDb = File(stageDir, dbName)
                    if (candidateDb.absolutePath != destDb.absolutePath) {
                        copyFileWithSync(candidateDb, destDb)
                    }
                    extractedAny = true
                }
            }

            // إذا لم يكن ملف ZIP، نتحقق إن كان ملف SQLite خام
            if (!extractedAny) {
                val isRawSqlite = try {
                    FileInputStream(tempPayload).use { fis ->
                        val header = ByteArray(16)
                        val bytesRead = fis.read(header)
                        bytesRead >= 16 && String(header, 0, 15, Charsets.US_ASCII) == "SQLite format 3"
                    }
                } catch (_: Exception) { false }

                if (isRawSqlite) {
                    val destDb = File(stageDir, dbName)
                    FileInputStream(tempPayload).use { fis ->
                        FileOutputStream(destDb).use { fos ->
                            fis.copyTo(fos)
                            fos.flush()
                            fos.fd.sync()
                        }
                    }
                    extractedAny = true
                }
            }

            if (!extractedAny) {
                stageDir.deleteRecursively()
                return@withContext BackupResult(
                    success = false,
                    message = "فشل استخراج ملفات النسخة الاحتياطية: الأرشيف غير صالح أو لا يحتوي على ملفات."
                )
            }

            // 4. التحقق الصارم من وجود ملف .db صالح داخل مجلد الحجر
            val stagedFiles = stageDir.listFiles() ?: emptyArray()
            val dbFileCandidate = stagedFiles.firstOrNull { file ->
                file.name == dbName ||
                file.extension.lowercase() in listOf("db", "sqlite")
            }

            if (dbFileCandidate == null || dbFileCandidate.length() == 0L) {
                stageDir.deleteRecursively()
                return@withContext BackupResult(
                    success = false,
                    message = "فشل تجهيز النسخة: لم يتم العثور على ملف قاعدة بيانات (.db) صالح داخل الأرشيف."
                )
            }

            // توحيد اسم ملف قاعدة البيانات المجهز ليطابق AidDatabase.DATABASE_NAME تماماً
            if (dbFileCandidate.name != dbName) {
                val targetFile = File(stageDir, dbName)
                val oldBase = dbFileCandidate.nameWithoutExtension
                dbFileCandidate.renameTo(targetFile)

                stagedFiles.forEach { extra ->
                    if (extra != dbFileCandidate && extra.name.startsWith(oldBase)) {
                        val suffix = extra.name.removePrefix(oldBase)
                        extra.renameTo(File(stageDir, "$dbName$suffix"))
                    }
                }
            }

            val finalTargetDb = File(stageDir, dbName)
            if (!finalTargetDb.exists() || finalTargetDb.length() == 0L) {
                stageDir.deleteRecursively()
                return@withContext BackupResult(
                    success = false,
                    message = "ملف قاعدة البيانات المجهز غير صالح (حجمه صفر بايت)."
                )
            }

            // 5. تعيين علم PENDING_DB_RESTORE = true في SharedPreferences
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putBoolean(KEY_PENDING_RESTORE, true).commit()

            Log.i(TAG, "Staging completed successfully! Flag PENDING_DB_RESTORE set to true.")

            BackupResult(
                success = true,
                message = "تم تجهيز النسخة، سيتم إعادة تشغيل التطبيق لتطبيقها",
                filePath = finalTargetDb.absolutePath,
                fileSizeKb = finalTargetDb.length() / 1024
            )
        } catch (e: Exception) {
            stageDir.deleteRecursively()
            BackupResult(
                success = false,
                message = "فشل تجهيز استعادة قاعدة البيانات: ${e.localizedMessage ?: e.message}"
            )
        } finally {
            try { tempPayload.delete() } catch (_: Exception) {}
        }
    }

    /**
     * تجهيز الاستعادة من مسار ملف محلي
     */
    suspend fun stageRestoreFromFile(file: File): BackupResult = withContext(Dispatchers.IO) {
        if (!file.exists() || file.length() == 0L) {
            return@withContext BackupResult(false, "ملف النسخة الاحتياطية غير موجود أو فارغ")
        }
        FileInputStream(file).use { fis ->
            stageRestoreFromInputStream(fis)
        }
    }

    /**
     * تجهيز الاستعادة من Uri (ملف منتقى من النظام)
     */
    suspend fun stageRestoreFromUri(uri: Uri): BackupResult = withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return@withContext BackupResult(false, "تعذر فتح ملف النسخة الاحتياطية المختار")
            inputStream.use { stream ->
                stageRestoreFromInputStream(stream)
            }
        } catch (e: Exception) {
            BackupResult(false, "فشلت قراءة ملف النسخة الاحتياطية: ${e.localizedMessage ?: e.message}")
        }
    }

    // دوال الاستعادة المباشرة الآمنة المتكاملة
    suspend fun restoreEncryptedDatabaseZip(zipFile: File): BackupResult = restoreDatabaseFile(zipFile)

    suspend fun restoreDatabaseFile(sourceFile: File): BackupResult = withContext(Dispatchers.IO) {
        if (!sourceFile.exists() || sourceFile.length() == 0L) {
            return@withContext BackupResult(false, "ملف النسخة الاحتياطية غير موجود أو فارغ")
        }
        try {
            FileInputStream(sourceFile).use { fis ->
                restoreDatabaseSafely(fis)
            }
        } catch (e: Exception) {
            BackupResult(false, "فشلت قراءة ملف النسخة: ${e.localizedMessage ?: e.message}")
        }
    }

    suspend fun restoreFromUri(uri: Uri): BackupResult = withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return@withContext BackupResult(false, "تعذر فتح ملف النسخة الاحتياطية المختار")
            inputStream.use { stream ->
                restoreDatabaseSafely(stream)
            }
        } catch (e: Exception) {
            BackupResult(false, "فشلت قراءة ملف النسخة: ${e.localizedMessage ?: e.message}")
        }
    }

    suspend fun restoreDatabaseFromInputStream(inputStream: InputStream): BackupResult = restoreDatabaseSafely(inputStream)

    /**
     * إظهار رسالة التوست وبدء إعادة التشغيل البارد النظيف
     */
    fun triggerColdRestart() {
        try {
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                Toast.makeText(
                    context,
                    "تم تجهيز النسخة، سيتم إعادة تشغيل التطبيق لتطبيقها",
                    Toast.LENGTH_LONG
                ).show()
            }
        } catch (_: Exception) {}
        restartApplication(context)
    }

    /**
     * قائمة النسخ الاحتياطية الموجودة محلياً وفي مجلد التنزيلات العام AidManagementBackups
     */
    fun listExistingBackups(): List<File> {
        val resultList = mutableListOf<File>()

        // 1. مجلد النسخ العام خارج التطبيق AidManagementBackups لضمان استرجاع النسخ بعد الحذف
        val publicDownloads = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        val customFolder = File(publicDownloads, "AidManagementBackups")
        if (customFolder.exists()) {
            customFolder.listFiles()?.filter { it.extension in listOf("json", "sql", "zip", "db", "sqlite") }?.let {
                resultList.addAll(it)
            }
        }

        // 2. مجلد التطبيق الداخلي
        val backupDir = File(context.getExternalFilesDir(null), "backups")
        if (backupDir.exists()) {
            backupDir.listFiles()?.filter { it.extension in listOf("json", "sql", "zip", "db", "sqlite") }?.forEach { internalFile ->
                if (resultList.none { it.name == internalFile.name }) {
                    resultList.add(internalFile)
                }
            }
        }

        return resultList.sortedByDescending { it.lastModified() }
    }

    companion object {
        const val PREFS_NAME = "aid_restore_prefs"
        const val KEY_PENDING_RESTORE = "PENDING_DB_RESTORE"
        const val STAGE_DIR_NAME = "restore_stage"
        private const val TAG = "DatabaseBackupManager"

        /**
         * 🚀 MISSION 3: THE BOOT INTERCEPTOR (The Clean Room)
         * يُنفّذ حتماً وبشكل تزامني في أول لحظة إقلاع للتطبيق في AidApplication و MainActivity
         * قبل تهيئة Room أو أي استدعاء لقاعدة البيانات أو الحقن البرمجي.
         *
         * 1. فحص العلم PENDING_DB_RESTORE == true
         * 2. استدعاء context.deleteDatabase(DB_NAME) لحذف كافة ملفات DB/WAL/SHM القديمة
         * 3. نسخ ملفات .db و .db-wal و .db-shm المجهزة بـ Pure Blocking File I/O مع fd.sync()
         * 4. مسح مجلد الحجر المؤقت restore_stage
         * 5. تصفير العلم PENDING_DB_RESTORE = false
         */
        @Synchronized
        fun performPendingRestoreIfRequired(context: Context): Boolean {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val isPending = prefs.getBoolean(KEY_PENDING_RESTORE, false)
            if (!isPending) return false

            Log.i(TAG, "⚡ PENDING_DB_RESTORE is TRUE! Executing Staged Pre-Boot Restore in Clean Room...")

            val stageDir = File(context.cacheDir, STAGE_DIR_NAME)
            val dbName = AidDatabase.DATABASE_NAME
            val targetDbFile = context.getDatabasePath(dbName)
            val targetParentDir = targetDbFile.parentFile ?: File(context.filesDir.parentFile, "databases")

            try {
                // 1. حذف قاعدة البيانات القديمة بكافة ملحقاتها (Clean Purge) لمنع أي قفل ذاكرة أو تلف WAL
                try {
                    context.deleteDatabase(dbName)
                } catch (e: Exception) {
                    Log.w(TAG, "context.deleteDatabase warning: ${e.message}")
                }
                try { targetDbFile.delete() } catch (_: Exception) {}
                try { File(targetDbFile.path + "-wal").delete() } catch (_: Exception) {}
                try { File(targetDbFile.path + "-shm").delete() } catch (_: Exception) {}
                try { File(targetDbFile.path + "-journal").delete() } catch (_: Exception) {}
                try { File(targetParentDir, "$dbName-wal").delete() } catch (_: Exception) {}
                try { File(targetParentDir, "$dbName-shm").delete() } catch (_: Exception) {}
                try { File(targetParentDir, "$dbName-journal").delete() } catch (_: Exception) {}
                try { File(targetParentDir, "${targetDbFile.nameWithoutExtension}.db-wal").delete() } catch (_: Exception) {}
                try { File(targetParentDir, "${targetDbFile.nameWithoutExtension}.db-shm").delete() } catch (_: Exception) {}

                if (!targetParentDir.exists()) {
                    targetParentDir.mkdirs()
                }

                // 2. فحص ملفات مجلد الحجر المؤقت
                val stagedFiles = stageDir.listFiles() ?: emptyArray()
                if (stagedFiles.isEmpty()) {
                    Log.e(TAG, "restore_stage directory is empty! Resetting flag.")
                    prefs.edit().putBoolean(KEY_PENDING_RESTORE, false).commit()
                    return false
                }

                // العثور على الملف الرئيسي .db
                val mainStagedDb = File(stageDir, dbName).takeIf { it.exists() }
                    ?: File(stageDir, "aid_database").takeIf { it.exists() }
                    ?: File(stageDir, "aid_database.db").takeIf { it.exists() }
                    ?: stagedFiles.firstOrNull { it.extension.lowercase() in listOf("db", "sqlite") }

                if (mainStagedDb == null || !mainStagedDb.exists() || mainStagedDb.length() == 0L) {
                    Log.e(TAG, "No valid .db file found in restore_stage. Resetting flag.")
                    prefs.edit().putBoolean(KEY_PENDING_RESTORE, false).commit()
                    stageDir.deleteRecursively()
                    return false
                }

                // 3. نسخ الملف الرئيسي .db وملحقات WAL/SHM بحظر كامل وإجبار عتادي على الكتابة: fd.sync()
                copyFileWithSync(mainStagedDb, targetDbFile)
                val targetAidDb = context.getDatabasePath("aid_database")
                val targetAidDbExt = context.getDatabasePath("aid_database.db")
                try { copyFileWithSync(mainStagedDb, targetAidDb) } catch (_: Exception) {}
                try { copyFileWithSync(mainStagedDb, targetAidDbExt) } catch (_: Exception) {}

                val stagedWal = File(stageDir, "$dbName-wal").takeIf { it.exists() && it.length() > 0L }
                    ?: stagedFiles.firstOrNull { it.name.endsWith("-wal") }
                if (stagedWal != null && stagedWal.exists()) {
                    copyFileWithSync(stagedWal, File(targetParentDir, "$dbName-wal"))
                    try { copyFileWithSync(stagedWal, File(targetAidDb.path + "-wal")) } catch (_: Exception) {}
                    try { copyFileWithSync(stagedWal, File(targetAidDbExt.path + "-wal")) } catch (_: Exception) {}
                } else {
                    try { File(targetParentDir, "$dbName-wal").delete() } catch (_: Exception) {}
                    try { File(targetDbFile.path + "-wal").delete() } catch (_: Exception) {}
                    try { File(targetAidDb.path + "-wal").delete() } catch (_: Exception) {}
                    try { File(targetAidDbExt.path + "-wal").delete() } catch (_: Exception) {}
                }

                val stagedShm = File(stageDir, "$dbName-shm").takeIf { it.exists() && it.length() > 0L }
                    ?: stagedFiles.firstOrNull { it.name.endsWith("-shm") }
                if (stagedShm != null && stagedShm.exists()) {
                    copyFileWithSync(stagedShm, File(targetParentDir, "$dbName-shm"))
                    try { copyFileWithSync(stagedShm, File(targetAidDb.path + "-shm")) } catch (_: Exception) {}
                    try { copyFileWithSync(stagedShm, File(targetAidDbExt.path + "-shm")) } catch (_: Exception) {}
                } else {
                    try { File(targetParentDir, "$dbName-shm").delete() } catch (_: Exception) {}
                    try { File(targetDbFile.path + "-shm").delete() } catch (_: Exception) {}
                    try { File(targetAidDb.path + "-shm").delete() } catch (_: Exception) {}
                    try { File(targetAidDbExt.path + "-shm").delete() } catch (_: Exception) {}
                }

                try { File(targetParentDir, "$dbName-journal").delete() } catch (_: Exception) {}

                // 4. مسح مجلد الحجر المؤقت لمنع أي تلوث للمجلدات
                stageDir.deleteRecursively()

                // 5. تصفير العلم
                prefs.edit().putBoolean(KEY_PENDING_RESTORE, false).commit()

                Log.i(TAG, "✅ Staged Pre-Boot Restore successfully completed! Restored DB size: ${targetDbFile.length()} bytes")
                return true
            } catch (e: Exception) {
                Log.e(TAG, "❌ Critical failure during Staged Pre-Boot Restore: ${e.message}", e)
                try { stageDir.deleteRecursively() } catch (_: Exception) {}
                prefs.edit().putBoolean(KEY_PENDING_RESTORE, false).commit()
                return false
            }
        }

        private fun copyFileWithSync(source: File, destination: File) {
            destination.parentFile?.mkdirs()
            FileInputStream(source).use { input ->
                FileOutputStream(destination).use { output ->
                    input.copyTo(output)
                    output.flush()
                    output.fd.sync()
                }
            }
        }

        /**
         * إعادة التشغيل الإجباري القاطع النظيف (Clean Cold Restart):
         * إطلاق Intent لتشغيل MainActivity مع FLAG_ACTIVITY_NEW_TASK or FLAG_ACTIVITY_CLEAR_TASK
         * وانتظار نصف ثانية (500ms) ثم استدعاء exitProcess(0) لقتل العملية القديمة كلياً
         */
        fun restartApplication(context: Context) {
            try {
                val intent = Intent(context, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                try {
                    val fallbackIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    }
                    if (fallbackIntent != null) {
                        context.startActivity(fallbackIntent)
                    }
                } catch (_: Exception) {}
            } finally {
                try {
                    Thread.sleep(500)
                } catch (_: InterruptedException) {}
                kotlin.system.exitProcess(0)
            }
        }
    }
}

/**
 * اسم توافقي بديل لمدير النسخ الاحتياطي والاستعادة
 */
typealias BackupRestoreManager = DatabaseBackupManager

