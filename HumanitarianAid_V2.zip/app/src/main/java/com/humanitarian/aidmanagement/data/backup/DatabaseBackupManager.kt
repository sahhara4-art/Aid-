package com.humanitarian.aidmanagement.data.backup

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class DatabaseBackupManager(private val context: Context) {

    fun exportDatabaseToLocalBackup(): File? {
        return try {
            val dbFile = context.getDatabasePath("humanitarian_aid_database.db")
            val backupFile = File(context.getExternalFilesDir("backups"), "aid_backup_${System.currentTimeMillis()}.db")
            backupFile.parentFile?.mkdirs()

            FileInputStream(dbFile).use { input ->
                FileOutputStream(backupFile).use { output ->
                    input.copyTo(output)
                }
            }
            backupFile
        } catch (e: Exception) {
            null
        }
    }
}
