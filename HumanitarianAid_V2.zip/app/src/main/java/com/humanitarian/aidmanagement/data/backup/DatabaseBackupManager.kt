package com.humanitarian.aidmanagement.data.backup

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.humanitarian.aidmanagement.MainActivity
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * معلومات النسخة الاحتياطية
 */
data class BackupMetadata(
    val exportDate: String,
    val timestamp: Long,
    val appVersion: String = "1.0.0",
    val totalFamilies: Int,
    val totalChildren: Int,
    val totalAidRecords: Int,
    val totalProjects: Int
)

data class BackupResult(
    val success: Boolean,
    val message: String,
    val filePath: String? = null,
    val fileSizeKb: Long = 0,
    val metadata: BackupMetadata? = null
)

/**
 * مدير النسخ الاحتياطي لقاعدة بيانات Room محلياً (JSON & SQL)
 */
class DatabaseBackupManager(
    private val context: Context,
    private val database: AidDatabase
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())

    /**
     * حفظ النسخة الاحتياطية في المجلد العام الخارجي المخصص AidManagementBackups
     * باستخدام Scoped Storage (MediaStore API على أندرويد 10+ أو التخزين العام للأنظمة الأقدم)
     * لضمان بقاء النسخ الاحتياطية حتى بعد إلغاء تثبيت التطبيق.
     */
    private fun writeToScopedStorage(
        fileName: String,
        mimeType: String,
        writer: (java.io.OutputStream) -> Unit
    ): Pair<String, Long> {
        val folderName = "AidManagementBackups"

        // 1. الكتابة في المجلد العام الخارجي عبر MediaStore Downloads لنظام Android 10 (Q) وما بعده
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val contentValues = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "${android.os.Environment.DIRECTORY_DOWNLOADS}/$folderName")
                put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                ?: throw IllegalStateException("فشل إنشاء ملف النسخة الاحتياطية في MediaStore")

            resolver.openOutputStream(uri)?.use { os ->
                writer(os)
                os.flush()
            } ?: throw IllegalStateException("تعذر فتح تيار الكتابة لملف النسخة الاحتياطية")

            contentValues.clear()
            contentValues.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, contentValues, null, null)

            // حفظ نسخة مطابقة أيضاً في مجلد التطبيق لتسهيل المعاينة والاسترجاع الفوري السريع
            val localDir = File(context.getExternalFilesDir(null), "backups").apply { mkdirs() }
            val localMirror = File(localDir, fileName)
            try {
                resolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(localMirror).use { output ->
                        input.copyTo(output)
                        output.flush()
                    }
                }
            } catch (e: Exception) { }

            val sizeKb = if (localMirror.exists()) localMirror.length() / 1024 else 0L
            return Pair("Downloads/$folderName/$fileName", sizeKb)
        } else {
            // الأنظمة السابقة لأندرويد 10: حفظ مباشر في مجلد Downloads/AidManagementBackups العام
            val publicDownloads = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            val customFolder = File(publicDownloads, folderName).apply { mkdirs() }
            val targetFile = File(customFolder, fileName)

            FileOutputStream(targetFile).use { fos ->
                writer(fos)
                fos.flush()
            }

            // حفظ نسخة احتياطية محلية
            val localDir = File(context.getExternalFilesDir(null), "backups").apply { mkdirs() }
            val localMirror = File(localDir, fileName)
            try { targetFile.copyTo(localMirror, overwrite = true) } catch (e: Exception) { }

            return Pair(targetFile.absolutePath, targetFile.length() / 1024)
        }
    }

    /**
     * تصدير قاعدة البيانات كاملة إلى ملف JSON منظم
     */
    suspend fun exportToJson(): BackupResult = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject()

            // 1. جلب البيانات من كافة الجداول
            val families = database.familyDao().getAllFamilies().first()
            val children = database.childDao().searchChildren("").first()
            val aidTypes = database.aidTypeDao().getAllActiveAidTypes().first()
            val projects = database.projectDao().getAllActiveProjects().first()
            val aidRecords = database.aidRecordDao().getAllAidRecords().first()
            val localities = database.localityDao().getAllLocalities().first()
            val distributions = database.localityDao().getDistributions().first()
            val settings = database.systemSettingDao().getAllSettings().first()
            val users = database.userDao().getAllUsers().first()

            val now = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now))

            // 2. ترويسة النسخة الاحتياطية
            val metaObj = JSONObject().apply {
                put("systemName", "نظام إدارة المساعدات الإنسانية")
                put("packageName", "com.humanitarian.aidmanagement")
                put("exportDate", dateStr)
                put("timestamp", now)
                put("version", "1.0.0")
                put("familiesCount", families.size)
                put("childrenCount", children.size)
                put("aidRecordsCount", aidRecords.size)
                put("projectsCount", projects.size)
            }
            root.put("metadata", metaObj)

            // 3. جدول الأسر
            val familiesArray = JSONArray()
            families.forEach { f ->
                val obj = JSONObject().apply {
                    put("familyID", f.familyID)
                    put("name", f.name)
                    put("nationalID", f.nationalID)
                    put("birthDate", f.birthDate)
                    put("gender", f.gender)
                    put("maritalStatus", f.maritalStatus)
                    put("familyMembersCount", f.familyMembersCount)
                    put("wifeName", f.wifeName ?: "")
                    put("wifeNationalID", f.wifeNationalID ?: "")
                    put("deathStatus", f.deathStatus)
                    put("developmentApproval", f.developmentApproval)
                    put("localityApproval", f.localityApproval)
                    put("worksApproval", f.worksApproval)
                    put("residentStatus", f.residentStatus)
                    put("damageType", f.damageType)
                    put("shelterStatus", f.shelterStatus)
                    put("localityID", f.localityID)
                    put("notes", f.notes ?: "")
                    put("createdDate", f.createdDate)
                }
                familiesArray.put(obj)
            }
            root.put("families", familiesArray)

            // 4. جدول الأطفال
            val childrenArray = JSONArray()
            children.forEach { c ->
                val obj = JSONObject().apply {
                    put("childID", c.childID)
                    put("nationalID", c.nationalID)
                    put("childName", c.childName)
                    put("birthDate", c.birthDate)
                    put("gender", c.gender)
                    put("familyNationalID", c.familyNationalID)
                    put("localityID", c.localityID)
                    put("shelterStatus", c.shelterStatus)
                }
                childrenArray.put(obj)
            }
            root.put("children", childrenArray)

            // 5. أنواع المساعدات
            val aidTypesArray = JSONArray()
            aidTypes.forEach { a ->
                val obj = JSONObject().apply {
                    put("aidTypeID", a.aidTypeID)
                    put("aidTypeName", a.aidTypeName)
                    put("description", a.description)
                    put("defaultExclusionDays", a.defaultExclusionDays)
                }
                aidTypesArray.put(obj)
            }
            root.put("aid_types", aidTypesArray)

            // 6. المشاريع
            val projectsArray = JSONArray()
            projects.forEach { p ->
                val obj = JSONObject().apply {
                    put("projectID", p.projectID)
                    put("projectNumber", p.projectNumber)
                    put("projectName", p.projectName)
                    put("aidTypeID", p.aidTypeID)
                    put("detailedDescription", p.detailedDescription)
                    put("projectDate", p.projectDate)
                    put("fundingInstitution", p.fundingInstitution)
                    put("quantity", p.quantity)
                }
                projectsArray.put(obj)
            }
            root.put("projects", projectsArray)

            // 7. سجلات المساعدات
            val aidRecordsArray = JSONArray()
            aidRecords.forEach { r ->
                val obj = JSONObject().apply {
                    put("aidRecordID", r.aidRecordID)
                    put("familyID", r.familyID)
                    put("aidTypeID", r.aidTypeID)
                    put("projectID", r.projectID)
                    put("aidDate", r.aidDate)
                    put("selectionDate", r.selectionDate)
                    put("recipientStatus", r.recipientStatus)
                    put("warehouse", r.warehouse)
                    put("aidValue", r.aidValue)
                }
                aidRecordsArray.put(obj)
            }
            root.put("aid_records", aidRecordsArray)

            // 8. حفظ الملف في التخزين الخارجي العام عبر Scoped Storage
            val fileName = "HumanitarianAid_Backup_${dateFormat.format(Date(now))}.json"
            val (savedPath, sizeKb) = writeToScopedStorage(fileName, "application/json") { os ->
                os.write(root.toString(2).toByteArray(Charsets.UTF_8))
            }

            BackupResult(
                success = true,
                message = "تم حفظ النسخة الاحتياطية بنجاح في مجلد التنزيلات (Downloads/AidManagementBackups)",
                filePath = savedPath,
                fileSizeKb = sizeKb,
                metadata = BackupMetadata(
                    exportDate = dateStr,
                    timestamp = now,
                    totalFamilies = families.size,
                    totalChildren = children.size,
                    totalAidRecords = aidRecords.size,
                    totalProjects = projects.size
                )
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "حدث خطأ أثناء تصدير النسخة الاحتياطية: ${e.localizedMessage}"
            )
        }
    }

    /**
     * تصدير قاعدة البيانات كأوامر SQL Dump جاهزة للاستيراد
     */
    suspend fun exportToSql(): BackupResult = withContext(Dispatchers.IO) {
        try {
            val sb = StringBuilder()
            val now = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now))

            sb.append("-- ========================================================\n")
            sb.append("-- نظام إدارة المساعدات الإنسانية - نسخة احتياطية SQL Dump\n")
            sb.append("-- تاريخ التصدير: $dateStr\n")
            sb.append("-- ========================================================\n\n")

            sb.append("BEGIN TRANSACTION;\n\n")

            // الأسر
            val families = database.familyDao().getAllFamilies().first()
            sb.append("-- تفريغ بيانات جدول الأسر (${families.size} أسرة)\n")
            families.forEach { f ->
                val name = f.name.replace("'", "''")
                val notes = (f.notes ?: "").replace("'", "''")
                val wife = (f.wifeName ?: "").replace("'", "''")
                sb.append("INSERT OR REPLACE INTO families (familyID, name, nationalID, birthDate, gender, maritalStatus, familyMembersCount, wifeName, wifeNationalID, deathStatus, developmentApproval, localityApproval, worksApproval, residentStatus, damageType, shelterStatus, localityID, notes, createdDate) ")
                sb.append("VALUES (${f.familyID}, '$name', '${f.nationalID}', '${f.birthDate}', '${f.gender}', '${f.maritalStatus}', ${f.familyMembersCount}, '$wife', '${f.wifeNationalID ?: ""}', '${f.deathStatus}', '${f.developmentApproval}', '${f.localityApproval}', '${f.worksApproval}', '${f.residentStatus}', '${f.damageType}', '${f.shelterStatus}', ${f.localityID}, '$notes', ${f.createdDate});\n")
            }
            sb.append("\n")

            // الأطفال
            val children = database.childDao().searchChildren("").first()
            sb.append("-- تفريغ بيانات جدول الأطفال (${children.size} طفل)\n")
            children.forEach { c ->
                val name = c.childName.replace("'", "''")
                sb.append("INSERT OR REPLACE INTO children (childID, nationalID, childName, birthDate, gender, familyNationalID, localityID, shelterStatus) ")
                sb.append("VALUES (${c.childID}, '${c.nationalID}', '$name', '${c.birthDate}', '${c.gender}', '${c.familyNationalID}', ${c.localityID}, '${c.shelterStatus}');\n")
            }
            sb.append("\n")

            // المشاريع وسجلات المساعدات
            val projects = database.projectDao().getAllActiveProjects().first()
            projects.forEach { p ->
                val pName = p.projectName.replace("'", "''")
                val pDesc = p.detailedDescription.replace("'", "''")
                val pFund = p.fundingInstitution.replace("'", "''")
                sb.append("INSERT OR REPLACE INTO projects (projectID, projectNumber, projectName, aidTypeID, detailedDescription, projectDate, fundingInstitution, quantity, isActive) ")
                sb.append("VALUES (${p.projectID}, '${p.projectNumber}', '$pName', ${p.aidTypeID}, '$pDesc', '${p.projectDate}', '$pFund', ${p.quantity}, 1);\n")
            }

            val records = database.aidRecordDao().getAllAidRecords().first()
            records.forEach { r ->
                sb.append("INSERT OR REPLACE INTO aid_records (aidRecordID, familyID, aidTypeID, projectID, aidDate, selectionDate, recipientStatus, warehouse, aidValue) ")
                sb.append("VALUES (${r.aidRecordID}, ${r.familyID}, ${r.aidTypeID}, ${r.projectID}, '${r.aidDate}', '${r.selectionDate}', '${r.recipientStatus}', '${r.warehouse}', ${r.aidValue});\n")
            }

            sb.append("\nCOMMIT;\n")

            val fileName = "HumanitarianAid_Dump_${dateFormat.format(Date(now))}.sql"
            val (savedPath, sizeKb) = writeToScopedStorage(fileName, "application/sql") { os ->
                os.write(sb.toString().toByteArray(Charsets.UTF_8))
            }

            BackupResult(
                success = true,
                message = "تم إنشاء وحفظ ملف تفريغ SQL بنجاح في مجلد (Downloads/AidManagementBackups)",
                filePath = savedPath,
                fileSizeKb = sizeKb,
                metadata = BackupMetadata(
                    exportDate = dateStr,
                    timestamp = now,
                    totalFamilies = families.size,
                    totalChildren = children.size,
                    totalAidRecords = records.size,
                    totalProjects = projects.size
                )
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "حدث خطأ أثناء تصدير ملف SQL: ${e.localizedMessage}"
            )
        }
    }

    /**
     * استعادة قاعدة البيانات من ملف JSON
     */
    suspend fun restoreFromJson(jsonString: String, clearExisting: Boolean = false): BackupResult = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            val familiesArray = root.optJSONArray("families") ?: JSONArray()
            val childrenArray = root.optJSONArray("children") ?: JSONArray()
            val projectsArray = root.optJSONArray("projects") ?: JSONArray()
            val aidRecordsArray = root.optJSONArray("aid_records") ?: JSONArray()

            var restoredFamilies = 0
            var restoredChildren = 0
            var restoredProjects = 0
            var restoredRecords = 0

            // استعادة الأسر
            for (i in 0 until familiesArray.length()) {
                val obj = familiesArray.getJSONObject(i)
                val family = FamilyEntity(
                    familyID = obj.optLong("familyID", 0),
                    name = obj.getString("name"),
                    nationalID = obj.getString("nationalID"),
                    birthDate = obj.optString("birthDate", "1980-01-01"),
                    gender = obj.optString("gender", "ذكر"),
                    maritalStatus = obj.optString("maritalStatus", "متزوج"),
                    familyMembersCount = obj.optInt("familyMembersCount", 6),
                    wifeName = obj.optString("wifeName").takeIf { it.isNotBlank() },
                    wifeNationalID = obj.optString("wifeNationalID").takeIf { it.isNotBlank() },
                    deathStatus = obj.optString("deathStatus", "على قيد الحياة"),
                    developmentApproval = obj.optString("developmentApproval", "معتمد"),
                    localityApproval = obj.optString("localityApproval", "معتمد"),
                    worksApproval = obj.optString("worksApproval", "معتمد أشغال"),
                    residentStatus = obj.optString("residentStatus", "مقيم"),
                    damageType = obj.optString("damageType", "أضرار كلية"),
                    shelterStatus = obj.optString("shelterStatus", "إيواء داخلي"),
                    localityID = obj.optInt("localityID", 1),
                    notes = obj.optString("notes").takeIf { it.isNotBlank() },
                    createdDate = obj.optLong("createdDate", System.currentTimeMillis())
                )
                database.familyDao().insertFamily(family)
                restoredFamilies++
            }

            // استعادة الأطفال
            for (i in 0 until childrenArray.length()) {
                val obj = childrenArray.getJSONObject(i)
                val child = ChildEntity(
                    childID = obj.optLong("childID", 0),
                    nationalID = obj.getString("nationalID"),
                    childName = obj.getString("childName"),
                    birthDate = obj.optString("birthDate", "2020-01-01"),
                    gender = obj.optString("gender", "ذكر"),
                    familyNationalID = obj.getString("familyNationalID"),
                    localityID = obj.optInt("localityID", 1),
                    shelterStatus = obj.optString("shelterStatus", "إيواء داخلي")
                )
                database.childDao().insertChild(child)
                restoredChildren++
            }

            // استعادة المشاريع
            for (i in 0 until projectsArray.length()) {
                val obj = projectsArray.getJSONObject(i)
                val project = ProjectEntity(
                    projectID = obj.optLong("projectID", 0),
                    projectNumber = obj.getString("projectNumber"),
                    projectName = obj.getString("projectName"),
                    aidTypeID = obj.optInt("aidTypeID", 1),
                    detailedDescription = obj.optString("detailedDescription", ""),
                    projectDate = obj.optString("projectDate", "2025-01-01"),
                    fundingInstitution = obj.optString("fundingInstitution", "منحة إغاثية"),
                    quantity = obj.optInt("quantity", 100),
                    isActive = true
                )
                database.projectDao().insertProject(project)
                restoredProjects++
            }

            // استعادة سجلات المساعدات
            for (i in 0 until aidRecordsArray.length()) {
                val obj = aidRecordsArray.getJSONObject(i)
                val record = AidRecordEntity(
                    aidRecordID = obj.optLong("aidRecordID", 0),
                    familyID = obj.optLong("familyID"),
                    aidTypeID = obj.optInt("aidTypeID", 1),
                    projectID = obj.optLong("projectID", 1),
                    aidDate = obj.optString("aidDate", "2025-01-01"),
                    selectionDate = obj.optString("selectionDate", "2025-01-01"),
                    recipientStatus = obj.optString("recipientStatus", "مرشح"),
                    warehouse = obj.optString("warehouse", "المستودع الرئيسي"),
                    aidValue = obj.optDouble("aidValue", 50.0)
                )
                database.aidRecordDao().insertAidRecord(record)
                restoredRecords++
            }

            try {
                database.invalidationTracker.refreshVersionsAsync()
            } catch (_: Exception) {}

            BackupResult(
                success = true,
                message = "تمت استعادة البيانات بنجاح: $restoredFamilies أسرة، $restoredChildren طفلاً، $restoredProjects مشاريع، $restoredRecords سجل مساعدة.",
                metadata = BackupMetadata(
                    exportDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()),
                    timestamp = System.currentTimeMillis(),
                    totalFamilies = restoredFamilies,
                    totalChildren = restoredChildren,
                    totalAidRecords = restoredRecords,
                    totalProjects = restoredProjects
                )
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "فشلت عملية الاستعادة: ${e.localizedMessage}"
            )
        }
    }

    /**
     * تصدير قاعدة بيانات Room المشفرة إلى ملف ZIP محلي قابل للنقل
     */
    suspend fun exportEncryptedDatabaseZip(): BackupResult = withContext(Dispatchers.IO) {
        try {
            val now = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(now))
            val backupFileName = "AidManagement_Encrypted_Backup_${dateStr}.zip"

            val totalFamilies = database.familyDao().getTotalFamiliesCount()
            val totalAidRecords = database.aidRecordDao().getTotalAidRecordsCount()
            val totalProjects = database.projectDao().getTotalProjectsCount()

            // 1. إجبار قاعدة البيانات على دمج كافة التعديلات المعلقة من الذاكرة (WAL) إلى الملف الرئيسي وحذف ملفات WAL
            try {
                database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").close()
            } catch (e: Exception) {
                android.util.Log.w("DatabaseBackupManager", "wal_checkpoint TRUNCATE: ${e.message}")
            }

            // 2. استدعاء database.close() فوراً لفك حجز الملف وتدمير مرجع Singleton
            try {
                database.close()
            } catch (e: Exception) {
                android.util.Log.w("DatabaseBackupManager", "database.close(): ${e.message}")
            }
            AidDatabase.resetInstance()

            val dbPath = context.getDatabasePath(AidDatabase.DATABASE_NAME)
            if (!dbPath.exists()) {
                return@withContext BackupResult(
                    success = false,
                    message = "ملف قاعدة البيانات المشفر غير موجود (${dbPath.name})"
                )
            }

            val metaObj = JSONObject().apply {
                put("systemName", "نظام إدارة المساعدات الإنسانية - قاعدة مشفرة")
                put("exportDate", dateStr)
                put("timestamp", now)
                put("totalFamilies", totalFamilies)
                put("totalAidRecords", totalAidRecords)
                put("totalProjects", totalProjects)
            }

            // 3. نسخ ملف قاعدة البيانات (.db) فقط مدمجاً بالكامل دون أي ملفات WAL معلقة
            val (savedPath, sizeKb) = writeToScopedStorage(backupFileName, "application/zip") { os ->
                java.util.zip.ZipOutputStream(os).use { zos ->
                    zos.putNextEntry(java.util.zip.ZipEntry("metadata.json"))
                    zos.write(metaObj.toString(2).toByteArray(Charsets.UTF_8))
                    zos.flush()
                    zos.closeEntry()

                    zos.putNextEntry(java.util.zip.ZipEntry(dbPath.name))
                    FileInputStream(dbPath).use { input ->
                        input.copyTo(zos)
                    }
                    zos.flush()
                    zos.closeEntry()
                }
            }

            BackupResult(
                success = true,
                message = "تم تصدير وحفظ قاعدة البيانات المشفرة بنجاح إلى ملف ZIP في مجلد (Downloads/AidManagementBackups)",
                filePath = savedPath,
                fileSizeKb = sizeKb,
                metadata = BackupMetadata(
                    exportDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(now)),
                    timestamp = now,
                    totalFamilies = totalFamilies,
                    totalChildren = 0,
                    totalAidRecords = totalAidRecords,
                    totalProjects = totalProjects
                )
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "فشل تصدير القاعدة المشفرة: ${e.localizedMessage ?: e.message}"
            )
        }
    }

    /**
     * استعادة قاعدة البيانات من InputStream مباشرة (سواء كان ملف ZIP يحتوي على .db أو ملف قاعدة بيانات خام)
     * مع الالتزام الصارم بالخطوات:
     * 1. إغلاق قاعدة البيانات أولاً: database.close() و AidDatabase.resetInstance()
     * 2. تنظيف شامل ذري: context.deleteDatabase(dbName) وحذف ملفات الذاكرة المؤقتة (.db, -wal, -shm, -journal)
     * 3. معالجة ملفات ZIP باستخدام ZipInputStream وتخطي __MACOSX والمجلدات والملفات المخفية
     * 4. كتابة الملف مع الإجبار العتادي: outputStream.flush() و outputStream.fd.sync() لمنع ملفات 0 بايت
     * 5. إعادة التشغيل البارد النظيف (Clean Cold Restart) عبر Intent و Thread.sleep(500) و exitProcess(0)
     */
    suspend fun restoreDatabaseFromInputStream(inputStream: InputStream): BackupResult = withContext(Dispatchers.IO) {
        val tempPayload = File(context.cacheDir, "temp_restore_${System.currentTimeMillis()}.bin")
        try {
            // حفظ التدفق في ملف مؤقت لقراءته بأمان
            FileOutputStream(tempPayload).use { fos ->
                inputStream.copyTo(fos)
                fos.flush()
            }

            if (!tempPayload.exists() || tempPayload.length() == 0L) {
                return@withContext BackupResult(
                    success = false,
                    message = "ملف النسخة الاحتياطية فارغ أو غير صالح"
                )
            }

            val dbName = AidDatabase.DATABASE_NAME
            val dbFile = context.getDatabasePath(dbName)

            // الخطوة 1: إغلاق قاعدة البيانات أولاً لقطع الاتصال وفك حجز الملف كلياً
            try {
                database.close()
            } catch (e: Exception) {
                android.util.Log.w("DatabaseBackupManager", "database.close(): ${e.message}")
            }
            AidDatabase.resetInstance()

            // الخطوة 2: تنظيف شامل ذري: دالة أندرويد الرسمية وحذف كافة ملفات الذاكرة المؤقتة لمنع التعارض والفساد
            try {
                context.deleteDatabase(dbName)
            } catch (e: Exception) {
                android.util.Log.w("DatabaseBackupManager", "context.deleteDatabase: ${e.message}")
            }
            try { File(dbFile.path + "-wal").delete() } catch (_: Exception) {}
            try { File(dbFile.path + "-shm").delete() } catch (_: Exception) {}
            try { File(dbFile.path + "-journal").delete() } catch (_: Exception) {}
            try { dbFile.delete() } catch (_: Exception) {}

            dbFile.parentFile?.mkdirs()

            // الخطوة 3: استخراج آمن بـ ZipInputStream متجاهلاً المجلدات و __MACOSX والملفات المخفية
            var extractedSuccessfully = false

            try {
                FileInputStream(tempPayload).use { fis ->
                    java.util.zip.ZipInputStream(fis).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            val entryPath = entry.name
                            val entryName = entryPath.substringAfterLast('/')
                            val isMacOrHidden = entryPath.contains("__MACOSX") || entryName.startsWith(".")

                            if (!entry.isDirectory && !isMacOrHidden &&
                                (entryName.endsWith(".db") || entryName == dbName || entryName.endsWith(".sqlite"))) {
                                FileOutputStream(dbFile).use { outputStream ->
                                    zis.copyTo(outputStream)
                                    outputStream.flush()
                                    outputStream.fd.sync()
                                }
                                zis.closeEntry()
                                extractedSuccessfully = true
                                break
                            }
                            zis.closeEntry()
                            entry = zis.nextEntry
                        }
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w("DatabaseBackupManager", "ZipInputStream check: ${e.message}")
            }

            // إذا لم يتم استخراجه كـ ZIP، التحقق مما إذا كان الملف هو ملف SQLite خام
            if (!extractedSuccessfully) {
                val isRawSqlite = try {
                    FileInputStream(tempPayload).use { fis ->
                        val header = ByteArray(16)
                        val bytesRead = fis.read(header)
                        bytesRead >= 16 && String(header, 0, 15, Charsets.US_ASCII) == "SQLite format 3"
                    }
                } catch (_: Exception) { false }

                if (isRawSqlite) {
                    FileInputStream(tempPayload).use { input ->
                        FileOutputStream(dbFile).use { output ->
                            input.copyTo(output)
                            output.flush()
                            output.fd.sync()
                        }
                    }
                    extractedSuccessfully = true
                }
            }

            if (!extractedSuccessfully) {
                return@withContext BackupResult(
                    success = false,
                    message = "فشل استخراج قاعدة البيانات: الملف المضغوط لا يحتوي على ملف .db صالح، أو الملف غير صالح."
                )
            }

            // الخطوة 4: إعادة التشغيل البارد النظيف بعد مهلة نصف ثانية
            restartApplication(context)

            BackupResult(
                success = true,
                message = "تمت استعادة قاعدة البيانات بنجاح وجاري إعادة تشغيل التطبيق.",
                filePath = dbFile.absolutePath,
                fileSizeKb = dbFile.length() / 1024
            )
        } catch (e: Exception) {
            BackupResult(
                success = false,
                message = "فشلت عملية الاستعادة: ${e.localizedMessage ?: e.message}"
            )
        } finally {
            try { tempPayload.delete() } catch (_: Exception) {}
        }
    }

    /**
     * استعادة قاعدة البيانات من Uri (ملف تم اختياره من منتقي الملفات)
     */
    suspend fun restoreFromUri(uri: Uri): BackupResult = withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return@withContext BackupResult(false, "تعذر فتح ملف النسخة الاحتياطية المختار")
            inputStream.use { stream ->
                restoreDatabaseFromInputStream(stream)
            }
        } catch (e: Exception) {
            BackupResult(false, "فشلت قراءة ملف النسخة الاحتياطية: ${e.localizedMessage ?: e.message}")
        }
    }

    /**
     * استرداد قاعدة البيانات من ملف ZIP مشفر أو مضغوط محلي
     */
    suspend fun restoreEncryptedDatabaseZip(zipFile: File): BackupResult = withContext(Dispatchers.IO) {
        if (!zipFile.exists() || zipFile.length() == 0L) {
            return@withContext BackupResult(false, "ملف الأرشيف المضغوط غير موجود أو فارغ")
        }
        FileInputStream(zipFile).use { fis ->
            restoreDatabaseFromInputStream(fis)
        }
    }

    /**
     * استعادة قاعدة البيانات من ملف محلي (.db أو .sqlite أو .zip)
     */
    suspend fun restoreDatabaseFile(sourceFile: File): BackupResult = withContext(Dispatchers.IO) {
        if (!sourceFile.exists() || sourceFile.length() == 0L) {
            return@withContext BackupResult(false, "ملف قاعدة البيانات غير صالح أو فارغ")
        }
        FileInputStream(sourceFile).use { fis ->
            restoreDatabaseFromInputStream(fis)
        }
    }

    private fun addFileToZip(zos: java.util.zip.ZipOutputStream, file: File, entryName: String) {
        val entry = java.util.zip.ZipEntry(entryName)
        zos.putNextEntry(entry)
        FileInputStream(file).use { fis ->
            fis.copyTo(zos)
        }
        zos.flush()
        zos.closeEntry()
    }

    /**
     * قائمة النسخ الاحتياطية الموجودة محلياً وفي مجلد التنزيلات العام AidManagementBackups
     */
    fun listExistingBackups(): List<File> {
        val resultList = mutableListOf<File>()

        // 1. مجلد النسخ العام خارج التطبيق AidManagementBackups لضمان استرجاع النسخ بعد الحذف
        val publicDownloads = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
        val customFolder = File(publicDownloads, "AidManagementBackups")
        if (customFolder.exists()) {
            customFolder.listFiles()?.filter { it.extension in listOf("json", "sql", "zip", "db", "sqlite") }?.let {
                resultList.addAll(it)
            }
        }

        // 2. مجلد التطبيق الداخلي
        val backupDir = File(context.getExternalFilesDir(null), "backups")
        if (backupDir.exists()) {
            backupDir.listFiles()?.filter { it.extension in listOf("json", "sql", "zip", "db", "sqlite") }?.forEach { internalFile ->
                if (resultList.none { it.name == internalFile.name }) {
                    resultList.add(internalFile)
                }
            }
        }

        return resultList.sortedByDescending { it.lastModified() }
    }

    companion object {
        /**
         * إعادة التشغيل الإجباري القاطع النظيف (Clean Cold Restart):
         * بعد إتمام الاستعادة بنجاح، إطلاق Intent لتشغيل MainActivity مع:
         * FLAG_ACTIVITY_NEW_TASK or FLAG_ACTIVITY_CLEAR_TASK
         * وانتظار نصف ثانية (500ms) لضمان تسجيل الـ Intent من قِبل ActivityManager
         * ثم استدعاء kotlin.system.exitProcess(0) لقتل العملية القديمة كلياً
         */
        fun restartApplication(context: Context) {
            try {
                val intent = Intent(context, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                try {
                    val fallbackIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)?.apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    }
                    if (fallbackIntent != null) {
                        context.startActivity(fallbackIntent)
                    }
                } catch (_: Exception) {}
            } finally {
                try {
                    Thread.sleep(500)
                } catch (_: InterruptedException) {}
                kotlin.system.exitProcess(0)
            }
        }
    }
}
