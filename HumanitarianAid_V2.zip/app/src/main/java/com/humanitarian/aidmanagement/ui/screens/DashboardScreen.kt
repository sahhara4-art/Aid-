package com.humanitarian.aidmanagement.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.charts.InteractiveAnalyticsCharts
import com.humanitarian.aidmanagement.ui.viewmodel.DashboardViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    repository: AidRepository,
    database: AidDatabase,
    isSuperAdmin: Boolean,
    allowedLocalityIds: List<Int>,
    onOpenDrawer: () -> Unit,
    viewModel: DashboardViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = object : androidx.lifecycle.ViewModelProvider.Factory {
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return DashboardViewModel(database) as T
            }
        }
    )
) {
    val context = LocalContext.current
    val dateFormatter = remember { SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH) }

    LaunchedEffect(isSuperAdmin, allowedLocalityIds) {
        viewModel.setUserScope(isSuperAdmin, allowedLocalityIds)
    }

    val startDate by viewModel.startDate.collectAsState()
    val endDate by viewModel.endDate.collectAsState()

    val familiesCount by viewModel.approvedResidentFamiliesCount.collectAsState()
    val beneficiariesCount by viewModel.approvedResidentBeneficiariesCount.collectAsState()
    val aidsCount by viewModel.totalAidsCount.collectAsState()
    val localityCharts by viewModel.dynamicLocalityCharts.collectAsState()

    val aidTypes by repository.getAidTypes().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val allAidRecords by repository.getAidRecords(isSuperAdmin, allowedLocalityIds, startDate = startDate, endDate = endDate).collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("لوحة التحكم والإحصائيات", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "القائمة")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.DateRange, contentDescription = null, tint = Color(0xFF1976D2))
                            Spacer(Modifier.width(8.dp))
                            Text("تصفية حسب الفترة الزمنية", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val c = Calendar.getInstance()
                                    DatePickerDialog(context, { _, y, m, d ->
                                        c.set(y, m, d, 0, 0, 0)
                                        viewModel.setDateRange(c.timeInMillis, endDate)
                                    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (startDate != null) "من: ${dateFormatter.format(Date(startDate!!))}" else "من تاريخ...",
                                    fontSize = 12.sp
                                )
                            }
                            OutlinedButton(
                                onClick = {
                                    val c = Calendar.getInstance()
                                    DatePickerDialog(context, { _, y, m, d ->
                                        c.set(y, m, d, 23, 59, 59)
                                        viewModel.setDateRange(startDate, c.timeInMillis)
                                    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (endDate != null) "إلى: ${dateFormatter.format(Date(endDate!!))}" else "إلى تاريخ...",
                                    fontSize = 12.sp
                                )
                            }
                        }
                        if (startDate != null || endDate != null) {
                            TextButton(
                                onClick = { viewModel.clearDateRange() },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text("إلغاء التصفية", color = Color(0xFFDC2626), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "الأسر المقيمة والمقرة",
                        value = familiesCount.toString(),
                        icon = Icons.Default.Groups,
                        color = Color(0xFF1976D2),
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "إجمالي المستفيدين",
                        value = beneficiariesCount.toString(),
                        icon = Icons.Default.Person,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "إجمالي المساعدات المصروفة",
                        value = aidsCount.toString(),
                        icon = Icons.Default.VolunteerActivism,
                        color = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                InteractiveAnalyticsCharts(stats = localityCharts)
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Category, contentDescription = null, tint = Color(0xFF1976D2))
                            Spacer(Modifier.width(8.dp))
                            Text("توزيع أنواع المساعدات (11 نوع)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }
                        Spacer(Modifier.height(12.dp))
                        aidTypes.forEach { type ->
                            val count = allAidRecords.count { it.aidTypeID == type.aidTypeID }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${type.sortOrder}. ${type.aidTypeName}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF334155)
                                )
                                Surface(
                                    color = if (count > 0) Color(0xFFE8F5E9) else Color(0xFFF1F5F9),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "$count مساعدة",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (count > 0) Color(0xFF2E7D32) else Color(0xFF64748B),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            HorizontalDivider(color = Color(0xFFF1F5F9))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(color.copy(alpha = 0.12f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
            Text(title, fontSize = 11.sp, color = Color(0xFF64748B), maxLines = 1)
        }
    }
}
