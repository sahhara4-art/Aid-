package com.humanitarian.aidmanagement.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    repository: AidRepository,
    database: AidDatabase,
    isSuperAdmin: Boolean,
    allowedLocalityIds: List<Int>,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val dateFormatter = remember { SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH) }

    var startDateMillis by remember { mutableStateOf<Long?>(null) }
    var endDateMillis by remember { mutableStateOf<Long?>(null) }

    // Collect counts reactively based on date range and user locality scope
    val totalFamilies by repository.getDashboardStats(isSuperAdmin, allowedLocalityIds, startDateMillis, endDateMillis).totalFamilies.collectAsState(initial = 0)
    val totalBeneficiaries by repository.getDashboardStats(isSuperAdmin, allowedLocalityIds, startDateMillis, endDateMillis).totalBeneficiaries.collectAsState(initial = 0)
    val totalAids by repository.getDashboardStats(isSuperAdmin, allowedLocalityIds, startDateMillis, endDateMillis).totalAids.collectAsState(initial = 0)
    val totalSelections by repository.getDashboardStats(isSuperAdmin, allowedLocalityIds, startDateMillis, endDateMillis).totalSelections.collectAsState(initial = 0)
    val totalProjects by repository.getDashboardStats(isSuperAdmin, allowedLocalityIds, startDateMillis, endDateMillis).totalProjects.collectAsState(initial = 0)

    val aidTypes by repository.getAidTypes().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val allFamilies by repository.getFamiliesFiltered(isSuperAdmin, allowedLocalityIds).collectAsState(initial = emptyList())
    val allAidRecords by repository.getAidRecords(isSuperAdmin, allowedLocalityIds, startDate = startDateMillis, endDate = endDateMillis).collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("المؤشرات العامة والتقارير", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(Icons.Default.Menu, contentDescription = "القائمة")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2),
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF8FAFC))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Date Range Filter Section ("اختيار فترة: من تاريخ / إلى تاريخ")
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.DateRange, contentDescription = null, tint = Color(0xFF1976D2))
                            Spacer(Modifier.width(8.dp))
                            Text("تصفية المؤشرات حسب الفترة الزمنية", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }

                        Spacer(Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // "من تاريخ" Button
                            OutlinedButton(
                                onClick = {
                                    val c = Calendar.getInstance()
                                    DatePickerDialog(context, { _, y, m, d ->
                                        c.set(y, m, d, 0, 0, 0)
                                        startDateMillis = c.timeInMillis
                                    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (startDateMillis != null) "من: ${dateFormatter.format(Date(startDateMillis!!))}" else "من تاريخ...",
                                    fontSize = 13.sp
                                )
                            }

                            // "إلى تاريخ" Button
                            OutlinedButton(
                                onClick = {
                                    val c = Calendar.getInstance()
                                    DatePickerDialog(context, { _, y, m, d ->
                                        c.set(y, m, d, 23, 59, 59)
                                        endDateMillis = c.timeInMillis
                                    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = if (endDateMillis != null) "إلى: ${dateFormatter.format(Date(endDateMillis!!))}" else "إلى تاريخ...",
                                    fontSize = 13.sp
                                )
                            }
                        }

                        if (startDateMillis != null || endDateMillis != null) {
                            TextButton(
                                onClick = {
                                    startDateMillis = null
                                    endDateMillis = null
                                },
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Text("إعادة ضبط (عرض جميع الفترات)", color = Color(0xFFDC2626), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // 2. High Level Metric Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "إجمالي الأسر",
                        value = totalFamilies.toString(),
                        icon = Icons.Default.Groups,
                        color = Color(0xFF1976D2),
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "إجمالي المستفيدين",
                        value = totalBeneficiaries.toString(),
                        icon = Icons.Default.Person,
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "إجمالي المساعدات",
                        value = totalAids.toString(),
                        icon = Icons.Default.VolunteerActivism,
                        color = Color(0xFF0284C7),
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "عدد المرشحين",
                        value = totalSelections.toString(),
                        icon = Icons.Default.HowToReg,
                        color = Color(0xFFD97706),
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "المشاريع المنفذة",
                        value = totalProjects.toString(),
                        icon = Icons.Default.Assignment,
                        color = Color(0xFF7C3AED),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 3. Aid Types Breakdown (تصنيفات المساعدات الـ 11)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Category, contentDescription = null, tint = Color(0xFF1976D2))
                            Spacer(Modifier.width(8.dp))
                            Text("تصنيفات المساعدات (الأنواع الـ 11)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }

                        Spacer(Modifier.height(12.dp))

                        aidTypes.forEach { type ->
                            val count = allAidRecords.count { it.aidTypeID == type.aidTypeID }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${type.sortOrder}. ${type.aidTypeName}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF334155)
                                )
                                Surface(
                                    color = if (count > 0) Color(0xFFE8F5E9) else Color(0xFFF1F5F9),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "$count مساعدة",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (count > 0) Color(0xFF2E7D32) else Color(0xFF64748B),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            HorizontalDivider(color = Color(0xFFF1F5F9))
                        }
                    }
                }
            }

            // 4. Locality Citizens Distribution Table (أعداد ونسب المواطنين في المحليات)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationCity, contentDescription = null, tint = Color(0xFF1976D2))
                            Spacer(Modifier.width(8.dp))
                            Text("أعداد ونسب المواطنين في المحليات", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }

                        Spacer(Modifier.height(12.dp))

                        val totalPopulation = allFamilies.sumOf { it.familyMembersCount }.coerceAtLeast(1)

                        localities.forEach { loc ->
                            val locFamilies = allFamilies.filter { it.localityID == loc.localityId }
                            val locPop = locFamilies.sumOf { it.familyMembersCount }
                            val percentage = (locPop.toDouble() / totalPopulation.toDouble() * 100.0)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(loc.localityName, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                Text("$locPop فرد (${String.format(Locale.ENGLISH, "%.1f", percentage)}%)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF1976D2))
                            }
                            HorizontalDivider(color = Color(0xFFF1F5F9))
                        }

                        // Total row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("الإجمالي العام", fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                            Text("$totalPopulation فرد (100%)", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        }
                    }
                }
            }

            // 5. Locality Aid Distribution Table (أعداد ونسب المساعدات في المحليات)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ShareLocation, contentDescription = null, tint = Color(0xFF2E7D32))
                            Spacer(Modifier.width(8.dp))
                            Text("أعداد ونسب المساعدات في المحليات", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        }

                        Spacer(Modifier.height(12.dp))

                        val totalAidCount = allAidRecords.size.coerceAtLeast(1)

                        localities.forEach { loc ->
                            val locAids = allAidRecords.filter { it.localityID == loc.localityId }.size
                            val percentage = (locAids.toDouble() / totalAidCount.toDouble() * 100.0)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(loc.localityName, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                                Text("$locAids مساعدة (${String.format(Locale.ENGLISH, "%.1f", percentage)}%)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2E7D32))
                            }
                            HorizontalDivider(color = Color(0xFFF1F5F9))
                        }

                        // Total row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("الإجمالي العام", fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                            Text("${allAidRecords.size} مساعدة (100%)", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(color.copy(alpha = 0.12f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
            Text(title, fontSize = 11.sp, color = Color(0xFF64748B), maxLines = 1)
        }
    }
}
