package com.humanitarian.aidmanagement.util

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import com.humanitarian.aidmanagement.data.local.entities.Family
import java.io.File
import java.io.FileOutputStream

object PdfReportExporter {

    fun exportFamiliesToPdf(context: Context, families: List<Family>): File? {
        val document = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = document.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint().apply {
            color = Color.BLACK
            textSize = 14f
            isAntiAlias = true
        }

        canvas.drawText("نظام إدارة المساعدات الإنسانية - تقرير الأسر المعتمدة", 50f, 50f, paint)
        var y = 90f

        families.take(30).forEachIndexed { index, family ->
            canvas.drawText(
                "${index + 1}. ${family.name} - هوية: ${family.nationalID} - محلية: ${family.localityName ?: family.localityID}",
                50f,
                y,
                paint
            )
            y += 24f
        }

        document.finishPage(page)

        val outputFile = File(context.getExternalFilesDir("reports"), "families_report_${System.currentTimeMillis()}.pdf")
        outputFile.parentFile?.mkdirs()

        return try {
            document.writeTo(FileOutputStream(outputFile))
            document.close()
            outputFile
        } catch (e: Exception) {
            document.close()
            null
        }
    }
}
