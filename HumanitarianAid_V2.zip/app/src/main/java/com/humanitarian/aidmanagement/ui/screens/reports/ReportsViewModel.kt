package com.humanitarian.aidmanagement.ui.screens.reports

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.dao.DamageTypeBreakdown
import com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord
import com.humanitarian.aidmanagement.data.local.dao.WarDamageStats
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.currentLocation
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.local.entities.damageLevel
import com.humanitarian.aidmanagement.data.repository.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * بيانات وإحصائيات النطاق الجغرافي وأضرار الحرب المحسوبة تفاعلياً
 */
data class GeoLocalityDamageStats(
    val selectedLocality: String = "",
    val selectedSubArea: String = "",
    val localityFamilyCount: Int = 0,
    val subAreaFamilyCount: Int = 0,
    val completelyDestroyedCount: Int = 0,
    val totalAssessed: Int = 0,
    val severePartialDamageCount: Int = 0,
    val minorPartialDamageCount: Int = 0,
    val noDamageCount: Int = 0,
    val warDamageStats: WarDamageStats = WarDamageStats(0, 0, 0, 0, 0),
    val damageDistribution: List<DamageTypeBreakdown> = emptyList(),
    val availableSubAreas: List<String> = emptyList(),
    val localityCounts: Map<String, Int> = emptyMap(),
    val damageDetailsByRegion: Map<String, Map<String, Int>> = emptyMap()
) {
    val selectedBranch: String get() = selectedSubArea
    val branchFamilyCount: Int get() = subAreaFamilyCount
    val availableBranches: List<String> get() = availableSubAreas
}

/**
 * ViewModel مخصص لشاشة التقارير يدير التوزيعات والقوائم الديناميكية
 * ويعتمد حصراً وبشكل صارم على حقل "المنطقة الفرعية الحالية" (currentSubRegion)
 * ويدير تدفق البيانات الحية والإحصائيات التفاعلية لمنع التصفير والجمود
 */
class ReportsViewModel(
    val repository: AidRepository
) : ViewModel() {

    // =========================================================================
    // 1. نطاق التاريخ والفترات الزمنية التفاعلية
    // =========================================================================
    private val defaultCalendar = Calendar.getInstance()
    private val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(defaultCalendar.time)
    private val past30DaysCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -30) }
    private val past30DaysStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(past30DaysCal.time)

    private val _fromDate = MutableStateFlow(past30DaysStr)
    val fromDate: StateFlow<String> = _fromDate.asStateFlow()

    private val _toDate = MutableStateFlow(todayStr)
    val toDate: StateFlow<String> = _toDate.asStateFlow()

    private val _selectedPreset = MutableStateFlow("آخر 30 يوماً")
    val selectedPreset: StateFlow<String> = _selectedPreset.asStateFlow()

    fun setDateRange(start: String, end: String, preset: String = "مخصص") {
        _fromDate.value = start
        _toDate.value = end
        _selectedPreset.value = preset
    }

    fun applyPreset(preset: String) {
        val cal = Calendar.getInstance()
        val end = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        val start = when (preset) {
            "آخر 7 أيام" -> {
                cal.add(Calendar.DAY_OF_YEAR, -7)
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            }
            "آخر 30 يوماً" -> {
                cal.add(Calendar.DAY_OF_YEAR, -30)
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            }
            "آخر 90 يوماً" -> {
                cal.add(Calendar.DAY_OF_YEAR, -90)
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            }
            "كافة الفترات" -> "2024-01-01"
            else -> past30DaysStr
        }
        _fromDate.value = start
        _toDate.value = end
        _selectedPreset.value = preset
    }

    // =========================================================================
    // 2. حالة التصدير عبر Storage Access Framework (SAF)
    // =========================================================================
    var isExporting by mutableStateOf(false)
    var exportedFile by mutableStateOf<File?>(null)
    var exportedFileType by mutableStateOf<String?>(null)
    var exportStatusMessage by mutableStateOf<String?>(null)

    var showColumnSelectorDialog by mutableStateOf(false)
    var columnSelectorFormat by mutableStateOf("EXCEL")
    var columnSelectorReportTitle by mutableStateOf("")
    var pendingExport by mutableStateOf<PendingReportExport?>(null)

    // =========================================================================
    // 3. تدفق كافة الأسر من قاعدة البيانات والمحليات
    // =========================================================================
    // 3. تدفق المحليات المعتمدة وخيارات الفلترة
    // =========================================================================
    val localities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { list -> list.filter { it.isNotBlank() }.sorted() }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedLocality = MutableStateFlow<String>("")
    val selectedLocality: StateFlow<String> = _selectedLocality.asStateFlow()

    private val _selectedSubArea = MutableStateFlow<String>("")
    val selectedSubArea: StateFlow<String> = _selectedSubArea.asStateFlow()
    val selectedBranch: StateFlow<String> = _selectedSubArea.asStateFlow()

    fun selectLocality(locality: String) {
        _selectedLocality.value = locality
        _selectedSubArea.value = "" // إعادة تعيين الشعبة المختارة فور تغيير المحلية لمنع تضارب البيانات
        viewModelScope.launch(Dispatchers.IO) {
            val ratios = if (locality.isNotBlank()) {
                repository.calculateBranchBenefitRatiosForLocality(locality)
            } else {
                repository.calculateSubAreaBenefitRatios()
            }
            _subAreaRatios.value = ratios
        }
    }

    fun selectSubArea(subArea: String) {
        _selectedSubArea.value = subArea
    }

    fun selectBranch(branch: String) {
        _selectedSubArea.value = branch
    }

    // تدفق الشعب الفريدة التابعة للمحلية المختارة ديناميكياً مستخرجة من حقل currentBranch
    val availableBranches: StateFlow<List<String>> = _selectedLocality
        .map { loc ->
            repository.getDistinctBranchesForLocality(loc)
        }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // =========================================================================
    // 4. الحسابات التفاعلية للإحصائيات وأضرار الحرب عبر استعلامات SQLite التجميعية المباشرة
    // =========================================================================
    val geoDamageStats: StateFlow<GeoLocalityDamageStats> = combine(
        _selectedLocality,
        _selectedSubArea
    ) { selectedLoc, selectedSub ->
        // جلب قائمة الشعب التابعة للمحلية المختارة حصراً من حقل currentBranch
        val branchesForLocality = repository.getDistinctBranchesForLocality(selectedLoc)

        // إحصائيات أضرار الحرب مصنفة بالمحلية والشعبة
        val warStats = repository.getDatabase().familyDao().getWarDamageStatsByLocalityAndBranch(
            locality = selectedLoc.ifBlank { null },
            branch = selectedSub.ifBlank { null }
        )
        val breakdownList = repository.getDatabase().familyDao().getWarDamageDistributionByLocalityAndBranch(
            locality = selectedLoc.ifBlank { null },
            branch = selectedSub.ifBlank { null }
        )

        // إجمالي أسر المحلية المختارة
        val totalForLoc = if (selectedLoc.isNotBlank()) {
            repository.getDatabase().familyDao().getTotalFamiliesCountForLocalityByName(selectedLoc)
        } else {
            repository.getDatabase().familyDao().getTotalFamiliesCount()
        }

        // إجمالي أسر الشعبة المختارة التابعة للمحلية
        val totalForSub = if (selectedSub.isNotBlank()) {
            repository.getDatabase().familyDao().getTotalFamiliesCountForBranch(
                locality = selectedLoc.ifBlank { null },
                branch = selectedSub
            )
        } else {
            totalForLoc
        }

        // أعداد الأسر لكل محلية لتضمينها في القائمة المنسدلة
        val subAreaCounts = repository.getDatabase().familyDao().getTotalFamiliesCountGroupedBySubArea()
        val localityCountsMap = subAreaCounts.associate { it.subArea to it.count }

        GeoLocalityDamageStats(
            selectedLocality = selectedLoc,
            selectedSubArea = selectedSub,
            localityFamilyCount = totalForLoc,
            subAreaFamilyCount = totalForSub,
            completelyDestroyedCount = warStats.completelyDestroyedCount,
            totalAssessed = warStats.totalAssessed,
            severePartialDamageCount = warStats.severePartialDamageCount,
            minorPartialDamageCount = warStats.minorPartialDamageCount,
            noDamageCount = warStats.noDamageCount,
            warDamageStats = warStats,
            damageDistribution = breakdownList,
            availableSubAreas = branchesForLocality,
            localityCounts = localityCountsMap,
            damageDetailsByRegion = _damageDetailsByRegion.value
        )
    }.flowOn(Dispatchers.IO).stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        GeoLocalityDamageStats()
    )

    // =========================================================================
    // 5. الحالات التفاعلية للوحة التقارير الرئيسية (Dashboard & Breakdown Stats)
    // =========================================================================
    private val _dashboardStats = MutableStateFlow<DashboardStats?>(null)
    val dashboardStats: StateFlow<DashboardStats?> = _dashboardStats.asStateFlow()

    private val _localityStats = MutableStateFlow<List<LocalityDistributionStat>>(emptyList())
    val localityStats: StateFlow<List<LocalityDistributionStat>> = _localityStats.asStateFlow()

    private val _aidTypeStats = MutableStateFlow<List<AidTypeDistributionStat>>(emptyList())
    val aidTypeStats: StateFlow<List<AidTypeDistributionStat>> = _aidTypeStats.asStateFlow()

    private val _distinctAidCategories = MutableStateFlow<List<String>>(emptyList())
    val distinctAidCategories: StateFlow<List<String>> = _distinctAidCategories.asStateFlow()

    private val _subAreaRatios = MutableStateFlow<List<SubAreaBenefitRatioStat>>(emptyList())
    val subAreaRatios: StateFlow<List<SubAreaBenefitRatioStat>> = _subAreaRatios.asStateFlow()

    private val _residentStats = MutableStateFlow<List<KeyCountRecord>>(emptyList())
    val residentStats: StateFlow<List<KeyCountRecord>> = _residentStats.asStateFlow()

    private val _warDamageStats = MutableStateFlow<List<KeyCountRecord>>(emptyList())
    val warDamageStats: StateFlow<List<KeyCountRecord>> = _warDamageStats.asStateFlow()

    private val _activeProjects = MutableStateFlow<List<ProjectEntity>>(emptyList())
    val activeProjects: StateFlow<List<ProjectEntity>> = _activeProjects.asStateFlow()

    private val _localitiesList = MutableStateFlow<List<LocalityEntity>>(emptyList())
    val localitiesList: StateFlow<List<LocalityEntity>> = _localitiesList.asStateFlow()

    private val _periodDeliveryCount = MutableStateFlow(0)
    val periodDeliveryCount: StateFlow<Int> = _periodDeliveryCount.asStateFlow()

    private val _selectedProjectId = MutableStateFlow<Long?>(null)
    val selectedProjectId: StateFlow<Long?> = _selectedProjectId.asStateFlow()

    private val _selectedLocalityId = MutableStateFlow<Int?>(null)
    val selectedLocalityId: StateFlow<Int?> = _selectedLocalityId.asStateFlow()

    // =========================================================================
    // 5.1. معاينة بيانات المستفيدين قبل التصدير (Preview Before Export Workflow)
    // =========================================================================
    private val _projectPreviewList = MutableStateFlow<List<com.humanitarian.aidmanagement.util.AidRecordWithBeneficiary>>(emptyList())
    val projectPreviewList: StateFlow<List<com.humanitarian.aidmanagement.util.AidRecordWithBeneficiary>> = _projectPreviewList.asStateFlow()

    private val _isLoadingProjectPreview = MutableStateFlow(false)
    val isLoadingProjectPreview: StateFlow<Boolean> = _isLoadingProjectPreview.asStateFlow()

    private val _comprehensivePreviewList = MutableStateFlow<List<com.humanitarian.aidmanagement.util.AidRecordWithBeneficiary>>(emptyList())
    val comprehensivePreviewList: StateFlow<List<com.humanitarian.aidmanagement.util.AidRecordWithBeneficiary>> = _comprehensivePreviewList.asStateFlow()

    private val _isLoadingComprehensivePreview = MutableStateFlow(false)
    val isLoadingComprehensivePreview: StateFlow<Boolean> = _isLoadingComprehensivePreview.asStateFlow()

    private val _projectSummaries = MutableStateFlow<List<com.humanitarian.aidmanagement.data.local.dao.ProjectAggregatedSummary>>(emptyList())
    val projectSummaries: StateFlow<List<com.humanitarian.aidmanagement.data.local.dao.ProjectAggregatedSummary>> = _projectSummaries.asStateFlow()

    private var refreshJob: Job? = null
    private var projectPreviewJob: Job? = null
    private var comprehensivePreviewJob: Job? = null

    fun loadProjectPreview(projectId: Long) {
        _selectedProjectId.value = projectId
        projectPreviewJob?.cancel()
        projectPreviewJob = viewModelScope.launch(Dispatchers.IO) {
            _isLoadingProjectPreview.value = true
            try {
                _projectPreviewList.value = repository.getProjectBeneficiariesWithFamilies(projectId)
            } catch (e: Exception) {
                _projectPreviewList.value = emptyList()
            } finally {
                _isLoadingProjectPreview.value = false
            }
        }
    }

    fun loadComprehensivePreview() {
        comprehensivePreviewJob?.cancel()
        comprehensivePreviewJob = viewModelScope.launch(Dispatchers.IO) {
            _isLoadingComprehensivePreview.value = true
            try {
                val from = _fromDate.value
                val to = _toDate.value
                _comprehensivePreviewList.value = repository.getBeneficiariesWithFamiliesInDateRange(from, to)
            } catch (e: Exception) {
                _comprehensivePreviewList.value = emptyList()
            } finally {
                _isLoadingComprehensivePreview.value = false
            }
        }
    }

    fun selectProject(projectId: Long) {
        _selectedProjectId.value = projectId
        loadProjectPreview(projectId)
    }

    fun selectLocalityEntity(localityId: Int) {
        _selectedLocalityId.value = localityId
    }

    private val _damageDetailsByRegion = MutableStateFlow<Map<String, Map<String, Int>>>(emptyMap())
    val damageDetailsByRegion: StateFlow<Map<String, Map<String, Int>>> = _damageDetailsByRegion.asStateFlow()

    fun calculateDamageStats(families: List<FamilyEntity>): Map<String, Map<String, Int>> {
        val damageDetails = families.filter { !it.damageLevel.isNullOrBlank() }
            .groupBy { it.damageLevel!! }
            .mapValues { (_, familiesWithDamage) ->
                familiesWithDamage.groupBy { it.currentLocation.takeIf { loc -> !loc.isNullOrBlank() } ?: "غير محدد" }
                    .mapValues { it.value.size }
            }
        _damageDetailsByRegion.value = damageDetails
        return damageDetails
    }

    // =========================================================================
    // 6. محرك تحميل وتحديث البيانات الحية (Reactive Data Loader)
    // =========================================================================
    fun refreshData() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val from = _fromDate.value
                val to = _toDate.value

                val dStats = repository.getDashboardStats()
                val locStats = repository.getLocalityDistributionStats()
                val aStats = repository.getAidTypeDistributionStats(from, to)
                val categories = repository.getDistinctAidCategoriesSync()
                val rStats = repository.getResidentStatusDistributionStats()
                val ratios = if (_selectedLocality.value.isNotBlank()) {
                    repository.calculateBranchBenefitRatiosForLocality(_selectedLocality.value)
                } else {
                    repository.calculateSubAreaBenefitRatios()
                }
                val wStats = repository.getWarDamageDistributionStats()
                val prjs = repository.getActiveProjects().first()
                val locs = repository.getAllowedLocalitiesSync()
                val delCount = repository.getDeliveredCountInDateRange(from, to)

                val fams = repository.getAllFamiliesSync()
                calculateDamageStats(fams)

                _dashboardStats.value = dStats
                _localityStats.value = locStats
                _aidTypeStats.value = aStats
                _distinctAidCategories.value = categories
                _subAreaRatios.value = ratios
                _residentStats.value = rStats
                _warDamageStats.value = wStats
                _activeProjects.value = prjs
                _localitiesList.value = locs
                _periodDeliveryCount.value = delCount

                val pSummaries = repository.getProjectAggregatedSummaries()
                _projectSummaries.value = pSummaries

                if (_selectedProjectId.value == null && prjs.isNotEmpty()) {
                    val firstId = prjs.first().projectID
                    _selectedProjectId.value = firstId
                    loadProjectPreview(firstId)
                } else if (_selectedProjectId.value != null) {
                    loadProjectPreview(_selectedProjectId.value!!)
                }
                loadComprehensivePreview()

                if (_selectedLocalityId.value == null && locs.isNotEmpty()) {
                    _selectedLocalityId.value = locs.first().LocalityID
                }
            } catch (t: Throwable) {
                android.util.Log.e("ReportsViewModel", "Error refreshing report data", t)
            }
        }
    }

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val fams = repository.getAllFamiliesSync()
                calculateDamageStats(fams)
            } catch (e: Exception) {
                android.util.Log.e("ReportsViewModel", "calculateDamageStats error: ${e.message}")
            }
        }
    }

    fun resetFilters() {
        _fromDate.value = past30DaysStr
        _toDate.value = todayStr
        _selectedPreset.value = "آخر 30 يوماً"
        _selectedLocality.value = ""
        _selectedSubArea.value = ""
        _selectedProjectId.value = null
        _selectedLocalityId.value = null
    }

    fun clearState() {
        refreshJob?.cancel()
        projectPreviewJob?.cancel()
        comprehensivePreviewJob?.cancel()
        _projectPreviewList.value = emptyList()
        _comprehensivePreviewList.value = emptyList()
        _damageDetailsByRegion.value = emptyMap()
        _isLoadingProjectPreview.value = false
        _isLoadingComprehensivePreview.value = false
        isExporting = false
        exportedFile = null
        exportedFileType = null
        exportStatusMessage = null
        showColumnSelectorDialog = false
        pendingExport = null
        resetFilters()
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    // قوائم الفلاتر الإضافية
    val aidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val shelterStatuses: StateFlow<List<String>> = repository.getDistinctShelterStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val worksApprovals: StateFlow<List<String>> = repository.getDistinctWorksApprovalsFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val residentStatuses: StateFlow<List<String>> = repository.getDistinctResidentStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReportsViewModel(repository) as T
        }
    }
}
