package com.humanitarian.aidmanagement.ui.screens.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

/**
 * ViewModel مخصص لشاشة التقارير يدير التوزيعات والقوائم الديناميكية
 */
class ReportsViewModel(
    val repository: AidRepository
) : ViewModel() {

    // 1. المحليات المعتمدة ديناميكياً من قاعدة البيانات
    val localities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    // 2. تصنيفات المساعدات
    val aidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    // 3. أنواع الأضرار
    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    // 4. حالات الإيواء
    val shelterStatuses: StateFlow<List<String>> = repository.getDistinctShelterStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    // 5. اعتمادات الأشغال
    val worksApprovals: StateFlow<List<String>> = repository.getDistinctWorksApprovalsFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    // 6. حالات الإقامة
    val residentStatuses: StateFlow<List<String>> = repository.getDistinctResidentStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReportsViewModel(repository) as T
        }
    }
}
