package com.humanitarian.aidmanagement.ui.screens.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.dao.DamageTypeBreakdown
import com.humanitarian.aidmanagement.data.local.dao.WarDamageStats
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.flow.*

/**
 * بيانات وإحصائيات النطاق الجغرافي وأضرار الحرب المحسوبة تفاعلياً
 */
data class GeoLocalityDamageStats(
    val selectedLocality: String = "",
    val selectedSubArea: String = "",
    val localityFamilyCount: Int = 0,
    val subAreaFamilyCount: Int = 0,
    val completelyDestroyedCount: Int = 0,
    val totalAssessed: Int = 0,
    val severePartialDamageCount: Int = 0,
    val minorPartialDamageCount: Int = 0,
    val noDamageCount: Int = 0,
    val warDamageStats: WarDamageStats = WarDamageStats(0, 0, 0, 0, 0),
    val damageDistribution: List<DamageTypeBreakdown> = emptyList(),
    val availableSubAreas: List<String> = emptyList(),
    val localityCounts: Map<String, Int> = emptyMap()
)

/**
 * ViewModel مخصص لشاشة التقارير يدير التوزيعات والقوائم الديناميكية
 * ويعتمد حصراً وبشكل صارم على حقل "المنطقة الفرعية الحالية" (currentSubRegion)
 */
class ReportsViewModel(
    val repository: AidRepository
) : ViewModel() {

    // 1. تدفق كافة الأسر من قاعدة البيانات
    val allFamilies: StateFlow<List<FamilyEntity>> = repository.getAllFamiliesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // 2. قائمة المحليات المعتمدة مستخرجة حصراً وبشكل صارم من حقل "المنطقة الفرعية الحالية" (currentSubRegion)
    val localities: StateFlow<List<String>> = allFamilies.map { families ->
        families.map { it.currentSubRegion.trim() }
            .distinct()
            .filter { it.isNotBlank() }
            .sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // المحلية المحددة حالياً
    private val _selectedLocality = MutableStateFlow<String>("")
    val selectedLocality: StateFlow<String> = _selectedLocality.asStateFlow()

    // الشعبة المحددة حالياً
    private val _selectedSubArea = MutableStateFlow<String>("")
    val selectedSubArea: StateFlow<String> = _selectedSubArea.asStateFlow()

    fun selectLocality(locality: String) {
        _selectedLocality.value = locality
        _selectedSubArea.value = ""
    }

    fun selectSubArea(subArea: String) {
        _selectedSubArea.value = subArea
    }

    // 3. الحسابات التفاعلية للإحصائيات وأضرار الحرب المفلترة بالاعتماد الحصري على currentSubRegion
    val geoDamageStats: StateFlow<GeoLocalityDamageStats> = combine(
        allFamilies,
        _selectedLocality,
        _selectedSubArea
    ) { families, selectedLoc, selectedSub ->
        val effectiveLocality = if (selectedLoc.isBlank()) {
            families.map { it.currentSubRegion.trim() }.firstOrNull { it.isNotBlank() } ?: ""
        } else {
            selectedLoc
        }

        // حساب عدد الأسر لكل محلية معتمدة لعرضها في القائمة المنسدلة
        val countsByLocality = families.groupBy { it.currentSubRegion.trim() }
            .filterKeys { it.isNotBlank() }
            .mapValues { it.value.size }

        // الفلترة الصارمة بحقل "المنطقة الفرعية الحالية"
        val filteredFamilies = if (effectiveLocality.isBlank()) {
            families
        } else {
            families.filter { it.currentSubRegion.trim() == effectiveLocality }
        }

        // الشعب المتاحة في هذه المحلية المعتمدة
        val availableSubAreas = filteredFamilies
            .map { it.currentBranch.ifBlank { it.currentMosque }.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .sorted()

        // الفلترة الإضافية بالشعبة إن تم تحديدها
        val subAreaFilteredFamilies = if (selectedSub.isNotBlank()) {
            filteredFamilies.filter {
                it.currentBranch.trim() == selectedSub || it.currentMosque.trim() == selectedSub
            }
        } else {
            filteredFamilies
        }

        // حساب أضرار الحرب والمنازل المهدمة
        var completelyDestroyed = 0
        var severePartial = 0
        var minorPartial = 0
        var noDamage = 0
        var totalAssessed = 0
        val damageMap = mutableMapOf<String, Int>()

        subAreaFilteredFamilies.forEach { fam ->
            val dt = fam.damageType.trim()
            if (dt.isNotBlank()) {
                damageMap[dt] = (damageMap[dt] ?: 0) + 1
            }

            when {
                dt.contains("كلي") || dt.contains("هدم") || dt.contains("مدمر") -> {
                    completelyDestroyed++
                    totalAssessed++
                }
                dt.contains("بليغ") || dt.contains("غير صالح") -> {
                    severePartial++
                    totalAssessed++
                }
                dt.contains("جزئي") || dt.contains("طفيف") || dt.contains("صالح") -> {
                    minorPartial++
                    totalAssessed++
                }
                dt.contains("سليم") || dt.contains("لا يوجد") || dt.contains("لا ضرر") -> {
                    noDamage++
                    totalAssessed++
                }
                dt.isNotBlank() -> {
                    totalAssessed++
                }
            }
        }

        val breakdownList = damageMap.map { DamageTypeBreakdown(it.key, it.value) }
            .sortedByDescending { it.count }

        val warStats = WarDamageStats(
            totalAssessed = totalAssessed,
            completelyDestroyedCount = completelyDestroyed,
            severePartialDamageCount = severePartial,
            minorPartialDamageCount = minorPartial,
            noDamageCount = noDamage
        )

        GeoLocalityDamageStats(
            selectedLocality = effectiveLocality,
            selectedSubArea = selectedSub,
            localityFamilyCount = filteredFamilies.size,
            subAreaFamilyCount = if (selectedSub.isNotBlank()) subAreaFilteredFamilies.size else filteredFamilies.size,
            completelyDestroyedCount = completelyDestroyed,
            totalAssessed = totalAssessed,
            severePartialDamageCount = severePartial,
            minorPartialDamageCount = minorPartial,
            noDamageCount = noDamage,
            warDamageStats = warStats,
            damageDistribution = breakdownList,
            availableSubAreas = availableSubAreas,
            localityCounts = countsByLocality
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        GeoLocalityDamageStats()
    )

    // قوائم الفلاتر الإضافية
    val aidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val shelterStatuses: StateFlow<List<String>> = repository.getDistinctShelterStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val worksApprovals: StateFlow<List<String>> = repository.getDistinctWorksApprovalsFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val residentStatuses: StateFlow<List<String>> = repository.getDistinctResidentStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReportsViewModel(repository) as T
        }
    }
}
