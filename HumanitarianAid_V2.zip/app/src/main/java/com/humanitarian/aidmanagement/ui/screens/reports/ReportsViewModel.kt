package com.humanitarian.aidmanagement.ui.screens.reports

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.dao.DamageTypeBreakdown
import com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord
import com.humanitarian.aidmanagement.data.local.dao.WarDamageStats
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.currentLocation
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.local.entities.damageLevel
import com.humanitarian.aidmanagement.data.repository.*
import com.humanitarian.aidmanagement.security.AccessControlManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * بيانات وإحصائيات النطاق الجغرافي وأضرار الحرب المحسوبة تفاعلياً
 */
data class GeoLocalityDamageStats(
    val selectedLocality: String = "",
    val selectedSubArea: String = "",
    val localityFamilyCount: Int = 0,
    val subAreaFamilyCount: Int = 0,
    val completelyDestroyedCount: Int = 0,
    val totalAssessed: Int = 0,
    val severePartialDamageCount: Int = 0,
    val minorPartialDamageCount: Int = 0,
    val noDamageCount: Int = 0,
    val warDamageStats: WarDamageStats = WarDamageStats(0, 0, 0, 0, 0),
    val damageDistribution: List<DamageTypeBreakdown> = emptyList(),
    val availableSubAreas: List<String> = emptyList(),
    val localityCounts: Map<String, Int> = emptyMap(),
    val damageDetailsByRegion: Map<String, Map<String, Int>> = emptyMap()
) {
    val selectedBranch: String get() = selectedSubArea
    val branchFamilyCount: Int get() = subAreaFamilyCount
    val availableBranches: List<String> get() = availableSubAreas
}

/**
 * ViewModel مخصص لشاشة التقارير يدير التوزيعات والقوائم الديناميكية
 * ويعتمد حصراً وبشكل صارم على حقل "المنطقة الفرعية الحالية" (currentSubRegion)
 * ويدير تدفق البيانات الحية والإحصائيات التفاعلية لمنع التصفير والجمود
 */
class ReportsViewModel(
    val repository: AidRepository
) : ViewModel() {

    // =========================================================================
    // 1. نطاق التاريخ والفترات الزمنية التفاعلية
    // =========================================================================
    private val defaultCalendar = Calendar.getInstance()
    private val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(defaultCalendar.time)
    private val past30DaysCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -30) }
    private val past30DaysStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(past30DaysCal.time)

    private val _fromDate = MutableStateFlow(past30DaysStr)
    val fromDate: StateFlow<String> = _fromDate.asStateFlow()

    private val _toDate = MutableStateFlow(todayStr)
    val toDate: StateFlow<String> = _toDate.asStateFlow()

    private val _selectedPreset = MutableStateFlow("آخر 30 يوماً")
    val selectedPreset: StateFlow<String> = _selectedPreset.asStateFlow()

    fun setDateRange(start: String, end: String, preset: String = "مخصص") {
        _fromDate.value = start
        _toDate.value = end
        _selectedPreset.value = preset
    }

    fun applyPreset(preset: String) {
        val cal = Calendar.getInstance()
        val end = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        val start = when (preset) {
            "آخر 7 أيام" -> {
                cal.add(Calendar.DAY_OF_YEAR, -7)
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            }
            "آخر 30 يوماً" -> {
                cal.add(Calendar.DAY_OF_YEAR, -30)
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            }
            "آخر 90 يوماً" -> {
                cal.add(Calendar.DAY_OF_YEAR, -90)
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            }
            "كافة الفترات" -> "2024-01-01"
            else -> past30DaysStr
        }
        _fromDate.value = start
        _toDate.value = end
        _selectedPreset.value = preset
    }

    // =========================================================================
    // 2. حالة التصدير عبر Storage Access Framework (SAF)
    // =========================================================================
    var isExporting by mutableStateOf(false)
    var exportedFile by mutableStateOf<File?>(null)
    var exportedFileType by mutableStateOf<String?>(null)
    var exportStatusMessage by mutableStateOf<String?>(null)

    var showColumnSelectorDialog by mutableStateOf(false)
    var columnSelectorFormat by mutableStateOf("EXCEL")
    var columnSelectorReportTitle by mutableStateOf("")
    var pendingExport by mutableStateOf<PendingReportExport?>(null)

    // =========================================================================
    // 3. تدفق كافة الأسر من قاعدة البيانات والمحليات
    // =========================================================================
    // =========================================================================
    // 3. تدفق المحليات المعتمدة وخيارات الفلترة والعزل الجغرافي الصارم (RLS)
    // =========================================================================
    private val _isLocalityLocked = MutableStateFlow(false)
    val isLocalityLocked: StateFlow<Boolean> = _isLocalityLocked.asStateFlow()

    private val _canViewAllLocalities = MutableStateFlow(true)
    val canViewAllLocalities: StateFlow<Boolean> = _canViewAllLocalities.asStateFlow()

    private val _isBranchLocked = MutableStateFlow(false)
    val isBranchLocked: StateFlow<Boolean> = _isBranchLocked.asStateFlow()

    private val _canViewAllBranches = MutableStateFlow(true)
    val canViewAllBranches: StateFlow<Boolean> = _canViewAllBranches.asStateFlow()

    private val _lockedBranchName = MutableStateFlow<String?>(null)
    val lockedBranchName: StateFlow<String?> = _lockedBranchName.asStateFlow()

    val localities: StateFlow<List<String>> = combine(
        repository.getDistinctLocalities(),
        AccessControlManager.currentUser
    ) { list, _ ->
        val (ignoreLoc, allowedNames) = repository.getEffectiveLocalityScope()
        val cleanDbList = list.filter { it.isNotBlank() }.map { it.trim() }.distinct()
        if (ignoreLoc == 1) {
            cleanDbList.sorted()
        } else {
            val validAllowed = allowedNames.filter { it != "__DENY__" && it != "__ALL__" }
            if (validAllowed.isEmpty()) {
                emptyList()
            } else {
                cleanDbList.filter { loc ->
                    validAllowed.any { allowed -> allowed.equals(loc, ignoreCase = true) }
                }.sorted()
            }
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedLocality = MutableStateFlow<String>("")
    val selectedLocality: StateFlow<String> = _selectedLocality.asStateFlow()

    private val _selectedSubArea = MutableStateFlow<String>("")
    val selectedSubArea: StateFlow<String> = _selectedSubArea.asStateFlow()
    val selectedBranch: StateFlow<String> = _selectedSubArea.asStateFlow()

    private suspend fun applyGeographicalScope(): Pair<Int, List<String>> {
        val (ignoreLoc, allowedNames) = repository.getEffectiveLocalityScope()
        val allowedLocEntities = repository.getAllowedLocalitiesSync()
        val dbLocalities = repository.getDistinctLocalitiesRestrictedSync()
        if (ignoreLoc == 1) {
            _canViewAllLocalities.value = true
            _isLocalityLocked.value = false
        } else {
            _canViewAllLocalities.value = false
            val validAllowed = allowedNames.filter { it != "__DENY__" && it != "__ALL__" }
            val intersectedLocalities = dbLocalities.filter { loc ->
                validAllowed.any { it.equals(loc, ignoreCase = true) }
            }
            val resolvedSingleName = when {
                validAllowed.size == 1 -> intersectedLocalities.firstOrNull() ?: validAllowed.first()
                allowedLocEntities.size == 1 -> allowedLocEntities.first().LocalityName
                else -> null
            }
            if (resolvedSingleName != null) {
                _isLocalityLocked.value = true
                _selectedLocality.value = resolvedSingleName
                _selectedLocalityId.value = allowedLocEntities.firstOrNull {
                    it.LocalityName.equals(resolvedSingleName, ignoreCase = true)
                }?.LocalityID ?: allowedLocEntities.firstOrNull()?.LocalityID
            } else {
                _isLocalityLocked.value = false
                val currentSel = _selectedLocality.value
                val targetPool = intersectedLocalities.ifEmpty { validAllowed }
                if (currentSel.isNotBlank() && targetPool.none { it.equals(currentSel.trim(), ignoreCase = true) }) {
                    _selectedLocality.value = targetPool.firstOrNull() ?: ""
                    _selectedSubArea.value = ""
                } else if (currentSel.isBlank() && targetPool.isNotEmpty()) {
                    _selectedLocality.value = targetPool.first()
                }
            }
        }

        val (ignoreBr, allowedBranches) = repository.getEffectiveBranchScope()
        if (ignoreBr == 1) {
            _canViewAllBranches.value = true
            _isBranchLocked.value = false
            _lockedBranchName.value = null
        } else {
            _canViewAllBranches.value = false
            val validBranches = allowedBranches.filter { it != "__DENY__" && it != "__ALL__" }
            val dbBranches = repository.getAllDistinctBranches()
            val intersectedBranches = dbBranches.filter { b ->
                validBranches.any { it.equals(b, ignoreCase = true) }
            }
            if (validBranches.size == 1) {
                val singleBranch = intersectedBranches.firstOrNull() ?: validBranches.first()
                _isBranchLocked.value = true
                _lockedBranchName.value = singleBranch
                _selectedSubArea.value = singleBranch
            } else {
                _isBranchLocked.value = false
                _lockedBranchName.value = null
                val currentBr = _selectedSubArea.value
                if (currentBr.isBlank() || intersectedBranches.none { it.equals(currentBr.trim(), ignoreCase = true) }) {
                    _selectedSubArea.value = intersectedBranches.firstOrNull() ?: ""
                }
            }
        }
        return ignoreLoc to allowedNames
    }

    fun selectLocality(locality: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val (ignoreLoc, allowedNames) = repository.getEffectiveLocalityScope()
            val effectiveTarget = if (ignoreLoc == 0) {
                val validAllowed = allowedNames.filter { it != "__DENY__" && it != "__ALL__" }
                if (validAllowed.size == 1) {
                    val lockedName = validAllowed.first()
                    _isLocalityLocked.value = true
                    lockedName
                } else {
                    if (locality.isBlank() || validAllowed.none { it.equals(locality.trim(), ignoreCase = true) }) {
                        return@launch
                    }
                    locality
                }
            } else {
                locality
            }
            _selectedLocality.value = effectiveTarget
            val (ignoreBr, allowedBranches) = repository.getEffectiveBranchScope()
            if (ignoreBr == 1) {
                _selectedSubArea.value = "" // إعادة تعيين الشعبة المختارة فور تغيير المحلية لمنع تضارب البيانات
            } else {
                val validBranches = allowedBranches.filter { it != "__DENY__" && it != "__ALL__" }
                if (validBranches.size == 1) {
                    _selectedSubArea.value = validBranches.first()
                } else {
                    val locBranches = repository.getDistinctBranchesForLocality(effectiveTarget)
                    val currentBr = _selectedSubArea.value
                    if (currentBr.isBlank() || validBranches.none { it.equals(currentBr.trim(), ignoreCase = true) }) {
                        _selectedSubArea.value = locBranches.firstOrNull() ?: validBranches.firstOrNull() ?: ""
                    }
                }
            }
            val ratios = if (effectiveTarget.isNotBlank()) {
                repository.calculateBranchBenefitRatiosForLocality(effectiveTarget)
            } else {
                repository.calculateSubAreaBenefitRatios()
            }
            _subAreaRatios.value = ratios
        }
    }

    fun selectSubArea(subArea: String) {
        val (ignoreBr, allowedBranches) = repository.getEffectiveBranchScope()
        if (ignoreBr == 0) {
            val validBranches = allowedBranches.filter { it != "__DENY__" && it != "__ALL__" }
            if (validBranches.size == 1) {
                val singleBranch = validBranches.first()
                _isBranchLocked.value = true
                _lockedBranchName.value = singleBranch
                _selectedSubArea.value = singleBranch
                return
            }
            if (subArea.isBlank() || validBranches.none { it.equals(subArea.trim(), ignoreCase = true) }) {
                return
            }
        }
        _selectedSubArea.value = subArea
    }

    fun selectBranch(branch: String) {
        selectSubArea(branch)
    }

    // تدفق الشعب الفريدة التابعة للمحلية المختارة ديناميكياً مستخرجة من حقل currentBranch
    val availableBranches: StateFlow<List<String>> = combine(
        _selectedLocality,
        AccessControlManager.currentUser
    ) { loc, _ ->
        repository.getDistinctBranchesForLocality(loc)
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // =========================================================================
    // 4. الحسابات التفاعلية للإحصائيات وأضرار الحرب عبر استعلامات SQLite التجميعية المباشرة والمقيدة جغرافياً
    // =========================================================================
    val geoDamageStats: StateFlow<GeoLocalityDamageStats> = combine(
        _selectedLocality,
        _selectedSubArea,
        AccessControlManager.currentUser
    ) { selectedLoc, selectedSub, _ ->
        val (ignoreLoc, allowedNames) = repository.getEffectiveLocalityScope()
        val (ignoreBr, allowedBranches) = repository.getEffectiveBranchScope()
        val effectiveLoc = if (ignoreLoc == 0) {
            val validAllowed = allowedNames.filter { it != "__DENY__" && it != "__ALL__" }
            when {
                validAllowed.size == 1 -> validAllowed.first()
                selectedLoc.isNotBlank() && validAllowed.any { it.equals(selectedLoc.trim(), ignoreCase = true) } -> selectedLoc
                else -> validAllowed.firstOrNull() ?: ""
            }
        } else {
            selectedLoc
        }

        val effectiveSub = if (ignoreBr == 0) {
            val validBranches = allowedBranches.filter { it != "__DENY__" && it != "__ALL__" }
            when {
                validBranches.size == 1 -> validBranches.first()
                selectedSub.isNotBlank() && validBranches.any { it.equals(selectedSub.trim(), ignoreCase = true) } -> selectedSub
                else -> validBranches.firstOrNull() ?: ""
            }
        } else {
            selectedSub
        }

        // جلب قائمة الشعب التابعة للمحلية المختارة حصراً من حقل currentBranch ضمن النطاق الجغرافي
        val branchesForLocality = repository.getDistinctBranchesForLocality(effectiveLoc)
        val familyDao = repository.getDatabase().familyDao()

        // إحصائيات أضرار الحرب مصنفة بالمحلية والشعبة مع العزل الجغرافي الصارم
        val warStats = familyDao.getWarDamageStatsByLocalityAndBranchRestricted(
            locality = effectiveLoc.ifBlank { null },
            branch = effectiveSub.ifBlank { null },
            ignoreLocalities = ignoreLoc,
            allowedLocalities = allowedNames,
            ignoreBranches = ignoreBr,
            allowedBranches = allowedBranches
        )
        val breakdownList = familyDao.getWarDamageDistributionByLocalityAndBranchRestricted(
            locality = effectiveLoc.ifBlank { null },
            branch = effectiveSub.ifBlank { null },
            ignoreLocalities = ignoreLoc,
            allowedLocalities = allowedNames,
            ignoreBranches = ignoreBr,
            allowedBranches = allowedBranches
        )

        // إجمالي أسر المحلية المختارة ضمن النطاق الجغرافي
        val totalForLoc = if (effectiveLoc.isNotBlank()) {
            familyDao.getTotalFamiliesCountForLocalityByNameRestricted(
                locality = effectiveLoc,
                ignoreLocalities = ignoreLoc,
                allowedLocalities = allowedNames,
                ignoreBranches = ignoreBr,
                allowedBranches = allowedBranches
            )
        } else {
            familyDao.getTotalFamiliesCountRestricted(
                ignoreLocalities = ignoreLoc,
                allowedLocalities = allowedNames,
                ignoreBranches = ignoreBr,
                allowedBranches = allowedBranches
            )
        }

        // إجمالي أسر الشعبة المختارة التابعة للمحلية ضمن النطاق الجغرافي
        val totalForSub = if (effectiveSub.isNotBlank()) {
            familyDao.getTotalFamiliesCountForBranchRestricted(
                locality = effectiveLoc.ifBlank { null },
                branch = effectiveSub,
                ignoreLocalities = ignoreLoc,
                allowedLocalities = allowedNames,
                ignoreBranches = ignoreBr,
                allowedBranches = allowedBranches
            )
        } else {
            totalForLoc
        }

        // أعداد الأسر لكل محلية لتضمينها في القائمة المنسدلة (مفلترة جغرافياً)
        val subAreaCounts = familyDao.getTotalFamiliesCountGroupedBySubAreaRestricted(
            ignoreLocalities = ignoreLoc,
            allowedLocalities = allowedNames,
            ignoreBranches = ignoreBr,
            allowedBranches = allowedBranches
        )
        val localityCountsMap = subAreaCounts.associate { it.subArea to it.count }

        GeoLocalityDamageStats(
            selectedLocality = effectiveLoc,
            selectedSubArea = effectiveSub,
            localityFamilyCount = totalForLoc,
            subAreaFamilyCount = totalForSub,
            completelyDestroyedCount = warStats.completelyDestroyedCount,
            totalAssessed = warStats.totalAssessed,
            severePartialDamageCount = warStats.severePartialDamageCount,
            minorPartialDamageCount = warStats.minorPartialDamageCount,
            noDamageCount = warStats.noDamageCount,
            warDamageStats = warStats,
            damageDistribution = breakdownList,
            availableSubAreas = branchesForLocality,
            localityCounts = localityCountsMap,
            damageDetailsByRegion = _damageDetailsByRegion.value
        )
    }.flowOn(Dispatchers.IO).stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        GeoLocalityDamageStats()
    )

    // =========================================================================
    // 5. الحالات التفاعلية للوحة التقارير الرئيسية (Dashboard & Breakdown Stats)
    // =========================================================================
    private val _dashboardStats = MutableStateFlow<DashboardStats?>(null)
    val dashboardStats: StateFlow<DashboardStats?> = _dashboardStats.asStateFlow()

    private val _localityStats = MutableStateFlow<List<LocalityDistributionStat>>(emptyList())
    val localityStats: StateFlow<List<LocalityDistributionStat>> = _localityStats.asStateFlow()

    private val _aidTypeStats = MutableStateFlow<List<AidTypeDistributionStat>>(emptyList())
    val aidTypeStats: StateFlow<List<AidTypeDistributionStat>> = _aidTypeStats.asStateFlow()

    private val _distinctAidCategories = MutableStateFlow<List<String>>(emptyList())
    val distinctAidCategories: StateFlow<List<String>> = _distinctAidCategories.asStateFlow()

    private val _subAreaRatios = MutableStateFlow<List<SubAreaBenefitRatioStat>>(emptyList())
    val subAreaRatios: StateFlow<List<SubAreaBenefitRatioStat>> = _subAreaRatios.asStateFlow()

    private val _residentStats = MutableStateFlow<List<KeyCountRecord>>(emptyList())
    val residentStats: StateFlow<List<KeyCountRecord>> = _residentStats.asStateFlow()

    private val _warDamageStats = MutableStateFlow<List<KeyCountRecord>>(emptyList())
    val warDamageStats: StateFlow<List<KeyCountRecord>> = _warDamageStats.asStateFlow()

    private val _activeProjects = MutableStateFlow<List<ProjectEntity>>(emptyList())
    val activeProjects: StateFlow<List<ProjectEntity>> = _activeProjects.asStateFlow()

    private val _localitiesList = MutableStateFlow<List<LocalityEntity>>(emptyList())
    val localitiesList: StateFlow<List<LocalityEntity>> = _localitiesList.asStateFlow()

    private val _periodDeliveryCount = MutableStateFlow(0)
    val periodDeliveryCount: StateFlow<Int> = _periodDeliveryCount.asStateFlow()

    private val _selectedProjectId = MutableStateFlow<Long?>(null)
    val selectedProjectId: StateFlow<Long?> = _selectedProjectId.asStateFlow()

    private val _selectedLocalityId = MutableStateFlow<Int?>(null)
    val selectedLocalityId: StateFlow<Int?> = _selectedLocalityId.asStateFlow()

    // =========================================================================
    // 5.1. معاينة بيانات المستفيدين قبل التصدير (Preview Before Export Workflow)
    // =========================================================================
    private val _projectPreviewList = MutableStateFlow<List<com.humanitarian.aidmanagement.util.AidRecordWithBeneficiary>>(emptyList())
    val projectPreviewList: StateFlow<List<com.humanitarian.aidmanagement.util.AidRecordWithBeneficiary>> = _projectPreviewList.asStateFlow()

    private val _isLoadingProjectPreview = MutableStateFlow(false)
    val isLoadingProjectPreview: StateFlow<Boolean> = _isLoadingProjectPreview.asStateFlow()

    private val _comprehensivePreviewList = MutableStateFlow<List<com.humanitarian.aidmanagement.util.AidRecordWithBeneficiary>>(emptyList())
    val comprehensivePreviewList: StateFlow<List<com.humanitarian.aidmanagement.util.AidRecordWithBeneficiary>> = _comprehensivePreviewList.asStateFlow()

    private val _isLoadingComprehensivePreview = MutableStateFlow(false)
    val isLoadingComprehensivePreview: StateFlow<Boolean> = _isLoadingComprehensivePreview.asStateFlow()

    private val _projectSummaries = MutableStateFlow<List<com.humanitarian.aidmanagement.data.local.dao.ProjectAggregatedSummary>>(emptyList())
    val projectSummaries: StateFlow<List<com.humanitarian.aidmanagement.data.local.dao.ProjectAggregatedSummary>> = _projectSummaries.asStateFlow()

    private var refreshJob: Job? = null
    private var projectPreviewJob: Job? = null
    private var comprehensivePreviewJob: Job? = null

    fun loadProjectPreview(projectId: Long) {
        _selectedProjectId.value = projectId
        projectPreviewJob?.cancel()
        projectPreviewJob = viewModelScope.launch(Dispatchers.IO) {
            _isLoadingProjectPreview.value = true
            try {
                _projectPreviewList.value = repository.getProjectBeneficiariesWithFamiliesPreview(projectId, limit = 50)
            } catch (e: Exception) {
                _projectPreviewList.value = emptyList()
            } finally {
                _isLoadingProjectPreview.value = false
            }
        }
    }

    fun loadComprehensivePreview() {
        comprehensivePreviewJob?.cancel()
        comprehensivePreviewJob = viewModelScope.launch(Dispatchers.IO) {
            _isLoadingComprehensivePreview.value = true
            try {
                val from = _fromDate.value
                val to = _toDate.value
                _comprehensivePreviewList.value = repository.getBeneficiariesWithFamiliesInDateRangePreview(from, to, limit = 50)
            } catch (e: Exception) {
                _comprehensivePreviewList.value = emptyList()
            } finally {
                _isLoadingComprehensivePreview.value = false
            }
        }
    }

    fun selectProject(projectId: Long) {
        _selectedProjectId.value = projectId
        loadProjectPreview(projectId)
    }

    fun selectLocalityEntity(localityId: Int) {
        _selectedLocalityId.value = localityId
    }

    private val _damageDetailsByRegion = MutableStateFlow<Map<String, Map<String, Int>>>(emptyMap())
    val damageDetailsByRegion: StateFlow<Map<String, Map<String, Int>>> = _damageDetailsByRegion.asStateFlow()

    fun calculateDamageStats(families: List<FamilyEntity>): Map<String, Map<String, Int>> {
        val damageDetails = families.filter { !it.damageLevel.isNullOrBlank() }
            .groupBy { it.damageLevel!! }
            .mapValues { (_, familiesWithDamage) ->
                familiesWithDamage.groupBy { it.currentLocation.takeIf { loc -> !loc.isNullOrBlank() } ?: "غير محدد" }
                    .mapValues { it.value.size }
            }
        _damageDetailsByRegion.value = damageDetails
        return damageDetails
    }

    // =========================================================================
    // 6. محرك تحميل وتحديث البيانات الحية (Reactive Data Loader)
    // =========================================================================
    fun refreshData() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                applyGeographicalScope()
                val from = _fromDate.value
                val to = _toDate.value

                val dStats = repository.getDashboardStats()
                val locStats = repository.getLocalityDistributionStats()
                val aStats = repository.getAidTypeDistributionStats(from, to)
                val categories = repository.getDistinctAidCategoriesSync()
                val rStats = repository.getResidentStatusDistributionStats()
                val ratios = if (_selectedLocality.value.isNotBlank()) {
                    repository.calculateBranchBenefitRatiosForLocality(_selectedLocality.value)
                } else {
                    repository.calculateSubAreaBenefitRatios()
                }
                val wStats = repository.getWarDamageDistributionStats()
                val prjs = repository.getActiveProjectsRestrictedSync()
                val locs = repository.getAllowedLocalitiesSync()
                val delCount = repository.getDeliveredCountInDateRange(from, to)

                _damageDetailsByRegion.value = repository.getDamageDetailsByRegionMap()

                _dashboardStats.value = dStats
                _localityStats.value = locStats
                _aidTypeStats.value = aStats
                _distinctAidCategories.value = categories
                _subAreaRatios.value = ratios
                _residentStats.value = rStats
                _warDamageStats.value = wStats
                _activeProjects.value = prjs
                _localitiesList.value = locs
                _periodDeliveryCount.value = delCount

                val pSummaries = repository.getProjectAggregatedSummaries()
                _projectSummaries.value = pSummaries

                if (_selectedProjectId.value == null && prjs.isNotEmpty()) {
                    val firstId = prjs.first().projectID
                    _selectedProjectId.value = firstId
                    loadProjectPreview(firstId)
                } else if (_selectedProjectId.value != null) {
                    loadProjectPreview(_selectedProjectId.value!!)
                }
                loadComprehensivePreview()

                if (_selectedLocalityId.value == null && locs.isNotEmpty()) {
                    _selectedLocalityId.value = locs.first().LocalityID
                }
            } catch (t: Throwable) {
                android.util.Log.e("ReportsViewModel", "Error refreshing report data", t)
            }
        }
    }

    init {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                applyGeographicalScope()
                _distinctAidCategories.value = repository.getDistinctAidCategoriesSync()
                _damageDetailsByRegion.value = repository.getDamageDetailsByRegionMap()
            } catch (e: Exception) {
                android.util.Log.e("ReportsViewModel", "init error: ${e.message}")
            }
        }
        viewModelScope.launch {
            repository.currentUserFlow.drop(1).collect {
                refreshData()
            }
        }
    }

    fun resetFilters() {
        _fromDate.value = past30DaysStr
        _toDate.value = todayStr
        _selectedPreset.value = "آخر 30 يوماً"
        if (!_isLocalityLocked.value) {
            _selectedLocality.value = ""
            _selectedLocalityId.value = null
        }
        if (_isBranchLocked.value && !_lockedBranchName.value.isNullOrBlank()) {
            _selectedSubArea.value = _lockedBranchName.value!!
        } else if (!_canViewAllBranches.value) {
            val (_, allowedBranches) = repository.getEffectiveBranchScope()
            _selectedSubArea.value = allowedBranches.firstOrNull { it != "__DENY__" && it != "__ALL__" } ?: ""
        } else {
            _selectedSubArea.value = ""
        }
        _selectedProjectId.value = null
    }

    fun clearState() {
        refreshJob?.cancel()
        projectPreviewJob?.cancel()
        comprehensivePreviewJob?.cancel()
        _projectPreviewList.value = emptyList()
        _comprehensivePreviewList.value = emptyList()
        _damageDetailsByRegion.value = emptyMap()
        _isLoadingProjectPreview.value = false
        _isLoadingComprehensivePreview.value = false
        isExporting = false
        exportedFile = null
        exportedFileType = null
        exportStatusMessage = null
        showColumnSelectorDialog = false
        pendingExport = null
        resetFilters()
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    // قوائم الفلاتر الإضافية
    val aidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val shelterStatuses: StateFlow<List<String>> = repository.getDistinctShelterStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val worksApprovals: StateFlow<List<String>> = repository.getDistinctWorksApprovalsFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val residentStatuses: StateFlow<List<String>> = repository.getDistinctResidentStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ReportsViewModel(repository) as T
        }
    }
}
