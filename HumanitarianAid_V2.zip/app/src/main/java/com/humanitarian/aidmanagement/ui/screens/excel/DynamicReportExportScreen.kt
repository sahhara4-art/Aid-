package com.humanitarian.aidmanagement.ui.screens.excel

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.util.ChildExportColumnRegistry
import com.humanitarian.aidmanagement.util.ExportColumnRegistry
import com.humanitarian.aidmanagement.util.ProjectExportColumnRegistry
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ScreenGradientColors = listOf(
    Color(0xFF0A192F),
    Color(0xFF0F2E3A),
    Color(0xFF0B3D38),
    Color(0xFF0D1B2A)
)

private val GlassCardBg = Color.White.copy(alpha = 0.1f)
private val GlassCardActiveBg = Color.White.copy(alpha = 0.14f)
private val GlassCardBorder = Color.White.copy(alpha = 0.4f)
private val GlassSubtleBg = Color.White.copy(alpha = 0.06f)

private val ExcelGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFF059669), Color(0xFF10B981))
)

private val PdfGradient = Brush.horizontalGradient(
    colors = listOf(Color(0xFFDC2626), Color(0xFFF43F5E))
)

/**
 * شاشة مركز التقارير والمعاينة الديناميكي المستقلة
 * تصميم زجاجي (Glassmorphism) مع فلاتر ديناميكية 100% من قاعدة البيانات،
 * دعم التحديد المتعدد والاستثناء والتجاوز التلقائي، والعزل الجغرافي الصارم RLS.
 */
@Composable
fun DynamicReportExportScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    exportViewModel: DynamicExportViewModel = viewModel(
        factory = DynamicExportViewModelFactory(repository)
    )
) {
    val totalMatchingCount by exportViewModel.totalMatchingCount.collectAsStateWithLifecycle()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(colors = ScreenGradientColors))
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // ترويسة زجاجية علوية مدمجة
                GlassTopHeader(
                    totalMatchingCount = totalMatchingCount,
                    onNavigateBack = onNavigateBack,
                    onRefresh = { exportViewModel.refreshGeographicalScope() },
                    onReset = { exportViewModel.resetFilters() }
                )

                DynamicReportExportContent(
                    viewModel = exportViewModel,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun GlassTopHeader(
    totalMatchingCount: Int,
    onNavigateBack: () -> Unit,
    onRefresh: () -> Unit,
    onReset: () -> Unit
) {
    Surface(
        color = Color.White.copy(alpha = 0.09f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
        shape = RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ArrowForward,
                        contentDescription = "رجوع",
                        tint = Color.White
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "مركز التقارير والمعاينة الديناميكي",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "استعلام SQLite ديناميكي • معاينة حية • تصدير آمن",
                        color = Color.White.copy(alpha = 0.72f),
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF10B981).copy(alpha = 0.25f),
                    border = BorderStroke(1.dp, Color(0xFF34D399).copy(alpha = 0.55f))
                ) {
                    Text(
                        text = "$totalMatchingCount سجل",
                        color = Color(0xFFA7F3D0),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }

                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.1f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = "تحديث الخيارات والبيانات",
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onReset,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.1f))
                ) {
                    Icon(
                        imageVector = Icons.Rounded.RestartAlt,
                        contentDescription = "إعادة ضبط الفلاتر",
                        tint = Color(0xFFFBBF24),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DynamicReportExportContent(
    viewModel: DynamicExportViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val selectedEntity by viewModel.selectedEntity.collectAsStateWithLifecycle()
    val filterOptions by viewModel.filterOptions.collectAsStateWithLifecycle()

    // حالات الفلاتر متعددة الاختيار (الأسر)
    val approvalFilter by viewModel.approvalFilter.collectAsStateWithLifecycle()
    val localityApprovalFilter by viewModel.localityApprovalFilter.collectAsStateWithLifecycle()
    val localityFilter by viewModel.localityFilter.collectAsStateWithLifecycle()
    val currentMainAreaFilter by viewModel.currentMainAreaFilter.collectAsStateWithLifecycle()
    val currentSubAreaFilter by viewModel.currentSubAreaFilter.collectAsStateWithLifecycle()
    val branchFilter by viewModel.branchFilter.collectAsStateWithLifecycle()
    val worksFilter by viewModel.worksFilter.collectAsStateWithLifecycle()
    val damageFilter by viewModel.damageFilter.collectAsStateWithLifecycle()
    val maritalFilter by viewModel.maritalFilter.collectAsStateWithLifecycle()
    val injuryFilter by viewModel.injuryFilter.collectAsStateWithLifecycle()
    val shelterFilter by viewModel.shelterFilter.collectAsStateWithLifecycle()
    val shelterCenterFilter by viewModel.shelterCenterFilter.collectAsStateWithLifecycle()
    val residentFilter by viewModel.residentFilter.collectAsStateWithLifecycle()
    val membersRangeFilter by viewModel.membersRangeFilter.collectAsStateWithLifecycle()

    // فلاتر المشاريع
    val projectLocalityFilter by viewModel.projectLocalityFilter.collectAsStateWithLifecycle()
    val projectStatusFilter by viewModel.projectStatusFilter.collectAsStateWithLifecycle()
    val projectAidTypeFilter by viewModel.projectAidTypeFilter.collectAsStateWithLifecycle()
    val projectFunderFilter by viewModel.projectFunderFilter.collectAsStateWithLifecycle()
    val projectWarehouseFilter by viewModel.projectWarehouseFilter.collectAsStateWithLifecycle()

    // فلاتر الأبناء
    val childGenderFilter by viewModel.childGenderFilter.collectAsStateWithLifecycle()
    val childShelterFilter by viewModel.childShelterFilter.collectAsStateWithLifecycle()
    val childLocalityFilter by viewModel.childLocalityFilter.collectAsStateWithLifecycle()
    val childSubAreaFilter by viewModel.childSubAreaFilter.collectAsStateWithLifecycle()

    // قيود العزل الجغرافي والخيارات المخزنة في StateFlow
    val residenceLocationOptions by viewModel.residenceLocationOptions.collectAsStateWithLifecycle()
    val residentStatusOptions by viewModel.residentStatusOptions.collectAsStateWithLifecycle()
    val approvalStatusOptions by viewModel.approvalStatusOptions.collectAsStateWithLifecycle()
    val maritalStatusOptions by viewModel.maritalStatusOptions.collectAsStateWithLifecycle()
    val currentSubAreaOptions by viewModel.currentSubAreaOptions.collectAsStateWithLifecycle()
    val isLocalityLocked by viewModel.isLocalityLocked.collectAsStateWithLifecycle()
    val lockedLocalityName by viewModel.lockedLocalityName.collectAsStateWithLifecycle()
    val allowedBranches by viewModel.allowedBranches.collectAsStateWithLifecycle()
    val isBranchLocked by viewModel.isBranchLocked.collectAsStateWithLifecycle()
    val lockedBranchName by viewModel.lockedBranchName.collectAsStateWithLifecycle()

    // المعاينة والأعمدة والتصدير
    val isLoadingPreview by viewModel.isLoadingPreview.collectAsStateWithLifecycle()
    val previewFamilies by viewModel.previewFamilies.collectAsStateWithLifecycle()
    val previewProjects by viewModel.previewProjects.collectAsStateWithLifecycle()
    val previewChildren by viewModel.previewChildren.collectAsStateWithLifecycle()
    val totalMatchingCount by viewModel.totalMatchingCount.collectAsStateWithLifecycle()

    val selectedColumnKeys by viewModel.selectedColumnKeys.collectAsStateWithLifecycle()
    val selectedExcelFormat by viewModel.selectedExcelFormat.collectAsStateWithLifecycle()
    val isExporting by viewModel.isExporting.collectAsStateWithLifecycle()
    val exportProgress by viewModel.exportProgress.collectAsStateWithLifecycle()
    val exportStatusMessage by viewModel.exportStatusMessage.collectAsStateWithLifecycle()

    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val canExportExcel = remember(currentUser) { AccessControlManager.canExportExcel() }
    val canExportPdf = remember(currentUser) { AccessControlManager.canExportPdf() }

    LaunchedEffect(currentUser) {
        viewModel.refreshGeographicalScope()
    }

    fun buildReportTitle(entity: DynamicEntityType): String = when (entity) {
        DynamicEntityType.FAMILIES -> "تقرير كشف الأسر والمواطنين الديناميكي"
        DynamicEntityType.PROJECTS -> "تقرير كشف المشاريع الإغاثية والمنح"
        DynamicEntityType.CHILDREN -> "تقرير كشف الأبناء والتابعين الديناميكي"
    }

    fun buildFilePrefix(entity: DynamicEntityType): String = when (entity) {
        DynamicEntityType.FAMILIES -> "Families_Dynamic"
        DynamicEntityType.PROJECTS -> "Projects_Dynamic"
        DynamicEntityType.CHILDREN -> "Children_Dynamic"
    }

    val xlsxExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(DynamicExportFormat.EXCEL_XLSX.mimeType)
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val res = viewModel.exportFullDataToUri(
                    context = context,
                    uri = uri,
                    format = DynamicExportFormat.EXCEL_XLSX,
                    title = buildReportTitle(selectedEntity)
                )
                res.onSuccess {
                    Toast.makeText(context, "✅ تم تصدير ملف الإكسل (.xlsx) بنجاح!", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    Toast.makeText(context, "❌ فشل تصدير الإكسل: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val csvExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(DynamicExportFormat.EXCEL_CSV.mimeType)
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val res = viewModel.exportFullDataToUri(
                    context = context,
                    uri = uri,
                    format = DynamicExportFormat.EXCEL_CSV,
                    title = buildReportTitle(selectedEntity)
                )
                res.onSuccess {
                    Toast.makeText(context, "✅ تم تصدير ملف الإكسل (.csv) بنجاح!", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    Toast.makeText(context, "❌ فشل تصدير الإكسل: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val pdfExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(DynamicExportFormat.PDF.mimeType)
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val res = viewModel.exportFullDataToUri(
                    context = context,
                    uri = uri,
                    format = DynamicExportFormat.PDF,
                    title = buildReportTitle(selectedEntity)
                )
                res.onSuccess {
                    Toast.makeText(context, "✅ تم توليد وحفظ ملف PDF بنجاح!", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    Toast.makeText(context, "❌ فشل تصدير PDF: ${err.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 36.dp)
    ) {
        // =========================================================================
        // 1. اختيار الكيان المستهدف للتقرير
        // =========================================================================
        item {
            GlassSectionCard(
                title = "اختيار نطاق البيانات",
                subtitle = "اختر الكيان المراد تصفيته ومعاينته وتصديره",
                icon = Icons.Rounded.Dataset,
                iconColor = Color(0xFF38BDF8)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DynamicEntityType.values().forEach { entity ->
                        val isSelected = selectedEntity == entity
                        val entityIcon = when (entity) {
                            DynamicEntityType.FAMILIES -> Icons.Rounded.FamilyRestroom
                            DynamicEntityType.PROJECTS -> Icons.Rounded.Inventory2
                            DynamicEntityType.CHILDREN -> Icons.Rounded.ChildCare
                        }
                        val entityAccent = when (entity) {
                            DynamicEntityType.FAMILIES -> Color(0xFF34D399)
                            DynamicEntityType.PROJECTS -> Color(0xFFFBBF24)
                            DynamicEntityType.CHILDREN -> Color(0xFF38BDF8)
                        }
                        Surface(
                            onClick = { viewModel.selectEntity(entity) },
                            shape = RoundedCornerShape(18.dp),
                            color = if (isSelected) entityAccent.copy(alpha = 0.22f) else GlassSubtleBg,
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) entityAccent else Color.White.copy(alpha = 0.28f)
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = entityIcon,
                                    contentDescription = null,
                                    tint = if (isSelected) entityAccent else Color.White.copy(alpha = 0.8f),
                                    modifier = Modifier.size(24.dp)
                                )
                                Text(
                                    text = entity.label,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }

        // =========================================================================
        // 2. بطاقات الفلاتر الزجاجية القابلة للتوسيع (Multi-Select + Exclude + Auto-Bypass)
        // =========================================================================
        when (selectedEntity) {
            DynamicEntityType.FAMILIES -> {
                item {
                    GlassGroupHeader(
                        title = "مكان الإقامة والنطاق الجغرافي",
                        icon = Icons.Rounded.Public,
                        accentColor = Color(0xFF38BDF8)
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = if (isLocalityLocked && !lockedLocalityName.isNullOrBlank()) {
                            "مكان الإقامة (مقيد: $lockedLocalityName)"
                        } else {
                            "مكان الإقامة"
                        },
                        icon = if (isLocalityLocked) Icons.Rounded.Lock else Icons.Rounded.LocationOn,
                        iconColor = Color(0xFF38BDF8),
                        options = residenceLocationOptions,
                        filterState = localityFilter,
                        isLocked = isLocalityLocked,
                        initiallyExpanded = isLocalityLocked,
                        onToggleOption = viewModel::toggleLocalityValue,
                        onExcludeChange = viewModel::setLocalityExclude,
                        onClearSelection = viewModel::clearLocalityFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "المنطقة الرئيسية / المحافظة",
                        icon = Icons.Rounded.Map,
                        iconColor = Color(0xFF0EA5E9),
                        options = filterOptions.currentMainAreas,
                        filterState = currentMainAreaFilter,
                        onToggleOption = viewModel::toggleCurrentMainAreaValue,
                        onExcludeChange = viewModel::setCurrentMainAreaExclude,
                        onClearSelection = viewModel::clearCurrentMainAreaFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "المنطقة الفرعية / الحي",
                        icon = Icons.Rounded.Place,
                        iconColor = Color(0xFF22D3EE),
                        options = currentSubAreaOptions,
                        filterState = currentSubAreaFilter,
                        onToggleOption = viewModel::toggleCurrentSubAreaValue,
                        onExcludeChange = viewModel::setCurrentSubAreaExclude,
                        onClearSelection = viewModel::clearCurrentSubAreaFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = if (isBranchLocked && !lockedBranchName.isNullOrBlank()) {
                            "الشعبة الميدانية (مقيد: $lockedBranchName)"
                        } else {
                            "الشعبة الميدانية"
                        },
                        icon = if (isBranchLocked) Icons.Rounded.Lock else Icons.Rounded.AccountTree,
                        iconColor = Color(0xFFA78BFA),
                        options = allowedBranches,
                        filterState = branchFilter,
                        isLocked = isBranchLocked,
                        initiallyExpanded = isBranchLocked,
                        onToggleOption = viewModel::toggleBranchValue,
                        onExcludeChange = viewModel::setBranchExclude,
                        onClearSelection = viewModel::clearBranchFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "صفة الإقامة",
                        icon = Icons.Rounded.Badge,
                        iconColor = Color(0xFF60A5FA),
                        options = residentStatusOptions,
                        filterState = residentFilter,
                        onToggleOption = viewModel::toggleResidentValue,
                        onExcludeChange = viewModel::setResidentExclude,
                        onClearSelection = viewModel::clearResidentFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "مركز الإيواء / المخيم",
                        icon = Icons.Rounded.Apartment,
                        iconColor = Color(0xFF2DD4BF),
                        options = filterOptions.shelterCenterNames,
                        filterState = shelterCenterFilter,
                        onToggleOption = viewModel::toggleShelterCenterValue,
                        onExcludeChange = viewModel::setShelterCenterExclude,
                        onClearSelection = viewModel::clearShelterCenterFilter
                    )
                }

                item {
                    GlassGroupHeader(
                        title = "حالة الاعتماد والميدان",
                        icon = Icons.Rounded.Verified,
                        accentColor = Color(0xFF34D399)
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "حالة الاعتماد",
                        icon = Icons.Rounded.Verified,
                        iconColor = Color(0xFF34D399),
                        options = approvalStatusOptions,
                        filterState = approvalFilter,
                        onToggleOption = viewModel::toggleApprovalValue,
                        onExcludeChange = viewModel::setApprovalExclude,
                        onClearSelection = viewModel::clearApprovalFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "حالة اعتماد المحلية / المناطق",
                        icon = Icons.Rounded.VerifiedUser,
                        iconColor = Color(0xFF10B981),
                        options = filterOptions.localityApprovals,
                        filterState = localityApprovalFilter,
                        onToggleOption = viewModel::toggleLocalityApprovalValue,
                        onExcludeChange = viewModel::setLocalityApprovalExclude,
                        onClearSelection = viewModel::clearLocalityApprovalFilter
                    )
                }

                item {
                    GlassGroupHeader(
                        title = "الوضع الاجتماعي والأضرار والدخل",
                        icon = Icons.Rounded.Tune,
                        accentColor = Color(0xFFFBBF24)
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "حالة الإيواء والسكن",
                        icon = Icons.Rounded.NightShelter,
                        iconColor = Color(0xFF2DD4BF),
                        options = filterOptions.shelterStatuses,
                        filterState = shelterFilter,
                        onToggleOption = viewModel::toggleShelterValue,
                        onExcludeChange = viewModel::setShelterExclude,
                        onClearSelection = viewModel::clearShelterFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "تصنيف أضرار الحرب",
                        icon = Icons.Rounded.HomeWork,
                        iconColor = Color(0xFFF87171),
                        options = filterOptions.damageTypes,
                        filterState = damageFilter,
                        onToggleOption = viewModel::toggleDamageValue,
                        onExcludeChange = viewModel::setDamageExclude,
                        onClearSelection = viewModel::clearDamageFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "الحالة الاجتماعية لرب الأسرة",
                        icon = Icons.Rounded.Diversity3,
                        iconColor = Color(0xFFF472B6),
                        options = maritalStatusOptions,
                        filterState = maritalFilter,
                        onToggleOption = viewModel::toggleMaritalValue,
                        onExcludeChange = viewModel::setMaritalExclude,
                        onClearSelection = viewModel::clearMaritalFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "حالة الإصابة الصحية",
                        icon = Icons.Rounded.MedicalServices,
                        iconColor = Color(0xFFFB7185),
                        options = filterOptions.injuryStatuses,
                        filterState = injuryFilter,
                        onToggleOption = viewModel::toggleInjuryValue,
                        onExcludeChange = viewModel::setInjuryExclude,
                        onClearSelection = viewModel::clearInjuryFilter
                    )
                }

                item {
                    val workAndIncomeOptions = remember(filterOptions) {
                        (filterOptions.worksApprovals + filterOptions.incomeSources)
                            .map { it.trim() }
                            .filter { it.isNotBlank() }
                            .distinct()
                            .sorted()
                    }
                    ExpandableGlassMultiFilterCard(
                        title = "اعتماد الأشغال وطبيعة العمل والدخل",
                        icon = Icons.Rounded.Work,
                        iconColor = Color(0xFFFBBF24),
                        options = workAndIncomeOptions,
                        filterState = worksFilter,
                        onToggleOption = viewModel::toggleWorksValue,
                        onExcludeChange = viewModel::setWorksExclude,
                        onClearSelection = viewModel::clearWorksFilter
                    )
                }

                item {
                    ExpandableGlassMembersRangeCard(
                        state = membersRangeFilter,
                        onToggleEnable = viewModel::setMembersRangeEnabled,
                        onExcludeChange = viewModel::setMembersRangeExclude,
                        onRangeChange = viewModel::setMembersRangeBounds
                    )
                }
            }

            DynamicEntityType.PROJECTS -> {
                item {
                    ExpandableGlassMultiFilterCard(
                        title = if (isLocalityLocked && !lockedLocalityName.isNullOrBlank()) {
                            "مكان الإقامة / النطاق الجغرافي للمشروع (مقيد: $lockedLocalityName)"
                        } else {
                            "مكان الإقامة / النطاق الجغرافي للمشروع"
                        },
                        icon = if (isLocalityLocked) Icons.Rounded.Lock else Icons.Rounded.LocationOn,
                        iconColor = Color(0xFF38BDF8),
                        options = residenceLocationOptions,
                        filterState = projectLocalityFilter,
                        isLocked = isLocalityLocked,
                        initiallyExpanded = isLocalityLocked,
                        onToggleOption = viewModel::toggleProjectLocalityValue,
                        onExcludeChange = viewModel::setProjectLocalityExclude,
                        onClearSelection = viewModel::clearProjectLocalityFilter
                    )
                }

                item {
                    val statusLabels = remember(filterOptions.projectActiveStates) {
                        filterOptions.projectActiveStates.map {
                            if (it) DynamicExportViewModel.PROJECT_STATUS_ACTIVE_LABEL
                            else DynamicExportViewModel.PROJECT_STATUS_ARCHIVED_LABEL
                        }.distinct()
                    }
                    ExpandableGlassMultiFilterCard(
                        title = "حالة نشاط المشروع",
                        icon = Icons.Rounded.ToggleOn,
                        iconColor = Color(0xFF34D399),
                        options = statusLabels,
                        filterState = projectStatusFilter,
                        onToggleOption = viewModel::toggleProjectStatusValue,
                        onExcludeChange = viewModel::setProjectStatusExclude,
                        onClearSelection = viewModel::clearProjectStatusFilter
                    )
                }

                item {
                    val aidTypeNames = remember(filterOptions.projectAidTypes) {
                        filterOptions.projectAidTypes.map { it.aidTypeName.trim() }.filter { it.isNotBlank() }.distinct()
                    }
                    ExpandableGlassMultiFilterCard(
                        title = "نوع المعونة / التصنيف",
                        icon = Icons.Rounded.Category,
                        iconColor = Color(0xFFFB923C),
                        options = aidTypeNames,
                        filterState = projectAidTypeFilter,
                        onToggleOption = viewModel::toggleProjectAidTypeValue,
                        onExcludeChange = viewModel::setProjectAidTypeExclude,
                        onClearSelection = viewModel::clearProjectAidTypeFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "الجهة الممولة / الداعمة",
                        icon = Icons.Rounded.VolunteerActivism,
                        iconColor = Color(0xFF38BDF8),
                        options = filterOptions.projectFunders,
                        filterState = projectFunderFilter,
                        onToggleOption = viewModel::toggleProjectFunderValue,
                        onExcludeChange = viewModel::setProjectFunderExclude,
                        onClearSelection = viewModel::clearProjectFunderFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "المستودع / نقطة التنفيذ",
                        icon = Icons.Rounded.Warehouse,
                        iconColor = Color(0xFFC084FC),
                        options = filterOptions.projectWarehouses,
                        filterState = projectWarehouseFilter,
                        onToggleOption = viewModel::toggleProjectWarehouseValue,
                        onExcludeChange = viewModel::setProjectWarehouseExclude,
                        onClearSelection = viewModel::clearProjectWarehouseFilter
                    )
                }
            }

            DynamicEntityType.CHILDREN -> {
                item {
                    ExpandableGlassMultiFilterCard(
                        title = if (isLocalityLocked && !lockedLocalityName.isNullOrBlank()) {
                            "مكان الإقامة للأبناء (مقيد: $lockedLocalityName)"
                        } else {
                            "مكان الإقامة"
                        },
                        icon = if (isLocalityLocked) Icons.Rounded.Lock else Icons.Rounded.LocationOn,
                        iconColor = Color(0xFF38BDF8),
                        options = residenceLocationOptions,
                        filterState = childLocalityFilter,
                        isLocked = isLocalityLocked,
                        initiallyExpanded = isLocalityLocked,
                        onToggleOption = viewModel::toggleChildLocalityValue,
                        onExcludeChange = viewModel::setChildLocalityExclude,
                        onClearSelection = viewModel::clearChildLocalityFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "المنطقة الفرعية للأبناء",
                        icon = Icons.Rounded.Place,
                        iconColor = Color(0xFF22D3EE),
                        options = currentSubAreaOptions,
                        filterState = childSubAreaFilter,
                        onToggleOption = viewModel::toggleChildSubAreaValue,
                        onExcludeChange = viewModel::setChildSubAreaExclude,
                        onClearSelection = viewModel::clearChildSubAreaFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "جنس الطفل / التابع",
                        icon = Icons.Rounded.Face,
                        iconColor = Color(0xFFF472B6),
                        options = filterOptions.childGenders,
                        filterState = childGenderFilter,
                        onToggleOption = viewModel::toggleChildGenderValue,
                        onExcludeChange = viewModel::setChildGenderExclude,
                        onClearSelection = viewModel::clearChildGenderFilter
                    )
                }

                item {
                    ExpandableGlassMultiFilterCard(
                        title = "حالة إيواء الطفل",
                        icon = Icons.Rounded.Home,
                        iconColor = Color(0xFF2DD4BF),
                        options = filterOptions.childShelterStatuses,
                        filterState = childShelterFilter,
                        onToggleOption = viewModel::toggleChildShelterValue,
                        onExcludeChange = viewModel::setChildShelterExclude,
                        onClearSelection = viewModel::clearChildShelterFilter
                    )
                }
            }
        }

        // =========================================================================
        // 3. بطاقة تخصيص الأعمدة (قابلة للطي والتوسيع)
        // =========================================================================
        if (canExportExcel || canExportPdf) {
            item {
                ExpandableColumnsGlassCard(
                    selectedEntity = selectedEntity,
                    selectedColumnKeys = selectedColumnKeys,
                    onToggleColumn = viewModel::toggleColumnKey,
                    onSelectAll = viewModel::selectAllColumns,
                    onSelectDefault = viewModel::selectDefaultColumns,
                    onClearAll = viewModel::clearAllColumns
                )
            }

            // =====================================================================
            // 4. أزرار التصدير البارزة بتدرج لوني (أخضر للإكسل • أحمر للـ PDF)
            // =====================================================================
            item {
                GlassSectionCard(
                    title = "إصدار وتصدير التقرير النهائي",
                    subtitle = "تصدير كافة الـ $totalMatchingCount سجل المطابقة بالأعمدة المختارة",
                    icon = Icons.Rounded.CloudDownload,
                    iconColor = Color(0xFF34D399)
                ) {
                    if (isExporting) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            LinearProgressIndicator(
                                progress = { exportProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = Color(0xFF34D399),
                                trackColor = Color.White.copy(alpha = 0.15f)
                            )
                            Text(
                                text = "جارِ معالجة وحفظ التقرير (${(exportProgress * 100).toInt()}%)...",
                                color = Color(0xFFA7F3D0),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    if (canExportExcel) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(GlassSubtleBg)
                                .padding(4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(
                                DynamicExportFormat.EXCEL_XLSX to "إكسل منسق (.xlsx)",
                                DynamicExportFormat.EXCEL_CSV to "إكسل فائق السرعة (.csv)"
                            ).forEach { (fmt, fmtTitle) ->
                                val selected = selectedExcelFormat == fmt
                                Surface(
                                    onClick = { viewModel.setExcelFormat(fmt) },
                                    shape = RoundedCornerShape(9.dp),
                                    color = if (selected) Color(0xFF10B981).copy(alpha = 0.28f) else Color.Transparent,
                                    border = if (selected) BorderStroke(1.dp, Color(0xFF34D399).copy(alpha = 0.7f)) else null,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = fmtTitle,
                                        color = if (selected) Color.White else Color.White.copy(alpha = 0.72f),
                                        fontSize = 10.5.sp,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(vertical = 7.dp, horizontal = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    val exportEnabled = !isExporting && totalMatchingCount > 0 && selectedColumnKeys.isNotEmpty()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (canExportExcel) {
                            GradientExportButton(
                                label = "تصدير ملفات الإكسل",
                                subLabel = if (selectedExcelFormat == DynamicExportFormat.EXCEL_XLSX) {
                                    "Cursor Streaming • .xlsx"
                                } else {
                                    "Cursor Streaming • .csv"
                                },
                                icon = Icons.Rounded.TableChart,
                                gradient = ExcelGradient,
                                enabled = exportEnabled,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                    val fileName = "${buildFilePrefix(selectedEntity)}_$ts.${selectedExcelFormat.extension}"
                                    if (selectedExcelFormat == DynamicExportFormat.EXCEL_XLSX) {
                                        xlsxExportLauncher.launch(fileName)
                                    } else {
                                        csvExportLauncher.launch(fileName)
                                    }
                                }
                            )
                        }

                        if (canExportPdf) {
                            GradientExportButton(
                                label = "تصدير PDF",
                                subLabel = "مستند A4 رسمي",
                                icon = Icons.Rounded.PictureAsPdf,
                                gradient = PdfGradient,
                                enabled = exportEnabled,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                    pdfExportLauncher.launch("${buildFilePrefix(selectedEntity)}_$ts.pdf")
                                }
                            )
                        }
                    }

                    if (selectedColumnKeys.isEmpty()) {
                        Text(
                            text = "⚠️ يرجى تحديد عمود واحد على الأقل لتفعيل أزرار التصدير.",
                            color = Color(0xFFFCD34D),
                            fontSize = 11.sp
                        )
                    }

                    if (!exportStatusMessage.isNullOrBlank()) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = exportStatusMessage!!,
                                color = Color.White,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }
        }

        // =========================================================================
        // 5. المعاينة الحية الفورية (LIMIT 50)
        // =========================================================================
        item {
            GlassSectionCard(
                title = "المعاينة الحية للبيانات (LIMIT 50)",
                subtitle = "إجمالي السجلات المطابقة: $totalMatchingCount سجل",
                icon = Icons.Rounded.Preview,
                iconColor = Color(0xFF38BDF8)
            ) {
                if (isLoadingPreview) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                            color = Color(0xFF34D399)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "جارِ تنفيذ الاستعلام الديناميكي...",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 12.sp
                        )
                    }
                } else if (totalMatchingCount == 0) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFFEF4444).copy(alpha = 0.16f),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5).copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.SearchOff,
                                contentDescription = null,
                                tint = Color(0xFFFCA5A5)
                            )
                            Text(
                                text = "لا توجد سجلات مطابقة للشروط الحالية. قم بتعديل الفلاتر أو مسح التحديد للتجاوز التلقائي.",
                                color = Color.White,
                                fontSize = 11.sp
                            )
                        }
                    }
                } else {
                    val horizontalScroll = rememberScrollState()
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                            .verticalScroll(rememberScrollState())
                            .horizontalScroll(horizontalScroll)
                    ) {
                        when (selectedEntity) {
                            DynamicEntityType.FAMILIES -> {
                                PreviewHeaderRow(
                                    cells = listOf(
                                        "الاسم" to 155.dp,
                                        "الهوية" to 95.dp,
                                        "مكان الإقامة" to 145.dp,
                                        "الشعبة" to 95.dp,
                                        "صفة الإقامة" to 80.dp,
                                        "الأفراد" to 55.dp,
                                        "الضرر" to 105.dp,
                                        "الاعتماد الحكومي" to 95.dp
                                    )
                                )
                                previewFamilies.forEachIndexed { idx, fam ->
                                    val residencePlace = listOf(fam.currentMainArea, fam.currentSubArea)
                                        .map { it.trim() }
                                        .filter { it.isNotBlank() }
                                        .distinct()
                                        .joinToString(" - ")
                                        .ifBlank { "-" }
                                    PreviewDataRow(
                                        isEven = idx % 2 == 0,
                                        cells = listOf(
                                            fam.name to 155.dp,
                                            fam.nationalID to 95.dp,
                                            residencePlace to 145.dp,
                                            fam.currentBranch.ifBlank { "-" } to 95.dp,
                                            fam.residentStatus.ifBlank { "-" } to 80.dp,
                                            fam.familyMembersCount.toString() to 55.dp,
                                            fam.damageType to 105.dp,
                                            fam.developmentApproval to 95.dp
                                        )
                                    )
                                }
                            }
                            DynamicEntityType.PROJECTS -> {
                                PreviewHeaderRow(
                                    cells = listOf(
                                        "رقم المشروع" to 95.dp,
                                        "اسم المشروع" to 180.dp,
                                        "الجهة الممولة" to 130.dp,
                                        "المستودع" to 115.dp,
                                        "الحصة" to 65.dp,
                                        "الحالة" to 85.dp
                                    )
                                )
                                previewProjects.forEachIndexed { idx, prj ->
                                    PreviewDataRow(
                                        isEven = idx % 2 == 0,
                                        cells = listOf(
                                            prj.projectNumber to 95.dp,
                                            prj.projectName to 180.dp,
                                            prj.fundingInstitution to 130.dp,
                                            prj.warehouseName to 115.dp,
                                            prj.quantity.toString() to 65.dp,
                                            (if (prj.isActive) "نشط" else "مؤرشف") to 85.dp
                                        )
                                    )
                                }
                            }
                            DynamicEntityType.CHILDREN -> {
                                PreviewHeaderRow(
                                    cells = listOf(
                                        "اسم الطفل" to 170.dp,
                                        "هوية الطفل" to 100.dp,
                                        "هوية المعيل" to 100.dp,
                                        "الجنس" to 70.dp,
                                        "الإيواء" to 115.dp,
                                        "تاريخ الميلاد" to 95.dp
                                    )
                                )
                                previewChildren.forEachIndexed { idx, child ->
                                    PreviewDataRow(
                                        isEven = idx % 2 == 0,
                                        cells = listOf(
                                            child.childName to 170.dp,
                                            child.nationalID to 100.dp,
                                            child.familyNationalID to 100.dp,
                                            child.gender to 70.dp,
                                            child.shelterStatus to 115.dp,
                                            child.birthDate to 95.dp
                                        )
                                    )
                                }
                            }
                        }
                    }

                    Text(
                        text = "💡 تُعرض أول 50 نتيجة للمعاينة الفورية دون استهلاك الذاكرة. يشمل التصدير كامل الـ $totalMatchingCount سجل.",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun GlassGroupHeader(
    title: String,
    icon: ImageVector,
    accentColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 4.dp, bottom = 2.dp, start = 4.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(16.dp)
        )
        Text(
            text = title,
            color = accentColor,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp
        )
        HorizontalDivider(
            color = accentColor.copy(alpha = 0.28f),
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun GlassSectionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = GlassCardBg,
        border = BorderStroke(1.dp, GlassCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconColor.copy(alpha = 0.22f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(21.dp)
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp
                    )
                    Text(
                        text = subtitle,
                        color = Color.White.copy(alpha = 0.72f),
                        fontSize = 10.5.sp
                    )
                }
            }
            content()
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun ExpandableGlassMultiFilterCard(
    title: String,
    icon: ImageVector,
    iconColor: Color,
    options: List<String>,
    filterState: MultiSelectFilterState,
    isLocked: Boolean = false,
    initiallyExpanded: Boolean = false,
    onToggleOption: (String) -> Unit,
    onExcludeChange: (Boolean) -> Unit,
    onClearSelection: () -> Unit
) {
    var expanded by remember(initiallyExpanded) { mutableStateOf(initiallyExpanded) }
    val isActive = filterState.selected.isNotEmpty()

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = if (isActive) GlassCardActiveBg else GlassCardBg,
        border = BorderStroke(
            width = 1.dp,
            color = if (isActive && filterState.exclude) {
                Color(0xFFFCA5A5).copy(alpha = 0.7f)
            } else if (isActive) {
                iconColor.copy(alpha = 0.75f)
            } else {
                GlassCardBorder
            }
        ),
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = tween(durationMillis = 240))
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // صف رأس الفلتر القابل للضغط لطي/توسيع الخيارات
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(iconColor.copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = iconColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val summaryText = when {
                            isLocked -> "نطاق مقيد تلقائياً حسب الصلاحية"
                            filterState.selected.isEmpty() -> "متجاوز تلقائياً (الكل مشمول)"
                            filterState.exclude -> "استثناء (${filterState.selected.size}): ${filterState.selected.take(2).joinToString("، ")}"
                            else -> "محدد (${filterState.selected.size}): ${filterState.selected.take(2).joinToString("، ")}"
                        }
                        Text(
                            text = summaryText,
                            color = when {
                                filterState.exclude && isActive -> Color(0xFFFCA5A5)
                                isActive -> Color(0xFFA7F3D0)
                                else -> Color.White.copy(alpha = 0.65f)
                            },
                            fontSize = 10.5.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = when {
                            isLocked -> Color(0xFF38BDF8).copy(alpha = 0.22f)
                            isActive && filterState.exclude -> Color(0xFFEF4444).copy(alpha = 0.25f)
                            isActive -> iconColor.copy(alpha = 0.25f)
                            else -> Color.White.copy(alpha = 0.1f)
                        }
                    ) {
                        Text(
                            text = when {
                                isLocked -> "مقيد"
                                !isActive -> "الكل"
                                filterState.exclude -> "استثناء ${filterState.selected.size}"
                                else -> "${filterState.selected.size} محدد"
                            },
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    Icon(
                        imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                        contentDescription = if (expanded) "طي" else "توسيع",
                        tint = Color.White.copy(alpha = 0.85f)
                    )
                }
            }

            // محتوى البطاقة عند التوسيع
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HorizontalDivider(color = Color.White.copy(alpha = 0.18f))

                    // شريط التبديل: استثناء المحدد + زر مسح التحديد
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(GlassSubtleBg)
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FilterAltOff,
                                contentDescription = null,
                                tint = if (filterState.exclude) Color(0xFFFCA5A5) else Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = "استثناء المحدد",
                                    color = Color.White,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (filterState.exclude) "سيتم استبعاد العناصر المحددة من النتائج" else "سيتم تضمين العناصر المحددة فقط",
                                    color = Color.White.copy(alpha = 0.65f),
                                    fontSize = 9.5.sp
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (!isLocked && isActive) {
                                TextButton(
                                    onClick = onClearSelection,
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "مسح",
                                        color = Color(0xFFFBBF24),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Switch(
                                checked = filterState.exclude,
                                enabled = !isLocked,
                                onCheckedChange = onExcludeChange,
                                modifier = Modifier.scale(0.85f)
                            )
                        }
                    }

                    if (options.isEmpty()) {
                        Text(
                            text = "لا توجد قيم مسجلة في قاعدة البيانات لهذا الحقل.",
                            color = Color.White.copy(alpha = 0.6f),
                            fontSize = 11.sp,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            options.forEach { option ->
                                val isSelected = filterState.selected.any {
                                    it.trim().equals(option.trim(), ignoreCase = true)
                                }
                                val chipHighlightColor = if (filterState.exclude) {
                                    Color(0xFFEF4444)
                                } else {
                                    iconColor
                                }
                                FilterChip(
                                    selected = isSelected,
                                    enabled = !isLocked,
                                    onClick = { onToggleOption(option) },
                                    label = {
                                        Text(
                                            text = option,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    leadingIcon = if (isSelected) {
                                        {
                                            Icon(
                                                imageVector = if (filterState.exclude) Icons.Rounded.Close else Icons.Rounded.Check,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    } else null,
                                    colors = FilterChipDefaults.filterChipColors(
                                        containerColor = Color.White.copy(alpha = 0.08f),
                                        labelColor = Color.White.copy(alpha = 0.9f),
                                        selectedContainerColor = chipHighlightColor.copy(alpha = 0.32f),
                                        selectedLabelColor = Color.White,
                                        selectedLeadingIconColor = Color.White,
                                        disabledContainerColor = Color.White.copy(alpha = 0.14f),
                                        disabledLabelColor = Color.White,
                                        disabledSelectedContainerColor = iconColor.copy(alpha = 0.28f),
                                        disabledLeadingIconColor = Color.White
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = !isLocked,
                                        selected = isSelected,
                                        borderColor = Color.White.copy(alpha = 0.3f),
                                        selectedBorderColor = chipHighlightColor,
                                        borderWidth = 1.dp,
                                        selectedBorderWidth = 1.2.dp
                                    ),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpandableGlassMembersRangeCard(
    state: MembersRangeFilterState,
    onToggleEnable: (Boolean) -> Unit,
    onExcludeChange: (Boolean) -> Unit,
    onRangeChange: (Int, Int) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = if (state.enabled) GlassCardActiveBg else GlassCardBg,
        border = BorderStroke(
            width = 1.dp,
            color = if (state.enabled) Color(0xFF818CF8).copy(alpha = 0.75f) else GlassCardBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = tween(durationMillis = 240))
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF818CF8).copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Groups,
                            contentDescription = null,
                            tint = Color(0xFF818CF8),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "نطاق عدد أفراد الأسرة",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = if (!state.enabled) {
                                "متجاوز تلقائياً (كافة الأحجام مشمولة)"
                            } else if (state.exclude) {
                                "استثناء الأسر من ${state.minMembers} إلى ${state.maxMembers} أفراد"
                            } else {
                                "من ${state.minMembers} إلى ${state.maxMembers} أفراد"
                            },
                            color = if (state.enabled) Color(0xFFA7F3D0) else Color.White.copy(alpha = 0.65f),
                            fontSize = 10.5.sp
                        )
                    }
                }
                Icon(
                    imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.85f)
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HorizontalDivider(color = Color.White.copy(alpha = 0.18f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("تفعيل فلتر عدد الأفراد", color = Color.White, fontSize = 12.sp)
                        Switch(
                            checked = state.enabled,
                            onCheckedChange = onToggleEnable,
                            modifier = Modifier.scale(0.85f)
                        )
                    }

                    if (state.enabled) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("استثناء النطاق المحدد", color = Color(0xFFFCA5A5), fontSize = 11.5.sp)
                            Switch(
                                checked = state.exclude,
                                onCheckedChange = onExcludeChange,
                                modifier = Modifier.scale(0.85f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = state.minMembers.toString(),
                                onValueChange = {
                                    val v = it.toIntOrNull() ?: 1
                                    onRangeChange(v, state.maxMembers)
                                },
                                label = { Text("الحد الأدنى", color = Color.White.copy(alpha = 0.8f)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color(0xFF818CF8),
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.35f)
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = state.maxMembers.toString(),
                                onValueChange = {
                                    val v = it.toIntOrNull() ?: state.minMembers
                                    onRangeChange(state.minMembers, v)
                                },
                                label = { Text("الحد الأقصى", color = Color.White.copy(alpha = 0.8f)) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    focusedBorderColor = Color(0xFF818CF8),
                                    unfocusedBorderColor = Color.White.copy(alpha = 0.35f)
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun ExpandableColumnsGlassCard(
    selectedEntity: DynamicEntityType,
    selectedColumnKeys: Set<String>,
    onToggleColumn: (String) -> Unit,
    onSelectAll: () -> Unit,
    onSelectDefault: () -> Unit,
    onClearAll: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val columns = remember(selectedEntity) {
        when (selectedEntity) {
            DynamicEntityType.FAMILIES -> ExportColumnRegistry.ALL_COLUMNS.map { it.key to it.label }
            DynamicEntityType.PROJECTS -> ProjectExportColumnRegistry.ALL_COLUMNS.map { it.key to it.label }
            DynamicEntityType.CHILDREN -> ChildExportColumnRegistry.ALL_COLUMNS.map { it.key to it.label }
        }
    }

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = GlassCardBg,
        border = BorderStroke(1.dp, GlassCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = tween(durationMillis = 240))
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF2DD4BF).copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ViewColumn,
                            contentDescription = null,
                            tint = Color(0xFF2DD4BF),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "تخصيص أعمدة التصدير",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "${selectedColumnKeys.size} من أصل ${columns.size} عمود محدد",
                            color = Color(0xFFA7F3D0),
                            fontSize = 10.5.sp
                        )
                    }
                }
                Icon(
                    imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.85f)
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HorizontalDivider(color = Color.White.copy(alpha = 0.18f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onSelectAll,
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("تحديد الكل", color = Color.White, fontSize = 10.5.sp)
                        }
                        OutlinedButton(
                            onClick = onSelectDefault,
                            border = BorderStroke(1.dp, Color(0xFF34D399).copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("الافتراضي", color = Color(0xFFA7F3D0), fontSize = 10.5.sp)
                        }
                        OutlinedButton(
                            onClick = onClearAll,
                            border = BorderStroke(1.dp, Color(0xFFFCA5A5).copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء الكل", color = Color(0xFFFCA5A5), fontSize = 10.5.sp)
                        }
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        columns.forEach { (key, label) ->
                            val isSelected = selectedColumnKeys.contains(key)
                            FilterChip(
                                selected = isSelected,
                                onClick = { onToggleColumn(key) },
                                label = { Text(label, fontSize = 10.5.sp) },
                                leadingIcon = if (isSelected) {
                                    {
                                        Icon(
                                            imageVector = Icons.Rounded.Check,
                                            contentDescription = null,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    }
                                } else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = Color.White.copy(alpha = 0.08f),
                                    labelColor = Color.White.copy(alpha = 0.85f),
                                    selectedContainerColor = Color(0xFF10B981).copy(alpha = 0.3f),
                                    selectedLabelColor = Color.White,
                                    selectedLeadingIconColor = Color.White
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = Color.White.copy(alpha = 0.28f),
                                    selectedBorderColor = Color(0xFF34D399)
                                ),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GradientExportButton(
    label: String,
    subLabel: String,
    icon: ImageVector,
    gradient: Brush,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                brush = if (enabled) gradient else Brush.horizontalGradient(
                    listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.1f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = if (enabled) 0.45f else 0.18f), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color.White.copy(alpha = if (enabled) 1f else 0.45f),
                modifier = Modifier.size(22.dp)
            )
            Column {
                Text(
                    text = label,
                    color = Color.White.copy(alpha = if (enabled) 1f else 0.5f),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.5.sp,
                    maxLines = 1
                )
                Text(
                    text = subLabel,
                    color = Color.White.copy(alpha = if (enabled) 0.85f else 0.4f),
                    fontSize = 9.5.sp,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun PreviewHeaderRow(cells: List<Pair<String, androidx.compose.ui.unit.Dp>>) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.16f))
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        cells.forEach { (title, width) ->
            Text(
                text = title,
                color = Color(0xFFA7F3D0),
                fontWeight = FontWeight.Bold,
                fontSize = 10.5.sp,
                modifier = Modifier
                    .width(width)
                    .padding(horizontal = 4.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun PreviewDataRow(
    isEven: Boolean,
    cells: List<Pair<String, androidx.compose.ui.unit.Dp>>
) {
    Row(
        modifier = Modifier
            .background(if (isEven) Color.Transparent else Color.White.copy(alpha = 0.05f))
            .padding(horizontal = 8.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        cells.forEach { (value, width) ->
            Text(
                text = value.ifBlank { "-" },
                color = Color.White.copy(alpha = 0.92f),
                fontSize = 10.5.sp,
                modifier = Modifier
                    .width(width)
                    .padding(horizontal = 4.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
