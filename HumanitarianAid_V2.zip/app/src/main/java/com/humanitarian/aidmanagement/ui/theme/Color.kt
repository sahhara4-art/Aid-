package com.humanitarian.aidmanagement.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF1976D2)
val BluePrimaryDark = Color(0xFF0D47A1)
val BlueLight = Color(0xFFE3F2FD)

val GreenSecondary = Color(0xFF2E7D32)
val GreenSecondaryLight = Color(0xFFE8F5E9)

val Emerald600 = Color(0xFF059669)
val Slate900 = Color(0xFF0F172A)
val Slate700 = Color(0xFF334155)
val Slate500 = Color(0xFF64748B)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val RedError = Color(0xFFDC2626)
val AmberWarning = Color(0xFFD97706)
