package com.humanitarian.aidmanagement.ui.theme

import androidx.compose.ui.graphics.Color

// ==================== ألوان الهوية الوطنية الفلسطينية ====================
// ألوان العلم الفلسطيني الأربعة: الأخضر الزيتوني، الأحمر القاني، الأبيض الناصع، الأسود الفحمي
val PalestineGreen = Color(0xFF007A3D)        // الأخضر الفلسطيني الأصيل (رمز الأرض والزيتون)
val PalestineGreenDark = Color(0xFF005A2C)    // الأخضر الداكن
val PalestineGreenLight = Color(0xFFE8F5E9)   // أخضر فاتح جداً للخلفيات
val PalestineGreenContainer = Color(0xFFDCFCE7)

val PalestineRed = Color(0xFFCE1126)          // الأحمر القاني (رمز التضحية والصمود)
val PalestineRedDark = Color(0xFFA50E1E)      // أحمر داكن
val PalestineRedLight = Color(0xFFFEE2E2)     // أحمر فاتح للبطاقات التحذيرية
val PalestineRedContainer = Color(0xFFFFE4E6)

val PalestineBlack = Color(0xFF111827)        // الأسود الفحمي (رمز العزة والكرامة)
val PalestineWhite = Color(0xFFFFFFFF)        // الأبيض الناصع (رمز السلام والصفاء)

val PalestineGold = Color(0xFFD97706)         // الذهبي العتيق / زيت الزيتون الصافي
val PalestineGoldLight = Color(0xFFFEF3C7)

// درجات الرمادي الفاتح الحديث (Light Theme Palette)
val SlateBackground = Color(0xFFF8FAFC)      // خلفية التطبيق الفاتحة والمريحة للعين
val SlateSurface = Color(0xFFFFFFFF)         // سطح البطاقات ناصع البياض
val SlateSurfaceVariant = Color(0xFFF1F5F9)  // الحاويات الداخلية الفاتحة
val SlateBorder = Color(0xFFE2E8F0)          // حدود البطاقات
val SlateBorderSubtle = Color(0xFFCBD5E1)

val SlateTextPrimary = Color(0xFF0F172A)     // النص الأساسي عالي التباين
val SlateTextSecondary = Color(0xFF475569)   // النص الثانوي
val SlateTextMuted = Color(0xFF64748B)       // النصوص الإرشادية والتاريخ

// ألوان تكميلية للعمليات
val SkyBlue = Color(0xFF0284C7)
val SkyBlueLight = Color(0xFFE0F2FE)
val AmberWarning = Color(0xFFF59E0B)
val EmeraldSuccess = Color(0xFF10B981)
val RoseDanger = Color(0xFFF43F5E)

// ==================== ألوان الحالات الدلالية (Semantic Status Colors) ====================
val StatusSuccess = Color(0xFF10B981)          // أخضر هادئ للنجاح والاعتماد
val StatusSuccessBg = Color(0xFFECFDF5)        // خلفية خفيفة للنجاح
val StatusSuccessBorder = Color(0xFFA7F3D0)

val StatusWarning = Color(0xFFF59E0B)          // كهرماني دافئ للتحذير والانتظار
val StatusWarningBg = Color(0xFFFFFBEB)
val StatusWarningBorder = Color(0xFFFDE68A)

val StatusError = Color(0xFFEF4444)            // أحمر ناعم للخطأ والاستبعاد
val StatusErrorBg = Color(0xFFFEF2F2)
val StatusErrorBorder = Color(0xFFFECACA)

val StatusInfo = Color(0xFF0284C7)             // أزرق سماوي للمعلومات
val StatusInfoBg = Color(0xFFF0F9FF)
val StatusInfoBorder = Color(0xFFBAE6FD)

val StatusNominated = Color(0xFFD97706)        // ذهبي/كهرماني مميز لحالة "مرشح"
val StatusNominatedBg = Color(0xFFFEF3C7)
val StatusNominatedBorder = Color(0xFFFCD34D)

val StatusMigrated = Color(0xFF059669)         // زمردي ناصع لحالة "مرحل / معتمد"
val StatusMigratedBg = Color(0xFFD1FAE5)
val StatusMigratedBorder = Color(0xFF6EE7B7)

val StatusDelivered = Color(0xFF007A3D)        // أخضر وطني لحالة "مستلم"
val StatusDeliveredBg = Color(0xFFDCFCE7)
val StatusDeliveredBorder = Color(0xFF86EFAC)

// ==================== ألوان تأثير الزجاج العاكس (Glassmorphism Palette) ====================
val GlassSurfaceLight = Color(0xE6FFFFFF)      // 90% شفافية للأسطح الزجاجية الرئيسية
val GlassSurfaceSubtle = Color(0xB3FFFFFF)     // 70% شفافية للبطاقات الداخلية
val GlassSurfaceOverlay = Color(0x66FFFFFF)    // 40% تراكب خفيف

val GlassBorderLight = Color(0xCCFFFFFF)       // لمعة بيضاء حادة للحافة العاكسة
val GlassBorderSubtle = Color(0x4DE2E8F0)      // حدود زجاجية ناعمة
val GlassBorderHighlight = Color(0x80FFFFFF)   // حافة عاكسة علوية

val GlassGreen = Color(0x1A007A3D)             // مسحة خضراء زجاجية
val GlassAmber = Color(0x1FD97706)             // مسحة ذهبية زجاجية
val GlassBlue = Color(0x1F0284C7)              // مسحة زرقاء زجاجية
val GlassRed = Color(0x1ACE1126)               // مسحة حمراء زجاجية

