package com.humanitarian.aidmanagement.ui.screens.families

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.calculateAgeFromBirthDate
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.ExcelParserHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Locale

/**
 * ViewModel شامل لإدارة كافة حقول نموذج إضافة أسرة جديدة
 * مع التحقق الفوري، العزل الجغرافي الصارم (RLS)، والتنفيذ غير المتزامن على Dispatchers.IO
 */
class AddFamilyViewModel(
    private val repository: AidRepository
) : ViewModel() {

    data class FormState(
        // 1. البيانات الأساسية ورب الأسرة
        val name: String = "",
        val nationalID: String = "",
        val birthDate: String = "1985-01-01",
        val gender: String = "ذكر",
        val maritalStatus: String = "متزوج",
        val deathStatus: String = "على قيد الحياة",
        val deathDate: String = "",

        // 2. بيانات الأسرة والزوج/الزوجة والمؤن
        val familyMembersCount: String = "5",
        val rationCardNumber: String = "",
        val wifeName: String = "",
        val wifeNationalID: String = "",

        // 3. بيانات التواصل والاتصال
        val primaryPhone: String = "",
        val alternativePhone1: String = "",
        val alternativePhone2: String = "",

        // 4. السكن والموقع الجغرافي والإيواء
        val selectedLocalityId: Int = 1,
        val currentMainArea: String = "",
        val currentSubArea: String = "",
        val currentBranch: String = "",
        val currentMosque: String = "",
        val residentStatus: String = "نازح",
        val shelterStatus: String = "إيواء داخلي",
        val shelterCenterName: String = "",

        // 5. العنوان الأصلي قبل النزوح
        val originalMainArea: String = "",
        val originalSubArea: String = "",
        val originalBranch: String = "",
        val originalMosque: String = "",

        // 6. العمل والدخل والأضرار والإصابات
        val incomeSource1: String = "بلا عمل",
        val incomeSource2: String = "",
        val incomeDetails: String = "",
        val damageType: String = "أضرار كلية",
        val damageDescription: String = "",
        val injuryStatus: String = "سليم",
        val injuryDate: String = "",

        // 7. حالات الاعتماد الإداري والملاحظات
        val developmentApproval: String = "معتمد",
        val localityApproval: String = "معتمد",
        val worksApproval: String = "اعتماد أشغال",
        val notes: String = "",

        // أخطاء التحقق وحالة الحفظ
        val isSaving: Boolean = false,
        val saveSuccess: Boolean = false,
        val errorMessage: String? = null,
        val nameError: String? = null,
        val nationalIdError: String? = null,
        val wifeNationalIdError: String? = null,
        val phoneError: String? = null,
        val membersCountError: String? = null
    )

    private val _state = MutableStateFlow(FormState())
    val state: StateFlow<FormState> = _state.asStateFlow()

    private val _allowedLocalities = MutableStateFlow<List<LocalityEntity>>(emptyList())
    val allowedLocalities: StateFlow<List<LocalityEntity>> = _allowedLocalities.asStateFlow()

    private val _isLocalityLocked = MutableStateFlow(false)
    val isLocalityLocked: StateFlow<Boolean> = _isLocalityLocked.asStateFlow()

    private val _availableSubAreas = MutableStateFlow<List<String>>(emptyList())
    val availableSubAreas: StateFlow<List<String>> = _availableSubAreas.asStateFlow()

    private val _availableBranches = MutableStateFlow<List<String>>(emptyList())
    val availableBranches: StateFlow<List<String>> = _availableBranches.asStateFlow()

    private val _isBranchLocked = MutableStateFlow(false)
    val isBranchLocked: StateFlow<Boolean> = _isBranchLocked.asStateFlow()

    private val _lockedBranchName = MutableStateFlow<String?>(null)
    val lockedBranchName: StateFlow<String?> = _lockedBranchName.asStateFlow()

    private val _maritalOptions = MutableStateFlow(listOf("متزوج", "أعزب", "أرمل", "مطلق", "مهجور"))
    val maritalOptions: StateFlow<List<String>> = _maritalOptions.asStateFlow()

    private val _governorateOptions = MutableStateFlow(listOf("غزة", "شمال غزة", "الوسطى / دير البلح", "خانيونس", "رفح"))
    val governorateOptions: StateFlow<List<String>> = _governorateOptions.asStateFlow()

    private val _residentStatusOptions = MutableStateFlow(listOf("نازح", "مقيم", "عائد", "مستضاف"))
    val residentStatusOptions: StateFlow<List<String>> = _residentStatusOptions.asStateFlow()

    private val _shelterStatusOptions = MutableStateFlow(
        listOf("إيواء داخلي", "خارج الإيواء", "خيمة", "مركز إيواء حكومي", "مخيم نزوح", "منزل مضيف", "بيت مستأجر", "منزل متضرر")
    )
    val shelterStatusOptions: StateFlow<List<String>> = _shelterStatusOptions.asStateFlow()

    private val _damageTypeOptions = MutableStateFlow(
        listOf("أضرار كلية", "أضرار جزئية بليغة", "أضرار جزئية غير صالحة للسكن", "أضرار جزئية صالحة للسكن", "أضرار طفيفة", "بلا أضرار")
    )
    val damageTypeOptions: StateFlow<List<String>> = _damageTypeOptions.asStateFlow()

    private val _injuryStatusOptions = MutableStateFlow(listOf("سليم", "مصاب", "شهيد", "إعاقة دائمة", "مريض مزمن"))
    val injuryStatusOptions: StateFlow<List<String>> = _injuryStatusOptions.asStateFlow()

    private val _incomeSourceOptions = MutableStateFlow(
        listOf("بلا عمل", "لا يعمل", "عمال مياومة", "موظف حكومي", "موظف وكالة (الأونروا)", "أعمال حرة / تجارة", "متقاعد", "شؤون اجتماعية")
    )
    val incomeSourceOptions: StateFlow<List<String>> = _incomeSourceOptions.asStateFlow()

    private val _developmentApprovalOptions = MutableStateFlow(listOf("معتمد", "مجمد", "حجب اعتماد", "قيد المراجعة"))
    val developmentApprovalOptions: StateFlow<List<String>> = _developmentApprovalOptions.asStateFlow()

    private val _localityApprovalOptions = MutableStateFlow(listOf("معتمد", "قيد التدقيق", "مرفوض"))
    val localityApprovalOptions: StateFlow<List<String>> = _localityApprovalOptions.asStateFlow()

    private val _worksApprovalOptions = MutableStateFlow(listOf("اعتماد أشغال", "قيد التدقيق", "غير معتمد"))
    val worksApprovalOptions: StateFlow<List<String>> = _worksApprovalOptions.asStateFlow()

    init {
        loadGeographicalScope()
        loadDynamicFieldOptions()
        viewModelScope.launch {
            repository.currentUserFlow.drop(1).collect {
                loadGeographicalScope()
                loadDynamicFieldOptions()
            }
        }
    }

    private fun mergeOptions(dbValues: List<String>, defaults: List<String>): List<String> =
        (dbValues.map { it.trim() }.filter { it.isNotBlank() } + defaults).distinct()

    private fun loadDynamicFieldOptions() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val opts = repository.getDynamicExportFilterOptions()
                _maritalOptions.value = mergeOptions(opts.maritalStatuses, listOf("متزوج", "أعزب", "أرمل", "مطلق", "مهجور"))
                _governorateOptions.value = mergeOptions(opts.currentMainAreas, listOf("غزة", "شمال غزة", "الوسطى / دير البلح", "خانيونس", "رفح"))
                _residentStatusOptions.value = mergeOptions(opts.residentStatuses, listOf("نازح", "مقيم", "عائد", "مستضاف"))
                _shelterStatusOptions.value = mergeOptions(
                    opts.shelterStatuses,
                    listOf("إيواء داخلي", "خارج الإيواء", "خيمة", "مركز إيواء حكومي", "مخيم نزوح", "منزل مضيف", "بيت مستأجر", "منزل متضرر")
                )
                _damageTypeOptions.value = mergeOptions(
                    opts.damageTypes,
                    listOf("أضرار كلية", "أضرار جزئية بليغة", "أضرار جزئية غير صالحة للسكن", "أضرار جزئية صالحة للسكن", "أضرار طفيفة", "بلا أضرار")
                )
                _injuryStatusOptions.value = mergeOptions(opts.injuryStatuses, listOf("سليم", "مصاب", "شهيد", "إعاقة دائمة", "مريض مزمن"))
                _incomeSourceOptions.value = mergeOptions(
                    opts.incomeSources,
                    listOf("بلا عمل", "لا يعمل", "عمال مياومة", "موظف حكومي", "موظف وكالة (الأونروا)", "أعمال حرة / تجارة", "متقاعد", "شؤون اجتماعية")
                )
                _developmentApprovalOptions.value = mergeOptions(opts.approvals, listOf("معتمد", "مجمد", "حجب اعتماد", "قيد المراجعة"))
                _localityApprovalOptions.value = mergeOptions(opts.localityApprovals, listOf("معتمد", "قيد التدقيق", "مرفوض"))
                _worksApprovalOptions.value = mergeOptions(opts.worksApprovals, listOf("اعتماد أشغال", "قيد التدقيق", "غير معتمد"))
            } catch (_: Exception) {
            }
        }
    }

    private fun loadGeographicalScope() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val locs = repository.getAllowedLocalitiesSync()
                val currentUser = repository.getCurrentUser()
                val isRestricted = !repository.isSuperAdmin() &&
                    ((currentUser?.AllowedLocalityID ?: 0) != 0 || locs.size == 1)

                _allowedLocalities.value = locs
                _isLocalityLocked.value = isRestricted && locs.size <= 1

                val currentSel = _state.value.selectedLocalityId
                val validSelected = locs.firstOrNull { it.LocalityID == currentSel } ?: locs.firstOrNull()
                if (validSelected != null) {
                    _state.update { s ->
                        s.copy(
                            selectedLocalityId = validSelected.LocalityID,
                            currentMainArea = s.currentMainArea.ifBlank { validSelected.LocalityName }
                        )
                    }
                    loadLocalityDetails(validSelected.LocalityID, validSelected.LocalityName)
                } else {
                    loadBranchRestrictionsOnly()
                }
            } catch (_: Exception) {
            }
        }
    }

    private suspend fun loadLocalityDetails(localityId: Int, localityName: String) {
        val subAreas = repository.getSubAreasByLocality(localityId)
        _availableSubAreas.value = subAreas

        val branches = repository.getDistinctBranchesForLocality(localityName)
        val (ignoreBr, allowedBranches) = repository.getEffectiveBranchScope()
        val validAllowedBranches = allowedBranches.filter { it != "__DENY__" && it != "__ALL__" }

        if (ignoreBr == 0 && validAllowedBranches.isNotEmpty()) {
            val merged = (branches + validAllowedBranches).distinct().sorted()
            _availableBranches.value = merged
            if (validAllowedBranches.size == 1) {
                val singleBranch = validAllowedBranches.first()
                _isBranchLocked.value = true
                _lockedBranchName.value = singleBranch
                _state.update { it.copy(currentBranch = singleBranch) }
            } else {
                _isBranchLocked.value = false
                _lockedBranchName.value = null
                val cur = _state.value.currentBranch
                if (cur.isBlank() || validAllowedBranches.none { it.equals(cur.trim(), ignoreCase = true) }) {
                    _state.update { it.copy(currentBranch = validAllowedBranches.first()) }
                }
            }
        } else {
            _isBranchLocked.value = false
            _lockedBranchName.value = null
            _availableBranches.value = branches
        }
    }

    private suspend fun loadBranchRestrictionsOnly() {
        val (ignoreBr, allowedBranches) = repository.getEffectiveBranchScope()
        val validAllowedBranches = allowedBranches.filter { it != "__DENY__" && it != "__ALL__" }
        if (ignoreBr == 0 && validAllowedBranches.size == 1) {
            val singleBranch = validAllowedBranches.first()
            _isBranchLocked.value = true
            _lockedBranchName.value = singleBranch
            _availableBranches.value = listOf(singleBranch)
            _state.update { it.copy(currentBranch = singleBranch) }
        }
    }

    // دوال تحديث كافة الحقول
    fun onNameChange(v: String) = _state.update { it.copy(name = v, nameError = null, errorMessage = null) }
    fun onNationalIdChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() }.take(9)
        _state.update { it.copy(nationalID = cleaned, nationalIdError = null, errorMessage = null) }
    }
    fun onBirthDateChange(v: String) = _state.update { it.copy(birthDate = v) }
    fun onGenderChange(v: String) = _state.update { it.copy(gender = v) }
    fun onMaritalStatusChange(v: String) = _state.update { it.copy(maritalStatus = v) }
    fun onDeathStatusChange(v: String) = _state.update {
        it.copy(
            deathStatus = v,
            deathDate = if (v == "على قيد الحياة") "" else it.deathDate
        )
    }
    fun onDeathDateChange(v: String) = _state.update { it.copy(deathDate = v) }

    fun onFamilyMembersCountChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() }.take(2)
        _state.update { it.copy(familyMembersCount = cleaned, membersCountError = null) }
    }
    fun onRationCardNumberChange(v: String) = _state.update { it.copy(rationCardNumber = v) }
    fun onWifeNameChange(v: String) = _state.update { it.copy(wifeName = v) }
    fun onWifeNationalIdChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() }.take(9)
        _state.update { it.copy(wifeNationalID = cleaned, wifeNationalIdError = null) }
    }

    fun onPrimaryPhoneChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() || it == '+' }.take(15)
        _state.update { it.copy(primaryPhone = cleaned, phoneError = null) }
    }
    fun onAlternativePhone1Change(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() || it == '+' }.take(15)
        _state.update { it.copy(alternativePhone1 = cleaned) }
    }
    fun onAlternativePhone2Change(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() || it == '+' }.take(15)
        _state.update { it.copy(alternativePhone2 = cleaned) }
    }

    fun onLocalitySelected(locality: LocalityEntity) {
        if (_isLocalityLocked.value) return
        _state.update {
            it.copy(
                selectedLocalityId = locality.LocalityID,
                currentMainArea = it.currentMainArea.ifBlank { locality.LocalityName }
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                loadLocalityDetails(locality.LocalityID, locality.LocalityName)
            } catch (_: Exception) {
            }
        }
    }

    fun onCurrentMainAreaChange(v: String) = _state.update { it.copy(currentMainArea = v) }
    fun onCurrentSubAreaChange(v: String) = _state.update { it.copy(currentSubArea = v) }
    fun onCurrentBranchChange(v: String) {
        if (_isBranchLocked.value) return
        _state.update { it.copy(currentBranch = v) }
    }
    fun onCurrentMosqueChange(v: String) = _state.update { it.copy(currentMosque = v) }
    fun onResidentStatusChange(v: String) = _state.update { it.copy(residentStatus = v) }
    fun onShelterStatusChange(v: String) = _state.update { it.copy(shelterStatus = v) }
    fun onShelterCenterNameChange(v: String) = _state.update { it.copy(shelterCenterName = v) }

    fun onOriginalMainAreaChange(v: String) = _state.update { it.copy(originalMainArea = v) }
    fun onOriginalSubAreaChange(v: String) = _state.update { it.copy(originalSubArea = v) }
    fun onOriginalBranchChange(v: String) = _state.update { it.copy(originalBranch = v) }
    fun onOriginalMosqueChange(v: String) = _state.update { it.copy(originalMosque = v) }

    fun copyCurrentAddressToOriginal() {
        _state.update {
            it.copy(
                originalMainArea = it.currentMainArea,
                originalSubArea = it.currentSubArea,
                originalBranch = it.currentBranch,
                originalMosque = it.currentMosque
            )
        }
    }

    fun onIncomeSource1Change(v: String) = _state.update { it.copy(incomeSource1 = v) }
    fun onIncomeSource2Change(v: String) = _state.update { it.copy(incomeSource2 = v) }
    fun onIncomeDetailsChange(v: String) = _state.update { it.copy(incomeDetails = v) }
    fun onDamageTypeChange(v: String) = _state.update { it.copy(damageType = v) }
    fun onDamageDescriptionChange(v: String) = _state.update { it.copy(damageDescription = v) }
    fun onInjuryStatusChange(v: String) = _state.update {
        it.copy(
            injuryStatus = v,
            injuryDate = if (v == "سليم" || v == "لا يوجد") "" else it.injuryDate
        )
    }
    fun onInjuryDateChange(v: String) = _state.update { it.copy(injuryDate = v) }

    fun onDevelopmentApprovalChange(v: String) = _state.update { it.copy(developmentApproval = v) }
    fun onLocalityApprovalChange(v: String) = _state.update { it.copy(localityApproval = v) }
    fun onWorksApprovalChange(v: String) = _state.update { it.copy(worksApproval = v) }
    fun onNotesChange(v: String) = _state.update { it.copy(notes = v) }

    fun saveFamily(onSuccess: () -> Unit) {
        val current = _state.value
        val cleanName = current.name.trim()
        val cleanNationalId = ExcelParserHelper.normalizeNationalId(current.nationalID)
        val cleanWifeNationalId = ExcelParserHelper.normalizeNationalId(current.wifeNationalID)
        val cleanPhone = current.primaryPhone.trim()
        val parsedMembers = current.familyMembersCount.trim().toIntOrNull()

        var nameErr: String? = null
        var natErr: String? = null
        var wifeNatErr: String? = null
        var phoneErr: String? = null
        var membersErr: String? = null
        var hasError = false

        if (cleanName.length < 5) {
            nameErr = "يرجى كتابة الاسم الرباعي لرب الأسرة (5 أحرف على الأقل)"
            hasError = true
        }
        if (cleanNationalId.length != 9) {
            natErr = "رقم الهوية الوطنية يجب أن يتكون من 9 أرقام بالضبط"
            hasError = true
        }
        if (current.wifeNationalID.isNotBlank() && cleanWifeNationalId.length != 9) {
            wifeNatErr = "رقم هوية الزوج/الزوجة يجب أن يتكون من 9 أرقام"
            hasError = true
        }
        if (cleanPhone.filter { it.isDigit() }.length < 9) {
            phoneErr = "يرجى إدخال رقم جوال أساسي صحيح (9 أرقام على الأقل)"
            hasError = true
        }
        if (parsedMembers == null || parsedMembers <= 0) {
            membersErr = "عدد أفراد الأسرة يجب أن يكون 1 على الأقل"
            hasError = true
        }

        if (hasError) {
            _state.update {
                it.copy(
                    nameError = nameErr,
                    nationalIdError = natErr,
                    wifeNationalIdError = wifeNatErr,
                    phoneError = phoneErr,
                    membersCountError = membersErr,
                    errorMessage = "يرجى استكمال وتصحيح الحقول الإلزامية المميزة باللون الأحمر"
                )
            }
            return
        }

        if (!repository.canAddFamilyInLocality(current.selectedLocalityId)) {
            _state.update {
                it.copy(errorMessage = "غير مصرح لك بإضافة أسرة ضمن هذه المحلية وفق صلاحيات العزل الجغرافي")
            }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _state.update {
                it.copy(
                    isSaving = true,
                    errorMessage = null,
                    nameError = null,
                    nationalIdError = null,
                    wifeNationalIdError = null,
                    phoneError = null,
                    membersCountError = null
                )
            }
            try {
                val existing = repository.getFamilyByNationalId(cleanNationalId)
                if (existing != null) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            nationalIdError = "رقم الهوية مسجل مسبقاً باسم: ${existing.name}",
                            errorMessage = "رقم الهوية الوطنية ($cleanNationalId) مسجل مسبقاً في قاعدة البيانات"
                        )
                    }
                    return@launch
                }

                val effectiveLocalityName = _allowedLocalities.value
                    .firstOrNull { it.LocalityID == current.selectedLocalityId }
                    ?.LocalityName
                    .orEmpty()

                val lockedBranch = _lockedBranchName.value
                val effectiveBranch = if (_isBranchLocked.value && !lockedBranch.isNullOrBlank()) {
                    lockedBranch
                } else {
                    current.currentBranch.trim()
                }

                val cleanIncome1 = current.incomeSource1.trim()
                val cleanIncome2 = current.incomeSource2.trim()
                val cleanIncomeDetails = current.incomeDetails.trim()
                val resolvedIncome1 = cleanIncome1.ifBlank { cleanIncomeDetails }.ifBlank { "بلا عمل" }
                val resolvedIncome2 = cleanIncome2.ifBlank {
                    cleanIncomeDetails.takeIf { it.isNotBlank() && it != resolvedIncome1 }.orEmpty()
                }.ifBlank { null }

                val combinedNotes = listOfNotNull(
                    cleanIncomeDetails.takeIf { it.isNotBlank() && it != resolvedIncome1 && it != resolvedIncome2 }
                        ?.let { "مصادر الدخل: $it" },
                    current.notes.trim().takeIf { it.isNotBlank() }
                ).joinToString(" | ").ifBlank { null }

                val newFamily = FamilyEntity(
                    nationalID = cleanNationalId,
                    name = cleanName,
                    gender = current.gender.trim(),
                    date_of_birth = current.birthDate.trim().ifBlank { "1985-01-01" },
                    maritalStatus = current.maritalStatus.trim(),
                    deathStatus = current.deathStatus.trim(),
                    deathDate = current.deathDate.trim().ifBlank { null },
                    primary_phone = cleanPhone,
                    alternative_phone_1 = current.alternativePhone1.trim().ifBlank { null },
                    alternative_phone_2 = current.alternativePhone2.trim().ifBlank { null },
                    wifeName = current.wifeName.trim().ifBlank { null },
                    wifeNationalID = cleanWifeNationalId.ifBlank { null },
                    familyMembersCount = parsedMembers ?: 1,
                    damageType = current.damageType.trim(),
                    damageDescription = current.damageDescription.trim().ifBlank { null },
                    injuryStatus = current.injuryStatus.trim(),
                    injuryDate = current.injuryDate.trim().ifBlank { null },
                    incomeSource1 = resolvedIncome1,
                    income_source_2 = resolvedIncome2,
                    rationCardNumber = current.rationCardNumber.trim().ifBlank { null },
                    originalMainArea = current.originalMainArea.trim(),
                    originalSubArea = current.originalSubArea.trim(),
                    originalBranch = current.originalBranch.trim(),
                    originalMosque = current.originalMosque.trim(),
                    currentMainArea = current.currentMainArea.trim().ifBlank { effectiveLocalityName },
                    currentSubArea = current.currentSubArea.trim().ifBlank { effectiveLocalityName },
                    currentBranch = effectiveBranch,
                    currentMosque = current.currentMosque.trim(),
                    developmentApproval = current.developmentApproval.trim(),
                    localityApproval = current.localityApproval.trim(),
                    residentStatus = current.residentStatus.trim(),
                    worksApproval = current.worksApproval.trim(),
                    shelterStatus = current.shelterStatus.trim(),
                    shelter_center_name = current.shelterCenterName.trim().ifBlank { null },
                    notes = combinedNotes,
                    localityID = current.selectedLocalityId,
                    createdDate = System.currentTimeMillis(),
                    modifiedDate = null
                )

                repository.insertFamily(newFamily)

                withContext(Dispatchers.Main) {
                    _state.update { it.copy(isSaving = false, saveSuccess = true) }
                    onSuccess()
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            errorMessage = t.localizedMessage ?: "حدث خطأ غير متوقع أثناء حفظ بيانات الأسرة"
                        )
                    }
                }
            }
        }
    }

    /**
     * واجهة توافقية للإدخال المباشر على Dispatchers.IO
     */
    fun insertFamily(
        family: FamilyEntity,
        onSuccess: () -> Unit
    ) {
        val cleanNationalId = ExcelParserHelper.normalizeNationalId(family.nationalID)
        if (cleanNationalId.length != 9) {
            _state.update { it.copy(nationalIdError = "رقم الهوية الوطنية يجب أن يتكون من 9 أرقام") }
            return
        }
        if (family.name.trim().length < 5) {
            _state.update { it.copy(nameError = "يرجى كتابة الاسم الرباعي بشكل صحيح") }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(isSaving = true, errorMessage = null, nationalIdError = null, nameError = null) }
            try {
                val existing = repository.getFamilyByNationalId(cleanNationalId)
                if (existing != null) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            nationalIdError = "رقم الهوية مسجل مسبقاً باسم: ${existing.name}"
                        )
                    }
                    return@launch
                }
                val normalized = family.copy(
                    nationalID = cleanNationalId,
                    wifeNationalID = family.wifeNationalID?.let { ExcelParserHelper.normalizeNationalId(it) }?.ifBlank { null }
                )
                repository.insertFamily(normalized)
                withContext(Dispatchers.Main) {
                    _state.update { it.copy(isSaving = false, saveSuccess = true) }
                    onSuccess()
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            errorMessage = t.localizedMessage ?: "حدث خطأ أثناء حفظ الأسرة في قاعدة البيانات"
                        )
                    }
                }
            }
        }
    }

    fun clearState() {
        val locId = _allowedLocalities.value.firstOrNull()?.LocalityID ?: 1
        val locName = _allowedLocalities.value.firstOrNull()?.LocalityName.orEmpty()
        val lockedBranch = if (_isBranchLocked.value) _lockedBranchName.value.orEmpty() else ""
        _state.value = FormState(
            selectedLocalityId = locId,
            currentMainArea = locName,
            currentBranch = lockedBranch
        )
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AddFamilyViewModel(repository) as T
        }
    }
}

/**
 * شاشة إضافة أسرة جديدة بتصميم الزجاج المكسر الفاتح الهادئ (Light Glassmorphism)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFamilyScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    viewModel: AddFamilyViewModel = viewModel(factory = AddFamilyViewModel.Factory(repository))
) {
    val context = LocalContext.current
    val formState by viewModel.state.collectAsStateWithLifecycle()
    val allowedLocalities by viewModel.allowedLocalities.collectAsStateWithLifecycle()
    val isLocalityLocked by viewModel.isLocalityLocked.collectAsStateWithLifecycle()
    val availableSubAreas by viewModel.availableSubAreas.collectAsStateWithLifecycle()
    val availableBranches by viewModel.availableBranches.collectAsStateWithLifecycle()
    val isBranchLocked by viewModel.isBranchLocked.collectAsStateWithLifecycle()
    val lockedBranchName by viewModel.lockedBranchName.collectAsStateWithLifecycle()
    val maritalOptions by viewModel.maritalOptions.collectAsStateWithLifecycle()
    val governorateSuggestions by viewModel.governorateOptions.collectAsStateWithLifecycle()
    val residentStatusOptions by viewModel.residentStatusOptions.collectAsStateWithLifecycle()
    val shelterStatusOptions by viewModel.shelterStatusOptions.collectAsStateWithLifecycle()
    val damageTypeOptions by viewModel.damageTypeOptions.collectAsStateWithLifecycle()
    val injuryStatusOptions by viewModel.injuryStatusOptions.collectAsStateWithLifecycle()
    val incomeSourceOptions by viewModel.incomeSourceOptions.collectAsStateWithLifecycle()
    val developmentApprovalOptions by viewModel.developmentApprovalOptions.collectAsStateWithLifecycle()
    val localityApprovalOptions by viewModel.localityApprovalOptions.collectAsStateWithLifecycle()
    val worksApprovalOptions by viewModel.worksApprovalOptions.collectAsStateWithLifecycle()

    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val canAddFamily = remember(currentUser, allowedLocalities) {
        currentUser != null &&
            (repository.isSuperAdmin() || repository.hasPermission("families_create")) &&
            AccessControlManager.hasActionPermission(AccessControlManager.ACTION_ADD) &&
            allowedLocalities.isNotEmpty()
    }

    val listState = rememberLazyListState()
    val ageText = remember(formState.birthDate) {
        calculateAgeFromBirthDate(formState.birthDate).toString()
    }

    fun showDatePicker(currentValue: String, defaultYearsBack: Int = 35, onPicked: (String) -> Unit) {
        val calendar = Calendar.getInstance()
        val parts = currentValue.trim().split("-", "/")
        val initialYear = parts.getOrNull(0)?.toIntOrNull() ?: (calendar.get(Calendar.YEAR) - defaultYearsBack)
        val initialMonth = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val initialDay = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(
            context,
            { _, y, m, d ->
                onPicked(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d))
            },
            initialYear,
            initialMonth,
            initialDay
        ).show()
    }

    // خلفية فاتحة هادئة بتدرج زجاجي ناعم
    val lightBackdropBrush = remember {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFFEEF7F3),
                Color(0xFFF8FAFC),
                Color(0xFFEAF3FA)
            )
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(lightBackdropBrush)
        ) {
            // هالات ضوئية هادئة لتعزيز العمق الزجاجي الفاتح
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 70.dp, y = (-40).dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                PalestineGreen.copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = (-60).dp, y = 50.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                SkyBlue.copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = "إضافة أسرة جديدة",
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = SlateTextPrimary
                                )
                                Text(
                                    text = "نموذج التسجيل الزجاجي الشامل لبيانات الأسرة",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SlateTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = {
                                    viewModel.clearState()
                                    onNavigateBack()
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ArrowForward,
                                    contentDescription = "رجوع",
                                    tint = PalestineGreen
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = {
                                    viewModel.clearState()
                                    Toast.makeText(context, "تمت إعادة تهيئة الحقول", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "إعادة تهيئة",
                                    tint = PalestineGreen
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.White.copy(alpha = 0.78f),
                            titleContentColor = SlateTextPrimary
                        )
                    )
                }
            ) { paddingValues ->
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // شريط تعريفي ونطاق الصلاحية الجغرافية
                    item(key = "header_banner") {
                        LightGlassCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = PalestineGreen.copy(alpha = 0.12f),
                                    border = BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.30f)),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.PersonAdd,
                                            contentDescription = null,
                                            tint = PalestineGreen,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "بطاقة تسجيل أسرة جديدة بالمنظومة",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = SlateTextPrimary
                                    )
                                    val selectedLocName = allowedLocalities
                                        .firstOrNull { it.LocalityID == formState.selectedLocalityId }
                                        ?.LocalityName
                                    val scopeSummary = buildString {
                                        append(if (selectedLocName != null) "المحلية: $selectedLocName" else "اختر المحلية المعتمدة")
                                        if (isBranchLocked && !lockedBranchName.isNullOrBlank()) {
                                            append(" • الشعبة: $lockedBranchName")
                                        }
                                    }
                                    Text(
                                        text = scopeSummary,
                                        fontSize = 11.sp,
                                        color = PalestineGreen,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (isLocalityLocked) {
                                    Icon(
                                        imageVector = Icons.Rounded.Lock,
                                        contentDescription = "نطاق محصور",
                                        tint = PalestineGreen,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }

                    // رسالة الخطأ العامة إن وجدت
                    if (formState.errorMessage != null) {
                        item(key = "error_banner") {
                            Surface(
                                shape = RoundedCornerShape(24.dp),
                                color = PalestineRedLight.copy(alpha = 0.90f),
                                border = BorderStroke(1.dp, PalestineRed.copy(alpha = 0.45f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Rounded.Error, contentDescription = null, tint = PalestineRed)
                                    Text(
                                        text = formState.errorMessage!!,
                                        color = PalestineRedDark,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // =========================================================================
                    // 1. بطاقة البيانات الأساسية
                    // =========================================================================
                    item(key = "card_basic_info") {
                        LightGlassCard {
                            LightGlassSectionHeader(
                                number = "1",
                                title = "بطاقة البيانات الأساسية",
                                subtitle = "الاسم الرباعي، رقم الهوية، الحالة الاجتماعية، الأفراد وبيانات الزوج/الزوجة",
                                icon = Icons.Rounded.Person,
                                accentColor = PalestineGreen
                            )

                            GlassOutlinedTextField(
                                value = formState.name,
                                onValueChange = viewModel::onNameChange,
                                label = "الاسم الرباعي *",
                                isError = formState.nameError != null,
                                errorMessage = formState.nameError,
                                leadingIcon = Icons.Rounded.Person
                            )

                            GlassOutlinedTextField(
                                value = formState.nationalID,
                                onValueChange = viewModel::onNationalIdChange,
                                label = "رقم الهوية (9 أرقام) *",
                                isError = formState.nationalIdError != null,
                                errorMessage = formState.nationalIdError,
                                keyboardType = KeyboardType.Number,
                                leadingIcon = Icons.Rounded.Badge
                            )

                            GlassEditableDropdownField(
                                value = formState.maritalStatus,
                                onValueChange = viewModel::onMaritalStatusChange,
                                label = "الحالة الاجتماعية",
                                suggestions = maritalOptions,
                                leadingIcon = Icons.Rounded.Favorite
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.birthDate,
                                    onValueChange = viewModel::onBirthDateChange,
                                    label = "تاريخ الميلاد *",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.CalendarToday,
                                    onClick = {
                                        showDatePicker(formState.birthDate, defaultYearsBack = 38) {
                                            viewModel.onBirthDateChange(it)
                                        }
                                    },
                                    modifier = Modifier.weight(0.64f)
                                )
                                GlassOutlinedTextField(
                                    value = "$ageText سنة",
                                    onValueChange = {},
                                    label = "العمر",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.Cake,
                                    modifier = Modifier.weight(0.36f)
                                )
                            }

                            GlassDropdownField(
                                value = formState.gender,
                                onValueChange = viewModel::onGenderChange,
                                label = "الجنس",
                                options = listOf("ذكر", "أنثى"),
                                leadingIcon = Icons.Rounded.Wc
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassDropdownField(
                                    value = formState.deathStatus,
                                    onValueChange = viewModel::onDeathStatusChange,
                                    label = "حالة الحياة / الوفاة",
                                    options = listOf("على قيد الحياة", "متوفى", "شهيد"),
                                    leadingIcon = Icons.Rounded.HeartBroken,
                                    modifier = Modifier.weight(1f)
                                )
                                GlassOutlinedTextField(
                                    value = formState.deathDate,
                                    onValueChange = viewModel::onDeathDateChange,
                                    label = "تاريخ الوفاة",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.EventBusy,
                                    onClick = {
                                        showDatePicker(
                                            currentValue = formState.deathDate.ifBlank { "2024-01-01" },
                                            defaultYearsBack = 1
                                        ) {
                                            viewModel.onDeathDateChange(it)
                                        }
                                    },
                                    enabled = formState.deathStatus != "على قيد الحياة",
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.familyMembersCount,
                                    onValueChange = viewModel::onFamilyMembersCountChange,
                                    label = "عدد أفراد الأسرة *",
                                    isError = formState.membersCountError != null,
                                    errorMessage = formState.membersCountError,
                                    keyboardType = KeyboardType.Number,
                                    leadingIcon = Icons.Rounded.Groups,
                                    modifier = Modifier.weight(1f)
                                )
                                GlassOutlinedTextField(
                                    value = formState.rationCardNumber,
                                    onValueChange = viewModel::onRationCardNumberChange,
                                    label = "رقم كرت المؤن",
                                    leadingIcon = Icons.Rounded.CreditCard,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            GlassOutlinedTextField(
                                value = formState.wifeName,
                                onValueChange = viewModel::onWifeNameChange,
                                label = "اسم الزوج / الزوجة الرباعي",
                                leadingIcon = Icons.Rounded.Face
                            )

                            GlassOutlinedTextField(
                                value = formState.wifeNationalID,
                                onValueChange = viewModel::onWifeNationalIdChange,
                                label = "رقم هوية الزوج / الزوجة (9 أرقام)",
                                isError = formState.wifeNationalIdError != null,
                                errorMessage = formState.wifeNationalIdError,
                                keyboardType = KeyboardType.Number,
                                leadingIcon = Icons.Rounded.PermIdentity
                            )
                        }
                    }

                    // =========================================================================
                    // 2. بطاقة السكن والتواصل
                    // =========================================================================
                    item(key = "card_housing_contact") {
                        LightGlassCard {
                            LightGlassSectionHeader(
                                number = "2",
                                title = "بطاقة السكن والتواصل",
                                subtitle = "رقم الجوال، المحافظة، المحلية، المنطقة الفرعية، نوع السكن وتصنيف الضرر",
                                icon = Icons.Rounded.LocationOn,
                                accentColor = SkyBlue
                            )

                            GlassOutlinedTextField(
                                value = formState.primaryPhone,
                                onValueChange = viewModel::onPrimaryPhoneChange,
                                label = "رقم الجوال *",
                                isError = formState.phoneError != null,
                                errorMessage = formState.phoneError,
                                keyboardType = KeyboardType.Phone,
                                leadingIcon = Icons.Rounded.Phone
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.alternativePhone1,
                                    onValueChange = viewModel::onAlternativePhone1Change,
                                    label = "جوال بديل 1",
                                    keyboardType = KeyboardType.Phone,
                                    leadingIcon = Icons.Rounded.PhoneIphone,
                                    modifier = Modifier.weight(1f)
                                )
                                GlassOutlinedTextField(
                                    value = formState.alternativePhone2,
                                    onValueChange = viewModel::onAlternativePhone2Change,
                                    label = "جوال بديل 2",
                                    keyboardType = KeyboardType.Phone,
                                    leadingIcon = Icons.Rounded.Call,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            GlassEditableDropdownField(
                                value = formState.currentMainArea,
                                onValueChange = viewModel::onCurrentMainAreaChange,
                                label = "المحافظة",
                                suggestions = governorateSuggestions,
                                leadingIcon = Icons.Rounded.Map
                            )

                            if (allowedLocalities.isNotEmpty()) {
                                val selectedLocName = allowedLocalities
                                    .firstOrNull { it.LocalityID == formState.selectedLocalityId }
                                    ?.LocalityName ?: allowedLocalities.first().LocalityName
                                GlassDropdownField(
                                    value = selectedLocName,
                                    onValueChange = { pickedName ->
                                        allowedLocalities.firstOrNull { it.LocalityName == pickedName }?.let {
                                            viewModel.onLocalitySelected(it)
                                        }
                                    },
                                    label = if (isLocalityLocked) "المحلية (مقيدة بصلاحيتك) *" else "المحلية *",
                                    options = allowedLocalities.map { it.LocalityName },
                                    leadingIcon = if (isLocalityLocked) Icons.Rounded.Lock else Icons.Rounded.LocationCity,
                                    enabled = !isLocalityLocked
                                )
                            } else {
                                GlassOutlinedTextField(
                                    value = formState.currentMainArea.ifBlank { "لا توجد محليات متاحة في النطاق" },
                                    onValueChange = {},
                                    label = "المحلية *",
                                    readOnly = true,
                                    enabled = false,
                                    leadingIcon = Icons.Rounded.LocationCity
                                )
                            }

                            GlassEditableDropdownField(
                                value = formState.currentSubArea,
                                onValueChange = viewModel::onCurrentSubAreaChange,
                                label = "المنطقة الفرعية *",
                                suggestions = availableSubAreas,
                                leadingIcon = Icons.Rounded.Place
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.currentBranch,
                                    onValueChange = viewModel::onCurrentBranchChange,
                                    label = if (isBranchLocked) "الشعبة الحالية (مقيدة)" else "الشعبة الحالية",
                                    suggestions = availableBranches.ifEmpty { availableSubAreas },
                                    leadingIcon = if (isBranchLocked) Icons.Rounded.Lock else Icons.Rounded.AltRoute,
                                    enabled = !isBranchLocked,
                                    modifier = Modifier.weight(1f)
                                )
                                GlassOutlinedTextField(
                                    value = formState.currentMosque,
                                    onValueChange = viewModel::onCurrentMosqueChange,
                                    label = "المسجد الحالي",
                                    leadingIcon = Icons.Rounded.Mosque,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.shelterStatus,
                                    onValueChange = viewModel::onShelterStatusChange,
                                    label = "نوع السكن",
                                    suggestions = shelterStatusOptions,
                                    leadingIcon = Icons.Rounded.Home,
                                    modifier = Modifier.weight(1f)
                                )
                                GlassDropdownField(
                                    value = formState.residentStatus,
                                    onValueChange = viewModel::onResidentStatusChange,
                                    label = "صفة الإقامة",
                                    options = residentStatusOptions,
                                    leadingIcon = Icons.Rounded.PinDrop,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            GlassOutlinedTextField(
                                value = formState.shelterCenterName,
                                onValueChange = viewModel::onShelterCenterNameChange,
                                label = "اسم مركز الإيواء أو المخيم (إن وجد)",
                                leadingIcon = Icons.Rounded.HolidayVillage
                            )

                            GlassEditableDropdownField(
                                value = formState.damageType,
                                onValueChange = viewModel::onDamageTypeChange,
                                label = "تصنيف الضرر",
                                suggestions = damageTypeOptions,
                                leadingIcon = Icons.Rounded.HomeWork
                            )

                            GlassOutlinedTextField(
                                value = formState.damageDescription,
                                onValueChange = viewModel::onDamageDescriptionChange,
                                label = "وصف تفاصيل الضرر",
                                leadingIcon = Icons.Rounded.ReportProblem,
                                singleLine = false,
                                minLines = 2
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.injuryStatus,
                                    onValueChange = viewModel::onInjuryStatusChange,
                                    label = "الحالة الصحية / الإصابة",
                                    suggestions = injuryStatusOptions,
                                    leadingIcon = Icons.Rounded.LocalHospital,
                                    modifier = Modifier.weight(1f)
                                )
                                GlassOutlinedTextField(
                                    value = formState.injuryDate,
                                    onValueChange = viewModel::onInjuryDateChange,
                                    label = "تاريخ الإصابة",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.Event,
                                    onClick = {
                                        showDatePicker(
                                            currentValue = formState.injuryDate.ifBlank { "2024-01-01" },
                                            defaultYearsBack = 1
                                        ) {
                                            viewModel.onInjuryDateChange(it)
                                        }
                                    },
                                    enabled = formState.injuryStatus != "سليم" && formState.injuryStatus != "لا يوجد",
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            HorizontalDivider(
                                color = SlateBorder,
                                thickness = 1.dp,
                                modifier = Modifier.padding(top = 4.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.History,
                                        contentDescription = null,
                                        tint = SkyBlue,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "العنوان الأصلي قبل النزوح",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = SlateTextPrimary
                                    )
                                }
                                TextButton(
                                    onClick = { viewModel.copyCurrentAddressToOriginal() },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.textButtonColors(contentColor = PalestineGreen)
                                ) {
                                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("نسخ الحالي", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.originalMainArea,
                                    onValueChange = viewModel::onOriginalMainAreaChange,
                                    label = "المحافظة الأصلية",
                                    suggestions = governorateSuggestions,
                                    leadingIcon = Icons.Rounded.Map,
                                    modifier = Modifier.weight(1f)
                                )
                                GlassOutlinedTextField(
                                    value = formState.originalSubArea,
                                    onValueChange = viewModel::onOriginalSubAreaChange,
                                    label = "المنطقة الفرعية الأصلية",
                                    leadingIcon = Icons.Rounded.Place,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.originalBranch,
                                    onValueChange = viewModel::onOriginalBranchChange,
                                    label = "الشعبة الأصلية",
                                    leadingIcon = Icons.Rounded.ShareLocation,
                                    modifier = Modifier.weight(1f)
                                )
                                GlassOutlinedTextField(
                                    value = formState.originalMosque,
                                    onValueChange = viewModel::onOriginalMosqueChange,
                                    label = "المسجد الأصلي",
                                    leadingIcon = Icons.Rounded.Mosque,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    // =========================================================================
                    // 3. بطاقة العمل والدخل
                    // =========================================================================
                    item(key = "card_work_income") {
                        LightGlassCard {
                            LightGlassSectionHeader(
                                number = "3",
                                title = "بطاقة العمل والدخل",
                                subtitle = "حالة العمل 1، حالة العمل 2، مصادر الدخل، والاعتمادات الإدارية",
                                icon = Icons.Rounded.Work,
                                accentColor = PalestineGold
                            )

                            GlassEditableDropdownField(
                                value = formState.incomeSource1,
                                onValueChange = viewModel::onIncomeSource1Change,
                                label = "حالة العمل 1",
                                suggestions = incomeSourceOptions,
                                leadingIcon = Icons.Rounded.Work
                            )

                            GlassEditableDropdownField(
                                value = formState.incomeSource2,
                                onValueChange = viewModel::onIncomeSource2Change,
                                label = "حالة العمل 2",
                                suggestions = incomeSourceOptions,
                                leadingIcon = Icons.Rounded.WorkOutline
                            )

                            GlassEditableDropdownField(
                                value = formState.incomeDetails,
                                onValueChange = viewModel::onIncomeDetailsChange,
                                label = "مصادر الدخل",
                                suggestions = incomeSourceOptions,
                                leadingIcon = Icons.Rounded.Payments
                            )

                            HorizontalDivider(
                                color = SlateBorder,
                                thickness = 1.dp,
                                modifier = Modifier.padding(top = 4.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassDropdownField(
                                    value = formState.developmentApproval,
                                    onValueChange = viewModel::onDevelopmentApprovalChange,
                                    label = "اعتماد التنمية",
                                    options = developmentApprovalOptions,
                                    leadingIcon = Icons.Rounded.Verified,
                                    modifier = Modifier.weight(1f)
                                )
                                GlassDropdownField(
                                    value = formState.localityApproval,
                                    onValueChange = viewModel::onLocalityApprovalChange,
                                    label = "اعتماد المحلية",
                                    options = localityApprovalOptions,
                                    leadingIcon = Icons.Rounded.CheckCircle,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            GlassEditableDropdownField(
                                value = formState.worksApproval,
                                onValueChange = viewModel::onWorksApprovalChange,
                                label = "اعتماد وزارة الأشغال",
                                suggestions = worksApprovalOptions,
                                leadingIcon = Icons.Rounded.Build
                            )

                            GlassOutlinedTextField(
                                value = formState.notes,
                                onValueChange = viewModel::onNotesChange,
                                label = "ملاحظات وتفاصيل إضافية",
                                leadingIcon = Icons.Rounded.Notes,
                                singleLine = false,
                                minLines = 3
                            )
                        }
                    }

                    // =========================================================================
                    // زر "اعتماد وحفظ الأسرة" في أسفل الشاشة
                    // =========================================================================
                    item(key = "save_button") {
                        val isEnabled = !formState.isSaving && canAddFamily
                        Button(
                            onClick = {
                                viewModel.saveFamily {
                                    Toast.makeText(
                                        context,
                                        "تم اعتماد وحفظ بيانات الأسرة بنجاح",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    onNavigateBack()
                                }
                            },
                            enabled = isEnabled,
                            shape = RoundedCornerShape(24.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PalestineGreen,
                                contentColor = Color.White,
                                disabledContainerColor = SlateBorder,
                                disabledContentColor = SlateTextMuted
                            ),
                            elevation = ButtonDefaults.buttonElevation(
                                defaultElevation = 6.dp,
                                pressedElevation = 10.dp
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(58.dp)
                        ) {
                            if (formState.isSaving) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color.White,
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "جاري اعتماد وحفظ الأسرة...",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Rounded.VerifiedUser,
                                    contentDescription = "اعتماد وحفظ الأسرة",
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (canAddFamily) "اعتماد وحفظ الأسرة" else "ليس لديك صلاحية إضافة أسر في هذا النطاق",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}

/**
 * بطاقة زجاجية فاتحة (Light Glassmorphism Card) بخلفية بيضاء شفافة 0.7f وحدود بيضاء رقيقة 1.dp وزوايا 24.dp
 */
@Composable
private fun LightGlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color.White, RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.7f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

/**
 * ترويسة زجاجية موحدة لكل بطاقة في شاشة الإضافة
 */
@Composable
private fun LightGlassSectionHeader(
    number: String,
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = accentColor.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(21.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "$number. $title",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = SlateTextPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateTextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        HorizontalDivider(
            color = SlateBorder,
            thickness = 1.dp
        )
    }
}

/**
 * حقل إدخال زجاجي أنيق متوافق مع نظام Glassmorphism ومستخدم في AddFamilyScreen و AddChildScreen
 */
@Composable
fun GlassOutlinedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    isError: Boolean = false,
    errorMessage: String? = null,
    readOnly: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    leadingIcon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    singleLine: Boolean = true,
    minLines: Int = 1,
    glassMode: Boolean = false
) {
    val isDark = isSystemInDarkTheme() || MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val interactionSource = remember { MutableInteractionSource() }

    if (onClick != null && enabled) {
        LaunchedEffect(interactionSource) {
            interactionSource.interactions.collect { interaction ->
                if (interaction is PressInteraction.Release) {
                    onClick()
                }
            }
        }
    }

    val focusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.90f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.85f)
        else -> Color.White.copy(alpha = 0.92f)
    }
    val unfocusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.72f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.62f)
        else -> Color.White.copy(alpha = 0.75f)
    }
    val borderUnfocused = when {
        glassMode -> SlateBorderSubtle
        isDark -> Color.White.copy(alpha = 0.2f)
        else -> SlateBorderSubtle.copy(alpha = 0.90f)
    }
    val accent = PalestineGreen
    val errorAccent = PalestineRed
    val textColor = if (isDark && !glassMode) Color.White else SlateTextPrimary
    val unfocusedLabel = if (isDark && !glassMode) Color(0xFF94A3B8) else SlateTextSecondary

    Column(modifier = modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            readOnly = readOnly,
            enabled = enabled,
            isError = isError,
            singleLine = singleLine,
            minLines = minLines,
            interactionSource = interactionSource,
            leadingIcon = leadingIcon?.let {
                {
                    Icon(
                        imageVector = it,
                        contentDescription = null,
                        tint = if (isError) errorAccent else accent,
                        modifier = Modifier.size(19.dp)
                    )
                }
            },
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = textColor,
                unfocusedTextColor = textColor,
                disabledTextColor = textColor.copy(alpha = 0.65f),
                focusedContainerColor = focusedBg,
                unfocusedContainerColor = unfocusedBg,
                disabledContainerColor = unfocusedBg.copy(alpha = 0.55f),
                focusedBorderColor = accent,
                unfocusedBorderColor = borderUnfocused,
                disabledBorderColor = borderUnfocused.copy(alpha = 0.5f),
                errorBorderColor = errorAccent,
                focusedLabelColor = accent,
                unfocusedLabelColor = unfocusedLabel,
                disabledLabelColor = unfocusedLabel.copy(alpha = 0.6f),
                cursorColor = accent
            ),
            modifier = Modifier.fillMaxWidth()
        )
        if (isError && errorMessage != null) {
            Text(
                text = errorMessage,
                color = errorAccent,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(start = 8.dp, top = 3.dp)
            )
        }
    }
}

/**
 * حقل اختيار منسدل زجاجي GlassDropdownField متوافق مع AddChildScreen
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlassDropdownField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    options: List<String>,
    modifier: Modifier = Modifier.fillMaxWidth(),
    leadingIcon: ImageVector? = Icons.Default.List,
    enabled: Boolean = true,
    glassMode: Boolean = false
) {
    var expanded by remember { mutableStateOf(false) }
    val isDark = isSystemInDarkTheme() || MaterialTheme.colorScheme.surface.luminance() < 0.5f

    val focusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.90f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.85f)
        else -> Color.White.copy(alpha = 0.92f)
    }
    val unfocusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.72f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.62f)
        else -> Color.White.copy(alpha = 0.75f)
    }
    val borderUnfocused = when {
        glassMode -> SlateBorderSubtle
        isDark -> Color.White.copy(alpha = 0.2f)
        else -> SlateBorderSubtle.copy(alpha = 0.90f)
    }
    val accent = PalestineGreen
    val textColor = if (isDark && !glassMode) Color.White else SlateTextPrimary
    val unfocusedLabel = if (isDark && !glassMode) Color(0xFF94A3B8) else SlateTextSecondary
    val menuBg = if (isDark && !glassMode) Color(0xFF1E293B) else Color.White

    ExposedDropdownMenuBox(
        expanded = expanded && enabled,
        onExpandedChange = { if (enabled) expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            singleLine = true,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = leadingIcon?.let {
                {
                    Icon(
                        imageVector = it,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(19.dp)
                    )
                }
            },
            trailingIcon = {
                if (enabled) {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = textColor,
                unfocusedTextColor = textColor,
                disabledTextColor = textColor.copy(alpha = 0.65f),
                focusedContainerColor = focusedBg,
                unfocusedContainerColor = unfocusedBg,
                disabledContainerColor = unfocusedBg.copy(alpha = 0.55f),
                focusedBorderColor = accent,
                unfocusedBorderColor = borderUnfocused,
                disabledBorderColor = borderUnfocused.copy(alpha = 0.5f),
                focusedLabelColor = accent,
                unfocusedLabelColor = unfocusedLabel,
                disabledLabelColor = unfocusedLabel.copy(alpha = 0.6f),
                focusedTrailingIconColor = accent,
                unfocusedTrailingIconColor = unfocusedLabel
            ),
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )

        ExposedDropdownMenu(
            expanded = expanded && enabled,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(menuBg)
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = option,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (option == value) FontWeight.Bold else FontWeight.Normal,
                                color = textColor
                            )
                            if (option == value) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = null,
                                    tint = accent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    onClick = {
                        onValueChange(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

/**
 * حقل اختيار منسدل قابل للكتابة والبحث الفوري (Editable OutlinedTextField + ExposedDropdownMenuBox)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GlassEditableDropdownField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    suggestions: List<String>,
    leadingIcon: ImageVector,
    modifier: Modifier = Modifier.fillMaxWidth(),
    enabled: Boolean = true
) {
    var expanded by remember { mutableStateOf(false) }

    val filtered = remember(value, suggestions) {
        if (value.isBlank()) suggestions
        else {
            val trimmed = value.trim()
            val matched = suggestions.filter { it.contains(trimmed, ignoreCase = true) }
            if (matched.isNotEmpty()) matched else suggestions
        }
    }

    ExposedDropdownMenuBox(
        expanded = expanded && enabled && filtered.isNotEmpty(),
        onExpandedChange = { if (enabled && filtered.isNotEmpty()) expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = {
                onValueChange(it)
                if (filtered.isNotEmpty()) expanded = true
            },
            readOnly = false,
            enabled = enabled,
            singleLine = true,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = leadingIcon,
                    contentDescription = null,
                    tint = PalestineGreen,
                    modifier = Modifier.size(19.dp)
                )
            },
            trailingIcon = {
                if (enabled && filtered.isNotEmpty()) {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = SlateTextPrimary,
                unfocusedTextColor = SlateTextPrimary,
                disabledTextColor = SlateTextPrimary.copy(alpha = 0.65f),
                focusedContainerColor = Color.White.copy(alpha = 0.92f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.75f),
                disabledContainerColor = Color.White.copy(alpha = 0.55f),
                focusedBorderColor = PalestineGreen,
                unfocusedBorderColor = SlateBorderSubtle,
                disabledBorderColor = SlateBorderSubtle.copy(alpha = 0.5f),
                focusedLabelColor = PalestineGreen,
                unfocusedLabelColor = SlateTextSecondary,
                disabledLabelColor = SlateTextSecondary.copy(alpha = 0.6f),
                focusedTrailingIconColor = PalestineGreen,
                unfocusedTrailingIconColor = SlateTextSecondary,
                cursorColor = PalestineGreen
            ),
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )

        if (filtered.isNotEmpty()) {
            ExposedDropdownMenu(
                expanded = expanded && enabled,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(Color.White)
            ) {
                filtered.forEach { option ->
                    DropdownMenuItem(
                        text = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = option,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (option == value) FontWeight.Bold else FontWeight.Normal,
                                    color = SlateTextPrimary
                                )
                                if (option == value) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = PalestineGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        },
                        onClick = {
                            onValueChange(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}
