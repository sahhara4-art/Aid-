package com.humanitarian.aidmanagement.ui.screens.families

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.calculateAgeFromBirthDate
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.ExcelParserHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Locale

/**
 * ViewModel شامل لإدارة جميع حقول نموذج إضافة أسرة جديدة (36+ حقل)
 * مع التحقق الفوري، العزل الجغرافي الصارم (RLS)، والتنفيذ غير المتزامن على Dispatchers.IO
 */
class AddFamilyViewModel(
    private val repository: AidRepository
) : ViewModel() {

    data class FormState(
        // 1. البيانات الأساسية ورب الأسرة
        val name: String = "",
        val nationalID: String = "",
        val birthDate: String = "1985-01-01",
        val gender: String = "ذكر",
        val maritalStatus: String = "متزوج",
        val deathStatus: String = "على قيد الحياة",
        val deathDate: String = "",

        // 2. بيانات الأسرة والزوج/الزوجة والمؤن
        val familyMembersCount: String = "5",
        val rationCardNumber: String = "",
        val wifeName: String = "",
        val wifeNationalID: String = "",

        // 3. بيانات التواصل والاتصال
        val primaryPhone: String = "",
        val alternativePhone1: String = "",
        val alternativePhone2: String = "",

        // 4. العنوان الجغرافي الحالي والإيواء
        val selectedLocalityId: Int = 1,
        val currentMainArea: String = "",
        val currentSubArea: String = "",
        val currentBranch: String = "",
        val currentMosque: String = "",
        val residentStatus: String = "نازح",
        val shelterStatus: String = "إيواء داخلي",
        val shelterCenterName: String = "",

        // 5. العنوان الأصلي قبل النزوح
        val originalMainArea: String = "",
        val originalSubArea: String = "",
        val originalBranch: String = "",
        val originalMosque: String = "",

        // 6. الوضع المعيشي والأضرار والإصابات
        val incomeSource1: String = "بلا عمل",
        val incomeSource2: String = "",
        val damageType: String = "أضرار كلية",
        val damageDescription: String = "",
        val injuryStatus: String = "سليم",
        val injuryDate: String = "",

        // 7. حالات الاعتماد الإداري والملاحظات
        val developmentApproval: String = "معتمد",
        val localityApproval: String = "معتمد",
        val worksApproval: String = "اعتماد أشغال",
        val notes: String = "",

        // أخطاء التحقق وحالة الحفظ
        val isSaving: Boolean = false,
        val saveSuccess: Boolean = false,
        val errorMessage: String? = null,
        val nameError: String? = null,
        val nationalIdError: String? = null,
        val wifeNationalIdError: String? = null,
        val phoneError: String? = null,
        val membersCountError: String? = null
    )

    private val _state = MutableStateFlow(FormState())
    val state: StateFlow<FormState> = _state.asStateFlow()

    private val _allowedLocalities = MutableStateFlow<List<LocalityEntity>>(emptyList())
    val allowedLocalities: StateFlow<List<LocalityEntity>> = _allowedLocalities.asStateFlow()

    private val _isLocalityLocked = MutableStateFlow(false)
    val isLocalityLocked: StateFlow<Boolean> = _isLocalityLocked.asStateFlow()

    private val _availableSubAreas = MutableStateFlow<List<String>>(emptyList())
    val availableSubAreas: StateFlow<List<String>> = _availableSubAreas.asStateFlow()

    private val _availableBranches = MutableStateFlow<List<String>>(emptyList())
    val availableBranches: StateFlow<List<String>> = _availableBranches.asStateFlow()

    private val _isBranchLocked = MutableStateFlow(false)
    val isBranchLocked: StateFlow<Boolean> = _isBranchLocked.asStateFlow()

    private val _lockedBranchName = MutableStateFlow<String?>(null)
    val lockedBranchName: StateFlow<String?> = _lockedBranchName.asStateFlow()

    init {
        loadGeographicalScope()
        viewModelScope.launch {
            repository.currentUserFlow.drop(1).collect {
                loadGeographicalScope()
            }
        }
    }

    private fun loadGeographicalScope() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val locs = repository.getAllowedLocalitiesSync()
                val currentUser = repository.getCurrentUser()
                val isRestricted = !repository.isSuperAdmin() &&
                    ((currentUser?.AllowedLocalityID ?: 0) != 0 || locs.size == 1)

                _allowedLocalities.value = locs
                _isLocalityLocked.value = isRestricted && locs.size <= 1

                val currentSel = _state.value.selectedLocalityId
                val validSelected = locs.firstOrNull { it.LocalityID == currentSel } ?: locs.firstOrNull()
                if (validSelected != null) {
                    _state.update { s ->
                        s.copy(
                            selectedLocalityId = validSelected.LocalityID,
                            currentMainArea = s.currentMainArea.ifBlank { validSelected.LocalityName }
                        )
                    }
                    loadLocalityDetails(validSelected.LocalityID, validSelected.LocalityName)
                } else {
                    loadBranchRestrictionsOnly()
                }
            } catch (_: Exception) {
            }
        }
    }

    private suspend fun loadLocalityDetails(localityId: Int, localityName: String) {
        val subAreas = repository.getSubAreasByLocality(localityId)
        _availableSubAreas.value = subAreas

        val branches = repository.getDistinctBranchesForLocality(localityName)
        val (ignoreBr, allowedBranches) = repository.getEffectiveBranchScope()
        val validAllowedBranches = allowedBranches.filter { it != "__DENY__" && it != "__ALL__" }

        if (ignoreBr == 0 && validAllowedBranches.isNotEmpty()) {
            val merged = (branches + validAllowedBranches).distinct().sorted()
            _availableBranches.value = merged
            if (validAllowedBranches.size == 1) {
                val singleBranch = validAllowedBranches.first()
                _isBranchLocked.value = true
                _lockedBranchName.value = singleBranch
                _state.update { it.copy(currentBranch = singleBranch) }
            } else {
                _isBranchLocked.value = false
                _lockedBranchName.value = null
                val cur = _state.value.currentBranch
                if (cur.isBlank() || validAllowedBranches.none { it.equals(cur.trim(), ignoreCase = true) }) {
                    _state.update { it.copy(currentBranch = validAllowedBranches.first()) }
                }
            }
        } else {
            _isBranchLocked.value = false
            _lockedBranchName.value = null
            _availableBranches.value = branches
        }
    }

    private suspend fun loadBranchRestrictionsOnly() {
        val (ignoreBr, allowedBranches) = repository.getEffectiveBranchScope()
        val validAllowedBranches = allowedBranches.filter { it != "__DENY__" && it != "__ALL__" }
        if (ignoreBr == 0 && validAllowedBranches.size == 1) {
            val singleBranch = validAllowedBranches.first()
            _isBranchLocked.value = true
            _lockedBranchName.value = singleBranch
            _availableBranches.value = listOf(singleBranch)
            _state.update { it.copy(currentBranch = singleBranch) }
        }
    }

    // دوال تحديث الحقول
    fun onNameChange(v: String) = _state.update { it.copy(name = v, nameError = null, errorMessage = null) }
    fun onNationalIdChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() }.take(9)
        _state.update { it.copy(nationalID = cleaned, nationalIdError = null, errorMessage = null) }
    }
    fun onBirthDateChange(v: String) = _state.update { it.copy(birthDate = v) }
    fun onGenderChange(v: String) = _state.update { it.copy(gender = v) }
    fun onMaritalStatusChange(v: String) = _state.update { it.copy(maritalStatus = v) }
    fun onDeathStatusChange(v: String) = _state.update {
        it.copy(
            deathStatus = v,
            deathDate = if (v == "على قيد الحياة") "" else it.deathDate
        )
    }
    fun onDeathDateChange(v: String) = _state.update { it.copy(deathDate = v) }

    fun onFamilyMembersCountChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() }.take(2)
        _state.update { it.copy(familyMembersCount = cleaned, membersCountError = null) }
    }
    fun onRationCardNumberChange(v: String) = _state.update { it.copy(rationCardNumber = v) }
    fun onWifeNameChange(v: String) = _state.update { it.copy(wifeName = v) }
    fun onWifeNationalIdChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() }.take(9)
        _state.update { it.copy(wifeNationalID = cleaned, wifeNationalIdError = null) }
    }

    fun onPrimaryPhoneChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() || it == '+' }.take(15)
        _state.update { it.copy(primaryPhone = cleaned, phoneError = null) }
    }
    fun onAlternativePhone1Change(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() || it == '+' }.take(15)
        _state.update { it.copy(alternativePhone1 = cleaned) }
    }
    fun onAlternativePhone2Change(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() || it == '+' }.take(15)
        _state.update { it.copy(alternativePhone2 = cleaned) }
    }

    fun onLocalitySelected(locality: LocalityEntity) {
        if (_isLocalityLocked.value) return
        _state.update {
            it.copy(
                selectedLocalityId = locality.LocalityID,
                currentMainArea = it.currentMainArea.ifBlank { locality.LocalityName }
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                loadLocalityDetails(locality.LocalityID, locality.LocalityName)
            } catch (_: Exception) {
            }
        }
    }

    fun onCurrentMainAreaChange(v: String) = _state.update { it.copy(currentMainArea = v) }
    fun onCurrentSubAreaChange(v: String) = _state.update { it.copy(currentSubArea = v) }
    fun onCurrentBranchChange(v: String) {
        if (_isBranchLocked.value) return
        _state.update { it.copy(currentBranch = v) }
    }
    fun onCurrentMosqueChange(v: String) = _state.update { it.copy(currentMosque = v) }
    fun onResidentStatusChange(v: String) = _state.update { it.copy(residentStatus = v) }
    fun onShelterStatusChange(v: String) = _state.update { it.copy(shelterStatus = v) }
    fun onShelterCenterNameChange(v: String) = _state.update { it.copy(shelterCenterName = v) }

    fun onOriginalMainAreaChange(v: String) = _state.update { it.copy(originalMainArea = v) }
    fun onOriginalSubAreaChange(v: String) = _state.update { it.copy(originalSubArea = v) }
    fun onOriginalBranchChange(v: String) = _state.update { it.copy(originalBranch = v) }
    fun onOriginalMosqueChange(v: String) = _state.update { it.copy(originalMosque = v) }

    fun copyCurrentAddressToOriginal() {
        _state.update {
            it.copy(
                originalMainArea = it.currentMainArea,
                originalSubArea = it.currentSubArea,
                originalBranch = it.currentBranch,
                originalMosque = it.currentMosque
            )
        }
    }

    fun onIncomeSource1Change(v: String) = _state.update { it.copy(incomeSource1 = v) }
    fun onIncomeSource2Change(v: String) = _state.update { it.copy(incomeSource2 = v) }
    fun onDamageTypeChange(v: String) = _state.update { it.copy(damageType = v) }
    fun onDamageDescriptionChange(v: String) = _state.update { it.copy(damageDescription = v) }
    fun onInjuryStatusChange(v: String) = _state.update {
        it.copy(
            injuryStatus = v,
            injuryDate = if (v == "سليم" || v == "لا يوجد") "" else it.injuryDate
        )
    }
    fun onInjuryDateChange(v: String) = _state.update { it.copy(injuryDate = v) }

    fun onDevelopmentApprovalChange(v: String) = _state.update { it.copy(developmentApproval = v) }
    fun onLocalityApprovalChange(v: String) = _state.update { it.copy(localityApproval = v) }
    fun onWorksApprovalChange(v: String) = _state.update { it.copy(worksApproval = v) }
    fun onNotesChange(v: String) = _state.update { it.copy(notes = v) }

    fun saveFamily(onSuccess: () -> Unit) {
        val current = _state.value
        val cleanName = current.name.trim()
        val cleanNationalId = ExcelParserHelper.normalizeNationalId(current.nationalID)
        val cleanWifeNationalId = ExcelParserHelper.normalizeNationalId(current.wifeNationalID)
        val cleanPhone = current.primaryPhone.trim()
        val parsedMembers = current.familyMembersCount.trim().toIntOrNull()

        var nameErr: String? = null
        var natErr: String? = null
        var wifeNatErr: String? = null
        var phoneErr: String? = null
        var membersErr: String? = null
        var hasError = false

        if (cleanName.length < 5) {
            nameErr = "يرجى كتابة الاسم الرباعي لرب الأسرة (5 أحرف على الأقل)"
            hasError = true
        }
        if (cleanNationalId.length != 9) {
            natErr = "رقم الهوية الوطنية يجب أن يتكون من 9 أرقام بالضبط"
            hasError = true
        }
        if (current.wifeNationalID.isNotBlank() && cleanWifeNationalId.length != 9) {
            wifeNatErr = "رقم هوية الزوج/الزوجة يجب أن يتكون من 9 أرقام"
            hasError = true
        }
        if (cleanPhone.filter { it.isDigit() }.length < 9) {
            phoneErr = "يرجى إدخال رقم جوال أساسي صحيح (9 أرقام على الأقل)"
            hasError = true
        }
        if (parsedMembers == null || parsedMembers <= 0) {
            membersErr = "عدد أفراد الأسرة يجب أن يكون 1 على الأقل"
            hasError = true
        }

        if (hasError) {
            _state.update {
                it.copy(
                    nameError = nameErr,
                    nationalIdError = natErr,
                    wifeNationalIdError = wifeNatErr,
                    phoneError = phoneErr,
                    membersCountError = membersErr,
                    errorMessage = "يرجى استكمال وتصحيح الحقول الإلزامية المميزة باللون الأحمر"
                )
            }
            return
        }

        if (!repository.canAddFamilyInLocality(current.selectedLocalityId)) {
            _state.update {
                it.copy(errorMessage = "غير مصرح لك بإضافة أسرة ضمن هذه المحلية وفق صلاحيات العزل الجغرافي")
            }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _state.update {
                it.copy(
                    isSaving = true,
                    errorMessage = null,
                    nameError = null,
                    nationalIdError = null,
                    wifeNationalIdError = null,
                    phoneError = null,
                    membersCountError = null
                )
            }
            try {
                val existing = repository.getFamilyByNationalId(cleanNationalId)
                if (existing != null) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            nationalIdError = "رقم الهوية مسجل مسبقاً باسم: ${existing.name}",
                            errorMessage = "رقم الهوية الوطنية ($cleanNationalId) مسجل مسبقاً في قاعدة البيانات"
                        )
                    }
                    return@launch
                }

                val effectiveLocalityName = _allowedLocalities.value
                    .firstOrNull { it.LocalityID == current.selectedLocalityId }
                    ?.LocalityName
                    .orEmpty()

                val lockedBranch = _lockedBranchName.value
                val effectiveBranch = if (_isBranchLocked.value && !lockedBranch.isNullOrBlank()) {
                    lockedBranch
                } else {
                    current.currentBranch.trim()
                }

                val newFamily = FamilyEntity(
                    nationalID = cleanNationalId,
                    name = cleanName,
                    gender = current.gender.trim(),
                    date_of_birth = current.birthDate.trim().ifBlank { "1985-01-01" },
                    maritalStatus = current.maritalStatus.trim(),
                    deathStatus = current.deathStatus.trim(),
                    deathDate = current.deathDate.trim().ifBlank { null },
                    primary_phone = cleanPhone,
                    alternative_phone_1 = current.alternativePhone1.trim().ifBlank { null },
                    alternative_phone_2 = current.alternativePhone2.trim().ifBlank { null },
                    wifeName = current.wifeName.trim().ifBlank { null },
                    wifeNationalID = cleanWifeNationalId.ifBlank { null },
                    familyMembersCount = parsedMembers ?: 1,
                    damageType = current.damageType.trim(),
                    damageDescription = current.damageDescription.trim().ifBlank { null },
                    injuryStatus = current.injuryStatus.trim(),
                    injuryDate = current.injuryDate.trim().ifBlank { null },
                    incomeSource1 = current.incomeSource1.trim().ifBlank { "بلا عمل" },
                    income_source_2 = current.incomeSource2.trim().ifBlank { null },
                    rationCardNumber = current.rationCardNumber.trim().ifBlank { null },
                    originalMainArea = current.originalMainArea.trim(),
                    originalSubArea = current.originalSubArea.trim(),
                    originalBranch = current.originalBranch.trim(),
                    originalMosque = current.originalMosque.trim(),
                    currentMainArea = current.currentMainArea.trim().ifBlank { effectiveLocalityName },
                    currentSubArea = current.currentSubArea.trim().ifBlank { effectiveLocalityName },
                    currentBranch = effectiveBranch,
                    currentMosque = current.currentMosque.trim(),
                    developmentApproval = current.developmentApproval.trim(),
                    localityApproval = current.localityApproval.trim(),
                    residentStatus = current.residentStatus.trim(),
                    worksApproval = current.worksApproval.trim(),
                    shelterStatus = current.shelterStatus.trim(),
                    shelter_center_name = current.shelterCenterName.trim().ifBlank { null },
                    notes = current.notes.trim().ifBlank { null },
                    localityID = current.selectedLocalityId,
                    createdDate = System.currentTimeMillis(),
                    modifiedDate = null
                )

                repository.insertFamily(newFamily)

                withContext(Dispatchers.Main) {
                    _state.update { it.copy(isSaving = false, saveSuccess = true) }
                    onSuccess()
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            errorMessage = t.localizedMessage ?: "حدث خطأ غير متوقع أثناء حفظ بيانات الأسرة"
                        )
                    }
                }
            }
        }
    }

    /**
     * واجهة توافقية للإدخال المباشر على Dispatchers.IO
     */
    fun insertFamily(
        family: FamilyEntity,
        onSuccess: () -> Unit
    ) {
        val cleanNationalId = ExcelParserHelper.normalizeNationalId(family.nationalID)
        if (cleanNationalId.length != 9) {
            _state.update { it.copy(nationalIdError = "رقم الهوية الوطنية يجب أن يتكون من 9 أرقام") }
            return
        }
        if (family.name.trim().length < 5) {
            _state.update { it.copy(nameError = "يرجى كتابة الاسم الرباعي بشكل صحيح") }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(isSaving = true, errorMessage = null, nationalIdError = null, nameError = null) }
            try {
                val existing = repository.getFamilyByNationalId(cleanNationalId)
                if (existing != null) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            nationalIdError = "رقم الهوية مسجل مسبقاً باسم: ${existing.name}"
                        )
                    }
                    return@launch
                }
                val normalized = family.copy(
                    nationalID = cleanNationalId,
                    wifeNationalID = family.wifeNationalID?.let { ExcelParserHelper.normalizeNationalId(it) }?.ifBlank { null }
                )
                repository.insertFamily(normalized)
                withContext(Dispatchers.Main) {
                    _state.update { it.copy(isSaving = false, saveSuccess = true) }
                    onSuccess()
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            errorMessage = t.localizedMessage ?: "حدث خطأ أثناء حفظ الأسرة في قاعدة البيانات"
                        )
                    }
                }
            }
        }
    }

    fun clearState() {
        val locId = _allowedLocalities.value.firstOrNull()?.LocalityID ?: 1
        val locName = _allowedLocalities.value.firstOrNull()?.LocalityName.orEmpty()
        val lockedBranch = if (_isBranchLocked.value) _lockedBranchName.value.orEmpty() else ""
        _state.value = FormState(
            selectedLocalityId = locId,
            currentMainArea = locName,
            currentBranch = lockedBranch
        )
    }

    override fun onCleared() {
        super.onCleared()
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AddFamilyViewModel(repository) as T
        }
    }
}

/**
 * شاشة إضافة أسرة جديدة بتصميم Glassmorphism فاخر وتغطية شاملة لكافة حقول FamilyEntity
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFamilyScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    viewModel: AddFamilyViewModel = viewModel(factory = AddFamilyViewModel.Factory(repository))
) {
    val context = LocalContext.current
    val formState by viewModel.state.collectAsStateWithLifecycle()
    val allowedLocalities by viewModel.allowedLocalities.collectAsStateWithLifecycle()
    val isLocalityLocked by viewModel.isLocalityLocked.collectAsStateWithLifecycle()
    val availableSubAreas by viewModel.availableSubAreas.collectAsStateWithLifecycle()
    val availableBranches by viewModel.availableBranches.collectAsStateWithLifecycle()
    val isBranchLocked by viewModel.isBranchLocked.collectAsStateWithLifecycle()
    val lockedBranchName by viewModel.lockedBranchName.collectAsStateWithLifecycle()

    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val canAddFamily = remember(currentUser, allowedLocalities) {
        currentUser != null &&
            (repository.isSuperAdmin() || repository.hasPermission("families_create")) &&
            AccessControlManager.hasActionPermission(AccessControlManager.ACTION_ADD) &&
            allowedLocalities.isNotEmpty()
    }

    val listState = rememberLazyListState()
    val isDark = isSystemInDarkTheme() || MaterialTheme.colorScheme.surface.luminance() < 0.5f

    val ageText = remember(formState.birthDate) {
        calculateAgeFromBirthDate(formState.birthDate).toString()
    }

    fun showDatePicker(currentValue: String, defaultYearsBack: Int = 35, onPicked: (String) -> Unit) {
        val calendar = Calendar.getInstance()
        val parts = currentValue.trim().split("-", "/")
        val initialYear = parts.getOrNull(0)?.toIntOrNull() ?: (calendar.get(Calendar.YEAR) - defaultYearsBack)
        val initialMonth = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val initialDay = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(
            context,
            { _, y, m, d ->
                onPicked(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d))
            },
            initialYear,
            initialMonth,
            initialDay
        ).show()
    }

    // خلفية زجاجية داكنة فاخرة بتدرج عميق تبرز شفافية البطاقات (Glassmorphism Ambient Backdrop)
    val backdropBrush = remember {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFF07131E),
                Color(0xFF0C2329),
                Color(0xFF0A192F)
            )
        )
    }

    val governorateSuggestions = remember {
        listOf("غزة", "شمال غزة", "الوسطى / دير البلح", "خانيونس", "رفح")
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(backdropBrush)
        ) {
            // هالات ضوئية لونية ناعمة في الخلفية لتعزيز العمق الزجاجي
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 70.dp, y = (-50).dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                PalestineGreen.copy(alpha = 0.28f),
                                Color.Transparent
                            )
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = (-60).dp, y = 50.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                SkyBlue.copy(alpha = 0.22f),
                                Color.Transparent
                            )
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .align(Alignment.CenterStart)
                    .offset(x = (-80).dp, y = (-40).dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                PalestineGold.copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = "إضافة أسرة جديدة",
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White
                                )
                                Text(
                                    text = "نموذج التسجيل الزجاجي الشامل لكافة الحقول المعتمدة",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFFCBD5E1),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = {
                                    viewModel.clearState()
                                    onNavigateBack()
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ArrowForward,
                                    contentDescription = "رجوع",
                                    tint = Color.White
                                )
                            }
                        },
                        actions = {
                            IconButton(
                                onClick = {
                                    viewModel.clearState()
                                    Toast.makeText(context, "تمت إعادة تهيئة الحقول", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "إعادة تهيئة",
                                    tint = Color.White
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color(0xFF0A192F).copy(alpha = 0.72f),
                            titleContentColor = Color.White
                        )
                    )
                }
            ) { paddingValues ->
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // شريط تعريفي ونطاق الصلاحية الجغرافية
                    item(key = "header_banner") {
                        LuxuryGlassCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color(0xFF34D399).copy(alpha = 0.16f),
                                    border = BorderStroke(1.dp, Color(0xFF34D399).copy(alpha = 0.35f)),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.PersonAdd,
                                            contentDescription = null,
                                            tint = Color(0xFF6EE7B7),
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "بطاقة تسجيل أسرة جديدة بالمنظومة",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                    val selectedLocName = allowedLocalities
                                        .firstOrNull { it.LocalityID == formState.selectedLocalityId }
                                        ?.LocalityName
                                    val scopeSummary = buildString {
                                        append(if (selectedLocName != null) "المحلية: $selectedLocName" else "اختر المحلية المعتمدة")
                                        if (isBranchLocked && !lockedBranchName.isNullOrBlank()) {
                                            append(" • الشعبة: $lockedBranchName")
                                        }
                                    }
                                    Text(
                                        text = scopeSummary,
                                        fontSize = 11.sp,
                                        color = Color(0xFF6EE7B7),
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (isLocalityLocked) {
                                    Icon(
                                        imageVector = Icons.Rounded.Lock,
                                        contentDescription = "نطاق محصور",
                                        tint = Color(0xFF6EE7B7),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }

                    // رسالة الخطأ العامة إن وجدت
                    if (formState.errorMessage != null) {
                        item(key = "error_banner") {
                            Surface(
                                shape = RoundedCornerShape(24.dp),
                                color = PalestineRed.copy(alpha = 0.22f),
                                border = BorderStroke(1.dp, Color(0xFFFCA5A5).copy(alpha = 0.55f)),
                                shadowElevation = 0.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Rounded.Error, contentDescription = null, tint = Color(0xFFFCA5A5))
                                    Text(
                                        text = formState.errorMessage!!,
                                        color = Color(0xFFFEE2E2),
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // =========================================================================
                    // البطاقة 1: البيانات الأساسية ورب الأسرة والزوجة
                    // =========================================================================
                    item(key = "card_basic_and_spouse") {
                        LuxuryGlassCard {
                            GlassSectionHeader(
                                number = "1",
                                title = "البيانات الأساسية ورب الأسرة والزوجة",
                                subtitle = "الهوية الوطنية، الميلاد، الحالة الاجتماعية، الأفراد والزوجة",
                                icon = Icons.Rounded.Person,
                                accentColor = Color(0xFF34D399)
                            )

                            GlassOutlinedTextField(
                                value = formState.name,
                                onValueChange = viewModel::onNameChange,
                                label = "الاسم الرباعي الكامل للمستفيد *",
                                isError = formState.nameError != null,
                                errorMessage = formState.nameError,
                                leadingIcon = Icons.Rounded.Person,
                                glassMode = true
                            )

                            GlassOutlinedTextField(
                                value = formState.nationalID,
                                onValueChange = viewModel::onNationalIdChange,
                                label = "رقم الهوية الوطنية (9 أرقام) *",
                                isError = formState.nationalIdError != null,
                                errorMessage = formState.nationalIdError,
                                keyboardType = KeyboardType.Number,
                                leadingIcon = Icons.Rounded.Badge,
                                glassMode = true
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.birthDate,
                                    onValueChange = {},
                                    label = "تاريخ الميلاد *",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.CalendarToday,
                                    onClick = {
                                        showDatePicker(formState.birthDate, defaultYearsBack = 38) {
                                            viewModel.onBirthDateChange(it)
                                        }
                                    },
                                    modifier = Modifier.weight(0.64f),
                                    glassMode = true
                                )
                                GlassOutlinedTextField(
                                    value = "$ageText سنة",
                                    onValueChange = {},
                                    label = "العمر",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.Cake,
                                    modifier = Modifier.weight(0.36f),
                                    glassMode = true
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassDropdownField(
                                    value = formState.gender,
                                    onValueChange = viewModel::onGenderChange,
                                    label = "الجنس",
                                    options = listOf("ذكر", "أنثى"),
                                    modifier = Modifier.weight(1f),
                                    leadingIcon = Icons.Rounded.Wc,
                                    glassMode = true
                                )
                                GlassDropdownField(
                                    value = formState.maritalStatus,
                                    onValueChange = viewModel::onMaritalStatusChange,
                                    label = "الحالة الاجتماعية",
                                    options = listOf("متزوج", "أعزب", "أرمل", "مطلق", "مهجور"),
                                    modifier = Modifier.weight(1f),
                                    leadingIcon = Icons.Rounded.Favorite,
                                    glassMode = true
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassDropdownField(
                                    value = formState.deathStatus,
                                    onValueChange = viewModel::onDeathStatusChange,
                                    label = "حالة الحياة / الوفاة",
                                    options = listOf("على قيد الحياة", "متوفى", "شهيد"),
                                    modifier = Modifier.weight(1f),
                                    leadingIcon = Icons.Rounded.HeartBroken,
                                    glassMode = true
                                )
                                GlassOutlinedTextField(
                                    value = formState.deathDate,
                                    onValueChange = viewModel::onDeathDateChange,
                                    label = "تاريخ الوفاة (إن وجد)",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.EventBusy,
                                    onClick = {
                                        showDatePicker(
                                            currentValue = formState.deathDate.ifBlank { "2024-01-01" },
                                            defaultYearsBack = 1
                                        ) {
                                            viewModel.onDeathDateChange(it)
                                        }
                                    },
                                    enabled = formState.deathStatus != "على قيد الحياة",
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.familyMembersCount,
                                    onValueChange = viewModel::onFamilyMembersCountChange,
                                    label = "عدد أفراد الأسرة *",
                                    isError = formState.membersCountError != null,
                                    errorMessage = formState.membersCountError,
                                    keyboardType = KeyboardType.Number,
                                    leadingIcon = Icons.Rounded.Groups,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                                GlassOutlinedTextField(
                                    value = formState.rationCardNumber,
                                    onValueChange = viewModel::onRationCardNumberChange,
                                    label = "رقم كرت المؤن / التموين",
                                    keyboardType = KeyboardType.Text,
                                    leadingIcon = Icons.Rounded.CreditCard,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }

                            GlassOutlinedTextField(
                                value = formState.wifeName,
                                onValueChange = viewModel::onWifeNameChange,
                                label = "اسم الزوج / الزوجة الرباعي",
                                leadingIcon = Icons.Rounded.Face,
                                glassMode = true
                            )

                            GlassOutlinedTextField(
                                value = formState.wifeNationalID,
                                onValueChange = viewModel::onWifeNationalIdChange,
                                label = "رقم هوية الزوج / الزوجة (9 أرقام)",
                                isError = formState.wifeNationalIdError != null,
                                errorMessage = formState.wifeNationalIdError,
                                keyboardType = KeyboardType.Number,
                                leadingIcon = Icons.Rounded.PermIdentity,
                                glassMode = true
                            )
                        }
                    }

                    // =========================================================================
                    // البطاقة 2: بيانات التواصل والنطاق الجغرافي والعنوان
                    // =========================================================================
                    item(key = "card_contact_and_location") {
                        LuxuryGlassCard {
                            GlassSectionHeader(
                                number = "2",
                                title = "بيانات التواصل والنطاق الجغرافي والعنوان",
                                subtitle = "الهواتف، المحلية المعتمدة، العنوان الحالي والعنوان الأصلي",
                                icon = Icons.Rounded.LocationOn,
                                accentColor = Color(0xFF38BDF8)
                            )

                            GlassOutlinedTextField(
                                value = formState.primaryPhone,
                                onValueChange = viewModel::onPrimaryPhoneChange,
                                label = "رقم الجوال الأساسي *",
                                isError = formState.phoneError != null,
                                errorMessage = formState.phoneError,
                                keyboardType = KeyboardType.Phone,
                                leadingIcon = Icons.Rounded.Phone,
                                glassMode = true
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.alternativePhone1,
                                    onValueChange = viewModel::onAlternativePhone1Change,
                                    label = "جوال بديل 1",
                                    keyboardType = KeyboardType.Phone,
                                    leadingIcon = Icons.Rounded.PhoneIphone,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                                GlassOutlinedTextField(
                                    value = formState.alternativePhone2,
                                    onValueChange = viewModel::onAlternativePhone2Change,
                                    label = "جوال بديل 2",
                                    keyboardType = KeyboardType.Phone,
                                    leadingIcon = Icons.Rounded.Call,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }

                            if (allowedLocalities.isNotEmpty()) {
                                val selectedLocName = allowedLocalities
                                    .firstOrNull { it.LocalityID == formState.selectedLocalityId }
                                    ?.LocalityName ?: allowedLocalities.first().LocalityName
                                GlassDropdownField(
                                    value = selectedLocName,
                                    onValueChange = { pickedName ->
                                        allowedLocalities.firstOrNull { it.LocalityName == pickedName }?.let {
                                            viewModel.onLocalitySelected(it)
                                        }
                                    },
                                    label = if (isLocalityLocked) "المحلية المعتمدة (مقيدة بصلاحيتك) *" else "المحلية المعتمدة *",
                                    options = allowedLocalities.map { it.LocalityName },
                                    leadingIcon = if (isLocalityLocked) Icons.Rounded.Lock else Icons.Rounded.LocationCity,
                                    enabled = !isLocalityLocked,
                                    glassMode = true
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.currentMainArea,
                                    onValueChange = viewModel::onCurrentMainAreaChange,
                                    label = "المحافظة / المنطقة الرئيسية",
                                    suggestions = governorateSuggestions,
                                    leadingIcon = Icons.Rounded.Map,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                                GlassEditableDropdownField(
                                    value = formState.currentSubArea,
                                    onValueChange = viewModel::onCurrentSubAreaChange,
                                    label = "المنطقة الفرعية / الحي *",
                                    suggestions = availableSubAreas,
                                    leadingIcon = Icons.Rounded.Place,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.currentBranch,
                                    onValueChange = viewModel::onCurrentBranchChange,
                                    label = if (isBranchLocked) "الشعبة الحالية (مقيدة)" else "الشعبة الحالية",
                                    suggestions = availableBranches.ifEmpty { availableSubAreas },
                                    leadingIcon = if (isBranchLocked) Icons.Rounded.Lock else Icons.Rounded.AltRoute,
                                    enabled = !isBranchLocked,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                                GlassOutlinedTextField(
                                    value = formState.currentMosque,
                                    onValueChange = viewModel::onCurrentMosqueChange,
                                    label = "المسجد الحالي",
                                    leadingIcon = Icons.Rounded.Mosque,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }

                            HorizontalDivider(
                                color = Color.White.copy(alpha = 0.16f),
                                thickness = 1.dp,
                                modifier = Modifier.padding(top = 4.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.History,
                                        contentDescription = null,
                                        tint = Color(0xFF38BDF8),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "العنوان الأصلي قبل النزوح",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                TextButton(
                                    onClick = { viewModel.copyCurrentAddressToOriginal() },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF6EE7B7))
                                ) {
                                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("نسخ الحالي", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.originalMainArea,
                                    onValueChange = viewModel::onOriginalMainAreaChange,
                                    label = "المحافظة / الرئيسية الأصلية",
                                    suggestions = governorateSuggestions,
                                    leadingIcon = Icons.Rounded.Map,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                                GlassOutlinedTextField(
                                    value = formState.originalSubArea,
                                    onValueChange = viewModel::onOriginalSubAreaChange,
                                    label = "المنطقة الفرعية الأصلية",
                                    leadingIcon = Icons.Rounded.Place,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.originalBranch,
                                    onValueChange = viewModel::onOriginalBranchChange,
                                    label = "الشعبة الأصلية",
                                    leadingIcon = Icons.Rounded.ShareLocation,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                                GlassOutlinedTextField(
                                    value = formState.originalMosque,
                                    onValueChange = viewModel::onOriginalMosqueChange,
                                    label = "المسجد الأصلي",
                                    leadingIcon = Icons.Rounded.Mosque,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }
                        }
                    }

                    // =========================================================================
                    // البطاقة 3: السكن والإيواء والأضرار والحالة الصحية
                    // =========================================================================
                    item(key = "card_shelter_damage_health") {
                        LuxuryGlassCard {
                            GlassSectionHeader(
                                number = "3",
                                title = "السكن والإيواء والأضرار والحالة الصحية",
                                subtitle = "صفة الإقامة، نوع الإيواء، تضرر المسكن، والإصابات",
                                icon = Icons.Rounded.HomeWork,
                                accentColor = Color(0xFFFBBF24)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassDropdownField(
                                    value = formState.residentStatus,
                                    onValueChange = viewModel::onResidentStatusChange,
                                    label = "صفة الإقامة",
                                    options = listOf("نازح", "مقيم", "عائد", "مستضاف"),
                                    leadingIcon = Icons.Rounded.PinDrop,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                                GlassDropdownField(
                                    value = formState.shelterStatus,
                                    onValueChange = viewModel::onShelterStatusChange,
                                    label = "نوع السكن / الإيواء",
                                    options = listOf(
                                        "إيواء داخلي",
                                        "خارج الإيواء",
                                        "خيمة",
                                        "مركز إيواء حكومي",
                                        "مخيم نزوح",
                                        "منزل مضيف",
                                        "بيت مستأجر",
                                        "منزل متضرر"
                                    ),
                                    leadingIcon = Icons.Rounded.Home,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }

                            GlassOutlinedTextField(
                                value = formState.shelterCenterName,
                                onValueChange = viewModel::onShelterCenterNameChange,
                                label = "اسم المخيم أو مركز / مدرسة الإيواء (إن وجد)",
                                leadingIcon = Icons.Rounded.HolidayVillage,
                                glassMode = true
                            )

                            GlassEditableDropdownField(
                                value = formState.damageType,
                                onValueChange = viewModel::onDamageTypeChange,
                                label = "حالة تضرر المسكن",
                                suggestions = listOf(
                                    "أضرار كلية",
                                    "أضرار جزئية بليغة",
                                    "أضرار جزئية غير صالحة للسكن",
                                    "أضرار جزئية صالحة للسكن",
                                    "أضرار طفيفة",
                                    "بلا أضرار"
                                ),
                                leadingIcon = Icons.Rounded.HomeWork,
                                glassMode = true
                            )

                            GlassOutlinedTextField(
                                value = formState.damageDescription,
                                onValueChange = viewModel::onDamageDescriptionChange,
                                label = "وصف تفاصيل أضرار المنزل",
                                leadingIcon = Icons.Rounded.ReportProblem,
                                singleLine = false,
                                minLines = 2,
                                glassMode = true
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.injuryStatus,
                                    onValueChange = viewModel::onInjuryStatusChange,
                                    label = "حالة الإصابة الصحية",
                                    suggestions = listOf("سليم", "مصاب", "شهيد", "إعاقة دائمة", "مريض مزمن"),
                                    leadingIcon = Icons.Rounded.LocalHospital,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                                GlassOutlinedTextField(
                                    value = formState.injuryDate,
                                    onValueChange = viewModel::onInjuryDateChange,
                                    label = "تاريخ الإصابة (إن وجد)",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.Event,
                                    onClick = {
                                        showDatePicker(
                                            currentValue = formState.injuryDate.ifBlank { "2024-01-01" },
                                            defaultYearsBack = 1
                                        ) {
                                            viewModel.onInjuryDateChange(it)
                                        }
                                    },
                                    enabled = formState.injuryStatus != "سليم" && formState.injuryStatus != "لا يوجد",
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }
                        }
                    }

                    // =========================================================================
                    // البطاقة 4: مصادر الدخل والاعتمادات الإدارية والملاحظات
                    // =========================================================================
                    item(key = "card_income_approvals_notes") {
                        LuxuryGlassCard {
                            GlassSectionHeader(
                                number = "4",
                                title = "مصادر الدخل والاعتمادات الإدارية والملاحظات",
                                subtitle = "مصادر الدخل، اعتمادات التنمية والمناطق والأشغال، والملاحظات",
                                icon = Icons.Rounded.Verified,
                                accentColor = Color(0xFFA78BFA)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.incomeSource1,
                                    onValueChange = viewModel::onIncomeSource1Change,
                                    label = "مصدر الدخل الأساسي (1)",
                                    suggestions = listOf(
                                        "بلا عمل",
                                        "عمال مياومة",
                                        "موظف حكومي",
                                        "موظف وكالة (الأونروا)",
                                        "أعمال حرة / تجارة",
                                        "متقاعد",
                                        "شؤون اجتماعية"
                                    ),
                                    leadingIcon = Icons.Rounded.Payments,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                                GlassOutlinedTextField(
                                    value = formState.incomeSource2,
                                    onValueChange = viewModel::onIncomeSource2Change,
                                    label = "مصدر الدخل الإضافي (2)",
                                    leadingIcon = Icons.Rounded.AccountBalanceWallet,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassDropdownField(
                                    value = formState.developmentApproval,
                                    onValueChange = viewModel::onDevelopmentApprovalChange,
                                    label = "اعتماد التنمية",
                                    options = listOf("معتمد", "مجمد", "حجب اعتماد", "قيد المراجعة"),
                                    leadingIcon = Icons.Rounded.Verified,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                                GlassDropdownField(
                                    value = formState.localityApproval,
                                    onValueChange = viewModel::onLocalityApprovalChange,
                                    label = "اعتماد المناطق / المحلية",
                                    options = listOf("معتمد", "قيد التدقيق", "مرفوض"),
                                    leadingIcon = Icons.Rounded.CheckCircle,
                                    modifier = Modifier.weight(1f),
                                    glassMode = true
                                )
                            }

                            GlassEditableDropdownField(
                                value = formState.worksApproval,
                                onValueChange = viewModel::onWorksApprovalChange,
                                label = "اعتماد وزارة الأشغال",
                                suggestions = listOf("اعتماد أشغال", "قيد التدقيق", "غير معتمد"),
                                leadingIcon = Icons.Rounded.Build,
                                glassMode = true
                            )

                            GlassOutlinedTextField(
                                value = formState.notes,
                                onValueChange = viewModel::onNotesChange,
                                label = "ملاحظات وتفاصيل ميدانية إضافية",
                                leadingIcon = Icons.Rounded.Notes,
                                singleLine = false,
                                minLines = 3,
                                glassMode = true
                            )
                        }
                    }

                    // =========================================================================
                    // زر الحفظ الرئيسي البارز بتدرج لوني فاخر
                    // =========================================================================
                    item(key = "save_button") {
                        val isEnabled = !formState.isSaving && canAddFamily
                        val buttonGradient = if (isEnabled) {
                            Brush.horizontalGradient(
                                colors = listOf(
                                    PalestineGreenDark,
                                    PalestineGreen,
                                    Color(0xFF0D9488)
                                )
                            )
                        } else {
                            Brush.horizontalGradient(
                                colors = listOf(
                                    SlateTextMuted.copy(alpha = 0.45f),
                                    SlateTextMuted.copy(alpha = 0.35f)
                                )
                            )
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .shadow(
                                    elevation = if (isEnabled) 8.dp else 0.dp,
                                    shape = RoundedCornerShape(18.dp),
                                    ambientColor = PalestineGreen.copy(alpha = 0.35f),
                                    spotColor = PalestineGreen.copy(alpha = 0.45f)
                                )
                                .clip(RoundedCornerShape(18.dp))
                                .background(buttonGradient)
                                .clickable(enabled = isEnabled) {
                                    viewModel.saveFamily {
                                        Toast.makeText(
                                            context,
                                            "تم حفظ بيانات الأسرة وكافة حقولها بنجاح!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        onNavigateBack()
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(horizontal = 20.dp)
                            ) {
                                if (formState.isSaving) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(22.dp),
                                        color = Color.White,
                                        strokeWidth = 2.5.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "جاري الحفظ الآمن في قاعدة البيانات...",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Rounded.Save,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = if (canAddFamily) "حفظ وتسجيل الأسرة الآن" else "ليس لديك صلاحية إضافة أسر في هذا النطاق",
                                        color = Color.White,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 16.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}

/**
 * بطاقة زجاجية فاخرة (Glassmorphism Card) بخلفية شبه شفافة وحدود بيضاء رفيعة وزوايا دائرية 24.dp
 */
@Composable
private fun LuxuryGlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        color = Color.White.copy(alpha = 0.1f),
        border = BorderStroke(
            width = 1.dp,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.45f),
                    Color.White.copy(alpha = 0.14f)
                )
            )
        ),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

/**
 * ترويسة زجاجية موحدة لكل بطاقة في نموذج الإضافة
 */
@Composable
private fun GlassSectionHeader(
    number: String,
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = accentColor.copy(alpha = 0.18f),
                border = BorderStroke(1.dp, accentColor.copy(alpha = 0.40f)),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(21.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "$number. $title",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFCBD5E1),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        HorizontalDivider(
            color = Color.White.copy(alpha = 0.16f),
            thickness = 1.dp
        )
    }
}

/**
 * حقل إدخال زجاجي أنيق متوافق مع نظام Glassmorphism ومستخدم في AddFamilyScreen و AddChildScreen
 */
@Composable
fun GlassOutlinedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    isError: Boolean = false,
    errorMessage: String? = null,
    readOnly: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    leadingIcon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    singleLine: Boolean = true,
    minLines: Int = 1,
    glassMode: Boolean = false
) {
    val isDark = isSystemInDarkTheme() || MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val interactionSource = remember { MutableInteractionSource() }

    if (onClick != null && enabled) {
        LaunchedEffect(interactionSource) {
            interactionSource.interactions.collect { interaction ->
                if (interaction is PressInteraction.Release) {
                    onClick()
                }
            }
        }
    }

    val focusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.14f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.85f)
        else -> Color.White.copy(alpha = 0.92f)
    }
    val unfocusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.08f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.62f)
        else -> Color.White.copy(alpha = 0.68f)
    }
    val borderUnfocused = when {
        glassMode -> Color.White.copy(alpha = 0.28f)
        isDark -> Color.White.copy(alpha = 0.2f)
        else -> SlateBorderSubtle.copy(alpha = 0.85f)
    }
    val accent = if (glassMode) Color(0xFF34D399) else PalestineGreen
    val errorAccent = if (glassMode) Color(0xFFFCA5A5) else PalestineRed
    val textColor = when {
        glassMode -> Color.White
        isDark -> Color.White
        else -> SlateTextPrimary
    }
    val unfocusedLabel = when {
        glassMode -> Color(0xFFCBD5E1)
        isDark -> Color(0xFF94A3B8)
        else -> SlateTextSecondary
    }

    Column(modifier = modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            readOnly = readOnly,
            enabled = enabled,
            isError = isError,
            singleLine = singleLine,
            minLines = minLines,
            interactionSource = interactionSource,
            leadingIcon = leadingIcon?.let {
                {
                    Icon(
                        imageVector = it,
                        contentDescription = null,
                        tint = if (isError) errorAccent else accent,
                        modifier = Modifier.size(19.dp)
                    )
                }
            },
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = textColor,
                unfocusedTextColor = textColor,
                disabledTextColor = textColor.copy(alpha = 0.65f),
                focusedContainerColor = focusedBg,
                unfocusedContainerColor = unfocusedBg,
                disabledContainerColor = unfocusedBg.copy(alpha = 0.45f),
                focusedBorderColor = accent,
                unfocusedBorderColor = borderUnfocused,
                disabledBorderColor = borderUnfocused.copy(alpha = 0.5f),
                errorBorderColor = errorAccent,
                focusedLabelColor = accent,
                unfocusedLabelColor = unfocusedLabel,
                disabledLabelColor = unfocusedLabel.copy(alpha = 0.6f),
                cursorColor = accent
            ),
            modifier = Modifier.fillMaxWidth()
        )
        if (isError && errorMessage != null) {
            Text(
                text = errorMessage,
                color = errorAccent,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(start = 8.dp, top = 3.dp)
            )
        }
    }
}

/**
 * حقل اختيار منسدل زجاجي GlassDropdownField متوافق مع AddChildScreen
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlassDropdownField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    options: List<String>,
    modifier: Modifier = Modifier.fillMaxWidth(),
    leadingIcon: ImageVector? = Icons.Default.List,
    enabled: Boolean = true,
    glassMode: Boolean = false
) {
    var expanded by remember { mutableStateOf(false) }
    val isDark = isSystemInDarkTheme() || MaterialTheme.colorScheme.surface.luminance() < 0.5f

    val focusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.14f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.85f)
        else -> Color.White.copy(alpha = 0.92f)
    }
    val unfocusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.08f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.62f)
        else -> Color.White.copy(alpha = 0.68f)
    }
    val borderUnfocused = when {
        glassMode -> Color.White.copy(alpha = 0.28f)
        isDark -> Color.White.copy(alpha = 0.2f)
        else -> SlateBorderSubtle.copy(alpha = 0.85f)
    }
    val accent = if (glassMode) Color(0xFF34D399) else PalestineGreen
    val textColor = when {
        glassMode -> Color.White
        isDark -> Color.White
        else -> SlateTextPrimary
    }
    val unfocusedLabel = when {
        glassMode -> Color(0xFFCBD5E1)
        isDark -> Color(0xFF94A3B8)
        else -> SlateTextSecondary
    }
    val menuBg = when {
        glassMode -> Color(0xFF0F2233)
        isDark -> Color(0xFF1E293B)
        else -> Color.White
    }

    ExposedDropdownMenuBox(
        expanded = expanded && enabled,
        onExpandedChange = { if (enabled) expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            singleLine = true,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = leadingIcon?.let {
                {
                    Icon(
                        imageVector = it,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(19.dp)
                    )
                }
            },
            trailingIcon = {
                if (enabled) {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = textColor,
                unfocusedTextColor = textColor,
                disabledTextColor = textColor.copy(alpha = 0.65f),
                focusedContainerColor = focusedBg,
                unfocusedContainerColor = unfocusedBg,
                disabledContainerColor = unfocusedBg.copy(alpha = 0.45f),
                focusedBorderColor = accent,
                unfocusedBorderColor = borderUnfocused,
                disabledBorderColor = borderUnfocused.copy(alpha = 0.5f),
                focusedLabelColor = accent,
                unfocusedLabelColor = unfocusedLabel,
                disabledLabelColor = unfocusedLabel.copy(alpha = 0.6f),
                focusedTrailingIconColor = accent,
                unfocusedTrailingIconColor = unfocusedLabel
            ),
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )

        ExposedDropdownMenu(
            expanded = expanded && enabled,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(menuBg)
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = option,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (option == value) FontWeight.Bold else FontWeight.Normal,
                                color = if (glassMode) Color.White else Color.Unspecified
                            )
                            if (option == value) {
                                Icon(
                                    imageVector = Icons.Rounded.Check,
                                    contentDescription = null,
                                    tint = accent,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    onClick = {
                        onValueChange(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

/**
 * حقل اختيار منسدل قابل للكتابة والبحث الفوري (Editable ExposedDropdownMenuBox)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GlassEditableDropdownField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    suggestions: List<String>,
    leadingIcon: ImageVector,
    modifier: Modifier = Modifier.fillMaxWidth(),
    enabled: Boolean = true,
    glassMode: Boolean = false
) {
    var expanded by remember { mutableStateOf(false) }
    val isDark = isSystemInDarkTheme() || MaterialTheme.colorScheme.surface.luminance() < 0.5f

    val filtered = remember(value, suggestions) {
        if (value.isBlank()) suggestions
        else {
            val trimmed = value.trim()
            val matched = suggestions.filter { it.contains(trimmed, ignoreCase = true) }
            if (matched.isNotEmpty()) matched else suggestions
        }
    }

    val focusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.14f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.85f)
        else -> Color.White.copy(alpha = 0.92f)
    }
    val unfocusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.08f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.62f)
        else -> Color.White.copy(alpha = 0.68f)
    }
    val borderUnfocused = when {
        glassMode -> Color.White.copy(alpha = 0.28f)
        isDark -> Color.White.copy(alpha = 0.2f)
        else -> SlateBorderSubtle.copy(alpha = 0.85f)
    }
    val accent = if (glassMode) Color(0xFF34D399) else PalestineGreen
    val textColor = when {
        glassMode -> Color.White
        isDark -> Color.White
        else -> SlateTextPrimary
    }
    val unfocusedLabel = when {
        glassMode -> Color(0xFFCBD5E1)
        isDark -> Color(0xFF94A3B8)
        else -> SlateTextSecondary
    }
    val menuBg = when {
        glassMode -> Color(0xFF0F2233)
        isDark -> Color(0xFF1E293B)
        else -> Color.White
    }

    ExposedDropdownMenuBox(
        expanded = expanded && enabled && filtered.isNotEmpty(),
        onExpandedChange = { if (enabled && filtered.isNotEmpty()) expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = {
                onValueChange(it)
                if (filtered.isNotEmpty()) expanded = true
            },
            readOnly = false,
            enabled = enabled,
            singleLine = true,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = leadingIcon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(19.dp)
                )
            },
            trailingIcon = {
                if (enabled && filtered.isNotEmpty()) {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = textColor,
                unfocusedTextColor = textColor,
                disabledTextColor = textColor.copy(alpha = 0.65f),
                focusedContainerColor = focusedBg,
                unfocusedContainerColor = unfocusedBg,
                disabledContainerColor = unfocusedBg.copy(alpha = 0.45f),
                focusedBorderColor = accent,
                unfocusedBorderColor = borderUnfocused,
                disabledBorderColor = borderUnfocused.copy(alpha = 0.5f),
                focusedLabelColor = accent,
                unfocusedLabelColor = unfocusedLabel,
                disabledLabelColor = unfocusedLabel.copy(alpha = 0.6f),
                focusedTrailingIconColor = accent,
                unfocusedTrailingIconColor = unfocusedLabel,
                cursorColor = accent
            ),
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )

        if (filtered.isNotEmpty()) {
            ExposedDropdownMenu(
                expanded = expanded && enabled,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(menuBg)
            ) {
                filtered.forEach { option ->
                    DropdownMenuItem(
                        text = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = option,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (option == value) FontWeight.Bold else FontWeight.Normal,
                                    color = if (glassMode) Color.White else Color.Unspecified
                                )
                                if (option == value) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = accent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        },
                        onClick = {
                            onValueChange(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}
