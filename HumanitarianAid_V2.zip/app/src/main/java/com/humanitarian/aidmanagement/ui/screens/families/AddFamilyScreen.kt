package com.humanitarian.aidmanagement.ui.screens.families

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.civilregistry.bridge.CivilRegistryDraftBridge
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryRecord
import com.humanitarian.aidmanagement.civilregistry.security.CivilRegistryPermissionGuard
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.calculateAgeFromBirthDate
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.ExcelParserHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Locale

/**
 * ViewModel شامل لإدارة كافة حقول نموذج إضافة أسرة جديدة
 * مع التحقق الفوري، العزل الجغرافي الصارم (RLS)، والتنفيذ غير المتزامن على Dispatchers.IO
 */
class AddFamilyViewModel(
    private val repository: AidRepository
) : ViewModel() {

    data class FormState(
        // 1. البيانات الأساسية ورب الأسرة
        val name: String = "",
        val nationalID: String = "",
        val birthDate: String = "1985-01-01",
        val gender: String = "ذكر",
        val maritalStatus: String = "متزوج",
        val deathStatus: String = "على قيد الحياة",
        val deathDate: String = "",

        // 2. بيانات الأسرة والزوج/الزوجة والمؤن
        val familyMembersCount: String = "5",
        val rationCardNumber: String = "",
        val wifeName: String = "",
        val wifeNationalID: String = "",

        // 3. بيانات التواصل والاتصال
        val primaryPhone: String = "",
        val alternativePhone1: String = "",
        val alternativePhone2: String = "",

        // 4. السكن والموقع الجغرافي والإيواء
        val selectedLocalityId: Int = 1,
        val localityName: String = "",
        val currentMainArea: String = "",
        val currentSubArea: String = "",
        val currentBranch: String = "",
        val currentMosque: String = "",
        val residentStatus: String = "نازح",
        val shelterStatus: String = "إيواء داخلي",
        val shelterCenterName: String = "",

        // 5. العنوان الأصلي قبل النزوح
        val originalMainArea: String = "",
        val originalSubArea: String = "",
        val originalBranch: String = "",
        val originalMosque: String = "",

        // 6. العمل والدخل والأضرار والإصابات
        val incomeSource1: String = "بلا عمل",
        val incomeSource2: String = "",
        val incomeDetails: String = "",
        val damageType: String = "أضرار كلية",
        val damageDescription: String = "",
        val injuryStatus: String = "سليم",
        val injuryDate: String = "",

        // 7. حالات الاعتماد الإداري والملاحظات
        val developmentApproval: String = "معتمد",
        val localityApproval: String = "معتمد",
        val worksApproval: String = "اعتماد أشغال",
        val notes: String = "",

        // أخطاء التحقق وحالة الحفظ
        val isSaving: Boolean = false,
        val saveSuccess: Boolean = false,
        val errorMessage: String? = null,
        val nameError: String? = null,
        val nationalIdError: String? = null,
        val wifeNationalIdError: String? = null,
        val phoneError: String? = null,
        val membersCountError: String? = null,

        // حالة المسودة المرحّلة من وحدة البحث في السجل المدني (غير محفوظة حتى يقرر المستخدم)
        val isFromCivilRegistryDraft: Boolean = false
    )

    private val _state = MutableStateFlow(FormState())
    val state: StateFlow<FormState> = _state.asStateFlow()

    private val _currentUserRegion = MutableStateFlow("ALL")
    val currentUserRegion: StateFlow<String> = _currentUserRegion.asStateFlow()

    private val _allowedRegionAliases = MutableStateFlow<List<String>>(emptyList())
    val allowedRegionAliases: StateFlow<List<String>> = _allowedRegionAliases.asStateFlow()

    private val _isRegionLocked = MutableStateFlow(false)
    val isRegionLocked: StateFlow<Boolean> = _isRegionLocked.asStateFlow()

    private val _allowedLocalities = MutableStateFlow<List<LocalityEntity>>(emptyList())
    val allowedLocalities: StateFlow<List<LocalityEntity>> = _allowedLocalities.asStateFlow()

    private val _isLocalityLocked = MutableStateFlow(false)
    val isLocalityLocked: StateFlow<Boolean> = _isLocalityLocked.asStateFlow()

    private val _availableSubAreas = MutableStateFlow<List<String>>(emptyList())
    val availableSubAreas: StateFlow<List<String>> = _availableSubAreas.asStateFlow()

    private val _availableBranches = MutableStateFlow<List<String>>(emptyList())
    val availableBranches: StateFlow<List<String>> = _availableBranches.asStateFlow()

    private val _isBranchLocked = MutableStateFlow(false)
    val isBranchLocked: StateFlow<Boolean> = _isBranchLocked.asStateFlow()

    private val _lockedBranchName = MutableStateFlow<String?>(null)
    val lockedBranchName: StateFlow<String?> = _lockedBranchName.asStateFlow()

    private val _maritalOptions = MutableStateFlow(listOf("متزوج", "أعزب", "أرمل", "مطلق", "مهجور"))
    val maritalOptions: StateFlow<List<String>> = _maritalOptions.asStateFlow()

    private val _governorateOptions = MutableStateFlow<List<String>>(emptyList())
    val governorateOptions: StateFlow<List<String>> = _governorateOptions.asStateFlow()

    private val _localityOptions = MutableStateFlow<List<String>>(emptyList())
    val localityOptions: StateFlow<List<String>> = _localityOptions.asStateFlow()

    private val _residentStatusOptions = MutableStateFlow(listOf("نازح", "مقيم", "عائد", "مستضاف"))
    val residentStatusOptions: StateFlow<List<String>> = _residentStatusOptions.asStateFlow()

    private val _shelterStatusOptions = MutableStateFlow(
        listOf("إيواء داخلي", "خارج الإيواء", "خيمة", "مركز إيواء حكومي", "مخيم نزوح", "منزل مضيف", "بيت مستأجر", "منزل متضرر")
    )
    val shelterStatusOptions: StateFlow<List<String>> = _shelterStatusOptions.asStateFlow()

    private val _damageTypeOptions = MutableStateFlow(
        listOf("أضرار كلية", "أضرار جزئية بليغة", "أضرار جزئية غير صالحة للسكن", "أضرار جزئية صالحة للسكن", "أضرار طفيفة", "بلا أضرار")
    )
    val damageTypeOptions: StateFlow<List<String>> = _damageTypeOptions.asStateFlow()

    private val _injuryStatusOptions = MutableStateFlow(listOf("سليم", "مصاب", "شهيد", "إعاقة دائمة", "مريض مزمن"))
    val injuryStatusOptions: StateFlow<List<String>> = _injuryStatusOptions.asStateFlow()

    private val _incomeSourceOptions = MutableStateFlow(
        listOf("بلا عمل", "لا يعمل", "عمال مياومة", "موظف حكومي", "موظف وكالة (الأونروا)", "أعمال حرة / تجارة", "متقاعد", "شؤون اجتماعية")
    )
    val incomeSourceOptions: StateFlow<List<String>> = _incomeSourceOptions.asStateFlow()

    private val _developmentApprovalOptions = MutableStateFlow(listOf("معتمد", "مجمد", "حجب اعتماد", "قيد المراجعة"))
    val developmentApprovalOptions: StateFlow<List<String>> = _developmentApprovalOptions.asStateFlow()

    private val _localityApprovalOptions = MutableStateFlow(listOf("معتمد", "قيد التدقيق", "مرفوض"))
    val localityApprovalOptions: StateFlow<List<String>> = _localityApprovalOptions.asStateFlow()

    private val _worksApprovalOptions = MutableStateFlow(listOf("اعتماد أشغال", "قيد التدقيق", "غير معتمد"))
    val worksApprovalOptions: StateFlow<List<String>> = _worksApprovalOptions.asStateFlow()

    init {
        loadScopeAndDynamicOptions()
        viewModelScope.launch {
            repository.currentUserFlow.drop(1).collect {
                loadScopeAndDynamicOptions()
            }
        }
    }

    private fun mergeOptions(dbValues: List<String>, defaults: List<String>): List<String> =
        (dbValues.map { it.trim() }.filter { it.isNotBlank() } + defaults).distinct()

    private fun loadScopeAndDynamicOptions() {
        viewModelScope.launch(Dispatchers.IO) {
            loadGeographicalScopeInternal()
            loadDynamicFieldOptionsInternal()
        }
    }

    private suspend fun loadDynamicFieldOptionsInternal() {
        try {
            val opts = repository.getDynamicExportFilterOptions()
            val distinctMainAreas = repository.getAllDistinctMainAreasSync()
            val distinctRegions = repository.getAllDistinctRegionsForAdminSync()
            val distinctSubAreas = repository.getAllDistinctSubAreasSync()
            val distinctBranches = repository.getAllDistinctBranchesUnrestrictedSync()

            _maritalOptions.value = mergeOptions(opts.maritalStatuses, listOf("متزوج", "أعزب", "أرمل", "مطلق", "مهجور"))
            _governorateOptions.value = distinctMainAreas
            _localityOptions.value = (distinctRegions + _allowedLocalities.value.map { it.LocalityName })
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .distinct()
                .sorted()
            _availableSubAreas.value = (_availableSubAreas.value + distinctSubAreas)
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .distinct()
            _availableBranches.value = (_availableBranches.value + distinctBranches)
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .distinct()

            _residentStatusOptions.value = mergeOptions(opts.residentStatuses, listOf("نازح", "مقيم", "عائد", "مستضاف"))
            _shelterStatusOptions.value = mergeOptions(
                opts.shelterStatuses,
                listOf("إيواء داخلي", "خارج الإيواء", "خيمة", "مركز إيواء حكومي", "مخيم نزوح", "منزل مضيف", "بيت مستأجر", "منزل متضرر")
            )
            _damageTypeOptions.value = mergeOptions(
                opts.damageTypes,
                listOf("أضرار كلية", "أضرار جزئية بليغة", "أضرار جزئية غير صالحة للسكن", "أضرار جزئية صالحة للسكن", "أضرار طفيفة", "بلا أضرار")
            )
            _injuryStatusOptions.value = mergeOptions(opts.injuryStatuses, listOf("سليم", "مصاب", "شهيد", "إعاقة دائمة", "مريض مزمن"))
            _incomeSourceOptions.value = mergeOptions(
                opts.incomeSources,
                listOf("بلا عمل", "لا يعمل", "عمال مياومة", "موظف حكومي", "موظف وكالة (الأونروا)", "أعمال حرة / تجارة", "متقاعد", "شؤون اجتماعية")
            )
            _developmentApprovalOptions.value = mergeOptions(opts.approvals, listOf("معتمد", "مجمد", "حجب اعتماد", "قيد المراجعة"))
            _localityApprovalOptions.value = mergeOptions(opts.localityApprovals, listOf("معتمد", "قيد التدقيق", "مرفوض"))
            _worksApprovalOptions.value = mergeOptions(opts.worksApprovals, listOf("اعتماد أشغال", "قيد التدقيق", "غير معتمد"))
        } catch (_: Exception) {
        }
    }

    private fun isAllScopeToken(value: String?): Boolean {
        val t = value?.trim() ?: return true
        return t.isBlank() || t.equals("ALL", ignoreCase = true) || t == "الكل" || t == "*"
    }

    private suspend fun loadGeographicalScopeInternal() {
        try {
            val locs = repository.getAllowedLocalitiesSync()
            val currentUser = repository.getCurrentUser()
            val isManager = repository.isSuperAdmin() || currentUser?.RoleID == 1
            val rawRegion = currentUser?.region?.trim().orEmpty()
            val cleanAllowedLocs = currentUser?.allowedLocalities
                ?.map { it.trim() }
                ?.filter { !isAllScopeToken(it) }
                ?.distinct()
                .orEmpty()

            val currentRegion = when {
                isManager -> "ALL"
                !isAllScopeToken(rawRegion) -> rawRegion
                cleanAllowedLocs.size == 1 -> cleanAllowedLocs.first()
                cleanAllowedLocs.isNotEmpty() -> cleanAllowedLocs.joinToString("، ")
                locs.size == 1 && (currentUser?.AllowedLocalityID ?: 0) > 0 -> locs.first().LocalityName.trim()
                else -> "ALL"
            }
            val regionLocked = currentRegion != "ALL"

            val aliases = buildList {
                if (!isAllScopeToken(rawRegion)) add(rawRegion)
                addAll(cleanAllowedLocs)
                if (regionLocked && locs.size == 1 && (currentUser?.AllowedLocalityID ?: 0) > 0) {
                    add(locs.first().LocalityName.trim())
                }
            }.map { it.trim() }.filter { it.isNotBlank() }.distinct()
            _allowedRegionAliases.value = aliases

            val rawSubRegion = currentUser?.sub_region?.trim().orEmpty()
            val currentSubRegion = rawSubRegion.takeIf { !isAllScopeToken(it) } ?: "ALL"

            _currentUserRegion.value = currentRegion
            _isRegionLocked.value = regionLocked

            val isRestricted = regionLocked || (currentUser?.AllowedLocalityID ?: 0) != 0

            _allowedLocalities.value = locs
            _isLocalityLocked.value = isRestricted && (regionLocked || locs.size <= 1)

            val matchedByRegion = if (regionLocked) {
                locs.firstOrNull { it.LocalityName.trim().equals(currentRegion, ignoreCase = true) }
            } else null

            val currentSel = _state.value.selectedLocalityId
            val validSelected = matchedByRegion
                ?: locs.firstOrNull { it.LocalityID == currentSel }
                ?: locs.firstOrNull()

            if (validSelected != null) {
                _state.update { s ->
                    val defaultName = if (regionLocked) currentRegion else validSelected.LocalityName
                    s.copy(
                        selectedLocalityId = validSelected.LocalityID,
                        localityName = s.localityName.ifBlank { defaultName },
                        currentMainArea = if (regionLocked && s.currentMainArea.isBlank()) currentRegion else s.currentMainArea.ifBlank { defaultName },
                        currentSubArea = if (regionLocked && s.currentSubArea.isBlank()) currentRegion else s.currentSubArea
                    )
                }
                loadLocalityDetails(validSelected.LocalityID, validSelected.LocalityName)
            } else {
                if (regionLocked) {
                    _state.update { s ->
                        s.copy(
                            localityName = s.localityName.ifBlank { currentRegion },
                            currentMainArea = s.currentMainArea.ifBlank { currentRegion },
                            currentSubArea = s.currentSubArea.ifBlank { currentRegion }
                        )
                    }
                }
                loadBranchRestrictionsOnly()
            }

            if (currentSubRegion != "ALL") {
                _isBranchLocked.value = true
                _lockedBranchName.value = currentSubRegion
                _state.update { it.copy(currentBranch = it.currentBranch.ifBlank { currentSubRegion }) }
            }
        } catch (_: Exception) {
        }
    }

    private suspend fun loadLocalityDetails(localityId: Int, localityName: String) {
        val localSubAreas = repository.getSubAreasByLocality(localityId)
        _availableSubAreas.value = (localSubAreas + _availableSubAreas.value)
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()

        val branches = repository.getDistinctBranchesForLocalityUnrestrictedSync(localityName)
        val (ignoreBr, allowedBranches) = repository.getEffectiveBranchScope()
        val validAllowedBranches = allowedBranches.filter { it != "__DENY__" && it != "__ALL__" }

        val mergedBranches = (branches + validAllowedBranches + _availableBranches.value)
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
        _availableBranches.value = mergedBranches

        if (ignoreBr == 0 && validAllowedBranches.isNotEmpty()) {
            if (validAllowedBranches.size == 1) {
                val singleBranch = validAllowedBranches.first()
                _isBranchLocked.value = true
                _lockedBranchName.value = singleBranch
                _state.update { it.copy(currentBranch = it.currentBranch.ifBlank { singleBranch }) }
            } else {
                _isBranchLocked.value = false
                _lockedBranchName.value = null
                val cur = _state.value.currentBranch
                if (cur.isBlank()) {
                    _state.update { it.copy(currentBranch = validAllowedBranches.first()) }
                }
            }
        } else {
            _isBranchLocked.value = false
            _lockedBranchName.value = null
        }
    }

    private suspend fun loadBranchRestrictionsOnly() {
        val (ignoreBr, allowedBranches) = repository.getEffectiveBranchScope()
        val validAllowedBranches = allowedBranches.filter { it != "__DENY__" && it != "__ALL__" }
        _availableBranches.value = (validAllowedBranches + _availableBranches.value)
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
        if (ignoreBr == 0 && validAllowedBranches.size == 1) {
            val singleBranch = validAllowedBranches.first()
            _isBranchLocked.value = true
            _lockedBranchName.value = singleBranch
            _state.update { it.copy(currentBranch = it.currentBranch.ifBlank { singleBranch }) }
        }
    }

    // دوال تحديث كافة الحقول
    fun onNameChange(v: String) = _state.update { it.copy(name = v, nameError = null, errorMessage = null) }
    fun onNationalIdChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() }.take(9)
        _state.update { it.copy(nationalID = cleaned, nationalIdError = null, errorMessage = null) }
        if (cleaned.length == 9) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    val existing = repository.getFamilyByNationalId(cleaned)
                    if (existing != null && _state.value.nationalID == cleaned) {
                        _state.update {
                            it.copy(nationalIdError = "عذراً، رقم الهوية مسجل مسبقاً في النظام!")
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }
    }
    fun onBirthDateChange(v: String) = _state.update { it.copy(birthDate = v) }
    fun onGenderChange(v: String) = _state.update { it.copy(gender = v) }
    fun onMaritalStatusChange(v: String) = _state.update { it.copy(maritalStatus = v) }
    fun onDeathStatusChange(v: String) = _state.update {
        it.copy(
            deathStatus = v,
            deathDate = if (v == "على قيد الحياة") "" else it.deathDate
        )
    }
    fun onDeathDateChange(v: String) = _state.update { it.copy(deathDate = v) }

    fun onFamilyMembersCountChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() }.take(2)
        _state.update { it.copy(familyMembersCount = cleaned, membersCountError = null) }
    }
    fun onRationCardNumberChange(v: String) = _state.update { it.copy(rationCardNumber = v) }
    fun onWifeNameChange(v: String) = _state.update { it.copy(wifeName = v) }
    fun onWifeNationalIdChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() }.take(9)
        _state.update { it.copy(wifeNationalID = cleaned, wifeNationalIdError = null) }
    }

    fun onPrimaryPhoneChange(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() || it == '+' }.take(15)
        _state.update { it.copy(primaryPhone = cleaned, phoneError = null) }
    }
    fun onAlternativePhone1Change(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() || it == '+' }.take(15)
        _state.update { it.copy(alternativePhone1 = cleaned) }
    }
    fun onAlternativePhone2Change(v: String) {
        val cleaned = ExcelParserHelper.convertEasternToArabicDigits(v).filter { it.isDigit() || it == '+' }.take(15)
        _state.update { it.copy(alternativePhone2 = cleaned) }
    }

    fun onLocalitySelected(locality: LocalityEntity) {
        _state.update {
            it.copy(
                selectedLocalityId = locality.LocalityID,
                localityName = locality.LocalityName,
                currentMainArea = it.currentMainArea.ifBlank { locality.LocalityName },
                errorMessage = null
            )
        }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                loadLocalityDetails(locality.LocalityID, locality.LocalityName)
            } catch (_: Exception) {
            }
        }
    }

    fun onLocalityNameChange(v: String) {
        val matched = _allowedLocalities.value.firstOrNull {
            it.LocalityName.trim().equals(v.trim(), ignoreCase = true)
        }
        _state.update {
            it.copy(
                localityName = v,
                selectedLocalityId = matched?.LocalityID ?: it.selectedLocalityId,
                errorMessage = null
            )
        }
        if (matched != null) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    loadLocalityDetails(matched.LocalityID, matched.LocalityName)
                } catch (_: Exception) {
                }
            }
        }
    }

    fun onCurrentMainAreaChange(v: String) {
        _state.update { it.copy(currentMainArea = v, errorMessage = null) }
    }
    fun onCurrentSubAreaChange(v: String) = _state.update { it.copy(currentSubArea = v, errorMessage = null) }
    fun onCurrentBranchChange(v: String) {
        _state.update { it.copy(currentBranch = v, errorMessage = null) }
    }
    fun onCurrentMosqueChange(v: String) = _state.update { it.copy(currentMosque = v) }
    fun onResidentStatusChange(v: String) = _state.update { it.copy(residentStatus = v) }
    fun onShelterStatusChange(v: String) = _state.update { it.copy(shelterStatus = v) }
    fun onShelterCenterNameChange(v: String) = _state.update { it.copy(shelterCenterName = v) }

    fun onOriginalMainAreaChange(v: String) = _state.update { it.copy(originalMainArea = v) }
    fun onOriginalSubAreaChange(v: String) = _state.update { it.copy(originalSubArea = v) }
    fun onOriginalBranchChange(v: String) = _state.update { it.copy(originalBranch = v) }
    fun onOriginalMosqueChange(v: String) = _state.update { it.copy(originalMosque = v) }

    fun copyCurrentAddressToOriginal() {
        _state.update {
            it.copy(
                originalMainArea = it.currentMainArea,
                originalSubArea = it.currentSubArea,
                originalBranch = it.currentBranch,
                originalMosque = it.currentMosque
            )
        }
    }

    fun onIncomeSource1Change(v: String) = _state.update { it.copy(incomeSource1 = v) }
    fun onIncomeSource2Change(v: String) = _state.update { it.copy(incomeSource2 = v) }
    fun onIncomeDetailsChange(v: String) = _state.update { it.copy(incomeDetails = v) }
    fun onDamageTypeChange(v: String) = _state.update { it.copy(damageType = v) }
    fun onDamageDescriptionChange(v: String) = _state.update { it.copy(damageDescription = v) }
    fun onInjuryStatusChange(v: String) = _state.update {
        it.copy(
            injuryStatus = v,
            injuryDate = if (v == "سليم" || v == "لا يوجد") "" else it.injuryDate
        )
    }
    fun onInjuryDateChange(v: String) = _state.update { it.copy(injuryDate = v) }

    fun onDevelopmentApprovalChange(v: String) = _state.update { it.copy(developmentApproval = v) }
    fun onLocalityApprovalChange(v: String) = _state.update { it.copy(localityApproval = v) }
    fun onWorksApprovalChange(v: String) = _state.update { it.copy(worksApproval = v) }
    fun onNotesChange(v: String) = _state.update { it.copy(notes = v) }

    fun saveFamily(onSuccess: () -> Unit) {
        val current = _state.value
        val cleanName = current.name.trim()
        val cleanNationalId = ExcelParserHelper.normalizeNationalId(current.nationalID)
        val cleanWifeNationalId = ExcelParserHelper.normalizeNationalId(current.wifeNationalID)
        val cleanPhone = current.primaryPhone.trim()
        val parsedMembers = current.familyMembersCount.trim().toIntOrNull()

        var nameErr: String? = null
        var natErr: String? = null
        var wifeNatErr: String? = null
        var phoneErr: String? = null
        var membersErr: String? = null
        var hasError = false

        if (cleanName.length < 5) {
            nameErr = "يرجى كتابة الاسم الرباعي لرب الأسرة (5 أحرف على الأقل)"
            hasError = true
        }
        if (cleanNationalId.length != 9) {
            natErr = "رقم الهوية الوطنية يجب أن يتكون من 9 أرقام بالضبط"
            hasError = true
        }
        if (current.wifeNationalID.isNotBlank() && cleanWifeNationalId.length != 9) {
            wifeNatErr = "رقم هوية الزوج/الزوجة يجب أن يتكون من 9 أرقام"
            hasError = true
        }
        if (cleanPhone.filter { it.isDigit() }.length < 9) {
            phoneErr = "يرجى إدخال رقم جوال أساسي صحيح (9 أرقام على الأقل)"
            hasError = true
        }
        if (parsedMembers == null || parsedMembers <= 0) {
            membersErr = "عدد أفراد الأسرة يجب أن يكون 1 على الأقل"
            hasError = true
        }

        if (hasError) {
            _state.update {
                it.copy(
                    nameError = nameErr,
                    nationalIdError = natErr,
                    wifeNationalIdError = wifeNatErr,
                    phoneError = phoneErr,
                    membersCountError = membersErr,
                    errorMessage = "يرجى استكمال وتصحيح الحقول الإلزامية المميزة باللون الأحمر"
                )
            }
            return
        }

        val userRegion = _currentUserRegion.value
        val currentUser = repository.getCurrentUser()
        val isManager = repository.isSuperAdmin() || currentUser?.RoleID == 1
        val aliases = _allowedRegionAliases.value
        val cleanMainInput = current.currentMainArea.trim()
        val cleanLocalityInput = current.localityName.trim()
        val isMainOk = userRegion == "ALL" || isManager || cleanMainInput.isBlank() ||
            cleanMainInput.equals(userRegion, ignoreCase = true) ||
            aliases.any { it.equals(cleanMainInput, ignoreCase = true) }
        val isLocOk = userRegion == "ALL" || isManager || cleanLocalityInput.isBlank() ||
            cleanLocalityInput.equals(userRegion, ignoreCase = true) ||
            aliases.any { it.equals(cleanLocalityInput, ignoreCase = true) }
        if (!isMainOk || !isLocOk) {
            _state.update {
                it.copy(errorMessage = "لا تمتلك صلاحية الإضافة في هذه المنطقة (نطاقك المخصص: $userRegion)")
            }
            return
        }

        if (!isManager && userRegion != "ALL" && !repository.canAddFamilyInLocality(current.selectedLocalityId)) {
            _state.update {
                it.copy(errorMessage = "لا تمتلك صلاحية الإضافة في هذه المنطقة (نطاقك المخصص: $userRegion)")
            }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _state.update {
                it.copy(
                    isSaving = true,
                    errorMessage = null,
                    nameError = null,
                    nationalIdError = null,
                    wifeNationalIdError = null,
                    phoneError = null,
                    membersCountError = null
                )
            }
            try {
                val existing = repository.getFamilyByNationalId(cleanNationalId)
                if (existing != null) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            nationalIdError = "عذراً، رقم الهوية مسجل مسبقاً في النظام!",
                            errorMessage = "عذراً، رقم الهوية مسجل مسبقاً في النظام! (مسجل باسم: ${existing.name})"
                        )
                    }
                    return@launch
                }

                val targetLocalityName = cleanLocalityInput.ifBlank { cleanMainInput }
                val resolvedLocalityId = repository.resolveOrCreateLocalityId(
                    localityName = targetLocalityName,
                    fallbackLocalityId = current.selectedLocalityId,
                    createIfMissing = (userRegion == "ALL" || isManager)
                )

                val effectiveBranch = current.currentBranch.trim()

                val cleanIncome1 = current.incomeSource1.trim()
                val cleanIncome2 = current.incomeSource2.trim()
                val cleanIncomeDetails = current.incomeDetails.trim()
                val resolvedIncome1 = cleanIncome1.ifBlank { cleanIncomeDetails }.ifBlank { "بلا عمل" }
                val resolvedIncome2 = cleanIncome2.ifBlank {
                    cleanIncomeDetails.takeIf { it.isNotBlank() && it != resolvedIncome1 }.orEmpty()
                }.ifBlank { null }

                val combinedNotes = listOfNotNull(
                    cleanIncomeDetails.takeIf { it.isNotBlank() && it != resolvedIncome1 && it != resolvedIncome2 }
                        ?.let { "مصادر الدخل: $it" },
                    current.notes.trim().takeIf { it.isNotBlank() }
                ).joinToString(" | ").ifBlank { null }

                val resolvedMainArea = cleanMainInput.ifBlank { targetLocalityName }
                val resolvedSubArea = current.currentSubArea.trim()
                    .ifBlank { targetLocalityName }
                    .ifBlank { resolvedMainArea }

                val newFamily = FamilyEntity(
                    nationalID = cleanNationalId,
                    name = cleanName,
                    gender = current.gender.trim(),
                    date_of_birth = current.birthDate.trim().ifBlank { "1985-01-01" },
                    maritalStatus = current.maritalStatus.trim(),
                    deathStatus = current.deathStatus.trim(),
                    deathDate = current.deathDate.trim().ifBlank { null },
                    primary_phone = cleanPhone,
                    alternative_phone_1 = current.alternativePhone1.trim().ifBlank { null },
                    alternative_phone_2 = current.alternativePhone2.trim().ifBlank { null },
                    wifeName = current.wifeName.trim().ifBlank { null },
                    wifeNationalID = cleanWifeNationalId.ifBlank { null },
                    familyMembersCount = parsedMembers ?: 1,
                    damageType = current.damageType.trim(),
                    damageDescription = current.damageDescription.trim().ifBlank { null },
                    injuryStatus = current.injuryStatus.trim(),
                    injuryDate = current.injuryDate.trim().ifBlank { null },
                    incomeSource1 = resolvedIncome1,
                    income_source_2 = resolvedIncome2,
                    rationCardNumber = current.rationCardNumber.trim().ifBlank { null },
                    originalMainArea = current.originalMainArea.trim(),
                    originalSubArea = current.originalSubArea.trim(),
                    originalBranch = current.originalBranch.trim(),
                    originalMosque = current.originalMosque.trim(),
                    currentMainArea = resolvedMainArea,
                    currentSubArea = resolvedSubArea,
                    currentBranch = effectiveBranch,
                    currentMosque = current.currentMosque.trim(),
                    developmentApproval = current.developmentApproval.trim(),
                    localityApproval = current.localityApproval.trim(),
                    residentStatus = current.residentStatus.trim(),
                    worksApproval = current.worksApproval.trim(),
                    shelterStatus = current.shelterStatus.trim(),
                    shelter_center_name = current.shelterCenterName.trim().ifBlank { null },
                    notes = combinedNotes,
                    localityID = resolvedLocalityId,
                    createdDate = System.currentTimeMillis(),
                    modifiedDate = null
                )

                repository.insertFamily(newFamily)
                loadDynamicFieldOptionsInternal()

                withContext(Dispatchers.Main) {
                    _state.update { it.copy(isSaving = false, saveSuccess = true) }
                    onSuccess()
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            errorMessage = t.localizedMessage ?: "حدث خطأ غير متوقع أثناء حفظ بيانات الأسرة"
                        )
                    }
                }
            }
        }
    }

    /**
     * واجهة توافقية للإدخال المباشر على Dispatchers.IO
     */
    fun insertFamily(
        family: FamilyEntity,
        onSuccess: () -> Unit
    ) {
        val cleanNationalId = ExcelParserHelper.normalizeNationalId(family.nationalID)
        if (cleanNationalId.length != 9) {
            _state.update { it.copy(nationalIdError = "رقم الهوية الوطنية يجب أن يتكون من 9 أرقام") }
            return
        }
        if (family.name.trim().length < 5) {
            _state.update { it.copy(nameError = "يرجى كتابة الاسم الرباعي بشكل صحيح") }
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(isSaving = true, errorMessage = null, nationalIdError = null, nameError = null) }
            try {
                val existing = repository.getFamilyByNationalId(cleanNationalId)
                if (existing != null) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            nationalIdError = "عذراً، رقم الهوية مسجل مسبقاً في النظام!",
                            errorMessage = "عذراً، رقم الهوية مسجل مسبقاً في النظام! (مسجل باسم: ${existing.name})"
                        )
                    }
                    return@launch
                }
                val normalized = family.copy(
                    nationalID = cleanNationalId,
                    wifeNationalID = family.wifeNationalID?.let { ExcelParserHelper.normalizeNationalId(it) }?.ifBlank { null }
                )
                repository.insertFamily(normalized)
                withContext(Dispatchers.Main) {
                    _state.update { it.copy(isSaving = false, saveSuccess = true) }
                    onSuccess()
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            errorMessage = t.localizedMessage ?: "حدث خطأ أثناء حفظ الأسرة في قاعدة البيانات"
                        )
                    }
                }
            }
        }
    }

    /**
     * تعبئة النموذج كمسودة قابلة للتعديل من سجل مرحّل من السجل المدني (Draft / Unsaved State)
     * لا يتم حفظ أي بيانات تلقائياً ولا يتم المساس بقاعدة civil_registry.db.
     */
    fun applyCivilRegistryDraft(record: CivilRegistryRecord) {
        val cleanNatId = ExcelParserHelper.convertEasternToArabicDigits(record.nationalId.removeSuffix(".0"))
            .filter { it.isDigit() }
            .take(9)
        val cleanWifeId = ExcelParserHelper.convertEasternToArabicDigits(record.wifeNationalId.removeSuffix(".0"))
            .filter { it.isDigit() }
            .take(9)
        val cleanMobile = ExcelParserHelper.convertEasternToArabicDigits(record.mobilePhone.removeSuffix(".0"))
            .filter { it.isDigit() }
        val cleanDevPhone = ExcelParserHelper.convertEasternToArabicDigits(record.developmentPhone.removeSuffix(".0"))
            .filter { it.isDigit() }

        val resolvedPrimaryPhone = cleanMobile.ifBlank { cleanDevPhone }
        val resolvedAltPhone1 = if (cleanMobile.isNotBlank() && cleanDevPhone.isNotBlank() && cleanDevPhone != cleanMobile) {
            cleanDevPhone
        } else {
            ""
        }
        val cleanMembers = ExcelParserHelper.convertEasternToArabicDigits(record.familyMembersCount.removeSuffix(".0"))
            .filter { it.isDigit() }
            .ifBlank { "1" }
        val cleanMainArea = record.mainArea.trim()

        _state.update { current ->
            current.copy(
                name = record.name.trim(),
                nationalID = cleanNatId,
                birthDate = record.birthDate.trim().ifBlank { current.birthDate },
                gender = record.gender.trim().ifBlank { current.gender },
                maritalStatus = record.maritalStatus.trim().ifBlank { current.maritalStatus },
                deathStatus = record.deathStatus.trim().ifBlank { current.deathStatus },
                deathDate = record.deathDate.trim(),
                primaryPhone = resolvedPrimaryPhone,
                alternativePhone1 = resolvedAltPhone1,
                wifeName = record.wifeName.trim(),
                wifeNationalID = cleanWifeId,
                familyMembersCount = cleanMembers,
                developmentApproval = record.developmentApprovalStatus.trim().ifBlank { current.developmentApproval },
                originalMainArea = cleanMainArea.ifBlank { current.originalMainArea },
                currentMainArea = if (!_isRegionLocked.value && cleanMainArea.isNotBlank()) cleanMainArea else current.currentMainArea,
                errorMessage = null,
                nameError = null,
                nationalIdError = null,
                wifeNationalIdError = null,
                phoneError = null,
                membersCountError = null,
                isFromCivilRegistryDraft = true
            )
        }

        // فحص استباقي غير متزامن لبيان إن كان رقم الهوية موجوداً مسبقاً في قاعدة المشروع
        if (cleanNatId.length == 9) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    val existing = repository.getFamilyByNationalId(cleanNatId)
                    if (existing != null && _state.value.nationalID == cleanNatId) {
                        _state.update {
                            it.copy(nationalIdError = "تنبيه: رقم الهوية مسجل مسبقاً في المشروع باسم (${existing.name})")
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    fun clearState() {
        val locId = _allowedLocalities.value.firstOrNull()?.LocalityID ?: 1
        val locName = if (_isRegionLocked.value) _currentUserRegion.value else _allowedLocalities.value.firstOrNull()?.LocalityName.orEmpty()
        val lockedBranch = if (_isBranchLocked.value) _lockedBranchName.value.orEmpty() else ""
        _state.value = FormState(
            selectedLocalityId = locId,
            localityName = locName,
            currentMainArea = locName,
            currentSubArea = if (_isRegionLocked.value) _currentUserRegion.value else "",
            currentBranch = lockedBranch,
            isFromCivilRegistryDraft = false
        )
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AddFamilyViewModel(repository) as T
        }
    }
}

/**
 * شاشة إضافة أسرة جديدة بتصميم الزجاج المكسر الفاتح الهادئ (Light Glassmorphism)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFamilyScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onOpenCivilRegistryLookup: (() -> Unit)? = null,
    viewModel: AddFamilyViewModel = viewModel(factory = AddFamilyViewModel.Factory(repository))
) {
    val context = LocalContext.current
    val formState by viewModel.state.collectAsStateWithLifecycle()
    val pendingCivilDraft by CivilRegistryDraftBridge.pendingDraft.collectAsStateWithLifecycle()
    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val acmPermissions by AccessControlManager.permissionsFlow.collectAsStateWithLifecycle()
    val canAccessCivilRegistry = remember(currentUser, acmPermissions) {
        CivilRegistryPermissionGuard.canAccessCivilRegistry(
            user = currentUser,
            permissions = acmPermissions
        )
    }
    val isCivilRegistryDraftActive = canAccessCivilRegistry && formState.isFromCivilRegistryDraft
    var showSaveDecisionDialog by remember { mutableStateOf(false) }

    LaunchedEffect(pendingCivilDraft, canAccessCivilRegistry) {
        if (pendingCivilDraft != null) {
            if (canAccessCivilRegistry) {
                CivilRegistryDraftBridge.consumeDraft()?.let { stagedRecord ->
                    viewModel.applyCivilRegistryDraft(stagedRecord)
                }
            } else {
                CivilRegistryDraftBridge.clearDraft()
            }
        }
    }
    val currentUserRegion by viewModel.currentUserRegion.collectAsStateWithLifecycle()
    val allowedRegionAliases by viewModel.allowedRegionAliases.collectAsStateWithLifecycle()
    val isRegionLocked by viewModel.isRegionLocked.collectAsStateWithLifecycle()
    val allowedLocalities by viewModel.allowedLocalities.collectAsStateWithLifecycle()
    val isLocalityLocked by viewModel.isLocalityLocked.collectAsStateWithLifecycle()
    val availableSubAreas by viewModel.availableSubAreas.collectAsStateWithLifecycle()
    val availableBranches by viewModel.availableBranches.collectAsStateWithLifecycle()
    val isBranchLocked by viewModel.isBranchLocked.collectAsStateWithLifecycle()
    val lockedBranchName by viewModel.lockedBranchName.collectAsStateWithLifecycle()
    val maritalOptions by viewModel.maritalOptions.collectAsStateWithLifecycle()
    val governorateSuggestions by viewModel.governorateOptions.collectAsStateWithLifecycle()
    val localitySuggestions by viewModel.localityOptions.collectAsStateWithLifecycle()
    val residentStatusOptions by viewModel.residentStatusOptions.collectAsStateWithLifecycle()
    val shelterStatusOptions by viewModel.shelterStatusOptions.collectAsStateWithLifecycle()
    val damageTypeOptions by viewModel.damageTypeOptions.collectAsStateWithLifecycle()
    val injuryStatusOptions by viewModel.injuryStatusOptions.collectAsStateWithLifecycle()
    val incomeSourceOptions by viewModel.incomeSourceOptions.collectAsStateWithLifecycle()
    val developmentApprovalOptions by viewModel.developmentApprovalOptions.collectAsStateWithLifecycle()
    val localityApprovalOptions by viewModel.localityApprovalOptions.collectAsStateWithLifecycle()
    val worksApprovalOptions by viewModel.worksApprovalOptions.collectAsStateWithLifecycle()

    val userRegion = currentUserRegion
    val isManager = remember(currentUser) {
        repository.isSuperAdmin() || currentUser?.RoleID == 1
    }
    val enteredMainArea = formState.currentMainArea.trim()
    val enteredLocality = formState.localityName.trim()
    val isMainAreaAllowed = remember(userRegion, isManager, enteredMainArea, allowedRegionAliases) {
        userRegion == "ALL" || isManager || enteredMainArea.isBlank() ||
            enteredMainArea.equals(userRegion, ignoreCase = true) ||
            allowedRegionAliases.any { it.equals(enteredMainArea, ignoreCase = true) }
    }
    val isLocalityAllowed = remember(userRegion, isManager, enteredLocality, allowedRegionAliases) {
        userRegion == "ALL" || isManager || enteredLocality.isBlank() ||
            enteredLocality.equals(userRegion, ignoreCase = true) ||
            allowedRegionAliases.any { it.equals(enteredLocality, ignoreCase = true) }
    }
    val isRegionAllowed = (userRegion == "ALL" || isManager || (isMainAreaAllowed && isLocalityAllowed))

    val canAddFamily = remember(currentUser) {
        currentUser != null &&
            (repository.isSuperAdmin() || repository.hasPermission("families_create") || AccessControlManager.hasActionPermission(AccessControlManager.CAN_MANAGE_FAMILIES)) &&
            AccessControlManager.hasActionPermission(AccessControlManager.ACTION_ADD)
    }

    val listState = rememberLazyListState()
    val ageText = remember(formState.birthDate) {
        calculateAgeFromBirthDate(formState.birthDate).toString()
    }

    fun showDatePicker(currentValue: String, defaultYearsBack: Int = 35, onPicked: (String) -> Unit) {
        val calendar = Calendar.getInstance()
        val parts = currentValue.trim().split("-", "/")
        val initialYear = parts.getOrNull(0)?.toIntOrNull() ?: (calendar.get(Calendar.YEAR) - defaultYearsBack)
        val initialMonth = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val initialDay = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(
            context,
            { _, y, m, d ->
                onPicked(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d))
            },
            initialYear,
            initialMonth,
            initialDay
        ).show()
    }

    // خلفية فاتحة هادئة بتدرج زجاجي ناعم
    val lightBackdropBrush = remember {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFFEEF7F3),
                Color(0xFFF8FAFC),
                Color(0xFFEAF3FA)
            )
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(lightBackdropBrush)
        ) {
            // هالات ضوئية هادئة لتعزيز العمق الزجاجي الفاتح
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 70.dp, y = (-40).dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                PalestineGreen.copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = (-60).dp, y = 50.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                SkyBlue.copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = "إضافة أسرة جديدة",
                                    fontWeight = FontWeight.ExtraBold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = SlateTextPrimary
                                )
                                Text(
                                    text = "نموذج التسجيل الزجاجي الشامل لبيانات الأسرة",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SlateTextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = {
                                    CivilRegistryDraftBridge.clearDraft()
                                    viewModel.clearState()
                                    onNavigateBack()
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.ArrowForward,
                                    contentDescription = "رجوع",
                                    tint = PalestineGreen
                                )
                            }
                        },
                        actions = {
                            if (canAccessCivilRegistry && onOpenCivilRegistryLookup != null) {
                                IconButton(onClick = onOpenCivilRegistryLookup) {
                                    Icon(
                                        imageVector = Icons.Rounded.ManageSearch,
                                        contentDescription = "البحث في السجل المدني",
                                        tint = PalestineGreen
                                    )
                                }
                            }
                            IconButton(
                                onClick = {
                                    CivilRegistryDraftBridge.clearDraft()
                                    viewModel.clearState()
                                    Toast.makeText(context, "تمت إعادة تهيئة الحقول", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = "إعادة تهيئة",
                                    tint = PalestineGreen
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.White.copy(alpha = 0.78f),
                            titleContentColor = SlateTextPrimary
                        )
                    )
                }
            ) { paddingValues ->
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // شريط حالة المسودة المرحّلة من السجل المدني (قابلة للتعديل وغير محفوظة بعد)
                    if (isCivilRegistryDraftActive) {
                        item(key = "civil_registry_draft_banner") {
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                color = Color(0xFFFFF8EC),
                                border = BorderStroke(1.dp, Color(0xFFF3C677)),
                                shadowElevation = 0.dp,
                                tonalElevation = 0.dp
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.EditNote,
                                        contentDescription = null,
                                        tint = Color(0xFF9A5B00),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "مسودة مرحّلة من السجل المدني (غير محفوظة)",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF7C4700)
                                        )
                                        Text(
                                            text = "يمكنك تعديل أي حقل بحرية، ولن يُحفظ أي شيء إلا بقرارك في شاشة الحفظ.",
                                            fontSize = 11.sp,
                                            color = Color(0xFF9A5B00)
                                        )
                                    }
                                    TextButton(
                                        onClick = {
                                            CivilRegistryDraftBridge.clearDraft()
                                            viewModel.clearState()
                                            Toast.makeText(context, "تم تجاهل المسودة المرحّلة", Toast.LENGTH_SHORT).show()
                                            onNavigateBack()
                                        },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = "تجاهل",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFC62828)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // شريط تعريفي ونطاق الصلاحية الجغرافية
                    item(key = "header_banner") {
                        LightGlassCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = PalestineGreen.copy(alpha = 0.12f),
                                    border = BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.30f)),
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Rounded.PersonAdd,
                                            contentDescription = null,
                                            tint = PalestineGreen,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "بطاقة تسجيل أسرة جديدة بالمنظومة",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = SlateTextPrimary
                                    )
                                    val activeRegionDisplay = formState.localityName.ifBlank { formState.currentMainArea }
                                    val scopeSummary = buildString {
                                        if (userRegion != "ALL" && !isManager) {
                                            append("نطاقك المخصص: $userRegion")
                                        } else {
                                            append(
                                                if (activeRegionDisplay.isNotBlank()) "المنطقة: $activeRegionDisplay"
                                                else "إدخال حر ومفتوح للمنطقة والمحلية"
                                            )
                                        }
                                        if (formState.currentBranch.isNotBlank()) {
                                            append(" • الشعبة: ${formState.currentBranch}")
                                        }
                                    }
                                    Text(
                                        text = scopeSummary,
                                        fontSize = 11.sp,
                                        color = if (isRegionAllowed) PalestineGreen else PalestineRed,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (isLocalityLocked || isRegionLocked) {
                                    Icon(
                                        imageVector = Icons.Rounded.Lock,
                                        contentDescription = "نطاق محصور",
                                        tint = if (isRegionAllowed) PalestineGreen else PalestineRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }

                    // رسالة الخطأ العامة إن وجدت
                    if (formState.errorMessage != null) {
                        item(key = "error_banner") {
                            Surface(
                                shape = RoundedCornerShape(24.dp),
                                color = PalestineRedLight.copy(alpha = 0.90f),
                                border = BorderStroke(1.dp, PalestineRed.copy(alpha = 0.45f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Rounded.Error, contentDescription = null, tint = PalestineRed)
                                    Text(
                                        text = formState.errorMessage!!,
                                        color = PalestineRedDark,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // =========================================================================
                    // 1. بطاقة البيانات الأساسية
                    // =========================================================================
                    item(key = "card_basic_info") {
                        LightGlassCard {
                            LightGlassSectionHeader(
                                number = "1",
                                title = "البيانات الأساسية",
                                subtitle = "الاسم الرباعي، رقم الهوية الوطنية (9 أرقام)، كرت المؤن وبيانات الزوج/الزوجة",
                                icon = Icons.Rounded.Person,
                                accentColor = PalestineGreen
                            )

                            GlassOutlinedTextField(
                                value = formState.name,
                                onValueChange = viewModel::onNameChange,
                                label = "الاسم الرباعي *",
                                isError = formState.nameError != null,
                                errorMessage = formState.nameError,
                                leadingIcon = Icons.Rounded.Person,
                                iconTint = Color(0xFF10B981)
                            )

                            GlassOutlinedTextField(
                                value = formState.nationalID,
                                onValueChange = viewModel::onNationalIdChange,
                                label = "رقم الهوية الوطنية (9 أرقام فقط) * (${formState.nationalID.length}/9)",
                                isError = formState.nationalIdError != null,
                                errorMessage = formState.nationalIdError,
                                keyboardType = KeyboardType.Number,
                                leadingIcon = Icons.Rounded.Badge,
                                iconTint = Color(0xFF3B82F6)
                            )

                            GlassOutlinedTextField(
                                value = formState.rationCardNumber,
                                onValueChange = viewModel::onRationCardNumberChange,
                                label = "رقم كرت المؤن / الوكالة",
                                leadingIcon = Icons.Rounded.CreditCard,
                                iconTint = Color(0xFF0EA5E9)
                            )

                            GlassOutlinedTextField(
                                value = formState.wifeName,
                                onValueChange = viewModel::onWifeNameChange,
                                label = "اسم الزوج / الزوجة الرباعي",
                                leadingIcon = Icons.Rounded.Face,
                                iconTint = Color(0xFFEC4899)
                            )

                            GlassOutlinedTextField(
                                value = formState.wifeNationalID,
                                onValueChange = viewModel::onWifeNationalIdChange,
                                label = "رقم هوية الزوج / الزوجة (9 أرقام)",
                                isError = formState.wifeNationalIdError != null,
                                errorMessage = formState.wifeNationalIdError,
                                keyboardType = KeyboardType.Number,
                                leadingIcon = Icons.Rounded.PermIdentity,
                                iconTint = Color(0xFF8B5CF6)
                            )
                        }
                    }

                    // =========================================================================
                    // 2. بطاقة بيانات السكن والاتصال
                    // =========================================================================
                    item(key = "card_housing_contact") {
                        LightGlassCard {
                            LightGlassSectionHeader(
                                number = "2",
                                title = "بيانات السكن والاتصال",
                                subtitle = "المنطقة (معزولة جغرافياً)، الشعبة/الحي، العنوان التفصيلي، الإيواء وأرقام الجوال",
                                icon = Icons.Rounded.LocationOn,
                                accentColor = SkyBlue
                            )

                            // المنطقة / المحافظة - إدخال حر مع اقتراحات DISTINCT من قاعدة البيانات
                            GlassEditableDropdownField(
                                value = formState.currentMainArea,
                                onValueChange = viewModel::onCurrentMainAreaChange,
                                label = "المنطقة / المحافظة *",
                                suggestions = governorateSuggestions,
                                leadingIcon = Icons.Rounded.Map,
                                isError = !isMainAreaAllowed,
                                iconTint = Color(0xFFF43F5E)
                            )

                            // المحلية - إدخال حر مع اقتراحات DISTINCT من قاعدة البيانات
                            GlassEditableDropdownField(
                                value = formState.localityName,
                                onValueChange = viewModel::onLocalityNameChange,
                                label = "المحلية *",
                                suggestions = localitySuggestions,
                                leadingIcon = Icons.Rounded.LocationCity,
                                isError = !isLocalityAllowed,
                                iconTint = Color(0xFF14B8A6)
                            )

                            if (!isRegionAllowed) {
                                Text(
                                    text = "لا تمتلك صلاحية الإضافة في هذه المنطقة (نطاقك المخصص: $userRegion)",
                                    color = PalestineRed,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(start = 8.dp, top = 2.dp)
                                )
                            }

                            GlassEditableDropdownField(
                                value = formState.currentSubArea,
                                onValueChange = viewModel::onCurrentSubAreaChange,
                                label = "الحي / المنطقة الفرعية الحالية *",
                                suggestions = availableSubAreas,
                                leadingIcon = Icons.Rounded.Place,
                                iconTint = Color(0xFFF59E0B)
                            )

                            val branchSuggestions = remember(availableBranches, availableSubAreas) {
                                availableBranches.ifEmpty { availableSubAreas }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.currentBranch,
                                    onValueChange = viewModel::onCurrentBranchChange,
                                    label = "الشعبة الحالية",
                                    suggestions = branchSuggestions,
                                    leadingIcon = Icons.Rounded.AltRoute,
                                    enabled = true,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF6366F1)
                                )
                                GlassOutlinedTextField(
                                    value = formState.currentMosque,
                                    onValueChange = viewModel::onCurrentMosqueChange,
                                    label = "العنوان التفصيلي / المسجد",
                                    leadingIcon = Icons.Rounded.Mosque,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF06B6D4)
                                )
                            }

                            GlassEditableDropdownField(
                                value = formState.shelterStatus,
                                onValueChange = viewModel::onShelterStatusChange,
                                label = "حالة السكن والإيواء",
                                suggestions = shelterStatusOptions,
                                leadingIcon = Icons.Rounded.Home,
                                iconTint = Color(0xFF14B8A6)
                            )

                            GlassOutlinedTextField(
                                value = formState.shelterCenterName,
                                onValueChange = viewModel::onShelterCenterNameChange,
                                label = "اسم مركز الإيواء أو المخيم (إن وجد)",
                                leadingIcon = Icons.Rounded.HolidayVillage,
                                iconTint = Color(0xFFF59E0B)
                            )

                            GlassOutlinedTextField(
                                value = formState.primaryPhone,
                                onValueChange = viewModel::onPrimaryPhoneChange,
                                label = "رقم الجوال الأساسي *",
                                isError = formState.phoneError != null,
                                errorMessage = formState.phoneError,
                                keyboardType = KeyboardType.Phone,
                                leadingIcon = Icons.Rounded.Phone,
                                iconTint = Color(0xFF10B981)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.alternativePhone1,
                                    onValueChange = viewModel::onAlternativePhone1Change,
                                    label = "جوال بديل 1",
                                    keyboardType = KeyboardType.Phone,
                                    leadingIcon = Icons.Rounded.PhoneIphone,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF0EA5E9)
                                )
                                GlassOutlinedTextField(
                                    value = formState.alternativePhone2,
                                    onValueChange = viewModel::onAlternativePhone2Change,
                                    label = "جوال بديل 2",
                                    keyboardType = KeyboardType.Phone,
                                    leadingIcon = Icons.Rounded.Call,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF3B82F6)
                                )
                            }

                            HorizontalDivider(
                                color = SlateBorder,
                                thickness = 1.dp,
                                modifier = Modifier.padding(top = 4.dp)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.History,
                                        contentDescription = null,
                                        tint = SkyBlue,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "العنوان الأصلي قبل النزوح",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = SlateTextPrimary
                                    )
                                }
                                TextButton(
                                    onClick = { viewModel.copyCurrentAddressToOriginal() },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.textButtonColors(contentColor = PalestineGreen)
                                ) {
                                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("نسخ الحالي", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.originalMainArea,
                                    onValueChange = viewModel::onOriginalMainAreaChange,
                                    label = "المحافظة الأصلية",
                                    suggestions = governorateSuggestions,
                                    leadingIcon = Icons.Rounded.Map,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF6366F1)
                                )
                                GlassOutlinedTextField(
                                    value = formState.originalSubArea,
                                    onValueChange = viewModel::onOriginalSubAreaChange,
                                    label = "المنطقة الفرعية الأصلية",
                                    leadingIcon = Icons.Rounded.Place,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF0EA5E9)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.originalBranch,
                                    onValueChange = viewModel::onOriginalBranchChange,
                                    label = "الشعبة الأصلية",
                                    leadingIcon = Icons.Rounded.ShareLocation,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF8B5CF6)
                                )
                                GlassOutlinedTextField(
                                    value = formState.originalMosque,
                                    onValueChange = viewModel::onOriginalMosqueChange,
                                    label = "المسجد الأصلي",
                                    leadingIcon = Icons.Rounded.Mosque,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF14B8A6)
                                )
                            }
                        }
                    }

                    // =========================================================================
                    // 3. بطاقة البيانات الديموغرافية والاقتصادية والاعتمادات
                    // =========================================================================
                    item(key = "card_demographic_info") {
                        LightGlassCard {
                            LightGlassSectionHeader(
                                number = "3",
                                title = "البيانات الديموغرافية",
                                subtitle = "عدد الأفراد، صفة الإقامة/النزوح، الجنس، الحالة الاجتماعية، الصحة، العمل والاعتمادات",
                                icon = Icons.Rounded.Groups,
                                accentColor = PalestineGold
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.familyMembersCount,
                                    onValueChange = viewModel::onFamilyMembersCountChange,
                                    label = "عدد أفراد الأسرة *",
                                    isError = formState.membersCountError != null,
                                    errorMessage = formState.membersCountError,
                                    keyboardType = KeyboardType.Number,
                                    leadingIcon = Icons.Rounded.Groups,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF3B82F6)
                                )
                                GlassDropdownField(
                                    value = formState.residentStatus,
                                    onValueChange = viewModel::onResidentStatusChange,
                                    label = "صفة الإقامة / النزوح",
                                    options = residentStatusOptions,
                                    leadingIcon = Icons.Rounded.PinDrop,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF10B981)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassDropdownField(
                                    value = formState.gender,
                                    onValueChange = viewModel::onGenderChange,
                                    label = "الجنس",
                                    options = listOf("ذكر", "أنثى"),
                                    leadingIcon = Icons.Rounded.Wc,
                                    modifier = Modifier.weight(0.45f),
                                    iconTint = Color(0xFF8B5CF6)
                                )
                                GlassEditableDropdownField(
                                    value = formState.maritalStatus,
                                    onValueChange = viewModel::onMaritalStatusChange,
                                    label = "الحالة الاجتماعية",
                                    suggestions = maritalOptions,
                                    leadingIcon = Icons.Rounded.Favorite,
                                    modifier = Modifier.weight(0.55f),
                                    iconTint = Color(0xFFEC4899)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassOutlinedTextField(
                                    value = formState.birthDate,
                                    onValueChange = viewModel::onBirthDateChange,
                                    label = "تاريخ الميلاد *",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.CalendarToday,
                                    onClick = {
                                        showDatePicker(formState.birthDate, defaultYearsBack = 38) {
                                            viewModel.onBirthDateChange(it)
                                        }
                                    },
                                    modifier = Modifier.weight(0.64f),
                                    iconTint = Color(0xFF6366F1)
                                )
                                GlassOutlinedTextField(
                                    value = "$ageText سنة",
                                    onValueChange = {},
                                    label = "العمر",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.Cake,
                                    modifier = Modifier.weight(0.36f),
                                    iconTint = Color(0xFFF59E0B)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassDropdownField(
                                    value = formState.deathStatus,
                                    onValueChange = viewModel::onDeathStatusChange,
                                    label = "حالة الحياة / الوفاة",
                                    options = listOf("على قيد الحياة", "متوفى", "شهيد"),
                                    leadingIcon = Icons.Rounded.HeartBroken,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFFE11D48)
                                )
                                GlassOutlinedTextField(
                                    value = formState.deathDate,
                                    onValueChange = viewModel::onDeathDateChange,
                                    label = "تاريخ الوفاة",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.EventBusy,
                                    onClick = {
                                        showDatePicker(
                                            currentValue = formState.deathDate.ifBlank { "2024-01-01" },
                                            defaultYearsBack = 1
                                        ) {
                                            viewModel.onDeathDateChange(it)
                                        }
                                    },
                                    enabled = formState.deathStatus != "على قيد الحياة",
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFFE11D48)
                                )
                            }

                            GlassEditableDropdownField(
                                value = formState.damageType,
                                onValueChange = viewModel::onDamageTypeChange,
                                label = "تصنيف الضرر",
                                suggestions = damageTypeOptions,
                                leadingIcon = Icons.Rounded.HomeWork,
                                iconTint = Color(0xFFF97316)
                            )

                            GlassOutlinedTextField(
                                value = formState.damageDescription,
                                onValueChange = viewModel::onDamageDescriptionChange,
                                label = "وصف تفاصيل الضرر",
                                leadingIcon = Icons.Rounded.ReportProblem,
                                singleLine = false,
                                minLines = 2,
                                iconTint = Color(0xFFF97316)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassEditableDropdownField(
                                    value = formState.injuryStatus,
                                    onValueChange = viewModel::onInjuryStatusChange,
                                    label = "الحالة الصحية / الإصابة",
                                    suggestions = injuryStatusOptions,
                                    leadingIcon = Icons.Rounded.LocalHospital,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFFEF4444)
                                )
                                GlassOutlinedTextField(
                                    value = formState.injuryDate,
                                    onValueChange = viewModel::onInjuryDateChange,
                                    label = "تاريخ الإصابة",
                                    readOnly = true,
                                    leadingIcon = Icons.Rounded.Event,
                                    onClick = {
                                        showDatePicker(
                                            currentValue = formState.injuryDate.ifBlank { "2024-01-01" },
                                            defaultYearsBack = 1
                                        ) {
                                            viewModel.onInjuryDateChange(it)
                                        }
                                    },
                                    enabled = formState.injuryStatus != "سليم" && formState.injuryStatus != "لا يوجد",
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFFEF4444)
                                )
                            }

                            HorizontalDivider(
                                color = SlateBorder,
                                thickness = 1.dp,
                                modifier = Modifier.padding(top = 4.dp)
                            )

                            GlassEditableDropdownField(
                                value = formState.incomeSource1,
                                onValueChange = viewModel::onIncomeSource1Change,
                                label = "مصدر الدخل / حالة العمل 1",
                                suggestions = incomeSourceOptions,
                                leadingIcon = Icons.Rounded.Work,
                                iconTint = Color(0xFF0EA5E9)
                            )

                            GlassEditableDropdownField(
                                value = formState.incomeSource2,
                                onValueChange = viewModel::onIncomeSource2Change,
                                label = "مصدر الدخل / حالة العمل 2",
                                suggestions = incomeSourceOptions,
                                leadingIcon = Icons.Rounded.WorkOutline,
                                iconTint = Color(0xFF06B6D4)
                            )

                            GlassEditableDropdownField(
                                value = formState.incomeDetails,
                                onValueChange = viewModel::onIncomeDetailsChange,
                                label = "مصادر الدخل التفصيلية",
                                suggestions = incomeSourceOptions,
                                leadingIcon = Icons.Rounded.Payments,
                                iconTint = Color(0xFF10B981)
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassDropdownField(
                                    value = formState.developmentApproval,
                                    onValueChange = viewModel::onDevelopmentApprovalChange,
                                    label = "اعتماد التنمية",
                                    options = developmentApprovalOptions,
                                    leadingIcon = Icons.Rounded.Verified,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF10B981)
                                )
                                GlassDropdownField(
                                    value = formState.localityApproval,
                                    onValueChange = viewModel::onLocalityApprovalChange,
                                    label = "اعتماد المحلية",
                                    options = localityApprovalOptions,
                                    leadingIcon = Icons.Rounded.CheckCircle,
                                    modifier = Modifier.weight(1f),
                                    iconTint = Color(0xFF3B82F6)
                                )
                            }

                            GlassEditableDropdownField(
                                value = formState.worksApproval,
                                onValueChange = viewModel::onWorksApprovalChange,
                                label = "اعتماد وزارة الأشغال",
                                suggestions = worksApprovalOptions,
                                leadingIcon = Icons.Rounded.Build,
                                iconTint = Color(0xFFF59E0B)
                            )

                            GlassOutlinedTextField(
                                value = formState.notes,
                                onValueChange = viewModel::onNotesChange,
                                label = "ملاحظات وتفاصيل إضافية",
                                leadingIcon = Icons.Rounded.Notes,
                                singleLine = false,
                                minLines = 3,
                                iconTint = Color(0xFF64748B)
                            )
                        }
                    }

                    // =========================================================================
                    // أزرار الانتقال إلى شاشة الحفظ أو تجاهل المسودة في أسفل النموذج
                    // =========================================================================
                    item(key = "save_button") {
                        val isEnabled = isRegionAllowed && !formState.isSaving && canAddFamily
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { showSaveDecisionDialog = true },
                                enabled = isEnabled,
                                shape = RoundedCornerShape(18.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF0F7B53),
                                    contentColor = Color.White,
                                    disabledContainerColor = SlateBorder,
                                    disabledContentColor = SlateTextMuted
                                ),
                                elevation = ButtonDefaults.buttonElevation(
                                    defaultElevation = 0.dp,
                                    pressedElevation = 0.dp
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(54.dp)
                            ) {
                                if (formState.isSaving) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = Color.White,
                                        strokeWidth = 2.5.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "جاري الحفظ في المشروع...",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Rounded.VerifiedUser,
                                        contentDescription = "شاشة الحفظ",
                                        modifier = Modifier.size(21.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = when {
                                            !canAddFamily -> "ليس لديك صلاحية إضافة أسر في هذا النطاق"
                                            isCivilRegistryDraftActive -> "الانتقال إلى شاشة الحفظ (حفظ / عدم الحفظ)"
                                            else -> "اعتماد وحفظ الأسرة في المشروع"
                                        },
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 15.sp
                                    )
                                }
                            }

                            if (isCivilRegistryDraftActive) {
                                OutlinedButton(
                                    onClick = {
                                        CivilRegistryDraftBridge.clearDraft()
                                        viewModel.clearState()
                                        Toast.makeText(
                                            context,
                                            "تم إلغاء الترحيل وتجاهل المسودة دون حفظ",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        onNavigateBack()
                                    },
                                    enabled = !formState.isSaving,
                                    shape = RoundedCornerShape(16.dp),
                                    border = BorderStroke(1.dp, Color(0xFFF5B7B1)),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = Color(0xFFFEECEB),
                                        contentColor = Color(0xFFC62828)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Cancel,
                                        contentDescription = null,
                                        modifier = Modifier.size(19.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "عدم الحفظ / تجاهل المسودة",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }

            // شاشة قرار الحفظ الصريحة: حفظ في المشروع أو عدم الحفظ / تجاهل
            if (showSaveDecisionDialog) {
                SaveFamilyDecisionDialog(
                    formState = formState,
                    isFromCivilRegistryDraft = isCivilRegistryDraftActive,
                    onSaveToProject = {
                        showSaveDecisionDialog = false
                        viewModel.saveFamily {
                            CivilRegistryDraftBridge.clearDraft()
                            Toast.makeText(
                                context,
                                "تم اعتماد وحفظ الأسرة في بيانات المشروع بنجاح",
                                Toast.LENGTH_SHORT
                            ).show()
                            onNavigateBack()
                        }
                    },
                    onDiscardWithoutSaving = {
                        showSaveDecisionDialog = false
                        CivilRegistryDraftBridge.clearDraft()
                        viewModel.clearState()
                        Toast.makeText(
                            context,
                            if (isCivilRegistryDraftActive) {
                                "تم إلغاء الترحيل وعدم الحفظ دون المساس بالسجل المدني"
                            } else {
                                "تم إلغاء الإدخال وعدم الحفظ"
                            },
                            Toast.LENGTH_SHORT
                        ).show()
                        onNavigateBack()
                    },
                    onContinueEditing = { showSaveDecisionDialog = false }
                )
            }
        }
    }
}

/**
 * شاشة الحفظ النهائية (Save Decision Screen):
 * تمنح المستخدم القرار الكامل الصريح بين:
 * 1. حفظ في المشروع (اعتماد وترحيل السجل إلى بيانات المشروع).
 * 2. عدم الحفظ / تجاهل (إلغاء الترحيل دون إجبار المستخدم ودون المساس بقاعدة civil_registry.db).
 */
@Composable
private fun SaveFamilyDecisionDialog(
    formState: AddFamilyViewModel.FormState,
    isFromCivilRegistryDraft: Boolean = formState.isFromCivilRegistryDraft,
    onSaveToProject: () -> Unit,
    onDiscardWithoutSaving: () -> Unit,
    onContinueEditing: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onContinueEditing,
        shape = RoundedCornerShape(22.dp),
        containerColor = Color(0xFFF9FCFA),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE6F4EA)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VerifiedUser,
                        contentDescription = null,
                        tint = Color(0xFF0F7B53),
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column {
                    Text(
                        text = "شاشة الحفظ والاعتماد",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = if (isFromCivilRegistryDraft) {
                            "مسودة مرحّلة من السجل المدني — القرار بيدك بالكامل"
                        } else {
                            "تأكيد قرار الحفظ في بيانات المشروع"
                        },
                        fontSize = 11.sp,
                        color = Color(0xFF5F6E68)
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color(0xFFD6E8DF)),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SaveSummaryMiniRow("الاسم", formState.name.ifBlank { "غير مدخل" })
                        HorizontalDivider(color = Color(0xFFECF3EF), thickness = 0.8.dp)
                        SaveSummaryMiniRow("رقم الهوية", formState.nationalID.ifBlank { "غير مدخل" })
                        if (formState.wifeName.isNotBlank()) {
                            HorizontalDivider(color = Color(0xFFECF3EF), thickness = 0.8.dp)
                            SaveSummaryMiniRow("الزوجة", formState.wifeName)
                        }
                        if (formState.primaryPhone.isNotBlank()) {
                            HorizontalDivider(color = Color(0xFFECF3EF), thickness = 0.8.dp)
                            SaveSummaryMiniRow("رقم الجوال", formState.primaryPhone)
                        }
                        HorizontalDivider(color = Color(0xFFECF3EF), thickness = 0.8.dp)
                        SaveSummaryMiniRow("أفراد الأسرة", formState.familyMembersCount.ifBlank { "1" })
                    }
                }

                Text(
                    text = if (isFromCivilRegistryDraft) {
                        "اختر بوضوح هل تريد اعتماد وحفظ هذه البيانات داخل المشروع، أم تجاهلها وعدم الحفظ (تبقى قاعدة السجل المدني للقراءة فقط ولا تتأثر بأي خيار)."
                    } else {
                        "اختر بوضوح هل تريد اعتماد وحفظ هذه البيانات داخل المشروع، أم تجاهلها وعدم الحفظ."
                    },
                    fontSize = 12.sp,
                    color = Color(0xFF5F6E68),
                    lineHeight = 18.sp
                )
            }
        },
        confirmButton = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSaveToProject,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF0F7B53),
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(0.dp, 0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("حفظ في المشروع", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                OutlinedButton(
                    onClick = onDiscardWithoutSaving,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFFF5B7B1)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color(0xFFFEECEB),
                        contentColor = Color(0xFFC62828)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                ) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("عدم الحفظ / تجاهل", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                TextButton(
                    onClick = onContinueEditing,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "العودة لمتابعة التعديل",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF5F6E68)
                    )
                }
            }
        }
    )
}

@Composable
private fun SaveSummaryMiniRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color(0xFF5F6E68),
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = value,
            fontSize = 12.sp,
            color = Color(0xFF0F172A),
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * بطاقة زجاجية فاتحة (Light Glassmorphism Card) بخلفية بيضاء شفافة 0.85f وحدود ناعمة وظل خفيف وزوايا 16.dp
 */
@Composable
private fun LightGlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .shadow(elevation = 4.dp, shape = RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
            .border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

/**
 * ترويسة زجاجية موحدة لكل بطاقة في شاشة الإضافة
 */
@Composable
private fun LightGlassSectionHeader(
    number: String,
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = accentColor.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(21.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "$number. $title",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = SlateTextPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateTextSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        HorizontalDivider(
            color = SlateBorder,
            thickness = 1.dp
        )
    }
}

/**
 * حقل إدخال زجاجي أنيق متوافق مع نظام Glassmorphism ومستخدم في AddFamilyScreen و AddChildScreen
 */
@Composable
fun GlassOutlinedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    isError: Boolean = false,
    errorMessage: String? = null,
    readOnly: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    leadingIcon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
    enabled: Boolean = true,
    singleLine: Boolean = true,
    minLines: Int = 1,
    glassMode: Boolean = false,
    iconTint: Color = PalestineGreen
) {
    val isDark = isSystemInDarkTheme() || MaterialTheme.colorScheme.surface.luminance() < 0.5f
    val interactionSource = remember { MutableInteractionSource() }

    if (onClick != null && enabled) {
        LaunchedEffect(interactionSource) {
            interactionSource.interactions.collect { interaction ->
                if (interaction is PressInteraction.Release) {
                    onClick()
                }
            }
        }
    }

    val focusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.90f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.85f)
        else -> Color.White.copy(alpha = 0.92f)
    }
    val unfocusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.72f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.62f)
        else -> Color.White.copy(alpha = 0.75f)
    }
    val borderUnfocused = when {
        glassMode -> SlateBorderSubtle
        isDark -> Color.White.copy(alpha = 0.2f)
        else -> SlateBorderSubtle.copy(alpha = 0.90f)
    }
    val accent = PalestineGreen
    val errorAccent = PalestineRed
    val textColor = if (isDark && !glassMode) Color.White else SlateTextPrimary
    val unfocusedLabel = if (isDark && !glassMode) Color(0xFF94A3B8) else SlateTextSecondary

    Column(modifier = modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            readOnly = readOnly,
            enabled = enabled,
            isError = isError,
            singleLine = singleLine,
            minLines = minLines,
            interactionSource = interactionSource,
            leadingIcon = leadingIcon?.let {
                {
                    Icon(
                        imageVector = it,
                        contentDescription = null,
                        tint = if (isError) errorAccent else iconTint,
                        modifier = Modifier.size(19.dp)
                    )
                }
            },
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = textColor,
                unfocusedTextColor = textColor,
                disabledTextColor = textColor.copy(alpha = 0.65f),
                focusedContainerColor = focusedBg,
                unfocusedContainerColor = unfocusedBg,
                disabledContainerColor = unfocusedBg.copy(alpha = 0.55f),
                focusedBorderColor = accent,
                unfocusedBorderColor = borderUnfocused,
                disabledBorderColor = borderUnfocused.copy(alpha = 0.5f),
                errorBorderColor = errorAccent,
                focusedLabelColor = accent,
                unfocusedLabelColor = unfocusedLabel,
                disabledLabelColor = unfocusedLabel.copy(alpha = 0.6f),
                cursorColor = accent
            ),
            modifier = Modifier.fillMaxWidth()
        )
        if (isError && errorMessage != null) {
            Text(
                text = errorMessage,
                color = errorAccent,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(start = 8.dp, top = 3.dp)
            )
        }
    }
}

/**
 * حقل اختيار منسدل زجاجي GlassDropdownField متوافق مع AddChildScreen
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlassDropdownField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    options: List<String>,
    modifier: Modifier = Modifier.fillMaxWidth(),
    leadingIcon: ImageVector? = Icons.Default.List,
    enabled: Boolean = true,
    glassMode: Boolean = false,
    iconTint: Color = PalestineGreen
) {
    var expanded by remember { mutableStateOf(false) }
    val isDark = isSystemInDarkTheme() || MaterialTheme.colorScheme.surface.luminance() < 0.5f

    val focusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.90f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.85f)
        else -> Color.White.copy(alpha = 0.92f)
    }
    val unfocusedBg = when {
        glassMode -> Color.White.copy(alpha = 0.72f)
        isDark -> Color(0xFF0F172A).copy(alpha = 0.62f)
        else -> Color.White.copy(alpha = 0.75f)
    }
    val borderUnfocused = when {
        glassMode -> SlateBorderSubtle
        isDark -> Color.White.copy(alpha = 0.2f)
        else -> SlateBorderSubtle.copy(alpha = 0.90f)
    }
    val accent = PalestineGreen
    val textColor = if (isDark && !glassMode) Color.White else SlateTextPrimary
    val unfocusedLabel = if (isDark && !glassMode) Color(0xFF94A3B8) else SlateTextSecondary
    val menuBg = if (isDark && !glassMode) Color(0xFF1E293B) else Color.White

    ExposedDropdownMenuBox(
        expanded = expanded && enabled,
        onExpandedChange = { if (enabled) expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            enabled = enabled,
            singleLine = true,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = leadingIcon?.let {
                {
                    Icon(
                        imageVector = it,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(19.dp)
                    )
                }
            },
            trailingIcon = {
                if (enabled) {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = textColor,
                unfocusedTextColor = textColor,
                disabledTextColor = textColor.copy(alpha = 0.65f),
                focusedContainerColor = focusedBg,
                unfocusedContainerColor = unfocusedBg,
                disabledContainerColor = unfocusedBg.copy(alpha = 0.55f),
                focusedBorderColor = accent,
                unfocusedBorderColor = borderUnfocused,
                disabledBorderColor = borderUnfocused.copy(alpha = 0.5f),
                focusedLabelColor = accent,
                unfocusedLabelColor = unfocusedLabel,
                disabledLabelColor = unfocusedLabel.copy(alpha = 0.6f),
                focusedTrailingIconColor = accent,
                unfocusedTrailingIconColor = unfocusedLabel
            ),
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )

        if (expanded && enabled && options.isNotEmpty()) {
            ExposedDropdownMenu(
                expanded = expanded && enabled,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(menuBg)
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = option,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (option == value) FontWeight.Bold else FontWeight.Normal,
                                    color = textColor
                                )
                                if (option == value) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = accent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        },
                        onClick = {
                            onValueChange(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}

/**
 * حقل اختيار منسدل قابل للكتابة والبحث الفوري (Editable OutlinedTextField + ExposedDropdownMenuBox)
 * مزود بفلترة حية وسقف أقصى 5 اقتراحات لمنع تجميد الواجهة (ANR)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GlassEditableDropdownField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    suggestions: List<String>,
    leadingIcon: ImageVector,
    modifier: Modifier = Modifier.fillMaxWidth(),
    enabled: Boolean = true,
    isError: Boolean = false,
    iconTint: Color = PalestineGreen
) {
    var expanded by remember { mutableStateOf(false) }

    val filteredSuggestions = remember(value, suggestions) {
        val enteredText = value.trim()
        if (enteredText.isBlank()) {
            suggestions.take(5)
        } else {
            val matches = suggestions
                .asSequence()
                .filter { it.contains(enteredText, ignoreCase = true) }
                .take(5)
                .toList()
            if (matches.size == 1 && matches.first().equals(enteredText, ignoreCase = true)) {
                suggestions.take(5)
            } else {
                matches
            }
        }
    }

    ExposedDropdownMenuBox(
        expanded = expanded && enabled && filteredSuggestions.isNotEmpty(),
        onExpandedChange = { if (enabled && filteredSuggestions.isNotEmpty()) expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = { newText ->
                onValueChange(newText)
                val trimmed = newText.trim()
                expanded = trimmed.isNotEmpty() && suggestions.any { s -> s.contains(trimmed, ignoreCase = true) }
            },
            readOnly = false,
            enabled = enabled,
            isError = isError,
            singleLine = true,
            label = {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = leadingIcon,
                    contentDescription = null,
                    tint = if (isError) PalestineRed else iconTint,
                    modifier = Modifier.size(19.dp)
                )
            },
            trailingIcon = {
                if (enabled && filteredSuggestions.isNotEmpty()) {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                }
            },
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = SlateTextPrimary,
                unfocusedTextColor = SlateTextPrimary,
                disabledTextColor = SlateTextPrimary.copy(alpha = 0.65f),
                focusedContainerColor = Color.White.copy(alpha = 0.92f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.75f),
                disabledContainerColor = Color.White.copy(alpha = 0.55f),
                focusedBorderColor = if (isError) PalestineRed else PalestineGreen,
                unfocusedBorderColor = if (isError) PalestineRed else SlateBorderSubtle,
                errorBorderColor = PalestineRed,
                disabledBorderColor = SlateBorderSubtle.copy(alpha = 0.5f),
                focusedLabelColor = if (isError) PalestineRed else PalestineGreen,
                unfocusedLabelColor = if (isError) PalestineRed else SlateTextSecondary,
                errorLabelColor = PalestineRed,
                disabledLabelColor = SlateTextSecondary.copy(alpha = 0.6f),
                focusedTrailingIconColor = if (isError) PalestineRed else PalestineGreen,
                unfocusedTrailingIconColor = SlateTextSecondary,
                cursorColor = if (isError) PalestineRed else PalestineGreen
            ),
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )

        if (expanded && enabled && filteredSuggestions.isNotEmpty()) {
            ExposedDropdownMenu(
                expanded = true,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(Color.White)
            ) {
                filteredSuggestions.forEach { option ->
                    DropdownMenuItem(
                        text = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = option,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (option == value) FontWeight.Bold else FontWeight.Normal,
                                    color = SlateTextPrimary
                                )
                                if (option == value) {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        tint = PalestineGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        },
                        onClick = {
                            onValueChange(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}
