package com.humanitarian.aidmanagement.ui.screens.families

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.GlassButton
import com.humanitarian.aidmanagement.ui.components.GlassCard
import com.humanitarian.aidmanagement.ui.components.glassEffect
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.ExcelParserHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.Period
import java.util.Calendar
import java.util.Locale

/**
 * ViewModel لإدارة نموذج إضافة أسرة جديدة مع الأداء العالي على Dispatchers.IO
 */
class AddFamilyViewModel(
    private val repository: AidRepository
) : ViewModel() {

    data class FormState(
        val isSaving: Boolean = false,
        val saveSuccess: Boolean = false,
        val errorMessage: String? = null,
        val nationalIdError: String? = null,
        val nameError: String? = null,
        val phoneError: String? = null
    )

    private val _state = MutableStateFlow(FormState())
    val state: StateFlow<FormState> = _state.asStateFlow()

    fun insertFamily(
        family: FamilyEntity,
        onSuccess: () -> Unit
    ) {
        val cleanNationalId = ExcelParserHelper.normalizeNationalId(family.nationalID)
        if (cleanNationalId.length < 9) {
            _state.update { it.copy(nationalIdError = "رقم الهوية الوطنية يجب أن يتكون من 9 أرقام") }
            return
        }

        if (family.name.trim().length < 5) {
            _state.update { it.copy(nameError = "يرجى كتابة الاسم الرباعي بشكل صحيح") }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(isSaving = true, errorMessage = null, nationalIdError = null, nameError = null) }
            try {
                // فحص تكرار رقم الهوية
                val existing = repository.getFamilyByNationalId(cleanNationalId)
                if (existing != null) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            nationalIdError = "رقم الهوية مسجل مسبقاً باسم: ${existing.name}"
                        )
                    }
                    return@launch
                }

                val normalized = family.copy(
                    nationalID = cleanNationalId,
                    wifeNationalID = family.wifeNationalID?.let { ExcelParserHelper.normalizeNationalId(it) }?.ifBlank { null }
                )

                repository.insertFamily(normalized)

                withContext(Dispatchers.Main) {
                    _state.update { it.copy(isSaving = false, saveSuccess = true) }
                    onSuccess()
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    _state.update {
                        it.copy(
                            isSaving = false,
                            errorMessage = t.localizedMessage ?: "حدث خطأ أثناء حفظ الأسرة في قاعدة البيانات"
                        )
                    }
                }
            }
        }
    }

    fun clearState() {
        _state.value = FormState()
    }

    override fun onCleared() {
        clearState()
        super.onCleared()
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return AddFamilyViewModel(repository) as T
        }
    }
}

/**
 * شاشة إضافة أسرة جديدة بنظام Glassmorphism وتدفق Dispatchers.IO
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFamilyScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    viewModel: AddFamilyViewModel = viewModel(factory = AddFamilyViewModel.Factory(repository))
) {
    val context = LocalContext.current
    val formState by viewModel.state.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    // جلب المحليات المصرح بها للمستخدم
    val currentUser = repository.getCurrentUser()
    val isLocalityRestricted = (currentUser?.AllowedLocalityID ?: 0) != 0 && !repository.isSuperAdmin()
    val allowedLocalityId = currentUser?.AllowedLocalityID ?: 0

    val localities by repository.getLocalities().collectAsStateWithLifecycle(initialValue = emptyList())
    val allowedLocalities = remember(localities, currentUser) {
        if (isLocalityRestricted) {
            localities.filter { it.LocalityID == allowedLocalityId }
        } else {
            localities.filter { repository.canAccessLocality(it.LocalityID) }
        }
    }

    // الحقول الأساسية
    var name by remember { mutableStateOf("") }
    var nationalID by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("1985-01-01") }
    var gender by remember { mutableStateOf("ذكر") }
    var maritalStatus by remember { mutableStateOf("متزوج") }
    var primaryPhone by remember { mutableStateOf("") }
    var altPhone1 by remember { mutableStateOf("") }
    var wifeName by remember { mutableStateOf("") }
    var wifeNationalID by remember { mutableStateOf("") }
    var familyMembersCount by remember { mutableStateOf("5") }

    // الحقول الجغرافية
    var selectedLocalityId by remember { mutableStateOf(allowedLocalities.firstOrNull()?.LocalityID ?: 1) }
    var currentMainArea by remember { mutableStateOf("خانيونس") }
    var currentSubArea by remember { mutableStateOf("") }
    var currentBranch by remember { mutableStateOf("") }
    var currentMosque by remember { mutableStateOf("") }
    var shelterStatus by remember { mutableStateOf("إيواء داخلي") }
    var shelterCenterName by remember { mutableStateOf("") }
    var residentStatus by remember { mutableStateOf("نازح") }

    // أضرار الحرب والوضع المعيشي
    var damageType by remember { mutableStateOf("أضرار كلية") }
    var injuryStatus by remember { mutableStateOf("لا يوجد") }
    var incomeSource1 by remember { mutableStateOf("عمال مياومة") }
    var rationCardNumber by remember { mutableStateOf("") }
    var developmentApproval by remember { mutableStateOf("معتمد") }
    var notes by remember { mutableStateOf("") }

    // حساب العمر اللحظي
    val ageText = remember(birthDate) {
        try {
            val parts = birthDate.trim().split("-")
            if (parts.size == 3) {
                val b = LocalDate.of(parts[0].toInt(), parts[1].toInt(), parts[2].toInt())
                Period.between(b, LocalDate.now()).years.coerceAtLeast(0).toString()
            } else "40"
        } catch (_: Exception) {
            "40"
        }
    }

    fun openDatePicker() {
        val calendar = Calendar.getInstance()
        val parts = birthDate.split("-")
        val initialYear = parts.getOrNull(0)?.toIntOrNull() ?: (calendar.get(Calendar.YEAR) - 40)
        val initialMonth = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val initialDay = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(
            context,
            { _, y, m, d ->
                birthDate = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
            },
            initialYear,
            initialMonth,
            initialDay
        ).show()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("إضافة أسرة جديدة", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("تسجيل وتوثيق بيانات مستفيد جديد بالنظام", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            viewModel.clearState()
                            onNavigateBack()
                        }) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SlateBackground)
                    .padding(paddingValues)
                    .verticalScroll(scrollState)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // رسالة الخطأ العامة
                formState.errorMessage?.let { err ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.errorContainer,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Text(err, color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                // 1. بطاقة البيانات الأساسية (GlassCard)
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "1. بيانات رب الأسرة والتعريف",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = PalestineGreen
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // الاسم رباعي
                    GlassOutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = "الاسم رباعياً *",
                        isError = formState.nameError != null,
                        errorMessage = formState.nameError,
                        leadingIcon = Icons.Default.Person
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // رقم الهوية
                    GlassOutlinedTextField(
                        value = nationalID,
                        onValueChange = { nationalID = ExcelParserHelper.convertEasternToArabicDigits(it).filter { c -> c.isDigit() }.take(9) },
                        label = "رقم الهوية الوطنية (9 أرقام) *",
                        isError = formState.nationalIdError != null,
                        errorMessage = formState.nationalIdError,
                        keyboardType = KeyboardType.Number,
                        leadingIcon = Icons.Default.Badge
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // تاريخ الميلاد والعمر المحسوب
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(modifier = Modifier.weight(0.65f)) {
                            GlassOutlinedTextField(
                                value = birthDate,
                                onValueChange = {},
                                label = "تاريخ الميلاد (YYYY-MM-DD)",
                                readOnly = true,
                                leadingIcon = Icons.Default.CalendarToday,
                                onClick = { openDatePicker() }
                            )
                        }
                        Box(modifier = Modifier.weight(0.35f)) {
                            GlassOutlinedTextField(
                                value = "$ageText سنة",
                                onValueChange = {},
                                label = "العمر ديناميكياً",
                                readOnly = true,
                                leadingIcon = Icons.Default.Cake
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // الجنس والحالة الاجتماعية
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassDropdownField(
                            value = gender,
                            onValueChange = { gender = it },
                            label = "الجنس",
                            options = listOf("ذكر", "أنثى"),
                            modifier = Modifier.weight(1f)
                        )
                        GlassDropdownField(
                            value = maritalStatus,
                            onValueChange = { maritalStatus = it },
                            label = "الحالة الاجتماعية",
                            options = listOf("متزوج", "أعزب", "أرمل", "مطلق", "مهجور"),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // عدد أفراد الأسرة
                    GlassOutlinedTextField(
                        value = familyMembersCount,
                        onValueChange = { familyMembersCount = it.filter { c -> c.isDigit() } },
                        label = "إجمالي عدد أفراد الأسرة *",
                        keyboardType = KeyboardType.Number,
                        leadingIcon = Icons.Default.Group
                    )
                }

                // 2. بطاقة بيانات الاتصال والزوجة
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "2. أرقام الاتصال وبيانات الزوجة",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = PalestineGreen
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassOutlinedTextField(
                            value = primaryPhone,
                            onValueChange = { primaryPhone = it },
                            label = "رقم الهاتف الأساسي *",
                            keyboardType = KeyboardType.Phone,
                            leadingIcon = Icons.Default.Phone,
                            modifier = Modifier.weight(1f)
                        )
                        GlassOutlinedTextField(
                            value = altPhone1,
                            onValueChange = { altPhone1 = it },
                            label = "رقم هاتف بديل",
                            keyboardType = KeyboardType.Phone,
                            leadingIcon = Icons.Default.PhoneAndroid,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (maritalStatus == "متزوج") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            GlassOutlinedTextField(
                                value = wifeName,
                                onValueChange = { wifeName = it },
                                label = "اسم الزوجة",
                                leadingIcon = Icons.Default.Female,
                                modifier = Modifier.weight(1f)
                            )
                            GlassOutlinedTextField(
                                value = wifeNationalID,
                                onValueChange = { wifeNationalID = ExcelParserHelper.convertEasternToArabicDigits(it).filter { c -> c.isDigit() }.take(9) },
                                label = "رقم هوية الزوجة",
                                keyboardType = KeyboardType.Number,
                                leadingIcon = Icons.Default.Badge,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // 3. بطاقة السكن والموقع الجغرافي
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "3. الموقع الجغرافي وبيانات الإيواء",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = PalestineGreen
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // المحلية
                    if (allowedLocalities.isNotEmpty()) {
                        GlassDropdownField(
                            value = allowedLocalities.firstOrNull { it.LocalityID == selectedLocalityId }?.LocalityName ?: "المحلية",
                            onValueChange = { selectedName ->
                                allowedLocalities.firstOrNull { it.LocalityName == selectedName }?.let {
                                    selectedLocalityId = it.LocalityID
                                }
                            },
                            label = "المحلية المعتمدة *",
                            options = allowedLocalities.map { it.LocalityName }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassOutlinedTextField(
                            value = currentMainArea,
                            onValueChange = { currentMainArea = it },
                            label = "المنطقة الرئيسية",
                            modifier = Modifier.weight(1f)
                        )
                        GlassOutlinedTextField(
                            value = currentSubArea,
                            onValueChange = { currentSubArea = it },
                            label = "المنطقة الفرعية / الحي",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassDropdownField(
                            value = shelterStatus,
                            onValueChange = { shelterStatus = it },
                            label = "حالة الإيواء",
                            options = listOf("إيواء داخلي", "إيواء خارجي", "خيمة", "منزل مضيف", "بيت مستأجر", "منزل متضرر"),
                            modifier = Modifier.weight(1f)
                        )
                        GlassDropdownField(
                            value = residentStatus,
                            onValueChange = { residentStatus = it },
                            label = "صفة الإقامة",
                            options = listOf("نازح", "مقيم", "عائد"),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (shelterStatus.contains("إيواء")) {
                        Spacer(modifier = Modifier.height(10.dp))
                        GlassOutlinedTextField(
                            value = shelterCenterName,
                            onValueChange = { shelterCenterName = it },
                            label = "اسم مركز أو مدرسة الإيواء",
                            leadingIcon = Icons.Default.HolidayVillage
                        )
                    }
                }

                // 4. بطاقة الأضرار والتنمية والاعتماد
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "4. أضرار الحرب والاعتماد الإداري",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = PalestineGreen
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GlassDropdownField(
                            value = damageType,
                            onValueChange = { damageType = it },
                            label = "نوع الضرر",
                            options = listOf("أضرار كلية", "أضرار جزئية بليغة", "أضرار جزئية صالحة للسكن", "بدون أضرار"),
                            modifier = Modifier.weight(1f)
                        )
                        GlassDropdownField(
                            value = developmentApproval,
                            onValueChange = { developmentApproval = it },
                            label = "اعتماد التنمية",
                            options = listOf("معتمد", "غير معتمد", "قيد المراجعة"),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    GlassOutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = "ملاحظات وتفاصيل إضافية عن الأسرة",
                        leadingIcon = Icons.Default.Notes
                    )
                }

                // زر الحفظ الزجاجي GlassButton
                GlassButton(
                    onClick = {
                        val members = familyMembersCount.toIntOrNull() ?: 1
                        val newFamily = FamilyEntity(
                            name = name.trim(),
                            nationalID = nationalID.trim(),
                            birthDate = birthDate.trim(),
                            gender = gender,
                            maritalStatus = maritalStatus,
                            familyMembersCount = members,
                            wifeName = wifeName.trim().ifBlank { null },
                            wifeNationalID = wifeNationalID.trim().ifBlank { null },
                            deathStatus = "على قيد الحياة",
                            developmentApproval = developmentApproval,
                            localityApproval = "معتمد",
                            worksApproval = "معتمد أشغال",
                            residentStatus = residentStatus,
                            damageType = damageType,
                            shelterStatus = shelterStatus,
                            localityID = selectedLocalityId,
                            notes = notes.trim().ifBlank { null },
                            createdDate = System.currentTimeMillis()
                        )

                        viewModel.insertFamily(newFamily) {
                            Toast.makeText(context, "تمت إضافة الأسرة بنجاح إلى قاعدة البيانات!", Toast.LENGTH_SHORT).show()
                            onNavigateBack()
                        }
                    },
                    enabled = !formState.isSaving && name.isNotBlank() && nationalID.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    icon = Icons.Default.Save,
                    containerColor = PalestineGreen
                ) {
                    if (formState.isSaving) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("جاري الحفظ الآمن في قاعدة البيانات...", fontWeight = FontWeight.Bold)
                    } else {
                        Text("حفظ وتسجيل الأسرة الآن", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

/**
 * حقل إدخال زجاجي أنيق متوافق مع نظام Glassmorphism
 */
@Composable
fun GlassOutlinedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
    isError: Boolean = false,
    errorMessage: String? = null,
    readOnly: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    leadingIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    onClick: (() -> Unit)? = null
) {
    val clickMod = if (onClick != null) Modifier.clickable { onClick() } else Modifier

    Column(modifier = modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label, style = MaterialTheme.typography.bodySmall) },
            readOnly = readOnly,
            isError = isError,
            singleLine = true,
            leadingIcon = leadingIcon?.let {
                { Icon(it, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(18.dp)) }
            },
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = GlassSurfaceLight,
                unfocusedContainerColor = GlassSurfaceSubtle,
                focusedBorderColor = PalestineGreen,
                unfocusedBorderColor = GlassBorderLight,
                focusedLabelColor = PalestineGreen,
                unfocusedLabelColor = SlateTextSecondary,
                cursorColor = PalestineGreen
            ),
            modifier = Modifier
                .fillMaxWidth()
                .then(clickMod)
        )
        if (isError && errorMessage != null) {
            Text(
                text = errorMessage,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(start = 6.dp, top = 2.dp)
            )
        }
    }
}

/**
 * حقل اختيار منسدل زجاجي GlassDropdownField
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlassDropdownField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    options: List<String>,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    var expanded by remember { mutableStateOf(false) }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it },
        modifier = modifier
    ) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, style = MaterialTheme.typography.bodySmall) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = GlassSurfaceLight,
                unfocusedContainerColor = GlassSurfaceSubtle,
                focusedBorderColor = PalestineGreen,
                unfocusedBorderColor = GlassBorderLight,
                focusedLabelColor = PalestineGreen,
                unfocusedLabelColor = SlateTextSecondary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Color.White)
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option, style = MaterialTheme.typography.bodyMedium) },
                    onClick = {
                        onValueChange(option)
                        expanded = false
                    }
                )
            }
        }
    }
}
