package com.humanitarian.aidmanagement.ui.screens.families

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.screens.children.ChildrenScreen
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamilyDetailsScreen(
    familyId: Long,
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    
    // التصحيح الوحيد المطلوب للبناء فقط: جمع الـ Flow الخاص بالأسرة بشكل صحيح
    val family by repository.getFamilyById(familyId).collectAsState(initial = null)
    
    var aidRecords by remember { mutableStateOf<List<AidRecordEntity>>(emptyList()) }
    var localitiesMap by remember { mutableStateOf<Map<Int, String>>(emptyMap()) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedTab by remember { mutableStateOf(0) }

    LaunchedEffect(familyId) {
        aidRecords = repository.getAidRecordsForFamilySync(familyId)
        val localitiesList = repository.getLocalities().first()
        localitiesMap = localitiesList.associate { it.LocalityID to it.LocalityName }
        isLoading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "الملف الشامل للأسرة: ${family?.name ?: ""}", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        val currentFamily = family
        if (isLoading && currentFamily == null) {
            Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (currentFamily == null) {
            Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
                Text("لم يتم العثور على بيانات الأسرة", color = MaterialTheme.colorScheme.error)
            }
        } else {
            val locName = localitiesMap[currentFamily.localityID] ?: "محلية #${currentFamily.localityID}"

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
            ) {
                // شريط التبويبات الذي يضم تفاصيل الأسرة وشاشة الأبناء والمساعدات الخاصة بها
                TabRow(selectedTabIndex = selectedTab) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("البيانات التفصيلية", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("شاشة الأبناء", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = { Text("المساعدات (${aidRecords.size})", fontWeight = FontWeight.Bold) }
                    )
                }

                when (selectedTab) {
                    0 -> {
                        // عرض التفاصيل والحقول كاملة كما أردتها
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            item {
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("البيانات الأساسية", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        HorizontalDivider()
                                        DetailItem("اسم رب الأسرة:", currentFamily.name)
                                        DetailItem("رقم الهوية الوطنية:", currentFamily.nationalID)
                                        DetailItem("المحلية والمنطقة:", "$locName - ${currentFamily.currentSubArea}")
                                        DetailItem("عدد أفراد الأسرة:", "${currentFamily.familyMembersCount} أفراد")
                                        DetailItem("رقم الجوال الرئيسي:", currentFamily.primaryPhone.ifBlank { "غير مسجل" })
                                        if (!currentFamily.alternative_phone_1.isNullOrBlank()) {
                                            DetailItem("جوال بديل:", currentFamily.alternative_phone_1)
                                        }
                                        DetailItem("حالة الإقامة:", currentFamily.residentStatus)
                                        DetailItem("نوع الضرر:", currentFamily.damageType)
                                        DetailItem("حالة الإيواء:", currentFamily.shelterStatus)
                                    }
                                }
                            }
                        }
                    }
                    1 -> {
                        // شاشة الأبناء الخاصة بالأسرة
                        Box(modifier = Modifier.fillMaxSize()) {
                            ChildrenScreen(repository = repository, familyId = familyId)
                        }
                    }
                    2 -> {
                        // شاشة المساعدات والترشيحات الخاصة بالأسرة
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (aidRecords.isEmpty()) {
                                item {
                                    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                        Text("لا توجد سجلات مساعدات مسجلة لهذه الأسرة حتى الآن", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            } else {
                                items(aidRecords, key = { it.aidRecordID }) { record ->
                                    Card(
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("سجل مساعدة رقم #${record.aidRecordID}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = if (record.recipientStatus.contains("مستلم") || record.recipientStatus.contains("تم التسليم")) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFFF59E0B).copy(alpha = 0.15f)
                                                ) {
                                                    Text(
                                                        text = record.recipientStatus,
                                                        color = if (record.recipientStatus.contains("مستلم") || record.recipientStatus.contains("تم التسليم")) Color(0xFF10B981) else Color(0xFFF59E0B),
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                            DetailItem("تاريخ الترشيح:", record.selectionDate ?: "-")
                                            DetailItem("المستودع / نقطة التوزيع:", record.warehouse)
                                            DetailItem("تاريخ الصرف:", record.deliveryDate ?: "لم تُصرف بعد")
                                            if (!record.notes.isNullOrBlank()) {
                                                DetailItem("ملاحظات:", record.notes ?: "")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}
