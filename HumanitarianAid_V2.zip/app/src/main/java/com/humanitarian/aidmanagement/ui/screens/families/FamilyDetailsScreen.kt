package com.humanitarian.aidmanagement.ui.screens.families

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.Period
import java.util.Date
import java.util.Locale

private val DetailsMintGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFFEDF7F2),
        Color(0xFFF6FAF8),
        Color(0xFFEAF4EF)
    )
)

private val GlassBorderMint = Color(0xFFD6E8DF)
private val SoftRowDividerColor = Color(0xFFECF3EF)
private val CalmLabelGray = Color(0xFF5F6E68)
private val PrimaryEmerald = Color(0xFF0F7B53)
private val VibrantEmerald = Color(0xFF10B981)
private val VibrantSkyBlue = Color(0xFF0EA5E9)
private val VibrantSoftRose = Color(0xFFF43F5E)
private val VibrantWarmAmber = Color(0xFFF59E0B)
private val VibrantIndigo = Color(0xFF6366F1)
private val DeepSlateText = Color(0xFF0F172A)

/**
 * شاشة تفاصيل الأسرة (FamilyDetailsScreen)
 * تصميم زجاجي نقي بدون ظلال رمادية (Zero Shadow Artifact)، مع ترويسة قابلة للتمرير،
 * شريط تبويبات زجاجي عائم (Sticky Segmented Control)، وصفوف بيانات متوازنة.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun FamilyDetailsScreen(
    familyId: Long,
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToAddChild: (familyId: Long, familyNationalId: String) -> Unit = { _, _ -> },
    viewModel: FamilyDetailsViewModel = viewModel(
        factory = FamilyDetailsViewModel.Factory(repository, familyId)
    )
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val family by repository.getFamilyById(familyId).collectAsStateWithLifecycle(initialValue = null)

    val aidTypes by repository.getActiveAidTypes().collectAsStateWithLifecycle(initialValue = emptyList())
    val projects by repository.getActiveProjects().collectAsStateWithLifecycle(initialValue = emptyList())

    var selectedTabIndex by remember { mutableStateOf(0) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(DetailsMintGradient)
        ) {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = "الملف الشامل للأسرة",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = DeepSlateText
                                )
                                val currentFamilyName = family?.name ?: uiState.family?.name
                                if (!currentFamilyName.isNullOrBlank()) {
                                    Text(
                                        text = currentFamilyName,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CalmLabelGray,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = {
                                viewModel.resetFilters()
                                onNavigateBack()
                            }) {
                                Icon(
                                    Icons.Default.ArrowForward,
                                    contentDescription = "رجوع",
                                    tint = DeepSlateText
                                )
                            }
                        },
                        actions = {
                            if (uiState.family != null && uiState.isAreaAllowed) {
                                if (uiState.canEdit) {
                                    IconButton(onClick = { showEditDialog = true }) {
                                        Icon(
                                            imageVector = Icons.Rounded.Edit,
                                            contentDescription = "تعديل بيانات الأسرة",
                                            tint = PrimaryEmerald
                                        )
                                    }
                                }
                                if (uiState.canDelete) {
                                    IconButton(onClick = { showDeleteConfirmDialog = true }) {
                                        Icon(
                                            imageVector = Icons.Rounded.Delete,
                                            contentDescription = "حذف الأسرة",
                                            tint = VibrantSoftRose
                                        )
                                    }
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color(0xFFEDF7F2).copy(alpha = 0.94f),
                            titleContentColor = DeepSlateText
                        )
                    )
                }
            ) { paddingValues ->
                when {
                    uiState.isLoading -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues),
                            contentAlignment = Alignment.Center
                        ) {
                            VibrantGlassDetailCard(modifier = Modifier.padding(32.dp)) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    CircularProgressIndicator(color = PrimaryEmerald)
                                    Text(
                                        text = "جاري تحميل الملف الشامل للأسرة...",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = CalmLabelGray
                                    )
                                }
                            }
                        }
                    }

                    uiState.family == null -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues),
                            contentAlignment = Alignment.Center
                        ) {
                            VibrantGlassDetailCard(modifier = Modifier.padding(24.dp)) {
                                Text(
                                    text = uiState.errorMessage ?: "تعذر العثور على ملف الأسرة المطلوبة.",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = VibrantSoftRose,
                                    modifier = Modifier.padding(20.dp)
                                )
                            }
                        }
                    }

                    !uiState.isAreaAllowed -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(CircleShape)
                                            .background(VibrantSoftRose.copy(alpha = 0.14f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Lock,
                                            contentDescription = null,
                                            tint = VibrantSoftRose,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }

                                    Text(
                                        text = "تقييد أمني للمنطقة الفرعية",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = VibrantSoftRose
                                    )

                                    Text(
                                        text = "عذراً، ليس لديك صلاحية للاطلاع على بيانات هذه الأسرة نظراً لتقييد حسابك الجغرافي.\nالأسرة مسجلة في المنطقة: (${uiState.family?.currentSubArea.orEmpty()}).",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = CalmLabelGray,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 22.sp
                                    )

                                    Button(
                                        onClick = onNavigateBack,
                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryEmerald),
                                        shape = RoundedCornerShape(12.dp),
                                        elevation = ButtonDefaults.buttonElevation(0.dp, 0.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.ArrowForward,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("العودة لقائمة الأسر", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    else -> {
                        val currentFamily = family ?: uiState.family ?: return@Scaffold
                        val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }
                        val dynamicallyCalculatedAge = remember(currentFamily.date_of_birth) {
                            viewModel.calculateAge(currentFamily.date_of_birth)
                        }

                        // حوار التعديل
                        if (showEditDialog) {
                            EditFamilyDialog(
                                family = currentFamily,
                                localities = uiState.localities,
                                onDismiss = { showEditDialog = false },
                                onSave = { updatedFamily ->
                                    viewModel.updateFamily(updatedFamily) { success, error ->
                                        if (success) {
                                            Toast.makeText(
                                                context,
                                                "تم حفظ وتحديث بيانات الأسرة بنجاح",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            showEditDialog = false
                                        } else {
                                            Toast.makeText(
                                                context,
                                                "خطأ أثناء حفظ التعديل: $error",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                    }
                                }
                            )
                        }

                        // حوار الحذف الآمن المشروط حصراً بكلمة مرور مدير النظام
                        if (showDeleteConfirmDialog) {
                            com.humanitarian.aidmanagement.ui.components.AdminPasswordConfirmDialog(
                                title = "تأكيد حذف ملف الأسرة نهائياً",
                                itemName = currentFamily.name,
                                itemTypeLabel = "الأسرة",
                                repository = repository,
                                onConfirm = {
                                    showDeleteConfirmDialog = false
                                    viewModel.deleteFamily { success, error ->
                                        if (success) {
                                            Toast.makeText(
                                                context,
                                                "تم حذف الأسرة بنجاح بعد التحقق من كلمة مرور المدير",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            onNavigateBack()
                                        } else {
                                            Toast.makeText(
                                                context,
                                                "خطأ أثناء الحذف: $error",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                    }
                                },
                                onDismiss = { showDeleteConfirmDialog = false }
                            )
                        }

                        // قائمة موحدة قابلة للتمرير: بطاقة رأس الأسرة تنساب للأعلى، والتبويبات تثبت بشكل رشيق
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues),
                            contentPadding = PaddingValues(bottom = 28.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // 1. بطاقة رأس الأسرة (أول عنصر داخل LazyColumn لتحرير مساحة الشاشة عند التمرير)
                            item(key = "family_hero_card") {
                                FamilyHeroCard(
                                    family = currentFamily,
                                    localityName = uiState.localityName,
                                    childrenCount = uiState.children.size,
                                    aidCount = uiState.aidRecords.size
                                )
                            }

                            // 2. شريط التبويبات الزجاجي العائم (Glass Segmented Control) مثبت كـ stickyHeader
                            stickyHeader(key = "family_segmented_tabs") {
                                GlassSegmentedTabBar(
                                    selectedTabIndex = selectedTabIndex,
                                    childrenCount = uiState.children.size,
                                    aidCount = uiState.aidRecords.size,
                                    onTabSelected = { selectedTabIndex = it }
                                )
                            }

                            // 3. محتوى التبويب المحدد
                            when (selectedTabIndex) {
                                0 -> familyBasicDetailsItems(
                                    family = currentFamily,
                                    localityName = uiState.localityName,
                                    dynamicallyCalculatedAge = dynamicallyCalculatedAge,
                                    dateFormat = dateFormat,
                                    onDialPhone = { phone ->
                                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${phone.trim()}"))
                                        runCatching { context.startActivity(intent) }
                                            .onFailure {
                                                Toast.makeText(
                                                    context,
                                                    "تعذر فتح تطبيق الاتصال",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }
                                    }
                                )

                                1 -> familyChildrenItems(
                                    children = uiState.children,
                                    canEdit = uiState.canEdit,
                                    onAddChild = {
                                        onNavigateToAddChild(currentFamily.familyID, currentFamily.nationalID)
                                    }
                                )

                                2 -> familyAidRecordsItems(
                                    aidRecords = uiState.aidRecords,
                                    aidTypes = aidTypes,
                                    projects = projects
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * بطاقة زجاجية نقية بدون أي ظل رمادي (Zero Shadow Artifact)
 */
@Composable
private fun VibrantGlassDetailCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = Color.White.copy(alpha = 0.88f),
        border = BorderStroke(1.dp, GlassBorderMint),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp
    ) {
        Column(content = content)
    }
}

/**
 * شريط التبويبات الزجاجي العائم (Glass Segmented Control)
 */
@Composable
private fun GlassSegmentedTabBar(
    selectedTabIndex: Int,
    childrenCount: Int,
    aidCount: Int,
    onTabSelected: (Int) -> Unit
) {
    val tabs = listOf(
        Triple("البيانات", Icons.Rounded.Badge, 0),
        Triple("الأبناء ($childrenCount)", Icons.Rounded.People, 1),
        Triple("المساعدات ($aidCount)", Icons.Rounded.History, 2)
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFEDF7F2).copy(alpha = 0.96f))
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFFE4F0EA),
            border = BorderStroke(1.dp, GlassBorderMint),
            shadowElevation = 0.dp,
            tonalElevation = 0.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEach { (title, icon, index) ->
                    val isSelected = selectedTabIndex == index
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onTabSelected(index) },
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) Color.White else Color.Transparent,
                        border = if (isSelected) BorderStroke(0.8.dp, GlassBorderMint) else null,
                        shadowElevation = 0.dp,
                        tonalElevation = 0.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 6.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (isSelected) PrimaryEmerald else Color(0xFF52635D)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) PrimaryEmerald else Color(0xFF52635D),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * البطاقة الرأسية الموجزة (Family Hero Card) - تنساب للأعلى عند التمرير
 */
@Composable
fun FamilyHeroCard(
    family: FamilyEntity,
    localityName: String,
    childrenCount: Int,
    aidCount: Int
) {
    VibrantGlassDetailCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    VibrantEmerald.copy(alpha = 0.18f),
                                    VibrantSkyBlue.copy(alpha = 0.16f)
                                )
                            )
                        )
                        .border(1.dp, GlassBorderMint, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.FamilyRestroom,
                        contentDescription = null,
                        modifier = Modifier.size(27.dp),
                        tint = PrimaryEmerald
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = family.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DeepSlateText,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = VibrantSkyBlue.copy(alpha = 0.13f),
                            border = BorderStroke(0.8.dp, VibrantSkyBlue.copy(alpha = 0.28f)),
                            shadowElevation = 0.dp,
                            tonalElevation = 0.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CreditCard,
                                    contentDescription = null,
                                    tint = Color(0xFF0369A1),
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = family.nationalID,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0369A1)
                                )
                            }
                        }

                        if (localityName.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = VibrantEmerald.copy(alpha = 0.13f),
                                border = BorderStroke(0.8.dp, VibrantEmerald.copy(alpha = 0.28f)),
                                shadowElevation = 0.dp,
                                tonalElevation = 0.dp
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.LocationOn,
                                        contentDescription = null,
                                        tint = PrimaryEmerald,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = localityName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = PrimaryEmerald,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            val shelterText = family.shelterStatus.ifBlank { "خارج الإيواء" }

            // شريط إحصائيات سريعة مدمج بدون بطاقة شفافة مزدوجة
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFF3F9F6))
                    .border(1.dp, Color(0xFFDCECE4), RoundedCornerShape(14.dp))
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                QuickMetric(
                    label = "أفراد الأسرة",
                    value = "${family.familyMembersCount}",
                    icon = Icons.Rounded.Groups,
                    tint = VibrantSkyBlue
                )
                VerticalDivider(modifier = Modifier.height(26.dp), color = Color(0xFFD6E8DF))
                QuickMetric(
                    label = "الأبناء",
                    value = "$childrenCount",
                    icon = Icons.Rounded.ChildCare,
                    tint = VibrantIndigo
                )
                VerticalDivider(modifier = Modifier.height(26.dp), color = Color(0xFFD6E8DF))
                QuickMetric(
                    label = "المساعدات",
                    value = "$aidCount",
                    icon = Icons.Rounded.VolunteerActivism,
                    tint = PrimaryEmerald
                )
                VerticalDivider(modifier = Modifier.height(26.dp), color = Color(0xFFD6E8DF))
                QuickMetric(
                    label = "الإيواء",
                    value = shelterText,
                    icon = Icons.Rounded.House,
                    tint = when {
                        family.damageType.contains("كلي") -> VibrantSoftRose
                        shelterText.contains("خارج") -> VibrantSkyBlue
                        else -> VibrantWarmAmber
                    }
                )
            }
        }
    }
}

@Composable
fun QuickMetric(label: String, value: String, icon: ImageVector, tint: Color = VibrantSkyBlue) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = tint
            )
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = DeepSlateText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text(
            text = label,
            fontSize = 10.sp,
            color = CalmLabelGray
        )
    }
}

private data class DetailFieldSpec(
    val icon: ImageVector,
    val label: String,
    val value: String?,
    val iconTint: Color = VibrantSkyBlue,
    val badgeColor: Color? = null,
    val textColor: Color? = null,
    val isLongField: Boolean = false
)

private fun isMeaningfulValue(value: String?): Boolean {
    if (value.isNullOrBlank()) return false
    val clean = value.trim()
    return clean.isNotEmpty() && clean != "-" && clean != "null"
}

/**
 * عناصر التبويب الأول: البيانات الأساسية والتفصيلية ضمن القائمة الموحدة
 */
private fun LazyListScope.familyBasicDetailsItems(
    family: FamilyEntity,
    localityName: String,
    dynamicallyCalculatedAge: Int?,
    dateFormat: SimpleDateFormat,
    onDialPhone: (String) -> Unit
) {
    // 1. بطاقة الهوية والمعلومات الشخصية
    item(key = "section_identity") {
        val genderIcon = if (family.gender.contains("أنث")) Icons.Rounded.Female else Icons.Rounded.Male
        val genderTint = if (family.gender.contains("أنث")) VibrantSoftRose else VibrantSkyBlue
        val isDeceased = family.deathStatus.contains("وفاة") || family.deathStatus.contains("متوفى")

        val identityFields = buildList {
            add(
                DetailFieldSpec(
                    icon = Icons.Rounded.Person,
                    label = "الاسم الرباعي الكامل",
                    value = family.name,
                    iconTint = PrimaryEmerald,
                    isLongField = true
                )
            )
            add(DetailFieldSpec(Icons.Rounded.CreditCard, "رقم الهوية الوطنية", family.nationalID, VibrantSkyBlue))
            add(DetailFieldSpec(Icons.Rounded.CalendarToday, "تاريخ الميلاد", family.date_of_birth, VibrantSkyBlue))
            dynamicallyCalculatedAge?.let { ageVal ->
                add(
                    DetailFieldSpec(
                        icon = Icons.Rounded.Cake,
                        label = "العمر المحسوب حالياً",
                        value = "$ageVal سنة",
                        iconTint = VibrantEmerald,
                        badgeColor = PrimaryEmerald
                    )
                )
            }
            add(DetailFieldSpec(genderIcon, "الجنس", family.gender, genderTint))
            add(DetailFieldSpec(Icons.Rounded.Favorite, "الحالة الاجتماعية", family.maritalStatus, VibrantSoftRose))
            add(
                DetailFieldSpec(
                    icon = if (isDeceased) Icons.Rounded.HeartBroken else Icons.Rounded.VerifiedUser,
                    label = "حالة الحياة والوفاة",
                    value = family.deathStatus,
                    iconTint = if (isDeceased) VibrantSoftRose else PrimaryEmerald,
                    badgeColor = if (isDeceased) VibrantSoftRose else PrimaryEmerald
                )
            )
            add(DetailFieldSpec(Icons.Rounded.EventBusy, "تاريخ الوفاة", family.deathDate, VibrantSoftRose))
            add(DetailFieldSpec(Icons.Rounded.Badge, "رقم كرت المؤن", family.rationCardNumber, VibrantIndigo))
        }

        DetailSectionCard(
            title = "الهوية والمعلومات الشخصية",
            icon = Icons.Rounded.Person,
            badgeText = "هوية: ${family.nationalID}",
            badgeColor = VibrantSkyBlue,
            fields = identityFields
        )
    }

    // 2. بطاقة أرقام وبيانات الاتصال (مع زر اتصال سريع وحالة فارغة أنيقة)
    item(key = "section_contact") {
        val phoneEntries = listOf(
            Triple(Icons.Rounded.Phone, "رقم الجوال الأساسي", family.primary_phone to PrimaryEmerald),
            Triple(Icons.Rounded.Call, "رقم جوال بديل (١)", family.alternative_phone_1 to VibrantEmerald),
            Triple(Icons.Rounded.PhoneIphone, "رقم جوال بديل (٢)", family.alternative_phone_2 to VibrantSkyBlue)
        ).filter { isMeaningfulValue(it.third.first) }

        VibrantGlassDetailCard(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                SectionHeaderWithBadge(
                    title = "أرقام وبيانات الاتصال",
                    icon = Icons.Rounded.Phone,
                    badgeText = if (phoneEntries.isNotEmpty()) "${phoneEntries.size} أرقام" else "التواصل",
                    badgeColor = PrimaryEmerald
                )
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = SoftRowDividerColor, thickness = 0.8.dp)

                if (phoneEntries.isEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF1F5F3))
                                .border(1.dp, Color(0xFFDDE7E2), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PhoneDisabled,
                                contentDescription = null,
                                tint = Color(0xFF7B8C85),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = "لا توجد أرقام اتصال مسجلة",
                            fontSize = 13.sp,
                            color = CalmLabelGray,
                            fontWeight = FontWeight.Medium
                        )
                    }
                } else {
                    phoneEntries.forEachIndexed { index, (icon, label, pair) ->
                        val phoneNumber = pair.first?.trim().orEmpty()
                        if (phoneNumber.isEmpty()) return@forEachIndexed
                        val tint = pair.second
                        if (index > 0) {
                            HorizontalDivider(color = SoftRowDividerColor, thickness = 0.8.dp)
                        }
                        ContactPhoneRow(
                            icon = icon,
                            label = label,
                            phoneNumber = phoneNumber,
                            iconTint = tint,
                            onDialClick = { onDialPhone(phoneNumber) }
                        )
                    }
                }
            }
        }
    }

    // 3. بطاقة بيانات الزوج/الزوجة والتركيبة الأسرية
    item(key = "section_spouse") {
        val spouseFields = listOf(
            DetailFieldSpec(
                icon = Icons.Rounded.People,
                label = "اسم الزوج/الزوجة",
                value = family.wifeName,
                iconTint = VibrantIndigo,
                isLongField = family.wifeName.orEmpty().trim().length > 22
            ),
            DetailFieldSpec(Icons.Rounded.CreditCard, "رقم هوية الزوج/الزوجة", family.wifeNationalID, VibrantSkyBlue),
            DetailFieldSpec(
                icon = Icons.Rounded.Groups,
                label = "إجمالي عدد أفراد الأسرة",
                value = if (family.familyMembersCount > 0) "${family.familyMembersCount} أفراد" else null,
                iconTint = PrimaryEmerald,
                badgeColor = VibrantSkyBlue
            )
        )
        DetailSectionCard(
            title = "الزوج/الزوجة والتركيبة الأسرية",
            icon = Icons.Rounded.FamilyRestroom,
            badgeText = "${family.familyMembersCount} أفراد",
            badgeColor = VibrantIndigo,
            fields = spouseFields
        )
    }

    // 4. بطاقة السكن ومراكز الإيواء والمواقع الجغرافية
    item(key = "section_shelter") {
        val isDisplacedShelter = family.shelterStatus.contains("مخيم") ||
            family.shelterStatus.contains("نازح") ||
            family.shelterStatus.contains("داخلي")
        val shelterChipColor = if (isDisplacedShelter) VibrantSoftRose else VibrantSkyBlue

        val shelterFields = listOf(
            DetailFieldSpec(Icons.Rounded.LocationOn, "المحلية المعتمدة", family.currentSubArea.ifBlank { localityName }, VibrantSkyBlue),
            DetailFieldSpec(
                icon = Icons.Rounded.House,
                label = "حالة الإيواء الحالية",
                value = family.shelterStatus,
                iconTint = shelterChipColor,
                badgeColor = shelterChipColor
            ),
            DetailFieldSpec(
                icon = Icons.Rounded.HolidayVillage,
                label = "اسم المخيم / مركز الإيواء",
                value = family.shelter_center_name,
                iconTint = VibrantSoftRose,
                badgeColor = VibrantSoftRose
            ),
            DetailFieldSpec(Icons.Rounded.Map, "المنطقة الرئيسية الحالية", family.currentMainArea, VibrantWarmAmber),
            DetailFieldSpec(Icons.Rounded.Place, "المنطقة الفرعية الحالية", family.currentSubArea, VibrantSkyBlue),
            DetailFieldSpec(Icons.Rounded.AltRoute, "الشعبة الحالية", family.currentBranch, PrimaryEmerald),
            DetailFieldSpec(Icons.Rounded.Mosque, "المسجد الحالي", family.currentMosque, PrimaryEmerald),
            DetailFieldSpec(Icons.Rounded.History, "المنطقة الرئيسية الأصلية", family.originalMainArea, VibrantSoftRose),
            DetailFieldSpec(Icons.Rounded.Map, "المنطقة الفرعية الأصلية", family.originalSubArea, VibrantSoftRose),
            DetailFieldSpec(Icons.Rounded.ShareLocation, "الشعبة الأصلية", family.originalBranch, VibrantWarmAmber),
            DetailFieldSpec(Icons.Rounded.Mosque, "المسجد الأصلي", family.originalMosque, VibrantWarmAmber)
        )

        DetailSectionCard(
            title = "السكن والموقع الجغرافي والنزوح",
            icon = Icons.Rounded.LocationOn,
            badgeText = family.currentSubArea.ifBlank { localityName },
            badgeColor = VibrantSkyBlue,
            fields = shelterFields
        )
    }

    // 5. بطاقة مصادر الدخل والمعيشة
    item(key = "section_income") {
        val incomeFields = listOf(
            DetailFieldSpec(Icons.Rounded.Payments, "مصدر الدخل الأساسي (١)", family.incomeSource1, PrimaryEmerald),
            DetailFieldSpec(Icons.Rounded.AccountBalanceWallet, "مصدر الدخل الإضافي (٢)", family.income_source_2, VibrantSkyBlue)
        )
        DetailSectionCard(
            title = "مصادر الدخل والوضع الاقتصادي",
            icon = Icons.Rounded.Payments,
            badgeText = family.incomeSource1.ifBlank { "الدخل" },
            badgeColor = PrimaryEmerald,
            fields = incomeFields
        )
    }

    // 6. بطاقة الحالة الصحية وأضرار الحرب
    item(key = "section_health") {
        val damageColor = when {
            family.damageType.contains("كلي") -> VibrantSoftRose
            family.damageType.contains("جزئي") || family.damageType.contains("بليغ") -> VibrantWarmAmber
            else -> PrimaryEmerald
        }
        val injuryHealthy = family.injuryStatus.contains("سليم")

        val healthFields = listOf(
            DetailFieldSpec(
                icon = Icons.Rounded.HomeWork,
                label = "نوع أضرار الحرب للمنزل",
                value = family.damageType,
                iconTint = damageColor,
                badgeColor = damageColor
            ),
            DetailFieldSpec(
                icon = Icons.Rounded.WarningAmber,
                label = "وصف تفاصيل أضرار المنزل",
                value = family.damageDescription,
                iconTint = VibrantWarmAmber,
                isLongField = true
            ),
            DetailFieldSpec(
                icon = Icons.Rounded.LocalHospital,
                label = "حالة الإصابة المسجلة",
                value = family.injuryStatus,
                iconTint = if (injuryHealthy) PrimaryEmerald else VibrantSoftRose,
                badgeColor = if (injuryHealthy) PrimaryEmerald else VibrantSoftRose
            ),
            DetailFieldSpec(Icons.Rounded.Event, "تاريخ الإصابة", family.injuryDate, VibrantSoftRose)
        )

        DetailSectionCard(
            title = "الحالة الصحية وأضرار الحرب",
            icon = Icons.Rounded.LocalHospital,
            badgeText = family.damageType.ifBlank { family.injuryStatus },
            badgeColor = damageColor,
            fields = healthFields
        )
    }

    // 7. بطاقة الاعتمادات والتصنيفات الرسمية
    item(key = "section_approvals") {
        val devApproved = family.developmentApproval.contains("معتمد") && !family.developmentApproval.contains("غير")
        val locApproved = family.localityApproval.contains("معتمد") && !family.localityApproval.contains("غير")
        val isDisplacedResident = family.residentStatus.contains("نازح")

        val approvalFields = listOf(
            DetailFieldSpec(
                icon = Icons.Rounded.Verified,
                label = "اعتماد وزارة التنمية",
                value = family.developmentApproval,
                iconTint = if (devApproved) PrimaryEmerald else VibrantSoftRose,
                badgeColor = if (devApproved) PrimaryEmerald else VibrantSoftRose
            ),
            DetailFieldSpec(
                icon = Icons.Rounded.DomainVerification,
                label = "اعتماد المناطق والمحليات",
                value = family.localityApproval,
                iconTint = if (locApproved) PrimaryEmerald else VibrantWarmAmber,
                badgeColor = if (locApproved) PrimaryEmerald else VibrantWarmAmber
            ),
            DetailFieldSpec(
                icon = Icons.Rounded.Gavel,
                label = "اعتماد وزارة الأشغال",
                value = family.worksApproval,
                iconTint = VibrantSkyBlue,
                badgeColor = VibrantSkyBlue
            ),
            DetailFieldSpec(
                icon = Icons.Rounded.PersonPin,
                label = "حالة الإقامة الرسمية",
                value = family.residentStatus,
                iconTint = if (isDisplacedResident) VibrantSoftRose else VibrantSkyBlue,
                badgeColor = if (isDisplacedResident) VibrantSoftRose else VibrantSkyBlue
            )
        )

        DetailSectionCard(
            title = "الاعتمادات والتصنيفات الرسمية",
            icon = Icons.Rounded.Verified,
            badgeText = family.developmentApproval.ifBlank { "اعتمادات" },
            badgeColor = if (devApproved) PrimaryEmerald else VibrantWarmAmber,
            fields = approvalFields
        )
    }

    // 8. الملاحظات الإدارية وتواريخ القيد
    item(key = "section_notes") {
        val notesFields = listOf(
            DetailFieldSpec(
                icon = Icons.Rounded.Notes,
                label = "الملاحظات الإدارية والميدانية",
                value = family.notes,
                iconTint = VibrantWarmAmber,
                isLongField = true
            ),
            DetailFieldSpec(
                icon = Icons.Rounded.Schedule,
                label = "تاريخ التسجيل الأولي",
                value = if (family.createdDate > 0) dateFormat.format(Date(family.createdDate)) else null,
                iconTint = VibrantSkyBlue
            ),
            DetailFieldSpec(
                icon = Icons.Rounded.Update,
                label = "تاريخ آخر تعديل للملف",
                value = family.modifiedDate?.let { if (it > 0) dateFormat.format(Date(it)) else null },
                iconTint = PrimaryEmerald
            )
        )

        DetailSectionCard(
            title = "الملاحظات الإدارية وتواريخ القيد",
            icon = Icons.Rounded.Description,
            badgeText = "سجل موثق",
            badgeColor = VibrantWarmAmber,
            fields = notesFields
        )
    }
}

/**
 * بطاقة قسم موحدة تعرض الحقول غير الفارغة فقط مع فواصل أفقية ناعمة بين الصفوف
 */
@Composable
private fun DetailSectionCard(
    title: String,
    icon: ImageVector,
    badgeText: String,
    badgeColor: Color,
    fields: List<DetailFieldSpec>
) {
    val visibleFields = fields.filter { isMeaningfulValue(it.value) }
    if (visibleFields.isEmpty()) return

    VibrantGlassDetailCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            SectionHeaderWithBadge(
                title = title,
                icon = icon,
                badgeText = badgeText,
                badgeColor = badgeColor
            )
            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = SoftRowDividerColor, thickness = 0.8.dp)

            visibleFields.forEachIndexed { index, spec ->
                if (index > 0) {
                    HorizontalDivider(color = SoftRowDividerColor, thickness = 0.8.dp)
                }
                DetailFieldItem(
                    icon = spec.icon,
                    label = spec.label,
                    value = spec.value,
                    iconTint = spec.iconTint,
                    badgeColor = spec.badgeColor,
                    textColor = spec.textColor,
                    isLongField = spec.isLongField
                )
            }
        }
    }
}

/**
 * صف رقم اتصال مع زر اتصال سريع (Intent.ACTION_DIAL)
 */
@Composable
private fun ContactPhoneRow(
    icon: ImageVector,
    label: String,
    phoneNumber: String,
    iconTint: Color,
    onDialClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(iconTint.copy(alpha = 0.13f))
                .border(1.dp, iconTint.copy(alpha = 0.25f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = iconTint,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                fontSize = 12.sp,
                color = CalmLabelGray,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = phoneNumber,
                fontSize = 14.sp,
                color = DeepSlateText,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0xFFE6F4EA))
                .border(1.dp, Color(0xFFB7E1CD), CircleShape)
                .clickable(onClick = onDialClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Phone,
                contentDescription = "اتصال سريع",
                tint = PrimaryEmerald,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * مكوّن عرض حقل بيانات متوازن (Balanced Row Layout):
 * - للحقول القصيرة: صف بعرض البطاقة الكامل (يمين: أيقونة دائرية 36.dp + العنوان، يسار: القيمة العريضة أو الكبسولة)
 * - للحقول الطويلة فقط (الاسم الرباعي، الملاحظات): العنوان فوق القيمة بعرض البطاقة الكامل
 */
@Composable
fun DetailFieldItem(
    icon: ImageVector,
    label: String,
    value: String?,
    iconTint: Color = VibrantSkyBlue,
    badgeColor: Color? = null,
    textColor: Color? = null,
    isLongField: Boolean = false
) {
    val cleanValue = value?.trim().orEmpty()
    if (!isMeaningfulValue(cleanValue)) return

    if (isLongField) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 9.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(iconTint.copy(alpha = 0.13f))
                        .border(1.dp, iconTint.copy(alpha = 0.25f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Text(
                    text = label,
                    fontSize = 12.sp,
                    color = CalmLabelGray,
                    fontWeight = FontWeight.Medium
                )
            }

            Text(
                text = cleanValue,
                fontSize = 14.sp,
                color = textColor ?: DeepSlateText,
                fontWeight = FontWeight.Bold,
                lineHeight = 20.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 46.dp)
            )
        }
    } else {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // يمين الصف: الأيقونة الدائرية الملونة (36.dp) + عنوان الحقل بلون رمادي هادئ
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.13f))
                    .border(1.dp, iconTint.copy(alpha = 0.25f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Text(
                text = label,
                fontSize = 13.sp,
                color = CalmLabelGray,
                fontWeight = FontWeight.Medium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )

            Spacer(modifier = Modifier.width(10.dp))

            // يسار الصف: القيمة بخط عريض داكن أو داخل كبسولة ملونة ناعمة
            if (badgeColor != null) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = badgeColor.copy(alpha = 0.13f),
                    border = BorderStroke(0.8.dp, badgeColor.copy(alpha = 0.30f)),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp,
                    modifier = Modifier.widthIn(max = 180.dp)
                ) {
                    Text(
                        text = cleanValue,
                        fontSize = 12.sp,
                        color = textColor ?: badgeColor,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            } else {
                Text(
                    text = cleanValue,
                    fontSize = 14.sp,
                    color = textColor ?: DeepSlateText,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.End,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.widthIn(max = 180.dp)
                )
            }
        }
    }
}

/**
 * عنوان القسم مع الشارة والأيقونة الدائرية الملونة
 */
@Composable
fun SectionHeaderWithBadge(
    title: String,
    icon: ImageVector,
    badgeText: String,
    badgeColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f, fill = false)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(badgeColor.copy(alpha = 0.13f))
                    .border(1.dp, badgeColor.copy(alpha = 0.24f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = badgeColor
                )
            }

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = DeepSlateText,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (badgeText.isNotBlank()) {
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
                shape = RoundedCornerShape(50),
                color = badgeColor.copy(alpha = 0.13f),
                border = BorderStroke(0.8.dp, badgeColor.copy(alpha = 0.28f)),
                shadowElevation = 0.dp,
                tonalElevation = 0.dp
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = badgeColor,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * عناصر التبويب الثاني: الأبناء والتابعون ضمن القائمة الموحدة
 */
private fun LazyListScope.familyChildrenItems(
    children: List<ChildEntity>,
    canEdit: Boolean,
    onAddChild: () -> Unit
) {
    if (children.isEmpty()) {
        item(key = "children_empty") {
            VibrantGlassDetailCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(PrimaryEmerald.copy(alpha = 0.13f))
                            .border(1.dp, PrimaryEmerald.copy(alpha = 0.26f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ChildCare,
                            contentDescription = null,
                            modifier = Modifier.size(34.dp),
                            tint = PrimaryEmerald
                        )
                    }
                    Text(
                        text = "لا يوجد أبناء أو تابعون مسجلون",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DeepSlateText
                    )
                    Text(
                        text = "لم يتم تسجيل بيانات أطفال مرتبطين بهذه الأسرة حتى الآن. يمكنك إضافة وتوثيق الأبناء مباشرة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CalmLabelGray,
                        textAlign = TextAlign.Center
                    )

                    if (canEdit) {
                        com.humanitarian.aidmanagement.ui.components.GlassButton(
                            onClick = onAddChild,
                            shape = RoundedCornerShape(12.dp),
                            icon = Icons.Rounded.PersonAdd,
                            containerColor = PrimaryEmerald,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("إضافة فرد / ابن جديد للأسرة", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    } else {
        item(key = "children_header") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "قائمة الأبناء والتابعين المسجلين (${children.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = DeepSlateText
                    )
                    val boysCount = children.count { it.gender.contains("ذكر") }
                    val girlsCount = children.size - boysCount
                    Text(
                        text = "$boysCount ذكور • $girlsCount إناث",
                        style = MaterialTheme.typography.labelSmall,
                        color = PrimaryEmerald,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (canEdit) {
                    com.humanitarian.aidmanagement.ui.components.GlassButton(
                        onClick = onAddChild,
                        shape = RoundedCornerShape(10.dp),
                        icon = Icons.Rounded.Add,
                        containerColor = PrimaryEmerald,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("إضافة ابن", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        items(children, key = { "child_${it.childID}" }) { child ->
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                ChildItemCard(child = child)
            }
        }
    }
}

/**
 * دالة مساعدة لحساب وعرض العمر الدقيق للأبناء والتابعين
 */
fun calculateExactAge(birthDateStr: String?): String {
    if (birthDateStr.isNullOrBlank()) return "تاريخ الميلاد غير صالح"
    val cleanDate = birthDateStr.trim().replace('/', '-')
    val parts = cleanDate.split('-')
    if (parts.size != 3) return "تاريخ الميلاد غير صالح"

    val birthLocalDate = try {
        val y = parts[0].toIntOrNull() ?: return "تاريخ الميلاد غير صالح"
        val m = parts[1].toIntOrNull() ?: return "تاريخ الميلاد غير صالح"
        val d = parts[2].toIntOrNull() ?: return "تاريخ الميلاد غير صالح"
        LocalDate.of(y, m, d)
    } catch (e: Exception) {
        try {
            LocalDate.parse(cleanDate)
        } catch (e2: Exception) {
            return "تاريخ الميلاد غير صالح"
        }
    }

    val today = LocalDate.now()
    if (birthLocalDate.isAfter(today)) {
        return "تاريخ الميلاد غير صالح"
    }

    val period = Period.between(birthLocalDate, today)
    return "(${period.years}) سنة و (${period.months}) شهر و (${period.days}) يوم"
}

@Composable
fun ChildItemCard(child: ChildEntity) {
    val isMale = child.gender.contains("ذكر")
    val avatarTint = if (isMale) VibrantSkyBlue else VibrantSoftRose
    val avatarBg = avatarTint.copy(alpha = 0.13f)
    val exactAge = calculateExactAge(child.birthDate)
    val isAgeValid = exactAge != "تاريخ الميلاد غير صالح"

    VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(avatarBg)
                        .border(1.dp, avatarTint.copy(alpha = 0.25f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ChildCare,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                        tint = avatarTint
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text(
                        text = child.childName.ifBlank { "طفل / تابع مسجل" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DeepSlateText
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CreditCard,
                            contentDescription = null,
                            tint = VibrantSkyBlue,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "هوية: ${child.nationalID}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CalmLabelGray,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = avatarBg,
                    border = BorderStroke(0.8.dp, avatarTint.copy(alpha = 0.30f)),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isMale) Icons.Rounded.Male else Icons.Rounded.Female,
                            contentDescription = null,
                            tint = avatarTint,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = child.gender.ifBlank { if (isMale) "ذكر" else "أنثى" },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = avatarTint
                        )
                    }
                }
            }

            HorizontalDivider(color = SoftRowDividerColor, thickness = 0.8.dp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(VibrantSkyBlue.copy(alpha = 0.13f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Cake,
                            contentDescription = null,
                            tint = VibrantSkyBlue,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Column {
                        Text("تاريخ الميلاد", fontSize = 10.sp, color = CalmLabelGray)
                        Text(
                            text = child.birthDate.ifBlank { "غير مسجل" },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = DeepSlateText
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (isAgeValid) PrimaryEmerald.copy(alpha = 0.12f) else VibrantSoftRose.copy(alpha = 0.13f),
                    border = BorderStroke(
                        0.8.dp,
                        (if (isAgeValid) PrimaryEmerald else VibrantSoftRose).copy(alpha = 0.30f)
                    ),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isAgeValid) Icons.Rounded.Schedule else Icons.Rounded.WarningAmber,
                            contentDescription = null,
                            tint = if (isAgeValid) PrimaryEmerald else VibrantSoftRose,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = exactAge,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isAgeValid) PrimaryEmerald else VibrantSoftRose
                        )
                    }
                }
            }
        }
    }
}

/**
 * عناصر التبويب الثالث: سجل المساعدات ضمن القائمة الموحدة
 */
private fun LazyListScope.familyAidRecordsItems(
    aidRecords: List<AidRecordEntity>,
    aidTypes: List<AidTypeEntity>,
    projects: List<ProjectEntity>
) {
    if (aidRecords.isEmpty()) {
        item(key = "aid_records_empty") {
            VibrantGlassDetailCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(VibrantSkyBlue.copy(alpha = 0.13f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.VolunteerActivism,
                            contentDescription = null,
                            modifier = Modifier.size(34.dp),
                            tint = VibrantSkyBlue
                        )
                    }
                    Text(
                        text = "لا توجد مساعدات مستفادة مسجلة",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = DeepSlateText
                    )
                    Text(
                        text = "هذه الأسرة لم تسجل لها أي عمليات استلام أو ترشيح مساعدات حتى اللحظة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CalmLabelGray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    } else {
        item(key = "aid_records_header") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "سجل المساعدات المستفادة (${aidRecords.size})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = DeepSlateText
                )

                val deliveredCount = aidRecords.count {
                    it.recipientStatus == "مستلم" || it.recipientStatus == "مستفيد"
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = PrimaryEmerald.copy(alpha = 0.12f),
                    border = BorderStroke(0.8.dp, PrimaryEmerald.copy(alpha = 0.28f)),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Text(
                        text = "مستلم: $deliveredCount • مرشح: ${aidRecords.size - deliveredCount}",
                        style = MaterialTheme.typography.labelSmall,
                        color = PrimaryEmerald,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        items(aidRecords, key = { "aid_${it.aidRecordID}" }) { record ->
            val project = projects.find { it.projectID == record.projectID }
            val aidType = aidTypes.find { it.aidTypeID == record.aidTypeID }

            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                AidRecordItemCard(
                    record = record,
                    project = project,
                    aidType = aidType
                )
            }
        }
    }
}

@Composable
fun AidRecordItemCard(
    record: AidRecordEntity,
    project: ProjectEntity?,
    aidType: AidTypeEntity?
) {
    val isDelivered = record.recipientStatus.contains("مستلم") ||
        record.recipientStatus.contains("مستفيد") ||
        record.recipientStatus.contains("تم التسليم") ||
        !record.deliveryDate.isNullOrBlank()

    val statusColor = if (isDelivered) PrimaryEmerald else VibrantWarmAmber
    val statusTextColor = if (isDelivered) PrimaryEmerald else Color(0xFFB45309)

    val projectNameText = project?.projectName?.takeIf { it.isNotBlank() } ?: "مشروع #${record.projectID}"
    val projectNumberText = project?.projectNumber?.takeIf { it.isNotBlank() } ?: "#${record.projectID}"
    val aidTypeNameText = aidType?.aidTypeName?.takeIf { it.isNotBlank() } ?: "مساعدة إنسانية"
    val fundingInstText = project?.fundingInstitution?.takeIf { it.isNotBlank() } ?: "جهة مانحة"
    val warehouseText = record.warehouse.ifBlank {
        project?.warehouseName?.ifBlank { "المستودع الرئيسي" } ?: "المستودع الرئيسي"
    }
    val nominationDateText = record.selectionDate.ifBlank { record.aidDate.ifBlank { "غير مسجل" } }

    VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(statusColor.copy(alpha = 0.13f))
                            .border(1.dp, statusColor.copy(alpha = 0.28f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isDelivered) Icons.Rounded.CheckCircle else Icons.Rounded.HourglassTop,
                            contentDescription = null,
                            tint = statusColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = projectNameText,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = DeepSlateText,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Rounded.QrCode,
                                contentDescription = null,
                                tint = VibrantSkyBlue,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "رمز المشروع: $projectNumberText",
                                fontSize = 11.sp,
                                color = CalmLabelGray
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = RoundedCornerShape(50),
                    color = statusColor.copy(alpha = 0.13f),
                    border = BorderStroke(0.8.dp, statusColor.copy(alpha = 0.30f)),
                    shadowElevation = 0.dp,
                    tonalElevation = 0.dp
                ) {
                    Text(
                        text = record.recipientStatus.ifBlank { if (isDelivered) "تم التسليم" else "مرشح" },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusTextColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = SoftRowDividerColor, thickness = 0.8.dp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AidMetaMiniTile(
                    icon = Icons.Rounded.Category,
                    label = "نوع المساعدة",
                    value = aidTypeNameText,
                    tint = VibrantSkyBlue,
                    modifier = Modifier.weight(1f)
                )
                AidMetaMiniTile(
                    icon = Icons.Rounded.AccountBalance,
                    label = "الجهة الممولة",
                    value = fundingInstText,
                    tint = VibrantIndigo,
                    modifier = Modifier.weight(1f)
                )
                AidMetaMiniTile(
                    icon = Icons.Rounded.Warehouse,
                    label = "المستودع",
                    value = warehouseText,
                    tint = VibrantWarmAmber,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(VibrantSkyBlue.copy(alpha = 0.13f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Rounded.Event,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = VibrantSkyBlue
                        )
                    }
                    Column {
                        Text("تاريخ الترشيح", fontSize = 10.sp, color = CalmLabelGray)
                        Text(
                            nominationDateText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = DeepSlateText
                        )
                    }
                }

                if (!record.deliveryDate.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = PrimaryEmerald.copy(alpha = 0.12f),
                        border = BorderStroke(0.8.dp, PrimaryEmerald.copy(alpha = 0.28f)),
                        shadowElevation = 0.dp,
                        tonalElevation = 0.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(13.dp),
                                tint = PrimaryEmerald
                            )
                            Text(
                                text = "الاستلام: ${record.deliveryDate}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryEmerald
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AidMetaMiniTile(
    icon: ImageVector,
    label: String,
    value: String,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF3F9F6),
        border = BorderStroke(0.8.dp, Color(0xFFDCECE4)),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(14.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    label,
                    fontSize = 9.sp,
                    color = CalmLabelGray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    value,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = DeepSlateText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
