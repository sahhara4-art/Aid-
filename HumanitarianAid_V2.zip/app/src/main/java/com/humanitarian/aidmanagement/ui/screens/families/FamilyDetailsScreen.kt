package com.humanitarian.aidmanagement.ui.screens.families

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.TypeToConfirmDeleteDialog
import com.humanitarian.aidmanagement.ui.screens.children.ChildrenScreen
import com.humanitarian.aidmanagement.ui.theme.*
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.Period
import java.util.Date
import java.util.Locale

/**
 * شاشة تفاصيل الأسرة (FamilyDetailsScreen)
 * مبنية وفق معايير Jetpack Compose المتطورة بالارتباط مع FamilyDetailsViewModel
 * مع تطبيق صارم لقواعد:
 * 1. الحساب الديناميكي اللحظي للعمر من date_of_birth دون استخدام أي عمر مخزن.
 * 2. الإخفاء التام لأي مكون واجهة (Row, Text, Icon) في حال كانت القيمة فارغة أو null.
 * 3. التجميعات والإحصائيات التفاعلية والقوائم المنسدلة الديناميكية للشعب والمحليات.
 * 4. تصميم بصري احترافي وبطاقات ElevatedCard مقسمة بدقة مع ترميز لوني متناسق.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamilyDetailsScreen(
    familyId: Long,
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToAddChild: (familyId: Long, familyNationalId: String) -> Unit = { _, _ -> },
    viewModel: FamilyDetailsViewModel = viewModel(
        factory = FamilyDetailsViewModel.Factory(repository, familyId)
    )
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val family by repository.getFamilyById(familyId).collectAsStateWithLifecycle(initialValue = null)

    val aidTypes by repository.getActiveAidTypes().collectAsStateWithLifecycle(initialValue = emptyList())
    val projects by repository.getActiveProjects().collectAsStateWithLifecycle(initialValue = emptyList())

    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabTitles = listOf(
        "البيانات التفصيلية",
        "الأبناء والتابعون (${uiState.children.size})",
        "سجل المساعدات (${uiState.aidRecords.size})"
    )

    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    val emeraldColor = Color(0xFF10B981)
    val skyBlueColor = Color(0xFF0EA5E9)
    val softRoseColor = Color(0xFFF43F5E)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFE0F2FE), // Soft Blue
                            Color(0xFFF0F9FF),
                            Color(0xFFF8FAFC),
                            Color(0xFFFFFFFF)  // Snowy White
                        )
                    )
                )
        ) {
            // إضاءات محيطية هادئة لإبراز لمعة الزجاج
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 80.dp, y = (-40).dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                skyBlueColor.copy(alpha = 0.18f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = (-70).dp, y = 70.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                emeraldColor.copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = "الملف الشامل للأسرة",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color(0xFF0F172A)
                                )
                                val currentFamilyName = family?.name ?: uiState.family?.name
                                if (!currentFamilyName.isNullOrBlank()) {
                                    Text(
                                        text = currentFamilyName,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF475569),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = {
                                viewModel.resetFilters()
                                onNavigateBack()
                            }) {
                                Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = Color(0xFF0F172A))
                            }
                        },
                        actions = {
                            if (uiState.family != null && uiState.isAreaAllowed) {
                                if (uiState.canEdit) {
                                    IconButton(onClick = { showEditDialog = true }) {
                                        Icon(
                                            imageVector = Icons.Rounded.Edit,
                                            contentDescription = "تعديل بيانات الأسرة",
                                            tint = emeraldColor
                                        )
                                    }
                                }
                                if (uiState.canDelete) {
                                    IconButton(onClick = { showDeleteConfirmDialog = true }) {
                                        Icon(
                                            imageVector = Icons.Rounded.Delete,
                                            contentDescription = "حذف الأسرة",
                                            tint = softRoseColor
                                        )
                                    }
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.White.copy(alpha = 0.72f),
                            titleContentColor = Color(0xFF0F172A)
                        )
                    )
                }
            ) { paddingValues ->
                when {
                    uiState.isLoading -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues),
                            contentAlignment = Alignment.Center
                        ) {
                            VibrantGlassDetailCard(modifier = Modifier.padding(32.dp)) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    CircularProgressIndicator(color = emeraldColor)
                                    Text(
                                        text = "جاري تحميل الملف الشامل للأسرة...",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xFF334155)
                                    )
                                }
                            }
                        }
                    }
                    uiState.family == null -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues),
                            contentAlignment = Alignment.Center
                        ) {
                            VibrantGlassDetailCard(modifier = Modifier.padding(24.dp)) {
                                Text(
                                    text = uiState.errorMessage ?: "تعذر العثور على ملف الأسرة المطلوبة.",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = softRoseColor,
                                    modifier = Modifier.padding(20.dp)
                                )
                            }
                        }
                    }
                    !uiState.isAreaAllowed -> {
                        // حظر الوصول بسبب تقييد الصلاحية الجغرافية
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                                Column(
                                    modifier = Modifier.padding(24.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(CircleShape)
                                            .background(softRoseColor.copy(alpha = 0.14f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Lock,
                                            contentDescription = null,
                                            tint = softRoseColor,
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }

                                    Text(
                                        text = "تقييد أمني للمنطقة الفرعية",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = softRoseColor
                                    )

                                    Text(
                                        text = "عذراً، ليس لديك صلاحية للاطلاع على بيانات هذه الأسرة نظراً لتقييد حسابك الجغرافي.\nالأسرة مسجلة في المنطقة: (${uiState.family!!.currentSubArea}).",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xFF475569),
                                        textAlign = TextAlign.Center,
                                        lineHeight = 22.sp
                                    )

                                    Button(
                                        onClick = onNavigateBack,
                                        colors = ButtonDefaults.buttonColors(containerColor = skyBlueColor),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("العودة لقائمة الأسر", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        val currentFamily = family ?: uiState.family!!

                        // حوار التعديل
                        if (showEditDialog) {
                            EditFamilyDialog(
                                family = currentFamily,
                                localities = uiState.localities,
                                onDismiss = { showEditDialog = false },
                                onSave = { updatedFamily ->
                                    viewModel.updateFamily(updatedFamily) { success, error ->
                                        if (success) {
                                            Toast.makeText(context, "تم حفظ وتحديث بيانات الأسرة بنجاح", Toast.LENGTH_SHORT).show()
                                            showEditDialog = false
                                        } else {
                                            Toast.makeText(context, "خطأ أثناء حفظ التعديل: $error", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            )
                        }

                        // حوار الحذف الآمن المشروط حصراً بكلمة مرور مدير النظام
                        if (showDeleteConfirmDialog) {
                            com.humanitarian.aidmanagement.ui.components.AdminPasswordConfirmDialog(
                                title = "تأكيد حذف ملف الأسرة نهائياً",
                                itemName = currentFamily.name,
                                itemTypeLabel = "الأسرة",
                                repository = repository,
                                onConfirm = {
                                    showDeleteConfirmDialog = false
                                    viewModel.deleteFamily { success, error ->
                                        if (success) {
                                            Toast.makeText(context, "تم حذف الأسرة بنجاح بعد التحقق من كلمة مرور المدير", Toast.LENGTH_SHORT).show()
                                            onNavigateBack()
                                        } else {
                                            Toast.makeText(context, "خطأ أثناء الحذف: $error", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                onDismiss = { showDeleteConfirmDialog = false }
                            )
                        }

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                        ) {
                            // البطاقة الرأسية الموجزة الزجاجية
                            FamilyHeroCard(
                                family = currentFamily,
                                localityName = uiState.localityName,
                                childrenCount = uiState.children.size,
                                aidCount = uiState.aidRecords.size
                            )

                            // شريط التبويبات الزجاجي المتطور
                            PrimaryTabRow(
                                selectedTabIndex = selectedTabIndex,
                                containerColor = Color.White.copy(alpha = 0.62f),
                                contentColor = emeraldColor,
                                indicator = {
                                    TabRowDefaults.PrimaryIndicator(
                                        modifier = Modifier.tabIndicatorOffset(selectedTabIndex),
                                        color = emeraldColor
                                    )
                                }
                            ) {
                                tabTitles.forEachIndexed { index, title ->
                                    Tab(
                                        selected = selectedTabIndex == index,
                                        onClick = { selectedTabIndex = index },
                                        text = {
                                            Text(
                                                text = title,
                                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                                fontSize = 12.sp,
                                                color = if (selectedTabIndex == index) Color(0xFF047857) else Color(0xFF64748B)
                                            )
                                        },
                                        icon = {
                                            Icon(
                                                imageVector = when (index) {
                                                    0 -> Icons.Rounded.Badge
                                                    1 -> Icons.Rounded.People
                                                    else -> Icons.Rounded.History
                                                },
                                                contentDescription = null,
                                                modifier = Modifier.size(18.dp),
                                                tint = if (selectedTabIndex == index) emeraldColor else Color(0xFF64748B)
                                            )
                                        }
                                    )
                                }
                            }

                            // محتوى التبويب المختار
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                            ) {
                                when (selectedTabIndex) {
                                    0 -> FamilyBasicDetailsTab(
                                        family = currentFamily,
                                        localityName = uiState.localityName,
                                        viewModel = viewModel
                                    )
                                    1 -> FamilyChildrenTab(
                                        children = uiState.children,
                                        canEdit = uiState.canEdit,
                                        onAddChild = {
                                            onNavigateToAddChild(currentFamily.familyID, currentFamily.nationalID)
                                        }
                                    )
                                    2 -> FamilyAidRecordsTab(
                                        aidRecords = uiState.aidRecords,
                                        aidTypes = aidTypes,
                                        projects = projects
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VibrantGlassDetailCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.65f)),
        border = BorderStroke(
            width = 1.dp,
            brush = Brush.linearGradient(
                colors = listOf(Color.White, Color.White.copy(alpha = 0.2f))
            )
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        content = content
    )
}

/**
 * البطاقة الرأسية الموجزة (Family Hero Card)
 */
@Composable
fun FamilyHeroCard(
    family: FamilyEntity,
    localityName: String,
    childrenCount: Int,
    aidCount: Int
) {
    val emerald = Color(0xFF10B981)
    val skyBlue = Color(0xFF0EA5E9)
    val softRose = Color(0xFFF43F5E)
    val amber = Color(0xFFF59E0B)

    VibrantGlassDetailCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    emerald.copy(alpha = 0.2f),
                                    skyBlue.copy(alpha = 0.18f)
                                )
                            )
                        )
                        .border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.FamilyRestroom,
                        contentDescription = null,
                        modifier = Modifier.size(28.dp),
                        tint = Color(0xFF047857)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = family.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = skyBlue.copy(alpha = 0.14f),
                            border = BorderStroke(0.8.dp, skyBlue.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.CreditCard,
                                    contentDescription = null,
                                    tint = Color(0xFF0369A1),
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = family.nationalID,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0369A1)
                                )
                            }
                        }

                        if (localityName.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = emerald.copy(alpha = 0.14f),
                                border = BorderStroke(0.8.dp, emerald.copy(alpha = 0.3f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.LocationOn,
                                        contentDescription = null,
                                        tint = Color(0xFF047857),
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = localityName,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF047857),
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // شريط إحصائيات سريعة للأسرة بتصميم زجاجي وأيقونات ملونة
            val shelterText = family.shelterStatus.ifBlank { "خارج الإيواء" }
            val shelterMetricColor = if (shelterText.contains("نازح") || shelterText.contains("داخلي") || shelterText.contains("مخيم")) softRose else skyBlue

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.55f))
                    .border(1.dp, Color.White.copy(alpha = 0.7f), RoundedCornerShape(14.dp))
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                QuickMetric(label = "أفراد الأسرة", value = "${family.familyMembersCount}", icon = Icons.Rounded.Groups, tint = skyBlue)
                VerticalDivider(modifier = Modifier.height(28.dp), color = Color(0xFFCBD5E1).copy(alpha = 0.6f))
                QuickMetric(label = "الأبناء", value = "$childrenCount", icon = Icons.Rounded.ChildCare, tint = Color(0xFF6366F1))
                VerticalDivider(modifier = Modifier.height(28.dp), color = Color(0xFFCBD5E1).copy(alpha = 0.6f))
                QuickMetric(label = "المساعدات", value = "$aidCount", icon = Icons.Rounded.VolunteerActivism, tint = emerald)
                VerticalDivider(modifier = Modifier.height(28.dp), color = Color(0xFFCBD5E1).copy(alpha = 0.6f))
                QuickMetric(
                    label = "الإيواء",
                    value = shelterText,
                    icon = Icons.Rounded.House,
                    tint = if (family.damageType.contains("كلي")) softRose else if (shelterText.contains("خارج")) skyBlue else amber
                )
            }
        }
    }
}

@Composable
fun QuickMetric(label: String, value: String, icon: ImageVector, tint: Color = Color(0xFF0EA5E9)) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(14.dp), tint = tint)
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = Color(0xFF0F172A),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Text(
            text = label,
            fontSize = 10.sp,
            color = Color(0xFF64748B)
        )
    }
}

/**
 * التبويب الأول: البيانات الأساسية والتفصيلية بتصميم زجاجي وأيقونات شاملة لكل حقل
 */
@Composable
fun FamilyBasicDetailsTab(
    family: FamilyEntity,
    localityName: String,
    viewModel: FamilyDetailsViewModel
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    val emerald = Color(0xFF10B981)
    val skyBlue = Color(0xFF0EA5E9)
    val softRose = Color(0xFFF43F5E)
    val warmAmber = Color(0xFFF59E0B)
    val indigo = Color(0xFF6366F1)

    // حساب العمر ديناميكياً ولحظياً من حقل date_of_birth
    val dynamicallyCalculatedAge = remember(family.date_of_birth) {
        viewModel.calculateAge(family.date_of_birth)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. بطاقة الهوية والمعلومات الشخصية (Personal Info & Identity)
        item {
            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الهوية والمعلومات الشخصية",
                        icon = Icons.Rounded.Person,
                        badgeText = "هوية: ${family.nationalID}",
                        badgeColor = skyBlue
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(6.dp))

                    DetailFieldItem(Icons.Rounded.Person, "الاسم الرباعي الكامل", family.name, iconTint = emerald)
                    DetailFieldItem(Icons.Rounded.CreditCard, "رقم الهوية الوطنية", family.nationalID, iconTint = skyBlue)
                    DetailFieldItem(Icons.Rounded.CalendarToday, "تاريخ الميلاد", family.date_of_birth, iconTint = skyBlue)

                    // العمر المحسوب ديناميكياً حصراً
                    dynamicallyCalculatedAge?.let { ageVal ->
                        DetailFieldItem(
                            icon = Icons.Rounded.Cake,
                            label = "العمر المحسوب حالياً",
                            value = "$ageVal سنة",
                            iconTint = emerald,
                            badgeColor = emerald
                        )
                    }

                    val genderIcon = if (family.gender.contains("أنث")) Icons.Rounded.Female else Icons.Rounded.Male
                    val genderTint = if (family.gender.contains("أنث")) softRose else skyBlue
                    DetailFieldItem(genderIcon, "الجنس", family.gender, iconTint = genderTint)
                    DetailFieldItem(Icons.Rounded.Favorite, "الحالة الاجتماعية", family.maritalStatus, iconTint = softRose)

                    val isDeceased = family.deathStatus.contains("وفاة") || family.deathStatus.contains("متوفى")
                    DetailFieldItem(
                        icon = if (isDeceased) Icons.Rounded.HeartBroken else Icons.Rounded.VerifiedUser,
                        label = "حالة الحياة والوفاة",
                        value = family.deathStatus,
                        iconTint = if (isDeceased) softRose else emerald,
                        badgeColor = if (isDeceased) softRose else emerald
                    )
                    DetailFieldItem(Icons.Rounded.EventBusy, "تاريخ الوفاة", family.deathDate, iconTint = softRose)
                    DetailFieldItem(Icons.Rounded.Badge, "رقم كرت المؤن (البطاقة التموينية)", family.rationCardNumber, iconTint = indigo)
                }
            }
        }

        // 2. بطاقة بيانات الاتصال والتواصل (Contact Information)
        item {
            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "أرقام وبيانات الاتصال",
                        icon = Icons.Rounded.Phone,
                        badgeText = family.primary_phone.ifBlank { "التواصل" },
                        badgeColor = emerald
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(6.dp))

                    DetailFieldItem(Icons.Rounded.Phone, "رقم الجوال الأساسي", family.primary_phone, iconTint = emerald)
                    DetailFieldItem(Icons.Rounded.Call, "رقم جوال بديل (١)", family.alternative_phone_1, iconTint = emerald)
                    DetailFieldItem(Icons.Rounded.PhoneIphone, "رقم جوال بديل (٢)", family.alternative_phone_2, iconTint = skyBlue)
                }
            }
        }

        // 3. بطاقة بيانات الزوج/الزوجة والتركيبة الأسرية (Spouse & Family Composition)
        item {
            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الزوج/الزوجة والتركيبة الأسرية",
                        icon = Icons.Rounded.FamilyRestroom,
                        badgeText = "${family.familyMembersCount} أفراد",
                        badgeColor = indigo
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(6.dp))

                    DetailFieldItem(Icons.Rounded.People, "اسم الزوج/الزوجة", family.wifeName, iconTint = indigo)
                    DetailFieldItem(Icons.Rounded.CreditCard, "رقم هوية الزوج/الزوجة", family.wifeNationalID, iconTint = skyBlue)
                    DetailFieldItem(
                        icon = Icons.Rounded.Groups,
                        label = "إجمالي عدد أفراد الأسرة",
                        value = if (family.familyMembersCount > 0) "${family.familyMembersCount} أفراد" else null,
                        iconTint = emerald,
                        badgeColor = skyBlue
                    )
                }
            }
        }

        // 4. بطاقة السكن ومراكز الإيواء والمواقع الجغرافية (Shelter & Displacement)
        item {
            val isDisplacedShelter = family.shelterStatus.contains("مخيم") || family.shelterStatus.contains("نازح") || family.shelterStatus.contains("داخلي")
            val shelterChipColor = if (isDisplacedShelter) softRose else skyBlue

            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "السكن والموقع الجغرافي والنزوح",
                        icon = Icons.Rounded.LocationOn,
                        badgeText = family.currentSubArea.ifBlank { localityName },
                        badgeColor = skyBlue
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(6.dp))

                    DetailFieldItem(Icons.Rounded.LocationOn, "المحلية المعتمدة", family.currentSubArea.ifBlank { localityName }, iconTint = skyBlue)
                    DetailFieldItem(
                        icon = Icons.Rounded.House,
                        label = "حالة الإيواء الحالية",
                        value = family.shelterStatus,
                        iconTint = shelterChipColor,
                        badgeColor = shelterChipColor
                    )
                    DetailFieldItem(
                        icon = Icons.Rounded.HolidayVillage,
                        label = "اسم المخيم / مركز الإيواء",
                        value = family.shelter_center_name,
                        iconTint = softRose,
                        badgeColor = softRose
                    )

                    DetailFieldItem(Icons.Rounded.Map, "المنطقة الرئيسية الحالية", family.currentMainArea, iconTint = warmAmber)
                    DetailFieldItem(Icons.Rounded.Place, "المنطقة الفرعية الحالية", family.currentSubArea, iconTint = skyBlue)
                    DetailFieldItem(Icons.Rounded.AltRoute, "الشعبة الحالية", family.currentBranch, iconTint = emerald)
                    DetailFieldItem(Icons.Rounded.Mosque, "المسجد الحالي", family.currentMosque, iconTint = emerald)

                    // تفاصيل العنوان الأصلي قبل النزوح
                    DetailFieldItem(Icons.Rounded.History, "المنطقة الرئيسية الأصلية (قبل النزوح)", family.originalMainArea, iconTint = softRose)
                    DetailFieldItem(Icons.Rounded.Map, "المنطقة الفرعية الأصلية", family.originalSubArea, iconTint = softRose)
                    DetailFieldItem(Icons.Rounded.ShareLocation, "الشعبة الأصلية", family.originalBranch, iconTint = warmAmber)
                    DetailFieldItem(Icons.Rounded.Mosque, "المسجد الأصلي", family.originalMosque, iconTint = warmAmber)
                }
            }
        }

        // 5. بطاقة مصادر الدخل والمعيشة (Income & Livelihood)
        item {
            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "مصادر الدخل والوضع الاقتصادي",
                        icon = Icons.Rounded.Payments,
                        badgeText = family.incomeSource1.ifBlank { "الدخل" },
                        badgeColor = emerald
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(6.dp))

                    DetailFieldItem(Icons.Rounded.Payments, "مصدر الدخل الأساسي (١)", family.incomeSource1, iconTint = emerald)
                    DetailFieldItem(Icons.Rounded.AccountBalanceWallet, "مصدر الدخل الإضافي (٢)", family.income_source_2, iconTint = skyBlue)
                }
            }
        }

        // 6. بطاقة الحالة الصحية وأضرار الحرب (Health Status & War Damages)
        item {
            val damageColor = when {
                family.damageType.contains("كلي") -> softRose
                family.damageType.contains("جزئي") || family.damageType.contains("بليغ") -> warmAmber
                else -> emerald
            }
            val injuryHealthy = family.injuryStatus.contains("سليم")

            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الحالة الصحية وأضرار الحرب",
                        icon = Icons.Rounded.LocalHospital,
                        badgeText = family.damageType.ifBlank { family.injuryStatus },
                        badgeColor = damageColor
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(6.dp))

                    DetailFieldItem(
                        icon = Icons.Rounded.HomeWork,
                        label = "نوع أضرار الحرب للمنزل",
                        value = family.damageType,
                        iconTint = damageColor,
                        badgeColor = damageColor
                    )
                    DetailFieldItem(Icons.Rounded.WarningAmber, "وصف تفاصيل أضرار المنزل", family.damageDescription, iconTint = warmAmber)

                    DetailFieldItem(
                        icon = Icons.Rounded.LocalHospital,
                        label = "حالة الإصابة المسجلة",
                        value = family.injuryStatus,
                        iconTint = if (injuryHealthy) emerald else softRose,
                        badgeColor = if (injuryHealthy) emerald else softRose
                    )
                    DetailFieldItem(Icons.Rounded.Event, "تاريخ الإصابة", family.injuryDate, iconTint = softRose)
                }
            }
        }

        // 7. بطاقة الاعتمادات والتصنيفات الحكومية الرسمية (Approvals & Official Status)
        item {
            val devApproved = family.developmentApproval.contains("معتمد") && !family.developmentApproval.contains("غير")
            val locApproved = family.localityApproval.contains("معتمد") && !family.localityApproval.contains("غير")
            val isDisplacedResident = family.residentStatus.contains("نازح")

            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الاعتمادات والتصنيفات الرسمية",
                        icon = Icons.Rounded.Verified,
                        badgeText = family.developmentApproval.ifBlank { "اعتمادات" },
                        badgeColor = if (devApproved) emerald else warmAmber
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(6.dp))

                    DetailFieldItem(
                        icon = Icons.Rounded.Verified,
                        label = "اعتماد وزارة التنمية الاجتماعية",
                        value = family.developmentApproval,
                        iconTint = if (devApproved) emerald else softRose,
                        badgeColor = if (devApproved) emerald else softRose
                    )
                    DetailFieldItem(
                        icon = Icons.Rounded.DomainVerification,
                        label = "اعتماد المناطق والمحليات",
                        value = family.localityApproval,
                        iconTint = if (locApproved) emerald else warmAmber,
                        badgeColor = if (locApproved) emerald else warmAmber
                    )
                    DetailFieldItem(Icons.Rounded.Gavel, "اعتماد وزارة الأشغال العامة", family.worksApproval, iconTint = skyBlue, badgeColor = skyBlue)
                    DetailFieldItem(
                        icon = Icons.Rounded.PersonPin,
                        label = "حالة الإقامة الرسمية",
                        value = family.residentStatus,
                        iconTint = if (isDisplacedResident) softRose else skyBlue,
                        badgeColor = if (isDisplacedResident) softRose else skyBlue
                    )
                }
            }
        }

        // 8. الملاحظات الإدارية وتواريخ القيد
        item {
            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الملاحظات الإدارية وتواريخ القيد",
                        icon = Icons.Rounded.Description,
                        badgeText = "سجل موثق",
                        badgeColor = warmAmber
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(6.dp))

                    DetailFieldItem(
                        icon = Icons.Rounded.Notes,
                        label = "الملاحظات الإدارية والميدانية",
                        value = family.notes,
                        iconTint = warmAmber,
                        badgeColor = if (!family.notes.isNullOrBlank()) warmAmber else null
                    )
                    DetailFieldItem(
                        icon = Icons.Rounded.Schedule,
                        label = "تاريخ التسجيل الأولي بالقاعدة",
                        value = if (family.createdDate > 0) dateFormat.format(Date(family.createdDate)) else null,
                        iconTint = skyBlue
                    )
                    DetailFieldItem(
                        icon = Icons.Rounded.Update,
                        label = "تاريخ آخر تعديل للملف",
                        value = family.modifiedDate?.let { if (it > 0) dateFormat.format(Date(it)) else null },
                        iconTint = emerald
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

/**
 * مكون عرض تفصيل حقل واحد بالتنسيق البصري الهرمي (Visual Hierarchy Layout):
 * - أيقونة معبرة دائرية ملونة على اليمين في الواجهة العربية
 * - Column بجانبها يحتوي على عنوان الحقل بلون رمادي باهت أنيق + القيمة بخط عريض Dark Slate
 * - إخفاء تلقائي صارم عند فراغ القيمة
 */
@Composable
fun DetailFieldItem(
    icon: ImageVector,
    label: String,
    value: String?,
    iconTint: Color = Color(0xFF0EA5E9),
    badgeColor: Color? = null,
    textColor: Color? = null
) {
    if (value.isNullOrBlank()) return

    val cleanValue = value.trim()
    if (cleanValue.isEmpty() || cleanValue == "-" || cleanValue == "null") return

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // الأيقونة على اليمين محاطة بدائرة صغيرة شبه شفافة بلون مميز
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(iconTint.copy(alpha = 0.14f))
                .border(1.dp, iconTint.copy(alpha = 0.28f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = iconTint,
                modifier = Modifier.size(19.dp)
            )
        }

        // عمود البيانات بجانب الأيقونة: عنوان الحقل بلون رمادي باهت + القيمة بخط عريض Dark Slate
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                color = Color.Gray,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (badgeColor != null) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = badgeColor.copy(alpha = 0.14f),
                    border = BorderStroke(0.8.dp, badgeColor.copy(alpha = 0.35f))
                ) {
                    Text(
                        text = cleanValue,
                        fontSize = 13.sp,
                        color = textColor ?: badgeColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                }
            } else {
                Text(
                    text = cleanValue,
                    fontSize = 14.sp,
                    color = textColor ?: Color(0xFF0F172A),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * عنوان القسم مع الشارة والأيقونة الزجاجية
 */
@Composable
fun SectionHeaderWithBadge(
    title: String,
    icon: ImageVector,
    badgeText: String,
    badgeColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f, fill = false)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(badgeColor.copy(alpha = 0.14f))
                    .border(1.dp, badgeColor.copy(alpha = 0.25f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = badgeColor
                )
            }

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (badgeText.isNotBlank()) {
            Surface(
                shape = RoundedCornerShape(50),
                color = badgeColor.copy(alpha = 0.14f),
                border = BorderStroke(0.8.dp, badgeColor.copy(alpha = 0.3f))
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = badgeColor,
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * التبويب الثاني: قائمة الأبناء والتابعين مع زر إضافة ذكي بتصميم زجاجي
 */
@Composable
fun FamilyChildrenTab(
    children: List<ChildEntity>,
    canEdit: Boolean = true,
    onAddChild: () -> Unit = {}
) {
    val emerald = Color(0xFF10B981)
    if (children.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(emerald.copy(alpha = 0.14f))
                            .border(1.dp, emerald.copy(alpha = 0.28f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ChildCare,
                            contentDescription = null,
                            modifier = Modifier.size(38.dp),
                            tint = emerald
                        )
                    }
                    Text(
                        text = "لا يوجد أبناء أو تابعون مسجلون",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "لم يتم تسجيل بيانات أطفال مرتبطين بهذه الأسرة حتى الآن. يمكنك إضافة وتوثيق الأبناء مباشرة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )

                    if (canEdit) {
                        com.humanitarian.aidmanagement.ui.components.GlassButton(
                            onClick = onAddChild,
                            shape = RoundedCornerShape(12.dp),
                            icon = Icons.Rounded.PersonAdd,
                            containerColor = emerald,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("إضافة فرد / ابن جديد للأسرة", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "قائمة الأبناء والتابعين المسجلين (${children.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                        val boysCount = children.count { it.gender.contains("ذكر") }
                        val girlsCount = children.size - boysCount
                        Text(
                            text = "$boysCount ذكور • $girlsCount إناث",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF047857),
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (canEdit) {
                        com.humanitarian.aidmanagement.ui.components.GlassButton(
                            onClick = onAddChild,
                            shape = RoundedCornerShape(10.dp),
                            icon = Icons.Rounded.Add,
                            containerColor = emerald,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("إضافة ابن", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            items(children, key = { it.childID }) { child ->
                ChildItemCard(child = child)
            }
        }
    }
}

/**
 * دالة مساعدة لحساب وعرض العمر الدقيق للأبناء والتابعين
 * الصيغة: "(X) سنة و (Y) شهر و (Z) يوم" أو "تاريخ الميلاد غير صالح"
 */
fun calculateExactAge(birthDateStr: String?): String {
    if (birthDateStr.isNullOrBlank()) return "تاريخ الميلاد غير صالح"
    val cleanDate = birthDateStr.trim().replace('/', '-')
    val parts = cleanDate.split('-')
    if (parts.size != 3) return "تاريخ الميلاد غير صالح"

    val birthLocalDate = try {
        val y = parts[0].toIntOrNull() ?: return "تاريخ الميلاد غير صالح"
        val m = parts[1].toIntOrNull() ?: return "تاريخ الميلاد غير صالح"
        val d = parts[2].toIntOrNull() ?: return "تاريخ الميلاد غير صالح"
        LocalDate.of(y, m, d)
    } catch (e: Exception) {
        try {
            LocalDate.parse(cleanDate)
        } catch (e2: Exception) {
            return "تاريخ الميلاد غير صالح"
        }
    }

    val today = LocalDate.now()
    if (birthLocalDate.isAfter(today)) {
        return "تاريخ الميلاد غير صالح"
    }

    val period = Period.between(birthLocalDate, today)
    return "(${period.years}) سنة و (${period.months}) شهر و (${period.days}) يوم"
}

@Composable
fun ChildItemCard(child: ChildEntity) {
    val isMale = child.gender.contains("ذكر")
    val skyBlue = Color(0xFF0EA5E9)
    val softRose = Color(0xFFF43F5E)
    val emerald = Color(0xFF10B981)
    val avatarTint = if (isMale) skyBlue else softRose
    val avatarBg = avatarTint.copy(alpha = 0.14f)
    val exactAge = calculateExactAge(child.birthDate)
    val isAgeValid = exactAge != "تاريخ الميلاد غير صالح"

    VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(avatarBg)
                        .border(1.dp, avatarTint.copy(alpha = 0.28f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ChildCare,
                        contentDescription = null,
                        modifier = Modifier.size(25.dp),
                        tint = avatarTint
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(
                        text = child.childName.ifBlank { "طفل / تابع مسجل" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CreditCard,
                            contentDescription = null,
                            tint = skyBlue,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "هوية: ${child.nationalID}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF475569),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = avatarBg,
                    border = BorderStroke(0.8.dp, avatarTint.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isMale) Icons.Rounded.Male else Icons.Rounded.Female,
                            contentDescription = null,
                            tint = avatarTint,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = child.gender.ifBlank { if (isMale) "ذكر" else "أنثى" },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = avatarTint
                        )
                    }
                }
            }

            HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(skyBlue.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Cake,
                            contentDescription = null,
                            tint = skyBlue,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Column {
                        Text("تاريخ الميلاد", fontSize = 10.sp, color = Color.Gray)
                        Text(
                            text = child.birthDate.ifBlank { "غير مسجل" },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (isAgeValid) emerald.copy(alpha = 0.14f) else softRose.copy(alpha = 0.14f),
                    border = BorderStroke(0.8.dp, (if (isAgeValid) emerald else softRose).copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (isAgeValid) Icons.Rounded.Schedule else Icons.Rounded.WarningAmber,
                            contentDescription = null,
                            tint = if (isAgeValid) Color(0xFF047857) else softRose,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = exactAge,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isAgeValid) Color(0xFF047857) else softRose
                        )
                    }
                }
            }
        }
    }
}

/**
 * التبويب الثالث: سجل المساعدات المستفادة وتواريخ الاستلام
 */
@Composable
fun FamilyAidRecordsTab(
    aidRecords: List<AidRecordEntity>,
    aidTypes: List<com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity>,
    projects: List<com.humanitarian.aidmanagement.data.local.entities.ProjectEntity>
) {
    val emerald = Color(0xFF10B981)
    val skyBlue = Color(0xFF0EA5E9)

    if (aidRecords.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(skyBlue.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.VolunteerActivism,
                            contentDescription = null,
                            modifier = Modifier.size(36.dp),
                            tint = skyBlue
                        )
                    }
                    Text(
                        text = "لا توجد مساعدات مستفادة مسجلة",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "هذه الأسرة لم تسجل لها أي عمليات استلام أو ترشيح مساعدات حتى اللحظة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "سجل المساعدات المستفادة (${aidRecords.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )

                    val deliveredCount = aidRecords.count { it.recipientStatus == "مستلم" || it.recipientStatus == "مستفيد" }
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = emerald.copy(alpha = 0.14f),
                        border = BorderStroke(0.8.dp, emerald.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = "مستلم: $deliveredCount • مرشح: ${aidRecords.size - deliveredCount}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF047857),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            items(aidRecords, key = { it.aidRecordID }) { record ->
                val project = projects.find { it.projectID == record.projectID }
                val aidType = aidTypes.find { it.aidTypeID == record.aidTypeID }

                AidRecordItemCard(
                    record = record,
                    project = project,
                    aidType = aidType
                )
            }
        }
    }
}

@Composable
fun AidRecordItemCard(
    record: AidRecordEntity,
    project: com.humanitarian.aidmanagement.data.local.entities.ProjectEntity?,
    aidType: com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity?
) {
    val emerald = Color(0xFF10B981)
    val skyBlue = Color(0xFF0EA5E9)
    val warmAmber = Color(0xFFF59E0B)

    val isDelivered = record.recipientStatus.contains("مستلم") ||
            record.recipientStatus.contains("مستفيد") ||
            record.recipientStatus.contains("تم التسليم") ||
            !record.deliveryDate.isNullOrBlank()

    val statusColor = if (isDelivered) emerald else warmAmber
    val statusTextColor = if (isDelivered) Color(0xFF047857) else Color(0xFFB45309)

    val projectNameText = project?.projectName?.takeIf { it.isNotBlank() } ?: "مشروع #${record.projectID}"
    val projectNumberText = project?.projectNumber?.takeIf { it.isNotBlank() } ?: "#${record.projectID}"
    val aidTypeNameText = aidType?.aidTypeName?.takeIf { it.isNotBlank() } ?: "مساعدة إنسانية"
    val fundingInstText = project?.fundingInstitution?.takeIf { it.isNotBlank() } ?: "جهة مانحة"
    val warehouseText = record.warehouse.ifBlank { project?.warehouseName?.ifBlank { "المستودع الرئيسي" } ?: "المستودع الرئيسي" }
    val nominationDateText = record.selectionDate.ifBlank { record.aidDate.ifBlank { "غير مسجل" } }

    VibrantGlassDetailCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // ترويسة البطاقة: اسم ورقم المشروع مع حالة التسليم
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(statusColor.copy(alpha = 0.14f))
                            .border(1.dp, statusColor.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isDelivered) Icons.Rounded.CheckCircle else Icons.Rounded.HourglassTop,
                            contentDescription = null,
                            tint = statusColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = projectNameText,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF0F172A),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Rounded.QrCode, contentDescription = null, tint = skyBlue, modifier = Modifier.size(12.dp))
                            Text(
                                text = "رمز المشروع: $projectNumberText",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = statusColor.copy(alpha = 0.14f),
                    border = BorderStroke(0.8.dp, statusColor.copy(alpha = 0.35f))
                ) {
                    Text(
                        text = record.recipientStatus.ifBlank { if (isDelivered) "تم التسليم" else "مرشح" },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusTextColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = Color(0xFFE2E8F0).copy(alpha = 0.7f))

            // شبكة التفاصيل بالأيقونات والهرمية البصرية
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AidMetaMiniTile(
                    icon = Icons.Rounded.Category,
                    label = "نوع المساعدة",
                    value = aidTypeNameText,
                    tint = skyBlue,
                    modifier = Modifier.weight(1f)
                )
                AidMetaMiniTile(
                    icon = Icons.Rounded.AccountBalance,
                    label = "الجهة الممولة",
                    value = fundingInstText,
                    tint = Color(0xFF6366F1),
                    modifier = Modifier.weight(1f)
                )
                AidMetaMiniTile(
                    icon = Icons.Rounded.Warehouse,
                    label = "المستودع",
                    value = warehouseText,
                    tint = warmAmber,
                    modifier = Modifier.weight(1f)
                )
            }

            // تواريخ الترشيح والتسليم الفعلي
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(skyBlue.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Event, contentDescription = null, modifier = Modifier.size(13.dp), tint = skyBlue)
                    }
                    Column {
                        Text("تاريخ الترشيح", fontSize = 10.sp, color = Color.Gray)
                        Text(nominationDateText, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A))
                    }
                }

                if (!record.deliveryDate.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = emerald.copy(alpha = 0.14f),
                        border = BorderStroke(0.8.dp, emerald.copy(alpha = 0.35f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(13.dp), tint = emerald)
                            Text(
                                text = "الاستلام: ${record.deliveryDate}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF047857)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AidMetaMiniTile(
    icon: ImageVector,
    label: String,
    value: String,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = Color.White.copy(alpha = 0.55f),
        border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.7f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(14.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(label, fontSize = 9.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(value, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0F172A), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
