package com.humanitarian.aidmanagement.ui.screens.families

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.TypeToConfirmDeleteDialog
import com.humanitarian.aidmanagement.ui.screens.children.ChildrenScreen
import com.humanitarian.aidmanagement.ui.theme.*
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.Period
import java.util.Date
import java.util.Locale

/**
 * شاشة تفاصيل الأسرة (FamilyDetailsScreen)
 * مبنية وفق معايير Jetpack Compose المتطورة بالارتباط مع FamilyDetailsViewModel
 * مع تطبيق صارم لقواعد:
 * 1. الحساب الديناميكي اللحظي للعمر من date_of_birth دون استخدام أي عمر مخزن.
 * 2. الإخفاء التام لأي مكون واجهة (Row, Text, Icon) في حال كانت القيمة فارغة أو null.
 * 3. التجميعات والإحصائيات التفاعلية والقوائم المنسدلة الديناميكية للشعب والمحليات.
 * 4. تصميم بصري احترافي وبطاقات ElevatedCard مقسمة بدقة مع ترميز لوني متناسق.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamilyDetailsScreen(
    familyId: Long,
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToAddChild: (familyId: Long, familyNationalId: String) -> Unit = { _, _ -> },
    viewModel: FamilyDetailsViewModel = viewModel(
        factory = FamilyDetailsViewModel.Factory(repository, familyId)
    )
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val family by repository.getFamilyById(familyId).collectAsStateWithLifecycle(initialValue = null)

    val aidTypes by repository.getActiveAidTypes().collectAsStateWithLifecycle(initialValue = emptyList())
    val projects by repository.getActiveProjects().collectAsStateWithLifecycle(initialValue = emptyList())

    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabTitles = listOf(
        "البيانات التفصيلية",
        "الأبناء والتابعون (${uiState.children.size})",
        "سجل المساعدات (${uiState.aidRecords.size})"
    )

    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "الملف الشامل للأسرة",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            val currentFamilyName = family?.name ?: uiState.family?.name
                            if (!currentFamilyName.isNullOrBlank()) {
                                Text(
                                    text = currentFamilyName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            viewModel.resetFilters()
                            onNavigateBack()
                        }) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        if (uiState.family != null && uiState.isAreaAllowed) {
                            if (uiState.canEdit) {
                                IconButton(onClick = { showEditDialog = true }) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "تعديل بيانات الأسرة",
                                        tint = PalestineGreen
                                    )
                                }
                            }
                            if (uiState.canDelete) {
                                IconButton(onClick = { showDeleteConfirmDialog = true }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف الأسرة",
                                        tint = PalestineRed
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            when {
                uiState.isLoading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator(color = PalestineGreen)
                            Text(
                                text = "جاري تحميل الملف الشامل للأسرة...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                uiState.family == null -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = uiState.errorMessage ?: "تعذر العثور على ملف الأسرة المطلوبة.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
                !uiState.isAreaAllowed -> {
                    // حظر الوصول بسبب تقييد الصلاحية الجغرافية
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                            .padding(paddingValues)
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(CircleShape)
                                        .background(PalestineRed.copy(alpha = 0.12f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = null,
                                        tint = PalestineRed,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }

                                Text(
                                    text = "تقييد أمني للمنطقة الفرعية",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = PalestineRed
                                )

                                Text(
                                    text = "عذراً، ليس لديك صلاحية للاطلاع على بيانات هذه الأسرة نظراً لتقييد حسابك الجغرافي.\nالأسرة مسجلة في المنطقة: (${uiState.family!!.currentSubArea}).",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center,
                                    lineHeight = 22.sp
                                )

                                Button(
                                    onClick = onNavigateBack,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("العودة لقائمة الأسر", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                else -> {
                    val currentFamily = family ?: uiState.family!!

                    // حوار التعديل
                    if (showEditDialog) {
                        EditFamilyDialog(
                            family = currentFamily,
                            localities = uiState.localities,
                            onDismiss = { showEditDialog = false },
                            onSave = { updatedFamily ->
                                viewModel.updateFamily(updatedFamily) { success, error ->
                                    if (success) {
                                        Toast.makeText(context, "تم حفظ وتحديث بيانات الأسرة بنجاح", Toast.LENGTH_SHORT).show()
                                        showEditDialog = false
                                    } else {
                                        Toast.makeText(context, "خطأ أثناء حفظ التعديل: $error", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        )
                    }

                    // حوار الحذف الآمن المشروط حصراً بكلمة مرور مدير النظام
                    if (showDeleteConfirmDialog) {
                        com.humanitarian.aidmanagement.ui.components.AdminPasswordConfirmDialog(
                            title = "تأكيد حذف ملف الأسرة نهائياً",
                            itemName = currentFamily.name,
                            itemTypeLabel = "الأسرة",
                            repository = repository,
                            onConfirm = {
                                showDeleteConfirmDialog = false
                                viewModel.deleteFamily { success, error ->
                                    if (success) {
                                        Toast.makeText(context, "تم حذف الأسرة بنجاح بعد التحقق من كلمة مرور المدير", Toast.LENGTH_SHORT).show()
                                        onNavigateBack()
                                    } else {
                                        Toast.makeText(context, "خطأ أثناء الحذف: $error", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            onDismiss = { showDeleteConfirmDialog = false }
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                            .padding(paddingValues)
                    ) {
                        // البطاقة الرأسية الموجزة (Hero Card)
                        FamilyHeroCard(
                            family = currentFamily,
                            localityName = uiState.localityName,
                            childrenCount = uiState.children.size,
                            aidCount = uiState.aidRecords.size
                        )

                        // شريط التبويبات المتطور
                        PrimaryTabRow(
                            selectedTabIndex = selectedTabIndex,
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = PalestineGreen,
                            indicator = {
                                TabRowDefaults.PrimaryIndicator(
                                    modifier = Modifier.tabIndicatorOffset(selectedTabIndex),
                                    color = PalestineGreen
                                )
                            }
                        ) {
                            tabTitles.forEachIndexed { index, title ->
                                Tab(
                                    selected = selectedTabIndex == index,
                                    onClick = { selectedTabIndex = index },
                                    text = {
                                        Text(
                                            text = title,
                                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 13.sp,
                                            color = if (selectedTabIndex == index) PalestineGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = when (index) {
                                                0 -> Icons.Default.Badge
                                                1 -> Icons.Default.People
                                                else -> Icons.Default.History
                                            },
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp),
                                            tint = if (selectedTabIndex == index) PalestineGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                )
                            }
                        }

                        // محتوى التبويب المختار
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            when (selectedTabIndex) {
                                0 -> FamilyBasicDetailsTab(
                                    family = currentFamily,
                                    localityName = uiState.localityName,
                                    viewModel = viewModel
                                )
                                1 -> FamilyChildrenTab(
                                    children = uiState.children,
                                    canEdit = uiState.canEdit,
                                    onAddChild = {
                                        onNavigateToAddChild(currentFamily.familyID, currentFamily.nationalID)
                                    }
                                )
                                2 -> FamilyAidRecordsTab(
                                    aidRecords = uiState.aidRecords,
                                    aidTypes = aidTypes,
                                    projects = projects
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * البطاقة الرأسية الموجزة (Family Hero Card)
 */
@Composable
fun FamilyHeroCard(
    family: FamilyEntity,
    localityName: String,
    childrenCount: Int,
    aidCount: Int
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(PalestineGreenContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FamilyRestroom,
                        contentDescription = null,
                        modifier = Modifier.size(30.dp),
                        tint = PalestineGreen
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = family.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(3.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "هوية: ${family.nationalID}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }

                        if (localityName.isNotBlank()) {
                            Text(
                                text = localityName,
                                style = MaterialTheme.typography.bodySmall,
                                color = PalestineGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // شريط إحصائيات سريعة للأسرة
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(SlateSurfaceVariant)
                    .padding(vertical = 10.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                QuickMetric(label = "أفراد الأسرة", value = "${family.familyMembersCount}", icon = Icons.Default.People)
                Divider(modifier = Modifier.height(28.dp).width(1.dp), color = SlateBorder)
                QuickMetric(label = "الأبناء المسجلون", value = "$childrenCount", icon = Icons.Default.ChildCare)
                Divider(modifier = Modifier.height(28.dp).width(1.dp), color = SlateBorder)
                QuickMetric(label = "المساعدات المستلمة", value = "$aidCount", icon = Icons.Default.VolunteerActivism)
                Divider(modifier = Modifier.height(28.dp).width(1.dp), color = SlateBorder)
                QuickMetric(
                    label = "حالة الإيواء",
                    value = family.shelterStatus.ifBlank { "خارج الإيواء" },
                    icon = Icons.Default.Home
                )
            }
        }
    }
}

@Composable
fun QuickMetric(label: String, value: String, icon: ImageVector) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(13.dp), tint = PalestineGreen)
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = SlateTextPrimary
            )
        }
        Text(
            text = label,
            fontSize = 11.sp,
            color = SlateTextMuted
        )
    }
}

/**
 * التبويب الأول: البيانات الأساسية والتفصيلية
 * مع الالتزام الحاسم:
 * 1. حساب العمر ديناميكياً من تاريخ الميلاد date_of_birth عبر ViewModel
 * 2. إخفاء أي حقل قيمته null أو فارغة تماماً دون أي علامة "-" أو نصوص بديلة
 * 3. عرض جميع الحقول الجديدة (alternative_phone_1, alternative_phone_2, income_source_2, shelter_center_name)
 * 4. قسم التجميعات والإحصائيات الجغرافية التفاعلية الحية للشعب والمحليات
 */
@Composable
fun FamilyBasicDetailsTab(
    family: FamilyEntity,
    localityName: String,
    viewModel: FamilyDetailsViewModel
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    // حساب العمر ديناميكياً ولحظياً من حقل date_of_birth
    val dynamicallyCalculatedAge = remember(family.date_of_birth) {
        viewModel.calculateAge(family.date_of_birth)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. بطاقة الهوية والمعلومات الشخصية (Personal Info & Identity)
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.5.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الهوية والمعلومات الشخصية لرب الأسرة",
                        icon = Icons.Default.Person,
                        badgeText = "هوية: ${family.nationalID}",
                        badgeColor = PalestineGreen
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailFieldItem(Icons.Default.Person, "الاسم الرباعي الكامل", family.name)
                    DetailFieldItem(Icons.Default.Badge, "رقم الهوية الوطنية", family.nationalID)
                    DetailFieldItem(Icons.Default.CalendarToday, "تاريخ الميلاد", family.date_of_birth)

                    // العمر المحسوب ديناميكياً حصراً بدون قراءة أي قيمة عمر مخزنة
                    dynamicallyCalculatedAge?.let { ageVal ->
                        DetailFieldItem(
                            icon = Icons.Default.Cake,
                            label = "العمر المحسوب حالياً",
                            value = "$ageVal سنة",
                            iconTint = PalestineGreen,
                            badgeColor = PalestineGreen
                        )
                    }

                    DetailFieldItem(Icons.Default.Wc, "الجنس", family.gender)
                    DetailFieldItem(Icons.Default.Favorite, "الحالة الاجتماعية", family.maritalStatus)
                    DetailFieldItem(
                        icon = Icons.Default.HeartBroken,
                        label = "حالة الحياة والوفاة",
                        value = family.deathStatus,
                        badgeColor = if (family.deathStatus.contains("وفاة") || family.deathStatus.contains("متوفى")) PalestineRed else PalestineGreen
                    )
                    DetailFieldItem(Icons.Default.EventBusy, "تاريخ الوفاة", family.deathDate, iconTint = PalestineRed)
                    DetailFieldItem(Icons.Default.CreditCard, "رقم كرت المؤن (البطاقة التموينية)", family.rationCardNumber)
                }
            }
        }

        // 2. بطاقة بيانات الاتصال والتواصل (Contact Information)
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.5.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "أرقام وبيانات الاتصال والتواصل",
                        icon = Icons.Default.Phone,
                        badgeText = family.primary_phone.ifBlank { "بيانات اتصال" },
                        badgeColor = Color(0xFF0284C7) // Cyan / Blue tint
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    // الحقول الثلاثة للجوال: الأساسي، البديل 1، البديل 2 مع إخفاء الصفر/الفارغ
                    DetailFieldItem(Icons.Default.Phone, "رقم الجوال الأساسي", family.primary_phone, iconTint = Color(0xFF0284C7))
                    DetailFieldItem(Icons.Default.PhoneIphone, "رقم جوال بديل (١)", family.alternative_phone_1, iconTint = Color(0xFF0284C7))
                    DetailFieldItem(Icons.Default.Call, "رقم جوال بديل (٢)", family.alternative_phone_2, iconTint = Color(0xFF0284C7))
                }
            }
        }

        // 3. بطاقة بيانات الزوج/الزوجة والتركيبة الأسرية (Spouse & Family Composition)
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.5.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "بيانات الزوج/الزوجة والتركيبة الأسرية",
                        icon = Icons.Default.FamilyRestroom,
                        badgeText = "${family.familyMembersCount} أفراد",
                        badgeColor = Color(0xFF6366F1) // Indigo tint
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailFieldItem(Icons.Default.Face, "اسم الزوج/الزوجة", family.wifeName, iconTint = Color(0xFF6366F1))
                    DetailFieldItem(Icons.Default.Badge, "رقم هوية الزوج/الزوجة", family.wifeNationalID, iconTint = Color(0xFF6366F1))
                    DetailFieldItem(
                        icon = Icons.Default.Groups,
                        label = "إجمالي عدد أفراد الأسرة",
                        value = if (family.familyMembersCount > 0) "${family.familyMembersCount} أفراد" else null,
                        iconTint = Color(0xFF6366F1)
                    )
                }
            }
        }

        // 4. بطاقة السكن ومراكز الإيواء والمواقع الجغرافية (Shelter & Displacement)
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.5.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "بيانات السكن والموقع الجغرافي والنزوح",
                        icon = Icons.Default.LocationOn,
                        badgeText = family.currentSubArea.ifBlank { localityName },
                        badgeColor = Color(0xFFD97706) // Amber tint
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailFieldItem(Icons.Default.LocationCity, "المحلية المعتمدة", family.currentSubArea.ifBlank { localityName }, iconTint = Color(0xFFD97706))
                    DetailFieldItem(Icons.Default.NightShelter, "حالة الإيواء الحالية", family.shelterStatus, iconTint = Color(0xFFD97706))
                    // الحقل الجديد: اسم المخيم / مركز الإيواء (يُعرض فقط إن وجد)
                    DetailFieldItem(
                        icon = Icons.Default.HolidayVillage,
                        label = "اسم المخيم / مركز الإيواء",
                        value = family.shelter_center_name,
                        iconTint = Color(0xFFD97706),
                        badgeColor = Color(0xFFD97706)
                    )

                    DetailFieldItem(Icons.Default.PinDrop, "المنطقة الرئيسية الحالية", family.currentMainArea, iconTint = Color(0xFFD97706))
                    DetailFieldItem(Icons.Default.Place, "المنطقة الفرعية الحالية", family.currentSubArea, iconTint = Color(0xFFD97706))
                    DetailFieldItem(Icons.Default.AltRoute, "الشعبة الحالية", family.currentBranch, iconTint = Color(0xFFD97706))
                    DetailFieldItem(Icons.Default.Mosque, "المسجد الحالي", family.currentMosque, iconTint = Color(0xFFD97706))

                    // تفاصيل العنوان الأصلي قبل النزوح (تختفي تلقائياً إن كانت فارغة)
                    DetailFieldItem(Icons.Default.History, "المنطقة الرئيسية الأصلية (قبل النزوح)", family.originalMainArea, iconTint = Color(0xFFD97706))
                    DetailFieldItem(Icons.Default.Map, "المنطقة الفرعية الأصلية", family.originalSubArea, iconTint = Color(0xFFD97706))
                    DetailFieldItem(Icons.Default.ShareLocation, "الشعبة الأصلية", family.originalBranch, iconTint = Color(0xFFD97706))
                    DetailFieldItem(Icons.Default.Mosque, "المسجد الأصلي", family.originalMosque, iconTint = Color(0xFFD97706))
                }
            }
        }

        // 5. بطاقة مصادر الدخل والمعيشة (Income & Livelihood)
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.5.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "مصادر الدخل والوضع الاقتصادي",
                        icon = Icons.Default.Payments,
                        badgeText = family.incomeSource1.ifBlank { "الدخل" },
                        badgeColor = Color(0xFF059669) // Emerald tint
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailFieldItem(Icons.Default.Payments, "مصدر الدخل الأساسي (١)", family.incomeSource1, iconTint = Color(0xFF059669))
                    // الحقل الجديد: مصدر الدخل الأساسي 2 (يختفي تماماً إن كان فارغاً أو null)
                    DetailFieldItem(Icons.Default.AccountBalanceWallet, "مصدر الدخل الإضافي (٢)", family.income_source_2, iconTint = Color(0xFF059669))
                }
            }
        }

        // 6. بطاقة الحالة الصحية وأضرار الحرب (Health Status & War Damages)
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.5.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الحالة الصحية والإصابات وأضرار الحرب",
                        icon = Icons.Default.LocalHospital,
                        badgeText = family.damageType.ifBlank { family.injuryStatus },
                        badgeColor = when {
                            family.damageType.contains("كلي") -> PalestineRed
                            family.damageType.contains("جزئي") -> Color(0xFFD97706)
                            else -> PalestineGreen
                        }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailFieldItem(
                        icon = Icons.Default.HomeWork,
                        label = "نوع أضرار الحرب المسجلة للمنزل",
                        value = family.damageType,
                        badgeColor = when {
                            family.damageType.contains("كلي") -> PalestineRed
                            family.damageType.contains("جزئي") -> Color(0xFFD97706)
                            else -> PalestineGreen
                        }
                    )
                    DetailFieldItem(Icons.Default.ReportProblem, "وصف تفاصيل أضرار المنزل", family.damageDescription)

                    DetailFieldItem(
                        icon = Icons.Default.LocalHospital,
                        label = "حالة الإصابة المسجلة",
                        value = family.injuryStatus,
                        badgeColor = if (family.injuryStatus.contains("سليم")) PalestineGreen else PalestineRed
                    )
                    DetailFieldItem(Icons.Default.Event, "تاريخ الإصابة", family.injuryDate)
                }
            }
        }

        // 7. بطاقة الاعتمادات والتصنيفات الحكومية الرسمية (Approvals & Official Status)
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.5.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الاعتمادات الرسمية والتصنيفات الحكومية",
                        icon = Icons.Default.Verified,
                        badgeText = family.developmentApproval.ifBlank { "اعتمادات" },
                        badgeColor = Color(0xFF7C3AED) // Purple tint
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailFieldItem(
                        icon = Icons.Default.Verified,
                        label = "اعتماد وزارة التنمية الاجتماعية",
                        value = family.developmentApproval,
                        badgeColor = if (family.developmentApproval.contains("معتمد")) PalestineGreen else PalestineRed
                    )
                    DetailFieldItem(
                        icon = Icons.Default.DomainVerification,
                        label = "اعتماد المناطق والمحليات",
                        value = family.localityApproval,
                        badgeColor = if (family.localityApproval.contains("معتمد")) PalestineGreen else Color(0xFFD97706)
                    )
                    DetailFieldItem(Icons.Default.Gavel, "اعتماد وزارة الأشغال العامة", family.worksApproval)
                    DetailFieldItem(Icons.Default.PersonPin, "حالة الإقامة الرسمية", family.residentStatus)
                }
            }
        }

        // 8. الملاحظات الإدارية وتواريخ القيد
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.5.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الملاحظات الإدارية وتواريخ القيد",
                        icon = Icons.Default.Description,
                        badgeText = "سجل إلكتروني",
                        badgeColor = PalestineGreen
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailFieldItem(Icons.Default.Notes, "الملاحظات الإدارية والميدانية", family.notes)
                    DetailFieldItem(
                        icon = Icons.Default.Schedule,
                        label = "تاريخ التسجيل الأولي بالقاعدة",
                        value = if (family.createdDate > 0) dateFormat.format(Date(family.createdDate)) else null
                    )
                    DetailFieldItem(
                        icon = Icons.Default.Update,
                        label = "تاريخ آخر تعديل للملف",
                        value = family.modifiedDate?.let { if (it > 0) dateFormat.format(Date(it)) else null }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

/**
 * مكون عرض تفصيل حقل واحد مع التطبيق الصارم لقاعدة:
 * إذا كانت القيمة فارغة أو null أو blank، يتم الخروج فوراً وإخفاء المكون بالكامل (Zero Slop / Strict Data Accuracy).
 */
@Composable
fun DetailFieldItem(
    icon: ImageVector,
    label: String,
    value: String?,
    iconTint: Color = PalestineGreen,
    badgeColor: Color? = null,
    textColor: Color? = null
) {
    // القاعدة الصارمة: إخفاء المكون فوراً دون رسم أي Row أو نص بديل
    if (value.isNullOrBlank()) return

    val cleanValue = value.trim()
    if (cleanValue.isEmpty() || cleanValue == "-" || cleanValue == "null") return

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(0.48f)
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(14.dp)
                )
            }

            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (badgeColor != null) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = badgeColor.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(0.8.dp, badgeColor.copy(alpha = 0.3f))
            ) {
                Text(
                    text = cleanValue,
                    style = MaterialTheme.typography.bodySmall,
                    color = textColor ?: badgeColor,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        } else {
            Text(
                text = cleanValue,
                style = MaterialTheme.typography.bodySmall,
                color = textColor ?: MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.52f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * عنوان القسم مع الشارة والأيقونة
 */
@Composable
fun SectionHeaderWithBadge(
    title: String,
    icon: ImageVector,
    badgeText: String,
    badgeColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f, fill = false)
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(badgeColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                    tint = badgeColor
                )
            }

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (badgeText.isNotBlank()) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = badgeColor.copy(alpha = 0.12f)
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = badgeColor,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * التبويب الثاني: قائمة الأبناء والتابعين مع زر إضافة ذكي بتصميم زجاجي
 */
@Composable
fun FamilyChildrenTab(
    children: List<ChildEntity>,
    canEdit: Boolean = true,
    onAddChild: () -> Unit = {}
) {
    if (children.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            com.humanitarian.aidmanagement.ui.components.GlassCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(PalestineGreenContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChildCare,
                            contentDescription = null,
                            modifier = Modifier.size(38.dp),
                            tint = PalestineGreen
                        )
                    }
                    Text(
                        text = "لا يوجد أبناء أو تابعون مسجلون",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "لم يتم تسجيل بيانات أطفال مرتبطين بهذه الأسرة حتى الآن. يمكنك إضافة وتوثيق الأبناء مباشرة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    if (canEdit) {
                        com.humanitarian.aidmanagement.ui.components.GlassButton(
                            onClick = onAddChild,
                            shape = RoundedCornerShape(12.dp),
                            icon = Icons.Default.PersonAdd,
                            containerColor = PalestineGreen,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("إضافة فرد / ابن جديد للأسرة", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "قائمة الأبناء والتابعين المسجلين (${children.size})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        val boysCount = children.count { it.gender.contains("ذكر") }
                        val girlsCount = children.size - boysCount
                        Text(
                            text = "$boysCount ذكور • $girlsCount إناث",
                            style = MaterialTheme.typography.labelSmall,
                            color = PalestineGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (canEdit) {
                        com.humanitarian.aidmanagement.ui.components.GlassButton(
                            onClick = onAddChild,
                            shape = RoundedCornerShape(10.dp),
                            icon = Icons.Default.Add,
                            containerColor = PalestineGreen,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("إضافة ابن", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            items(children, key = { it.childID }) { child ->
                ChildItemCard(child = child)
            }
        }
    }
}

/**
 * دالة مساعدة لحساب وعرض العمر الدقيق للأبناء والتابعين
 * الصيغة: "(X) سنة و (Y) شهر و (Z) يوم" أو "تاريخ الميلاد غير صالح"
 */
fun calculateExactAge(birthDateStr: String?): String {
    if (birthDateStr.isNullOrBlank()) return "تاريخ الميلاد غير صالح"
    val cleanDate = birthDateStr.trim().replace('/', '-')
    val parts = cleanDate.split('-')
    if (parts.size != 3) return "تاريخ الميلاد غير صالح"

    val birthLocalDate = try {
        val y = parts[0].toIntOrNull() ?: return "تاريخ الميلاد غير صالح"
        val m = parts[1].toIntOrNull() ?: return "تاريخ الميلاد غير صالح"
        val d = parts[2].toIntOrNull() ?: return "تاريخ الميلاد غير صالح"
        LocalDate.of(y, m, d)
    } catch (e: Exception) {
        try {
            LocalDate.parse(cleanDate)
        } catch (e2: Exception) {
            return "تاريخ الميلاد غير صالح"
        }
    }

    val today = LocalDate.now()
    if (birthLocalDate.isAfter(today)) {
        return "تاريخ الميلاد غير صالح"
    }

    val period = Period.between(birthLocalDate, today)
    return "(${period.years}) سنة و (${period.months}) شهر و (${period.days}) يوم"
}

@Composable
fun ChildItemCard(child: ChildEntity) {
    val isMale = child.gender.contains("ذكر")
    val avatarBg = if (isMale) Color(0xFFE0F2FE) else Color(0xFFFCE7F3)
    val avatarTint = if (isMale) Color(0xFF0284C7) else Color(0xFFDB2777)
    val exactAge = calculateExactAge(child.birthDate)
    val isAgeValid = exactAge != "تاريخ الميلاد غير صالح"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(avatarBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ChildCare,
                        contentDescription = null,
                        modifier = Modifier.size(26.dp),
                        tint = avatarTint
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = child.childName.ifBlank { "طفل / تابع مسجل" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "رقم الهوية: ${child.nationalID}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = avatarBg
                ) {
                    Text(
                        text = child.gender.ifBlank { if (isMale) "ذكر" else "أنثى" },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = avatarTint,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = SlateBorder.copy(alpha = 0.6f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Cake,
                        contentDescription = null,
                        tint = SlateTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "تاريخ الميلاد: ${child.birthDate.ifBlank { "غير مسجل" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isAgeValid) PalestineGreenLight else PalestineRed.copy(alpha = 0.1f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (isAgeValid) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = PalestineGreenDark,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = exactAge,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isAgeValid) PalestineGreenDark else PalestineRed
                        )
                    }
                }
            }
        }
    }
}

/**
 * التبويب الثالث: سجل المساعدات المستفادة وتواريخ الاستلام
 */
@Composable
fun FamilyAidRecordsTab(
    aidRecords: List<AidRecordEntity>,
    aidTypes: List<com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity>,
    projects: List<com.humanitarian.aidmanagement.data.local.entities.ProjectEntity>
) {
    if (aidRecords.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VolunteerActivism,
                        contentDescription = null,
                        modifier = Modifier.size(36.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
                Text(
                    text = "لا توجد مساعدات مستفادة مسجلة",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "هذه الأسرة لم تسجل لها أي عمليات استلام أو ترشيح مساعدات حتى اللحظة.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "سجل المساعدات المستفادة (${aidRecords.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val deliveredCount = aidRecords.count { it.recipientStatus == "مستلم" || it.recipientStatus == "مستفيد" }
                    Text(
                        text = "مستلم: $deliveredCount • مرشح: ${aidRecords.size - deliveredCount}",
                        style = MaterialTheme.typography.labelSmall,
                        color = PalestineGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            items(aidRecords, key = { it.aidRecordID }) { record ->
                val project = projects.find { it.projectID == record.projectID }
                val aidType = aidTypes.find { it.aidTypeID == record.aidTypeID }

                AidRecordItemCard(
                    record = record,
                    project = project,
                    aidType = aidType
                )
            }
        }
    }
}

@Composable
fun AidRecordItemCard(
    record: AidRecordEntity,
    project: com.humanitarian.aidmanagement.data.local.entities.ProjectEntity?,
    aidType: com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity?
) {
    val isDelivered = record.recipientStatus.contains("مستلم") ||
            record.recipientStatus.contains("مستفيد") ||
            record.recipientStatus.contains("تم التسليم") ||
            !record.deliveryDate.isNullOrBlank()

    val statusColor = if (isDelivered) PalestineGreen else Color(0xFFD97706)
    val statusBg = if (isDelivered) PalestineGreen.copy(alpha = 0.12f) else Color(0xFFFEF3C7)

    val projectNameText = project?.projectName?.takeIf { it.isNotBlank() } ?: "مشروع #${record.projectID}"
    val projectNumberText = project?.projectNumber?.takeIf { it.isNotBlank() } ?: "#${record.projectID}"
    val aidTypeNameText = aidType?.aidTypeName?.takeIf { it.isNotBlank() } ?: "مساعدة إنسانية"
    val fundingInstText = project?.fundingInstitution?.takeIf { it.isNotBlank() } ?: "جهة مانحة غير محددة"
    val warehouseText = record.warehouse.ifBlank { project?.warehouseName?.ifBlank { "المستودع الرئيسي" } ?: "المستودع الرئيسي" }
    val nominationDateText = record.selectionDate.ifBlank { record.aidDate.ifBlank { "غير مسجل" } }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // ترويسة البطاقة: اسم ورقم المشروع مع حالة التسليم
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(statusBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isDelivered) Icons.Default.CheckCircle else Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = statusColor,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = projectNameText,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "رمز المشروع: $projectNumberText",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = statusBg
                ) {
                    Text(
                        text = record.recipientStatus.ifBlank { if (isDelivered) "تم التسليم" else "مرشح" },
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(color = SlateBorder.copy(alpha = 0.6f))

            // شبكة التفاصيل: نوع المساعدة والجهة الممولة والمستودع
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("نوع المساعدة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(aidTypeNameText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("الجهة الممولة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(fundingInstText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("المستودع", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(warehouseText, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }

            // تواريخ الترشيح والتسليم الفعلي
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "تاريخ الترشيح: $nominationDateText",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (!record.deliveryDate.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = PalestineGreenLight
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(12.dp), tint = PalestineGreenDark)
                            Text(
                                text = "الاستلام الفعلي: ${record.deliveryDate}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PalestineGreenDark
                            )
                        }
                    }
                }
            }
        }
    }
}
