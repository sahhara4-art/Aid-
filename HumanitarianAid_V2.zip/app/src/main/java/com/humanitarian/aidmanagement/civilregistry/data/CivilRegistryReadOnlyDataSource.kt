package com.humanitarian.aidmanagement.civilregistry.data

import android.content.Context
import android.net.Uri
import android.os.CancellationSignal
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryChildRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryDbStatus
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryImportProgress
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchPage
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery
import com.humanitarian.aidmanagement.civilregistry.security.CivilRegistryPermissionGuard

/**
 * طبقة التكييف والمستودع المفصولة للقراءة فقط (Civil Registry Read-Only Repository / Adapter)
 *
 * تدير التبديل السلس والشفاف بين مصدرين مستقلين يطبقان CivilRegistryDataSource:
 * 1. SqliteCivilRegistryDataSource: يرتبط بملف civil_registry.db الفعلي (أرباب الأسر + جدول الأبناء children_registry).
 * 2. SampleCivilRegistryDataSource: يعمل تلقائياً وفورياً ببيانات تجريبية مطابقة للبنية عند عدم رفع الملف بعد.
 */
class CivilRegistryReadOnlyDataSource(
    appContext: Context,
    private val realDataSource: SqliteCivilRegistryDataSource = SqliteCivilRegistryDataSource(appContext.applicationContext),
    private val sampleDataSource: SampleCivilRegistryDataSource = SampleCivilRegistryDataSource(),
    private val enableSampleFallbackWhenMissing: Boolean = true
) : CivilRegistryDataSource {

    companion object {
        const val DEFAULT_PAGE_SIZE = 40
    }

    @Volatile
    private var activeAdapter: CivilRegistryDataSource = realDataSource

    val isUsingSampleFallback: Boolean
        get() = activeAdapter === sampleDataSource

    override suspend fun ensureDatabaseReady(): CivilRegistryDbStatus {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            close()
            return CivilRegistryDbStatus.Checking
        }

        val realStatus = realDataSource.ensureDatabaseReady()
        return when {
            realStatus is CivilRegistryDbStatus.Ready -> {
                activeAdapter = realDataSource
                realStatus
            }
            realStatus is CivilRegistryDbStatus.Missing && enableSampleFallbackWhenMissing -> {
                activeAdapter = sampleDataSource
                sampleDataSource.ensureDatabaseReady()
            }
            else -> {
                activeAdapter = realDataSource
                realStatus
            }
        }
    }

    /**
     * ربط ونسخ ملف civil_registry.db الفعلي من ذاكرة الجهاز مع تقارير تقدم فورية
     */
    suspend fun importExternalDatabase(
        uri: Uri,
        onProgress: ((CivilRegistryImportProgress) -> Unit)? = null
    ): CivilRegistryDbStatus {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            return CivilRegistryDbStatus.Checking
        }

        val status = realDataSource.importExternalDatabase(uri, onProgress)
        if (status is CivilRegistryDbStatus.Ready) {
            activeAdapter = realDataSource
        }
        return status
    }

    override suspend fun search(
        query: CivilRegistrySearchQuery,
        offset: Int,
        pageSize: Int,
        cancellationSignal: CancellationSignal?
    ): CivilRegistrySearchPage {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            return CivilRegistrySearchPage(emptyList(), hasMore = false, offset = 0)
        }

        return activeAdapter.search(
            query = query,
            offset = offset,
            pageSize = pageSize,
            cancellationSignal = cancellationSignal
        )
    }

    override suspend fun getChildrenForParent(
        parentId: String,
        minBirthDateIso: String?,
        maxBirthDateIso: String?,
        cancellationSignal: CancellationSignal?
    ): List<CivilRegistryChildRecord> {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            return emptyList()
        }
        return activeAdapter.getChildrenForParent(
            parentId = parentId,
            minBirthDateIso = minBirthDateIso,
            maxBirthDateIso = maxBirthDateIso,
            cancellationSignal = cancellationSignal
        )
    }

    override suspend fun hasChildrenRegistryTable(): Boolean {
        if (!CivilRegistryPermissionGuard.canAccessCivilRegistry()) {
            return false
        }
        return activeAdapter.hasChildrenRegistryTable()
    }

    /**
     * استعلام قراءة فقط ومفهرس لجلب أبناء أسرة رسمية مسجلة في المشروع بغرض التحديث من children_registry
     * (يعمل على Dispatchers.IO ويعيد: هل جدول children_registry موجود، هل المصدر تجريبي، قائمة الأبناء)
     */
    suspend fun queryChildrenForOfficialFamilySync(
        parentId: String,
        minBirthDateIso: String? = null,
        maxBirthDateIso: String? = null
    ): OfficialChildrenQueryResult {
        val realStatus = realDataSource.ensureDatabaseReady()
        if (realStatus is CivilRegistryDbStatus.Ready) {
            activeAdapter = realDataSource
            val (hasTable, children) = realDataSource.getChildrenForOfficialSync(
                parentId = parentId,
                minBirthDateIso = minBirthDateIso,
                maxBirthDateIso = maxBirthDateIso
            )
            return OfficialChildrenQueryResult(
                isDatabaseAvailable = true,
                hasChildrenTable = hasTable,
                isUsingSampleFallback = false,
                children = children
            )
        }

        if (realStatus is CivilRegistryDbStatus.Missing && enableSampleFallbackWhenMissing) {
            activeAdapter = sampleDataSource
            val children = sampleDataSource.getChildrenForOfficialSync(
                parentId = parentId,
                minBirthDateIso = minBirthDateIso,
                maxBirthDateIso = maxBirthDateIso
            )
            return OfficialChildrenQueryResult(
                isDatabaseAvailable = true,
                hasChildrenTable = true,
                isUsingSampleFallback = true,
                children = children
            )
        }

        return OfficialChildrenQueryResult(
            isDatabaseAvailable = false,
            hasChildrenTable = false,
            isUsingSampleFallback = false,
            children = emptyList()
        )
    }

    /**
     * تهيئة جلسة التحديث الجماعي للأبناء بالتحقق من وجود قاعدة civil_registry.db وجدول children_registry
     * مرة واحدة فقط قبل بدء معالجة الدفعات (Chunks) لتفادي إعادة فتح القاعدة في كل دفعة.
     */
    suspend fun prepareOfficialChildrenBulkSync(): OfficialBulkSyncSessionStatus {
        val realStatus = realDataSource.ensureDatabaseReady()
        if (realStatus is CivilRegistryDbStatus.Ready) {
            activeAdapter = realDataSource
            val hasTable = realStatus.hasChildrenRegistry || realDataSource.hasChildrenRegistryTable()
            return OfficialBulkSyncSessionStatus(
                isDatabaseAvailable = true,
                hasChildrenTable = hasTable,
                isUsingSampleFallback = false
            )
        }

        if (realStatus is CivilRegistryDbStatus.Missing && enableSampleFallbackWhenMissing) {
            activeAdapter = sampleDataSource
            sampleDataSource.ensureDatabaseReady()
            return OfficialBulkSyncSessionStatus(
                isDatabaseAvailable = true,
                hasChildrenTable = true,
                isUsingSampleFallback = true
            )
        }

        return OfficialBulkSyncSessionStatus(
            isDatabaseAvailable = false,
            hasChildrenTable = false,
            isUsingSampleFallback = false
        )
    }

    /**
     * جلب أبناء دفعة من أرقام هويات أرباب الأسر (500 أسرة في الاستعلام الواحد) ضمن جلسة التحديث الجماعي.
     */
    suspend fun queryChildrenChunkForOfficialBulkSync(
        parentIds: List<String>,
        minBirthDateIso: String? = null,
        maxBirthDateIso: String? = null
    ): List<CivilRegistryChildRecord> {
        if (parentIds.isEmpty()) return emptyList()
        return if (activeAdapter === sampleDataSource) {
            sampleDataSource.getChildrenForOfficialSyncChunk(
                parentIds = parentIds,
                minBirthDateIso = minBirthDateIso,
                maxBirthDateIso = maxBirthDateIso
            )
        } else {
            realDataSource.getChildrenForOfficialSyncChunk(
                parentIds = parentIds,
                minBirthDateIso = minBirthDateIso,
                maxBirthDateIso = maxBirthDateIso
            )
        }
    }

    override fun close() {
        realDataSource.close()
        sampleDataSource.close()
    }
}

data class OfficialChildrenQueryResult(
    val isDatabaseAvailable: Boolean,
    val hasChildrenTable: Boolean,
    val isUsingSampleFallback: Boolean,
    val children: List<CivilRegistryChildRecord>
)

data class OfficialBulkSyncSessionStatus(
    val isDatabaseAvailable: Boolean,
    val hasChildrenTable: Boolean,
    val isUsingSampleFallback: Boolean
)
