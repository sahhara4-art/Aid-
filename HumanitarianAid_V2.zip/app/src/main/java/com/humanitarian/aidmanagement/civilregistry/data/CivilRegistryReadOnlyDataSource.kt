package com.humanitarian.aidmanagement.civilregistry.data

import android.content.Context
import android.net.Uri
import android.os.CancellationSignal
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryDbStatus
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchPage
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery

/**
 * طبقة التكييف والمستودع المفصولة للقراءة فقط (Civil Registry Read-Only Repository / Adapter)
 *
 * تدير التبديل السلس والشفاف بين مصدرين مستقلين يطبقان CivilRegistryDataSource:
 * 1. SqliteCivilRegistryDataSource: يرتبط بملف civil_registry.db الفعلي (478,638 سجل) عند توفره أو اختياره.
 * 2. SampleCivilRegistryDataSource: يعمل تلقائياً وفورياً ببيانات تجريبية واقعية بنفس الـ 14 عموداً حرفياً
 *    عندما لا يكون ملف civil_registry.db مرفوعاً بعد (مثل بيئة المعاينة الفورية في AI Studio).
 *
 * يضمن هذا الفصل استبدال أو ربط القاعدة الفعلية لاحقاً دون تعديل الواجهة أو منطق البحث أو الترحيل أو الحفظ.
 */
class CivilRegistryReadOnlyDataSource(
    appContext: Context,
    private val realDataSource: SqliteCivilRegistryDataSource = SqliteCivilRegistryDataSource(appContext.applicationContext),
    private val sampleDataSource: CivilRegistryDataSource = SampleCivilRegistryDataSource(),
    private val enableSampleFallbackWhenMissing: Boolean = true
) : CivilRegistryDataSource {

    companion object {
        const val DEFAULT_PAGE_SIZE = 40
    }

    @Volatile
    private var activeAdapter: CivilRegistryDataSource = realDataSource

    /**
     * يحدد ما إذا كان المصدر النشط حالياً هو القاعدة الفعلية civil_registry.db أم البيانات التجريبية
     */
    val isUsingSampleFallback: Boolean
        get() = activeAdapter === sampleDataSource

    override suspend fun ensureDatabaseReady(): CivilRegistryDbStatus {
        val realStatus = realDataSource.ensureDatabaseReady()
        return when {
            realStatus is CivilRegistryDbStatus.Ready -> {
                activeAdapter = realDataSource
                realStatus
            }
            realStatus is CivilRegistryDbStatus.Missing && enableSampleFallbackWhenMissing -> {
                activeAdapter = sampleDataSource
                sampleDataSource.ensureDatabaseReady()
            }
            else -> {
                activeAdapter = realDataSource
                realStatus
            }
        }
    }

    /**
     * عند ربط ملف civil_registry.db الفعلي من ذاكرة الجهاز، ينتقل المحوّل فوراً للقاعدة الفعلية للقراءة فقط
     */
    suspend fun importExternalDatabase(uri: Uri): CivilRegistryDbStatus {
        val status = realDataSource.importExternalDatabase(uri)
        if (status is CivilRegistryDbStatus.Ready) {
            activeAdapter = realDataSource
        }
        return status
    }

    override suspend fun search(
        query: CivilRegistrySearchQuery,
        offset: Int,
        pageSize: Int,
        cancellationSignal: CancellationSignal?
    ): CivilRegistrySearchPage {
        return activeAdapter.search(
            query = query,
            offset = offset,
            pageSize = pageSize,
            cancellationSignal = cancellationSignal
        )
    }

    override fun close() {
        realDataSource.close()
        sampleDataSource.close()
    }
}
