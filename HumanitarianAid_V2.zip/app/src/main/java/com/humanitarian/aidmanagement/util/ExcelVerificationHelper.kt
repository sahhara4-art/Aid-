package com.humanitarian.aidmanagement.util

import android.content.Context
import android.net.Uri
import android.util.Log
import com.humanitarian.aidmanagement.data.local.dao.FamilyWithLatestAid
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.*
import org.apache.poi.xssf.streaming.SXSSFWorkbook
import org.apache.poi.xssf.usermodel.XSSFCellStyle
import org.apache.poi.xssf.usermodel.XSSFColor
import java.io.InputStream
import java.io.OutputStream
import java.math.BigDecimal

/**
 * ملخص إحصائي لنتائج تدقيق ومطابقة كشف الهويات
 */
data class VerificationSummary(
    val totalInputIds: Int,
    val eligibleCount: Int,
    val ineligibleCount: Int,
    val notRegisteredCount: Int,
    val outOfScopeCount: Int = 0
)

/**
 * النتيجة الكاملة لعملية مطابقة كشف الهويات مقسمة إلى ثلاثة تصنيفات
 */
data class VerificationResult(
    val summary: VerificationSummary,
    val eligibleMatched: List<FamilyWithLatestAid>,
    val ineligibleMatched: List<FamilyWithLatestAid>,
    val notRegisteredIds: List<String>
)

/**
 * محرك فحص ومطابقة كشوف الهويات وتوليد التقارير الثلاثية المعتمدة
 * مبني لمعالجة كشوف تصل إلى 10,000 هوية بأمان تام ودون استهلاك الذاكرة (Memory-Safe)
 */
object ExcelVerificationHelper {

    private const val TAG = "ExcelVerificationHelper"

    // كلمات مفتاحية للتعرف التلقائي على عمود أرقام الهويات
    private val ID_HEADER_KEYWORDS = listOf(
        "رقم الهوية", "الهوية", "هوية", "الرقم الوطني", "رقم_الهوية",
        "nationalid", "national_id", "id", "بطاقة الهوية", "رقم هوية رب الاسرة"
    )

    /**
     * استخراج قائمة أرقام الهويات من ملف الإكسل بكفاءة وحماية ضد استهلاك الذاكرة
     */
    suspend fun extractNationalIds(inputStream: InputStream): List<String> = withContext(Dispatchers.IO) {
        val extractedIds = mutableListOf<String>()
        var workbook: Workbook? = null
        try {
            workbook = WorkbookFactory.create(inputStream)
            val sheet = workbook.getSheetAt(0) ?: return@withContext emptyList()
            val formatter = DataFormatter()

            var idColumnIndex = -1
            var dataStartRowIndex = 0

            // 1. البحث عن الصف الذي يحتوي على ترويسة عمود الهوية
            val maxHeaderScan = sheet.lastRowNum.coerceAtMost(15)
            for (rowIndex in 0..maxHeaderScan) {
                val row = sheet.getRow(rowIndex) ?: continue
                for (cell in row) {
                    val cellText = formatter.formatCellValue(cell).trim().lowercase()
                    if (ID_HEADER_KEYWORDS.any { keyword -> cellText.contains(keyword) }) {
                        idColumnIndex = cell.columnIndex
                        dataStartRowIndex = rowIndex + 1
                        break
                    }
                }
                if (idColumnIndex != -1) break
            }

            // إذا لم يتم العثور على ترويسة واضحة، نفترض العمود الأول (Index 0)
            if (idColumnIndex == -1) {
                idColumnIndex = 0
                // فحص إذا كان الصف الأول نصياً لتخطيه
                val firstRow = sheet.getRow(0)
                val firstCellText = firstRow?.getCell(0)?.let { formatter.formatCellValue(it) }?.trim() ?: ""
                if (firstCellText.contains(Regex("[\\p{L}]"))) {
                    dataStartRowIndex = 1
                } else {
                    dataStartRowIndex = 0
                }
            }

            // 2. قراءة قيم عمود الهوية صفاً بصف
            val totalRows = sheet.lastRowNum
            for (rowIndex in dataStartRowIndex..totalRows) {
                val row = sheet.getRow(rowIndex) ?: continue
                val cell = row.getCell(idColumnIndex) ?: continue

                val rawId = extractRawCellValue(cell, formatter)
                val normalizedId = normalizeNationalId(rawId)
                if (normalizedId.isNotBlank()) {
                    extractedIds.add(normalizedId)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting national IDs: ${e.message}", e)
            throw e
        } finally {
            try {
                workbook?.close()
            } catch (closeEx: Exception) {
                Log.e(TAG, "Failed to close input workbook: ${closeEx.message}", closeEx)
            }
        }

        // إرجاع قائمة فريدة مع الحفاظ على الترتيب الأصلي
        extractedIds.distinct()
    }

    /**
     * استخراج القيمة النصية الصافية للخلية مع منع الترقيم العلمي (Scientific Notation) للأرقام الكبيرة
     */
    private fun extractRawCellValue(cell: Cell, formatter: DataFormatter): String {
        return when (cell.cellType) {
            CellType.NUMERIC -> {
                try {
                    BigDecimal(cell.numericCellValue).toPlainString().replace(Regex("\\.0$"), "").trim()
                } catch (_: Exception) {
                    formatter.formatCellValue(cell).trim()
                }
            }
            CellType.FORMULA -> {
                try {
                    when (cell.cachedFormulaResultType) {
                        CellType.NUMERIC -> BigDecimal(cell.numericCellValue).toPlainString().replace(Regex("\\.0$"), "").trim()
                        else -> formatter.formatCellValue(cell).trim()
                    }
                } catch (_: Exception) {
                    formatter.formatCellValue(cell).trim()
                }
            }
            CellType.STRING -> cell.stringCellValue.trim()
            else -> formatter.formatCellValue(cell).trim()
        }
    }

    /**
     * تنظيف وتوحيد صياغة رقم الهوية وتحويل الأرقام العربية المشرقية إلى غربية
     */
    private fun normalizeNationalId(raw: String): String {
        if (raw.isBlank()) return ""
        val sb = StringBuilder()
        for (ch in raw.trim()) {
            when (ch) {
                in '0'..'9' -> sb.append(ch)
                '٠' -> sb.append('0')
                '١' -> sb.append('1')
                '٢' -> sb.append('2')
                '٣' -> sb.append('3')
                '٤' -> sb.append('4')
                '٥' -> sb.append('5')
                '٦' -> sb.append('6')
                '٧' -> sb.append('7')
                '٨' -> sb.append('8')
                '٩' -> sb.append('9')
            }
        }
        return sb.toString().trim()
    }

    /**
     * محرك المطابقة والفحص الثلاثي لقائمة الهويات المدخلة مع قاعدة بيانات النظام (Mission 2)
     */
    suspend fun verifyNationalIds(
        repository: AidRepository,
        inputIds: List<String>
    ): VerificationResult = withContext(Dispatchers.IO) {
        val distinctInputIds = inputIds.map { normalizeNationalId(it) }.filter { it.isNotBlank() }.distinct()

        if (distinctInputIds.isEmpty()) {
            return@withContext VerificationResult(
                summary = VerificationSummary(0, 0, 0, 0),
                eligibleMatched = emptyList(),
                ineligibleMatched = emptyList(),
                notRegisteredIds = emptyList()
            )
        }

        // 1. جلب السجلات مقترنة بآخر مساعدة عبر الدفعات المقسمة (Chunking) لتفادي حدود SQLite
        val familiesWithAid = repository.getFamiliesWithLatestAid(distinctInputIds)
        val matchedFamiliesMap = familiesWithAid.associateBy { normalizeNationalId(it.family.nationalID) }

        val localitiesMap = repository.getAllLocalitiesSync().associate { it.LocalityID to it.LocalityName }
        val extraLocalityIds = repository.getCurrentUserLocalityIds()

        val eligibleMatched = mutableListOf<FamilyWithLatestAid>()
        val ineligibleMatched = mutableListOf<FamilyWithLatestAid>()
        val notRegisteredIds = mutableListOf<String>()
        var outOfScopeCount = 0

        // 2. التصنيف الثلاثي الصارم مع تطبيق العزل الجغرافي (RLS)
        for (id in distinctInputIds) {
            val familyWithAid = matchedFamiliesMap[id]
            if (familyWithAid != null) {
                if (!com.humanitarian.aidmanagement.security.AccessControlManager.isFamilyAllowed(
                        family = familyWithAid.family,
                        localitiesMap = localitiesMap,
                        extraAllowedLocalityIds = extraLocalityIds
                    )
                ) {
                    outOfScopeCount++
                    continue
                }
                if (isFamilyEligible(familyWithAid.family)) {
                    eligibleMatched.add(familyWithAid)
                } else {
                    ineligibleMatched.add(familyWithAid)
                }
            } else {
                notRegisteredIds.add(id)
            }
        }

        val summary = VerificationSummary(
            totalInputIds = distinctInputIds.size,
            eligibleCount = eligibleMatched.size,
            ineligibleCount = ineligibleMatched.size,
            notRegisteredCount = notRegisteredIds.size,
            outOfScopeCount = outOfScopeCount
        )

        VerificationResult(
            summary = summary,
            eligibleMatched = eligibleMatched,
            ineligibleMatched = ineligibleMatched,
            notRegisteredIds = notRegisteredIds
        )
    }

    /**
     * معيار الاستحقاق الصارم: (مقيم) وَ (معتمد في التنمية والشؤون الاجتماعية)
     */
    private fun isFamilyEligible(family: FamilyEntity): Boolean {
        val isResident = family.residentStatus.trim().contains("مقيم")
        val isApproved = family.developmentApproval.trim().contains("معتمد")
        return isResident && isApproved
    }

    /**
     * توليد مصنف إكسل احترافي (XSSFWorkbook) مكون من 3 أوراق عمل مطابقة للمواصفات الصارمة (Mission 3)
     */
    suspend fun generateVerificationWorkbook(
        result: VerificationResult,
        outputStream: OutputStream
    ) = withContext(Dispatchers.IO) {
        try {
            val workbook = SXSSFWorkbook(100).apply {
                isCompressTempFiles = true
            }
            try {
                // تجهيز الأنماط والألوان التنسيقية
                val (eligibleHeaderStyle, ineligibleHeaderStyle, notRegisteredHeaderStyle) = createHeaderStyles(workbook)
                val dataCellStyle = createDataCellStyle(workbook)

                // الورقة الأولى: مطابق للشروط
                val sheetEligible = workbook.createSheet("مطابق للشروط")
                sheetEligible.setRightToLeft(true)
                populateFamilySheet(
                    sheet = sheetEligible,
                    items = result.eligibleMatched,
                    headerStyle = eligibleHeaderStyle,
                    dataCellStyle = dataCellStyle
                )

                // الورقة الثانية: غير مطابق للشروط
                val sheetIneligible = workbook.createSheet("غير مطابق للشروط")
                sheetIneligible.setRightToLeft(true)
                populateFamilySheet(
                    sheet = sheetIneligible,
                    items = result.ineligibleMatched,
                    headerStyle = ineligibleHeaderStyle,
                    dataCellStyle = dataCellStyle
                )

                // الورقة الثالثة: غير مسجل بالنظام
                val sheetNotRegistered = workbook.createSheet("غير مسجل بالنظام")
                sheetNotRegistered.setRightToLeft(true)
                populateNotRegisteredSheet(
                    sheet = sheetNotRegistered,
                    ids = result.notRegisteredIds,
                    headerStyle = notRegisteredHeaderStyle,
                    dataCellStyle = dataCellStyle
                )

                workbook.write(outputStream)
                outputStream.flush()
            } finally {
                try {
                    workbook.dispose()
                } catch (_: Throwable) {}
                try {
                    workbook.close()
                } catch (closeEx: Throwable) {
                    Log.e(TAG, "Failed to close generated workbook: ${closeEx.message}")
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Falling back to UTF-8 CSV streaming due to POI error: ${t.message}")
            generateVerificationCsv(result, outputStream)
        }
    }

    private fun generateVerificationCsv(
        result: VerificationResult,
        outputStream: OutputStream
    ) {
        val writer = outputStream.bufferedWriter(Charsets.UTF_8)
        writer.write("\uFEFF") // UTF-8 BOM

        fun escape(s: String?): String {
            if (s == null) return "\"\""
            val clean = s.replace("\"", "\"\"")
            return "\"$clean\""
        }

        writer.write("=== تقرير مطابقة كشوف الهويات الثلاثي المعتمد ===\n")
        writer.write("إجمالي الهويات المدخلة:,${result.summary.totalInputIds},مطابق للشروط:,${result.summary.eligibleCount},غير مطابق:,${result.summary.ineligibleCount},غير مسجل:,${result.summary.notRegisteredCount},محجوب خارج النطاق:,${result.summary.outOfScopeCount}\n\n")

        // 1. مطابق للشروط
        writer.write("--- 1. الأسر المطابقة للشروط (المعتمدة والمقيمة) (${result.eligibleMatched.size}) ---\n")
        writer.write(FAMILY_SHEET_HEADERS.joinToString(",") { escape(it) } + "\n")
        for (item in result.eligibleMatched) {
            val f = item.family
            val phonesList = listOfNotNull(f.primary_phone, f.alternative_phone_1, f.alternative_phone_2)
                .map { it.trim() }
                .filter { it.isNotBlank() }
            val phonesText = if (phonesList.isNotEmpty()) phonesList.joinToString(" / ") else "لا يوجد"
            val row = listOf(
                f.nationalID,
                f.date_of_birth.takeIf { it.isNotBlank() } ?: "لا يوجد",
                f.gender.takeIf { it.isNotBlank() } ?: "غير محدد",
                f.maritalStatus.takeIf { it.isNotBlank() } ?: "غير محدد",
                phonesText,
                f.wifeName?.trim()?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                f.wifeNationalID?.trim()?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                if (item.totalAidsCount > 0) item.totalAidsCount.toString() else "لا يوجد",
                item.lastAidDate?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                item.lastAidType?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                item.lastAidCategory?.takeIf { it.isNotBlank() } ?: "لا يوجد"
            )
            writer.write(row.joinToString(",") { escape(it) } + "\n")
        }
        writer.write("\n")

        // 2. غير مطابق للشروط
        writer.write("--- 2. الأسر غير المطابقة للشروط (${result.ineligibleMatched.size}) ---\n")
        writer.write(FAMILY_SHEET_HEADERS.joinToString(",") { escape(it) } + "\n")
        for (item in result.ineligibleMatched) {
            val f = item.family
            val phonesList = listOfNotNull(f.primary_phone, f.alternative_phone_1, f.alternative_phone_2)
                .map { it.trim() }
                .filter { it.isNotBlank() }
            val phonesText = if (phonesList.isNotEmpty()) phonesList.joinToString(" / ") else "لا يوجد"
            val row = listOf(
                f.nationalID,
                f.date_of_birth.takeIf { it.isNotBlank() } ?: "لا يوجد",
                f.gender.takeIf { it.isNotBlank() } ?: "غير محدد",
                f.maritalStatus.takeIf { it.isNotBlank() } ?: "غير محدد",
                phonesText,
                f.wifeName?.trim()?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                f.wifeNationalID?.trim()?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                if (item.totalAidsCount > 0) item.totalAidsCount.toString() else "لا يوجد",
                item.lastAidDate?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                item.lastAidType?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                item.lastAidCategory?.takeIf { it.isNotBlank() } ?: "لا يوجد"
            )
            writer.write(row.joinToString(",") { escape(it) } + "\n")
        }
        writer.write("\n")

        // 3. غير مسجل بالنظام
        writer.write("--- 3. الهويات غير المسجلة بالنظام (${result.notRegisteredIds.size}) ---\n")
        writer.write(NOT_REGISTERED_HEADERS.joinToString(",") { escape(it) } + "\n")
        for (id in result.notRegisteredIds) {
            writer.write("${escape(id)},${escape("غير مسجل في قاعدة البيانات")}\n")
        }

        writer.flush()
    }

    /**
     * عناوين أعمدة أوراق الأسر المطابقة وغير المطابقة (11 عموداً)
     */
    private val FAMILY_SHEET_HEADERS = listOf(
        "رقم الهوية",
        "تاريخ الميلاد",
        "الجنس",
        "الحالة الاجتماعية",
        "أرقام التواصل",
        "اسم الزوج/ة",
        "رقم هوية الزوج/ة",
        "إجمالي عدد المساعدات",
        "تاريخ آخر مساعدة",
        "نوع آخر مساعدة",
        "تصنيف آخر مساعدة"
    )

    private val FAMILY_SHEET_WIDTHS = listOf(18, 14, 10, 16, 26, 24, 18, 18, 16, 20, 20)

    private fun populateFamilySheet(
        sheet: Sheet,
        items: List<FamilyWithLatestAid>,
        headerStyle: CellStyle,
        dataCellStyle: CellStyle
    ) {
        // صف العناوين
        val headerRow = sheet.createRow(0)
        headerRow.heightInPoints = 28f
        FAMILY_SHEET_HEADERS.forEachIndexed { colIdx, title ->
            val cell = headerRow.createCell(colIdx)
            cell.setCellValue(title)
            cell.cellStyle = headerStyle
        }

        // صفوف البيانات
        items.forEachIndexed { rowIdx, item ->
            val row = sheet.createRow(rowIdx + 1)
            row.heightInPoints = 20f
            val f = item.family

            // تجميع أرقام التواصل
            val phonesList = listOfNotNull(f.primary_phone, f.alternative_phone_1, f.alternative_phone_2)
                .map { it.trim() }
                .filter { it.isNotBlank() }
            val phonesText = if (phonesList.isNotEmpty()) phonesList.joinToString(" / ") else "لا يوجد"

            val cellValues = listOf(
                f.nationalID,
                f.date_of_birth.takeIf { it.isNotBlank() } ?: "لا يوجد",
                f.gender.takeIf { it.isNotBlank() } ?: "غير محدد",
                f.maritalStatus.takeIf { it.isNotBlank() } ?: "غير محدد",
                phonesText,
                f.wifeName?.trim()?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                f.wifeNationalID?.trim()?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                if (item.totalAidsCount > 0) item.totalAidsCount.toString() else "لا يوجد",
                item.lastAidDate?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                item.lastAidType?.takeIf { it.isNotBlank() } ?: "لا يوجد",
                item.lastAidCategory?.takeIf { it.isNotBlank() } ?: "لا يوجد"
            )

            cellValues.forEachIndexed { colIdx, text ->
                val cell = row.createCell(colIdx)
                cell.setCellValue(text)
                cell.cellStyle = dataCellStyle
            }
        }

        // ضبط عرض الأعمدة
        FAMILY_SHEET_WIDTHS.forEachIndexed { colIdx, width ->
            sheet.setColumnWidth(colIdx, width * 256)
        }
    }

    private val NOT_REGISTERED_HEADERS = listOf(
        "رقم الهوية",
        "حالة التسجيل"
    )

    private fun populateNotRegisteredSheet(
        sheet: Sheet,
        ids: List<String>,
        headerStyle: CellStyle,
        dataCellStyle: CellStyle
    ) {
        val headerRow = sheet.createRow(0)
        headerRow.heightInPoints = 28f
        NOT_REGISTERED_HEADERS.forEachIndexed { colIdx, title ->
            val cell = headerRow.createCell(colIdx)
            cell.setCellValue(title)
            cell.cellStyle = headerStyle
        }

        ids.forEachIndexed { rowIdx, nationalId ->
            val row = sheet.createRow(rowIdx + 1)
            row.heightInPoints = 20f

            val cell0 = row.createCell(0)
            cell0.setCellValue(nationalId)
            cell0.cellStyle = dataCellStyle

            val cell1 = row.createCell(1)
            cell1.setCellValue("غير مسجل في النظام")
            cell1.cellStyle = dataCellStyle
        }

        sheet.setColumnWidth(0, 20 * 256)
        sheet.setColumnWidth(1, 26 * 256)
    }

    /**
     * بناء أنماط الترويسة الملونة للأوراق الثلاث
     */
    private fun createHeaderStyles(workbook: Workbook): Triple<CellStyle, CellStyle, CellStyle> {
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 11.toShort()
            color = IndexedColors.WHITE.index
        }

        // الأخضر الزمردي للمطابق للشروط (#107C41)
        val eligibleStyle = workbook.createCellStyle().apply {
            setFont(font)
            alignment = HorizontalAlignment.CENTER
            verticalAlignment = VerticalAlignment.CENTER
            fillPattern = FillPatternType.SOLID_FOREGROUND
            (this as? XSSFCellStyle)?.setFillForegroundColor(
                XSSFColor(byteArrayOf(16.toByte(), 124.toByte(), 65.toByte()), null)
            ) ?: run {
                fillForegroundColor = IndexedColors.DARK_GREEN.index
            }
            borderTop = BorderStyle.THIN
            borderBottom = BorderStyle.THIN
            borderLeft = BorderStyle.THIN
            borderRight = BorderStyle.THIN
        }

        // العنبري/الأحمر لغير المطابق (#C62828)
        val ineligibleStyle = workbook.createCellStyle().apply {
            setFont(font)
            alignment = HorizontalAlignment.CENTER
            verticalAlignment = VerticalAlignment.CENTER
            fillPattern = FillPatternType.SOLID_FOREGROUND
            (this as? XSSFCellStyle)?.setFillForegroundColor(
                XSSFColor(byteArrayOf(198.toByte(), 40.toByte(), 40.toByte()), null)
            ) ?: run {
                fillForegroundColor = IndexedColors.RED.index
            }
            borderTop = BorderStyle.THIN
            borderBottom = BorderStyle.THIN
            borderLeft = BorderStyle.THIN
            borderRight = BorderStyle.THIN
        }

        // الرمادي الداكن لغير المسجل بالنظام (#37474F)
        val notRegisteredStyle = workbook.createCellStyle().apply {
            setFont(font)
            alignment = HorizontalAlignment.CENTER
            verticalAlignment = VerticalAlignment.CENTER
            fillPattern = FillPatternType.SOLID_FOREGROUND
            (this as? XSSFCellStyle)?.setFillForegroundColor(
                XSSFColor(byteArrayOf(55.toByte(), 71.toByte(), 79.toByte()), null)
            ) ?: run {
                fillForegroundColor = IndexedColors.GREY_50_PERCENT.index
            }
            borderTop = BorderStyle.THIN
            borderBottom = BorderStyle.THIN
            borderLeft = BorderStyle.THIN
            borderRight = BorderStyle.THIN
        }

        return Triple(eligibleStyle, ineligibleStyle, notRegisteredStyle)
    }

    private fun createDataCellStyle(workbook: Workbook): CellStyle {
        val dataFont = workbook.createFont().apply {
            fontHeightInPoints = 10.toShort()
        }
        return workbook.createCellStyle().apply {
            setFont(dataFont)
            alignment = HorizontalAlignment.CENTER
            verticalAlignment = VerticalAlignment.CENTER
            borderTop = BorderStyle.THIN
            borderBottom = BorderStyle.THIN
            borderLeft = BorderStyle.THIN
            borderRight = BorderStyle.THIN
        }
    }
}
