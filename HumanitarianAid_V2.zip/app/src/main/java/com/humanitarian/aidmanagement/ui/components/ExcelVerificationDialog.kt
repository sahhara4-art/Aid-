package com.humanitarian.aidmanagement.ui.components

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.ExcelVerificationHelper
import com.humanitarian.aidmanagement.util.VerificationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * نافذة حوار فحص ومطابقة كشوف الهويات وتصدير التقارير الثلاثية
 */
@Composable
fun ExcelVerificationDialog(
    repository: AidRepository,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isProcessing by remember { mutableStateOf(false) }
    var processingStatus by remember { mutableStateOf("") }
    var verificationResult by remember { mutableStateOf<VerificationResult?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0 = مطابق, 1 = غير مطابق, 2 = غير مسجل

    // لاقط اختيار ملف الإكسل للإدخال
    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                isProcessing = true
                errorMessage = null
                processingStatus = "جاري فتح الملف واستخراج أرقام الهويات..."

                val ids = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        ExcelVerificationHelper.extractNationalIds(stream)
                    } ?: emptyList()
                }

                if (ids.isEmpty()) {
                    errorMessage = "لم يتم العثور على أي أرقام هويات صالحة في الملف المحدد."
                    isProcessing = false
                    return@launch
                }

                processingStatus = "تم استخراج ${ids.size} هوية. جاري الفحص والمطابقة مع قاعدة البيانات..."
                val result = ExcelVerificationHelper.verifyNationalIds(repository, ids)

                verificationResult = result
                isProcessing = false
            } catch (e: Exception) {
                errorMessage = "حدث خطأ أثناء فحص الملف: ${e.localizedMessage ?: e.message}"
                isProcessing = false
            }
        }
    }

    // لاقط حفظ وتصدير ملف التقرير الثلاثي
    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri: Uri? ->
        val currentResult = verificationResult ?: return@rememberLauncherForActivityResult
        if (uri == null) return@rememberLauncherForActivityResult

        scope.launch {
            try {
                isProcessing = true
                processingStatus = "جاري إنشاء المصنف وتصدير الأوراق الثلاث بصيغة XLSX..."

                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.use { outStream ->
                        ExcelVerificationHelper.generateVerificationWorkbook(currentResult, outStream)
                    }
                }

                isProcessing = false
                Toast.makeText(context, "تم تصدير تقرير المطابقة الثلاثي بنجاح!", Toast.LENGTH_LONG).show()
            } catch (t: Throwable) {
                errorMessage = "فشل تصدير الملف: ${t.localizedMessage ?: t.message ?: "خطأ غير متوقع"}"
                isProcessing = false
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = {
                if (!isProcessing) onDismiss()
            },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.90f)
                    .padding(8.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // شريط العنوان
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF107C41).copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FactCheck,
                                    contentDescription = null,
                                    tint = Color(0xFF107C41),
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "فحص ومطابقة كشف هويات",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "التدقيق الميداني والتصدير الثلاثي (مقيم ومعتمد / غير مطابق / غير مسجل)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                            }
                        }

                        IconButton(
                            onClick = { if (!isProcessing) onDismiss() },
                            enabled = !isProcessing
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق")
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    // رسالة الخطأ إن وجدت
                    errorMessage?.let { err ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp),
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Text(
                                    text = err,
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    // الحالة 1: أثناء المعالجة الخلفية
                    if (isProcessing) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp),
                                modifier = Modifier.padding(24.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(54.dp),
                                    color = Color(0xFF107C41),
                                    strokeWidth = 4.dp
                                )
                                Text(
                                    text = processingStatus,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "تتم المعالجة بنظام الدفعات الآمن لمنع استهلاك الذاكرة وحماية استقرار التطبيق",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else if (verificationResult == null) {
                        // الحالة 2: شاشة البدء قبل اختيار الملف
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = null,
                                modifier = Modifier.size(80.dp),
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "اختر ملف إكسل يحتوي على أرقام الهويات الوطنية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "سيقوم النظام تلقائياً باستخراج الهويات ومطابقتها مع قاعدة البيانات، مع حساب سجل المساعدات الأخير، وتصنيف المستفيدين بدقة إلى ثلاثة مسارات.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                            Spacer(modifier = Modifier.height(24.dp))

                            Button(
                                onClick = {
                                    openDocumentLauncher.launch(
                                        arrayOf(
                                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                            "application/vnd.ms-excel",
                                            "application/octet-stream",
                                            "*/*"
                                        )
                                    )
                                },
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 14.dp)
                            ) {
                                Icon(Icons.Default.UploadFile, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("اختيار كشف الإكسل (.xlsx / .xls)", fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        // الحالة 3: عرض النتائج الثلاثية الكاملة
                        val res = verificationResult!!
                        val summary = res.summary

                        // بطاقات الإحصائيات العلوية
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StatMiniCard(
                                title = "إجمالي المفحوصين",
                                count = summary.totalInputIds,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            StatMiniCard(
                                title = "مطابق للشروط",
                                count = summary.eligibleCount,
                                color = Color(0xFF107C41),
                                modifier = Modifier.weight(1f)
                            )
                            StatMiniCard(
                                title = "غير مطابق",
                                count = summary.ineligibleCount,
                                color = Color(0xFFD97706),
                                modifier = Modifier.weight(1f)
                            )
                            StatMiniCard(
                                title = "غير مسجل",
                                count = summary.notRegisteredCount,
                                color = Color(0xFFE11D48),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // أزرار التبديل بين الأوراق الثلاث
                        TabRow(
                            selectedTabIndex = selectedTab,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.clip(RoundedCornerShape(12.dp))
                        ) {
                            Tab(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                text = {
                                    Text(
                                        "مطابق للشروط (${summary.eligibleCount})",
                                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedTab == 0) Color(0xFF107C41) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            )
                            Tab(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                text = {
                                    Text(
                                        "غير مطابق (${summary.ineligibleCount})",
                                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedTab == 1) Color(0xFFD97706) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            )
                            Tab(
                                selected = selectedTab == 2,
                                onClick = { selectedTab = 2 },
                                text = {
                                    Text(
                                        "غير مسجل (${summary.notRegisteredCount})",
                                        fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                        color = if (selectedTab == 2) Color(0xFFE11D48) else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // قائمة المعاينة التفاعلية
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
                                .padding(8.dp)
                        ) {
                            when (selectedTab) {
                                0 -> {
                                    if (res.eligibleMatched.isEmpty()) {
                                        EmptyTabPlaceholder("لا توجد أسر مطابقة للشروط في هذا الكشف")
                                    } else {
                                        LazyColumn(
                                            modifier = Modifier.fillMaxSize(),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            items(res.eligibleMatched) { item ->
                                                MatchedFamilyPreviewRow(item, isEligible = true)
                                            }
                                        }
                                    }
                                }
                                1 -> {
                                    if (res.ineligibleMatched.isEmpty()) {
                                        EmptyTabPlaceholder("لا توجد أسر غير مطابقة للشروط")
                                    } else {
                                        LazyColumn(
                                            modifier = Modifier.fillMaxSize(),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            items(res.ineligibleMatched) { item ->
                                                MatchedFamilyPreviewRow(item, isEligible = false)
                                            }
                                        }
                                    }
                                }
                                2 -> {
                                    if (res.notRegisteredIds.isEmpty()) {
                                        EmptyTabPlaceholder("جميع أرقام الهويات مسجلة في النظام")
                                    } else {
                                        LazyColumn(
                                            modifier = Modifier.fillMaxSize(),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            items(res.notRegisteredIds) { id ->
                                                NotRegisteredRow(id)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // أزرار التحكم السفلية
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    verificationResult = null
                                    errorMessage = null
                                },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("فحص كشف آخر")
                            }

                            Button(
                                onClick = {
                                    val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
                                    val filename = "تقرير_مطابقة_الهويات_الثلاثي_$timestamp.xlsx"
                                    createDocumentLauncher.launch(filename)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF107C41)),
                                modifier = Modifier.weight(1.5f)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تصدير التقرير الثلاثي (Excel)", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatMiniCard(
    title: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = count.toString(),
                fontWeight = FontWeight.Black,
                style = MaterialTheme.typography.titleMedium,
                color = color
            )
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MatchedFamilyPreviewRow(item: com.humanitarian.aidmanagement.data.local.dao.FamilyWithLatestAid, isEligible: Boolean) {
    val f = item.family
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isEligible) Color(0xFF107C41).copy(alpha = 0.05f) else Color(0xFFD97706).copy(alpha = 0.05f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.2f)) {
                Text(
                    text = f.name,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "هوية: ${f.nationalID} • ${f.maritalStatus} • ${f.residentStatus} • ${f.developmentApproval}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                )
            }

            Column(
                modifier = Modifier.weight(0.8f),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = if (item.totalAidsCount > 0) "${item.totalAidsCount} مساعدات سابقة" else "لا توجد مساعدات",
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (item.totalAidsCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                item.lastAidDate?.let { date ->
                    Text(
                        text = "آخر مساعدة: $date",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

@Composable
private fun NotRegisteredRow(nationalId: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE11D48).copy(alpha = 0.05f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PersonOff,
                    contentDescription = null,
                    tint = Color(0xFFE11D48),
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "رقم الهوية: $nationalId",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFFE11D48).copy(alpha = 0.15f)
            ) {
                Text(
                    text = "غير مسجل في النظام",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE11D48),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun EmptyTabPlaceholder(message: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            textAlign = TextAlign.Center
        )
    }
}
