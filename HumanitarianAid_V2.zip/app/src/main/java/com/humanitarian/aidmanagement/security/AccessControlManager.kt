package com.humanitarian.aidmanagement.security

import android.content.Context
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * مراقب الصلاحيات المؤسسي ومحرك التحكم في الوصول (Enterprise ABAC & Row-Level Security Engine)
 * يدير التحقق الدقيق من الصلاحيات الإجرائية، العزل الجغرافي، القيود الزمنية، وحدود الجلسات
 */
object AccessControlManager {

    // الأوامر والصلاحيات الإجرائية الدقيقة (Granular Action & UI Permissions)
    const val CAN_MANAGE_USERS = "CAN_MANAGE_USERS"
    const val CAN_VIEW_HOME_CARDS = "CAN_VIEW_HOME_CARDS"
    const val CAN_IMPORT_EXCEL = "CAN_IMPORT_EXCEL"
    const val CAN_EXPORT_REPORTS = "CAN_EXPORT_REPORTS"
    const val CAN_ACCESS_BI_DASHBOARD = "CAN_ACCESS_BI_DASHBOARD"
    const val CAN_VERIFY_IDS = "CAN_VERIFY_IDS"
    const val CAN_RUN_FILTRATION = "CAN_RUN_FILTRATION"
    const val CAN_MANAGE_FAMILIES = "CAN_MANAGE_FAMILIES"
    const val CAN_DELIVER_AID = "CAN_DELIVER_AID"
    const val CAN_BACKUP_CLOUD = "CAN_BACKUP_CLOUD"
    const val CAN_BACKUP_LOCAL = "CAN_BACKUP_LOCAL"
    const val CAN_SEARCH_CIVIL_REGISTRY = "CAN_SEARCH_CIVIL_REGISTRY"

    const val ACTION_ADD = "CAN_ADD"
    const val ACTION_EDIT = "CAN_EDIT"
    const val ACTION_DELETE = "CAN_DELETE"
    const val ACTION_EXPORT = "CAN_EXPORT"
    const val ACTION_EXPORT_EXCEL = "CAN_EXPORT_EXCEL"
    const val ACTION_EXPORT_PDF = "CAN_EXPORT_PDF"
    const val ACTION_DELIVER = "CAN_DELIVER"
    const val ACTION_NOMINATE = "CAN_NOMINATE"

    // صلاحيات إضافية متوافقة مع الشاشات الميدانية
    const val CAN_VIEW_REPORTS = "CAN_VIEW_REPORTS"
    const val CAN_VIEW_GEOGRAPHIC = "CAN_VIEW_GEOGRAPHIC"
    const val CAN_MANAGE_PROJECTS = "CAN_MANAGE_PROJECTS"

    // صلاحيات نظام إدارة المخازن واللوجستيات والتخزين للغير (Warehouse ERP & 3PL)
    const val CAN_WAREHOUSE_MANAGE_DEF = "CAN_WAREHOUSE_MANAGE_DEF"
    const val CAN_WAREHOUSE_MOVEMENTS = "CAN_WAREHOUSE_MOVEMENTS"
    const val CAN_WAREHOUSE_CLIENTS_3PL = "CAN_WAREHOUSE_CLIENTS_3PL"
    const val CAN_WAREHOUSE_FINANCE = "CAN_WAREHOUSE_FINANCE"
    const val CAN_WAREHOUSE_AUDIT = "CAN_WAREHOUSE_AUDIT"
    const val CAN_WAREHOUSE_EXPORT_REPORTS = "CAN_WAREHOUSE_EXPORT_REPORTS"

    // أسماء اختصارية متوافقة (Aliases)
    const val CAN_ADD = ACTION_ADD
    const val CAN_EDIT = ACTION_EDIT
    const val CAN_DELETE = ACTION_DELETE
    const val CAN_EXPORT = ACTION_EXPORT
    const val CAN_EXPORT_EXCEL = ACTION_EXPORT_EXCEL
    const val CAN_EXPORT_PDF = ACTION_EXPORT_PDF
    const val CAN_DELIVER = ACTION_DELIVER
    const val CAN_NOMINATE = ACTION_NOMINATE

    val ALL_ACTIONS = listOf(
        CAN_MANAGE_USERS to "إدارة حسابات المستخدمين والصلاحيات",
        CAN_VIEW_HOME_CARDS to "عرض بطاقات ومؤشرات الشاشة الرئيسية",
        CAN_IMPORT_EXCEL to "استيراد ملفات إكسل وتنزيل القوالب",
        CAN_EXPORT_REPORTS to "تصدير التقارير وكشوفات المشاريع (Excel / PDF)",
        CAN_ACCESS_BI_DASHBOARD to "الوصول للوحة التقارير والتحليلات الذكية (BI)",
        CAN_VERIFY_IDS to "أداة فحص ومطابقة كشوفات الهويات",
        CAN_RUN_FILTRATION to "تشغيل محرك الترشيح والفرز والمفاضلة",
        CAN_MANAGE_FAMILIES to "إدارة وعرض سجل الأسر والمستفيدين",
        CAN_DELIVER_AID to "تنفيذ عمليات تسليم وصرف المساعدات الميدانية",
        CAN_BACKUP_CLOUD to "النسخ الاحتياطي والاستعادة السحابية (Google Drive)",
        CAN_BACKUP_LOCAL to "النسخ الاحتياطي والاستعادة المحلية (.db / JSON / SQL)",
        CAN_VIEW_GEOGRAPHIC to "عرض التوزيع الجغرافي للمناطق والشعب",
        CAN_MANAGE_PROJECTS to "إدارة ومتابعة المشاريع الإغاثية",
        ACTION_ADD to "إضافة سجلات جديدة (أسر، أطفال، مشاريع)",
        ACTION_EDIT to "تعديل وتحديث بيانات المواطنين والمشاريع",
        ACTION_DELETE to "حذف السجلات أو التراجع عن التسليم",
        ACTION_NOMINATE to "اعتماد وترحيل قوائم المرشحين للمشاريع",
        CAN_SEARCH_CIVIL_REGISTRY to "البحث والاستعلام في السجل المدني (للقراءة فقط)",
        CAN_WAREHOUSE_MANAGE_DEF to "إدارة تعريف المخازن والطاقم",
        CAN_WAREHOUSE_MOVEMENTS to "تسجيل واردات وصادرات ومناقلات",
        CAN_WAREHOUSE_CLIENTS_3PL to "إدارة التخزين للغير (العملاء)",
        CAN_WAREHOUSE_FINANCE to "إدارة الموازنة والمصروفات والرواتب",
        CAN_WAREHOUSE_AUDIT to "إجراء الجرد الأعمى والتسويات",
        CAN_WAREHOUSE_EXPORT_REPORTS to "تصدير تقارير المخازن (Excel/PDF)"
    )

    // الشاشات المصرح بها (Screen Access Permissions — مطابقة 100% للقائمة الجانبية)
    const val SCREEN_DASHBOARD = "dashboard"
    const val SCREEN_FAMILIES = "families"
    const val SCREEN_ADD_FAMILY = "add_family"
    const val SCREEN_CIVIL_REGISTRY = "civil_registry_lookup"
    const val SCREEN_NOMINATION = "nomination"
    const val SCREEN_DELIVERY = "delivery"
    const val SCREEN_PROJECTS = "projects"
    const val SCREEN_WAREHOUSE_ERP = "warehouse_erp"
    const val SCREEN_WAREHOUSE_REPORTS = "warehouse_dynamic_reports"
    const val SCREEN_GEOGRAPHIC = "geographic_distribution"
    const val SCREEN_REPORTS = "reports"
    const val SCREEN_EXECUTIVE_REPORTS = "executive_reports"
    const val SCREEN_DYNAMIC_REPORTS = "dynamic_report_export"
    const val SCREEN_INTEGRITY_AUDITOR = "household_integrity_auditor"
    const val SCREEN_EXCEL_MATCHING = "excel_matching"
    const val SCREEN_EXCEL = "excel_import_export"
    const val SCREEN_AUDIT_LOG = "audit_log_screen"
    const val SCREEN_BACKUP = "backup"
    const val SCREEN_USERS = "users"

    val ALL_SCREENS = listOf(
        SCREEN_DASHBOARD to "الرئيسية (لوحة القيادة)",
        SCREEN_FAMILIES to "سجل الأسر والمستفيدين",
        SCREEN_ADD_FAMILY to "إضافة أسرة جديدة",
        SCREEN_CIVIL_REGISTRY to "البحث في السجل المدني",
        SCREEN_NOMINATION to "محرك الترشيح",
        SCREEN_DELIVERY to "تسليم وصرف المساعدات",
        SCREEN_PROJECTS to "المشاريع الإنسانية",
        SCREEN_WAREHOUSE_ERP to "إدارة المخازن والمحاسبة اللوجستية",
        SCREEN_WAREHOUSE_REPORTS to "تقارير المخازن التفصيلية",
        SCREEN_GEOGRAPHIC to "التوزيع الجغرافي",
        SCREEN_REPORTS to "التقارير والإحصائيات",
        SCREEN_EXECUTIVE_REPORTS to "التقرير الإداري التنفيذي",
        SCREEN_DYNAMIC_REPORTS to "مركز التقارير الديناميكي",
        SCREEN_INTEGRITY_AUDITOR to "كاشف التداخل والازدواجية",
        SCREEN_EXCEL_MATCHING to "مطابقة وتدقيق الإكسل (الشركاء)",
        SCREEN_EXCEL to "استيراد ملفات الإكسل",
        SCREEN_AUDIT_LOG to "سجل الرقابة والتدقيق",
        SCREEN_BACKUP to "النسخ الاحتياطي واستعادة البيانات",
        SCREEN_USERS to "إدارة الحسابات والصلاحيات"
    )

    val ALL_SCREEN_KEYS: Set<String> = ALL_SCREENS.map { it.first }.toSet()

    fun normalizeScreenKey(rawKey: String): String {
        return when (rawKey.trim().lowercase()) {
            "backup_restore", "backup", "settings" -> SCREEN_BACKUP
            "accounts_permissions", "users_management_route", "users" -> SCREEN_USERS
            "civil_registry", "civil_registry_lookup" -> SCREEN_CIVIL_REGISTRY
            "dynamic_nomination", "manual_selection", "nomination_results", "migration", "transfer", "nomination" -> SCREEN_NOMINATION
            "family_details", "children", "families" -> SCREEN_FAMILIES
            "project_details", "projects" -> SCREEN_PROJECTS
            "warehouse", "warehouses", "warehouse_erp", "warehouse_management" -> SCREEN_WAREHOUSE_ERP
            "warehouse_reports", "warehouse_dynamic_reports", "تقارير المخازن التفصيلية" -> SCREEN_WAREHOUSE_REPORTS
            "export_project_screen", "dynamic_report_export" -> SCREEN_DYNAMIC_REPORTS
            else -> rawKey.trim().lowercase()
        }
    }

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _permissionsFlow = MutableStateFlow<List<String>>(emptyList())
    val permissionsFlow: StateFlow<List<String>> = _permissionsFlow.asStateFlow()

    private val _permissionsSetFlow = MutableStateFlow<Set<String>>(emptySet())
    val permissionsSetFlow: StateFlow<Set<String>> = _permissionsSetFlow.asStateFlow()

    val permissionsSet: Set<String>
        get() = _permissionsSetFlow.value

    private val _currentRegionFlow = MutableStateFlow("ALL")
    val currentRegionFlow: StateFlow<String> = _currentRegionFlow.asStateFlow()

    val currentRegion: String
        get() = _currentRegionFlow.value

    private val _currentSubRegionFlow = MutableStateFlow("ALL")
    val currentSubRegionFlow: StateFlow<String> = _currentSubRegionFlow.asStateFlow()

    val currentSubRegion: String
        get() = _currentSubRegionFlow.value

    private val _assignedSubAreaFlow = MutableStateFlow<String?>(null)
    val assignedSubAreaFlow: StateFlow<String?> = _assignedSubAreaFlow.asStateFlow()

    private val _assignedDivisionsFlow = MutableStateFlow<List<String>>(emptyList())
    val assignedDivisionsFlow: StateFlow<List<String>> = _assignedDivisionsFlow.asStateFlow()

    // ربط المستخدم بمخزن محدد ("ALL" = جميع المخازن أو معرف مخزن محدد) — يُحفظ محلياً في SharedPreferences دون المساس بجداول Room
    private const val WAREHOUSE_ASSIGN_PREFS = "warehouse_user_assignments_v1"
    private const val WAREHOUSE_ASSIGN_KEY_PREFIX = "wh_user_"

    @Volatile
    private var appContextForWarehouse: Context? = null

    private val _assignedWarehouseIdFlow = MutableStateFlow("ALL")
    val assignedWarehouseIdFlow: StateFlow<String> = _assignedWarehouseIdFlow.asStateFlow()

    val currentAssignedWarehouseId: String
        get() = _assignedWarehouseIdFlow.value

    fun initWarehouseAssignments(context: Context) {
        appContextForWarehouse = context.applicationContext
        _assignedWarehouseIdFlow.value = computeAssignedWarehouseId(_currentUser.value)
    }

    private fun warehouseAssignmentKey(username: String): String {
        return WAREHOUSE_ASSIGN_KEY_PREFIX + username.trim().lowercase()
    }

    fun getAssignedWarehouseId(context: Context, username: String?): String {
        appContextForWarehouse = context.applicationContext
        val cleanName = username?.trim().orEmpty()
        if (cleanName.isBlank() || cleanName == "admin") return "ALL"
        val prefs = context.applicationContext.getSharedPreferences(WAREHOUSE_ASSIGN_PREFS, Context.MODE_PRIVATE)
        val stored = prefs.getString(warehouseAssignmentKey(cleanName), "ALL")?.trim().orEmpty()
        return if (isAllToken(stored)) "ALL" else stored
    }

    fun getAssignedWarehouseId(user: UserEntity? = _currentUser.value): String {
        if (user == null || isSuperAdminUser(user)) return "ALL"
        val ctx = appContextForWarehouse ?: return "ALL"
        return getAssignedWarehouseId(ctx, user.UserName)
    }

    fun setAssignedWarehouseId(context: Context, username: String, warehouseId: String) {
        appContextForWarehouse = context.applicationContext
        val cleanName = username.trim()
        if (cleanName.isBlank() || cleanName == "admin") return
        val normalized = if (isAllToken(warehouseId)) "ALL" else warehouseId.trim()
        val prefs = context.applicationContext.getSharedPreferences(WAREHOUSE_ASSIGN_PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(warehouseAssignmentKey(cleanName), normalized).apply()
        if (_currentUser.value?.UserName?.trim()?.equals(cleanName, ignoreCase = true) == true) {
            _assignedWarehouseIdFlow.value = normalized
        }
    }

    private fun computeAssignedWarehouseId(user: UserEntity?): String {
        if (user == null || isSuperAdminUser(user)) return "ALL"
        val ctx = appContextForWarehouse ?: return "ALL"
        return getAssignedWarehouseId(ctx, user.UserName)
    }

    fun isRestrictedToSingleWarehouse(user: UserEntity? = _currentUser.value): Boolean {
        if (user == null || isSuperAdminUser(user)) return false
        return !isAllToken(getAssignedWarehouseId(user))
    }

    /**
     * تحديث أو تعيين المستخدم المسجل حالياً في النظام وتحديث تدفقات الصلاحيات والنطاق الجغرافي والمخزني
     */
    fun setCurrentUser(user: UserEntity?) {
        _currentUser.value = user
        val effectiveList = computeEffectivePermissions(user)
        _permissionsFlow.value = effectiveList
        _permissionsSetFlow.value = effectiveList.toSet()
        _currentRegionFlow.value = computeEffectiveRegion(user)
        _currentSubRegionFlow.value = computeEffectiveSubRegion(user)
        _assignedSubAreaFlow.value = computeAssignedSubArea(user)
        _assignedDivisionsFlow.value = computeAssignedDivisions(user)
        _assignedWarehouseIdFlow.value = computeAssignedWarehouseId(user)
    }

    /**
     * قائمة الصلاحيات النشطة للمستخدم الحالي (متوافقة مع Zero-Trust RBAC)
     */
    val permissions: List<String>
        get() = computeEffectivePermissions(_currentUser.value)

    /**
     * المنطقة / المحلية الفردية المعينة للمستخدم (تُقفل القوائم عليها؛ أو null إذا كان غير مقيد أو لديه عدة محليات)
     */
    val assignedSubArea: String?
        get() = computeAssignedSubArea(_currentUser.value)

    /**
     * الشعب الميدانية المعينة للمستخدم (فارغة تعني عدم وجود تقييد على الشعب)
     */
    val assignedDivisions: List<String>
        get() = computeAssignedDivisions(_currentUser.value)

    private fun isAllToken(value: String?): Boolean {
        val t = value?.trim() ?: return true
        return t.isBlank() ||
            t.equals("ALL", ignoreCase = true) ||
            t == "الكل" ||
            t == "*" ||
            t == "كافة المجموعات" ||
            t == "كافة المناطق" ||
            t == "كافة مناطق قطاع غزة" ||
            t == "جميع المناطق" ||
            t == "جميع المحليات"
    }

    /**
     * تجاوز الصلاحيات محصور حصرياً بالحساب الرئيسي الأساسي (username == "admin") فقط.
     * أي حساب آخر (حتى لو كان دوره مدير النظام أو مشرف) يخضع بالكامل للشاشات والعمليات والنطاق الجغرافي المحدد له.
     */
    private fun isSuperAdminUser(user: UserEntity?): Boolean {
        if (user == null) return false
        return user.UserName.trim() == "admin"
    }

    private fun computeEffectiveRegion(user: UserEntity?): String {
        if (user == null) return "ALL"
        val explicitRegion = user.region.trim()
        return if (!isAllToken(explicitRegion)) explicitRegion else "ALL"
    }

    private fun computeEffectiveSubRegion(user: UserEntity?): String {
        if (user == null) return "ALL"
        val explicitSubRegion = user.sub_region.trim()
        return if (!isAllToken(explicitSubRegion)) explicitSubRegion else "ALL"
    }

    private fun computeAssignedSubArea(user: UserEntity?): String? {
        if (user == null) return null
        val explicitRegion = user.region.trim()
        return if (!isAllToken(explicitRegion)) explicitRegion else null
    }

    private fun computeAssignedDivisions(user: UserEntity?): List<String> {
        if (user == null) return emptyList()
        val explicitSubRegion = user.sub_region.trim()
        if (!isAllToken(explicitSubRegion)) {
            return listOf(explicitSubRegion)
        }
        val cleaned = user.allowedBranches.map { it.trim() }.filter { !isAllToken(it) }.distinct()
        return if (cleaned.size > 1) cleaned else emptyList()
    }

    private fun parsePermissionsString(raw: String): List<String> {
        if (raw.isBlank()) return emptyList()
        val cleaned = raw.trim().removePrefix("[").removeSuffix("]")
        return cleaned.split(",", ";", "|", "\n")
            .map { it.trim().removeSurrounding("\"").removeSurrounding("'") }
            .filter { it.isNotBlank() }
    }

    private fun expandPermissionAliases(rawTokens: Collection<String>): List<String> {
        val result = linkedSetOf<String>()
        rawTokens.forEach { raw ->
            val token = raw.trim()
            if (token.isNotBlank()) {
                result.add(token)
                when (token.uppercase()) {
                    "BACKUP_LOCAL", CAN_BACKUP_LOCAL -> {
                        result.add(CAN_BACKUP_LOCAL)
                        result.add("BACKUP_LOCAL")
                    }
                    "BACKUP_CLOUD", CAN_BACKUP_CLOUD -> {
                        result.add(CAN_BACKUP_CLOUD)
                        result.add("BACKUP_CLOUD")
                    }
                    "IMPORT", "IMPORT_EXCEL", "ACTION_IMPORT", CAN_IMPORT_EXCEL -> {
                        result.add(CAN_IMPORT_EXCEL)
                        result.add("IMPORT")
                    }
                    "EXPORT", CAN_EXPORT_REPORTS, ACTION_EXPORT, ACTION_EXPORT_EXCEL, ACTION_EXPORT_PDF -> {
                        if (token.uppercase() == "EXPORT" || token.uppercase() == CAN_EXPORT_REPORTS || token.uppercase() == ACTION_EXPORT) {
                            result.add(CAN_EXPORT_REPORTS)
                            result.add("EXPORT")
                            result.add(ACTION_EXPORT)
                            result.add(ACTION_EXPORT_EXCEL)
                            result.add(ACTION_EXPORT_PDF)
                        }
                    }
                }
            }
        }
        return result.toList()
    }

    private fun computeEffectivePermissions(user: UserEntity?): List<String> {
        if (user == null) return emptyList()
        if (isSuperAdminUser(user)) {
            return (ALL_ACTIONS.map { it.first } +
                ALL_SCREENS.map { it.first } +
                listOf(
                    ACTION_DELIVER, CAN_VIEW_REPORTS, ACTION_EXPORT,
                    ACTION_EXPORT_EXCEL, ACTION_EXPORT_PDF,
                    "BACKUP_CLOUD", "BACKUP_LOCAL", "IMPORT", "EXPORT"
                )
            ).distinct()
        }
        if (isAccountValid(user) !is AccountValidationResult.Valid) return emptyList()

        val parsedUnified = parsePermissionsString(user.permissions)
        val rawCombined = if (parsedUnified.isNotEmpty()) {
            parsedUnified
        } else {
            (user.actionPermissions + user.screenPermissions).distinct()
        }
        return expandPermissionAliases(rawCombined)
    }

    fun isAllRegions(): Boolean {
        return isAllToken(currentRegion) && getCleanAllowedLocalities().isEmpty()
    }

    fun isAllSubRegions(): Boolean {
        return isAllToken(currentSubRegion) && getCleanAllowedBranches().isEmpty()
    }

    fun effectiveSqlRegion(): String = if (isAllToken(currentRegion)) "ALL" else currentRegion.trim()

    fun effectiveSqlSubRegion(): String = if (isAllToken(currentSubRegion)) "ALL" else currentSubRegion.trim()

    fun isGeoRestrictedUser(): Boolean = !isAllRegions() || !isAllSubRegions()

    /**
     * الحصول على المستخدم النشط حالياً
     */
    fun getCurrentUser(): UserEntity? = _currentUser.value

    /**
     * هل يوجد مستخدم مسجل حالياً
     */
    fun isLoggedIn(): Boolean = _currentUser.value != null

    /**
     * هل المستخدم الحالي هو مدير النظام العام (Super Admin)
     */
    fun isSuperAdmin(): Boolean = isSuperAdminUser(_currentUser.value)

    /**
     * التحقق من صلاحية الحساب (نشط، غير مقفل، غير منتهي الصلاحية، ولم يتجاوز مرات الدخول)
     */
    fun isAccountValid(targetUser: UserEntity? = _currentUser.value): AccountValidationResult {
        val user = targetUser ?: return AccountValidationResult.NotLoggedIn

        if (!user.IsActive) {
            return AccountValidationResult.Inactive("تم تعطيل هذا الحساب من قِبل إدارة النظام.")
        }

        if (user.IsLocked) {
            return AccountValidationResult.Locked("الحساب مقفل أمنياً بسبب تجاوز محاولات الدخول.")
        }

        val lockedUntil = user.LockedUntil ?: 0L
        if (lockedUntil > System.currentTimeMillis()) {
            return AccountValidationResult.Locked("الحساب مقفل مؤقتاً حتى نهاية فترة الحظر.")
        }

        // فحص تاريخ انتهاء الحساب
        val accountExpiryTimestamp = user.accountExpiryDate ?: 0L
        if (accountExpiryTimestamp > 0L && System.currentTimeMillis() >= accountExpiryTimestamp) {
            return AccountValidationResult.Expired("انتهت صلاحية هذا الحساب الزمني. يرجى مراجعة المسؤول.")
        }

        // فحص رصيد مرات الدخول للجلسة النشطة (بعد احتساب الدخول الحالي في LoginViewModel)
        val maxAllowedLogins = if (user.maxLogins > 0) user.maxLogins else user.MaxAllowedLogins
        val consumedLogins = if (user.maxLogins > 0) user.currentLogins else maxOf(user.currentLogins, user.ConsumedLogins)
        if (maxAllowedLogins > 0 && consumedLogins > maxAllowedLogins) {
            return AccountValidationResult.QuotaExceeded("تم استنفاد الحد الأقصى لمرات الدخول المسموح بها ($maxAllowedLogins مرة).")
        }

        // فحص رصيد مرات الدخول الإجمالي التراكمي (Lifetime Login Quota: -1 = غير محدود)
        if (user.totalAllowedLogins != -1 && (user.totalAllowedLogins == 0 || user.totalLoginsUsed > user.totalAllowedLogins)) {
            return AccountValidationResult.QuotaExceeded("لقد استنفدت رصيدك الإجمالي لمرات الدخول المسموحة على هذا النظام. تم قفل الحساب، راجع الإدارة.")
        }

        return AccountValidationResult.Valid
    }

    /**
     * التحقق من امتلاك أمر إجرائي محدد (CAN_ADD, CAN_EDIT, CAN_DELETE, CAN_EXPORT_EXCEL, CAN_EXPORT_PDF, ...)
     */
    fun hasActionPermission(action: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        if (isAccountValid(user) !is AccountValidationResult.Valid) return false
        val perms = computeEffectivePermissions(user)
        return when (action) {
            ACTION_DELIVER, CAN_DELIVER_AID -> {
                perms.contains(CAN_DELIVER_AID) || perms.contains(ACTION_DELIVER)
            }
            CAN_ACCESS_BI_DASHBOARD, CAN_VIEW_REPORTS -> {
                perms.contains(CAN_ACCESS_BI_DASHBOARD) || perms.contains(CAN_VIEW_REPORTS)
            }
            CAN_IMPORT_EXCEL, "IMPORT" -> {
                perms.contains(CAN_IMPORT_EXCEL) || perms.contains("IMPORT")
            }
            CAN_BACKUP_LOCAL, "BACKUP_LOCAL" -> {
                perms.contains(CAN_BACKUP_LOCAL) || perms.contains("BACKUP_LOCAL")
            }
            CAN_BACKUP_CLOUD, "BACKUP_CLOUD" -> {
                perms.contains(CAN_BACKUP_CLOUD) || perms.contains("BACKUP_CLOUD")
            }
            ACTION_EXPORT_EXCEL, ACTION_EXPORT_PDF -> {
                val hasGranularExport = perms.contains(ACTION_EXPORT_EXCEL) || perms.contains(ACTION_EXPORT_PDF)
                perms.contains(CAN_EXPORT_REPORTS) || perms.contains("EXPORT") ||
                    if (hasGranularExport) perms.contains(action) else perms.contains(ACTION_EXPORT)
            }
            ACTION_EXPORT, CAN_EXPORT_REPORTS, "EXPORT" -> {
                perms.contains(CAN_EXPORT_REPORTS) || perms.contains("EXPORT") ||
                    perms.contains(ACTION_EXPORT) || perms.contains(ACTION_EXPORT_EXCEL) || perms.contains(ACTION_EXPORT_PDF)
            }
            else -> perms.contains(action)
        }
    }

    fun hasPermission(permissionKey: String): Boolean {
        if (isSuperAdmin()) return true
        return permissions.contains(permissionKey) || hasActionPermission(permissionKey) || canAccessScreen(permissionKey)
    }

    fun canImportExcel(): Boolean = hasActionPermission(CAN_IMPORT_EXCEL)

    fun canExportReports(): Boolean = hasActionPermission(CAN_EXPORT_REPORTS)

    fun canBackupLocal(): Boolean = hasActionPermission(CAN_BACKUP_LOCAL)

    fun canBackupCloud(): Boolean = hasActionPermission(CAN_BACKUP_CLOUD)

    fun canExportExcel(): Boolean = hasActionPermission(ACTION_EXPORT_EXCEL)

    fun canExportPdf(): Boolean = hasActionPermission(ACTION_EXPORT_PDF)

    fun canManageWarehousesDef(): Boolean = hasActionPermission(CAN_WAREHOUSE_MANAGE_DEF)

    fun canRecordWarehouseMovements(): Boolean = hasActionPermission(CAN_WAREHOUSE_MOVEMENTS)

    fun canManageWarehouseClients3pl(): Boolean = hasActionPermission(CAN_WAREHOUSE_CLIENTS_3PL)

    fun canManageWarehouseFinance(): Boolean = hasActionPermission(CAN_WAREHOUSE_FINANCE)

    fun canPerformWarehouseAudit(): Boolean = hasActionPermission(CAN_WAREHOUSE_AUDIT)

    fun canExportWarehouseReports(): Boolean = hasActionPermission(CAN_WAREHOUSE_EXPORT_REPORTS)

    /**
     * هل المستخدم مقيد حصرياً بوحدة المخازن فقط (شاشة المخازن و/أو تقارير المخازن التفصيلية).
     */
    fun isWarehouseOnlyUser(user: UserEntity? = _currentUser.value): Boolean {
        if (user == null || isSuperAdminUser(user)) return false
        val screens = extractUserScreenKeys(user)
        return screens.isNotEmpty() && screens.all {
            it == SCREEN_WAREHOUSE_ERP || it == SCREEN_WAREHOUSE_REPORTS
        }
    }

    /**
     * يحدد شاشة البداية الافتراضية للمستخدم فور تسجيل الدخول:
     * - أمين المخزن المقيد بشاشة المخازن فقط يفتح مباشرة على شاشة المخازن.
     * - من لا يملك صلاحية لوحة القيادة يُوجَّه تلقائياً لأول شاشة مسموحة له.
     */
    fun getDefaultStartRoute(user: UserEntity? = _currentUser.value): String {
        if (user == null) return "login"
        if (isSuperAdminUser(user)) return SCREEN_DASHBOARD
        val screens = extractUserScreenKeys(user)
        if (screens.isNotEmpty() && screens.all { it == SCREEN_WAREHOUSE_ERP || it == SCREEN_WAREHOUSE_REPORTS }) {
            return if (screens.contains(SCREEN_WAREHOUSE_ERP)) SCREEN_WAREHOUSE_ERP else SCREEN_WAREHOUSE_REPORTS
        }
        if (screens.contains(SCREEN_DASHBOARD)) {
            return SCREEN_DASHBOARD
        }
        val orderedRoutes = listOf(
            SCREEN_WAREHOUSE_ERP to "warehouse_erp",
            SCREEN_WAREHOUSE_REPORTS to "warehouse_dynamic_reports",
            SCREEN_FAMILIES to "families",
            SCREEN_DELIVERY to "delivery",
            SCREEN_NOMINATION to "nomination",
            SCREEN_PROJECTS to "projects",
            SCREEN_GEOGRAPHIC to "geographic_distribution",
            SCREEN_REPORTS to "reports",
            SCREEN_EXECUTIVE_REPORTS to "executive_reports",
            SCREEN_DYNAMIC_REPORTS to "dynamic_report_export",
            SCREEN_INTEGRITY_AUDITOR to "household_integrity_auditor",
            SCREEN_CIVIL_REGISTRY to "civil_registry_lookup",
            SCREEN_EXCEL_MATCHING to "excel_matching",
            SCREEN_EXCEL to "excel_import_export",
            SCREEN_AUDIT_LOG to "audit_log_screen",
            SCREEN_BACKUP to "backup_restore",
            SCREEN_USERS to "accounts_permissions"
        )
        return orderedRoutes.firstOrNull { screens.contains(it.first) }?.second ?: SCREEN_DASHBOARD
    }

    /**
     * التحقق الصارم من صلاحية فتح شاشة معينة.
     * لشاشة «إضافة أسرة جديدة» يُشترط تفعيل شاشة add_family معاً مع صلاحية العملية ACTION_ADD.
     */
    fun canAccessScreen(screenKey: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        if (isAccountValid(user) !is AccountValidationResult.Valid) return false

        val canonicalKey = normalizeScreenKey(screenKey)
        val userScreens = extractUserScreenKeys(user)
        if (!userScreens.contains(canonicalKey)) return false

        if (canonicalKey == SCREEN_ADD_FAMILY) {
            return hasActionPermission(ACTION_ADD)
        }
        return true
    }

    /**
     * هل يملك المستخدم الحالي صلاحية إضافة أسرة جديدة (شاشة add_family + عملية CAN_ADD).
     */
    fun canAddNewFamily(): Boolean {
        if (isSuperAdmin()) return true
        return canAccessScreen(SCREEN_ADD_FAMILY) && hasActionPermission(ACTION_ADD)
    }

    fun extractUserScreenKeys(user: UserEntity): Set<String> {
        if (isSuperAdminUser(user)) return ALL_SCREEN_KEYS
        val result = linkedSetOf<String>()
        user.screenPermissions
            .map { normalizeScreenKey(it) }
            .filter { it in ALL_SCREEN_KEYS }
            .forEach { result.add(it) }
        user.AllowedScreens.split(",")
            .map { normalizeScreenKey(it) }
            .filter { it in ALL_SCREEN_KEYS }
            .forEach { result.add(it) }
        parsePermissionsString(user.permissions)
            .map { normalizeScreenKey(it) }
            .filter { it in ALL_SCREEN_KEYS }
            .forEach { result.add(it) }
        return result
    }

    /**
     * التحقق من السماح بمحلية معينة وفق العزل الجغرافي (Row-Level Security)
     */
    fun isLocalityAllowed(localityName: String): Boolean {
        if (_currentUser.value == null) return false
        val cleanAllowed = getCleanAllowedLocalities()
        if (cleanAllowed.isEmpty()) {
            return true
        }
        val cleanLoc = localityName.trim()
        if (cleanLoc.isBlank()) return false
        return cleanAllowed.any { it.equals(cleanLoc, ignoreCase = true) }
    }

    /**
     * التحقق من السماح بشعبة معينة وفق العزل الجغرافي
     */
    fun isBranchAllowed(branchName: String): Boolean {
        if (_currentUser.value == null) return false
        val cleanAllowed = getCleanAllowedBranches()
        if (cleanAllowed.isEmpty()) {
            return true
        }
        val cleanBranch = branchName.trim()
        if (cleanBranch.isBlank()) return false
        return cleanAllowed.any { it.equals(cleanBranch, ignoreCase = true) }
    }

    /**
     * التحقق المركب من صلاحية الوصول لأسرة معينة وفق العزل الجغرافي (المحليات + الشعب)
     */
    fun isFamilyAllowed(
        family: FamilyEntity,
        localitiesMap: Map<Int, String> = emptyMap(),
        extraAllowedLocalityIds: List<Int> = emptyList()
    ): Boolean {
        return isFamilyScopeAllowed(
            localityId = family.localityID,
            currentSubArea = family.currentSubArea,
            currentMainArea = family.currentMainArea,
            currentBranch = family.currentBranch,
            localitiesMap = localitiesMap,
            extraAllowedLocalityIds = extraAllowedLocalityIds
        )
    }

    fun isFamilyScopeAllowed(
        localityId: Int,
        currentSubArea: String,
        currentMainArea: String,
        currentBranch: String,
        localitiesMap: Map<Int, String> = emptyMap(),
        extraAllowedLocalityIds: List<Int> = emptyList()
    ): Boolean {
        val user = _currentUser.value ?: return false

        val cleanLocalities = getCleanAllowedLocalities()
        val allowedLocalityIds = buildSet {
            if (user.AllowedLocalityID > 0) add(user.AllowedLocalityID)
            extraAllowedLocalityIds.filter { it > 0 }.forEach { add(it) }
        }

        if (cleanLocalities.isNotEmpty() || allowedLocalityIds.isNotEmpty()) {
            val sub = currentSubArea.trim()
            val main = currentMainArea.trim()
            val mappedLoc = localitiesMap[localityId]?.trim() ?: ""
            val matchesId = allowedLocalityIds.contains(localityId)
            val matchesName = cleanLocalities.any { allowed ->
                (sub.isNotBlank() && allowed.equals(sub, ignoreCase = true)) ||
                (main.isNotBlank() && allowed.equals(main, ignoreCase = true)) ||
                (mappedLoc.isNotBlank() && allowed.equals(mappedLoc, ignoreCase = true))
            }
            if (!matchesId && !matchesName) {
                return false
            }
        }

        val cleanBranches = getCleanAllowedBranches()
        if (cleanBranches.isNotEmpty()) {
            val branch = currentBranch.trim()
            if (branch.isBlank() || cleanBranches.none { it.equals(branch, ignoreCase = true) }) {
                return false
            }
        }

        return true
    }

    /**
     * قائمة المحليات المصرح بها للمستخدم الحالي (فارغة = جميع المحليات)
     */
    fun getAllowedLocalities(): List<String> = getCleanAllowedLocalities()

    fun getCleanAllowedLocalities(): List<String> {
        val user = _currentUser.value ?: return emptyList()
        if (isSuperAdminUser(user)) return emptyList()
        val explicitRegion = user.region.trim()
        val cleaned = user.allowedLocalities.map { it.trim() }.filter { !isAllToken(it) }.distinct()
        if (!isAllToken(explicitRegion)) {
            return (listOf(explicitRegion) + cleaned).distinct()
        }
        if (cleaned.isNotEmpty()) {
            return cleaned
        }
        val groupFallback = user.AllowedGroup.trim()
        return if (!isAllToken(groupFallback)) listOf(groupFallback) else emptyList()
    }

    /**
     * النطاق الجغرافي الفعّال لكاشف التداخل والازدواجية (فارغ = غير مقيد).
     */
    fun getEffectiveAllowedLocalitiesForAudit(): List<String> = getCleanAllowedLocalities()

    fun getEffectiveAllowedLocalityIdForAudit(): Int {
        val user = _currentUser.value ?: return 0
        if (isSuperAdminUser(user)) return 0
        return user.AllowedLocalityID.coerceAtLeast(0)
    }

    fun getEffectiveGeographicScopeDisplay(): String? {
        val user = _currentUser.value ?: return null
        if (isSuperAdminUser(user)) return null
        val scopes = getCleanAllowedLocalities()
        if (scopes.isNotEmpty()) {
            return scopes.joinToString("، ")
        }
        val groupFallback = user.AllowedGroup.trim()
        if (!isAllToken(groupFallback)) {
            return groupFallback
        }
        return null
    }

    /**
     * قائمة الشعب المصرح بها للمستخدم الحالي (فارغة = جميع الشعب)
     */
    fun getAllowedBranches(): List<String> = getCleanAllowedBranches()

    fun getCleanAllowedBranches(): List<String> {
        val user = _currentUser.value ?: return emptyList()
        if (isSuperAdminUser(user)) return emptyList()
        val explicitSubRegion = user.sub_region.trim()
        val cleaned = user.allowedBranches.map { it.trim() }.filter { !isAllToken(it) }.distinct()
        if (!isAllToken(explicitSubRegion)) {
            return (listOf(explicitSubRegion) + cleaned).distinct()
        }
        return if (cleaned.isNotEmpty()) cleaned else emptyList()
    }

    /**
     * عدد تسجيلات الدخول المتبقية
     */
    fun getRemainingLogins(): Int? {
        val user = _currentUser.value ?: return null
        val effectiveMax = if (user.maxLogins > 0) user.maxLogins else user.MaxAllowedLogins
        if (effectiveMax <= 0) return null // غير محدود
        val effectiveCurrent = if (user.maxLogins > 0) user.currentLogins else maxOf(user.currentLogins, user.ConsumedLogins)
        return (effectiveMax - effectiveCurrent).coerceAtLeast(0)
    }

    /**
     * نتيجة التحقق من صلاحية الحساب
     */
    sealed class AccountValidationResult {
        object Valid : AccountValidationResult()
        object NotLoggedIn : AccountValidationResult()
        data class Inactive(val reason: String) : AccountValidationResult()
        data class Locked(val reason: String) : AccountValidationResult()
        data class Expired(val reason: String) : AccountValidationResult()
        data class QuotaExceeded(val reason: String) : AccountValidationResult()

        val isValid: Boolean get() = this is Valid
    }
}

typealias SessionManager = AccessControlManager

