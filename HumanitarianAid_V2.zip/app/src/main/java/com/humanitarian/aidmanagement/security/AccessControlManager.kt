package com.humanitarian.aidmanagement.security

import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * مراقب الصلاحيات المؤسسي ومحرك التحكم في الوصول (Enterprise ABAC & Row-Level Security Engine)
 * يدير التحقق الدقيق من الصلاحيات الإجرائية، العزل الجغرافي، القيود الزمنية، وحدود الجلسات
 */
object AccessControlManager {

    // الأوامر والصلاحيات الإجرائية الدقيقة (Granular Action Permissions)
    const val ACTION_ADD = "CAN_ADD"
    const val ACTION_EDIT = "CAN_EDIT"
    const val ACTION_DELETE = "CAN_DELETE"
    const val ACTION_EXPORT = "CAN_EXPORT"
    const val ACTION_EXPORT_EXCEL = "CAN_EXPORT_EXCEL"
    const val ACTION_EXPORT_PDF = "CAN_EXPORT_PDF"
    const val ACTION_DELIVER = "CAN_DELIVER"
    const val ACTION_NOMINATE = "CAN_NOMINATE"

    val ALL_ACTIONS = listOf(
        ACTION_ADD to "إضافة سجلات جديدة (أسر، أطفال، مشاريع)",
        ACTION_EDIT to "تعديل وتحديث بيانات المواطنين والمشاريع",
        ACTION_DELETE to "حذف السجلات أو تجميدها",
        ACTION_EXPORT to "تصدير البيانات والتقارير (صلاحية التصدير الشاملة)",
        ACTION_EXPORT_EXCEL to "تصدير كشوفات الإكسل (Excel / CSV)",
        ACTION_EXPORT_PDF to "تصدير التقارير الرسمية (PDF)",
        ACTION_DELIVER to "تنفيذ عمليات التسليم والصرف الميداني",
        ACTION_NOMINATE to "تشغيل محرك الترشيح والمفاضلة واعتماد الدفعات"
    )

    // الشاشات المصرح بها (Screen Access Permissions)
    const val SCREEN_DASHBOARD = "dashboard"
    const val SCREEN_FAMILIES = "families"
    const val SCREEN_NOMINATION = "nomination"
    const val SCREEN_DELIVERY = "delivery"
    const val SCREEN_REPORTS = "reports"
    const val SCREEN_EXCEL = "excel_import_export"
    const val SCREEN_USERS = "users"
    const val SCREEN_BACKUP = "backup"

    val ALL_SCREENS = listOf(
        SCREEN_DASHBOARD to "لوحة المؤشرات العامة",
        SCREEN_FAMILIES to "سجل المواطنين والأسر",
        SCREEN_NOMINATION to "ترشيح المستفيدين والمفاضلة",
        SCREEN_DELIVERY to "تسليم وصرف المساعدات",
        SCREEN_REPORTS to "مركز التقارير والإحصائيات",
        SCREEN_EXCEL to "مركز التصدير والاستيراد المتقدم",
        SCREEN_USERS to "إدارة المستخدمين والصلاحيات",
        SCREEN_BACKUP to "النسخ الاحتياطي والأمان"
    )

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    /**
     * تحديث أو تعيين المستخدم المسجل حالياً في النظام
     */
    fun setCurrentUser(user: UserEntity?) {
        _currentUser.value = user
    }

    /**
     * الحصول على المستخدم النشط حالياً
     */
    fun getCurrentUser(): UserEntity? = _currentUser.value

    /**
     * هل يوجد مستخدم مسجل حالياً
     */
    fun isLoggedIn(): Boolean = _currentUser.value != null

    /**
     * هل المستخدم الحالي هو مدير النظام العام (Super Admin)
     */
    fun isSuperAdmin(): Boolean {
        val user = _currentUser.value ?: return false
        return user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true) || user.RoleName == "مدير النظام"
    }

    /**
     * التحقق من صلاحية الحساب (نشط، غير مقفل، غير منتهي الصلاحية، ولم يتجاوز مرات الدخول)
     */
    fun isAccountValid(): AccountValidationResult {
        val user = _currentUser.value ?: return AccountValidationResult.NotLoggedIn

        if (!user.IsActive) {
            return AccountValidationResult.Inactive("تم تعطيل هذا الحساب من قِبل إدارة النظام.")
        }

        if (user.IsLocked) {
            return AccountValidationResult.Locked("الحساب مقفل أمنياً بسبب تجاوز محاولات الدخول.")
        }

        val lockedUntil = user.LockedUntil ?: 0L
        if (lockedUntil > System.currentTimeMillis()) {
            return AccountValidationResult.Locked("الحساب مقفل مؤقتاً حتى نهاية فترة الحظر.")
        }

        // فحص تاريخ انتهاء الحساب
        val expiryTimestamp = user.accountExpiryDate ?: 0L
        if (expiryTimestamp > 0L && System.currentTimeMillis() > expiryTimestamp) {
            return AccountValidationResult.Expired("انتهت صلاحية هذا الحساب الزمني. يرجى مراجعة المسؤول.")
        }

        // فحص رصيد مرات الدخول المتبقية
        if (user.maxLogins > 0 && user.currentLogins >= user.maxLogins) {
            return AccountValidationResult.QuotaExceeded("تم استنفاد الحد الأقصى لمرات الدخول المسموح بها (${user.maxLogins} مرة).")
        }

        return AccountValidationResult.Valid
    }

    /**
     * التحقق من امتلاك أمر إجرائي محدد (CAN_ADD, CAN_EDIT, CAN_DELETE, CAN_EXPORT_EXCEL, CAN_EXPORT_PDF, ...)
     */
    fun hasActionPermission(action: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        if (isAccountValid() !is AccountValidationResult.Valid) return false
        val perms = user.actionPermissions
        return when (action) {
            ACTION_EXPORT_EXCEL, ACTION_EXPORT_PDF -> {
                val hasGranularExport = perms.contains(ACTION_EXPORT_EXCEL) || perms.contains(ACTION_EXPORT_PDF)
                if (hasGranularExport) perms.contains(action) else perms.contains(ACTION_EXPORT)
            }
            ACTION_EXPORT -> {
                perms.contains(ACTION_EXPORT) || perms.contains(ACTION_EXPORT_EXCEL) || perms.contains(ACTION_EXPORT_PDF)
            }
            else -> perms.contains(action)
        }
    }

    fun canExportExcel(): Boolean = hasActionPermission(ACTION_EXPORT_EXCEL)

    fun canExportPdf(): Boolean = hasActionPermission(ACTION_EXPORT_PDF)

    /**
     * التحقق من صلاحية فتح شاشة معينة
     */
    fun canAccessScreen(screenKey: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        if (isAccountValid() !is AccountValidationResult.Valid) return false

        val key = screenKey.lowercase().trim()
        val inScreenPermissions = user.screenPermissions.any { it.equals(key, ignoreCase = true) }
        val inAllowedScreens = user.AllowedScreens.split(",").map { it.trim().lowercase() }.contains(key)
        return inScreenPermissions || inAllowedScreens
    }

    /**
     * التحقق من السماح بمحلية معينة وفق العزل الجغرافي (Row-Level Security)
     */
    fun isLocalityAllowed(localityName: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        val cleanAllowed = getCleanAllowedLocalities()
        if (cleanAllowed.isEmpty()) {
            return true
        }
        val cleanLoc = localityName.trim()
        return cleanAllowed.any { it.equals(cleanLoc, ignoreCase = true) }
    }

    /**
     * التحقق من السماح بشعبة معينة وفق العزل الجغرافي
     */
    fun isBranchAllowed(branchName: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        if (user.allowedBranches.isEmpty() || user.allowedBranches.contains("*") || user.allowedBranches.contains("الكل")) {
            return true
        }
        val cleanBranch = branchName.trim()
        return user.allowedBranches.any { it.trim().equals(cleanBranch, ignoreCase = true) }
    }

    /**
     * قائمة المحليات المصرح بها للمستخدم الحالي (فارغة = جميع المحليات)
     */
    fun getAllowedLocalities(): List<String> = getCleanAllowedLocalities()

    fun getCleanAllowedLocalities(): List<String> {
        if (isSuperAdmin()) return emptyList()
        val user = _currentUser.value ?: return emptyList()
        val cleaned = user.allowedLocalities.map { it.trim() }.filter { it.isNotBlank() }
        if (cleaned.any { it == "*" || it == "الكل" }) {
            return emptyList()
        }
        return cleaned.distinct()
    }

    /**
     * قائمة الشعب المصرح بها للمستخدم الحالي (فارغة = جميع الشعب)
     */
    fun getAllowedBranches(): List<String> {
        if (isSuperAdmin()) return emptyList()
        val user = _currentUser.value ?: return emptyList()
        if (user.allowedBranches.contains("*") || user.allowedBranches.contains("الكل")) {
            return emptyList()
        }
        return user.allowedBranches
    }

    /**
     * عدد تسجيلات الدخول المتبقية
     */
    fun getRemainingLogins(): Int? {
        val user = _currentUser.value ?: return null
        if (user.maxLogins <= 0) return null // غير محدود
        return (user.maxLogins - user.currentLogins).coerceAtLeast(0)
    }

    /**
     * نتيجة التحقق من صلاحية الحساب
     */
    sealed class AccountValidationResult {
        object Valid : AccountValidationResult()
        object NotLoggedIn : AccountValidationResult()
        data class Inactive(val reason: String) : AccountValidationResult()
        data class Locked(val reason: String) : AccountValidationResult()
        data class Expired(val reason: String) : AccountValidationResult()
        data class QuotaExceeded(val reason: String) : AccountValidationResult()

        val isValid: Boolean get() = this is Valid
    }
}
