package com.humanitarian.aidmanagement.security

import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * مراقب الصلاحيات المؤسسي ومحرك التحكم في الوصول (Enterprise ABAC & Row-Level Security Engine)
 * يدير التحقق الدقيق من الصلاحيات الإجرائية، العزل الجغرافي، القيود الزمنية، وحدود الجلسات
 */
object AccessControlManager {

    // الأوامر والصلاحيات الإجرائية الدقيقة (Granular Action Permissions)
    const val ACTION_ADD = "CAN_ADD"
    const val ACTION_EDIT = "CAN_EDIT"
    const val ACTION_DELETE = "CAN_DELETE"
    const val ACTION_EXPORT = "CAN_EXPORT"
    const val ACTION_EXPORT_EXCEL = "CAN_EXPORT_EXCEL"
    const val ACTION_EXPORT_PDF = "CAN_EXPORT_PDF"
    const val ACTION_DELIVER = "CAN_DELIVER"
    const val ACTION_NOMINATE = "CAN_NOMINATE"

    val ALL_ACTIONS = listOf(
        ACTION_ADD to "إضافة سجلات جديدة (أسر، أطفال، مشاريع)",
        ACTION_EDIT to "تعديل وتحديث بيانات المواطنين والمشاريع",
        ACTION_DELETE to "حذف السجلات أو تجميدها",
        ACTION_EXPORT to "تصدير البيانات والتقارير (صلاحية التصدير الشاملة)",
        ACTION_EXPORT_EXCEL to "تصدير كشوفات الإكسل (Excel / CSV)",
        ACTION_EXPORT_PDF to "تصدير التقارير الرسمية (PDF)",
        ACTION_DELIVER to "تنفيذ عمليات التسليم والصرف الميداني",
        ACTION_NOMINATE to "تشغيل محرك الترشيح والمفاضلة واعتماد الدفعات"
    )

    // الشاشات المصرح بها (Screen Access Permissions)
    const val SCREEN_DASHBOARD = "dashboard"
    const val SCREEN_FAMILIES = "families"
    const val SCREEN_NOMINATION = "nomination"
    const val SCREEN_DELIVERY = "delivery"
    const val SCREEN_REPORTS = "reports"
    const val SCREEN_EXCEL = "excel_import_export"
    const val SCREEN_USERS = "users"
    const val SCREEN_BACKUP = "backup"

    val ALL_SCREENS = listOf(
        SCREEN_DASHBOARD to "لوحة المؤشرات العامة",
        SCREEN_FAMILIES to "سجل المواطنين والأسر",
        SCREEN_NOMINATION to "ترشيح المستفيدين والمفاضلة",
        SCREEN_DELIVERY to "تسليم وصرف المساعدات",
        SCREEN_REPORTS to "مركز التقارير والإحصائيات",
        SCREEN_EXCEL to "مركز التصدير والاستيراد المتقدم",
        SCREEN_USERS to "إدارة المستخدمين والصلاحيات",
        SCREEN_BACKUP to "النسخ الاحتياطي والأمان"
    )

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    /**
     * تحديث أو تعيين المستخدم المسجل حالياً في النظام
     */
    fun setCurrentUser(user: UserEntity?) {
        _currentUser.value = user
    }

    /**
     * الحصول على المستخدم النشط حالياً
     */
    fun getCurrentUser(): UserEntity? = _currentUser.value

    /**
     * هل يوجد مستخدم مسجل حالياً
     */
    fun isLoggedIn(): Boolean = _currentUser.value != null

    /**
     * هل المستخدم الحالي هو مدير النظام العام (Super Admin)
     */
    fun isSuperAdmin(): Boolean {
        val user = _currentUser.value ?: return false
        return user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true) || user.RoleName == "مدير النظام"
    }

    /**
     * التحقق من صلاحية الحساب (نشط، غير مقفل، غير منتهي الصلاحية، ولم يتجاوز مرات الدخول)
     */
    fun isAccountValid(): AccountValidationResult {
        val user = _currentUser.value ?: return AccountValidationResult.NotLoggedIn

        if (!user.IsActive) {
            return AccountValidationResult.Inactive("تم تعطيل هذا الحساب من قِبل إدارة النظام.")
        }

        if (user.IsLocked) {
            return AccountValidationResult.Locked("الحساب مقفل أمنياً بسبب تجاوز محاولات الدخول.")
        }

        val lockedUntil = user.LockedUntil ?: 0L
        if (lockedUntil > System.currentTimeMillis()) {
            return AccountValidationResult.Locked("الحساب مقفل مؤقتاً حتى نهاية فترة الحظر.")
        }

        // فحص تاريخ انتهاء الحساب
        val accountExpiryTimestamp = user.accountExpiryDate ?: 0L
        if (accountExpiryTimestamp > 0L && System.currentTimeMillis() >= accountExpiryTimestamp) {
            return AccountValidationResult.Expired("انتهت صلاحية هذا الحساب الزمني. يرجى مراجعة المسؤول.")
        }

        // فحص رصيد مرات الدخول للجلسة النشطة (بعد احتساب الدخول الحالي في LoginViewModel)
        val maxAllowedLogins = if (user.maxLogins > 0) user.maxLogins else user.MaxAllowedLogins
        val consumedLogins = if (user.maxLogins > 0) user.currentLogins else maxOf(user.currentLogins, user.ConsumedLogins)
        if (maxAllowedLogins > 0 && consumedLogins > maxAllowedLogins) {
            return AccountValidationResult.QuotaExceeded("تم استنفاد الحد الأقصى لمرات الدخول المسموح بها ($maxAllowedLogins مرة).")
        }

        return AccountValidationResult.Valid
    }

    /**
     * التحقق من امتلاك أمر إجرائي محدد (CAN_ADD, CAN_EDIT, CAN_DELETE, CAN_EXPORT_EXCEL, CAN_EXPORT_PDF, ...)
     */
    fun hasActionPermission(action: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        if (isAccountValid() !is AccountValidationResult.Valid) return false
        val perms = user.actionPermissions
        return when (action) {
            ACTION_EXPORT_EXCEL, ACTION_EXPORT_PDF -> {
                val hasGranularExport = perms.contains(ACTION_EXPORT_EXCEL) || perms.contains(ACTION_EXPORT_PDF)
                if (hasGranularExport) perms.contains(action) else perms.contains(ACTION_EXPORT)
            }
            ACTION_EXPORT -> {
                perms.contains(ACTION_EXPORT) || perms.contains(ACTION_EXPORT_EXCEL) || perms.contains(ACTION_EXPORT_PDF)
            }
            else -> perms.contains(action)
        }
    }

    fun canExportExcel(): Boolean = hasActionPermission(ACTION_EXPORT_EXCEL)

    fun canExportPdf(): Boolean = hasActionPermission(ACTION_EXPORT_PDF)

    /**
     * التحقق من صلاحية فتح شاشة معينة
     */
    fun canAccessScreen(screenKey: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        if (isAccountValid() !is AccountValidationResult.Valid) return false

        val key = screenKey.lowercase().trim()
        val inScreenPermissions = user.screenPermissions.any { it.equals(key, ignoreCase = true) }
        val inAllowedScreens = user.AllowedScreens.split(",").map { it.trim().lowercase() }.contains(key)
        return inScreenPermissions || inAllowedScreens
    }

    /**
     * التحقق من السماح بمحلية معينة وفق العزل الجغرافي (Row-Level Security)
     */
    fun isLocalityAllowed(localityName: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        val cleanAllowed = getCleanAllowedLocalities()
        if (cleanAllowed.isEmpty()) {
            return true
        }
        val cleanLoc = localityName.trim()
        if (cleanLoc.isBlank()) return false
        return cleanAllowed.any { it.equals(cleanLoc, ignoreCase = true) }
    }

    /**
     * التحقق من السماح بشعبة معينة وفق العزل الجغرافي
     */
    fun isBranchAllowed(branchName: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        val cleanAllowed = getCleanAllowedBranches()
        if (cleanAllowed.isEmpty()) {
            return true
        }
        val cleanBranch = branchName.trim()
        if (cleanBranch.isBlank()) return false
        return cleanAllowed.any { it.equals(cleanBranch, ignoreCase = true) }
    }

    /**
     * التحقق المركب من صلاحية الوصول لأسرة معينة وفق العزل الجغرافي (المحليات + الشعب)
     */
    fun isFamilyAllowed(
        family: FamilyEntity,
        localitiesMap: Map<Int, String> = emptyMap(),
        extraAllowedLocalityIds: List<Int> = emptyList()
    ): Boolean {
        return isFamilyScopeAllowed(
            localityId = family.localityID,
            currentSubArea = family.currentSubArea,
            currentMainArea = family.currentMainArea,
            currentBranch = family.currentBranch,
            localitiesMap = localitiesMap,
            extraAllowedLocalityIds = extraAllowedLocalityIds
        )
    }

    fun isFamilyScopeAllowed(
        localityId: Int,
        currentSubArea: String,
        currentMainArea: String,
        currentBranch: String,
        localitiesMap: Map<Int, String> = emptyMap(),
        extraAllowedLocalityIds: List<Int> = emptyList()
    ): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false

        val cleanLocalities = getCleanAllowedLocalities()
        val allowedLocalityIds = buildSet {
            if (user.AllowedLocalityID > 0) add(user.AllowedLocalityID)
            extraAllowedLocalityIds.filter { it > 0 }.forEach { add(it) }
        }

        if (cleanLocalities.isNotEmpty() || allowedLocalityIds.isNotEmpty()) {
            val sub = currentSubArea.trim()
            val main = currentMainArea.trim()
            val mappedLoc = localitiesMap[localityId]?.trim() ?: ""
            val matchesId = allowedLocalityIds.contains(localityId)
            val matchesName = cleanLocalities.any { allowed ->
                (sub.isNotBlank() && allowed.equals(sub, ignoreCase = true)) ||
                (main.isNotBlank() && allowed.equals(main, ignoreCase = true)) ||
                (mappedLoc.isNotBlank() && allowed.equals(mappedLoc, ignoreCase = true))
            }
            if (!matchesId && !matchesName) {
                return false
            }
        }

        val cleanBranches = getCleanAllowedBranches()
        if (cleanBranches.isNotEmpty()) {
            val branch = currentBranch.trim()
            if (branch.isBlank() || cleanBranches.none { it.equals(branch, ignoreCase = true) }) {
                return false
            }
        }

        return true
    }

    /**
     * قائمة المحليات المصرح بها للمستخدم الحالي (فارغة = جميع المحليات)
     */
    fun getAllowedLocalities(): List<String> = getCleanAllowedLocalities()

    fun getCleanAllowedLocalities(): List<String> {
        if (isSuperAdmin()) return emptyList()
        val user = _currentUser.value ?: return emptyList()
        val cleaned = user.allowedLocalities.map { it.trim() }.filter { it.isNotBlank() }
        if (cleaned.any { it == "*" || it == "الكل" }) {
            return emptyList()
        }
        return cleaned.distinct()
    }

    /**
     * قائمة الشعب المصرح بها للمستخدم الحالي (فارغة = جميع الشعب)
     */
    fun getAllowedBranches(): List<String> = getCleanAllowedBranches()

    fun getCleanAllowedBranches(): List<String> {
        if (isSuperAdmin()) return emptyList()
        val user = _currentUser.value ?: return emptyList()
        val cleaned = user.allowedBranches.map { it.trim() }.filter { it.isNotBlank() }
        if (cleaned.any { it == "*" || it == "الكل" }) {
            return emptyList()
        }
        return cleaned.distinct()
    }

    /**
     * عدد تسجيلات الدخول المتبقية
     */
    fun getRemainingLogins(): Int? {
        val user = _currentUser.value ?: return null
        val effectiveMax = if (user.maxLogins > 0) user.maxLogins else user.MaxAllowedLogins
        if (effectiveMax <= 0) return null // غير محدود
        val effectiveCurrent = if (user.maxLogins > 0) user.currentLogins else maxOf(user.currentLogins, user.ConsumedLogins)
        return (effectiveMax - effectiveCurrent).coerceAtLeast(0)
    }

    /**
     * نتيجة التحقق من صلاحية الحساب
     */
    sealed class AccountValidationResult {
        object Valid : AccountValidationResult()
        object NotLoggedIn : AccountValidationResult()
        data class Inactive(val reason: String) : AccountValidationResult()
        data class Locked(val reason: String) : AccountValidationResult()
        data class Expired(val reason: String) : AccountValidationResult()
        data class QuotaExceeded(val reason: String) : AccountValidationResult()

        val isValid: Boolean get() = this is Valid
    }
}
