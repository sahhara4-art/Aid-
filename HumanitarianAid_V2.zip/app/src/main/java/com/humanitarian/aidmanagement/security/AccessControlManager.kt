package com.humanitarian.aidmanagement.security

import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * مراقب الصلاحيات المؤسسي ومحرك التحكم في الوصول (Enterprise ABAC & Row-Level Security Engine)
 * يدير التحقق الدقيق من الصلاحيات الإجرائية، العزل الجغرافي، القيود الزمنية، وحدود الجلسات
 */
object AccessControlManager {

    // الأوامر والصلاحيات الإجرائية الدقيقة (Granular Action & UI Permissions)
    const val CAN_MANAGE_USERS = "CAN_MANAGE_USERS"
    const val CAN_VIEW_HOME_CARDS = "CAN_VIEW_HOME_CARDS"
    const val CAN_IMPORT_EXCEL = "CAN_IMPORT_EXCEL"
    const val CAN_EXPORT_REPORTS = "CAN_EXPORT_REPORTS"
    const val CAN_ACCESS_BI_DASHBOARD = "CAN_ACCESS_BI_DASHBOARD"
    const val CAN_VERIFY_IDS = "CAN_VERIFY_IDS"
    const val CAN_RUN_FILTRATION = "CAN_RUN_FILTRATION"
    const val CAN_MANAGE_FAMILIES = "CAN_MANAGE_FAMILIES"
    const val CAN_DELIVER_AID = "CAN_DELIVER_AID"
    const val CAN_BACKUP_CLOUD = "CAN_BACKUP_CLOUD"
    const val CAN_BACKUP_LOCAL = "CAN_BACKUP_LOCAL"

    const val ACTION_ADD = "CAN_ADD"
    const val ACTION_EDIT = "CAN_EDIT"
    const val ACTION_DELETE = "CAN_DELETE"
    const val ACTION_EXPORT = "CAN_EXPORT"
    const val ACTION_EXPORT_EXCEL = "CAN_EXPORT_EXCEL"
    const val ACTION_EXPORT_PDF = "CAN_EXPORT_PDF"
    const val ACTION_DELIVER = "CAN_DELIVER"
    const val ACTION_NOMINATE = "CAN_NOMINATE"

    // صلاحيات إضافية متوافقة مع الشاشات الميدانية
    const val CAN_VIEW_REPORTS = "CAN_VIEW_REPORTS"
    const val CAN_VIEW_GEOGRAPHIC = "CAN_VIEW_GEOGRAPHIC"
    const val CAN_MANAGE_PROJECTS = "CAN_MANAGE_PROJECTS"

    // أسماء اختصارية متوافقة (Aliases)
    const val CAN_ADD = ACTION_ADD
    const val CAN_EDIT = ACTION_EDIT
    const val CAN_DELETE = ACTION_DELETE
    const val CAN_EXPORT = ACTION_EXPORT
    const val CAN_EXPORT_EXCEL = ACTION_EXPORT_EXCEL
    const val CAN_EXPORT_PDF = ACTION_EXPORT_PDF
    const val CAN_DELIVER = ACTION_DELIVER
    const val CAN_NOMINATE = ACTION_NOMINATE

    val ALL_ACTIONS = listOf(
        CAN_MANAGE_USERS to "إدارة حسابات المستخدمين والصلاحيات",
        CAN_VIEW_HOME_CARDS to "عرض بطاقات ومؤشرات الشاشة الرئيسية",
        CAN_IMPORT_EXCEL to "استيراد ملفات إكسل وتنزيل القوالب",
        CAN_EXPORT_REPORTS to "تصدير التقارير وكشوفات المشاريع (Excel / PDF)",
        CAN_ACCESS_BI_DASHBOARD to "الوصول للوحة التقارير والتحليلات الذكية (BI)",
        CAN_VERIFY_IDS to "أداة فحص ومطابقة كشوفات الهويات",
        CAN_RUN_FILTRATION to "تشغيل محرك الترشيح والفرز والمفاضلة",
        CAN_MANAGE_FAMILIES to "إدارة وعرض سجل الأسر والمستفيدين",
        CAN_DELIVER_AID to "تنفيذ عمليات تسليم وصرف المساعدات الميدانية",
        CAN_BACKUP_CLOUD to "النسخ الاحتياطي والاستعادة السحابية (Google Drive)",
        CAN_BACKUP_LOCAL to "النسخ الاحتياطي والاستعادة المحلية (.db / JSON / SQL)",
        CAN_VIEW_GEOGRAPHIC to "عرض التوزيع الجغرافي للمناطق والشعب",
        CAN_MANAGE_PROJECTS to "إدارة ومتابعة المشاريع الإغاثية",
        ACTION_ADD to "إضافة سجلات جديدة (أسر، أطفال، مشاريع)",
        ACTION_EDIT to "تعديل وتحديث بيانات المواطنين والمشاريع",
        ACTION_DELETE to "حذف السجلات أو التراجع عن التسليم",
        ACTION_NOMINATE to "اعتماد وترحيل قوائم المرشحين للمشاريع"
    )

    // الشاشات المصرح بها (Screen Access Permissions)
    const val SCREEN_DASHBOARD = "dashboard"
    const val SCREEN_FAMILIES = "families"
    const val SCREEN_NOMINATION = "nomination"
    const val SCREEN_DELIVERY = "delivery"
    const val SCREEN_REPORTS = "reports"
    const val SCREEN_EXCEL = "excel_import_export"
    const val SCREEN_USERS = "users"
    const val SCREEN_BACKUP = "backup"

    val ALL_SCREENS = listOf(
        SCREEN_DASHBOARD to "لوحة المؤشرات العامة",
        SCREEN_FAMILIES to "سجل المواطنين والأسر",
        SCREEN_NOMINATION to "ترشيح المستفيدين والمفاضلة",
        SCREEN_DELIVERY to "تسليم وصرف المساعدات",
        SCREEN_REPORTS to "مركز التقارير والإحصائيات",
        SCREEN_EXCEL to "مركز التصدير والاستيراد المتقدم",
        SCREEN_USERS to "إدارة المستخدمين والصلاحيات",
        SCREEN_BACKUP to "النسخ الاحتياطي والأمان"
    )

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _permissionsFlow = MutableStateFlow<List<String>>(emptyList())
    val permissionsFlow: StateFlow<List<String>> = _permissionsFlow.asStateFlow()

    private val _assignedSubAreaFlow = MutableStateFlow<String?>(null)
    val assignedSubAreaFlow: StateFlow<String?> = _assignedSubAreaFlow.asStateFlow()

    private val _assignedDivisionsFlow = MutableStateFlow<List<String>>(emptyList())
    val assignedDivisionsFlow: StateFlow<List<String>> = _assignedDivisionsFlow.asStateFlow()

    /**
     * تحديث أو تعيين المستخدم المسجل حالياً في النظام وتحديث تدفقات الصلاحيات والنطاق الجغرافي
     */
    fun setCurrentUser(user: UserEntity?) {
        _currentUser.value = user
        _permissionsFlow.value = computeEffectivePermissions(user)
        _assignedSubAreaFlow.value = computeAssignedSubArea(user)
        _assignedDivisionsFlow.value = computeAssignedDivisions(user)
    }

    /**
     * قائمة الصلاحيات النشطة للمستخدم الحالي (متوافقة مع Zero-Trust RBAC)
     */
    val permissions: List<String>
        get() = computeEffectivePermissions(_currentUser.value)

    /**
     * المنطقة / المحلية الفردية المعينة للمستخدم (تُقفل القوائم عليها؛ أو null إذا كان غير مقيد أو لديه عدة محليات)
     */
    val assignedSubArea: String?
        get() = computeAssignedSubArea(_currentUser.value)

    /**
     * الشعب الميدانية المعينة للمستخدم (فارغة تعني عدم وجود تقييد على الشعب)
     */
    val assignedDivisions: List<String>
        get() = computeAssignedDivisions(_currentUser.value)

    private fun isSuperAdminUser(user: UserEntity?): Boolean {
        if (user == null) return false
        return user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true) || user.RoleName == "مدير النظام"
    }

    private fun computeAssignedSubArea(user: UserEntity?): String? {
        if (user == null || isSuperAdminUser(user)) return null
        val cleaned = user.allowedLocalities.map { it.trim() }.filter { it.isNotBlank() && it != "*" && it != "الكل" }.distinct()
        return if (cleaned.size == 1) cleaned.first() else null
    }

    private fun computeAssignedDivisions(user: UserEntity?): List<String> {
        if (user == null || isSuperAdminUser(user)) return emptyList()
        val cleaned = user.allowedBranches.map { it.trim() }.filter { it.isNotBlank() }
        if (cleaned.any { it == "*" || it == "الكل" }) return emptyList()
        return cleaned.distinct()
    }

    private fun computeEffectivePermissions(user: UserEntity?): List<String> {
        if (user == null) return emptyList()
        if (isSuperAdminUser(user)) {
            return (ALL_ACTIONS.map { it.first } +
                ALL_SCREENS.map { it.first } +
                listOf(ACTION_DELIVER, CAN_VIEW_REPORTS, ACTION_EXPORT, ACTION_EXPORT_EXCEL, ACTION_EXPORT_PDF)
            ).distinct()
        }
        if (isAccountValid(user) !is AccountValidationResult.Valid) return emptyList()

        return user.actionPermissions
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
    }

    /**
     * الحصول على المستخدم النشط حالياً
     */
    fun getCurrentUser(): UserEntity? = _currentUser.value

    /**
     * هل يوجد مستخدم مسجل حالياً
     */
    fun isLoggedIn(): Boolean = _currentUser.value != null

    /**
     * هل المستخدم الحالي هو مدير النظام العام (Super Admin)
     */
    fun isSuperAdmin(): Boolean = isSuperAdminUser(_currentUser.value)

    /**
     * التحقق من صلاحية الحساب (نشط، غير مقفل، غير منتهي الصلاحية، ولم يتجاوز مرات الدخول)
     */
    fun isAccountValid(targetUser: UserEntity? = _currentUser.value): AccountValidationResult {
        val user = targetUser ?: return AccountValidationResult.NotLoggedIn

        if (!user.IsActive) {
            return AccountValidationResult.Inactive("تم تعطيل هذا الحساب من قِبل إدارة النظام.")
        }

        if (user.IsLocked) {
            return AccountValidationResult.Locked("الحساب مقفل أمنياً بسبب تجاوز محاولات الدخول.")
        }

        val lockedUntil = user.LockedUntil ?: 0L
        if (lockedUntil > System.currentTimeMillis()) {
            return AccountValidationResult.Locked("الحساب مقفل مؤقتاً حتى نهاية فترة الحظر.")
        }

        // فحص تاريخ انتهاء الحساب
        val accountExpiryTimestamp = user.accountExpiryDate ?: 0L
        if (accountExpiryTimestamp > 0L && System.currentTimeMillis() >= accountExpiryTimestamp) {
            return AccountValidationResult.Expired("انتهت صلاحية هذا الحساب الزمني. يرجى مراجعة المسؤول.")
        }

        // فحص رصيد مرات الدخول للجلسة النشطة (بعد احتساب الدخول الحالي في LoginViewModel)
        val maxAllowedLogins = if (user.maxLogins > 0) user.maxLogins else user.MaxAllowedLogins
        val consumedLogins = if (user.maxLogins > 0) user.currentLogins else maxOf(user.currentLogins, user.ConsumedLogins)
        if (maxAllowedLogins > 0 && consumedLogins > maxAllowedLogins) {
            return AccountValidationResult.QuotaExceeded("تم استنفاد الحد الأقصى لمرات الدخول المسموح بها ($maxAllowedLogins مرة).")
        }

        // فحص رصيد مرات الدخول الإجمالي التراكمي (Lifetime Login Quota: -1 = غير محدود)
        if (user.totalAllowedLogins != -1 && (user.totalAllowedLogins == 0 || user.totalLoginsUsed > user.totalAllowedLogins)) {
            return AccountValidationResult.QuotaExceeded("لقد استنفدت رصيدك الإجمالي لمرات الدخول المسموحة على هذا النظام. تم قفل الحساب، راجع الإدارة.")
        }

        return AccountValidationResult.Valid
    }

    /**
     * التحقق من امتلاك أمر إجرائي محدد (CAN_ADD, CAN_EDIT, CAN_DELETE, CAN_EXPORT_EXCEL, CAN_EXPORT_PDF, ...)
     */
    fun hasActionPermission(action: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        if (isAccountValid(user) !is AccountValidationResult.Valid) return false
        val perms = user.actionPermissions
        return when (action) {
            ACTION_DELIVER, CAN_DELIVER_AID -> {
                perms.contains(CAN_DELIVER_AID) || perms.contains(ACTION_DELIVER)
            }
            CAN_ACCESS_BI_DASHBOARD, CAN_VIEW_REPORTS -> {
                perms.contains(CAN_ACCESS_BI_DASHBOARD) || perms.contains(CAN_VIEW_REPORTS)
            }
            ACTION_EXPORT_EXCEL, ACTION_EXPORT_PDF -> {
                val hasGranularExport = perms.contains(ACTION_EXPORT_EXCEL) || perms.contains(ACTION_EXPORT_PDF)
                perms.contains(CAN_EXPORT_REPORTS) || if (hasGranularExport) perms.contains(action) else perms.contains(ACTION_EXPORT)
            }
            ACTION_EXPORT, CAN_EXPORT_REPORTS -> {
                perms.contains(CAN_EXPORT_REPORTS) || perms.contains(ACTION_EXPORT) || perms.contains(ACTION_EXPORT_EXCEL) || perms.contains(ACTION_EXPORT_PDF)
            }
            else -> perms.contains(action)
        }
    }

    fun hasPermission(permissionKey: String): Boolean {
        if (isSuperAdmin()) return true
        return permissions.contains(permissionKey) || hasActionPermission(permissionKey)
    }

    fun canExportExcel(): Boolean = hasActionPermission(ACTION_EXPORT_EXCEL)

    fun canExportPdf(): Boolean = hasActionPermission(ACTION_EXPORT_PDF)

    /**
     * التحقق من صلاحية فتح شاشة معينة
     */
    fun canAccessScreen(screenKey: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        if (isAccountValid(user) !is AccountValidationResult.Valid) return false

        val key = screenKey.lowercase().trim()
        val inScreenPermissions = user.screenPermissions.any { it.equals(key, ignoreCase = true) }
        val inAllowedScreens = user.AllowedScreens.split(",").map { it.trim().lowercase() }.contains(key)
        return inScreenPermissions || inAllowedScreens
    }

    /**
     * التحقق من السماح بمحلية معينة وفق العزل الجغرافي (Row-Level Security)
     */
    fun isLocalityAllowed(localityName: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        val cleanAllowed = getCleanAllowedLocalities()
        if (cleanAllowed.isEmpty()) {
            return true
        }
        val cleanLoc = localityName.trim()
        if (cleanLoc.isBlank()) return false
        return cleanAllowed.any { it.equals(cleanLoc, ignoreCase = true) }
    }

    /**
     * التحقق من السماح بشعبة معينة وفق العزل الجغرافي
     */
    fun isBranchAllowed(branchName: String): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false
        val cleanAllowed = getCleanAllowedBranches()
        if (cleanAllowed.isEmpty()) {
            return true
        }
        val cleanBranch = branchName.trim()
        if (cleanBranch.isBlank()) return false
        return cleanAllowed.any { it.equals(cleanBranch, ignoreCase = true) }
    }

    /**
     * التحقق المركب من صلاحية الوصول لأسرة معينة وفق العزل الجغرافي (المحليات + الشعب)
     */
    fun isFamilyAllowed(
        family: FamilyEntity,
        localitiesMap: Map<Int, String> = emptyMap(),
        extraAllowedLocalityIds: List<Int> = emptyList()
    ): Boolean {
        return isFamilyScopeAllowed(
            localityId = family.localityID,
            currentSubArea = family.currentSubArea,
            currentMainArea = family.currentMainArea,
            currentBranch = family.currentBranch,
            localitiesMap = localitiesMap,
            extraAllowedLocalityIds = extraAllowedLocalityIds
        )
    }

    fun isFamilyScopeAllowed(
        localityId: Int,
        currentSubArea: String,
        currentMainArea: String,
        currentBranch: String,
        localitiesMap: Map<Int, String> = emptyMap(),
        extraAllowedLocalityIds: List<Int> = emptyList()
    ): Boolean {
        if (isSuperAdmin()) return true
        val user = _currentUser.value ?: return false

        val cleanLocalities = getCleanAllowedLocalities()
        val allowedLocalityIds = buildSet {
            if (user.AllowedLocalityID > 0) add(user.AllowedLocalityID)
            extraAllowedLocalityIds.filter { it > 0 }.forEach { add(it) }
        }

        if (cleanLocalities.isNotEmpty() || allowedLocalityIds.isNotEmpty()) {
            val sub = currentSubArea.trim()
            val main = currentMainArea.trim()
            val mappedLoc = localitiesMap[localityId]?.trim() ?: ""
            val matchesId = allowedLocalityIds.contains(localityId)
            val matchesName = cleanLocalities.any { allowed ->
                (sub.isNotBlank() && allowed.equals(sub, ignoreCase = true)) ||
                (main.isNotBlank() && allowed.equals(main, ignoreCase = true)) ||
                (mappedLoc.isNotBlank() && allowed.equals(mappedLoc, ignoreCase = true))
            }
            if (!matchesId && !matchesName) {
                return false
            }
        }

        val cleanBranches = getCleanAllowedBranches()
        if (cleanBranches.isNotEmpty()) {
            val branch = currentBranch.trim()
            if (branch.isBlank() || cleanBranches.none { it.equals(branch, ignoreCase = true) }) {
                return false
            }
        }

        return true
    }

    /**
     * قائمة المحليات المصرح بها للمستخدم الحالي (فارغة = جميع المحليات)
     */
    fun getAllowedLocalities(): List<String> = getCleanAllowedLocalities()

    fun getCleanAllowedLocalities(): List<String> {
        if (isSuperAdmin()) return emptyList()
        val user = _currentUser.value ?: return emptyList()
        val cleaned = user.allowedLocalities.map { it.trim() }.filter { it.isNotBlank() }
        if (cleaned.any { it == "*" || it == "الكل" }) {
            return emptyList()
        }
        return cleaned.distinct()
    }

    /**
     * قائمة الشعب المصرح بها للمستخدم الحالي (فارغة = جميع الشعب)
     */
    fun getAllowedBranches(): List<String> = getCleanAllowedBranches()

    fun getCleanAllowedBranches(): List<String> {
        if (isSuperAdmin()) return emptyList()
        val user = _currentUser.value ?: return emptyList()
        val cleaned = user.allowedBranches.map { it.trim() }.filter { it.isNotBlank() }
        if (cleaned.any { it == "*" || it == "الكل" }) {
            return emptyList()
        }
        return cleaned.distinct()
    }

    /**
     * عدد تسجيلات الدخول المتبقية
     */
    fun getRemainingLogins(): Int? {
        val user = _currentUser.value ?: return null
        val effectiveMax = if (user.maxLogins > 0) user.maxLogins else user.MaxAllowedLogins
        if (effectiveMax <= 0) return null // غير محدود
        val effectiveCurrent = if (user.maxLogins > 0) user.currentLogins else maxOf(user.currentLogins, user.ConsumedLogins)
        return (effectiveMax - effectiveCurrent).coerceAtLeast(0)
    }

    /**
     * نتيجة التحقق من صلاحية الحساب
     */
    sealed class AccountValidationResult {
        object Valid : AccountValidationResult()
        object NotLoggedIn : AccountValidationResult()
        data class Inactive(val reason: String) : AccountValidationResult()
        data class Locked(val reason: String) : AccountValidationResult()
        data class Expired(val reason: String) : AccountValidationResult()
        data class QuotaExceeded(val reason: String) : AccountValidationResult()

        val isValid: Boolean get() = this is Valid
    }
}

typealias SessionManager = AccessControlManager

