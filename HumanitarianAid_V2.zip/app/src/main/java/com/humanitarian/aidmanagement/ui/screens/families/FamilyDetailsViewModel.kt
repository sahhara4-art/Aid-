package com.humanitarian.aidmanagement.ui.screens.families

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.dao.DamageTypeBreakdown
import com.humanitarian.aidmanagement.data.local.dao.LocalityFamilyCount
import com.humanitarian.aidmanagement.data.local.dao.SubAreaFamilyCount
import com.humanitarian.aidmanagement.data.local.dao.WarDamageStats
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

/**
 * حالة واجهة المستخدم لشاشة تفاصيل الأسرة (Family Details UI State)
 */
data class FamilyDetailsUiState(
    val family: FamilyEntity? = null,
    val children: List<ChildEntity> = emptyList(),
    val aidRecords: List<AidRecordEntity> = emptyList(),
    val localities: List<LocalityEntity> = emptyList(),
    val localityName: String = "",
    val isAreaAllowed: Boolean = true,
    val canEdit: Boolean = false,
    val canDelete: Boolean = false,
    val isLoading: Boolean = true,
    val errorMessage: String? = null,

    // الحقول الديناميكية للتجميع والإحصاء الجغرافي
    val selectedLocalityId: Int = 1,
    val selectedSubArea: String = "",
    val availableSubAreas: List<String> = emptyList(),
    val localityFamilyCount: Int = 0,
    val subAreaFamilyCount: Int = 0,
    val warDamageStats: WarDamageStats = WarDamageStats(0, 0, 0, 0, 0),
    val damageDistribution: List<DamageTypeBreakdown> = emptyList(),
    val completelyDestroyedCount: Int = 0,
    val allLocalityFamilyCounts: List<LocalityFamilyCount> = emptyList()
)

private sealed interface FamilyLoadResult {
    data object Loading : FamilyLoadResult
    data class Loaded(val family: FamilyEntity?, val error: String? = null) : FamilyLoadResult
}

private data class GeoAggregateState(
    val selectedLocalityId: Int = 1,
    val selectedSubArea: String = "",
    val availableSubAreas: List<String> = emptyList(),
    val localityFamilyCount: Int = 0,
    val subAreaFamilyCount: Int = 0,
    val warDamageStats: WarDamageStats = WarDamageStats(0, 0, 0, 0, 0),
    val damageDistribution: List<DamageTypeBreakdown> = emptyList(),
    val completelyDestroyedCount: Int = 0
)

private data class FamilyMetaBundle(
    val localities: List<LocalityEntity>,
    val allCounts: List<LocalityFamilyCount>,
    val geo: GeoAggregateState,
    val error: String?
)

/**
 * ViewModel لإدارة منطق وتدفقات بيانات شاشة تفاصيل الأسرة
 * - يستخدم flatMapLatest + flowOn(Dispatchers.IO) + WhileSubscribed(5000) لمنع تكدس المراقبين وتسرب الذاكرة
 * - حساب العمر الديناميكي اللحظي من تاريخ الميلاد (date_of_birth)
 * - تحديث منسدل الشعب والمناطق الفرعية وفق المحلية المختارة
 */
class FamilyDetailsViewModel(
    private val repository: AidRepository,
    private val familyId: Long
) : ViewModel() {

    private val _selectedLocalityId = MutableStateFlow<Int?>(null)
    private val _selectedSubArea = MutableStateFlow<String?>(null)
    private val _errorMessage = MutableStateFlow<String?>(null)

    private val familyLoadFlow: Flow<FamilyLoadResult> = repository.getFamilyById(familyId)
        .map<FamilyEntity?, FamilyLoadResult> { FamilyLoadResult.Loaded(it) }
        .catch { e -> emit(FamilyLoadResult.Loaded(null, e.message)) }
        .flowOn(Dispatchers.IO)

    @OptIn(ExperimentalCoroutinesApi::class)
    private val childrenFlow: Flow<List<ChildEntity>> = familyLoadFlow
        .map { (it as? FamilyLoadResult.Loaded)?.family }
        .distinctUntilChangedBy { it?.familyID to it?.nationalID }
        .flatMapLatest { family ->
            when {
                family == null -> flowOf(emptyList())
                family.nationalID.isNotBlank() -> repository.getChildrenByFamily(family.nationalID)
                else -> repository.getChildrenByFamilyId(family.familyID)
            }
        }
        .catch { emit(emptyList()) }
        .flowOn(Dispatchers.IO)

    @OptIn(ExperimentalCoroutinesApi::class)
    private val aidRecordsFlow: Flow<List<AidRecordEntity>> = familyLoadFlow
        .map { (it as? FamilyLoadResult.Loaded)?.family?.familyID }
        .distinctUntilChanged()
        .flatMapLatest { fId ->
            if (fId == null) flowOf(emptyList())
            else repository.getAidRecordsForFamily(fId)
        }
        .catch { emit(emptyList()) }
        .flowOn(Dispatchers.IO)

    private val localitiesFlow: Flow<List<LocalityEntity>> = repository.getLocalities()
        .catch { emit(emptyList()) }
        .flowOn(Dispatchers.IO)

    private val localityCountsFlow: Flow<List<LocalityFamilyCount>> = repository.getFamilyCountForEachLocalityFlow()
        .catch { emit(emptyList()) }
        .flowOn(Dispatchers.IO)

    @OptIn(ExperimentalCoroutinesApi::class)
    private val geoStatsFlow: Flow<GeoAggregateState> = combine(
        familyLoadFlow.map { (it as? FamilyLoadResult.Loaded)?.family },
        _selectedLocalityId,
        _selectedSubArea
    ) { fam, locOverride, subOverride ->
        val locId = locOverride ?: fam?.localityID?.takeIf { it != 0 } ?: 1
        val subArea = subOverride ?: fam?.currentSubArea ?: ""
        locId to subArea
    }
        .distinctUntilChanged()
        .flatMapLatest { (localityId, subArea) ->
            flow {
                val stats = computeDynamicGeoStats(localityId, subArea)
                emit(stats)
            }
        }
        .flowOn(Dispatchers.IO)

    private val coreBundleFlow = combine(familyLoadFlow, childrenFlow, aidRecordsFlow) { famRes, children, records ->
        Triple(famRes, children, records)
    }

    private val metaBundleFlow = combine(localitiesFlow, localityCountsFlow, geoStatsFlow, _errorMessage) { locs, counts, geo, err ->
        FamilyMetaBundle(locs, counts, geo, err)
    }

    val uiState: StateFlow<FamilyDetailsUiState> = combine(coreBundleFlow, metaBundleFlow) { (famRes, children, records), meta ->
        when (famRes) {
            is FamilyLoadResult.Loading -> FamilyDetailsUiState(
                localities = meta.localities,
                allLocalityFamilyCounts = meta.allCounts,
                isLoading = true,
                errorMessage = meta.error
            )
            is FamilyLoadResult.Loaded -> {
                val family = famRes.family
                if (family == null) {
                    FamilyDetailsUiState(
                        family = null,
                        localities = meta.localities,
                        allLocalityFamilyCounts = meta.allCounts,
                        isLoading = false,
                        errorMessage = meta.error ?: famRes.error
                    )
                } else {
                    val isAllowed = repository.canUserViewSubArea(family.currentSubArea)
                    val canEdit = repository.canUserEditFamily(family)
                    val canDelete = repository.canUserDeleteFamily(family)
                    val locName = family.currentSubArea.ifBlank {
                        meta.localities.find { it.LocalityID == family.localityID }?.LocalityName
                            ?: "محلية #${family.localityID}"
                    }
                    val effectiveLocCount = if (meta.geo.localityFamilyCount > 0) {
                        meta.geo.localityFamilyCount
                    } else {
                        meta.allCounts.find { it.localityID == meta.geo.selectedLocalityId }?.familyCount ?: 0
                    }

                    FamilyDetailsUiState(
                        family = family,
                        children = children,
                        aidRecords = records,
                        localities = meta.localities,
                        localityName = locName,
                        isAreaAllowed = isAllowed,
                        canEdit = canEdit,
                        canDelete = canDelete,
                        isLoading = false,
                        errorMessage = meta.error ?: famRes.error,
                        selectedLocalityId = meta.geo.selectedLocalityId,
                        selectedSubArea = meta.geo.selectedSubArea,
                        availableSubAreas = meta.geo.availableSubAreas,
                        localityFamilyCount = effectiveLocCount,
                        subAreaFamilyCount = meta.geo.subAreaFamilyCount,
                        warDamageStats = meta.geo.warDamageStats,
                        damageDistribution = meta.geo.damageDistribution,
                        completelyDestroyedCount = meta.geo.completelyDestroyedCount,
                        allLocalityFamilyCounts = meta.allCounts
                    )
                }
            }
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FamilyDetailsUiState())

    /**
     * حساب دقيق وحصري للعمر الحالي ديناميكياً من حقل date_of_birth
     * بصيغة (YYYY-MM-DD أو YYYY/MM/DD) بدون استخدام أي قيمة عمر ثابتة ومخزنة
     * يُرجع null إذا كان تاريخ الميلاد فارغاً أو غير صالح لإخفاء المكون بالكامل
     */
    fun calculateAge(dobString: String?): Int? {
        if (dobString.isNullOrBlank()) return null
        return try {
            val parts = dobString.trim().split("-", "/")
            if (parts.size >= 3) {
                val year = parts[0].toIntOrNull() ?: return null
                val month = parts[1].toIntOrNull() ?: 1
                val day = parts[2].toIntOrNull() ?: 1
                val birthCal = Calendar.getInstance().apply { set(year, month - 1, day) }
                val today = Calendar.getInstance()
                var age = today.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR)
                if (today.get(Calendar.DAY_OF_YEAR) < birthCal.get(Calendar.DAY_OF_YEAR)) {
                    age--
                }
                age.coerceAtLeast(0)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * تحديث الشعب المتاحة والإحصائيات التجميعية عند تغيير اختيار المحلية
     */
    fun onLocalitySelected(localityId: Int) {
        _selectedLocalityId.value = localityId
        _selectedSubArea.value = ""
    }

    /**
     * تحديث الإحصائيات التجميعية عند اختيار شعبة معينة
     */
    fun onSubAreaSelected(subArea: String) {
        _selectedSubArea.value = subArea
    }

    private suspend fun computeDynamicGeoStats(localityId: Int, subArea: String): GeoAggregateState = withContext(Dispatchers.IO) {
        try {
            val subAreas = repository.getSubAreasByLocality(localityId)
            val subAreaCounts = repository.getFamilyCountForEachSubArea(localityId)
            val selectedSubCount = if (subArea.isNotBlank()) {
                subAreaCounts.find { it.subArea == subArea }?.familyCount ?: 0
            } else {
                0
            }
            val allLocCounts = repository.getFamilyCountForEachLocality()
            val currentLocCount = allLocCounts.find { it.localityID == localityId }?.familyCount ?: 0

            val targetSub = if (subArea.isNotBlank()) subArea else null
            val warStats = repository.getWarDamageStatsFiltered(localityId, targetSub)
            val destroyedCount = repository.getCompletelyDestroyedCountFiltered(localityId, targetSub)
            val damageBreakdown = repository.getWarDamageDistributionFiltered(localityId, targetSub)

            GeoAggregateState(
                selectedLocalityId = localityId,
                selectedSubArea = subArea,
                availableSubAreas = subAreas,
                localityFamilyCount = currentLocCount,
                subAreaFamilyCount = selectedSubCount,
                warDamageStats = warStats,
                damageDistribution = damageBreakdown,
                completelyDestroyedCount = destroyedCount
            )
        } catch (_: Exception) {
            GeoAggregateState(selectedLocalityId = localityId, selectedSubArea = subArea)
        }
    }

    fun updateFamily(updatedFamily: FamilyEntity, onComplete: (Boolean, String?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.updateFamily(updatedFamily)
                withContext(Dispatchers.Main) {
                    onComplete(true, null)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onComplete(false, e.message)
                }
            }
        }
    }

    fun deleteFamily(onComplete: (Boolean, String?) -> Unit) {
        val currentFam = uiState.value.family ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.deleteFamily(currentFam)
                withContext(Dispatchers.Main) {
                    onComplete(true, null)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onComplete(false, e.message)
                }
            }
        }
    }

    fun resetFilters() {
        _selectedLocalityId.value = null
        _selectedSubArea.value = null
        _errorMessage.value = null
    }

    fun clearState() {
        resetFilters()
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    class Factory(
        private val repository: AidRepository,
        private val familyId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return FamilyDetailsViewModel(repository, familyId) as T
        }
    }
}
