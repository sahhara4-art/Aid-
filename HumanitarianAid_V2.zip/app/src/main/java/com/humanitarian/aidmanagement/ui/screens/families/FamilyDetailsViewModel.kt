package com.humanitarian.aidmanagement.ui.screens.families

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class FamilyDetailsViewModel(
    private val repository: AidRepository,
    private val familyId: Long
) : ViewModel() {

    private val _localities = MutableStateFlow<List<LocalityEntity>>(emptyList())
    val localities: StateFlow<List<LocalityEntity>> = _localities.asStateFlow()

    init {
        loadLocalities()
    }

    private fun loadLocalities() {
        viewModelScope.launch {
            // تم تصحيح اسم الدالة هنا ليتطابق مع الـ Repository (getAllLocalitiesSync بدلاً من الاسم القديم)
            _localities.value = repository.getAllLocalitiesSync()
        }
    }

    class Factory(
        private val repository: AidRepository,
        private val familyId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(FamilyDetailsViewModel::class.java)) {
                return FamilyDetailsViewModel(repository, familyId) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
