package com.humanitarian.aidmanagement.sync

import android.util.Log
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * FirebaseSyncListener - غلاف توافقي خفيف (Lightweight Compatibility Wrapper)
 *
 * تم إيقاف كافة المستمعات المفتوحة في الخلفية (addChildEventListener / addSnapshotListener)
 * وتوجيه الاستدعاءات بالكامل إلى المسار التفاضلي الموحّد والمجزأ في FirestoreSyncManager
 * (دفعات 250 وثيقة عبر .get() داخل Dispatchers.IO) لمنع استنزاف الذاكرة العشوائية (OOM).
 */
class FirebaseSyncListener(
    private val database: AidDatabase,
    private val firebaseSyncManager: FirebaseSyncManager
) {
    private val unifiedSyncManager: FirestoreSyncManager
        get() = firebaseSyncManager.getUnifiedFirestoreSyncManager()

    val isListening: StateFlow<Boolean>
        get() = unifiedSyncManager.isListening

    private val _lastMergedDelta = MutableStateFlow<SyncDelta?>(null)
    val lastMergedDelta: StateFlow<SyncDelta?> = _lastMergedDelta.asStateFlow()

    private val _recentMergedDeltas = MutableStateFlow<List<SyncDelta>>(emptyList())
    val recentMergedDeltas: StateFlow<List<SyncDelta>> = _recentMergedDeltas.asStateFlow()

    val totalMergedCount: StateFlow<Int>
        get() = unifiedSyncManager.totalMergedCount

    companion object {
        private const val TAG = "FirebaseSyncListener"
    }

    /**
     * تشغيل المزامنة التفاضلية المجزأة عبر FirestoreSyncManager بدلاً من أي مستمع مفتوح في الخلفية
     */
    fun startListening(targetLocalityId: Int = 0) {
        unifiedSyncManager.startRealtimeListener(database, targetLocalityId)
        Log.i(TAG, "Delegated sync listening for locality=$targetLocalityId to paginated FirestoreSyncManager.")
    }

    /**
     * إيقاف حلقة المزامنة التفاضلية وتفريغ أي مراجع نشطة
     */
    fun stopListening() {
        unifiedSyncManager.stopRealtimeListener()
        Log.i(TAG, "Delegated stopListening() to unified FirestoreSyncManager.")
    }
}
