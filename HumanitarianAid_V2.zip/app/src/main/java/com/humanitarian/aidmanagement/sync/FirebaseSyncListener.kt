package com.humanitarian.aidmanagement.sync

interface FirebaseSyncListener {
    fun onSyncStarted()
    fun onSyncProgress(current: Int, total: Int)
    fun onSyncCompleted(successCount: Int, errorCount: Int)
    fun onSyncFailed(errorMessage: String)
}
