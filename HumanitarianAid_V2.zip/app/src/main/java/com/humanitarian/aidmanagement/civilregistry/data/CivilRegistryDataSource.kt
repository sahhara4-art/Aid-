package com.humanitarian.aidmanagement.civilregistry.data

import android.os.CancellationSignal
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryChildRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryDbStatus
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchPage
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery

/**
 * واجهة مصدر بيانات السجل المدني للقراءة فقط (Read-Only Data Source Adapter Contract)
 *
 * تفصل طبقة البيانات بالكامل عن واجهة البحث ومنطق الترحيل والحفظ، مما يتيح:
 * 1. التشغيل الفوري ببيانات تجريبية واقعية (SampleCivilRegistryDataSource).
 * 2. الاستبدال أو الربط المباشر بقاعدة civil_registry.db الفعلية (أرباب الأسر + جدول الأبناء children_registry)
 *    عبر SqliteCivilRegistryDataSource دون أي تعديل في الواجهة أو صفحة الإضافة أو شاشة الحفظ.
 */
interface CivilRegistryDataSource {
    suspend fun ensureDatabaseReady(): CivilRegistryDbStatus

    suspend fun search(
        query: CivilRegistrySearchQuery,
        offset: Int = 0,
        pageSize: Int = CivilRegistryReadOnlyDataSource.DEFAULT_PAGE_SIZE,
        cancellationSignal: CancellationSignal? = null
    ): CivilRegistrySearchPage

    suspend fun getChildrenForParent(
        parentId: String,
        minBirthDateIso: String? = null,
        maxBirthDateIso: String? = null,
        cancellationSignal: CancellationSignal? = null
    ): List<CivilRegistryChildRecord>

    suspend fun hasChildrenRegistryTable(): Boolean

    fun close()
}
