package com.humanitarian.aidmanagement.util

import java.time.LocalDate
import java.time.Period
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * أداة موحدة لحساب العمر التقويمي الدقيق (سنة، شهر، يوم) من تاريخ الميلاد
 * وتوليد نطاق تواريخ الميلاد المطابق لفلتر (من عمر إلى عمر) لاستخدامه مع فهارس SQLite.
 */
object ExactAgeUtil {

    private val ISO_DATE_FORMATTER: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US)

    data class CalendarAge(
        val years: Int,
        val months: Int,
        val days: Int
    ) {
        val totalMonthsApprox: Int
            get() = (years * 12) + months
    }

    /**
     * توحيد الأرقام العربية/الفارسية واستخراج تاريخ ISO صالح من الصيغ الشائعة:
     * YYYY-MM-DD ، YYYY/MM/DD ، DD/MM/YYYY ، DD-MM-YYYY
     */
    fun parseBirthDate(raw: String?): LocalDate? {
        if (raw.isNullOrBlank()) return null
        val ascii = normalizeDigits(raw.trim())
            .substringBefore('T')
            .substringBefore(' ')
            .trim()
        if (ascii.isBlank()) return null

        val separator = when {
            ascii.contains('-') -> '-'
            ascii.contains('/') -> '/'
            ascii.contains('.') -> '.'
            else -> return null
        }

        val parts = ascii.split(separator).map { it.trim() }.filter { it.isNotEmpty() }
        if (parts.size != 3) return null

        val p0 = parts[0].toIntOrNull() ?: return null
        val p1 = parts[1].toIntOrNull() ?: return null
        val p2 = parts[2].toIntOrNull() ?: return null

        return try {
            when {
                // YYYY-MM-DD
                parts[0].length == 4 && p0 in 1900..2100 -> LocalDate.of(p0, p1, p2)
                // DD/MM/YYYY
                parts[2].length == 4 && p2 in 1900..2100 -> LocalDate.of(p2, p1, p0)
                else -> null
            }
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * تطبيع تاريخ الميلاد إلى الصيغة القياسية YYYY-MM-DD (أو النص الأصلي عند تعذر التحليل)
     */
    fun normalizeIsoDate(raw: String?): String {
        val parsed = parseBirthDate(raw)
        return parsed?.format(ISO_DATE_FORMATTER) ?: raw?.trim().orEmpty()
    }

    /**
     * حساب العمر التقويمي الدقيق (سنوات، شهور، أيام) باستخدام Period.between
     */
    fun calculateCalendarAge(
        birthDateStr: String?,
        referenceDate: LocalDate = LocalDate.now()
    ): CalendarAge? {
        val birthDate = parseBirthDate(birthDateStr) ?: return null
        if (birthDate.isAfter(referenceDate)) return null
        val period = Period.between(birthDate, referenceDate)
        return CalendarAge(
            years = period.years.coerceAtLeast(0),
            months = period.months.coerceAtLeast(0),
            days = period.days.coerceAtLeast(0)
        )
    }

    /**
     * تنسيق العمر بالعربية الدقيقة مع إخفاء السنوات أو الشهور الصفرية:
     * أمثلة:
     * - "1 سنة 3 شهور 28 يوم"
     * - "6 شهور 12 يوم"
     * - "15 يوم"
     * - "حديث الولادة (0 يوم)"
     */
    fun formatArabicAge(
        birthDateStr: String?,
        referenceDate: LocalDate = LocalDate.now(),
        fallback: String = "تاريخ الميلاد غير صالح"
    ): String {
        val age = calculateCalendarAge(birthDateStr, referenceDate) ?: return fallback
        return formatArabicAge(age)
    }

    fun formatArabicAge(age: CalendarAge): String {
        val parts = mutableListOf<String>()

        if (age.years > 0) {
            val yearLabel = if (age.years in 3..10) "سنوات" else "سنة"
            parts.add("${age.years} $yearLabel")
        }

        if (age.months > 0) {
            val monthLabel = if (age.months in 2..10) "شهور" else "شهر"
            parts.add("${age.months} $monthLabel")
        }

        if (age.days > 0) {
            val dayLabel = if (age.days in 2..10) "أيام" else "يوم"
            parts.add("${age.days} $dayLabel")
        }

        if (parts.isEmpty()) {
            return "حديث الولادة (0 يوم)"
        }

        return parts.joinToString(" ")
    }

    /**
     * تحويل فلتر العمر (من عمر minYears/minMonths إلى عمر maxYears/maxMonths)
     * إلى نطاق تواريخ ميلاد قياسي (minBirthDateIso, maxBirthDateIso) بصيغة YYYY-MM-DD
     * للاستعلام المفهرس المباشر: birth_date BETWEEN minBirthDateIso AND maxBirthDateIso
     *
     * مثال: من عمر 0 سنة 0 شهر إلى 1 سنة 0 شهر ->
     * - الأصغر سناً (0 سنة 0 شهر): birth_date <= today
     * - الأكبر سناً (1 سنة 0 شهر): birth_date >= today - 1 year
     */
    fun computeBirthDateRangeForAgeFilter(
        minYears: Int,
        minMonths: Int,
        maxYears: Int,
        maxMonths: Int,
        referenceDate: LocalDate = LocalDate.now()
    ): Pair<String, String> {
        val safeMinY = minYears.coerceAtLeast(0)
        val safeMinM = minMonths.coerceIn(0, 11)
        val safeMaxY = maxYears.coerceAtLeast(0)
        val safeMaxM = maxMonths.coerceIn(0, 11)

        val dateForMinAge = referenceDate
            .minusYears(safeMinY.toLong())
            .minusMonths(safeMinM.toLong())

        val dateForMaxAge = referenceDate
            .minusYears(safeMaxY.toLong())
            .minusMonths(safeMaxM.toLong())

        val minBirthDate = if (dateForMaxAge.isBefore(dateForMinAge)) dateForMaxAge else dateForMinAge
        val maxBirthDate = if (dateForMaxAge.isBefore(dateForMinAge)) dateForMinAge else dateForMaxAge

        return minBirthDate.format(ISO_DATE_FORMATTER) to maxBirthDate.format(ISO_DATE_FORMATTER)
    }

    private fun normalizeDigits(input: String): String {
        val sb = StringBuilder(input.length)
        for (ch in input) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }
}
