package com.humanitarian.aidmanagement.data.security

import android.content.Context

object DatabaseKeyManager {
    // مفتاح ثابت ومدمج لتشفير القاعدة، يضمن عدم ضياع التشفير بعد مسح بيانات التطبيق
    private val HARDENED_APP_SALT = byteArrayOf(
        0x50, 0x61, 0x6C, 0x65, 0x73, 0x74, 0x69, 0x6E,
        0x65, 0x48, 0x75, 0x6D, 0x61, 0x6E, 0x69, 0x74,
        0x61, 0x72, 0x69, 0x61, 0x6E, 0x41, 0x69, 0x64,
        0x53, 0x65, 0x63, 0x75, 0x72, 0x65, 0x4B, 0x65
    )

    fun getOrCreateDatabaseKey(context: Context): ByteArray {
        // نستخدم المفتاح الثابت دائماً لكي نتمكن من فك تشفير النسخة الاحتياطية عند الاستعادة في تثبيت جديد
        return HARDENED_APP_SALT
    }
}
