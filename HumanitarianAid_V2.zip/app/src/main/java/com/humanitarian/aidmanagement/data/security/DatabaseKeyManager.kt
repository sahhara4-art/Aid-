package com.humanitarian.aidmanagement.data.security

import android.content.Context
import android.content.SharedPreferences
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object DatabaseKeyManager {
    private const val KEY_ALIAS = "HumanitarianAid_DB_MasterKey"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val PREFS_FILE = "secure_db_vault"
    private const val ENCRYPTED_KEY_PREF = "enc_db_passphrase"
    private const val IV_PREF = "enc_db_iv"

    private val HARDENED_APP_SALT = byteArrayOf(
        0x50, 0x61, 0x6C, 0x65, 0x73, 0x74, 0x69, 0x6E,
        0x65, 0x48, 0x75, 0x6D, 0x61, 0x6E, 0x69, 0x74,
        0x61, 0x72, 0x69, 0x61, 0x6E, 0x41, 0x69, 0x64,
        0x53, 0x65, 0x63, 0x75, 0x72, 0x65, 0x4B, 0x65
    )

    fun getOrCreateDatabaseKey(context: Context): ByteArray {
        // 1. التحقق مما إذا كان هناك مفتاح تم استرجاعه من النسخة الاحتياطية
        val restoredKeyFile = java.io.File(context.filesDir, "restored_key.bin")
        if (restoredKeyFile.exists()) {
            val key = restoredKeyFile.readBytes()
            if (key.isNotEmpty()) {
                return key
            }
        }

        // 2. الكود الأصلي: جلب المفتاح من SharedPreferences
        val prefs = context.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
        val encryptedKeyBase64 = prefs.getString(ENCRYPTED_KEY_PREF, null)
        val ivBase64 = prefs.getString(IV_PREF, null)

        if (encryptedKeyBase64 != null && ivBase64 != null) {
            try {
                val decrypted = decryptPassphrase(encryptedKeyBase64, ivBase64)
                if (decrypted != null && decrypted.isNotEmpty()) {
                    return decrypted
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        return try {
            val rawKey = ByteArray(32)
            SecureRandom().nextBytes(rawKey)
            encryptAndSavePassphrase(prefs, rawKey)
            rawKey
        } catch (e: Exception) {
            HARDENED_APP_SALT
        }
    }

    private fun getOrCreateMasterKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (!keyStore.containsAlias(KEY_ALIAS)) {
            val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
            keyGenerator.init(spec)
            return keyGenerator.generateKey()
        }
        return (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    private fun encryptAndSavePassphrase(prefs: SharedPreferences, rawKey: ByteArray) {
        val masterKey = getOrCreateMasterKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, masterKey)
        val iv = cipher.iv
        val encryptedBytes = cipher.doFinal(rawKey)

        prefs.edit()
            .putString(ENCRYPTED_KEY_PREF, Base64.encodeToString(encryptedBytes, Base64.NO_WRAP))
            .putString(IV_PREF, Base64.encodeToString(iv, Base64.NO_WRAP))
            .apply()
    }

    private fun decryptPassphrase(encryptedBase64: String, ivBase64: String): ByteArray? {
        val masterKey = getOrCreateMasterKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val iv = Base64.decode(ivBase64, Base64.NO_WRAP)
        val spec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.DECRYPT_MODE, masterKey, spec)
        val encryptedBytes = Base64.decode(encryptedBase64, Base64.NO_WRAP)
        return cipher.doFinal(encryptedBytes)
    }
}
