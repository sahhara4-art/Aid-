package com.humanitarian.aidmanagement.ui.screens.excel

import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.ExcelParserHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

enum class ExcelTab {
    EXPORT_PERIOD, // تصدير إكسل مع تحديد الفترة
    IMPORT_EXCEL   // رفع واستيراد بيانات إكسل
}

enum class ImportDataType(val label: String, val icon: String) {
    FAMILIES("بيانات الأسر", "👨‍👩‍👧"),
    AID_RECORDS("سجلات المساعدات", "📦"),
    CHILDREN("سجل الأبناء والتابعين", "👶")
}

data class SystemFieldDef(
    val key: String,
    val label: String,
    val isRequired: Boolean = false,
    val description: String = "",
    val autoMatchKeywords: List<String> = emptyList()
)

val familySystemFields = listOf(
    SystemFieldDef("nationalID", "رقم الهوية الوطنية", isRequired = true, "رقم هوية رب الأسرة (9 أرقام)", listOf("nationalID", "national_id", "هوية", "رقم الهوية", "الهوية", "id", "رقم_الهوية", "بطاقة", "الرقم الوطني", "رقم الهوية الوطنية", "هوية رب الاسرة", "هوية رب الأسرة", "رقم هوية رب الاسرة", "رقم بطاقة الهوية", "رقم الهويه")),
    SystemFieldDef("name", "اسم المستفيد الرباعي", isRequired = true, "الاسم الكامل لرب الأسرة", listOf("name", "full_name", "الاسم", "اسم المستفيد", "الاسم رباعي", "رب الأسرة", "اسم_المستفيد", "اسم رب الأسرة", "اسم رب الاسرة", "الاسم الكامل", "اسم المواطن")),
    SystemFieldDef("localityID", "المحلية المعتمدة", isRequired = true, "رقم أو اسم المحلية المعتمدة (الشيخ رضوان، مشروع عامر، الرمال...)", listOf("localityID", "locality", "المحلية المعتمدة", "المحلية", "رقم المحلية", "اسم المحلية", "كود المحلية", "منطقة التوزيع", "مركز التوزيع", "المحليه")),
    SystemFieldDef("residentStatus", "صفة الإقامة (مقيم / نازح)", isRequired = false, "مقيم أو نازح", listOf("residentStatus", "الوضع", "صفة الإقامة", "صفة الاقامة", "مقيم/نازح", "الإقامة", "الاقامة", "حالة الإقامة", "نوع الإقامة", "status")),
    SystemFieldDef("developmentApproval", "حالة الاعتماد", isRequired = false, "معتمد / حجب اعتماد / مجمد", listOf("developmentApproval", "حالة الاعتماد", "الاعتماد", "اعتماد التنمية", "حالة_الاعتماد", "اعتماد", "approval", "حالة اعتماد التنمية", "الاعتماد الحكومي")),
    SystemFieldDef("familyMembersCount", "عدد أفراد الأسرة", isRequired = false, "إجمالي عدد أفراد الأسرة", listOf("members", "membersCount", "عدد الأفراد", "عدد الافراد", "الأفراد", "العدد", "عدد_الأفراد", "عدد أفراد الأسرة", "عدد افراد الاسرة", "أفراد الأسرة")),
    SystemFieldDef("primaryPhone", "رقم الجوال للتواصل", isRequired = false, "رقم الهاتف المحمول الأساسي", listOf("phone", "primaryPhone", "جوال", "رقم الجوال", "الهاتف", "موبايل", "رقم_الجوال", "رقم الهاتف", "المحمول")),
    SystemFieldDef("alternativePhone1", "رقم جوال بديل 1", isRequired = false, "جوال بديل", listOf("alternativePhone1", "جوال بديل", "هاتف بديل", "رقم بديل")),
    SystemFieldDef("alternativePhone2", "رقم جوال بديل 2", isRequired = false, "جوال بديل ثان", listOf("alternativePhone2", "جوال بديل 2", "هاتف ثان")),
    SystemFieldDef("currentSubArea", "المنطقة الفرعية الحالية", isRequired = false, "مكان السكن أو المخيم الميداني", listOf("subArea", "sub_area", "الحي", "المنطقة", "المخيم", "المنطقة الفرعية", "مكان السكن", "الحي / المخيم", "مكان النزوح", "المنطقة الفرعية الحالية")),
    SystemFieldDef("currentMainArea", "المنطقة الرئيسية الحالية", isRequired = false, "المحافظة الحالية", listOf("currentMainArea", "المنطقة الحالية", "المحافظة الحالية")),
    SystemFieldDef("currentBranch", "الشعبة الحالية", isRequired = false, "الشعبة الحالية", listOf("currentBranch", "الشعبة الحالية", "الشعبة")),
    SystemFieldDef("currentMosque", "المسجد الحالي", isRequired = false, "المسجد الحالي", listOf("currentMosque", "المسجد الحالي", "المسجد")),
    SystemFieldDef("originalMainArea", "المنطقة الرئيسية الأصلية", isRequired = false, "المحافظة أو المنطقة الأصلية", listOf("originalMainArea", "المنطقة الأصلية", "المحافظة الأصلية")),
    SystemFieldDef("originalSubArea", "المنطقة الفرعية الأصلية", isRequired = false, "الحي الأصلي قبل النزوح", listOf("originalSubArea", "الحي الأصلي", "المنطقة الفرعية الأصلية")),
    SystemFieldDef("originalBranch", "الشعبة الأصلية", isRequired = false, "الشعبة قبل النزوح", listOf("originalBranch", "الشعبة الأصلية")),
    SystemFieldDef("originalMosque", "المسجد الأصلي", isRequired = false, "المسجد قبل النزوح", listOf("originalMosque", "المسجد الأصلي")),
    SystemFieldDef("campOrCenterName", "اسم المخيم أو مركز الإيواء", isRequired = false, "اسم المركز أو المخيم", listOf("campOrCenterName", "مركز الإيواء", "المخيم", "مركز الايواء")),
    SystemFieldDef("worksApproval", "اعتماد وزارة الأشغال", isRequired = false, "اعتماد الأشغال العامة", listOf("worksApproval", "اعتماد الأشغال", "اعتماد الاشغال")),
    SystemFieldDef("localityApproval", "اعتماد المناطق والمحليات", isRequired = false, "اعتماد اللجنة المحلية", listOf("localityApproval", "اعتماد المناطق", "اعتماد المحلية")),
    SystemFieldDef("shelterStatus", "حالة الإيواء", isRequired = false, "إيواء داخلي / مركز إيواء / خيمة", listOf("shelter", "shelterStatus", "حالة الإيواء", "الإيواء", "مركز الإيواء", "حالة_الإيواء", "مكان الإيواء", "نوع المأوى")),
    SystemFieldDef("damageType", "حالة الضرر", isRequired = false, "أضرار كلية / جزئية / غير متضرر", listOf("damage", "damageType", "حالة الضرر", "الضرر", "نوع الضرر", "أضرار السكن", "تصنيف الضرر")),
    SystemFieldDef("damageDescription", "وصف أضرار المنزل", isRequired = false, "تفاصيل أضرار السكن", listOf("damageDescription", "وصف الضرر", "أضرار المنزل")),
    SystemFieldDef("injuryStatus", "حالة الإصابة", isRequired = false, "سليم / مصاب / مبتور", listOf("injuryStatus", "الإصابة", "الاصابة", "حالة الإصابة")),
    SystemFieldDef("injuryDate", "تاريخ الإصابة", isRequired = false, "تاريخ وقوع الإصابة", listOf("injuryDate", "تاريخ الإصابة", "تاريخ الاصابة")),
    SystemFieldDef("incomeSource1", "مصدر الدخل الأول", isRequired = false, "مصدر الدخل الأساسي", listOf("incomeSource1", "مصدر الدخل", "الدخل الأول", "العمل")),
    SystemFieldDef("incomeSource2", "مصدر الدخل الثاني", isRequired = false, "مصدر دخل إضافي", listOf("incomeSource2", "الدخل الثاني", "دخل إضافي")),
    SystemFieldDef("rationCardNumber", "رقم كرت المؤن / الوكالة", isRequired = false, "رقم بطاقة التموين", listOf("rationCardNumber", "كرت المؤن", "بطاقة المؤن", "رقم المؤن", "كرت الوكالة")),
    SystemFieldDef("wifeName", "اسم الزوج/الزوجة", isRequired = false, "اسم الزوجة الرباعي", listOf("wifeName", "wife_name", "اسم الزوجة", "الزوجة", "اسم الزوج")),
    SystemFieldDef("wifeNationalID", "رقم هوية الزوج/الزوجة", isRequired = false, "رقم هوية الزوجة", listOf("wifeNationalID", "wife_id", "هوية الزوجة", "رقم هوية الزوجة")),
    SystemFieldDef("birthDate", "تاريخ الميلاد", isRequired = false, "تاريخ ميلاد رب الأسرة", listOf("birthDate", "birth_date", "تاريخ الميلاد", "الميلاد", "سنة الميلاد")),
    SystemFieldDef("age", "العمر", isRequired = false, "عمر رب الأسرة بالسنوات", listOf("age", "العمر", "السن")),
    SystemFieldDef("gender", "الجنس", isRequired = false, "ذكر / أنثى", listOf("gender", "الجنس", "النوع")),
    SystemFieldDef("maritalStatus", "الحالة الاجتماعية", isRequired = false, "متزوج / أعزب / أرمل / مطلق", listOf("maritalStatus", "الحالة الاجتماعية", "الحالة_الاجتماعية", "الحالة")),
    SystemFieldDef("deathStatus", "حالة الوفاة", isRequired = false, "على قيد الحياة / متوفى", listOf("deathStatus", "الوفاة", "حالة الوفاة", "شهيد")),
    SystemFieldDef("deathDate", "تاريخ الوفاة", isRequired = false, "تاريخ الاستشهاد أو الوفاة", listOf("deathDate", "تاريخ الوفاة", "تاريخ الاستشهاد")),
    SystemFieldDef("notes", "ملاحظات ميدانية", isRequired = false, "أي شروط أو تفاصيل إضافية", listOf("notes", "ملاحظات", "الملاحظات", "بيان", "ملاحظة"))
)

val aidRecordSystemFields = listOf(
    SystemFieldDef("familyNationalID", "رقم هوية المستفيد / الأسرة", isRequired = true, "رقم هوية رب الأسرة المستفيدة للربط", listOf("familyNationalID", "nationalID", "هوية", "رقم الهوية", "الهوية", "id", "هوية الأسرة", "هوية رب الأسرة")),
    SystemFieldDef("familyID", "معرف الأسرة الرقمي (اختياري)", isRequired = false, "رقم تعريف الأسرة في جدول الأسر", listOf("familyID", "family_id", "معرف الأسرة", "رقم الأسرة", "رقم السجل")),
    SystemFieldDef("aidTypeName", "نوع أو تصنيف المساعدة", isRequired = true, "سلة غذائية / نقدية / كسوة...", listOf("aidTypeName", "aidType", "نوع المساعدة", "المساعدة", "نوع_المساعدة", "التصنيف", "اسم المساعدة")),
    SystemFieldDef("projectName", "اسم المشروع الإغاثي", isRequired = false, "اسم المنحة أو المشروع والجهة المانحة", listOf("projectName", "project", "المشروع", "اسم المشروع", "المانح", "رقم المشروع")),
    SystemFieldDef("date", "تاريخ الصرف والتسليم", isRequired = false, "تاريخ الاستلام الفعلي", listOf("date", "aidDate", "التاريخ", "تاريخ الصرف", "تاريخ التسليم", "تاريخ المساعدة")),
    SystemFieldDef("selectionDate", "تاريخ الترشيح", isRequired = false, "تاريخ اختيار المستفيد", listOf("selectionDate", "تاريخ الترشيح", "الترشيح")),
    SystemFieldDef("warehouse", "نقطة التوزيع أو المستودع", isRequired = false, "مستودع أو نقطة الصرف الميداني", listOf("warehouse", "المستودع", "نقطة التوزيع", "نقطة الصرف", "المخزن")),
    SystemFieldDef("status", "حالة الاستلام", isRequired = false, "مستلم / بانتظار الصرف", listOf("status", "recipientStatus", "حالة الاستلام", "الحالة", "حالة المستفيد")),
    SystemFieldDef("deliveryDate", "تاريخ التسليم الفعلي", isRequired = false, "تاريخ الاستلام الفعلي", listOf("deliveryDate", "تاريخ الاستلام", "تاريخ التسليم الفعلي")),
    SystemFieldDef("aidValue", "قيمة المساعدة (بالدولار أو الشيكل)", isRequired = false, "القيمة النقدية أو التقديرية", listOf("aidValue", "القيمة", "المبلغ", "value", "قيمة المساعدة")),
    SystemFieldDef("notes", "ملاحظات", isRequired = false, "ملاحظات السجل", listOf("notes", "الملاحظات", "ملاحظة", "بيان"))
)

val childSystemFields = listOf(
    SystemFieldDef("childNationalID", "رقم هوية الطفل/التابع", isRequired = true, "رقم هوية الطفل (9 أرقام)", listOf("childNationalID", "هوية الطفل", "رقم هوية الطفل", "هوية التابع", "nationalID", "رقم الهوية")),
    SystemFieldDef("childName", "اسم الطفل الرباعي", isRequired = true, "اسم الطفل أو التابع كاملاً", listOf("childName", "اسم الطفل", "اسم التابع", "الاسم", "name", "اسم الطفل الرباعي")),
    SystemFieldDef("familyNationalID", "رقم هوية رب الأسرة (للربط)", isRequired = true, "رقم هوية المعيل التابع له في جدول الأسر", listOf("familyNationalID", "هوية الأسرة", "هوية المعيل", "هوية الأب", "parent_id", "هوية رب الاسرة", "رقم هوية الاسرة", "هوية رب الأسرة")),
    SystemFieldDef("birthDate", "تاريخ ميلاد الطفل", isRequired = false, "تاريخ الميلاد (YYYY-MM-DD)", listOf("birthDate", "تاريخ الميلاد", "الميلاد", "سنة الميلاد")),
    SystemFieldDef("gender", "الجنس (ذكر / أنثى)", isRequired = false, "ذكر أو أنثى", listOf("gender", "الجنس", "نوع الجنس", "النوع")),
    SystemFieldDef("localityID", "رقم أو اسم المحلية", isRequired = false, "المحلية التابع لها", listOf("localityID", "المحلية", "رقم المحلية", "منطقة الطفل")),
    SystemFieldDef("shelterStatus", "حالة الإيواء", isRequired = false, "إيواء داخلي / مركز إيواء / خيمة", listOf("shelterStatus", "الإيواء", "حالة الإيواء", "مكان الإيواء"))
)

fun detectBestMatch(field: SystemFieldDef, availableHeaders: List<String>, usedHeaders: Set<String> = emptySet()): String {
    for (kw in field.autoMatchKeywords) {
        val found = availableHeaders.find { header ->
            if (usedHeaders.contains(header)) return@find false
            val clean = header.trim().lowercase().replace("_", "").replace(" ", "").replace("-", "")
            val target = kw.lowercase().replace("_", "").replace(" ", "").replace("-", "")
            clean == target || clean.contains(target) || target.contains(clean)
        }
        if (found != null) return found
    }
    return ""
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExcelImportExportScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var activeTab by remember { mutableStateOf(ExcelTab.EXPORT_PERIOD) }
    var selectedImportType by remember { mutableStateOf(ImportDataType.FAMILIES) }

    var startDate by remember { mutableStateOf("2026-01-01") }
    var endDate by remember { mutableStateOf("2026-10-14") }
    var selectedLocalityId by remember { mutableStateOf(0) }
    var selectedAidTypeId by remember { mutableStateOf(0) }
    var selectedGroup by remember { mutableStateOf("كافة المجموعات") }

    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val groups = remember { repository.getAvailableGroups() }

    var exportSuccessMessage by remember { mutableStateOf<String?>(null) }
    var exportedFilePath by remember { mutableStateOf<String?>(null) }
    var isExporting by remember { mutableStateOf(false) }

    var importStatusMessage by remember { mutableStateOf<String?>(null) }
    var isImporting by remember { mutableStateOf(false) }
    var parsedPreviewRows by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var loadedFileName by remember { mutableStateOf<String?>(null) }

    var showMappingDialog by remember { mutableStateOf(false) }
    var detectedHeaders by remember { mutableStateOf<List<String>>(emptyList()) }
    var rawImportRows by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var currentFieldMappings by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var duplicateMode by remember { mutableStateOf(AidRepository.DuplicateHandlingMode.UPDATE_EXISTING) }

    var showProgressDialog by remember { mutableStateOf(false) }
    var importProgressPct by remember { mutableStateOf(0f) }
    var importCurrentCount by remember { mutableStateOf(0) }
    var importTotalCount by remember { mutableStateOf(0) }
    var batchResult by remember { mutableStateOf<AidRepository.BatchImportResult?>(null) }

    var showResultSummaryDialog by remember { mutableStateOf(false) }
    var showTemplateExportDialog by remember { mutableStateOf(false) }

    fun exportTemplateFile(type: ImportDataType) {
        val fileName = when (type) {
            ImportDataType.FAMILIES -> "قالب_استيراد_الأسر_المعتمد.xlsx"
            ImportDataType.CHILDREN -> "قالب_استيراد_الأبناء_المعتمد.xlsx"
            ImportDataType.AID_RECORDS -> "قالب_سجلات_المساعدات_المعتمد.xlsx"
        }
        val generator: (java.io.OutputStream) -> Unit = { os ->
            when (type) {
                ImportDataType.FAMILIES -> ExcelParserHelper.generateFamilyTemplate(os)
                ImportDataType.CHILDREN -> ExcelParserHelper.generateChildrenTemplate(os)
                ImportDataType.AID_RECORDS -> ExcelParserHelper.generateAidRecordsTemplate(os)
            }
        }
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                val values = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { os -> generator(os) }
                    Toast.makeText(context, "✅ تم حفظ قالب ${type.label} في Downloads: $fileName", Toast.LENGTH_LONG).show()
                } else {
                    throw Exception("تعذر فتح مسار التنزيلات")
                }
            } else {
                val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                val targetFile = java.io.File(downloadsDir, fileName)
                java.io.FileOutputStream(targetFile).use { os -> generator(os) }
                Toast.makeText(context, "✅ تم حفظ قالب ${type.label} في التنزيلات: ${targetFile.name}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            try {
                val fallbackFile = java.io.File(context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS), fileName)
                java.io.FileOutputStream(fallbackFile).use { os -> generator(os) }
                Toast.makeText(context, "✅ تم حفظ القالب في مجلد التطبيق: ${fallbackFile.name}", Toast.LENGTH_LONG).show()
            } catch (ex: Exception) {
                Toast.makeText(context, "❌ تعذر تصدير القالب: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun generateFallbackRows(type: ImportDataType): List<Map<String, String>> {
        return when (type) {
            ImportDataType.FAMILIES -> listOf(
                mapOf("nationalID" to "902145890", "name" to "عمر حاتم صبحي القدوة", "members" to "6", "locality" to "غزة - الرمال", "phone" to "0599112233", "shelter" to "إيواء داخلي", "damage" to "أضرار كلية"),
                mapOf("nationalID" to "914872341", "name" to "محمود خليل إبراهيم النجار", "members" to "8", "locality" to "خان يونس", "phone" to "0599223344", "shelter" to "إيواء داخلي", "damage" to "أضرار جزئية بليغة")
            )
            ImportDataType.AID_RECORDS -> listOf(
                mapOf("familyNationalID" to "902145890", "aidTypeName" to "سلة غذائية", "projectName" to "مشروع إغاثة 2026", "date" to "2026-10-10", "warehouse" to "مستودع الرمال", "status" to "مستلم")
            )
            ImportDataType.CHILDREN -> listOf(
                mapOf("childNationalID" to "412589632", "childName" to "حاتم عمر القدوة", "birthDate" to "2018-05-14", "gender" to "ذكر", "familyNationalID" to "902145890")
            )
        }
    }

    fun openSampleMapping() {
        val sampleRows = generateFallbackRows(selectedImportType)
        val headers = sampleRows.firstOrNull()?.keys?.toList() ?: listOf("nationalID", "name", "members")
        detectedHeaders = headers
        rawImportRows = sampleRows
        loadedFileName = "نموذج_إكسل_تجريبي.xlsx"

        val targetFields = when (selectedImportType) {
            ImportDataType.FAMILIES -> familySystemFields
            ImportDataType.AID_RECORDS -> aidRecordSystemFields
            ImportDataType.CHILDREN -> childSystemFields
        }
        val autoMap = mutableMapOf<String, String>()
        targetFields.forEach { f ->
            val matched = detectBestMatch(f, headers)
            if (matched.isNotBlank()) {
                autoMap[f.key] = matched
            }
        }
        currentFieldMappings = autoMap
        showMappingDialog = true
    }

    val excelFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    var fileName = "imported_data.xlsx"
                    try {
                        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (nameIdx != -1 && cursor.moveToFirst()) {
                                fileName = cursor.getString(nameIdx)
                            }
                        }
                    } catch (_: Exception) {
                        fileName = uri.lastPathSegment ?: "imported_data.xlsx"
                    }
                    loadedFileName = fileName

                    val parsedList: List<Map<String, String>> = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { stream ->
                            when (selectedImportType) {
                                ImportDataType.FAMILIES -> ExcelParserHelper.parseExcelFile(stream)
                                ImportDataType.CHILDREN -> ExcelParserHelper.parseChildrenExcelFile(stream)
                                ImportDataType.AID_RECORDS -> ExcelParserHelper.parseAidRecordsExcelFile(stream)
                            }
                        } ?: emptyList()
                    }
                    val rows: List<Map<String, String>> = if (parsedList.isNotEmpty()) parsedList else generateFallbackRows(selectedImportType)
                    val headers: List<String> = rows.firstOrNull()?.keys?.toList() ?: listOf("nationalID", "name")

                    detectedHeaders = headers
                    rawImportRows = rows

                    val targetFields = when (selectedImportType) {
                        ImportDataType.FAMILIES -> familySystemFields
                        ImportDataType.AID_RECORDS -> aidRecordSystemFields
                        ImportDataType.CHILDREN -> childSystemFields
                    }
