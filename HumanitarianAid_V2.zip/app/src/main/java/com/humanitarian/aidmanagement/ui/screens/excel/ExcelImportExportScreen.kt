package com.humanitarian.aidmanagement.ui.screens.excel

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExcelImportExportScreen(
    onNavigateBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("استيراد وتصدير الإكسل", fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            Text("محرك الاستيراد الديناميكي للمحليات", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("يقرأ معرف واسم المحلية مباشرة بدون أي قيم افتراضية.")
        }
    }
}
