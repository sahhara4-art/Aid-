package com.humanitarian.aidmanagement.ui.screens.excel

import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.ExcelParserHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

enum class ExcelTab {
    EXPORT_PERIOD,
    IMPORT_EXCEL
}

enum class ImportDataType(val label: String, val icon: String) {
    FAMILIES("بيانات الأسر", "👨‍👩‍👧"),
    AID_RECORDS("سجلات المساعدات", "📦"),
    CHILDREN("سجل الأبناء والتابعين", "👶")
}

data class SystemFieldDef(
    val key: String,
    val label: String,
    val isRequired: Boolean = false,
    val description: String = "",
    val autoMatchKeywords: List<String> = emptyList()
)

val familySystemFields = listOf(
    SystemFieldDef("nationalID", "رقم الهوية الوطنية", isRequired = true, "رقم هوية رب الأسرة (9 أرقام)", listOf("nationalID", "national_id", "هوية", "رقم الهوية", "الهوية", "id", "الرقم الوطني")),
    SystemFieldDef("name", "اسم المستفيد الرباعي", isRequired = true, "الاسم الكامل لرب الأسرة", listOf("name", "full_name", "الاسم", "اسم المستفيد", "الاسم رباعي", "رب الأسرة")),
    SystemFieldDef("localityID", "المحلية المعتمدة", isRequired = true, "رقم أو اسم المحلية المعتمدة", listOf("localityID", "locality", "المحلية المعتمدة", "المحلية")),
    SystemFieldDef("residentStatus", "صفة الإقامة", isRequired = false, "م
