package com.humanitarian.aidmanagement.ui.screens.excel

import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.ExcelParserHelper
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.scale
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*


enum class ImportDataType(val label: String, val icon: String) {
    FAMILIES("بيانات الأسر", "👨‍👩‍👧"),
    AID_RECORDS("سجلات المساعدات", "📦"),
    CHILDREN("سجل الأبناء والتابعين", "👶")
}

data class SystemFieldDef(
    val key: String,
    val label: String,
    val isRequired: Boolean = false,
    val description: String = "",
    val autoMatchKeywords: List<String> = emptyList()
)

val familySystemFields = listOf(
    SystemFieldDef("nationalID", "رقم الهوية الوطنية", isRequired = true, "رقم هوية رب الأسرة (9 أرقام)", listOf("nationalID", "national_id", "هوية", "رقم الهوية", "الهوية", "id", "رقم_الهوية", "بطاقة", "الرقم الوطني", "رقم الهوية الوطنية", "هوية رب الاسرة", "هوية رب الأسرة", "رقم هوية رب الاسرة", "رقم بطاقة الهوية", "رقم الهويه")),
    SystemFieldDef("name", "اسم المستفيد الرباعي", isRequired = true, "الاسم الكامل لرب الأسرة", listOf("name", "full_name", "الاسم", "اسم المستفيد", "الاسم رباعي", "رب الأسرة", "اسم_المستفيد", "اسم رب الأسرة", "اسم رب الاسرة", "الاسم الكامل", "اسم المواطن")),
    SystemFieldDef("localityID", "المحلية المعتمدة", isRequired = true, "رقم أو اسم المحلية المعتمدة في النظام", listOf("localityID", "locality", "المحلية المعتمدة", "المحلية", "رقم المحلية", "اسم المحلية", "كود المحلية", "منطقة التوزيع", "مركز التوزيع", "المحليه")),
    SystemFieldDef("residentStatus", "صفة الإقامة (مقيم / نازح)", isRequired = false, "مقيم أو نازح", listOf("residentStatus", "الوضع", "صفة الإقامة", "صفة الاقامة", "مقيم/نازح", "الإقامة", "الاقامة", "حالة الإقامة", "نوع الإقامة", "status")),
    SystemFieldDef("developmentApproval", "حالة الاعتماد", isRequired = false, "معتمد / حجب اعتماد / مجمد", listOf("developmentApproval", "حالة الاعتماد", "الاعتماد", "اعتماد التنمية", "حالة_الاعتماد", "اعتماد", "approval", "حالة اعتماد التنمية", "الاعتماد الحكومي")),
    SystemFieldDef("familyMembersCount", "عدد أفراد الأسرة", isRequired = false, "إجمالي عدد أفراد الأسرة", listOf("members", "membersCount", "عدد الأفراد", "عدد الافراد", "الأفراد", "العدد", "عدد_الأفراد", "عدد أفراد الأسرة", "عدد افراد الاسرة", "أفراد الأسرة")),
    SystemFieldDef("primaryPhone", "رقم الجوال للتواصل", isRequired = false, "رقم الهاتف المحمول الأساسي", listOf("phone", "primaryPhone", "جوال", "رقم الجوال", "الهاتف", "موبايل", "رقم_الجوال", "رقم الهاتف", "المحمول")),
    SystemFieldDef("alternativePhone1", "رقم جوال بديل 1", isRequired = false, "جوال بديل", listOf("alternativePhone1", "جوال بديل", "هاتف بديل", "رقم بديل")),
    SystemFieldDef("alternativePhone2", "رقم جوال بديل 2", isRequired = false, "جوال بديل ثان", listOf("alternativePhone2", "جوال بديل 2", "هاتف ثان")),
    SystemFieldDef("currentSubArea", "المنطقة الفرعية الحالية", isRequired = false, "مكان السكن أو المخيم الميداني", listOf("subArea", "sub_area", "الحي", "المنطقة", "المخيم", "المنطقة الفرعية", "مكان السكن", "الحي / المخيم", "مكان النزوح", "المنطقة الفرعية الحالية")),
    SystemFieldDef("currentMainArea", "المنطقة الرئيسية الحالية", isRequired = false, "المحافظة الحالية", listOf("currentMainArea", "المنطقة الحالية", "المحافظة الحالية")),
    SystemFieldDef("currentBranch", "الشعبة الحالية", isRequired = false, "الشعبة الحالية", listOf("currentBranch", "الشعبة الحالية", "الشعبة")),
    SystemFieldDef("currentMosque", "المسجد الحالي", isRequired = false, "المسجد الحالي", listOf("currentMosque", "المسجد الحالي", "المسجد")),
    SystemFieldDef("originalMainArea", "المنطقة الرئيسية الأصلية", isRequired = false, "المحافظة أو المنطقة الأصلية", listOf("originalMainArea", "المنطقة الأصلية", "المحافظة الأصلية")),
    SystemFieldDef("originalSubArea", "المنطقة الفرعية الأصلية", isRequired = false, "الحي الأصلي قبل النزوح", listOf("originalSubArea", "الحي الأصلي", "المنطقة الفرعية الأصلية")),
    SystemFieldDef("originalBranch", "الشعبة الأصلية", isRequired = false, "الشعبة قبل النزوح", listOf("originalBranch", "الشعبة الأصلية")),
    SystemFieldDef("originalMosque", "المسجد الأصلي", isRequired = false, "المسجد قبل النزوح", listOf("originalMosque", "المسجد الأصلي")),
    SystemFieldDef("campOrCenterName", "اسم المخيم أو مركز الإيواء", isRequired = false, "اسم المركز أو المخيم", listOf("campOrCenterName", "مركز الإيواء", "المخيم", "مركز الايواء")),
    SystemFieldDef("worksApproval", "اعتماد وزارة الأشغال", isRequired = false, "اعتماد الأشغال العامة", listOf("worksApproval", "اعتماد الأشغال", "اعتماد الاشغال")),
    SystemFieldDef("localityApproval", "اعتماد المناطق والمحليات", isRequired = false, "اعتماد اللجنة المحلية", listOf("localityApproval", "اعتماد المناطق", "اعتماد المحلية")),
    SystemFieldDef("shelterStatus", "حالة الإيواء", isRequired = false, "إيواء داخلي / مركز إيواء / خيمة", listOf("shelter", "shelterStatus", "حالة الإيواء", "الإيواء", "مركز الإيواء", "حالة_الإيواء", "مكان الإيواء", "نوع المأوى")),
    SystemFieldDef("damageType", "حالة الضرر", isRequired = false, "أضرار كلية / جزئية / غير متضرر", listOf("damage", "damageType", "حالة الضرر", "الضرر", "نوع الضرر", "أضرار السكن", "تصنيف الضرر")),
    SystemFieldDef("damageDescription", "وصف أضرار المنزل", isRequired = false, "تفاصيل أضرار السكن", listOf("damageDescription", "وصف الضرر", "أضرار المنزل")),
    SystemFieldDef("injuryStatus", "حالة الإصابة", isRequired = false, "سليم / مصاب / مبتور", listOf("injuryStatus", "الإصابة", "الاصابة", "حالة الإصابة")),
    SystemFieldDef("injuryDate", "تاريخ الإصابة", isRequired = false, "تاريخ وقوع الإصابة", listOf("injuryDate", "تاريخ الإصابة", "تاريخ الاصابة")),
    SystemFieldDef("incomeSource1", "مصدر الدخل الأول", isRequired = false, "مصدر الدخل الأساسي", listOf("incomeSource1", "مصدر الدخل", "الدخل الأول", "العمل")),
    SystemFieldDef("incomeSource2", "مصدر الدخل الثاني", isRequired = false, "مصدر دخل إضافي", listOf("incomeSource2", "الدخل الثاني", "دخل إضافي")),
    SystemFieldDef("rationCardNumber", "رقم كرت المؤن / الوكالة", isRequired = false, "رقم بطاقة التموين", listOf("rationCardNumber", "كرت المؤن", "بطاقة المؤن", "رقم المؤن", "كرت الوكالة")),
    SystemFieldDef("wifeName", "اسم الزوج/الزوجة", isRequired = false, "اسم الزوجة الرباعي", listOf("wifeName", "wife_name", "اسم الزوجة", "الزوجة", "اسم الزوج")),
    SystemFieldDef("wifeNationalID", "رقم هوية الزوج/الزوجة", isRequired = false, "رقم هوية الزوجة", listOf("wifeNationalID", "wife_id", "هوية الزوجة", "رقم هوية الزوجة")),
    SystemFieldDef("birthDate", "تاريخ الميلاد", isRequired = false, "تاريخ ميلاد رب الأسرة", listOf("birthDate", "birth_date", "تاريخ الميلاد", "الميلاد", "سنة الميلاد")),
    SystemFieldDef("age", "العمر", isRequired = false, "عمر رب الأسرة بالسنوات", listOf("age", "العمر", "السن")),
    SystemFieldDef("gender", "الجنس", isRequired = false, "ذكر / أنثى", listOf("gender", "الجنس", "النوع")),
    SystemFieldDef("maritalStatus", "الحالة الاجتماعية", isRequired = false, "متزوج / أعزب / أرمل / مطلق", listOf("maritalStatus", "الحالة الاجتماعية", "الحالة_الاجتماعية", "الحالة")),
    SystemFieldDef("deathStatus", "حالة الوفاة", isRequired = false, "على قيد الحياة / متوفى", listOf("deathStatus", "الوفاة", "حالة الوفاة", "شهيد")),
    SystemFieldDef("deathDate", "تاريخ الوفاة", isRequired = false, "تاريخ الاستشهاد أو الوفاة", listOf("deathDate", "تاريخ الوفاة", "تاريخ الاستشهاد")),
    SystemFieldDef("notes", "ملاحظات ميدانية", isRequired = false, "أي شروط أو تفاصيل إضافية", listOf("notes", "ملاحظات", "الملاحظات", "بيان", "ملاحظة"))
)


val aidRecordSystemFields = listOf(
    SystemFieldDef("familyNationalID", "رقم هوية المستفيد / الأسرة", isRequired = true, "رقم هوية رب الأسرة المستفيدة للربط", listOf("familyNationalID", "nationalID", "هوية", "رقم الهوية", "الهوية", "id", "هوية الأسرة", "هوية رب الأسرة")),
    SystemFieldDef("familyID", "معرف الأسرة الرقمي (اختياري)", isRequired = false, "رقم تعريف الأسرة في جدول الأسر", listOf("familyID", "family_id", "معرف الأسرة", "رقم الأسرة", "رقم السجل")),
    SystemFieldDef("aidTypeName", "تصنيف المساعدة (Assistance Category)", isRequired = true, "تصنيف المساعدة المعتمد في النظام", listOf("aidTypeName", "aidCategory", "aidType", "تصنيف المساعدة", "التصنيف", "اسم المساعدة", "صنف المساعدة")),
    SystemFieldDef("assistanceType", "نوع المساعدة (Assistance Type)", isRequired = false, "عينية / نقدية / طرد / قسيمة شرائية...", listOf("assistanceType", "assistance_type", "نوع المساعدة", "نوع المعونة", "طبيعة المساعدة", "نوع_المساعدة")),
    SystemFieldDef("projectNumber", "رقم المشروع (Project Number)", isRequired = false, "كود أو رقم المشروع الإغاثي للربط الديناميكي", listOf("projectNumber", "project_number", "رقم المشروع", "كود المشروع", "رقم_المشروع", "رمز المشروع")),
    SystemFieldDef("projectName", "اسم المشروع الإغاثي (Project Name)", isRequired = false, "اسم المنحة أو المشروع والجهة المانحة", listOf("projectName", "project", "المشروع", "اسم المشروع", "المانح", "اسم_المشروع")),
    SystemFieldDef("date", "تاريخ الصرف والتسليم", isRequired = false, "تاريخ الاستلام الفعلي", listOf("date", "aidDate", "التاريخ", "تاريخ الصرف", "تاريخ التسليم", "تاريخ المساعدة")),
    SystemFieldDef("selectionDate", "تاريخ الترشيح", isRequired = false, "تاريخ اختيار المستفيد", listOf("selectionDate", "تاريخ الترشيح", "الترشيح")),
    SystemFieldDef("warehouse", "نقطة التوزيع أو المستودع", isRequired = false, "مستودع أو نقطة الصرف الميداني", listOf("warehouse", "المستودع", "نقطة التوزيع", "نقطة الصرف", "المخزن")),
    SystemFieldDef("status", "حالة الاستلام", isRequired = false, "مستلم / بانتظار الصرف", listOf("status", "recipientStatus", "حالة الاستلام", "الحالة", "حالة المستفيد")),
    SystemFieldDef("deliveryDate", "تاريخ التسليم الفعلي", isRequired = false, "تاريخ الاستلام الفعلي", listOf("deliveryDate", "تاريخ الاستلام", "تاريخ التسليم الفعلي")),
    SystemFieldDef("aidValue", "قيمة المساعدة (بالدولار أو الشيكل)", isRequired = false, "القيمة النقدية أو التقديرية", listOf("aidValue", "القيمة", "المبلغ", "value", "قيمة المساعدة")),
    SystemFieldDef("notes", "ملاحظات", isRequired = false, "ملاحظات السجل", listOf("notes", "الملاحظات", "ملاحظة", "بيان"))
)

val childSystemFields = listOf(
    SystemFieldDef("childNationalID", "رقم هوية الطفل/التابع", isRequired = true, "رقم هوية الطفل (9 أرقام)", listOf("childNationalID", "هوية الطفل", "رقم هوية الطفل", "هوية التابع", "nationalID", "رقم الهوية")),
    SystemFieldDef("childName", "اسم الطفل الرباعي", isRequired = true, "اسم الطفل أو التابع كاملاً", listOf("childName", "اسم الطفل", "اسم التابع", "الاسم", "name", "اسم الطفل الرباعي")),
    SystemFieldDef("familyNationalID", "رقم هوية رب الأسرة (للربط)", isRequired = true, "رقم هوية المعيل التابع له في جدول الأسر", listOf("familyNationalID", "هوية الأسرة", "هوية المعيل", "هوية الأب", "parent_id", "هوية رب الاسرة", "رقم هوية الاسرة", "هوية رب الأسرة")),
    SystemFieldDef("birthDate", "تاريخ ميلاد الطفل", isRequired = false, "تاريخ الميلاد (YYYY-MM-DD)", listOf("birthDate", "تاريخ الميلاد", "الميلاد", "سنة الميلاد")),
    SystemFieldDef("gender", "الجنس (ذكر / أنثى)", isRequired = false, "ذكر أو أنثى", listOf("gender", "الجنس", "نوع الجنس", "النوع")),
    SystemFieldDef("localityID", "رقم أو اسم المحلية", isRequired = false, "المحلية التابع لها", listOf("localityID", "المحلية", "رقم المحلية", "منطقة الطفل")),
    SystemFieldDef("shelterStatus", "حالة الإيواء", isRequired = false, "إيواء داخلي / مركز إيواء / خيمة", listOf("shelterStatus", "الإيواء", "حالة الإيواء", "مكان الإيواء"))
)


fun detectBestMatch(field: SystemFieldDef, availableHeaders: List<String>, usedHeaders: Set<String> = emptySet()): String {
    for (kw in field.autoMatchKeywords) {
        val found = availableHeaders.find { header ->
            if (usedHeaders.contains(header)) return@find false
            val clean = header.trim().lowercase().replace("_", "").replace(" ", "").replace("-", "")
            val target = kw.lowercase().replace("_", "").replace(" ", "").replace("-", "")
            clean == target || clean.contains(target) || target.contains(clean)
        }
        if (found != null) return found
    }
    return ""
}


@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExcelImportExportScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedImportType by remember { mutableStateOf(ImportDataType.FAMILIES) }

    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val acmPermissions by AccessControlManager.permissionsSetFlow.collectAsStateWithLifecycle()
    val canImportData = remember(currentUser, acmPermissions) {
        currentUser != null && AccessControlManager.canImportExcel()
    }

    val localities by repository.getAllowedLocalitiesFlow().collectAsStateWithLifecycle(initialValue = emptyList())

    // حالات الاستيراد ومطابقة الحقول
    var importStatusMessage by remember { mutableStateOf<String?>(null) }
    var isImporting by remember { mutableStateOf(false) }
    var parsedPreviewRows by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var loadedFileName by remember { mutableStateOf<String?>(null) }

    // شاشة مطابقة الحقول ومؤشر التقدم غير المتزامن
    var showMappingDialog by remember { mutableStateOf(false) }
    var detectedHeaders by remember { mutableStateOf<List<String>>(emptyList()) }
    var rawImportRows by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var currentFieldMappings by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var selectedImportUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var duplicateMode by remember { mutableStateOf(AidRepository.DuplicateHandlingMode.UPDATE_EXISTING) }
    var selectedAidTypeColumnIndex by remember { mutableStateOf<Int?>(null) }

    var showProgressDialog by remember { mutableStateOf(false) }
    var importProgressPct by remember { mutableStateOf(0f) }
    var importCurrentCount by remember { mutableStateOf(0) }
    var importTotalCount by remember { mutableStateOf(0) }
    var batchResult by remember { mutableStateOf<AidRepository.BatchImportResult?>(null) }

    var showResultSummaryDialog by remember { mutableStateOf(false) }
    var showTemplateExportDialog by remember { mutableStateOf(false) }


    fun exportTemplateFile(type: ImportDataType) {
        val fileName = when (type) {
            ImportDataType.FAMILIES -> "قالب_استيراد_الأسر_المعتمد.xlsx"
            ImportDataType.CHILDREN -> "قالب_استيراد_الأبناء_المعتمد.xlsx"
            ImportDataType.AID_RECORDS -> "قالب_سجلات_المساعدات_المعتمد.xlsx"
        }
        val generator: (java.io.OutputStream) -> Unit = { os ->
            when (type) {
                ImportDataType.FAMILIES -> com.humanitarian.aidmanagement.util.ExcelParserHelper.generateFamilyTemplate(os)
                ImportDataType.CHILDREN -> com.humanitarian.aidmanagement.util.ExcelParserHelper.generateChildrenTemplate(os)
                ImportDataType.AID_RECORDS -> com.humanitarian.aidmanagement.util.ExcelParserHelper.generateAidRecordsTemplate(os)
            }
        }
        scope.launch {
            val message = withContext(Dispatchers.IO) {
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                        val values = android.content.ContentValues().apply {
                            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                            put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
                        }
                        val uri = context.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        if (uri != null) {
                            context.contentResolver.openOutputStream(uri)?.use { os -> generator(os) }
                            "✅ تم حفظ قالب ${type.label} في Downloads: $fileName"
                        } else {
                            throw Exception("تعذر فتح مسار التنزيلات")
                        }
                    } else {
                        val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                        val targetFile = java.io.File(downloadsDir, fileName)
                        java.io.FileOutputStream(targetFile).use { os -> generator(os) }
                        "✅ تم حفظ قالب ${type.label} في التنزيلات: ${targetFile.name}"
                    }
                } catch (e: Exception) {
                    try {
                        val fallbackFile = java.io.File(context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS), fileName)
                        java.io.FileOutputStream(fallbackFile).use { os -> generator(os) }
                        "✅ تم حفظ القالب في مجلد التطبيق: ${fallbackFile.name}"
                    } catch (_: Exception) {
                        "❌ تعذر تصدير القالب: ${e.message}"
                    }
                }
            }
            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
        }
    }

    // دالة محاكاة قراءة ملف إكسل وتجهيز عينات للفحص
    fun generateFallbackRows(type: ImportDataType): List<Map<String, String>> {

        return when (type) {
            ImportDataType.FAMILIES -> listOf(
                mapOf("nationalID" to "902145890", "name" to "عمر حاتم صبحي القدوة", "members" to "6", "locality" to "غزة - الرمال", "phone" to "0599112233", "shelter" to "إيواء داخلي", "damage" to "أضرار كلية"),
                mapOf("nationalID" to "914872341", "name" to "محمود خليل إبراهيم النجار", "members" to "8", "locality" to "خان يونس", "phone" to "0599223344", "shelter" to "إيواء داخلي", "damage" to "أضرار جزئية بليغة"),
                mapOf("nationalID" to "925634129", "name" to "فاطمة أحمد سليم المصري", "members" to "5", "locality" to "دير البلح والوسطى", "phone" to "0599334455", "shelter" to "خارج الإيواء", "damage" to "أضرار كلية"),
                mapOf("nationalID" to "936512784", "name" to "ياسر كمال حسن بركة", "members" to "7", "locality" to "رفح - تل السلطان", "phone" to "0599445566", "shelter" to "إيواء داخلي", "damage" to "أضرار كلية"),
                mapOf("nationalID" to "947823901", "name" to "سليمان رجب عبد الفتاح عابد", "members" to "4", "locality" to "شمال غزة - جباليا", "phone" to "0599556677", "shelter" to "إيواء داخلي", "damage" to "أضرار كلية")
            )
            ImportDataType.AID_RECORDS -> listOf(
                mapOf("familyNationalID" to "902145890", "aidTypeName" to "سلة خضار طازجة وطرد غذائي", "projectName" to "مشروع إغاثة غزة العاجل 2026", "date" to "2026-10-10", "warehouse" to "مستودع الرمال الرئيسي", "status" to "مستلم"),
                mapOf("familyNationalID" to "914872341", "aidTypeName" to "مساعدة مالية نقدية (100 دولار)", "projectName" to "منحة الطوارئ الإنسانية", "date" to "2026-10-11", "warehouse" to "مستودع خان يونس", "status" to "مستلم"),
                mapOf("familyNationalID" to "925634129", "aidTypeName" to "طرد صحي ومنظفات أطفال", "projectName" to "حملة الرعاية الصحية والوقاية", "date" to "2026-10-12", "warehouse" to "مستودع دير البلح", "status" to "مرشح"),
                mapOf("familyNationalID" to "936512784", "aidTypeName" to "شوادر وخيمة إيواء شتوية", "projectName" to "مشروع الإيواء الشتوي المستعجل", "date" to "2026-10-13", "warehouse" to "مستودع تل السلطان", "status" to "مستلم")
            )
            ImportDataType.CHILDREN -> listOf(
                mapOf("childNationalID" to "412589632", "childName" to "حاتم عمر حاتم القدوة", "birthDate" to "2018-05-14", "gender" to "ذكر", "familyNationalID" to "902145890"),
                mapOf("childNationalID" to "423698521", "childName" to "مريم عمر حاتم القدوة", "birthDate" to "2020-09-22", "gender" to "أنثى", "familyNationalID" to "902145890"),
                mapOf("childNationalID" to "434789654", "childName" to "إبراهيم محمود خليل النجار", "birthDate" to "2017-03-10", "gender" to "ذكر", "familyNationalID" to "914872341"),
                mapOf("childNationalID" to "445896321", "childName" to "سارة ياسر كمال بركة", "birthDate" to "2021-11-05", "gender" to "أنثى", "familyNationalID" to "936512784")
            )
        }
    }

    // دالة فتح عينة تجريبية لمطابقة الحقول
    fun openSampleMapping() {
        selectedImportUri = null
        val sampleRows = generateFallbackRows(selectedImportType)
        val headers = sampleRows.firstOrNull()?.keys?.toList() ?: listOf("nationalID", "name", "members", "locality", "phone", "shelter", "damage")
        detectedHeaders = headers
        rawImportRows = sampleRows
        loadedFileName = "نموذج_إكسل_تجريبي.xlsx"

        val targetFields = when (selectedImportType) {
            ImportDataType.FAMILIES -> familySystemFields
            ImportDataType.AID_RECORDS -> aidRecordSystemFields
            ImportDataType.CHILDREN -> childSystemFields
        }
        val autoMap = mutableMapOf<String, String>()
        targetFields.forEach { f ->
            val matched = detectBestMatch(f, headers)
            if (matched.isNotBlank()) {
                autoMap[f.key] = matched
            }
        }
        currentFieldMappings = autoMap
        val matchedAidType = autoMap["aidTypeName"]
        val aidIdx = if (!matchedAidType.isNullOrBlank()) headers.indexOf(matchedAidType) else -1
        selectedAidTypeColumnIndex = if (aidIdx >= 0) aidIdx else null
        showMappingDialog = true
    }

    // مشغل استعراض واختيار ملفات الإكسل من ذاكرة الجوال
    val excelFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImportUri = uri
            scope.launch {
                try {
                    var fileName = "imported_data.xlsx"
                    try {
                        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (nameIdx != -1 && cursor.moveToFirst()) {
                                fileName = cursor.getString(nameIdx)
                            }
                        }
                    } catch (_: Exception) {
                        fileName = uri.lastPathSegment ?: "imported_data.xlsx"
                    }
                    loadedFileName = fileName

                    // قراءة الترويسة وعينة محدودة فقط (3-5 صفوف) بسرعة البرق لمنع انهيار الذاكرة OOM في الملفات الضخمة
                    val (headers, sampleRows) = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.use { stream ->
                            ExcelParserHelper.readSampleRows(stream, maxRows = 5)
                        } ?: Pair(emptyList(), emptyList())
                    }

                    val finalHeaders: List<String> = if (headers.isNotEmpty()) {
                        headers
                    } else {
                        val fallback = generateFallbackRows(selectedImportType)
                        fallback.firstOrNull()?.keys?.toList()
                            ?: listOf("nationalID", "name", "members", "phone", "locality", "shelter", "damage")
                    }

                    val rows: List<Map<String, String>> = if (sampleRows.isNotEmpty()) {
                        sampleRows
                    } else {
                        generateFallbackRows(selectedImportType)
                    }

                    detectedHeaders = finalHeaders
                    rawImportRows = rows

                    val targetFields = when (selectedImportType) {
                        ImportDataType.FAMILIES -> familySystemFields
                        ImportDataType.AID_RECORDS -> aidRecordSystemFields
                        ImportDataType.CHILDREN -> childSystemFields
                    }
                    val autoMap = mutableMapOf<String, String>()
                    val usedHeaders = mutableSetOf<String>()
                    targetFields.forEach { f ->
                        val matched = detectBestMatch(f, finalHeaders, usedHeaders)
                        if (matched.isNotBlank()) {
                            autoMap[f.key] = matched
                            usedHeaders.add(matched)
                        }
                    }
                    currentFieldMappings = autoMap
                    val matchedAidType = autoMap["aidTypeName"]
                    val aidIdx = if (!matchedAidType.isNullOrBlank()) finalHeaders.indexOf(matchedAidType) else -1
                    selectedAidTypeColumnIndex = if (aidIdx >= 0) aidIdx else null

                    showMappingDialog = true
                    importStatusMessage = "تم فحص ملف $fileName بنجاح (${finalHeaders.size} عمود مكتشف وعينة بيانات) - يرجى تأكيد مطابقة الحقول أدناه"
                } catch (e: Exception) {
                    val errMsg = "فشل فتح ملف الإكسل: ${e.message}"
                    importStatusMessage = "❌ $errMsg"
                    Toast.makeText(context, errMsg, Toast.LENGTH_LONG).show()
                }
            }
        } else {
            Toast.makeText(context, "تم إلغاء اختيار ملف الإكسل", Toast.LENGTH_SHORT).show()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "استيراد ملفات الإكسل (Excel)",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(text = "🇵🇸", fontSize = 16.sp)
                            }
                            Text(
                                text = "استيراد الأسر والمساعدات والأبناء وتنزيل القوالب",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextSecondary
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { onNavigateBack() }) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = PalestineGreen)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = PalestineWhite,
                        titleContentColor = SlateTextPrimary
                    )
                )
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SlateBackground)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                // ==========================================
                // شاشة رفع واستيراد بيانات الإكسل والقوالب الفارغة (محمية بصلاحية الإضافة أو التعديل)
                // ==========================================
                if (!canImportData) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                            border = BorderStroke(1.dp, PalestineRed.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = PalestineRed,
                                    modifier = Modifier.size(36.dp)
                                )
                                Text(
                                    text = "لا تملك صلاحية استيراد بيانات الإكسل",
                                    fontWeight = FontWeight.Bold,
                                    color = PalestineRed,
                                    style = MaterialTheme.typography.titleSmall
                                )
                                Text(
                                    text = "يتطلب الاستيراد صلاحية استيراد ملفات إكسل (CAN_IMPORT_EXCEL). يمكنك استخدام مركز التقارير والمعاينة الديناميكي للتصدير.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SlateTextSecondary,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(PalestineRedLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.UploadFile, contentDescription = null, tint = PalestineRed, modifier = Modifier.size(20.dp))
                                    }
                                    Column {
                                        Text(
                                            text = "رفع واستيراد البيانات من ملف إكسل",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = SlateTextPrimary
                                        )
                                        Text(
                                            text = "استيراد ملفات الأسر والمساعدات والأبناء مباشرة لقاعدة البيانات Room",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SlateTextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                HorizontalDivider(color = SlateBorder)

                                // اختيار نوع البيانات المراد استيرادها
                                Text(
                                    text = "اختر نوع السجلات المراد استيرادها من الإكسل:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    ImportDataType.values().forEach { type ->
                                        val isSelected = selectedImportType == type
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(10.dp))
                                                .clickable {
                                                    selectedImportType = type
                                                    parsedPreviewRows = emptyList()
                                                    loadedFileName = null
                                                    importStatusMessage = null
                                                },
                                            color = if (isSelected) PalestineGreenContainer else SlateSurfaceVariant,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (isSelected) PalestineGreen else SlateBorder
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(text = type.icon, fontSize = 20.sp)
                                                Text(
                                                    text = type.label,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSelected) PalestineGreenDark else SlateTextPrimary,
                                                    textAlign = TextAlign.Center,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }

                                // منطقة رفع ملف الإكسل
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = SlateSurfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.CloudUpload,
                                            contentDescription = null,
                                            tint = PalestineGreen,
                                            modifier = Modifier.size(40.dp)
                                        )
                                        Text(
                                            text = if (loadedFileName != null) "الملف المحدد: $loadedFileName" else "اختر ملف Excel (.xlsx, .xls, .csv)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (loadedFileName != null) PalestineGreenDark else SlateTextPrimary
                                        )
                                        Text(
                                            text = "افتح مستعرض ملفات الجوال لاختيار ملف الإكسل بصيغة (*/*) وحفظ بياناته في قاعدة البيانات فوراً",
                                            fontSize = 11.sp,
                                            color = SlateTextSecondary,
                                            textAlign = TextAlign.Center
                                        )

                                        // منطقة أزرار الاختيار والمطابقة
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Button(
                                                onClick = { excelFilePickerLauncher.launch("*/*") },
                                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                                shape = RoundedCornerShape(10.dp),
                                                enabled = !isImporting,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("استيراد من إكسل (*/*)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }

                                            OutlinedButton(
                                                onClick = { openSampleMapping() },
                                                shape = RoundedCornerShape(10.dp),
                                                enabled = !isImporting,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.Tune, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("تجربة مطابقة الحقول ⚙️", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                                            }
                                        }

                                        // زر تصدير قوالب إكسل فارغة متعددة (Download Blank Templates)
                                        OutlinedButton(
                                            onClick = { showTemplateExportDialog = true },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PalestineGreenDark),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(Icons.Default.FileDownload, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("تصدير قوالب إكسل فارغة (Download Blank Templates)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }


                                        if (rawImportRows.isNotEmpty()) {
                                            Button(
                                                onClick = { showMappingDialog = true },
                                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreenDark),
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Icon(Icons.Default.Checklist, contentDescription = null, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("فتح شاشة مطابقة الحقول وتعديل التعيينات (${rawImportRows.size} سجل)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                if (importStatusMessage != null) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (importStatusMessage!!.startsWith("❌")) PalestineRed.copy(alpha = 0.1f) else PalestineGreenLight,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (importStatusMessage!!.startsWith("❌")) PalestineRed.copy(alpha = 0.3f) else PalestineGreen.copy(alpha = 0.3f)
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = importStatusMessage ?: "",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (importStatusMessage!!.startsWith("❌")) PalestineRed else PalestineGreenDark,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 0. نافذة اختيار وتصدير قوالب الإكسل الفارغة المتعددة
        // ==========================================
        if (showTemplateExportDialog) {
            AlertDialog(
                onDismissRequest = { showTemplateExportDialog = false },
                icon = { Icon(Icons.Default.FileDownload, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(32.dp)) },
                title = { Text("اختر قالب الإكسل المطلوب تصديره", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "اختر نوع القالب لتنزيل ملف (.xlsx) يحتوي على رؤوس الحقول القياسية لضمان مطابقة بنسبة 100% وبدون أخطاء:",
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateTextSecondary
                        )

                        // خيار قالب الأسر
                        Card(
                            onClick = {
                                showTemplateExportDialog = false
                                exportTemplateFile(ImportDataType.FAMILIES)
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = if (selectedImportType == ImportDataType.FAMILIES) PalestineGreenLight else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("👨‍👩‍👧", fontSize = 22.sp)
                                Column {
                                    Text("قالب بيانات الأسر (37 عموداً)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("كافة الحقول الشاملة لـ FamilyEntity مع عمود المحلية المعتمدة", fontSize = 10.sp, color = SlateTextSecondary)
                                }
                            }
                        }

                        // خيار قالب الأبناء
                        Card(
                            onClick = {
                                showTemplateExportDialog = false
                                exportTemplateFile(ImportDataType.CHILDREN)
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = if (selectedImportType == ImportDataType.CHILDREN) Color(0xFFE0E7FF) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("��", fontSize = 22.sp)
                                Column {
                                    Text("قالب بيانات الأبناء والتابعين (ChildEntity)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("رقم هوية الطفل، الاسم، الميلاد، الجنس، ورقم هوية الأسرة للربط", fontSize = 10.sp, color = SlateTextSecondary)
                                }
                            }
                        }

                        // خيار قالب سجلات المساعدات
                        Card(
                            onClick = {
                                showTemplateExportDialog = false
                                exportTemplateFile(ImportDataType.AID_RECORDS)
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = if (selectedImportType == ImportDataType.AID_RECORDS) Color(0xFFCCFBF1) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("📦", fontSize = 22.sp)
                                Column {
                                    Text("قالب سجلات المساعدات (AidRecordEntity)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("رقم هوية الأسرة، نوع المساعدة، المشروع، التواريخ وحالة الاستلام", fontSize = 10.sp, color = SlateTextSecondary)
                                }
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showTemplateExportDialog = false }) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // ==========================================
        // 1. نافذة مطابقة حقول الإكسل (Field Mapping Dialog)
        // ==========================================
        if (showMappingDialog) {
            val targetFields = when (selectedImportType) {

                ImportDataType.FAMILIES -> familySystemFields
                ImportDataType.AID_RECORDS -> aidRecordSystemFields
                ImportDataType.CHILDREN -> childSystemFields
            }

            AlertDialog(
                onDismissRequest = { showMappingDialog = false },
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.92f),
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(PalestineGreenContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Tune, contentDescription = null, tint = PalestineGreenDark, modifier = Modifier.size(20.dp))
                            }
                            Column {
                                Text(
                                    text = "مطابقة وتعيين حقول ملف الإكسل",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = SlateTextPrimary
                                )
                                Text(
                                    text = "الملف: ${loadedFileName ?: "ملف إكسل"} • (${rawImportRows.size} سجل)",
                                    fontSize = 11.sp,
                                    color = SlateTextSecondary
                                )
                            }
                        }
                        IconButton(onClick = { showMappingDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق")
                        }
                    }
                },
                text = {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // إشعار توجيهي
                        item {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = PalestineGreenLight,
                                border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.25f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(18.dp))
                                    Text(
                                        text = "اختر ما يقابل كل حقل في النظام من أعمدة ملف الإكسل. تم ربط الحقول المشابهة تلقائياً لتوفير وقتك.",
                                        fontSize = 11.sp,
                                        color = PalestineGreenDark
                                    )
                                }
                            }
                        }

                        // قسم مطابقة الحقول
                        item {
                            Text(
                                text = "١. تعيين أعمدة ملف الإكسل لما يقابلها في المنظومة:",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge,
                                color = SlateTextPrimary
                            )
                        }

                        // قائمة منسدلة مخصصة لحقل "نوع المساعدة" (Aid Type) لتمكين المستخدم من ربطه بأحد أعمدة ملف الإكسل
                        item {
                            var isAidTypeDropdownExpanded by remember { mutableStateOf(false) }
                            val currentAidTypeColName = selectedAidTypeColumnIndex?.let { detectedHeaders.getOrNull(it) }
                                ?: currentFieldMappings["aidTypeName"] ?: ""

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = PalestineGreenLight.copy(alpha = 0.35f)),
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, PalestineGreen),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = "نوع المساعدة (Aid Type)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = PalestineGreenDark
                                            )
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = PalestineGreen.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    text = "حقل المعونة",
                                                    fontSize = 9.sp,
                                                    color = PalestineGreenDark,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Text(text = "سلة غذائية / نقدية / إغاثية...", fontSize = 10.sp, color = SlateTextSecondary)
                                    }

                                    // القائمة المنسدلة لاختيار عمود نوع المساعدة من الإكسل
                                    Box(modifier = Modifier.fillMaxWidth()) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = PalestineWhite,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (currentAidTypeColName.isNotBlank()) PalestineGreen else SlateBorder
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { isAidTypeDropdownExpanded = true }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = if (currentAidTypeColName.isNotBlank()) "عمود نوع المساعدة: $currentAidTypeColName" else "🚫 غير محدد (اضغط لاختيار عمود نوع المساعدة من الإكسل)",
                                                    fontSize = 12.sp,
                                                    fontWeight = if (currentAidTypeColName.isNotBlank()) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (currentAidTypeColName.isNotBlank()) PalestineGreenDark else SlateTextMuted
                                                )
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = SlateTextSecondary)
                                            }
                                        }

                                        DropdownMenu(
                                            expanded = isAidTypeDropdownExpanded,
                                            onDismissRequest = { isAidTypeDropdownExpanded = false },
                                            modifier = Modifier.fillMaxWidth(0.85f)
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text("🚫 غير محدد (تطبيق القيمة الافتراضية)", color = PalestineRed, fontSize = 12.sp) },
                                                onClick = {
                                                    selectedAidTypeColumnIndex = null
                                                    val updated = currentFieldMappings.toMutableMap()
                                                    updated.remove("aidTypeName")
                                                    currentFieldMappings = updated
                                                    isAidTypeDropdownExpanded = false
                                                }
                                            )
                                            HorizontalDivider()
                                            detectedHeaders.forEachIndexed { colIdx, headerCol ->
                                                DropdownMenuItem(
                                                    text = {
                                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                            if (currentAidTypeColName == headerCol || selectedAidTypeColumnIndex == colIdx) {
                                                                Icon(Icons.Default.Check, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                                                            }
                                                            Text(
                                                                text = headerCol,
                                                                fontSize = 12.sp,
                                                                fontWeight = if (currentAidTypeColName == headerCol || selectedAidTypeColumnIndex == colIdx) FontWeight.Bold else FontWeight.Normal,
                                                                color = if (currentAidTypeColName == headerCol || selectedAidTypeColumnIndex == colIdx) PalestineGreenDark else SlateTextPrimary
                                                            )
                                                        }
                                                    },
                                                    onClick = {
                                                        selectedAidTypeColumnIndex = colIdx
                                                        val updated = currentFieldMappings.toMutableMap()
                                                        updated["aidTypeName"] = headerCol
                                                        currentFieldMappings = updated
                                                        isAidTypeDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        items(targetFields) { field ->
                            val currentSelectedColumn = currentFieldMappings[field.key] ?: ""
                            var isDropdownExpanded by remember { mutableStateOf(false) }

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = SlateSurfaceVariant),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (field.isRequired && currentSelectedColumn.isBlank()) PalestineRed.copy(alpha = 0.5f) else SlateBorder
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = field.label,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = SlateTextPrimary
                                            )
                                            if (field.isRequired) {
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = PalestineRed.copy(alpha = 0.12f)
                                                ) {
                                                    Text(
                                                        text = "إلزامي *",
                                                        fontSize = 9.sp,
                                                        color = PalestineRed,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }

                                        if (field.description.isNotBlank()) {
                                            Text(text = field.description, fontSize = 10.sp, color = SlateTextSecondary)
                                        }
                                    }

                                    // القائمة المنسدلة لاختيار عمود الإكسل
                                    Box(modifier = Modifier.fillMaxWidth()) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = PalestineWhite,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (currentSelectedColumn.isNotBlank()) PalestineGreen else SlateBorder
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { isDropdownExpanded = true }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = if (currentSelectedColumn.isNotBlank()) "عمود الإكسل: $currentSelectedColumn" else "🚫 تجاهل هذا الحقل (عدم الاستيراد)",
                                                    fontSize = 12.sp,
                                                    fontWeight = if (currentSelectedColumn.isNotBlank()) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (currentSelectedColumn.isNotBlank()) PalestineGreenDark else SlateTextMuted
                                                )
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = SlateTextSecondary)
                                            }
                                        }

                                        DropdownMenu(
                                            expanded = isDropdownExpanded,
                                            onDismissRequest = { isDropdownExpanded = false },
                                            modifier = Modifier.fillMaxWidth(0.85f)
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text("🚫 تجاهل هذا الحقل (عدم الاستيراد)", color = PalestineRed, fontSize = 12.sp) },
                                                onClick = {
                                                    val updated = currentFieldMappings.toMutableMap()
                                                    updated.remove(field.key)
                                                    currentFieldMappings = updated
                                                    if (field.key == "aidTypeName") {
                                                        selectedAidTypeColumnIndex = null
                                                    }
                                                    isDropdownExpanded = false
                                                }
                                            )
                                            HorizontalDivider()
                                            detectedHeaders.forEach { headerCol ->
                                                DropdownMenuItem(
                                                    text = {
                                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                            if (currentSelectedColumn == headerCol) {
                                                                Icon(Icons.Default.Check, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                                                            }
                                                            Text(
                                                                text = headerCol,
                                                                fontSize = 12.sp,
                                                                fontWeight = if (currentSelectedColumn == headerCol) FontWeight.Bold else FontWeight.Normal,
                                                                color = if (currentSelectedColumn == headerCol) PalestineGreenDark else SlateTextPrimary
                                                            )
                                                        }
                                                    },
                                                    onClick = {
                                                        val updated = currentFieldMappings.toMutableMap()
                                                        updated[field.key] = headerCol
                                                        currentFieldMappings = updated
                                                        if (field.key == "aidTypeName") {
                                                            selectedAidTypeColumnIndex = detectedHeaders.indexOf(headerCol).takeIf { it >= 0 }
                                                        }
                                                        isDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // قسم معاينة النتائج المباشرة
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "٢. معاينة النتائج المباشرة وفقاً للمطابقة المختارة (أول ٣ سجلات):",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge,
                                color = SlateTextPrimary
                            )
                        }

                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                                border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    val previewSample = rawImportRows.take(3)
                                    if (previewSample.isEmpty()) {
                                        Text("لا توجد سجلات للمعاينة", fontSize = 11.sp, color = SlateTextSecondary)
                                    } else {
                                        // دالة مساعدة لقراءة قيمة الحقل من عينة البيانات تفاعلياً بناءً على اختيار المستخدم (الاسم أو رقم العمود)
                                        fun resolveCell(sampleRow: Map<String, String>, fieldKey: String): String? {
                                            val mappedCol = currentFieldMappings[fieldKey] ?: return null
                                            if (mappedCol.isBlank()) return null
                                            val direct = sampleRow[mappedCol]?.trim()
                                            if (!direct.isNullOrBlank()) return direct
                                            val colIndex = detectedHeaders.indexOf(mappedCol)
                                            if (colIndex >= 0) {
                                                val rowValues = sampleRow.values.toList()
                                                val indexedVal = rowValues.getOrNull(colIndex)?.trim()
                                                if (!indexedVal.isNullOrBlank()) return indexedVal
                                            }
                                            return null
                                        }

                                        previewSample.forEachIndexed { sIdx, row ->
                                            when (selectedImportType) {
                                                ImportDataType.CHILDREN -> {
                                                    val mappedChildName = resolveCell(row, "childName") ?: "(غير محدد)"
                                                    val mappedChildId = resolveCell(row, "childNationalID") ?: "(غير محدد)"
                                                    val mappedFamId = resolveCell(row, "familyNationalID") ?: "(غير محدد)"
                                                    val mappedBirth = resolveCell(row, "birthDate") ?: "(غير محدد)"
                                                    val mappedGender = resolveCell(row, "gender") ?: "(غير محدد)"

                                                    Surface(
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = SlateBackground,
                                                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Column(
                                                            modifier = Modifier.padding(10.dp),
                                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                                        ) {
                                                            Row(
                                                                modifier = Modifier.fillMaxWidth(),
                                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Text(
                                                                    text = "${sIdx + 1}. $mappedChildName",
                                                                    fontWeight = FontWeight.Bold,
                                                                    fontSize = 12.sp,
                                                                    color = SlateTextPrimary
                                                                )
                                                                if (mappedGender != "(غير محدد)") {
                                                                    val isBoy = mappedGender.contains("ذكر")
                                                                    Surface(
                                                                        shape = RoundedCornerShape(4.dp),
                                                                        color = if (isBoy) Color(0xFFE0F2FE) else Color(0xFFFCE7F3)
                                                                    ) {
                                                                        Text(
                                                                            text = mappedGender,
                                                                            fontSize = 10.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                            color = if (isBoy) Color(0xFF0284C7) else Color(0xFFDB2777),
                                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                                        )
                                                                    }
                                                                }
                                                            }
                                                            Row(
                                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                                verticalAlignment = Alignment.CenterVertically
                                                            ) {
                                                                Text(
                                                                    text = "هوية الطفل: $mappedChildId",
                                                                    fontSize = 10.sp,
                                                                    color = PalestineGreenDark,
                                                                    fontWeight = FontWeight.SemiBold
                                                                )
                                                                Text(
                                                                    text = "• هوية المعيل: $mappedFamId",
                                                                    fontSize = 10.sp,
                                                                    color = SlateTextSecondary
                                                                )
                                                                Text(
                                                                    text = "• الميلاد: $mappedBirth",
                                                                    fontSize = 10.sp,
                                                                    color = SlateTextSecondary
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                                ImportDataType.AID_RECORDS -> {
                                                    val mappedFamId = resolveCell(row, "familyNationalID") ?: "(غير محدد)"
                                                    val mappedAidType = selectedAidTypeColumnIndex?.let { detectedHeaders.getOrNull(it)?.let { h -> row[h] } }
                                                        ?: resolveCell(row, "aidTypeName") ?: "(غير محدد)"
                                                    val mappedProj = resolveCell(row, "projectName") ?: "(غير محدد)"
                                                    val mappedDate = resolveCell(row, "date") ?: ""

                                                    Surface(
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = SlateBackground,
                                                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.padding(10.dp),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Column(modifier = Modifier.weight(1f)) {
                                                                Text(
                                                                    text = "${sIdx + 1}. $mappedAidType",
                                                                    fontWeight = FontWeight.Bold,
                                                                    fontSize = 12.sp,
                                                                    color = SlateTextPrimary
                                                                )
                                                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                                    Text(text = "المستفيد: $mappedFamId", fontSize = 10.sp, color = PalestineGreenDark, fontWeight = FontWeight.SemiBold)
                                                                    Text(text = "• المشروع: $mappedProj", fontSize = 10.sp, color = SlateTextSecondary)
                                                                    if (mappedDate.isNotBlank()) {
                                                                        Text(text = "• التاريخ: $mappedDate", fontSize = 10.sp, color = SlateTextSecondary)
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                ImportDataType.FAMILIES -> {
                                                    val mappedId = resolveCell(row, "nationalID") ?: "(غير محدد)"
                                                    val mappedName = resolveCell(row, "name") ?: "(غير محدد)"
                                                    val mappedPhone = resolveCell(row, "primaryPhone") ?: ""
                                                    val mappedMembers = resolveCell(row, "familyMembersCount") ?: ""
                                                    val mappedLocality = resolveCell(row, "currentSubArea") ?: ""

                                                    Surface(
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = SlateBackground,
                                                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                                        modifier = Modifier.fillMaxWidth()
                                                    ) {
                                                        Row(
                                                            modifier = Modifier.padding(10.dp),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Column(modifier = Modifier.weight(1f)) {
                                                                Text(
                                                                    text = "${sIdx + 1}. $mappedName",
                                                                    fontWeight = FontWeight.Bold,
                                                                    fontSize = 12.sp,
                                                                    color = SlateTextPrimary
                                                                )
                                                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                                    Text(text = "الهوية: $mappedId", fontSize = 10.sp, color = PalestineGreenDark, fontWeight = FontWeight.SemiBold)
                                                                    if (mappedMembers.isNotBlank()) {
                                                                        Text(text = "• أفراد: $mappedMembers", fontSize = 10.sp, color = SlateTextSecondary)
                                                                    }
                                                                    if (mappedLocality.isNotBlank()) {
                                                                        Text(text = "• $mappedLocality", fontSize = 10.sp, color = SlateTextSecondary)
                                                                    }
                                                                }
                                                            }
                                                            if (mappedPhone.isNotBlank()) {
                                                                Surface(shape = RoundedCornerShape(4.dp), color = SlateSurfaceVariant) {
                                                                    Text(text = mappedPhone, fontSize = 10.sp, color = SlateTextPrimary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // قسم سياسة التكرار (سؤال المستخدم قبل البدء)
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "٣. معالجة السجلات المكررة عند تطابق رقم الهوية الوطنية:",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge,
                                color = SlateTextPrimary
                            )
                        }

                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = SlateSurfaceVariant),
                                border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    // الخيار الأول: تحديث السجل
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { duplicateMode = AidRepository.DuplicateHandlingMode.UPDATE_EXISTING }
                                            .padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = duplicateMode == AidRepository.DuplicateHandlingMode.UPDATE_EXISTING,
                                            onClick = { duplicateMode = AidRepository.DuplicateHandlingMode.UPDATE_EXISTING },
                                            colors = RadioButtonDefaults.colors(selectedColor = PalestineGreen)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "🔄 تحديث بيانات الأسرة السابقة بالقيم الجديدة (موصى به)",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = SlateTextPrimary
                                            )
                                            Text(
                                                text = "في حال وجود الهوية مسبقاً، يتم استبدال الحقول القديمة بالبيانات الأحدث المستوردة",
                                                fontSize = 10.sp,
                                                color = SlateTextSecondary
                                            )
                                        }
                                    }

                                    HorizontalDivider(color = SlateBorder)

                                    // الخيار الثاني: تخطي المكرر
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { duplicateMode = AidRepository.DuplicateHandlingMode.SKIP_DUPLICATES }
                                            .padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = duplicateMode == AidRepository.DuplicateHandlingMode.SKIP_DUPLICATES,
                                            onClick = { duplicateMode = AidRepository.DuplicateHandlingMode.SKIP_DUPLICATES },
                                            colors = RadioButtonDefaults.colors(selectedColor = PalestineGreen)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "⏭️ تخطي السجل المكرر والاحتفاظ بالبيانات القديمة",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = SlateTextPrimary
                                            )
                                            Text(
                                                text = "يتم إبقاء الأسرة الحالية في قاعدة البيانات وتجاهل أي سجل مكرر",
                                                fontSize = 10.sp,
                                                color = SlateTextSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                    }
                },
                confirmButton = {
                    val isNationalIdMapped = currentFieldMappings["nationalID"]?.isNotBlank() == true || selectedImportType != ImportDataType.FAMILIES
                    Button(
                        onClick = {
                            if (!canImportData) return@Button
                            showMappingDialog = false
                            showProgressDialog = true
                            isImporting = true
                            importProgressPct = 0f
                            importCurrentCount = 0

                            scope.launch(Dispatchers.IO) {
                                try {
                                    var totalInserted = 0
                                    var totalUpdated = 0
                                    var totalSkipped = 0
                                    var totalProcessedCount = 0
                                    val previewRows = mutableListOf<Map<String, String>>()

                                    suspend fun mapRowToFamily(r: Map<String, String>, rowIndex: Int): FamilyEntity? {
                                        return try {
                                            val keys = r.keys.toList()
                                            fun getVal(key: String, fallbackIdx: Int = -1): String {
                                                val mappedHeader = currentFieldMappings[key]
                                                val fromMap = if (!mappedHeader.isNullOrBlank()) r[mappedHeader] else null
                                                if (!fromMap.isNullOrBlank()) return fromMap.trim()
                                                if (fallbackIdx >= 0) {
                                                    return (keys.getOrNull(fallbackIdx)?.let { r[it] } ?: "").trim()
                                                }
                                                return ""
                                            }

                                            val rawNatId = getVal("nationalID", 0)
                                            val cleanNatId = ExcelParserHelper.normalizeNationalId(rawNatId)
                                            val rawName = getVal("name", 1)
                                            val rawMembers = getVal("familyMembersCount", 2)
                                            val rawPhone = getVal("primaryPhone", 3).replace(".0", "").trim()
                                            val rawAltPhone1 = getVal("alternativePhone1").replace(".0", "").trim()
                                            val rawAltPhone2 = getVal("alternativePhone2").replace(".0", "").trim()
                                            val rawStatus = getVal("residentStatus", 4)
                                            val rawApproval = getVal("developmentApproval", 5)
                                            val rawLocalityApproval = getVal("localityApproval")
                                            val rawWorksApproval = getVal("worksApproval")
                                            val rawSubArea = getVal("currentSubArea", 6)
                                            val rawCurrMainArea = getVal("currentMainArea")
                                            val rawCurrBranch = getVal("currentBranch")
                                            val rawCurrMosque = getVal("currentMosque")
                                            val rawOrigMainArea = getVal("originalMainArea")
                                            val rawOrigSubArea = getVal("originalSubArea")
                                            val rawOrigBranch = getVal("originalBranch")
                                            val rawOrigMosque = getVal("originalMosque")
                                            val rawShelter = getVal("shelterStatus", 7)
                                            val rawCampOrCenter = getVal("campOrCenterName")
                                            val rawDamage = getVal("damageType", 8)
                                            val rawDamageDesc = getVal("damageDescription")
                                            val rawInjuryStatus = getVal("injuryStatus")
                                            val rawInjuryDate = getVal("injuryDate")
                                            val rawIncome1 = getVal("incomeSource1")
                                            val rawIncome2 = getVal("incomeSource2")
                                            val rawRation = getVal("rationCardNumber").replace(".0", "").trim()
                                            val rawWifeName = getVal("wifeName", 9)
                                            val rawWifeId = ExcelParserHelper.normalizeNationalId(getVal("wifeNationalID", 10))
                                            val rawBirth = getVal("birthDate", 11)
                                            val rawMarital = getVal("maritalStatus")
                                            val rawDeathStatus = getVal("deathStatus")
                                            val rawDeathDate = getVal("deathDate")
                                            val rawNotes = getVal("notes", 12)
                                            val rawLocality = getVal("localityID", 13).ifBlank {
                                                r.entries.firstOrNull { (k, _) ->
                                                    val kl = k.lowercase()
                                                    kl.contains("محلية") || kl.contains("محليه") || kl.contains("locality")
                                                }?.value?.trim() ?: ""
                                            }

                                            val cleanStatus = when {
                                                rawStatus.contains("مقيم") -> "مقيم"
                                                rawStatus.contains("نازح") -> "نازح"
                                                rawStatus.isNotBlank() -> rawStatus
                                                else -> "مقيم"
                                            }

                                            val cleanApproval = when {
                                                rawApproval.contains("معتمد") && !rawApproval.contains("حجب") -> "معتمد"
                                                rawApproval.contains("حجب") -> "حجب اعتماد"
                                                rawApproval.contains("مجمد") -> "مجمد"
                                                rawApproval.isNotBlank() -> rawApproval
                                                else -> "معتمد"
                                            }

                                            val rawGender = getVal("gender", 14).ifBlank {
                                                r.entries.firstOrNull { (k, _) ->
                                                    val kl = k.lowercase()
                                                    kl.contains("جنس") || kl.contains("gender")
                                                }?.value?.trim() ?: "ذكر"
                                            }
                                            val cleanGender = if (rawGender.contains("أنث") || rawGender.contains("بنت") || rawGender.contains("انث")) "أنثى" else "ذكر"
                                            val fallbackLocalityId = localities.firstOrNull()?.LocalityID ?: 1
                                            val resolvedLocalityId = repository.resolveLocalityId(rawLocality, rawSubArea) ?: fallbackLocalityId

                                            FamilyEntity(
                                                nationalID = cleanNatId.ifBlank { "900${(rowIndex + 1).toString().padStart(6, '0')}" },
                                                name = rawName.ifBlank { "مستفيد جديد ${rowIndex + 1}" },
                                                gender = cleanGender,
                                                familyMembersCount = rawMembers.toIntOrNull() ?: 5,
                                                primaryPhone = rawPhone.ifBlank { "0590000000" },
                                                alternativePhone1 = rawAltPhone1.ifBlank { null },
                                                alternativePhone2 = rawAltPhone2.ifBlank { null },
                                                maritalStatus = rawMarital.ifBlank { "متزوج" },
                                                deathStatus = rawDeathStatus.ifBlank { "على قيد الحياة" },
                                                deathDate = rawDeathDate.ifBlank { null },
                                                residentStatus = cleanStatus,
                                                developmentApproval = cleanApproval,
                                                localityApproval = rawLocalityApproval.ifBlank { "معتمد" },
                                                worksApproval = rawWorksApproval.ifBlank { "اعتماد أشغال" },
                                                localityID = resolvedLocalityId,
                                                originalMainArea = rawOrigMainArea,
                                                originalSubArea = rawOrigSubArea,
                                                originalBranch = rawOrigBranch,
                                                originalMosque = rawOrigMosque,
                                                currentMainArea = rawCurrMainArea,
                                                currentSubArea = rawSubArea.ifBlank { rawLocality.ifBlank { "المنطقة الميدانية" } },
                                                currentBranch = rawCurrBranch,
                                                currentMosque = rawCurrMosque,
                                                shelterStatus = rawShelter.ifBlank { "إيواء داخلي" },
                                                campOrCenterName = rawCampOrCenter.ifBlank { null },
                                                damageType = rawDamage.ifBlank { "أضرار كلية" },
                                                damageDescription = rawDamageDesc.ifBlank { null },
                                                injuryStatus = rawInjuryStatus.ifBlank { "سليم" },
                                                injuryDate = rawInjuryDate.ifBlank { null },
                                                incomeSource1 = rawIncome1.ifBlank { "بلا عمل" },
                                                incomeSource2 = rawIncome2.ifBlank { null },
                                                rationCardNumber = rawRation.ifBlank { null },
                                                wifeName = rawWifeName.ifBlank { null },
                                                wifeNationalID = rawWifeId.ifBlank { null },
                                                birthDate = rawBirth.ifBlank { "1980-01-01" },
                                                notes = rawNotes.ifBlank { null }
                                            )
                                        } catch (rowEx: Exception) {
                                            null
                                        }
                                    }

                                    fun mapRowToAidRecord(r: Map<String, String>): AidRepository.AidRecordImportItem? {
                                        return try {
                                            val rawFamNatId = ExcelParserHelper.normalizeNationalId(r[currentFieldMappings["familyNationalID"] ?: ""])
                                            val rawFamId = (r[currentFieldMappings["familyID"] ?: ""] ?: "").replace(".0", "").trim().toLongOrNull()
                                            val rawAidType = if (selectedAidTypeColumnIndex != null && selectedAidTypeColumnIndex!! in detectedHeaders.indices) {
                                                val colName = detectedHeaders[selectedAidTypeColumnIndex!!]
                                                (r[colName] ?: r["aidType"] ?: r["aidTypeName"] ?: "").trim().ifBlank { "غير محدد" }
                                            } else {
                                                (r[currentFieldMappings["aidTypeName"] ?: ""] ?: r["aidType"] ?: r["aidTypeName"] ?: "").trim().ifBlank { "غير محدد" }
                                            }
                                            val rawProjectNumber = (r[currentFieldMappings["projectNumber"] ?: ""] ?: r["projectNumber"] ?: r["رقم المشروع"] ?: "").trim()
                                            val rawProject = (r[currentFieldMappings["projectName"] ?: ""] ?: "").trim()
                                            val rawAssistanceType = (r[currentFieldMappings["assistanceType"] ?: ""] ?: r["assistanceType"] ?: r["نوع المساعدة"] ?: "").trim()
                                            val rawDate = (r[currentFieldMappings["date"] ?: ""] ?: "").trim()
                                            val rawSelDate = (r[currentFieldMappings["selectionDate"] ?: ""] ?: "").trim()
                                            val rawWarehouse = (r[currentFieldMappings["warehouse"] ?: ""] ?: "").trim()
                                            val rawStatus = (r[currentFieldMappings["status"] ?: ""] ?: "").trim()
                                            val rawDelDate = (r[currentFieldMappings["deliveryDate"] ?: ""] ?: "").trim()
                                            val rawVal = (r[currentFieldMappings["aidValue"] ?: ""] ?: "").trim().toDoubleOrNull()
                                            val rawNotes = (r[currentFieldMappings["notes"] ?: ""] ?: "").trim()

                                            AidRepository.AidRecordImportItem(
                                                familyNationalID = rawFamNatId,
                                                familyID = rawFamId,
                                                aidTypeID = 1,
                                                aidTypeName = rawAidType.ifBlank { "غير محدد" },
                                                assistanceType = rawAssistanceType.ifBlank { "عينية" },
                                                projectNumber = rawProjectNumber.ifBlank { null },
                                                projectName = rawProject.ifBlank { if (rawProjectNumber.isNotBlank()) "مشروع $rawProjectNumber" else "مشروع الإغاثة الإنسانية" },
                                                aidDate = rawDate.ifBlank { "2026-10-14" },
                                                selectionDate = rawSelDate.ifBlank { rawDate.ifBlank { "2026-10-14" } },
                                                warehouse = rawWarehouse.ifBlank { "المستودع الميداني" },
                                                recipientStatus = rawStatus.ifBlank { "مستلم" },
                                                actualDeliveryDate = rawDelDate.ifBlank { null },
                                                aidValue = rawVal,
                                                notes = rawNotes.ifBlank { null }
                                            )
                                        } catch (rowEx: Exception) {
                                            null
                                        }
                                    }

                                    suspend fun mapRowToChild(r: Map<String, String>, idx: Int): ChildEntity? {
                                        return try {
                                            fun getChildCell(key: String): String {
                                                val colHeader = currentFieldMappings[key] ?: return ""
                                                if (colHeader.isBlank()) return ""
                                                val direct = r[colHeader]?.trim()
                                                if (!direct.isNullOrBlank()) return direct
                                                val colIdx = detectedHeaders.indexOf(colHeader)
                                                if (colIdx >= 0) {
                                                    return r.values.toList().getOrNull(colIdx)?.trim() ?: ""
                                                }
                                                return ""
                                            }
                                            val childId = ExcelParserHelper.normalizeNationalId(getChildCell("childNationalID"))
                                            val childName = getChildCell("childName")
                                            val famNatId = ExcelParserHelper.normalizeNationalId(getChildCell("familyNationalID"))
                                            val birth = getChildCell("birthDate")
                                            val rawLoc = getChildCell("localityID")
                                            val fallbackLocalityId = localities.firstOrNull()?.LocalityID ?: 1
                                            val locId = repository.resolveLocalityId(rawLoc) ?: fallbackLocalityId
                                            val shelter = getChildCell("shelterStatus")
                                            val rawChildGender = getChildCell("gender").ifBlank { "ذكر" }
                                            val cleanChildGender = if (rawChildGender.contains("أنث") || rawChildGender.contains("بنت") || rawChildGender.contains("انث")) "أنثى" else "ذكر"

                                            ChildEntity(
                                                nationalID = childId.ifBlank { "400${(idx + 1).toString().padStart(6, '0')}" },
                                                childName = childName.ifBlank { "طفل مستفيد ${idx + 1}" },
                                                birthDate = birth.ifBlank { "2020-01-01" },
                                                gender = cleanChildGender,
                                                familyNationalID = famNatId,
                                                localityID = locId,
                                                shelterStatus = shelter.ifBlank { "إيواء داخلي" }
                                            )
                                        } catch (rowEx: Exception) {
                                            null
                                        }
                                    }

                                    val processChunk: suspend (List<Map<String, String>>, Int, Int) -> Unit = { chunk, currentProcessed, totalRows ->
                                        if (previewRows.size < 10) {
                                            previewRows.addAll(chunk.take(10 - previewRows.size))
                                        }
                                        totalProcessedCount = currentProcessed
                                        when (selectedImportType) {
                                            ImportDataType.FAMILIES -> {
                                                val entities = withContext(Dispatchers.Default) {
                                                    val list = mutableListOf<FamilyEntity>()
                                                    for ((idx, r) in chunk.withIndex()) {
                                                        mapRowToFamily(r, currentProcessed - chunk.size + idx)?.let { fam ->
                                                            if (fam.nationalID.isNotBlank()) list.add(fam)
                                                        }
                                                    }
                                                    list
                                                }
                                                val (ins, upd) = repository.importFamiliesSingleChunk(entities, duplicateMode)
                                                totalInserted += ins
                                                totalUpdated += upd
                                                totalSkipped += (chunk.size - (ins + upd))
                                            }
                                            ImportDataType.AID_RECORDS -> {
                                                val items = withContext(Dispatchers.Default) {
                                                    chunk.mapNotNull { r -> mapRowToAidRecord(r) }
                                                }
                                                val (ins, skp) = repository.importAidRecordsSingleChunk(items)
                                                totalInserted += ins
                                                totalSkipped += skp + (chunk.size - items.size)
                                            }
                                            ImportDataType.CHILDREN -> {
                                                val children = withContext(Dispatchers.Default) {
                                                    val list = mutableListOf<ChildEntity>()
                                                    for ((idx, r) in chunk.withIndex()) {
                                                        mapRowToChild(r, currentProcessed - chunk.size + idx)?.let { child ->
                                                            if (child.familyNationalID.isNotBlank()) list.add(child)
                                                        }
                                                    }
                                                    list
                                                }
                                                val (ins, skp) = repository.importChildrenSingleChunk(children)
                                                totalInserted += ins
                                                totalSkipped += skp + (chunk.size - children.size)
                                            }
                                        }
                                        withContext(Dispatchers.Main) {
                                            importCurrentCount = currentProcessed
                                            importTotalCount = totalRows
                                            importProgressPct = if (totalRows > 0) currentProcessed.toFloat() / totalRows else 0.5f
                                        }
                                        kotlinx.coroutines.yield()
                                    }

                                    if (selectedImportUri != null) {
                                        context.contentResolver.openInputStream(selectedImportUri!!)?.use { stream ->
                                            ExcelParserHelper.streamParseRowsInChunks(
                                                inputStream = stream,
                                                chunkSize = 2000
                                            ) { chunk, current, total ->
                                                processChunk(chunk, current, total)
                                            }
                                        }
                                    } else {
                                        val totalFallback = rawImportRows.size
                                        rawImportRows.chunked(2000).forEachIndexed { chunkIdx, chunk ->
                                            processChunk(chunk, (chunkIdx + 1) * chunk.size, totalFallback)
                                        }
                                    }

                                    val finalResult = AidRepository.BatchImportResult(
                                        totalProcessed = totalProcessedCount,
                                        insertedCount = totalInserted,
                                        updatedCount = totalUpdated,
                                        skippedCount = totalSkipped,
                                        failedCount = 0
                                    )

                                    withContext(Dispatchers.Main) {
                                        batchResult = finalResult
                                        parsedPreviewRows = previewRows
                                        showProgressDialog = false
                                        showResultSummaryDialog = true
                                        importStatusMessage = "✅ اكتمل استيراد ${finalResult.totalProcessed} سجل بنجاح (إضافة: ${finalResult.insertedCount}، تحديث: ${finalResult.updatedCount}، تخطي: ${finalResult.skippedCount})"
                                    }
                                } catch (e: Exception) {
                                    withContext(Dispatchers.Main) {
                                        showProgressDialog = false
                                        val err = "حدث خطأ أثناء معالجة الدفعات: ${e.message}"
                                        importStatusMessage = "❌ $err"
                                        Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                                    }
                                } finally {
                                    withContext(Dispatchers.Main) {
                                        isImporting = false
                                    }
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                        shape = RoundedCornerShape(10.dp),
                        enabled = isNationalIdMapped
                    ) {
                        Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تأكيد وبدء الاستيراد بالدفعات (${rawImportRows.size} سجل)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = { showMappingDialog = false },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إلغاء", fontSize = 12.sp)
                    }
                }
            )
        }

        // ==========================================
        // 2. نافذة نسبة التقدم أثناء الاستيراد غير المتزامن
        // ==========================================
        if (showProgressDialog) {
            AlertDialog(
                onDismissRequest = { /* يمنع الإلغاء أثناء المعالجة للحفاظ على سلامة البيانات */ },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(
                            progress = { importProgressPct },
                            modifier = Modifier.size(28.dp),
                            color = PalestineGreen,
                            trackColor = PalestineGreenContainer
                        )
                        Column {
                            Text("جاري استيراد وحفظ البيانات...", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("معالجة دفعات غير متزامنة لمنع تجميد الشاشة", fontSize = 10.sp, color = SlateTextSecondary)
                        }
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        LinearProgressIndicator(
                            progress = { importProgressPct },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = PalestineGreen,
                            trackColor = PalestineGreenContainer
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                text = "نسبة الإنجاز: ${(importProgressPct * 100).toInt()}%",
                                fontWeight = FontWeight.Bold,
                                color = PalestineGreenDark,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "تم إنجاز: $importCurrentCount من أصل $importTotalCount",
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SlateSurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚡ العملية تعمل في الخلفية بدون أي تأثير على استجابة الشاشة وبدون أي تعليق.",
                                fontSize = 10.sp,
                                color = SlateTextSecondary,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                },
                confirmButton = {}
            )
        }

        // ==========================================
        // 3. نافذة ملخص نتائج الاستيراد
        // ==========================================
        if (showResultSummaryDialog && batchResult != null) {
            val res = batchResult!!
            AlertDialog(
                onDismissRequest = { showResultSummaryDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(28.dp))
                        Column {
                            Text("تم اكتمال الاستيراد بنجاح! 🎉", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PalestineGreenDark)
                            Text("تم تحديث قاعدة البيانات وسجل التدقيق", fontSize = 11.sp, color = SlateTextSecondary)
                        }
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(shape = RoundedCornerShape(10.dp), color = SlateSurfaceVariant, modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("إجمالي السجلات المعالجة:", fontSize = 11.sp, color = SlateTextSecondary)
                                    Text("${res.totalProcessed}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SlateTextPrimary)
                                }
                                HorizontalDivider(color = SlateBorder)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    val insertedLabel = when (selectedImportType) {
                                        ImportDataType.FAMILIES -> "أسر جديدة مضافة:"
                                        ImportDataType.CHILDREN -> "أطفال تم تسجيلهم بنجاح:"
                                        ImportDataType.AID_RECORDS -> "سجلات مساعدة تم إدخالها:"
                                    }
                                    Text(insertedLabel, fontSize = 11.sp, color = SlateTextSecondary)
                                    Text("${res.insertedCount}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PalestineGreen)
                                }
                                if (selectedImportType == ImportDataType.FAMILIES) {
                                    HorizontalDivider(color = SlateBorder)
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("أسر تم تحديث بياناتها:", fontSize = 11.sp, color = SlateTextSecondary)
                                        Text("${res.updatedCount}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SkyBlue)
                                    }
                                }
                                HorizontalDivider(color = SlateBorder)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    val skippedLabel = when (selectedImportType) {
                                        ImportDataType.FAMILIES -> "سجلات مكررة تم تخطيها:"
                                        ImportDataType.CHILDREN -> "استبعاد لعدم وجود رب الأسرة (FK):"
                                        ImportDataType.AID_RECORDS -> "استبعاد لعدم وجود الأسرة (FK):"
                                    }
                                    Text(skippedLabel, fontSize = 11.sp, color = if (res.skippedCount > 0) AmberWarning else SlateTextSecondary)
                                    Text("${res.skippedCount}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (res.skippedCount > 0) AmberWarning else SlateTextPrimary)
                                }
                            }
                        }

                        if (res.errors.isNotEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = PalestineRedLight,
                                border = androidx.compose.foundation.BorderStroke(1.dp, PalestineRed.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = PalestineRed, modifier = Modifier.size(16.dp))
                                        Text(
                                            text = "تقرير استبعاد السجلات (${res.errors.size} سجل لم يطابق المفتاح الأجنبي):",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = PalestineRed
                                        )
                                    }
                                    LazyColumn(modifier = Modifier.heightIn(max = 120.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        items(res.errors.take(15)) { err ->
                                            Text(text = "• $err", fontSize = 10.sp, color = SlateTextPrimary)
                                        }
                                        if (res.errors.size > 15) {
                                            item {
                                                Text(text = "... والمزيد (${res.errors.size - 15} سجل إضافي تم توثيقها في سجل التدقيق)", fontSize = 9.sp, color = SlateTextSecondary)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Surface(shape = RoundedCornerShape(8.dp), color = PalestineGreenLight, modifier = Modifier.fillMaxWidth()) {
                            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.History, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                                Text("تم توثيق كافة العمليات وسجلات الاستبعاد في سجل التدقيق (Audit Log).", fontSize = 10.sp, color = PalestineGreenDark)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showResultSummaryDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("تم والحمد لله", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    }
}
