package com.humanitarian.aidmanagement.ui.screens.dashboard

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.data.local.entities.FamilyComplaintEntity
import com.humanitarian.aidmanagement.util.AidCategoryCatalog
import org.json.JSONObject

private val RadarEmerald = Color(0xFF0F7B53)
private val RadarAmber = Color(0xFFD97706)
private val RadarCrimson = Color(0xFFDC2626)
private val RadarSlateDark = Color(0xFF0F172A)
private val RadarSlateMuted = Color(0xFF64748B)
private val RadarSurfaceTint = Color(0xFFF6FAF8)
private val RadarCardSelected = Color(0xFFEAF7F1)
private val RadarBorder = Color(0xFFD7E6DF)

data class ForgottenFamilyItem(
    val familyId: String,
    val headName: String,
    val nationalId: String,
    val subRegion: String,
    val status: String,
    val daysSinceLastAid: Int,
    val lastAidDateText: String
) {
    /**
     * تحويل عنصر الأسرة المنسية إلى كيان شكوى مفتوحة متوافق مع FamilyComplaintEntity.
     */
    fun toComplaintEntity(
        targetAidCategory: String,
        createdAt: Long = System.currentTimeMillis()
    ): FamilyComplaintEntity {
        val reason = if (daysSinceLastAid < 0) {
            "رادار الأسر المنسية: لم تستلم الأسرة أي معونة مسجلة سابقاً"
        } else {
            "رادار الأسر المنسية: انقطاع عن استلام المعونات منذ $daysSinceLastAid يوم (آخر استلام: $lastAidDateText)"
        }
        return FamilyComplaintEntity(
            familyId = nationalId.ifBlank { familyId },
            familyName = headName,
            localArea = subRegion,
            complaintReason = reason,
            targetAidCategory = AidCategoryCatalog.cleanName(targetAidCategory).ifBlank { "غذائي" },
            status = FamilyComplaintEntity.STATUS_OPEN,
            createdAt = createdAt,
            nominatedProjectName = null
        )
    }
}

/**
 * مخزن تأجيل مؤقت للأسر المنسية في SharedPreferences لمدة 30 يوماً دون حذفها من النظام.
 */
object ForgottenRadarSnoozeStore {
    private const val PREFS_NAME = "forgotten_families_radar_snooze_prefs"
    private const val KEY_SNOOZE_MAP_JSON = "snoozed_national_ids_expiry_json"
    private const val SNOOZE_DURATION_MS = 30L * 24 * 60 * 60 * 1000

    fun snoozeFamilies(
        context: Context,
        nationalIds: Collection<String>
    ) {
        if (nationalIds.isEmpty()) return
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val expiresAt = now + SNOOZE_DURATION_MS

        val json = readCleanJson(prefs.getString(KEY_SNOOZE_MAP_JSON, null), now)
        for (rawId in nationalIds) {
            val normalized = normalizeIdKey(rawId)
            if (normalized.isNotBlank()) {
                json.put(normalized, expiresAt)
            }
        }
        prefs.edit().putString(KEY_SNOOZE_MAP_JSON, json.toString()).apply()
    }

    fun getActiveSnoozedIds(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_SNOOZE_MAP_JSON, null) ?: return emptySet()
        val now = System.currentTimeMillis()

        val activeIds = LinkedHashSet<String>()
        val cleaned = JSONObject()
        var hadExpired = false

        runCatching {
            val obj = JSONObject(raw)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val expiry = obj.optLong(key, 0L)
                if (expiry > now) {
                    cleaned.put(key, expiry)
                    activeIds.add(key)
                } else {
                    hadExpired = true
                }
            }
        }

        if (hadExpired) {
            prefs.edit().putString(KEY_SNOOZE_MAP_JSON, cleaned.toString()).apply()
        }

        return activeIds
    }

    fun clearAllSnoozes(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().remove(KEY_SNOOZE_MAP_JSON).apply()
    }

    private fun readCleanJson(raw: String?, now: Long): JSONObject {
        val cleaned = JSONObject()
        if (raw.isNullOrBlank()) return cleaned
        runCatching {
            val existing = JSONObject(raw)
            val keys = existing.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val expiry = existing.optLong(key, 0L)
                if (expiry > now) {
                    cleaned.put(key, expiry)
                }
            }
        }
        return cleaned
    }

    private fun normalizeIdKey(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return ""
        val sb = StringBuilder(trimmed.length)
        for (ch in trimmed) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }
}

/**
 * نافذة رادار الأسر المنسية والمنقطعة عن استلام المعونات باللغة العربية (RTL).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForgottenFamiliesRadarDialog(
    items: List<ForgottenFamilyItem>,
    selectedThresholdDays: Int,
    onThresholdChange: (Int) -> Unit,
    onSnoozeSelected: (List<String>) -> Unit,
    onTransferToComplaints: (List<ForgottenFamilyItem>, String) -> Unit,
    onDismiss: () -> Unit,
    availableCategories: List<String> = emptyList()
) {
    val thresholdOptions = remember { listOf(30, 60, 90, 120) }
    val allRegionsLabel = "كل المناطق"

    var searchQuery by remember { mutableStateOf("") }
    var selectedSubRegion by remember { mutableStateOf(allRegionsLabel) }
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showCategoryPickerDialog by remember { mutableStateOf(false) }

    val subRegionOptions = remember(items) {
        val distinctRegions = items
            .map { it.subRegion.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .sorted()
        listOf(allRegionsLabel) + distinctRegions
    }

    val effectiveSubRegion = if (selectedSubRegion in subRegionOptions) {
        selectedSubRegion
    } else {
        allRegionsLabel
    }

    val filteredSortedItems = remember(items, searchQuery, effectiveSubRegion) {
        val cleanQuery = normalizeSearchText(searchQuery)
        items
            .filter { item ->
                val matchesRegion = effectiveSubRegion == allRegionsLabel ||
                    item.subRegion.trim() == effectiveSubRegion
                val matchesQuery = cleanQuery.isBlank() ||
                    normalizeSearchText(item.headName).contains(cleanQuery) ||
                    normalizeSearchText(item.nationalId).contains(cleanQuery)
                matchesRegion && matchesQuery
            }
            .sortedWith(
                compareByDescending<ForgottenFamilyItem> { item ->
                    if (item.daysSinceLastAid < 0) Int.MAX_VALUE else item.daysSinceLastAid
                }.thenBy { it.headName }
            )
    }

    val visibleKeys = remember(filteredSortedItems) {
        filteredSortedItems.map { itemSelectionKey(it) }.toSet()
    }
    val selectedVisibleItems = remember(filteredSortedItems, selectedIds) {
        filteredSortedItems.filter { itemSelectionKey(it) in selectedIds }
    }
    val allVisibleSelected = visibleKeys.isNotEmpty() && visibleKeys.all { it in selectedIds }

    val aidCategories = remember(availableCategories) {
        AidCategoryCatalog.deduplicateCategoryNames(
            primaryNames = availableCategories,
            includeDefaults = true
        )
    }
    var selectedCategory by remember(aidCategories) {
        mutableStateOf(aidCategories.firstOrNull() ?: "غذائي")
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false),
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(vertical = 12.dp),
            title = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "رادار الأسر المنسية",
                            color = RadarSlateDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Surface(
                            color = RadarCrimson.copy(alpha = 0.12f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, RadarCrimson.copy(alpha = 0.28f))
                        ) {
                            Text(
                                text = "${filteredSortedItems.size} أسرة منقطعة",
                                color = RadarCrimson,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Text(
                        text = "رصد الأسر المنقطعة عن المعونات لأكثر من $selectedThresholdDays يوماً، مع إمكانية التأجيل المؤقت أو التحويل المباشر للشكاوى والأولويات.",
                        color = RadarSlateMuted,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // 1) شريط تبديل فترة الانقطاع (30 | 60 | 90 | 120 يوم)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "عتبة الانقطاع عن المعونات:",
                            color = RadarSlateDark,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(thresholdOptions) { days ->
                                val isSelected = selectedThresholdDays == days
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { onThresholdChange(days) },
                                    label = {
                                        Text(
                                            text = if (isSelected) "✓ $days يوم" else "$days يوم",
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = RadarEmerald.copy(alpha = 0.16f),
                                        selectedLabelColor = RadarEmerald
                                    )
                                )
                            }
                        }
                    }

                    // 2) شريط البحث السريع بالاسم أو الهوية
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("بحث سريع باسم رب الأسرة أو رقم الهوية", fontSize = 12.sp) },
                        placeholder = { Text("اكتب الاسم أو الهوية...", fontSize = 12.sp) },
                        trailingIcon = if (searchQuery.isNotBlank()) {
                            {
                                TextButton(onClick = { searchQuery = "" }) {
                                    Text("مسح", fontSize = 11.sp, color = RadarSlateMuted)
                                }
                            }
                        } else {
                            null
                        }
                    )

                    // 3) فلتر المنطقة المحلية (subRegion)
                    if (subRegionOptions.size > 1) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "تصفية حسب المنطقة المحلية:",
                                color = RadarSlateDark,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(subRegionOptions) { region ->
                                    val isSelected = effectiveSubRegion == region
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = { selectedSubRegion = region },
                                        label = {
                                            Text(
                                                text = region,
                                                fontSize = 11.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = RadarAmber.copy(alpha = 0.16f),
                                            selectedLabelColor = RadarAmber
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // 4) شريط التحديد الجماعي
                    Surface(
                        color = RadarSurfaceTint,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, RadarBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "المحدد: ${selectedVisibleItems.size} من ${filteredSortedItems.size}",
                                color = RadarSlateDark,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            TextButton(
                                enabled = filteredSortedItems.isNotEmpty(),
                                onClick = {
                                    selectedIds = if (allVisibleSelected) {
                                        selectedIds - visibleKeys
                                    } else {
                                        selectedIds + visibleKeys
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (allVisibleSelected) "إلغاء تحديد الكل" else "تحديد الكل",
                                    color = RadarEmerald,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // 5) قائمة الأسر المرتبة من الأكثر انقطاعاً
                    if (filteredSortedItems.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(150.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "لا توجد أسر منقطعة مطابقة للفترة أو معايير التصفية الحالية.",
                                color = RadarSlateMuted,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 160.dp, max = 320.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(
                                items = filteredSortedItems,
                                key = { itemSelectionKey(it) }
                            ) { item ->
                                val key = itemSelectionKey(item)
                                val isChecked = key in selectedIds
                                ForgottenFamilyRowCard(
                                    item = item,
                                    isChecked = isChecked,
                                    onToggle = {
                                        selectedIds = if (isChecked) {
                                            selectedIds - key
                                        } else {
                                            selectedIds + key
                                        }
                                    }
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(RadarBorder)
                    )

                    // 6) أزرار الإجراءات الجماعية
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showCategoryPickerDialog = true },
                            enabled = selectedVisibleItems.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = RadarEmerald),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "تحويل إلى قائمة الشكاوى والأولويات (${selectedVisibleItems.size})",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val idsToSnooze = selectedVisibleItems
                                        .map { it.nationalId.ifBlank { it.familyId } }
                                        .distinct()
                                    if (idsToSnooze.isNotEmpty()) {
                                        onSnoozeSelected(idsToSnooze)
                                        selectedIds = selectedIds - selectedVisibleItems.map { itemSelectionKey(it) }.toSet()
                                    }
                                },
                                enabled = selectedVisibleItems.isNotEmpty(),
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (selectedVisibleItems.isNotEmpty()) RadarAmber else RadarBorder
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "تأجيل مؤقت (30 يوم)",
                                    color = if (selectedVisibleItems.isNotEmpty()) RadarAmber else RadarSlateMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            TextButton(
                                onClick = onDismiss,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(
                                    text = "إغلاق",
                                    color = RadarSlateMuted,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // نافذة اختيار تصنيف المساعدة من AidCategoryCatalog قبل التحويل للشكاوى
    if (showCategoryPickerDialog) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = { showCategoryPickerDialog = false },
                title = {
                    Text(
                        text = "اختيار تصنيف المساعدة المستهدفة",
                        color = RadarSlateDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "سيتم تحويل ${selectedVisibleItems.size} أسرة إلى قائمة الشكاوى والأولويات ضمن التصنيف المحدد:",
                            color = RadarSlateMuted,
                            fontSize = 12.sp
                        )
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 260.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(aidCategories) { category ->
                                val isSelected = selectedCategory == category
                                Surface(
                                    color = if (isSelected) RadarCardSelected else Color.White,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) RadarEmerald else RadarBorder
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedCategory = category }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = category,
                                            color = if (isSelected) RadarEmerald else RadarSlateDark,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = 13.sp
                                        )
                                        if (isSelected) {
                                            Text(
                                                text = "✓ محدد",
                                                color = RadarEmerald,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val itemsToTransfer = selectedVisibleItems
                            if (itemsToTransfer.isNotEmpty()) {
                                onTransferToComplaints(itemsToTransfer, selectedCategory)
                                selectedIds = selectedIds - itemsToTransfer.map { itemSelectionKey(it) }.toSet()
                            }
                            showCategoryPickerDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RadarEmerald),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("تأكيد التحويل", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCategoryPickerDialog = false }) {
                        Text("إلغاء", color = RadarSlateMuted, fontSize = 12.sp)
                    }
                }
            )
        }
    }
}

@Composable
private fun ForgottenFamilyRowCard(
    item: ForgottenFamilyItem,
    isChecked: Boolean,
    onToggle: () -> Unit
) {
    val severityColor = when {
        item.daysSinceLastAid < 0 || item.daysSinceLastAid >= 90 -> RadarCrimson
        item.daysSinceLastAid >= 60 -> RadarAmber
        else -> RadarEmerald
    }
    val disconnectionLabel = if (item.daysSinceLastAid < 0) {
        "لم تستلم مسبقاً"
    } else {
        "منقطعة ${item.daysSinceLastAid} يوم"
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isChecked) RadarCardSelected else Color.White
        ),
        border = BorderStroke(
            width = if (isChecked) 1.5.dp else 1.dp,
            color = if (isChecked) RadarEmerald else RadarBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Checkbox(
                checked = isChecked,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(checkedColor = RadarEmerald)
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.headName.ifBlank { "بدون اسم" },
                        color = RadarSlateDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.padding(horizontal = 3.dp))
                    Surface(
                        color = severityColor.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, severityColor.copy(alpha = 0.3f))
                    ) {
                        Text(
                            text = disconnectionLabel,
                            color = severityColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = "هوية: ${item.nationalId.ifBlank { "-" }} • المنطقة: ${item.subRegion.ifBlank { "غير محددة" }}",
                    color = RadarSlateMuted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = "الحالة: ${item.status.ifBlank { "نشط" }} • آخر معونة: ${item.lastAidDateText.ifBlank { "لا يوجد" }}",
                    color = RadarSlateMuted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

private fun itemSelectionKey(item: ForgottenFamilyItem): String {
    return item.nationalId.trim().ifBlank { item.familyId.trim() }
}

private fun normalizeSearchText(raw: String): String {
    val trimmed = raw.trim().lowercase()
    if (trimmed.isBlank()) return ""
    val sb = StringBuilder(trimmed.length)
    for (ch in trimmed) {
        when (ch) {
            in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
            in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
            else -> sb.append(ch)
        }
    }
    return sb.toString()
}
