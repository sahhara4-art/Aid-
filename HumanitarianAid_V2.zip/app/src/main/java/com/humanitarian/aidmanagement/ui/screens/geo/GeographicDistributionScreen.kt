package com.humanitarian.aidmanagement.ui.screens.geo

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.PalestineNationalBanner
import com.humanitarian.aidmanagement.ui.theme.*

data class GeoSectorUiModel(
    val id: Int,
    val name: String,
    val code: String,
    val locality: String,
    val targetQuota: Int,
    val registeredCount: Int,
    val deliveredCount: Int,
    val shelterCount: Int,
    val destroyedHomes: Int,
    val warInjuries: Int,
    val warehouseName: String,
    val supervisorsCount: Int,
    val description: String,
    val accentColor: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeographicDistributionScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val currentUser = repository.currentUser
        val isSuperAdmin = repository.isSuperAdmin()

        // 5 Sub-Areas data model aligned with the system
        val subAreas = remember {
            listOf(
                GeoSectorUiModel(
                    id = 1,
                    name = "الرمال الشمالي",
                    code = "GZ-RML-N",
                    locality = "مدينة غزة",
                    targetQuota = 3500,
                    registeredCount = 3120,
                    deliveredCount = 1420,
                    shelterCount = 1890,
                    destroyedHomes = 640,
                    warInjuries = 310,
                    warehouseName = "مستودع الرمال الإغاثي الرئيسي (محيط مجمع الشفاء)",
                    supervisorsCount = 6,
                    description = "يضم شارع النصر، محيط مجمع الشفاء الطبي، وحي الميناء",
                    accentColor = PalestineGreen
                ),
                GeoSectorUiModel(
                    id = 2,
                    name = "الشيخ رضوان",
                    code = "GZ-SH-RDW",
                    locality = "مدينة غزة",
                    targetQuota = 4200,
                    registeredCount = 3950,
                    deliveredCount = 2180,
                    shelterCount = 2450,
                    destroyedHomes = 820,
                    warInjuries = 430,
                    warehouseName = "مستودع الشيخ رضوان المركزي (قرب البركة وجسر الجلاء)",
                    supervisorsCount = 8,
                    description = "مركزية توزيع كبرى تضم بئر النعجة ومحيط البركة وشارع النفق",
                    accentColor = SkyBlue
                ),
                GeoSectorUiModel(
                    id = 3,
                    name = "الشاطئ الشمالي والنصر",
                    code = "GZ-SHT-NSR",
                    locality = "مدينة غزة",
                    targetQuota = 3800,
                    registeredCount = 3410,
                    deliveredCount = 1540,
                    shelterCount = 2650,
                    destroyedHomes = 730,
                    warInjuries = 390,
                    warehouseName = "نقطة توزيع مخيم الشاطئ (مدرسة الوكالة المركزية)",
                    supervisorsCount = 5,
                    description = "كثافة سكانية ونزوح مرتفع - مخيم الشاطئ ومدارس الإيواء",
                    accentColor = PalestineRed
                ),
                GeoSectorUiModel(
                    id = 4,
                    name = "الشاطئ الجنوبي",
                    code = "GZ-SHT-SOU",
                    locality = "مدينة غزة",
                    targetQuota = 2900,
                    registeredCount = 2640,
                    deliveredCount = 1190,
                    shelterCount = 1420,
                    destroyedHomes = 490,
                    warInjuries = 220,
                    warehouseName = "نقطة توزيع الساحل الجنوبي (شارع الرشيد وميناء الصيادين)",
                    supervisorsCount = 4,
                    description = "الخط الساحلي الممتد جنوب ميناء غزة ومحاذاة وادي غزة",
                    accentColor = AmberWarning
                ),
                GeoSectorUiModel(
                    id = 5,
                    name = "مشروع عامر",
                    code = "GZ-PRJ-AMR",
                    locality = "شمال غزة",
                    targetQuota = 2200,
                    registeredCount = 1980,
                    deliveredCount = 920,
                    shelterCount = 1350,
                    destroyedHomes = 510,
                    warInjuries = 280,
                    warehouseName = "مستودع شمال غزة الإغاثي الميداني (محاذاة بيت لاهيا والندى)",
                    supervisorsCount = 3,
                    description = "منطقة حدودية شمالية مستهدفة ببرامج الإغاثة السريعة",
                    accentColor = PalestineBlack
                )
            )
        }

        var selectedSectorId by remember { mutableStateOf(1) }
        val activeSector = subAreas.find { it.id == selectedSectorId } ?: subAreas.first()
        var viewMode by remember { mutableStateOf("density") } // density, quota, warehouse

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "التوزيع الجغرافي للمستفيدين 🇵🇸",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )
                            }
                            Text(
                                "لوحة المؤشرات الجغرافية للمناطق الفرعية الـ 5",
                                style = MaterialTheme.typography.labelSmall,
                                color = SlateTextSecondary
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = SlateTextPrimary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PalestineWhite)
                )
            },
            containerColor = SlateBackground
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    PalestineNationalBanner()
                }

                // Summary KPIs Header Card
                item {
                    val totalReg = subAreas.sumOf { it.registeredCount }
                    val totalDel = subAreas.sumOf { it.deliveredCount }
                    val totalQuota = subAreas.sumOf { it.targetQuota }
                    val totalPct = if (totalQuota > 0) (totalDel * 100 / totalQuota) else 0

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(PalestineGreenContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Map, contentDescription = null, tint = PalestineGreenDark, modifier = Modifier.size(20.dp))
                                    }
                                    Column {
                                        Text("التوزيع الكلي في المحليات", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SlateTextPrimary)
                                        Text("تغطية 5 مناطق فرعية معتمدة", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary)
                                    }
                                }

                                Text(
                                    text = "$totalPct%",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = PalestineGreen
                                )
                            }

                            LinearProgressIndicator(
                                progress = { totalPct / 100f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = PalestineGreen,
                                trackColor = SlateBorder
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("إجمالي المسجلين: $totalReg أسرة", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary)
                                Text("المستلمون: $totalDel أسرة", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                                Text("الحصة الكلية: $totalQuota", style = MaterialTheme.typography.labelSmall, color = SlateTextMuted)
                            }
                        }
                    }
                }

                // Sector Selector Carousel
                item {
                    Text(
                        "اختر المنطقة الفرعية لمعاينة المؤشرات والكثافة:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = SlateTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(subAreas) { sector ->
                            val isSelected = sector.id == selectedSectorId
                            val pct = if (sector.targetQuota > 0) (sector.deliveredCount * 100 / sector.targetQuota) else 0

                            Card(
                                modifier = Modifier
                                    .width(160.dp)
                                    .clickable { selectedSectorId = sector.id },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) PalestineGreenContainer else PalestineWhite
                                ),
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, PalestineGreen) else androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
                            ) {
                                Column(
                                    modifier = Modifier.padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("#${sector.id}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PalestineGreen)
                                        Text("$pct%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                                    }
                                    Text(
                                        sector.name,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = SlateTextPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "${sector.registeredCount} أسرة مسجلة",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SlateTextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Active Sector Detailed Inspection Card
                item {
                    val activePct = if (activeSector.targetQuota > 0) (activeSector.deliveredCount * 100 / activeSector.targetQuota) else 0

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Sector Title Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .clip(CircleShape)
                                                .background(PalestineGreen),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("${activeSector.id}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                        Text(activeSector.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SlateTextPrimary)
                                    }
                                    Text("${activeSector.locality} • رمز المنطقة: ${activeSector.code}", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary)
                                }

                                Surface(
                                    color = PalestineGreenContainer,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "$activePct% إنجاز",
                                        color = PalestineGreenDark,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            // Progress Indicator
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                LinearProgressIndicator(
                                    progress = { activePct / 100f },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(5.dp)),
                                    color = PalestineGreen,
                                    trackColor = SlateBorder
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("المسلّم: ${activeSector.deliveredCount} أسرة", style = MaterialTheme.typography.labelSmall, color = PalestineGreenDark, fontWeight = FontWeight.SemiBold)
                                    Text("حصة المنطقة: ${activeSector.targetQuota}", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary)
                                }
                            }

                            HorizontalDivider(color = SlateBorder)

                            // 4 Analytical KPI Metric Pills
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Registered Families
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    color = SlateSurfaceVariant,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("الأسر المسجلة", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontSize = 10.sp)
                                        Text("${activeSector.registeredCount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SlateTextPrimary)
                                    }
                                }

                                // Shelters / Displaced
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    color = PalestineRedContainer,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("أسر الإيواء والنزوح", style = MaterialTheme.typography.labelSmall, color = PalestineRed, fontSize = 10.sp)
                                        Text("${activeSector.shelterCount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = PalestineRed)
                                    }
                                }
                            }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                // Destroyed Homes
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    color = SlateSurfaceVariant,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("منازل مهدمة كلياً", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontSize = 10.sp)
                                        Text("${activeSector.destroyedHomes}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = AmberWarning)
                                    }
                                }

                                // War Injuries
                                Surface(
                                    modifier = Modifier.weight(1f),
                                    color = SlateSurfaceVariant,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("حالات إصابات الحرب", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontSize = 10.sp)
                                        Text("${activeSector.warInjuries}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = PalestineBlack)
                                    }
                                }
                            }

                            // Warehouse and Distribution Point
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = PalestineGreenContainer,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Default.Store, contentDescription = null, tint = PalestineGreenDark, modifier = Modifier.size(24.dp))
                                    Column {
                                        Text("نقطة الصرف والمستودع الميداني:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                                        Text(activeSector.warehouseName, style = MaterialTheme.typography.bodySmall, color = SlateTextPrimary)
                                        Text("طاقم الإشراف الميداني: ${activeSector.supervisorsCount} مشرفين نشطين", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontSize = 10.sp)
                                    }
                                }
                            }

                            // Description of Geographic Zone
                            Text(
                                "نطاق المنطقة: ${activeSector.description}",
                                style = MaterialTheme.typography.labelSmall,
                                color = SlateTextSecondary,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(SlateSurfaceVariant, RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            )
                        }
                    }
                }

                // Sector Distribution Matrix Table
                item {
                    Text(
                        "مصفوفة التغطية الميدانية لكافة المناطق الفرعية:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = SlateTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            subAreas.forEach { sector ->
                                val pct = if (sector.targetQuota > 0) (sector.deliveredCount * 100 / sector.targetQuota) else 0

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedSectorId = sector.id }
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(20.dp)
                                                .clip(CircleShape)
                                                .background(if (sector.id == selectedSectorId) PalestineGreen else SlateBorder),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("${sector.id}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (sector.id == selectedSectorId) Color.White else SlateTextPrimary)
                                        }
                                        Column {
                                            Text(sector.name, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = SlateTextPrimary)
                                            Text("${sector.locality} • حصة ${sector.targetQuota}", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontSize = 10.sp)
                                        }
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("$pct%", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                                        Text("${sector.deliveredCount} مستلم", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontSize = 10.sp)
                                    }
                                }
                                if (sector.id != subAreas.last().id) {
                                    HorizontalDivider(color = SlateBorder)
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}
