package com.humanitarian.aidmanagement.ui.screens.geo

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.util.GeographicGapAnalyzer
import com.humanitarian.aidmanagement.util.SubRegionGapMetric
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

private val GeoScreenBg = Color(0xFFF6FAF8)
private val GeoCardBg = Color.White
private val GeoMintBg = Color(0xFFF0FDF4)
private val GeoCardBorder = Color(0xFFD1FAE5)
private val GeoSelectedBorder = Color(0xFF059669)
private val GeoPrimaryGreen = Color(0xFF059669)
private val GeoDarkGreen = Color(0xFF047857)
private val GeoTextPrimary = Color(0xFF0F172A)
private val GeoTextSecondary = Color(0xFF475569)
private val GeoBlueAccent = Color(0xFF0284C7)
private val GeoIndigoAccent = Color(0xFF4F46E5)
private val GeoAmberAccent = Color(0xFFD97706)
private val GeoRedAccent = Color(0xFFDC2626)

data class UnifiedLocalityGeoModel(
    val name: String,
    val eligibleCount: Int,
    val targetQuota: Int,
    val deliveredCount: Int,
    val sharePercentage: Double,
    val completionPct: Int
) {
    val formattedSharePercentage: String
        get() = String.format(Locale.US, "%.1f%%", sharePercentage)
}

data class DistinctSubAreaGeoItem(
    val name: String,
    val eligibleCount: Int,
    val deliveredCount: Int,
    val completionPct: Int
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeographicDistributionScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val currentUser by repository.currentUserFlow.collectAsStateWithLifecycle()

        // البيانات الحية المستخرجة حصراً من قاعدة البيانات ضمن النطاق الجغرافي (RLS)
        val localityShares by repository.getLocalityQuotaSharesRestrictedFlow().collectAsStateWithLifecycle(initialValue = emptyList())
        val totalSystemEligible by repository.countSystemEligibleFamiliesRestrictedFlow().collectAsStateWithLifecycle(initialValue = 0)
        var benefitRatios by remember { mutableStateOf<List<com.humanitarian.aidmanagement.data.repository.SubAreaBenefitRatioStat>>(emptyList()) }
        var localityStats by remember { mutableStateOf<List<com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat>>(emptyList()) }
        var isLoading by remember { mutableStateOf(true) }

        LaunchedEffect(currentUser) {
            isLoading = true
            val (ratios, stats) = withContext(Dispatchers.IO) {
                Pair(
                    repository.calculateSubAreaBenefitRatios(),
                    repository.getLocalityDistributionStats()
                )
            }
            benefitRatios = ratios
            localityStats = stats
            isLoading = false
        }

        // توحيد مصدر البيانات بالكامل ومنع تكرار المحليات وضمان تطابق الأرقام 100%
        val unifiedLocalities = remember(localityShares, benefitRatios, localityStats) {
            val rawAggregated = LinkedHashMap<String, Pair<Int, Int>>()

            if (localityShares.isNotEmpty()) {
                for (share in localityShares) {
                    val cleanName = share.localityName.trim()
                    if (cleanName.isBlank()) continue
                    val matchedRatio = benefitRatios.firstOrNull {
                        it.subAreaName.trim().equals(cleanName, ignoreCase = true)
                    }
                    val matchedStat = localityStats.firstOrNull { it.localityId == share.localityId }
                    val eligible = if (share.eligibleFamiliesCount > 0) {
                        share.eligibleFamiliesCount
                    } else {
                        matchedRatio?.eligibleFamiliesCount ?: 0
                    }
                    val ratioDelivered = matchedRatio?.deliveredBeneficiariesCount ?: 0
                    val statDelivered = matchedStat?.deliveredAidCount ?: 0
                    val delivered = if (ratioDelivered > 0) ratioDelivered else statDelivered

                    val existing = rawAggregated[cleanName]
                    if (existing == null) {
                        rawAggregated[cleanName] = eligible to delivered
                    } else {
                        rawAggregated[cleanName] = (existing.first + eligible) to (existing.second + delivered)
                    }
                }
            } else if (benefitRatios.isNotEmpty()) {
                for (ratio in benefitRatios) {
                    val cleanName = ratio.subAreaName.trim()
                    if (cleanName.isBlank()) continue
                    val existing = rawAggregated[cleanName]
                    if (existing == null) {
                        rawAggregated[cleanName] = ratio.eligibleFamiliesCount to ratio.deliveredBeneficiariesCount
                    } else {
                        rawAggregated[cleanName] = (existing.first + ratio.eligibleFamiliesCount) to
                            (existing.second + ratio.deliveredBeneficiariesCount)
                    }
                }
            }

            val sumEligible = rawAggregated.values.sumOf { it.first }

            rawAggregated.entries.map { (name, counts) ->
                val eligible = counts.first.coerceAtLeast(0)
                val delivered = counts.second.coerceAtLeast(0)
                val sharePct = if (sumEligible > 0) {
                    (eligible.toDouble() * 100.0) / sumEligible.toDouble()
                } else {
                    0.0
                }
                val targetQuota = if (eligible > 0) {
                    (eligible * 0.7).toInt().coerceAtLeast(1)
                } else {
                    0
                }
                val completionPct = if (eligible > 0) {
                    ((delivered.toDouble() * 100.0) / eligible.toDouble()).toInt().coerceIn(0, 100)
                } else {
                    0
                }
                UnifiedLocalityGeoModel(
                    name = name,
                    eligibleCount = eligible,
                    targetQuota = targetQuota,
                    deliveredCount = delivered,
                    sharePercentage = sharePct,
                    completionPct = completionPct
                )
            }
        }

        // إجمالي المؤهلين الحقيقي عبر كافة المحليات + نسبة الإنجاز الكلية الدقيقة (المسلّم ÷ المؤهلون × 100)
        val totalEligibleAcrossLocalities = remember(unifiedLocalities, totalSystemEligible) {
            if (unifiedLocalities.isNotEmpty()) {
                unifiedLocalities.sumOf { it.eligibleCount }
            } else {
                totalSystemEligible
            }
        }
        val totalDeliveredAcrossLocalities = remember(unifiedLocalities) {
            unifiedLocalities.sumOf { it.deliveredCount }
        }
        val overallCompletionPct = remember(totalEligibleAcrossLocalities, totalDeliveredAcrossLocalities) {
            if (totalEligibleAcrossLocalities > 0) {
                ((totalDeliveredAcrossLocalities.toDouble() * 100.0) / totalEligibleAcrossLocalities.toDouble())
                    .toInt()
                    .coerceIn(0, 100)
            } else {
                0
            }
        }

        var selectedLocalityName by remember { mutableStateOf("") }

        LaunchedEffect(unifiedLocalities) {
            if (unifiedLocalities.isNotEmpty() && unifiedLocalities.none { it.name == selectedLocalityName }) {
                selectedLocalityName = unifiedLocalities.first().name
            }
        }

        val activeLocality = unifiedLocalities.firstOrNull { it.name == selectedLocalityName }
            ?: unifiedLocalities.firstOrNull()

        // مناطق فرعية حقيقية فقط إذا كان اسمها مختلفاً عن أسماء المحليات الرئيسية
        val distinctRealSubAreas = remember(benefitRatios, unifiedLocalities) {
            val localityNamesLower = unifiedLocalities.map { it.name.trim().lowercase(Locale.ROOT) }.toSet()
            benefitRatios
                .mapNotNull { stat ->
                    val cleanSub = stat.subAreaName.trim()
                    if (cleanSub.isBlank() || cleanSub.lowercase(Locale.ROOT) in localityNamesLower) {
                        null
                    } else {
                        val eligible = stat.eligibleFamiliesCount.coerceAtLeast(0)
                        val delivered = stat.deliveredBeneficiariesCount.coerceAtLeast(0)
                        val pct = if (eligible > 0) {
                            ((delivered.toDouble() * 100.0) / eligible.toDouble()).toInt().coerceIn(0, 100)
                        } else {
                            0
                        }
                        DistinctSubAreaGeoItem(
                            name = cleanSub,
                            eligibleCount = eligible,
                            deliveredCount = delivered,
                            completionPct = pct
                        )
                    }
                }
                .distinctBy { it.name.lowercase(Locale.ROOT) }
        }

        // تحليل الفجوة الإغاثية من نفس مصدر الأرقام الموحد (مرتب من الأعلى فجوة إلى الأقل فجوة)
        val gapMetrics = remember(unifiedLocalities) {
            val totalsMap = LinkedHashMap<String, Int>()
            val servedMap = LinkedHashMap<String, Int>()
            for (loc in unifiedLocalities) {
                totalsMap[loc.name] = loc.eligibleCount
                servedMap[loc.name] = loc.deliveredCount
            }
            GeographicGapAnalyzer.calculateSubRegionGaps(
                subRegionTotals = totalsMap,
                subRegionServed = servedMap
            )
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "التوزيع الجغرافي للمستفيدين",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = GeoTextPrimary
                            )
                            Text(
                                text = "لوحة مؤشرات المحليات والتغطية الإغاثية",
                                style = MaterialTheme.typography.labelSmall,
                                color = GeoTextSecondary
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "رجوع",
                                tint = GeoPrimaryGreen
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.White,
                        titleContentColor = GeoTextPrimary
                    )
                )
            },
            containerColor = GeoScreenBg
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(GeoScreenBg)
                    .padding(paddingValues),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 115.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 1. بطاقة التوزيع الجغرافي الشامل العلوية (أرقام متطابقة 100% مع مجموع المحليات)
                item {
                    CleanGeoCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = GeoMintBg,
                                    border = BorderStroke(1.dp, GeoCardBorder),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Map,
                                            contentDescription = null,
                                            tint = GeoDarkGreen,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = "التوزيع الجغرافي الشامل",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = GeoTextPrimary
                                    )
                                    Text(
                                        text = "الإنجاز الكلي للتسليم الميداني",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GeoTextSecondary
                                    )
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "$overallCompletionPct%",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GeoPrimaryGreen
                                )
                                Text(
                                    text = "نسبة الإنجاز الكلية",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GeoTextSecondary,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        LinearProgressIndicator(
                            progress = { (overallCompletionPct / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(10.dp)
                                .clip(RoundedCornerShape(5.dp)),
                            color = GeoPrimaryGreen,
                            trackColor = GeoCardBorder,
                            strokeCap = StrokeCap.Round
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SummaryMiniBadge(
                                icon = Icons.Default.Groups,
                                label = "المؤهلون",
                                value = "$totalEligibleAcrossLocalities",
                                accent = GeoBlueAccent,
                                modifier = Modifier.weight(1f)
                            )
                            SummaryMiniBadge(
                                icon = Icons.Default.CheckCircle,
                                label = "المسلّم",
                                value = "$totalDeliveredAcrossLocalities",
                                accent = GeoPrimaryGreen,
                                modifier = Modifier.weight(1f)
                            )
                            SummaryMiniBadge(
                                icon = Icons.Default.LocationOn,
                                label = "المحليات",
                                value = "${unifiedLocalities.size}",
                                accent = GeoAmberAccent,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // 2. شريط أفقي واحد فقط: حصص ونسب المحليات (بدون أي تكرار أو رموز تقنية)
                if (unifiedLocalities.isNotEmpty()) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PieChart,
                                        contentDescription = null,
                                        tint = GeoDarkGreen,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "حصص ونسب المحليات",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = GeoTextPrimary
                                    )
                                }
                                Text(
                                    text = "${unifiedLocalities.size} محليات",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = GeoDarkGreen
                                )
                            }

                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(unifiedLocalities, key = { it.name }) { loc ->
                                    val isSelected = activeLocality?.name == loc.name
                                    val ratioColor = when {
                                        loc.sharePercentage >= 30.0 -> GeoPrimaryGreen
                                        loc.sharePercentage >= 15.0 -> GeoBlueAccent
                                        else -> GeoIndigoAccent
                                    }

                                    Surface(
                                        modifier = Modifier
                                            .width(164.dp)
                                            .clip(RoundedCornerShape(16.dp))
                                            .clickable { selectedLocalityName = loc.name },
                                        shape = RoundedCornerShape(16.dp),
                                        color = if (isSelected) GeoMintBg else GeoCardBg,
                                        tonalElevation = 0.dp,
                                        shadowElevation = if (isSelected) 2.dp else 1.dp,
                                        border = BorderStroke(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) GeoSelectedBorder else GeoCardBorder
                                        )
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(7.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = loc.name,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 13.sp,
                                                    color = GeoTextPrimary,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(8.dp),
                                                    color = if (isSelected) Color.White else GeoMintBg,
                                                    border = BorderStroke(1.dp, GeoCardBorder)
                                                ) {
                                                    Text(
                                                        text = loc.formattedSharePercentage,
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = ratioColor,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }

                                            Text(
                                                text = "${loc.eligibleCount} أسرة مؤهلة",
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = GeoTextSecondary
                                            )

                                            LinearProgressIndicator(
                                                progress = { (loc.sharePercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(5.dp)
                                                    .clip(RoundedCornerShape(3.dp)),
                                                color = ratioColor,
                                                trackColor = GeoCardBorder,
                                                strokeCap = StrokeCap.Round
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. بطاقة التفاصيل الموحدة للمحلية المختارة فقط (4 مؤشرات متناسقة 2×2 بدون رموز تقنية)
                if (activeLocality != null) {
                    item {
                        CleanGeoCard(borderColor = GeoSelectedBorder, borderWidth = 1.5.dp) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = GeoMintBg,
                                        border = BorderStroke(1.dp, GeoCardBorder),
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.LocationOn,
                                                contentDescription = null,
                                                tint = GeoPrimaryGreen,
                                                modifier = Modifier.size(19.dp)
                                            )
                                        }
                                    }
                                    Column {
                                        Text(
                                            text = "تفاصيل المحلية: ${activeLocality.name}",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = GeoTextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "الثقل السكاني: ${activeLocality.formattedSharePercentage} من إجمالي المؤهلين",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = GeoTextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Surface(
                                    color = GeoMintBg,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, GeoCardBorder)
                                ) {
                                    Text(
                                        text = "${activeLocality.completionPct}% إنجاز",
                                        color = GeoDarkGreen,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            LinearProgressIndicator(
                                progress = { (activeLocality.completionPct / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = GeoPrimaryGreen,
                                trackColor = GeoCardBorder,
                                strokeCap = StrokeCap.Round
                            )

                            // شبكة مدمجة (2 × 2) للمؤشرات الأربعة المتطابقة 100%
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CompactStatTile(
                                    title = "الأسر المؤهلة",
                                    value = "${activeLocality.eligibleCount}",
                                    icon = Icons.Default.Groups,
                                    accentColor = GeoBlueAccent,
                                    modifier = Modifier.weight(1f)
                                )
                                CompactStatTile(
                                    title = "الحصة المستهدفة",
                                    value = "${activeLocality.targetQuota}",
                                    icon = Icons.Default.Analytics,
                                    accentColor = GeoIndigoAccent,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CompactStatTile(
                                    title = "المسلّم فعلياً",
                                    value = "${activeLocality.deliveredCount}",
                                    icon = Icons.Default.Inventory2,
                                    accentColor = GeoPrimaryGreen,
                                    modifier = Modifier.weight(1f)
                                )
                                CompactStatTile(
                                    title = "نسبة الإنجاز",
                                    value = "${activeLocality.completionPct}%",
                                    icon = Icons.Default.CheckCircle,
                                    accentColor = GeoDarkGreen,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            // قائمة فرعية عمودية تظهر حصراً إذا وُجدت مناطق فرعية حقيقية مختلفة الاسم عن المحليات
                            if (distinctRealSubAreas.isNotEmpty()) {
                                HorizontalDivider(color = GeoCardBorder)
                                Text(
                                    text = "المناطق الفرعية المسجلة",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GeoTextPrimary
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    distinctRealSubAreas.forEach { sub ->
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = GeoMintBg,
                                            border = BorderStroke(1.dp, GeoCardBorder),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = sub.name,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = GeoTextPrimary,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "${sub.deliveredCount} / ${sub.eligibleCount} (${sub.completionPct}%)",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = GeoDarkGreen
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (!isLoading) {
                    item {
                        CleanGeoCard {
                            Text(
                                text = "لا توجد بيانات توزيع جغرافي ضمن نطاق الصلاحيات الحالي.",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = GeoTextSecondary
                            )
                        }
                    }
                }

                // 4. تحليل الفجوة الإغاثية (GeographicGapAnalyzer) مرتباً من الأعلى فجوة إلى الأقل فجوة
                if (gapMetrics.isNotEmpty()) {
                    item {
                        ReliefGapAnalysisSection(
                            gapMetrics = gapMetrics,
                            selectedLocalityName = activeLocality?.name.orEmpty(),
                            onSelectLocality = { name -> selectedLocalityName = name }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CleanGeoCard(
    modifier: Modifier = Modifier,
    borderColor: Color = GeoCardBorder,
    borderWidth: androidx.compose.ui.unit.Dp = 1.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = GeoCardBg,
        tonalElevation = 0.dp,
        shadowElevation = 1.dp,
        border = BorderStroke(borderWidth, borderColor)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
private fun SummaryMiniBadge(
    icon: ImageVector,
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = GeoMintBg,
        tonalElevation = 0.dp,
        border = BorderStroke(1.dp, GeoCardBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(16.dp)
            )
            Column {
                Text(
                    text = value,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = GeoTextPrimary,
                    maxLines = 1
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = GeoTextSecondary,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun CompactStatTile(
    title: String,
    value: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = GeoMintBg,
        tonalElevation = 0.dp,
        border = BorderStroke(1.dp, GeoCardBorder)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color.White,
                border = BorderStroke(1.dp, GeoCardBorder),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = GeoTextPrimary,
                    maxLines = 1
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = GeoTextSecondary,
                    fontSize = 10.5.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ReliefGapAnalysisSection(
    gapMetrics: List<SubRegionGapMetric>,
    selectedLocalityName: String,
    onSelectLocality: (String) -> Unit
) {
    val criticalCount = remember(gapMetrics) { gapMetrics.count { it.coveragePercentage < 30 } }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "تحليل الفجوة الإغاثية",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = GeoTextPrimary
                )
                Text(
                    text = "مرتّب من الأعلى فجوة (الأقل تغطية) إلى الأقل فجوة",
                    style = MaterialTheme.typography.labelSmall,
                    color = GeoTextSecondary,
                    fontSize = 11.sp
                )
            }

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (criticalCount > 0) Color(0xFFFEF2F2) else GeoMintBg,
                border = BorderStroke(
                    1.dp,
                    if (criticalCount > 0) Color(0xFFFECACA) else GeoCardBorder
                )
            ) {
                Text(
                    text = if (criticalCount > 0) "$criticalCount فجوة حرجة" else "${gapMetrics.size} محليات",
                    fontSize = 10.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (criticalCount > 0) GeoRedAccent else GeoDarkGreen,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        CleanGeoCard {
            gapMetrics.forEachIndexed { index, metric ->
                val isSelected = metric.subRegionName == selectedLocalityName
                val statusColor = when {
                    metric.coveragePercentage < 30 -> GeoRedAccent
                    metric.coveragePercentage <= 65 -> GeoAmberAccent
                    else -> GeoPrimaryGreen
                }
                val badgeBg = when {
                    metric.coveragePercentage < 30 -> Color(0xFFFEF2F2)
                    metric.coveragePercentage <= 65 -> Color(0xFFFFFBEB)
                    else -> GeoMintBg
                }
                val badgeBorder = when {
                    metric.coveragePercentage < 30 -> Color(0xFFFECACA)
                    metric.coveragePercentage <= 65 -> Color(0xFFFDE68A)
                    else -> GeoCardBorder
                }
                val statusBadgeLabel = when {
                    metric.coveragePercentage < 30 -> "فجوة حرجة"
                    metric.coveragePercentage <= 65 -> "تغطية متوسطة"
                    else -> "تغطية جيدة"
                }

                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectLocality(metric.subRegionName) },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isSelected) GeoMintBg else Color.White,
                    tonalElevation = 0.dp,
                    border = if (isSelected) BorderStroke(1.5.dp, GeoSelectedBorder) else BorderStroke(1.dp, GeoCardBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 9.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = statusColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = metric.subRegionName,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GeoTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = badgeBg,
                                border = BorderStroke(1.dp, badgeBorder)
                            ) {
                                Text(
                                    text = statusBadgeLabel,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = statusColor,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        LinearProgressIndicator(
                            progress = { (metric.coveragePercentage / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(7.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = statusColor,
                            trackColor = Color(0xFFE2E8F0),
                            strokeCap = StrokeCap.Round
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "التغطية: ${metric.coveragePercentage}% • الفجوة: ${metric.gapScore}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${metric.servedFamiliesCount} / ${metric.totalRegisteredFamilies} أسرة",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GeoTextSecondary
                            )
                        }
                    }
                }

                if (index < gapMetrics.lastIndex) {
                    Spacer(modifier = Modifier.height(2.dp))
                }
            }
        }
    }
}
