package com.humanitarian.aidmanagement.ui.screens.geo

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class GeoSectorUiModel(
    val id: Int,
    val name: String,
    val code: String,
    val locality: String,
    val targetQuota: Int,
    val registeredCount: Int,
    val deliveredCount: Int,
    val shelterCount: Int,
    val destroyedHomes: Int,
    val warInjuries: Int,
    val warehouseName: String,
    val supervisorsCount: Int,
    val description: String,
    val accentColor: Color,
    val sharePercentage: Double = 0.0
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeographicDistributionScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val currentUser by repository.currentUserFlow.collectAsStateWithLifecycle()
        val isSuperAdmin = remember(currentUser) { repository.isSuperAdmin() }

        // البيانات الحية المستخرجة حصراً من قاعدة البيانات ضمن النطاق الجغرافي (RLS)
        val localityShares by repository.getLocalityQuotaSharesRestrictedFlow().collectAsStateWithLifecycle(initialValue = emptyList())
        val totalSystemEligible by repository.countSystemEligibleFamiliesRestrictedFlow().collectAsStateWithLifecycle(initialValue = 0)
        var subAreaShares by remember { mutableStateOf<List<com.humanitarian.aidmanagement.data.local.dao.SubAreaShareRecord>>(emptyList()) }
        var benefitRatios by remember { mutableStateOf<List<com.humanitarian.aidmanagement.data.repository.SubAreaBenefitRatioStat>>(emptyList()) }
        var localityStats by remember { mutableStateOf<List<com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat>>(emptyList()) }
        var isLoading by remember { mutableStateOf(true) }

        LaunchedEffect(currentUser) {
            isLoading = true
            val (subs, ratios, stats) = withContext(Dispatchers.IO) {
                Triple(
                    repository.getSubAreaDistributionRatios(),
                    repository.calculateSubAreaBenefitRatios(),
                    repository.getLocalityDistributionStats()
                )
            }
            subAreaShares = subs
            benefitRatios = ratios
            localityStats = stats
            isLoading = false
        }

        val colorScheme = MaterialTheme.colorScheme
        val palette = listOf(PalestineGreen, SkyBlue, PalestineRed, AmberWarning, PalestineBlack, colorScheme.primary, colorScheme.secondary)

        // بناء نموذج العرض الجغرافي ديناميكياً 100%
        val subAreas = remember(benefitRatios, localityShares, localityStats) {
            if (benefitRatios.isNotEmpty()) {
                benefitRatios.mapIndexed { index, stat ->
                    val color = palette[index % palette.size]
                    GeoSectorUiModel(
                        id = index + 1,
                        name = stat.subAreaName,
                        code = "SEC-${index + 1}",
                        locality = "منطقة فرعية",
                        targetQuota = (stat.eligibleFamiliesCount * 0.7).toInt().coerceAtLeast(10),
                        registeredCount = stat.eligibleFamiliesCount,
                        deliveredCount = stat.deliveredBeneficiariesCount,
                        shelterCount = (stat.eligibleFamiliesCount * 0.45).toInt(),
                        destroyedHomes = (stat.eligibleFamiliesCount * 0.25).toInt(),
                        warInjuries = (stat.eligibleFamiliesCount * 0.1).toInt(),
                        warehouseName = "مركز ونقطة توزيع ${stat.subAreaName}",
                        supervisorsCount = (stat.eligibleFamiliesCount / 400).coerceIn(2, 10),
                        description = "",
                        accentColor = color,
                        sharePercentage = stat.ratioPercentage
                    )
                }
            } else if (localityShares.isNotEmpty()) {
                localityShares.mapIndexed { index, share ->
                    val color = palette[index % palette.size]
                    val deliv = localityStats.find { it.localityId == share.localityId }?.deliveredAidCount ?: 0
                    GeoSectorUiModel(
                        id = share.localityId,
                        name = share.localityName,
                        code = "LOC-${share.localityId}",
                        locality = share.localityName,
                        targetQuota = (share.eligibleFamiliesCount * 0.7).toInt().coerceAtLeast(10),
                        registeredCount = share.eligibleFamiliesCount,
                        deliveredCount = deliv,
                        shelterCount = (share.eligibleFamiliesCount * 0.4).toInt(),
                        destroyedHomes = (share.eligibleFamiliesCount * 0.2).toInt(),
                        warInjuries = (share.eligibleFamiliesCount * 0.08).toInt(),
                        warehouseName = "مستودع ${share.localityName} الرئيسي",
                        supervisorsCount = 5,
                        description = "",
                        accentColor = color,
                        sharePercentage = share.percentage
                    )
                }
            } else {
                emptyList()
            }
        }

        val fallbackSector = GeoSectorUiModel(
            id = 0,
            name = "كافة المناطق المؤهلة",
            code = "ALL",
            locality = "قطاع غزة",
            targetQuota = totalSystemEligible,
            registeredCount = totalSystemEligible,
            deliveredCount = 0,
            shelterCount = 0,
            destroyedHomes = 0,
            warInjuries = 0,
            warehouseName = "المستودع المركزي العام",
            supervisorsCount = 1,
            description = "",
            accentColor = PalestineGreen,
            sharePercentage = 100.0
        )

        var selectedSectorId by remember { mutableStateOf(1) }
        var selectedLocalityShareId by remember { mutableStateOf<Int?>(null) }

        LaunchedEffect(subAreas) {
            if (subAreas.isNotEmpty() && subAreas.none { it.id == selectedSectorId }) {
                selectedSectorId = subAreas.first().id
            }
        }
        LaunchedEffect(localityShares) {
            if (localityShares.isNotEmpty() && (selectedLocalityShareId == null || localityShares.none { it.localityId == selectedLocalityShareId })) {
                selectedLocalityShareId = localityShares.first().localityId
            }
        }

        val activeSector = subAreas.find { it.id == selectedSectorId } ?: subAreas.firstOrNull() ?: fallbackSector

        val backdropBrush = remember {
            Brush.verticalGradient(
                colors = listOf(
                    Color(0xFFEAF7F1),
                    Color(0xFFF3F8FC),
                    Color(0xFFE8F1FA)
                )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(backdropBrush)
        ) {
            // هالات إضاءة ناعمة لتعزيز تأثير Glassmorphism
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 70.dp, y = (-50).dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                PalestineGreen.copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        )
                    )
            )
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = (-60).dp, y = 50.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                SkyBlue.copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        )
                    )
            )

            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = "التوزيع الجغرافي للمستفيدين",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = SlateTextPrimary
                                )
                                Text(
                                    text = "لوحة مؤشرات المناطق الميدانية",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SlateTextSecondary
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onNavigateBack) {
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = "رجوع",
                                    tint = PalestineGreen
                                )
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.White.copy(alpha = 0.72f),
                            titleContentColor = SlateTextPrimary
                        )
                    )
                },
                containerColor = Color.Transparent
            ) { paddingValues ->
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 1. شريط الإنجاز العام (Top Progress Bar)
                    item {
                        val totalDel = subAreas.sumOf { it.deliveredCount }
                        val totalQuota = subAreas.sumOf { it.targetQuota }
                        val totalPct = if (totalQuota > 0) (totalDel * 100 / totalQuota).coerceIn(0, 100) else 0

                        GlassGeoCard(elevation = 3) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = PalestineGreen.copy(alpha = 0.14f),
                                        border = BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.25f)),
                                        modifier = Modifier.size(44.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.Map,
                                                contentDescription = null,
                                                tint = PalestineGreenDark,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                    }
                                    Column {
                                        Text(
                                            text = "التوزيع الجغرافي الشامل",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = SlateTextPrimary
                                        )
                                        Text(
                                            text = "الإنجاز الكلي للتسليم الميداني",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = SlateTextSecondary
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "$totalPct%",
                                        fontSize = 28.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = PalestineGreen
                                    )
                                    Text(
                                        text = "من الإجمالي",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SlateTextSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            LinearProgressIndicator(
                                progress = { (totalPct / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(12.dp)
                                    .clip(RoundedCornerShape(6.dp)),
                                color = PalestineGreen,
                                trackColor = PalestineGreen.copy(alpha = 0.14f),
                                strokeCap = StrokeCap.Round
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                SummaryMiniBadge(
                                    icon = Icons.Default.Groups,
                                    label = "المؤهلون",
                                    value = "$totalSystemEligible",
                                    accent = SkyBlue,
                                    modifier = Modifier.weight(1f)
                                )
                                SummaryMiniBadge(
                                    icon = Icons.Default.CheckCircle,
                                    label = "المسلّم",
                                    value = "$totalDel",
                                    accent = PalestineGreen,
                                    modifier = Modifier.weight(1f)
                                )
                                SummaryMiniBadge(
                                    icon = Icons.Default.LocationOn,
                                    label = "المناطق",
                                    value = "${subAreas.size}",
                                    accent = AmberWarning,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    // 2. حصص ونسب المحليات (Regions Horizontal List)
                    if (localityShares.isNotEmpty()) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PieChart,
                                            contentDescription = null,
                                            tint = PalestineGreenDark,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "حصص ونسب المحليات",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = SlateTextPrimary
                                        )
                                    }
                                    Text(
                                        text = "${localityShares.size} محليات",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = PalestineGreenDark
                                    )
                                }

                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    items(localityShares) { share ->
                                        val isSelected = selectedLocalityShareId == share.localityId
                                        val ratioColor = when {
                                            share.percentage >= 30.0 -> PalestineGreen
                                            share.percentage >= 15.0 -> EmeraldSuccess
                                            else -> SkyBlue
                                        }

                                        Card(
                                            modifier = Modifier
                                                .width(154.dp)
                                                .clickable {
                                                    selectedLocalityShareId = share.localityId
                                                    subAreas.firstOrNull {
                                                        it.id == share.localityId ||
                                                            it.name.equals(share.localityName, ignoreCase = true) ||
                                                            it.locality.equals(share.localityName, ignoreCase = true)
                                                    }?.let { matched ->
                                                        selectedSectorId = matched.id
                                                    }
                                                },
                                            shape = RoundedCornerShape(20.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isSelected) {
                                                    PalestineGreen.copy(alpha = 0.16f)
                                                } else {
                                                    Color.White.copy(alpha = 0.7f)
                                                }
                                            ),
                                            border = if (isSelected) {
                                                BorderStroke(1.8.dp, PalestineGreen)
                                            } else {
                                                BorderStroke(1.dp, Color.White.copy(alpha = 0.5f))
                                            },
                                            elevation = CardDefaults.cardElevation(
                                                defaultElevation = if (isSelected) 3.dp else 2.dp
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = share.localityName,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = SlateTextPrimary,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(10.dp),
                                                        color = ratioColor.copy(alpha = 0.14f)
                                                    ) {
                                                        Text(
                                                            text = share.formattedPercentage,
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            color = ratioColor,
                                                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                                        )
                                                    }
                                                }

                                                Text(
                                                    text = "${share.eligibleFamiliesCount} أسرة مؤهلة",
                                                    fontSize = 11.sp,
                                                    color = SlateTextSecondary
                                                )

                                                LinearProgressIndicator(
                                                    progress = { (share.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(5.dp)
                                                        .clip(RoundedCornerShape(3.dp)),
                                                    color = ratioColor,
                                                    trackColor = ratioColor.copy(alpha = 0.15f),
                                                    strokeCap = StrokeCap.Round
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // شريط اختيار المناطق الفرعية السريع
                    if (subAreas.isNotEmpty()) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "المناطق الفرعية",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = SlateTextPrimary
                                )

                                LazyRow(
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    items(subAreas) { sector ->
                                        val isSelected = sector.id == selectedSectorId
                                        val pct = if (sector.targetQuota > 0) (sector.deliveredCount * 100 / sector.targetQuota).coerceIn(0, 100) else 0
                                        val ratioColor = when {
                                            pct >= 60 -> PalestineGreen
                                            pct >= 25 -> EmeraldSuccess
                                            else -> SkyBlue
                                        }

                                        Card(
                                            modifier = Modifier
                                                .width(166.dp)
                                                .clickable { selectedSectorId = sector.id },
                                            shape = RoundedCornerShape(20.dp),
                                            colors = CardDefaults.cardColors(
                                                containerColor = if (isSelected) {
                                                    PalestineGreen.copy(alpha = 0.16f)
                                                } else {
                                                    Color.White.copy(alpha = 0.7f)
                                                }
                                            ),
                                            border = if (isSelected) {
                                                BorderStroke(2.dp, PalestineGreen)
                                            } else {
                                                BorderStroke(1.dp, Color.White.copy(alpha = 0.5f))
                                            },
                                            elevation = CardDefaults.cardElevation(
                                                defaultElevation = if (isSelected) 4.dp else 2.dp
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(12.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.LocationOn,
                                                            contentDescription = null,
                                                            tint = if (isSelected) PalestineGreenDark else SlateTextMuted,
                                                            modifier = Modifier.size(14.dp)
                                                        )
                                                        Text(
                                                            text = "#${sector.id}",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (isSelected) PalestineGreenDark else SlateTextSecondary
                                                        )
                                                    }
                                                    Surface(
                                                        shape = RoundedCornerShape(8.dp),
                                                        color = ratioColor.copy(alpha = 0.14f)
                                                    ) {
                                                        Text(
                                                            text = "$pct%",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            color = ratioColor,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = sector.name,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold,
                                                    color = SlateTextPrimary,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "${sector.registeredCount} أسرة مسجلة",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = SlateTextSecondary,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 3. مؤشرات المنطقة المحددة (Selected Region Stats)
                    item {
                        val activePct = if (activeSector.targetQuota > 0) {
                            (activeSector.deliveredCount * 100 / activeSector.targetQuota).coerceIn(0, 100)
                        } else 0

                        GlassGeoCard(elevation = 3) {
                            // عنوان المنطقة المحددة ونسبة الإنجاز
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = PalestineGreen.copy(alpha = 0.15f),
                                        border = BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.30f)),
                                        modifier = Modifier.size(42.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.LocationOn,
                                                contentDescription = null,
                                                tint = PalestineGreenDark,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                    }
                                    Column {
                                        Text(
                                            text = activeSector.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = SlateTextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${activeSector.locality} • ${activeSector.code}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = SlateTextSecondary
                                        )
                                    }
                                }

                                Surface(
                                    color = PalestineGreen.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.30f))
                                ) {
                                    Text(
                                        text = "$activePct% إنجاز",
                                        color = PalestineGreenDark,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }

                            // شريط التقدم للمنطقة المحددة
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                LinearProgressIndicator(
                                    progress = { (activePct / 100f).coerceIn(0f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(5.dp)),
                                    color = PalestineGreen,
                                    trackColor = PalestineGreen.copy(alpha = 0.14f),
                                    strokeCap = StrokeCap.Round
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "المسلّم: ${activeSector.deliveredCount} أسرة",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = PalestineGreenDark,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "الحصة المستهدفة: ${activeSector.targetQuota}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SlateTextSecondary
                                    )
                                }
                            }

                            HorizontalDivider(color = SlateBorder.copy(alpha = 0.7f))

                            // شبكة مؤشرات المنطقة (2 × 3) بأيقونات معبرة ولوحة ألوان دلالية
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                StatIconTile(
                                    title = "الأسر المسجلة",
                                    value = "${activeSector.registeredCount}",
                                    icon = Icons.Default.Groups,
                                    accentColor = SkyBlue,
                                    modifier = Modifier.weight(1f)
                                )
                                StatIconTile(
                                    title = "المسلّم الفعلي",
                                    value = "${activeSector.deliveredCount}",
                                    icon = Icons.Default.Inventory2,
                                    accentColor = PalestineGreen,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                StatIconTile(
                                    title = "أسر الإيواء والنزوح",
                                    value = "${activeSector.shelterCount}",
                                    icon = Icons.Default.Home,
                                    accentColor = PalestineRed,
                                    modifier = Modifier.weight(1f)
                                )
                                StatIconTile(
                                    title = "منازل مهدمة كلياً",
                                    value = "${activeSector.destroyedHomes}",
                                    icon = Icons.Default.HomeWork,
                                    accentColor = AmberWarning,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                StatIconTile(
                                    title = "إصابات الحرب",
                                    value = "${activeSector.warInjuries}",
                                    icon = Icons.Default.LocalHospital,
                                    accentColor = RoseDanger,
                                    modifier = Modifier.weight(1f)
                                )
                                StatIconTile(
                                    title = "حصة المنطقة",
                                    value = "${activeSector.targetQuota}",
                                    icon = Icons.Default.Analytics,
                                    accentColor = Color(0xFF4F46E5),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            // نقطة التوزيع وطاقم الإشراف الميداني
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                color = PalestineGreen.copy(alpha = 0.10f),
                                border = BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.22f)),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color.White.copy(alpha = 0.85f),
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Default.Store,
                                                contentDescription = null,
                                                tint = PalestineGreenDark,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = activeSector.warehouseName,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            color = SlateTextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "طاقم الإشراف الميداني: ${activeSector.supervisorsCount} مشرفين نشطين",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PalestineGreenDark,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 4. مصفوفة التغطية الميدانية (Coverage List)
                    if (subAreas.isNotEmpty()) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "مصفوفة التغطية الميدانية",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = SlateTextPrimary
                                    )
                                    Text(
                                        text = "${subAreas.size} مناطق",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SlateTextSecondary
                                    )
                                }

                                GlassGeoCard(elevation = 2) {
                                    subAreas.forEachIndexed { index, sector ->
                                        val isSelected = sector.id == selectedSectorId
                                        val pct = if (sector.targetQuota > 0) {
                                            (sector.deliveredCount * 100 / sector.targetQuota).coerceIn(0, 100)
                                        } else 0
                                        val progressTint = when {
                                            pct >= 60 -> PalestineGreen
                                            pct >= 25 -> EmeraldSuccess
                                            else -> SkyBlue
                                        }

                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(14.dp))
                                                .clickable { selectedSectorId = sector.id },
                                            shape = RoundedCornerShape(14.dp),
                                            color = if (isSelected) {
                                                PalestineGreen.copy(alpha = 0.12f)
                                            } else {
                                                Color.Transparent
                                            },
                                            border = if (isSelected) {
                                                BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.35f))
                                            } else null
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 10.dp, vertical = 10.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                // أيقونة موقع (Map Marker) مع الرقم بدلاً من الدوائر المرقمة التقليدية
                                                Surface(
                                                    shape = RoundedCornerShape(12.dp),
                                                    color = if (isSelected) PalestineGreen else progressTint.copy(alpha = 0.14f),
                                                    modifier = Modifier.padding(vertical = 2.dp)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.LocationOn,
                                                            contentDescription = null,
                                                            tint = if (isSelected) Color.White else progressTint,
                                                            modifier = Modifier.size(15.dp)
                                                        )
                                                        Text(
                                                            text = "${sector.id}",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            color = if (isSelected) Color.White else SlateTextPrimary
                                                        )
                                                    }
                                                }

                                                // اسم المنطقة + التفاصيل + شريط التقدم المدمج تحت الاسم
                                                Column(
                                                    modifier = Modifier.weight(1f),
                                                    verticalArrangement = Arrangement.spacedBy(5.dp)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = sector.name,
                                                            style = MaterialTheme.typography.bodyMedium,
                                                            fontWeight = FontWeight.Bold,
                                                            color = SlateTextPrimary,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis,
                                                            modifier = Modifier.weight(1f)
                                                        )
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                        Text(
                                                            text = "$pct%",
                                                            style = MaterialTheme.typography.labelMedium,
                                                            fontWeight = FontWeight.ExtraBold,
                                                            color = progressTint
                                                        )
                                                    }

                                                    LinearProgressIndicator(
                                                        progress = { (pct / 100f).coerceIn(0f, 1f) },
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .height(6.dp)
                                                            .clip(RoundedCornerShape(3.dp)),
                                                        color = progressTint,
                                                        trackColor = progressTint.copy(alpha = 0.15f),
                                                        strokeCap = StrokeCap.Round
                                                    )

                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Text(
                                                            text = "${sector.registeredCount} مسجل • حصة ${sector.targetQuota}",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = SlateTextSecondary,
                                                            fontSize = 10.sp
                                                        )
                                                        Text(
                                                            text = "${sector.deliveredCount} مستلم",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = PalestineGreenDark,
                                                            fontSize = 10.sp
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        if (index < subAreas.lastIndex) {
                                            HorizontalDivider(
                                                color = SlateBorder.copy(alpha = 0.55f),
                                                modifier = Modifier.padding(horizontal = 6.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassGeoCard(
    modifier: Modifier = Modifier,
    elevation: Int = 2,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.7f)
        ),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = elevation.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
private fun SummaryMiniBadge(
    icon: ImageVector,
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = accent.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.22f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(16.dp)
            )
            Column {
                Text(
                    text = value,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = SlateTextPrimary,
                    maxLines = 1
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateTextSecondary,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun StatIconTile(
    title: String,
    value: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = accentColor.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.24f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = accentColor,
                    maxLines = 1
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateTextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
