package com.humanitarian.aidmanagement.crash

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.system.exitProcess

/**
 * معالج الانهيارات العام (Global Crash Handler).
 * يلتقط أي استثناء غير معالج في أي خيط ويحوله إلى تقرير Stack Trace كامل
 * ثم يفتح CrashActivity في عملية معزولة قبل إنهاء العملية المنهارة بأمان.
 */
class GlobalCrashHandler(
    context: Context
) : Thread.UncaughtExceptionHandler {

    private val appContext: Context = context.applicationContext ?: context
    private val previousHandler: Thread.UncaughtExceptionHandler? =
        Thread.getDefaultUncaughtExceptionHandler()

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        try {
            val timestamp = try {
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            } catch (_: Throwable) {
                System.currentTimeMillis().toString()
            }

            val stackTrace = Log.getStackTraceString(throwable)
                .ifBlank { "${throwable::class.java.name}: ${throwable.message}\n${throwable.stackTrace.joinToString("\n")}" }

            val report = buildString {
                appendLine("=== CRASH REPORT ===")
                appendLine("Time: $timestamp")
                appendLine("Thread: ${thread.name} (id=${thread.id})")
                appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
                appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                appendLine("Exception: ${throwable::class.java.name}: ${throwable.message}")
                appendLine("====================")
                appendLine()
                append(stackTrace)
            }

            Log.e(TAG, report)

            val crashIntent = Intent(appContext, CrashActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TASK or
                        Intent.FLAG_ACTIVITY_NO_ANIMATION
                )
                putExtra(CrashActivity.EXTRA_ERROR, report)
            }

            appContext.startActivity(crashIntent)

            try {
                Thread.sleep(250L)
            } catch (_: InterruptedException) {
            }

            Process.killProcess(Process.myPid())
            exitProcess(10)
        } catch (handlerError: Throwable) {
            Log.e(TAG, "Failed to launch CrashActivity", handlerError)
            previousHandler?.uncaughtException(thread, throwable) ?: run {
                Process.killProcess(Process.myPid())
                exitProcess(10)
            }
        }
    }

    companion object {
        private const val TAG = "GlobalCrashHandler"
    }
}
