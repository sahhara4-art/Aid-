package com.humanitarian.aidmanagement.sync

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * SyncWorker - غلاف توافقي خفيف (Lightweight Compatibility Wrapper)
 *
 * تم توحيد المزامنة الخلفية في WorkManager عبر مسار وحيد هو FirestoreSyncWorker
 * (مزامنة تفاضلية مجزأة على دفعات 250 وثيقة) منعاً لتكرار المهام الخلفية واستنزاف الرام.
 * أي استدعاء قديم لهذا العامل يتم توجيهه مباشرة إلى FirestoreSyncWorker دون تشغيل حلقة مزامنة مكررة.
 */
class SyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val TAG = "SyncWorker"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.i(TAG, "Legacy SyncWorker delegated to unified FirestoreSyncWorker (no duplicate sync loop).")
        runCatching {
            FirestoreSyncWorker.triggerImmediateSync(applicationContext)
        }.onFailure { e ->
            Log.w(TAG, "Delegation to FirestoreSyncWorker warning: ${e.message}")
        }
        Result.success()
    }
}
