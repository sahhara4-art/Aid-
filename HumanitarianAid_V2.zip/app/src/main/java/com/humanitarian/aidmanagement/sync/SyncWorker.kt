package com.humanitarian.aidmanagement.sync

import android.content.Context
import com.humanitarian.aidmanagement.AidApplication

class SyncWorker(context: Context) {
    private val app = context.applicationContext as AidApplication

    suspend fun doWork(): Boolean {
        return try {
            val syncManager = SyncManager(app.database)
            syncManager.triggerSync().isSuccess
        } catch (e: Exception) {
            false
        }
    }
}
