package com.humanitarian.aidmanagement.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.humanitarian.aidmanagement.AidApplication
import com.humanitarian.aidmanagement.data.local.entities.SyncLogEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val app = applicationContext as AidApplication
        val database = app.database
        val syncDao = database.syncQueueDao()

        val pendingItems = syncDao.getPendingSyncItems()
        if (pendingItems.isEmpty()) {
            return@withContext Result.success()
        }

        var succeeded = 0
        var failed = 0

        for (item in pendingItems) {
            try {
                syncDao.markAsSyncing(item.syncId)

                // محاكاة الإرسال والمصادقة مع الخادم السحابي مع معالجة التعارضات
                // في وضع الإنتاج: يتم إرسال طلب HTTPS مع التوكن
                kotlinx.coroutines.delay(100) // معالجة شبكية سريعة

                // تأكيد نجاح المزامنة وتحديث حالة السجل
                syncDao.markAsSynced(item.syncId)
                succeeded++
            } catch (e: Exception) {
                syncDao.markAsFailed(item.syncId, e.message ?: "فشل الاتصال بالخادم")
                failed++
            }
        }

        // مسح العناصر المكتملة للحفاظ على خفة قاعدة البيانات
        syncDao.clearSynced()

        // تسجيل ملخص العملية في جدول سجلات المزامنة
        val status = if (failed == 0) "SUCCESS" else if (succeeded > 0) "PARTIAL" else "FAILED"
        val summary = "تمت مزامنة $succeeded عملية بنجاح، و $failed عمليات فاشلة من أصل ${pendingItems.size}."
        val log = SyncLogEntity(
            syncType = "AUTO_BACKGROUND",
            itemsProcessed = pendingItems.size,
            itemsSucceeded = succeeded,
            itemsFailed = failed,
            status = status,
            summary = summary
        )
        syncDao.insertSyncLog(log)

        if (failed > 0 && succeeded == 0) {
            Result.retry()
        } else {
            Result.success()
        }
    }
}
