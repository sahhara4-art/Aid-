package com.humanitarian.aidmanagement.ui.screens.audit

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.sqlite.db.SupportSQLiteDatabase
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyTable
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.util.PublicDownloadsExporter
import com.humanitarian.aidmanagement.util.SavedExportResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val AuditEmerald = Color(0xFF0F7B53)
private val AuditAmber = Color(0xFFD97706)
private val AuditCrimson = Color(0xFFDC2626)
private val AuditIndigo = Color(0xFF4338CA)
private val AuditSlateDark = Color(0xFF0F172A)
private val AuditSlateMuted = Color(0xFF64748B)
private val AuditSurfaceBg = Color(0xFFF3F8F5)
private val AuditBorder = Color(0xFFD5E5DD)

enum class IntegrityConflictType(val arabicTitle: String) {
    DUPLICATE_WIFE("تداخل الزوجات"),
    ROLE_DUPLICATION("ازدواجية الدور"),
    SHARED_CHILDREN("الأبناء المشتركون")
}

/**
 * ملخص خفيف لملف الأسرة لتجنب الاحتفاظ بنسخ FamilyEntity كاملة في الذاكرة (256MB Heap Safe).
 */
data class HouseholdFileSummary(
    val familyFileId: Long,
    val headNationalId: String,
    val headName: String,
    val subRegion: String,
    val status: String,
    val roleLabel: String = "",
    val linkedPersonName: String = "",
    val mainArea: String = "",
    val localityId: Int = 0
)

/**
 * سجل حالة تداخل بين ملفي أسرة رسميين على نفس رقم الهوية (9 أرقام).
 */
data class IntegrityConflictItem(
    val conflictId: String,
    val conflictingNationalId: String,
    val conflictingPersonName: String,
    val conflictType: IntegrityConflictType,
    val firstFile: HouseholdFileSummary,
    val secondFile: HouseholdFileSummary
)

/**
 * نتيجة الفحص الشامل المصنفة إلى 3 تبويبات.
 */
data class IntegrityAuditReport(
    val duplicateWifeConflicts: List<IntegrityConflictItem> = emptyList(),
    val roleDuplicationConflicts: List<IntegrityConflictItem> = emptyList(),
    val sharedChildrenConflicts: List<IntegrityConflictItem> = emptyList(),
    val scannedFamiliesCount: Int = 0,
    val scannedChildrenCount: Int = 0,
    val geographicScopeLabel: String? = null,
    val auditTimestampMs: Long = System.currentTimeMillis()
) {
    val totalConflictsCount: Int
        get() = duplicateWifeConflicts.size + roleDuplicationConflicts.size + sharedChildrenConflicts.size

    fun allConflicts(): List<IntegrityConflictItem> {
        return buildList(totalConflictsCount) {
            addAll(duplicateWifeConflicts)
            addAll(roleDuplicationConflicts)
            addAll(sharedChildrenConflicts)
        }
    }

    fun conflictsForTab(type: IntegrityConflictType): List<IntegrityConflictItem> = when (type) {
        IntegrityConflictType.DUPLICATE_WIFE -> duplicateWifeConflicts
        IntegrityConflictType.ROLE_DUPLICATION -> roleDuplicationConflicts
        IntegrityConflictType.SHARED_CHILDREN -> sharedChildrenConflicts
    }
}

/**
 * محرك الفحص السريع لسلامة وتداخل بيانات الأسر والأبناء.
 * يعمل على Dispatchers.IO باستخدام خرائط تجزئة خفيفة (HashMap) لأرقام الهويات ذات الـ 9 أرقام.
 */
object HouseholdIntegrityEngine {

    private data class WifeEntryRef(
        val wifeNationalId: String,
        val wifeName: String,
        val fileSummary: HouseholdFileSummary
    )

    private data class ChildOwnerRef(
        val childName: String,
        val familyNationalId: String
    )

    private fun normalizeGeoToken(raw: String): String {
        val trimmed = raw.trim().lowercase(Locale.ROOT)
        if (trimmed.isBlank()) return ""
        val sb = StringBuilder(trimmed.length)
        var prevSpace = false
        for (ch in trimmed) {
            val mapped = when (ch) {
                'أ', 'إ', 'آ' -> 'ا'
                'ة' -> 'ه'
                'ى' -> 'ي'
                'ـ' -> continue
                else -> ch
            }
            if (mapped.isWhitespace()) {
                if (!prevSpace) {
                    sb.append(' ')
                    prevSpace = true
                }
            } else {
                sb.append(mapped)
                prevSpace = false
            }
        }
        return sb.toString().trim()
    }

    private fun isGeoAllToken(raw: String): Boolean {
        val t = raw.trim()
        return t.isBlank() ||
            t.equals("ALL", ignoreCase = true) ||
            t == "الكل" ||
            t == "*" ||
            t == "كافة المجموعات" ||
            t == "كافة المناطق" ||
            t == "كافة مناطق قطاع غزة" ||
            t == "جميع المناطق" ||
            t == "جميع المحليات"
    }

    private fun isSummaryInGeoScope(
        summary: HouseholdFileSummary,
        normalizedAllowedLocalities: Set<String>,
        allowedLocalityId: Int
    ): Boolean {
        if (normalizedAllowedLocalities.isEmpty() && allowedLocalityId <= 0) return true
        if (allowedLocalityId > 0 && summary.localityId == allowedLocalityId) return true
        if (normalizedAllowedLocalities.isNotEmpty()) {
            val subNorm = normalizeGeoToken(summary.subRegion)
            val mainNorm = normalizeGeoToken(summary.mainArea)
            if (subNorm.isNotBlank() && normalizedAllowedLocalities.contains(subNorm)) return true
            if (mainNorm.isNotBlank() && normalizedAllowedLocalities.contains(mainNorm)) return true
        }
        return false
    }

    /**
     * فحص مباشر وخفيف الذاكرة عبر SupportSQLiteDatabase بدون تحميل الكائنات الكاملة في الذاكرة،
     * مع فرض العزل الجغرافي الصارم للمستخدمين المقيدين بمنطقة/محلية محددة.
     */
    suspend fun auditDatabase(
        database: SupportSQLiteDatabase,
        allowedLocalities: List<String> = AccessControlManager.getEffectiveAllowedLocalitiesForAudit(),
        allowedLocalityId: Int = AccessControlManager.getEffectiveAllowedLocalityIdForAudit()
    ): IntegrityAuditReport =
        withContext(Dispatchers.IO) {
            val cleanAllowedLocalities = allowedLocalities
                .map { it.trim() }
                .filter { !isGeoAllToken(it) }
                .distinct()
            val normalizedAllowedSet = cleanAllowedLocalities
                .map { normalizeGeoToken(it) }
                .filter { it.isNotBlank() }
                .toSet()
            val isGeoRestricted = normalizedAllowedSet.isNotEmpty() || allowedLocalityId > 0
            val scopeDisplayLabel = when {
                cleanAllowedLocalities.isNotEmpty() -> cleanAllowedLocalities.joinToString("، ")
                allowedLocalityId > 0 -> AccessControlManager.getEffectiveGeographicScopeDisplay()
                else -> null
            }

            val headsByNatId = HashMap<String, HouseholdFileSummary>(4096)
            val firstWifeByNatId = HashMap<String, HouseholdFileSummary>(4096)
            val wifeRefsForRoleCheck = ArrayList<WifeEntryRef>(2048)

            val duplicateWives = ArrayList<IntegrityConflictItem>()
            val roleDuplications = ArrayList<IntegrityConflictItem>()
            val sharedChildren = ArrayList<IntegrityConflictItem>()

            val seenConflictKeys = HashSet<String>()
            var scannedFamilies = 0
            var scannedChildren = 0
            var matchedScopeNameFallback: String? = null

            val familySql = """
                SELECT
                    ${FamilyTable.COL_FAMILY_ID},
                    ${FamilyTable.COL_NATIONAL_ID},
                    ${FamilyTable.COL_NAME},
                    ${FamilyTable.COL_WIFE_NAME},
                    ${FamilyTable.COL_WIFE_NATIONAL_ID},
                    ${FamilyTable.COL_CURRENT_SUB_AREA},
                    ${FamilyTable.COL_DEVELOPMENT_APPROVAL},
                    ${FamilyTable.COL_RESIDENT_STATUS},
                    ${FamilyTable.COL_CURRENT_MAIN_AREA},
                    ${FamilyTable.COL_LOCALITY_ID}
                FROM ${FamilyTable.TABLE_NAME}
            """.trimIndent()

            database.query(familySql).use { cursor ->
                while (cursor.moveToNext()) {
                    val familyId = cursor.getLong(0)
                    val rawHeadNatId = cursor.getString(1).orEmpty()
                    val headName = cursor.getString(2).orEmpty().trim()
                    val wifeName = cursor.getString(3).orEmpty().trim()
                    val rawWifeNatId = cursor.getString(4).orEmpty()
                    val subArea = cursor.getString(5).orEmpty().trim()
                    val devApproval = cursor.getString(6).orEmpty().trim()
                    val residentStatus = cursor.getString(7).orEmpty().trim()
                    val mainArea = cursor.getString(8).orEmpty().trim()
                    val localityId = cursor.getInt(9)

                    val statusText = formatHouseholdStatus(devApproval, residentStatus)
                    val normHeadId = normalizeNineDigitId(rawHeadNatId)
                    val normWifeId = normalizeNineDigitId(rawWifeNatId)

                    val baseSummary = HouseholdFileSummary(
                        familyFileId = familyId,
                        headNationalId = normHeadId ?: rawHeadNatId.trim(),
                        headName = headName.ifBlank { "بدون اسم" },
                        subRegion = subArea.ifBlank { "غير محددة" },
                        status = statusText,
                        roleLabel = "رب أسرة",
                        mainArea = mainArea,
                        localityId = localityId
                    )

                    val isCurrentFamilyInScope = !isGeoRestricted ||
                        isSummaryInGeoScope(baseSummary, normalizedAllowedSet, allowedLocalityId)
                    if (isCurrentFamilyInScope) {
                        scannedFamilies++
                        if (isGeoRestricted && matchedScopeNameFallback == null) {
                            matchedScopeNameFallback = subArea.ifBlank { mainArea }.takeIf { it.isNotBlank() }
                        }
                    }

                    if (normHeadId != null && !headsByNatId.containsKey(normHeadId)) {
                        headsByNatId[normHeadId] = baseSummary
                    }

                    if (normWifeId != null) {
                        val wifeFileSummary = baseSummary.copy(
                            roleLabel = "زوجة",
                            linkedPersonName = wifeName
                        )
                        wifeRefsForRoleCheck.add(
                            WifeEntryRef(
                                wifeNationalId = normWifeId,
                                wifeName = wifeName,
                                fileSummary = wifeFileSummary
                            )
                        )

                        val existingWifeFile = firstWifeByNatId[normWifeId]
                        if (existingWifeFile == null) {
                            firstWifeByNatId[normWifeId] = wifeFileSummary
                        } else if (existingWifeFile.familyFileId != familyId) {
                            val matchesScope = !isGeoRestricted ||
                                isSummaryInGeoScope(existingWifeFile, normalizedAllowedSet, allowedLocalityId) ||
                                isSummaryInGeoScope(wifeFileSummary, normalizedAllowedSet, allowedLocalityId)
                            if (matchesScope) {
                                val pairKey = buildPairKey(
                                    IntegrityConflictType.DUPLICATE_WIFE,
                                    normWifeId,
                                    existingWifeFile.familyFileId,
                                    familyId
                                )
                                if (seenConflictKeys.add(pairKey)) {
                                    duplicateWives.add(
                                        IntegrityConflictItem(
                                            conflictId = pairKey,
                                            conflictingNationalId = normWifeId,
                                            conflictingPersonName = wifeName.ifBlank { existingWifeFile.linkedPersonName },
                                            conflictType = IntegrityConflictType.DUPLICATE_WIFE,
                                            firstFile = existingWifeFile,
                                            secondFile = wifeFileSummary
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // فحص ازدواجية الدور (هوية مسجلة كزوجة في ملف وكرب أسرة في ملف آخر)
            for (wifeRef in wifeRefsForRoleCheck) {
                val headFile = headsByNatId[wifeRef.wifeNationalId] ?: continue
                if (headFile.familyFileId == wifeRef.fileSummary.familyFileId) continue

                val matchesScope = !isGeoRestricted ||
                    isSummaryInGeoScope(wifeRef.fileSummary, normalizedAllowedSet, allowedLocalityId) ||
                    isSummaryInGeoScope(headFile, normalizedAllowedSet, allowedLocalityId)
                if (!matchesScope) continue

                val pairKey = buildPairKey(
                    IntegrityConflictType.ROLE_DUPLICATION,
                    wifeRef.wifeNationalId,
                    wifeRef.fileSummary.familyFileId,
                    headFile.familyFileId
                )
                if (seenConflictKeys.add(pairKey)) {
                    roleDuplications.add(
                        IntegrityConflictItem(
                            conflictId = pairKey,
                            conflictingNationalId = wifeRef.wifeNationalId,
                            conflictingPersonName = wifeRef.wifeName.ifBlank { headFile.headName },
                            conflictType = IntegrityConflictType.ROLE_DUPLICATION,
                            firstFile = wifeRef.fileSummary,
                            secondFile = headFile.copy(roleLabel = "رب أسرة")
                        )
                    )
                }
            }

            // تحرير خرائط الزوجات قبل فحص جدول الأبناء للحفاظ على أقل استهلاك للذاكرة
            firstWifeByNatId.clear()
            wifeRefsForRoleCheck.clear()

            // فحص الأبناء المشتركين بين أكثر من أسرة رسمية
            val firstChildOwnerByNatId = HashMap<String, ChildOwnerRef>(4096)
            val childSql = "SELECT nationalID, childName, familyNationalID FROM children"

            database.query(childSql).use { cursor ->
                while (cursor.moveToNext()) {
                    val normChildId = normalizeNineDigitId(cursor.getString(0).orEmpty())
                    val childName = cursor.getString(1).orEmpty().trim()
                    val rawFamNatId = cursor.getString(2).orEmpty()
                    val normFamNatId = normalizeNineDigitId(rawFamNatId) ?: rawFamNatId.trim()

                    val currentFamily = if (normFamNatId.isNotBlank()) headsByNatId[normFamNatId] else null
                    if (!isGeoRestricted) {
                        scannedChildren++
                    } else if (currentFamily != null && isSummaryInGeoScope(currentFamily, normalizedAllowedSet, allowedLocalityId)) {
                        scannedChildren++
                    }

                    if (normChildId == null || normFamNatId.isBlank() || currentFamily == null) continue

                    val firstOwner = firstChildOwnerByNatId[normChildId]
                    if (firstOwner == null) {
                        firstChildOwnerByNatId[normChildId] = ChildOwnerRef(
                            childName = childName,
                            familyNationalId = normFamNatId
                        )
                    } else if (firstOwner.familyNationalId != normFamNatId) {
                        val firstFamily = headsByNatId[firstOwner.familyNationalId] ?: continue
                        if (firstFamily.familyFileId == currentFamily.familyFileId) continue

                        val matchesScope = !isGeoRestricted ||
                            isSummaryInGeoScope(firstFamily, normalizedAllowedSet, allowedLocalityId) ||
                            isSummaryInGeoScope(currentFamily, normalizedAllowedSet, allowedLocalityId)
                        if (!matchesScope) continue

                        val pairKey = buildPairKey(
                            IntegrityConflictType.SHARED_CHILDREN,
                            normChildId,
                            firstFamily.familyFileId,
                            currentFamily.familyFileId
                        )
                        if (seenConflictKeys.add(pairKey)) {
                            val resolvedChildName = childName.ifBlank { firstOwner.childName }
                            sharedChildren.add(
                                IntegrityConflictItem(
                                    conflictId = pairKey,
                                    conflictingNationalId = normChildId,
                                    conflictingPersonName = resolvedChildName,
                                    conflictType = IntegrityConflictType.SHARED_CHILDREN,
                                    firstFile = firstFamily.copy(
                                        roleLabel = "ابن مسجل في الملف",
                                        linkedPersonName = resolvedChildName
                                    ),
                                    secondFile = currentFamily.copy(
                                        roleLabel = "ابن مسجل في الملف",
                                        linkedPersonName = resolvedChildName
                                    )
                                )
                            )
                        }
                    }
                }
            }

            IntegrityAuditReport(
                duplicateWifeConflicts = duplicateWives,
                roleDuplicationConflicts = roleDuplications,
                sharedChildrenConflicts = sharedChildren,
                scannedFamiliesCount = scannedFamilies,
                scannedChildrenCount = scannedChildren,
                geographicScopeLabel = scopeDisplayLabel ?: matchedScopeNameFallback,
                auditTimestampMs = System.currentTimeMillis()
            )
        }

    /**
     * فحص سريع لقوائم الكيانات الجاهزة (FamilyEntity و ChildEntity) على Dispatchers.IO بخرائط تجزئة خفيفة،
     * مع فرض العزل الجغرافي الصارم للمستخدمين المقيدين بمنطقة/محلية محددة.
     */
    suspend fun auditEntities(
        families: List<FamilyEntity>,
        children: List<ChildEntity>,
        allowedLocalities: List<String> = AccessControlManager.getEffectiveAllowedLocalitiesForAudit(),
        allowedLocalityId: Int = AccessControlManager.getEffectiveAllowedLocalityIdForAudit()
    ): IntegrityAuditReport = withContext(Dispatchers.IO) {
        val cleanAllowedLocalities = allowedLocalities
            .map { it.trim() }
            .filter { !isGeoAllToken(it) }
            .distinct()
        val normalizedAllowedSet = cleanAllowedLocalities
            .map { normalizeGeoToken(it) }
            .filter { it.isNotBlank() }
            .toSet()
        val isGeoRestricted = normalizedAllowedSet.isNotEmpty() || allowedLocalityId > 0
        val scopeDisplayLabel = when {
            cleanAllowedLocalities.isNotEmpty() -> cleanAllowedLocalities.joinToString("، ")
            allowedLocalityId > 0 -> AccessControlManager.getEffectiveGeographicScopeDisplay()
            else -> null
        }

        val headsByNatId = HashMap<String, HouseholdFileSummary>(families.size)
        val firstWifeByNatId = HashMap<String, HouseholdFileSummary>(families.size / 2 + 16)
        val wifeRefsForRoleCheck = ArrayList<WifeEntryRef>(families.size / 2 + 16)

        val duplicateWives = ArrayList<IntegrityConflictItem>()
        val roleDuplications = ArrayList<IntegrityConflictItem>()
        val sharedChildren = ArrayList<IntegrityConflictItem>()
        val seenConflictKeys = HashSet<String>()
        var scannedFamilies = 0
        var scannedChildren = 0

        for (fam in families) {
            val statusText = formatHouseholdStatus(fam.developmentApproval, fam.residentStatus)
            val normHeadId = normalizeNineDigitId(fam.nationalID)
            val normWifeId = normalizeNineDigitId(fam.wifeNationalID.orEmpty())
            val wifeName = fam.wifeName.orEmpty().trim()

            val baseSummary = HouseholdFileSummary(
                familyFileId = fam.familyID,
                headNationalId = normHeadId ?: fam.nationalID.trim(),
                headName = fam.name.trim().ifBlank { "بدون اسم" },
                subRegion = fam.currentSubArea.trim().ifBlank { "غير محددة" },
                status = statusText,
                roleLabel = "رب أسرة",
                mainArea = fam.currentMainArea.trim(),
                localityId = fam.localityID
            )

            if (!isGeoRestricted || isSummaryInGeoScope(baseSummary, normalizedAllowedSet, allowedLocalityId)) {
                scannedFamilies++
            }

            if (normHeadId != null && !headsByNatId.containsKey(normHeadId)) {
                headsByNatId[normHeadId] = baseSummary
            }

            if (normWifeId != null) {
                val wifeSummary = baseSummary.copy(
                    roleLabel = "زوجة",
                    linkedPersonName = wifeName
                )
                wifeRefsForRoleCheck.add(
                    WifeEntryRef(
                        wifeNationalId = normWifeId,
                        wifeName = wifeName,
                        fileSummary = wifeSummary
                    )
                )

                val existingWifeFile = firstWifeByNatId[normWifeId]
                if (existingWifeFile == null) {
                    firstWifeByNatId[normWifeId] = wifeSummary
                } else if (existingWifeFile.familyFileId != fam.familyID) {
                    val matchesScope = !isGeoRestricted ||
                        isSummaryInGeoScope(existingWifeFile, normalizedAllowedSet, allowedLocalityId) ||
                        isSummaryInGeoScope(wifeSummary, normalizedAllowedSet, allowedLocalityId)
                    if (matchesScope) {
                        val pairKey = buildPairKey(
                            IntegrityConflictType.DUPLICATE_WIFE,
                            normWifeId,
                            existingWifeFile.familyFileId,
                            fam.familyID
                        )
                        if (seenConflictKeys.add(pairKey)) {
                            duplicateWives.add(
                                IntegrityConflictItem(
                                    conflictId = pairKey,
                                    conflictingNationalId = normWifeId,
                                    conflictingPersonName = wifeName.ifBlank { existingWifeFile.linkedPersonName },
                                    conflictType = IntegrityConflictType.DUPLICATE_WIFE,
                                    firstFile = existingWifeFile,
                                    secondFile = wifeSummary
                                )
                            )
                        }
                    }
                }
            }
        }

        for (wifeRef in wifeRefsForRoleCheck) {
            val headFile = headsByNatId[wifeRef.wifeNationalId] ?: continue
            if (headFile.familyFileId == wifeRef.fileSummary.familyFileId) continue

            val matchesScope = !isGeoRestricted ||
                isSummaryInGeoScope(wifeRef.fileSummary, normalizedAllowedSet, allowedLocalityId) ||
                isSummaryInGeoScope(headFile, normalizedAllowedSet, allowedLocalityId)
            if (!matchesScope) continue

            val pairKey = buildPairKey(
                IntegrityConflictType.ROLE_DUPLICATION,
                wifeRef.wifeNationalId,
                wifeRef.fileSummary.familyFileId,
                headFile.familyFileId
            )
            if (seenConflictKeys.add(pairKey)) {
                roleDuplications.add(
                    IntegrityConflictItem(
                        conflictId = pairKey,
                        conflictingNationalId = wifeRef.wifeNationalId,
                        conflictingPersonName = wifeRef.wifeName.ifBlank { headFile.headName },
                        conflictType = IntegrityConflictType.ROLE_DUPLICATION,
                        firstFile = wifeRef.fileSummary,
                        secondFile = headFile.copy(roleLabel = "رب أسرة")
                    )
                )
            }
        }

        firstWifeByNatId.clear()
        wifeRefsForRoleCheck.clear()

        val firstChildOwnerByNatId = HashMap<String, ChildOwnerRef>(children.size / 2 + 16)
        for (child in children) {
            val normChildId = normalizeNineDigitId(child.nationalID)
            val normFamNatId = normalizeNineDigitId(child.familyNationalID) ?: child.familyNationalID.trim()
            val currentFamily = if (normFamNatId.isNotBlank()) headsByNatId[normFamNatId] else null

            if (!isGeoRestricted) {
                scannedChildren++
            } else if (currentFamily != null && isSummaryInGeoScope(currentFamily, normalizedAllowedSet, allowedLocalityId)) {
                scannedChildren++
            }

            if (normChildId == null || normFamNatId.isBlank() || currentFamily == null) continue

            val firstOwner = firstChildOwnerByNatId[normChildId]
            if (firstOwner == null) {
                firstChildOwnerByNatId[normChildId] = ChildOwnerRef(
                    childName = child.childName.trim(),
                    familyNationalId = normFamNatId
                )
            } else if (firstOwner.familyNationalId != normFamNatId) {
                val firstFamily = headsByNatId[firstOwner.familyNationalId] ?: continue
                if (firstFamily.familyFileId == currentFamily.familyFileId) continue

                val matchesScope = !isGeoRestricted ||
                    isSummaryInGeoScope(firstFamily, normalizedAllowedSet, allowedLocalityId) ||
                    isSummaryInGeoScope(currentFamily, normalizedAllowedSet, allowedLocalityId)
                if (!matchesScope) continue

                val pairKey = buildPairKey(
                    IntegrityConflictType.SHARED_CHILDREN,
                    normChildId,
                    firstFamily.familyFileId,
                    currentFamily.familyFileId
                )
                if (seenConflictKeys.add(pairKey)) {
                    val resolvedChildName = child.childName.trim().ifBlank { firstOwner.childName }
                    sharedChildren.add(
                        IntegrityConflictItem(
                            conflictId = pairKey,
                            conflictingNationalId = normChildId,
                            conflictingPersonName = resolvedChildName,
                            conflictType = IntegrityConflictType.SHARED_CHILDREN,
                            firstFile = firstFamily.copy(
                                roleLabel = "ابن مسجل في الملف",
                                linkedPersonName = resolvedChildName
                            ),
                            secondFile = currentFamily.copy(
                                roleLabel = "ابن مسجل في الملف",
                                linkedPersonName = resolvedChildName
                            )
                        )
                    )
                }
            }
        }

        IntegrityAuditReport(
            duplicateWifeConflicts = duplicateWives,
            roleDuplicationConflicts = roleDuplications,
            sharedChildrenConflicts = sharedChildren,
            scannedFamiliesCount = scannedFamilies,
            scannedChildrenCount = scannedChildren,
            geographicScopeLabel = scopeDisplayLabel,
            auditTimestampMs = System.currentTimeMillis()
        )
    }

    fun buildConflictsCsvContent(conflicts: List<IntegrityConflictItem>): String {
        val sb = StringBuilder(conflicts.size * 180 + 256)
        sb.append(
            listOf(
                "نوع التداخل",
                "رقم الهوية المتداخلة",
                "اسم الشخص المتداخل",
                "رقم الملف الأول",
                "هوية رب الأسرة (الأول)",
                "اسم رب الأسرة (الأول)",
                "المنطقة المحلية (الأول)",
                "الحالة (الأول)",
                "الدور (الأول)",
                "رقم الملف الثاني",
                "هوية رب الأسرة (الثاني)",
                "اسم رب الأسرة (الثاني)",
                "المنطقة المحلية (الثاني)",
                "الحالة (الثاني)",
                "الدور (الثاني)"
            ).joinToString(",") { escapeCsvCell(it) }
        )
        sb.append("\r\n")

        for (item in conflicts) {
            sb.append(
                listOf(
                    item.conflictType.arabicTitle,
                    item.conflictingNationalId,
                    item.conflictingPersonName,
                    item.firstFile.familyFileId.toString(),
                    item.firstFile.headNationalId,
                    item.firstFile.headName,
                    item.firstFile.subRegion,
                    item.firstFile.status,
                    item.firstFile.roleLabel,
                    item.secondFile.familyFileId.toString(),
                    item.secondFile.headNationalId,
                    item.secondFile.headName,
                    item.secondFile.subRegion,
                    item.secondFile.status,
                    item.secondFile.roleLabel
                ).joinToString(",") { escapeCsvCell(it) }
            )
            sb.append("\r\n")
        }
        return sb.toString()
    }

    /**
     * حفظ تقرير التداخل مباشرة في مجلد التنزيلات العام بالجوال (Downloads/HumanitarianAid) بترميز UTF-8 BOM.
     */
    suspend fun exportConflictsToPublicDownloads(
        context: Context,
        conflicts: List<IntegrityConflictItem>,
        fileProviderAuthority: String? = null
    ): SavedExportResult = withContext(Dispatchers.IO) {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "household_integrity_conflicts_$stamp.csv"
        val csvContent = buildConflictsCsvContent(conflicts)
        PublicDownloadsExporter.saveCsvToPublicDownloads(
            context = context,
            fileName = fileName,
            csvContent = csvContent,
            fileProviderAuthority = fileProviderAuthority
        )
    }

    /**
     * تصدير تقرير التداخل كملف CSV بترميز UTF-8 BOM (\uFEFF) ليفتح بسلاسة في Excel مع اللغة العربية.
     */
    suspend fun exportConflictsCsv(
        context: Context,
        conflicts: List<IntegrityConflictItem>
    ): File = withContext(Dispatchers.IO) {
        val reportsDir = File(context.cacheDir, "integrity_audit_reports").apply {
            if (!exists()) mkdirs()
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outFile = File(reportsDir, "household_integrity_conflicts_$stamp.csv")
        val csvContent = buildConflictsCsvContent(conflicts)

        BufferedWriter(OutputStreamWriter(FileOutputStream(outFile), Charsets.UTF_8)).use { writer ->
            // UTF-8 BOM لضمان عرض الأحرف العربية بشكل صحيح في Microsoft Excel
            writer.write("\uFEFF")
            writer.write(csvContent)
        }
        outFile
    }

    fun shareCsvReport(
        context: Context,
        csvFile: File,
        fileProviderAuthority: String? = null
    ): Boolean {
        return runCatching {
            val authority = fileProviderAuthority?.takeIf { it.isNotBlank() }
                ?: "${context.packageName}.fileprovider"
            val contentUri = FileProvider.getUriForFile(context, authority, csvFile)
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, "تقرير تدقيق وتداخل بيانات الأسر")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(sendIntent, "مشاركة / فتح تقرير التداخل (Excel)").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            true
        }.getOrDefault(false)
    }

    private fun buildPairKey(
        type: IntegrityConflictType,
        conflictingId: String,
        fileIdA: Long,
        fileIdB: Long
    ): String {
        val low = minOf(fileIdA, fileIdB)
        val high = maxOf(fileIdA, fileIdB)
        return "${type.name}|$conflictingId|$low|$high"
    }

    private fun formatHouseholdStatus(devApproval: String, residentStatus: String): String {
        val parts = listOf(devApproval.trim(), residentStatus.trim()).filter { it.isNotBlank() }
        return if (parts.isEmpty()) "غير محدد" else parts.joinToString(" • ")
    }

    fun normalizeNineDigitId(raw: String): String? {
        if (raw.isBlank()) return null
        val sb = StringBuilder(9)
        for (ch in raw) {
            when (ch) {
                in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
                in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
                in '0'..'9' -> sb.append(ch)
            }
        }
        val digits = sb.toString()
        if (digits.length != 9) return null
        if (digits.all { it == '0' }) return null
        return digits
    }

    private fun escapeCsvCell(raw: String): String {
        val safe = raw.replace("\"", "\"\"")
        return "\"$safe\""
    }
}

/**
 * واجهة مدقق سلامة وتداخل بيانات الأسر (RTL - Material 3 بدون استخدام Icons).
 */
@Composable
fun HouseholdIntegrityAuditorScreen(
    onRunAudit: suspend () -> IntegrityAuditReport,
    onOpenFamilyFile: (familyFileId: Long, familyNationalId: String) -> Unit,
    onBack: () -> Unit = {},
    fileProviderAuthority: String? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val acmRegion by AccessControlManager.currentRegionFlow.collectAsStateWithLifecycle()
    val userGeoScopeLabel = remember(currentUser, acmRegion) {
        AccessControlManager.getEffectiveGeographicScopeDisplay()
    }
    val tabs = remember {
        listOf(
            IntegrityConflictType.DUPLICATE_WIFE,
            IntegrityConflictType.ROLE_DUPLICATION,
            IntegrityConflictType.SHARED_CHILDREN
        )
    }

    var report by remember { mutableStateOf(IntegrityAuditReport()) }
    var isScanning by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    var savedExportResult by remember { mutableStateOf<SavedExportResult?>(null) }
    var hasCompletedFirstScan by remember { mutableStateOf(false) }
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    fun triggerAudit() {
        if (isScanning) return
        scope.launch {
            isScanning = true
            runCatching { onRunAudit() }
                .onSuccess { result ->
                    report = result
                    hasCompletedFirstScan = true
                }
                .onFailure { err ->
                    Toast.makeText(
                        context,
                        "تعذر إتمام الفحص: ${err.message ?: "خطأ غير متوقع"}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            isScanning = false
        }
    }

    LaunchedEffect(userGeoScopeLabel) {
        triggerAudit()
    }

    val effectiveGeoScopeBanner = report.geographicScopeLabel ?: userGeoScopeLabel

    val activeTabType = tabs[selectedTabIndex.coerceIn(tabs.indices)]
    val filteredConflicts = remember(report, activeTabType, searchQuery) {
        val rawList = report.conflictsForTab(activeTabType)
        val cleanQuery = normalizeAuditSearch(searchQuery)
        if (cleanQuery.isBlank()) {
            rawList
        } else {
            rawList.filter { item ->
                normalizeAuditSearch(item.conflictingNationalId).contains(cleanQuery) ||
                    normalizeAuditSearch(item.conflictingPersonName).contains(cleanQuery) ||
                    normalizeAuditSearch(item.firstFile.headName).contains(cleanQuery) ||
                    normalizeAuditSearch(item.firstFile.headNationalId).contains(cleanQuery) ||
                    normalizeAuditSearch(item.firstFile.subRegion).contains(cleanQuery) ||
                    normalizeAuditSearch(item.secondFile.headName).contains(cleanQuery) ||
                    normalizeAuditSearch(item.secondFile.headNationalId).contains(cleanQuery) ||
                    normalizeAuditSearch(item.secondFile.subRegion).contains(cleanQuery)
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(AuditSurfaceBg)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1) الشريط العلوي
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color.White,
                border = BorderStroke(1.dp, AuditBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onBack,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, AuditBorder),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "رجوع",
                            color = AuditSlateDark,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "مدقق سلامة وتداخل الأسر",
                            color = AuditSlateDark,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (hasCompletedFirstScan) {
                                "تم فحص ${report.scannedFamiliesCount} أسرة و${report.scannedChildrenCount} ابن"
                            } else {
                                "جاري تحضير الفحص الشامل للقاعدة الرسمية..."
                            },
                            color = AuditSlateMuted,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Button(
                        onClick = { triggerAudit() },
                        enabled = !isScanning,
                        colors = ButtonDefaults.buttonColors(containerColor = AuditEmerald),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (isScanning) "جاري الفحص..." else "تحديث الفحص",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // شارة النطاق الجغرافي المفروض على الفحص
            if (!effectiveGeoScopeBanner.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFECFDF5),
                    border = BorderStroke(1.dp, AuditEmerald.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "📍 نطاق الفحص الجغرافي: $effectiveGeoScopeBanner",
                        color = AuditEmerald,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }

            // 2) الملخص الرقمي العلوي لعدد حالات كل نوع تداخل
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AuditSummaryMetricCard(
                    title = "تداخل الزوجات",
                    count = report.duplicateWifeConflicts.size,
                    accentColor = AuditCrimson,
                    isSelected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    modifier = Modifier.weight(1f)
                )
                AuditSummaryMetricCard(
                    title = "ازدواجية الدور",
                    count = report.roleDuplicationConflicts.size,
                    accentColor = AuditAmber,
                    isSelected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    modifier = Modifier.weight(1f)
                )
                AuditSummaryMetricCard(
                    title = "الأبناء المشتركون",
                    count = report.sharedChildrenConflicts.size,
                    accentColor = AuditIndigo,
                    isSelected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    modifier = Modifier.weight(1f)
                )
            }

            // 3) شريط الإجراء السريع للتصدير (CSV بترميز UTF-8 BOM)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "إجمالي التداخلات المرصودة: ${report.totalConflictsCount}",
                    color = AuditSlateDark,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Button(
                    onClick = {
                        val all = report.allConflicts()
                        if (all.isEmpty()) {
                            Toast.makeText(
                                context,
                                "لا توجد حالات تداخل لتصديرها حالياً",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            scope.launch {
                                isExporting = true
                                runCatching {
                                    HouseholdIntegrityEngine.exportConflictsToPublicDownloads(
                                        context = context,
                                        conflicts = all,
                                        fileProviderAuthority = fileProviderAuthority
                                    )
                                }.onSuccess { savedResult ->
                                    savedExportResult = savedResult
                                }.onFailure { err ->
                                    Toast.makeText(
                                        context,
                                        "تعذر حفظ التقرير في التنزيلات: ${err.message ?: "خطأ غير متوقع"}",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                                isExporting = false
                            }
                        }
                    },
                    enabled = !isScanning && !isExporting && report.totalConflictsCount > 0,
                    colors = ButtonDefaults.buttonColors(containerColor = AuditIndigo),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (isExporting) "جاري التصدير..." else "تصدير تقرير التداخل (Excel)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // 4) التبويبات الثلاثة (TabRow)
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color.White,
                border = BorderStroke(1.dp, AuditBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                TabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = Color.White,
                    contentColor = AuditEmerald
                ) {
                    tabs.forEachIndexed { index, type ->
                        val count = report.conflictsForTab(type).size
                        val selected = selectedTabIndex == index
                        Tab(
                            selected = selected,
                            onClick = { selectedTabIndex = index },
                            text = {
                                Text(
                                    text = "${type.arabicTitle} ($count)",
                                    fontSize = 11.sp,
                                    fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium,
                                    color = if (selected) AuditEmerald else AuditSlateMuted,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        )
                    }
                }
            }

            // 5) شريط البحث برقم الهوية أو الاسم
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("بحث برقم الهوية أو اسم رب الأسرة أو المنطقة", fontSize = 12.sp) },
                placeholder = { Text("أدخل رقم الهوية (9 أرقام) أو الاسم...", fontSize = 12.sp) },
                trailingIcon = if (searchQuery.isNotBlank()) {
                    {
                        TextButton(onClick = { searchQuery = "" }) {
                            Text("مسح", fontSize = 11.sp, color = AuditSlateMuted)
                        }
                    }
                } else {
                    null
                }
            )

            // 6) قائمة بطاقات التداخل (عرض الملفين المتعارضين جنباً إلى جنب)
            if (isScanning) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CircularProgressIndicator(color = AuditEmerald)
                        Text(
                            text = "جاري فحص الهويات المتداخلة على مسار الخلفية...",
                            color = AuditSlateMuted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else if (filteredConflicts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, AuditBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = if (searchQuery.isBlank()) {
                                    "لا توجد حالات «${activeTabType.arabicTitle}» في القاعدة الرسمية"
                                } else {
                                    "لا توجد نتائج مطابقة لـ \"$searchQuery\""
                                },
                                color = AuditEmerald,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "يمكنك التبديل بين التبويبات أو الضغط على «تحديث الفحص» لإعادة التدقيق.",
                                color = AuditSlateMuted,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(
                        items = filteredConflicts,
                        key = { it.conflictId }
                    ) { conflict ->
                        IntegrityConflictComparisonCard(
                            item = conflict,
                            onOpenFamilyFile = onOpenFamilyFile
                        )
                    }
                }
            }
        }

        val activeExport = savedExportResult
        if (activeExport != null) {
            AlertDialog(
                onDismissRequest = { savedExportResult = null },
                containerColor = Color.White,
                shape = RoundedCornerShape(18.dp),
                title = {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Text(
                            text = "✅ تم حفظ تقرير التداخل في الجوال بنجاح",
                            color = AuditEmerald,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                text = {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(
                                    text = "اسم الملف:",
                                    color = AuditSlateMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = activeExport.fileName,
                                    color = AuditSlateDark,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "مكان الحفظ:",
                                    color = AuditSlateMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0xFFECFDF5),
                                    border = BorderStroke(1.dp, AuditEmerald.copy(alpha = 0.45f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = activeExport.humanReadablePath,
                                        color = AuditSlateDark,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        lineHeight = 18.sp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    val opened = PublicDownloadsExporter.openSavedCsv(context, activeExport)
                                    if (!opened) {
                                        Toast.makeText(
                                            context,
                                            "لا يوجد تطبيق Excel أو قارئ CSV مثبّت لفتح الملف مباشرة؛ يمكنك الوصول إليه من مجلد التنزيلات.",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AuditEmerald),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = "📂 فتح الملف",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    val shared = PublicDownloadsExporter.shareSavedCsv(context, activeExport)
                                    if (!shared) {
                                        Toast.makeText(
                                            context,
                                            "تعذر فتح قائمة المشاركة",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                },
                                border = BorderStroke(1.dp, AuditIndigo),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = "📤 مشاركة",
                                    color = AuditIndigo,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { savedExportResult = null }) {
                        Text(
                            text = "إغلاق",
                            color = AuditSlateMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            )
        }
    }
}

/**
 * تحميل وتمرير مباشر لقوائم الكيانات لمن يرغب بالربط السريع بدون lambda مخصصة.
 */
@Composable
fun HouseholdIntegrityAuditorScreen(
    families: List<FamilyEntity>,
    children: List<ChildEntity>,
    onOpenFamilyFile: (familyFileId: Long, familyNationalId: String) -> Unit,
    onBack: () -> Unit = {},
    fileProviderAuthority: String? = null
) {
    HouseholdIntegrityAuditorScreen(
        onRunAudit = { HouseholdIntegrityEngine.auditEntities(families, children) },
        onOpenFamilyFile = onOpenFamilyFile,
        onBack = onBack,
        fileProviderAuthority = fileProviderAuthority
    )
}

@Composable
private fun AuditSummaryMetricCard(
    title: String,
    count: Int,
    accentColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) accentColor.copy(alpha = 0.12f) else Color.White,
        border = BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) accentColor else AuditBorder
        ),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(
                text = count.toString(),
                color = accentColor,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = title,
                color = AuditSlateDark,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun IntegrityConflictComparisonCard(
    item: IntegrityConflictItem,
    onOpenFamilyFile: (familyFileId: Long, familyNationalId: String) -> Unit
) {
    val accentColor = when (item.conflictType) {
        IntegrityConflictType.DUPLICATE_WIFE -> AuditCrimson
        IntegrityConflictType.ROLE_DUPLICATION -> AuditAmber
        IntegrityConflictType.SHARED_CHILDREN -> AuditIndigo
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.32f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // رأس البطاقة: نوع التداخل ورقم الهوية المتداخلة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "الهوية المتداخلة: ${item.conflictingNationalId}",
                        color = AuditSlateDark,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    if (item.conflictingPersonName.isNotBlank()) {
                        Text(
                            text = "الاسم المسجل: ${item.conflictingPersonName}",
                            color = AuditSlateMuted,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = accentColor.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = item.conflictType.arabicTitle,
                        color = accentColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(AuditBorder)
            )

            // عرض الملفين المتعارضين جنباً إلى جنب
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ConflictingFilePanel(
                    panelTitle = "الملف الأول",
                    file = item.firstFile,
                    accentColor = AuditEmerald,
                    onOpenFamilyFile = onOpenFamilyFile,
                    modifier = Modifier.weight(1f)
                )
                ConflictingFilePanel(
                    panelTitle = "الملف الثاني المتعارض",
                    file = item.secondFile,
                    accentColor = accentColor,
                    onOpenFamilyFile = onOpenFamilyFile,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun ConflictingFilePanel(
    panelTitle: String,
    file: HouseholdFileSummary,
    accentColor: Color,
    onOpenFamilyFile: (familyFileId: Long, familyNationalId: String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AuditSurfaceBg,
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.28f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(9.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = panelTitle,
                    color = accentColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "#${file.familyFileId}",
                    color = AuditSlateMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = file.headName,
                color = AuditSlateDark,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "هوية الرب: ${file.headNationalId.ifBlank { "-" }}",
                color = AuditSlateMuted,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "المنطقة: ${file.subRegion}",
                color = AuditSlateMuted,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = "الحالة: ${file.status}",
                color = AuditSlateDark,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (file.roleLabel.isNotBlank()) {
                Text(
                    text = "الدور: ${file.roleLabel}",
                    color = accentColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Button(
                onClick = { onOpenFamilyFile(file.familyFileId, file.headNationalId) },
                colors = ButtonDefaults.buttonColors(containerColor = accentColor),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "فتح ملف الأسرة",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

private fun normalizeAuditSearch(raw: String): String {
    val trimmed = raw.trim().lowercase(Locale.ROOT)
    if (trimmed.isBlank()) return ""
    val sb = StringBuilder(trimmed.length)
    for (ch in trimmed) {
        when (ch) {
            in '٠'..'٩' -> sb.append(('0'.code + (ch.code - '٠'.code)).toChar())
            in '۰'..'۹' -> sb.append(('0'.code + (ch.code - '۰'.code)).toChar())
            else -> sb.append(ch)
        }
    }
    return sb.toString()
}
