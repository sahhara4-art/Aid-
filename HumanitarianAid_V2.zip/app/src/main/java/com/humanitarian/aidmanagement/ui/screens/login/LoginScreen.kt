package com.humanitarian.aidmanagement.ui.screens.login

import android.app.Application
import android.content.Context
import android.content.ContextWrapper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository

/**
 * دالة مساعدة لاستخراج FragmentActivity الفعلي من سياق Compose بأمان تام ومنع انهيار التطبيق (ClassCastException)
 */
fun Context.findFragmentActivity(): FragmentActivity? {
    var currentContext: Context? = this
    while (currentContext != null) {
        if (currentContext is FragmentActivity) {
            return currentContext
        }
        currentContext = if (currentContext is ContextWrapper) {
            currentContext.baseContext
        } else {
            null
        }
    }
    return null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    database: AidDatabase,
    repository: AidRepository,
    onLoginSuccess: () -> Unit,
    viewModel: LoginViewModel = viewModel(
        factory = LoginViewModel.Factory(
            application = LocalContext.current.applicationContext as Application,
            database = database,
            repository = repository
        )
    )
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // إطلاق فحص البصمة عبر BiometricPrompt
    fun launchBiometricPrompt() {
        try {
            val fragmentActivity = context.findFragmentActivity()
            if (fragmentActivity == null) {
                viewModel.setErrorMessage("عذراً، تعذر العثور على واجهة FragmentActivity للمصادقة الحيوية")
                return
            }

            val biometricManager = try {
                BiometricManager.from(context)
            } catch (e: Exception) {
                null
            }
            if (biometricManager == null) {
                viewModel.setErrorMessage("مستشعر البصمة غير متاح حالياً، يرجى إدخال كلمة المرور.")
                return
            }

            val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL

            val canAuthenticate = try {
                biometricManager.canAuthenticate(authenticators)
            } catch (e: Exception) {
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE
            }

            if (canAuthenticate != BiometricManager.BIOMETRIC_SUCCESS) {
                when (canAuthenticate) {
                    BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                        viewModel.setErrorMessage("لم يتم تسجيل أي بصمة في جهازك بعد. يرجى تسجيل بصمة في إعدادات النظام.")
                    }
                    BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
                        viewModel.setErrorMessage("هذا الجهاز لا يدعم مستشعر البصمة.")
                    }
                    else -> {
                        viewModel.setErrorMessage("مستشعر البصمة غير متاح حالياً، يرجى إدخال كلمة المرور.")
                    }
                }
                return
            }

            if (!uiState.hasSavedCredentials) {
                viewModel.setErrorMessage("يرجى تسجيل الدخول أولاً باسم المستخدم وكلمة المرور وتحديد 'تذكر بيانات الدخول' لتفعيل الدخول بالبصمة.")
                return
            }

            val executor = ContextCompat.getMainExecutor(context)
            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle("تسجيل الدخول ببصمة الأصبع")
                .setSubtitle("منظومة إدارة المساعدات الإنسانية")
                .setDescription("المس مستشعر البصمة للتحقق من هويتك والدخول السريع")
                .setNegativeButtonText("إلغاء")
                .build()

            val biometricPrompt = BiometricPrompt(
                fragmentActivity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        viewModel.loginWithBiometric(onLoginSuccess)
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                            errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                            errorCode != BiometricPrompt.ERROR_CANCELED
                        ) {
                            viewModel.setErrorMessage(errString.toString())
                        }
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        viewModel.setErrorMessage("لم يتم التعرف على بصمة الأصبع، يرجى المحاولة مرة أخرى.")
                    }
                }
            )

            biometricPrompt.authenticate(promptInfo)
        } catch (e: Exception) {
            android.util.Log.e("LoginScreen", "Biometric prompt launch handled safely: ${e.message}", e)
            viewModel.setErrorMessage("تعذر بدء المصادقة بالبصمة: ${e.localizedMessage ?: e.message}")
        }
    }

    // إظهار نافذة البصمة تلقائياً عند فتح الشاشة إذا كان مسجلاً ومفعلاً مسبقاً
    LaunchedEffect(uiState.canLoginWithBiometric) {
        try {
            if (viewModel.shouldAutoPromptBiometric()) {
                launchBiometricPrompt()
            }
        } catch (e: Exception) {
            android.util.Log.e("LoginScreen", "Auto biometric prompt safe catch: ${e.message}", e)
        }
    }

    val goldColor = Color(0xFFFFD700)
    val emeraldGreen = Color(0xFF10B981)
    val darkOliveGreen = Color(0xFF1B3B22)
    val midOliveShadow = Color(0xFF0E2313)
    val quranTextStyle = TextStyle(
        fontFamily = FontFamily.Serif,
        fontWeight = FontWeight.Bold,
        shadow = Shadow(
            color = Color.Black,
            offset = Offset(0f, 3f),
            blurRadius = 15f
        )
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            darkOliveGreen,
                            midOliveShadow,
                            Color(0xFF071009),
                            Color.Black
                        )
                    )
                )
        ) {
            // إضاءات برمجية محيطية هادئة تعزز الطابع الوطني والزجاجي دون أي موارد خارجية
            Box(
                modifier = Modifier
                    .size(300.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = (-60).dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                goldColor.copy(alpha = 0.14f),
                                emeraldGreen.copy(alpha = 0.10f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = (-70).dp, y = 70.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                emeraldGreen.copy(alpha = 0.16f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            // 3. المحتوى الرئيسي (الآيات القرآنية في النصف العلوي + البطاقة الزجاجية)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp)
                    .padding(top = 28.dp, bottom = 60.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // قسم الآيات القرآنية الكريمة بتنسيق المصحف في النصف العلوي
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "﴿ إِنَّ اللَّهَ يَأْمُرُ بِالْعَدْلِ وَالْإِحْسَانِ ﴾",
                        style = quranTextStyle.copy(
                            fontSize = 21.sp,
                            lineHeight = 32.sp,
                            color = goldColor
                        ),
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "﴿ وَيُطْعِمُونَ الطَّعَامَ عَلَىٰ حُبِّهِ مِسْكِينًا وَيَتِيمًا وَأَسِيرًا ﴾",
                        style = quranTextStyle.copy(
                            fontSize = 18.sp,
                            lineHeight = 30.sp,
                            color = Color.White
                        ),
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(22.dp))

                // 4. البطاقة الزجاجية الفاخرة لتسجيل الدخول
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(32.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White.copy(alpha = 0.15f)
                    ),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 26.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // شعار التطبيق داخل إطار زجاجي ذهبي-زمردي
                        Box(
                            modifier = Modifier
                                .size(68.dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            emeraldGreen.copy(alpha = 0.35f),
                                            goldColor.copy(alpha = 0.18f)
                                        )
                                    )
                                )
                                .border(
                                    width = 1.dp,
                                    color = Color.White.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(20.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolunteerActivism,
                                contentDescription = "شعار التطبيق",
                                tint = goldColor,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "نظام إدارة المساعدات الإنسانية",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                shadow = Shadow(color = Color.Black.copy(alpha = 0.6f), blurRadius = 8f)
                            ),
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "منظومة الترشيح والتوزيع الميداني المحمي",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.85f),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(22.dp))

                        val glassTextFieldColors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.White.copy(alpha = 0.10f),
                            unfocusedContainerColor = Color.White.copy(alpha = 0.08f),
                            focusedBorderColor = Color.White.copy(alpha = 0.78f),
                            unfocusedBorderColor = Color.White.copy(alpha = 0.32f),
                            focusedLabelColor = goldColor,
                            unfocusedLabelColor = Color.White.copy(alpha = 0.82f),
                            focusedLeadingIconColor = goldColor,
                            unfocusedLeadingIconColor = Color.White.copy(alpha = 0.85f),
                            focusedTrailingIconColor = Color.White,
                            unfocusedTrailingIconColor = Color.White.copy(alpha = 0.82f),
                            cursorColor = goldColor
                        )

                        // حقل اسم المستخدم (ممتلئ تلقائياً إذا كان مفعل خيار تذكرني)
                        OutlinedTextField(
                            value = uiState.username,
                            onValueChange = { viewModel.onUsernameChange(it) },
                            label = { Text("اسم المستخدم / البريد") },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = glassTextFieldColors,
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // حقل كلمة المرور (ممتلئ تلقائياً إذا كان مفعل خيار تذكرني)
                        OutlinedTextField(
                            value = uiState.password,
                            onValueChange = { viewModel.onPasswordChange(it) },
                            label = { Text("كلمة المرور") },
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null)
                            },
                            trailingIcon = {
                                IconButton(onClick = { viewModel.togglePasswordVisibility() }) {
                                    Icon(
                                        imageVector = if (uiState.passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = if (uiState.passwordVisible) "إخفاء كلمة المرور" else "إظهار كلمة المرور"
                                    )
                                }
                            },
                            visualTransformation = if (uiState.passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = glassTextFieldColors,
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // ميزة تذكر بيانات الدخول (Remember Me)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = uiState.rememberMe,
                                onCheckedChange = { viewModel.onRememberMeChange(it) },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = emeraldGreen,
                                    uncheckedColor = Color.White.copy(alpha = 0.7f),
                                    checkmarkColor = Color.White
                                )
                            )
                            Text(
                                text = "تذكر بيانات الدخول",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White
                            )
                        }

                        // عرض رسالة الخطأ بالعربية إن وجدت
                        if (uiState.errorMessage != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                color = Color(0xFFF43F5E).copy(alpha = 0.24f),
                                border = BorderStroke(1.dp, Color(0xFFFDA4AF).copy(alpha = 0.5f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = uiState.errorMessage ?: "",
                                    color = Color(0xFFFFE4E6),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(12.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // أزرار تسجيل الدخول وبصمة الأصبع
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // زر تسجيل الدخول الرئيسي بلون أخضر زمردي وتصميم زجاجي بارز
                            Button(
                                onClick = { viewModel.login(onLoginSuccess) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(54.dp),
                                shape = RoundedCornerShape(16.dp),
                                enabled = !uiState.isLoading,
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.45f)),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = emeraldGreen.copy(alpha = 0.88f),
                                    contentColor = Color.White,
                                    disabledContainerColor = emeraldGreen.copy(alpha = 0.45f)
                                ),
                                elevation = ButtonDefaults.buttonElevation(
                                    defaultElevation = 6.dp,
                                    pressedElevation = 2.dp
                                )
                            ) {
                                if (uiState.isLoading) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(24.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Login,
                                        contentDescription = null,
                                        modifier = Modifier.size(20.dp),
                                        tint = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "تسجيل الدخول",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                }
                            }

                            // أيقونة بصمة الأصبع (Fingerprint Icon)
                            OutlinedIconButton(
                                onClick = { launchBiometricPrompt() },
                                modifier = Modifier.size(54.dp),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(
                                    1.2.dp,
                                    if (uiState.canLoginWithBiometric) emeraldGreen.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.35f)
                                ),
                                colors = IconButtonDefaults.outlinedIconButtonColors(
                                    containerColor = if (uiState.canLoginWithBiometric) emeraldGreen.copy(alpha = 0.25f) else Color.White.copy(alpha = 0.10f)
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Fingerprint,
                                    contentDescription = "تسجيل الدخول بالبصمة",
                                    tint = if (uiState.canLoginWithBiometric) Color(0xFF6EE7B7) else Color.White.copy(alpha = 0.85f),
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        }

                        // إشعار توضيحي للدخول بالبصمة إذا كانت البيانات مسجلة
                        if (uiState.hasSavedCredentials) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = emeraldGreen.copy(alpha = 0.20f),
                                border = BorderStroke(0.8.dp, Color.White.copy(alpha = 0.25f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Fingerprint,
                                        contentDescription = null,
                                        tint = Color(0xFF6EE7B7),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "يمكنك الضغط على أيقونة البصمة للدخول السريع",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 5. توقيع المطور والمصمم في أقصى أسفل الشاشة
            Text(
                text = "تطوير وتصميم: أحمد السحار \"أبو محمود\"",
                style = MaterialTheme.typography.labelMedium.copy(
                    shadow = Shadow(
                        color = Color.Black,
                        offset = Offset(0f, 1.5f),
                        blurRadius = 6f
                    )
                ),
                color = Color.White.copy(alpha = 0.7f),
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(bottom = 14.dp, start = 16.dp, end = 16.dp)
            )
        }
    }
}
