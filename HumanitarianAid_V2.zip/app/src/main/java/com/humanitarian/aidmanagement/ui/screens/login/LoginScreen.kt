package com.humanitarian.aidmanagement.ui.screens.login

import android.app.Application
import android.content.Context
import android.content.ContextWrapper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository

/**
 * دالة مساعدة لاستخراج FragmentActivity الفعلي من سياق Compose بأمان تام ومنع انهيار التطبيق (ClassCastException)
 */
fun Context.findFragmentActivity(): FragmentActivity? {
    var currentContext: Context? = this
    while (currentContext != null) {
        if (currentContext is FragmentActivity) {
            return currentContext
        }
        currentContext = if (currentContext is ContextWrapper) {
            currentContext.baseContext
        } else {
            null
        }
    }
    return null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(
    database: AidDatabase,
    repository: AidRepository,
    onLoginSuccess: () -> Unit,
    viewModel: LoginViewModel = viewModel(
        factory = LoginViewModel.Factory(
            application = LocalContext.current.applicationContext as Application,
            database = database,
            repository = repository
        )
    )
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    // إطلاق فحص البصمة عبر BiometricPrompt
    fun launchBiometricPrompt() {
        try {
            val fragmentActivity = context.findFragmentActivity()
            if (fragmentActivity == null) {
                viewModel.setErrorMessage("عذراً، تعذر العثور على واجهة FragmentActivity للمصادقة الحيوية")
                return
            }

            val biometricManager = try {
                BiometricManager.from(context)
            } catch (e: Exception) {
                null
            }
            if (biometricManager == null) {
                viewModel.setErrorMessage("مستشعر البصمة غير متاح حالياً، يرجى إدخال كلمة المرور.")
                return
            }

            val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL

            val canAuthenticate = try {
                biometricManager.canAuthenticate(authenticators)
            } catch (e: Exception) {
                BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE
            }

            if (canAuthenticate != BiometricManager.BIOMETRIC_SUCCESS) {
                when (canAuthenticate) {
                    BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                        viewModel.setErrorMessage("لم يتم تسجيل أي بصمة في جهازك بعد. يرجى تسجيل بصمة في إعدادات النظام.")
                    }
                    BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
                        viewModel.setErrorMessage("هذا الجهاز لا يدعم مستشعر البصمة.")
                    }
                    else -> {
                        viewModel.setErrorMessage("مستشعر البصمة غير متاح حالياً، يرجى إدخال كلمة المرور.")
                    }
                }
                return
            }

            if (!uiState.hasSavedCredentials) {
                viewModel.setErrorMessage("يرجى تسجيل الدخول أولاً باسم المستخدم وكلمة المرور وتحديد 'تذكر بيانات الدخول' لتفعيل الدخول بالبصمة.")
                return
            }

            val executor = ContextCompat.getMainExecutor(context)
            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle("تسجيل الدخول ببصمة الأصبع")
                .setSubtitle("منظومة إدارة المساعدات الإنسانية")
                .setDescription("المس مستشعر البصمة للتحقق من هويتك والدخول السريع")
                .setNegativeButtonText("إلغاء")
                .build()

            val biometricPrompt = BiometricPrompt(
                fragmentActivity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        viewModel.loginWithBiometric(onLoginSuccess)
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                            errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                            errorCode != BiometricPrompt.ERROR_CANCELED
                        ) {
                            viewModel.setErrorMessage(errString.toString())
                        }
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        viewModel.setErrorMessage("لم يتم التعرف على بصمة الأصبع، يرجى المحاولة مرة أخرى.")
                    }
                }
            )

            biometricPrompt.authenticate(promptInfo)
        } catch (e: Exception) {
            android.util.Log.e("LoginScreen", "Biometric prompt launch handled safely: ${e.message}", e)
            viewModel.setErrorMessage("تعذر بدء المصادقة بالبصمة: ${e.localizedMessage ?: e.message}")
        }
    }

    // إظهار نافذة البصمة تلقائياً عند فتح الشاشة إذا كان مسجلاً ومفعلاً مسبقاً
    LaunchedEffect(uiState.canLoginWithBiometric) {
        try {
            if (viewModel.shouldAutoPromptBiometric()) {
                launchBiometricPrompt()
            }
        } catch (e: Exception) {
            android.util.Log.e("LoginScreen", "Auto biometric prompt safe catch: ${e.message}", e)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // الشعار والأيقونة
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VolunteerActivism,
                        contentDescription = "شعار التطبيق",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "نظام إدارة المساعدات الإنسانية",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "منظومة الترشيح والتوزيع الميداني المحمي",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                // حقل اسم المستخدم (ممتلئ تلقائياً إذا كان مفعل خيار تذكرني)
                OutlinedTextField(
                    value = uiState.username,
                    onValueChange = { viewModel.onUsernameChange(it) },
                    label = { Text("اسم المستخدم / البريد") },
                    leadingIcon = {
                        Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                // حقل كلمة المرور (ممتلئ تلقائياً إذا كان مفعل خيار تذكرني)
                OutlinedTextField(
                    value = uiState.password,
                    onValueChange = { viewModel.onPasswordChange(it) },
                    label = { Text("كلمة المرور") },
                    leadingIcon = {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    },
                    trailingIcon = {
                        IconButton(onClick = { viewModel.togglePasswordVisibility() }) {
                            Icon(
                                imageVector = if (uiState.passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = if (uiState.passwordVisible) "إخفاء كلمة المرور" else "إظهار كلمة المرور"
                            )
                        }
                    },
                    visualTransformation = if (uiState.passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                // ميزة تذكر بيانات الدخول (Remember Me)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = uiState.rememberMe,
                        onCheckedChange = { viewModel.onRememberMeChange(it) },
                        colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                    )
                    Text(
                        text = "تذكر بيانات الدخول",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // عرض رسالة الخطأ بالعربية إن وجدت
                if (uiState.errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.12f)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = uiState.errorMessage ?: "",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(12.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // أزرار تسجيل الدخول وبصمة الأصبع
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // زر تسجيل الدخول الرئيسي
                    Button(
                        onClick = { viewModel.login(onLoginSuccess) },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        enabled = !uiState.isLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        if (uiState.isLoading) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(24.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "تسجيل الدخول",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    }

                    // أيقونة بصمة الأصبع (Fingerprint Icon)
                    OutlinedIconButton(
                        onClick = { launchBiometricPrompt() },
                        modifier = Modifier.size(52.dp),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(
                            1.5.dp,
                            if (uiState.canLoginWithBiometric) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                        ),
                        colors = IconButtonDefaults.outlinedIconButtonColors(
                            containerColor = if (uiState.canLoginWithBiometric) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else Color.Transparent
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = "تسجيل الدخول بالبصمة",
                            tint = if (uiState.canLoginWithBiometric) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // إشعار توضيحي للدخول بالبصمة إذا كانت البيانات مسجلة
                if (uiState.hasSavedCredentials) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Fingerprint,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "يمكنك الضغط على أيقونة البصمة للدخول السريع",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}
