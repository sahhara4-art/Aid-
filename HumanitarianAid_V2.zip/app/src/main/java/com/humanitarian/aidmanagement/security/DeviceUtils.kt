package com.humanitarian.aidmanagement.security

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.provider.Settings
import java.security.MessageDigest
import java.util.UUID

/**
 * أداة استخراج البصمة العتادية الثابتة للجهاز (Hardware Fingerprint).
 * تعتمد على ANDROID_ID مع خصائص العتاد الثابتة في Build، وتوفر بديلاً محلياً محفوظاً (UUID)
 * في حال فشل قراءة ANDROID_ID لضمان عدم حدوث أي انهيار على كافة الأجهزة.
 */
object DeviceUtils {

    private const val FALLBACK_PREFS_NAME = "device_identity_fallback_prefs"
    private const val KEY_FALLBACK_UUID = "device_fallback_uuid"

    @SuppressLint("HardwareIds")
    fun getHardwareId(context: Context): String {
        return try {
            val appContext = context.applicationContext ?: context
            val androidId = try {
                Settings.Secure.getString(
                    appContext.contentResolver,
                    Settings.Secure.ANDROID_ID
                )?.trim().orEmpty()
            } catch (_: Exception) {
                ""
            } catch (_: Throwable) {
                ""
            }

            val stableIdentity = if (androidId.isNotBlank() && !androidId.equals("9774d56d682e549c", ignoreCase = true)) {
                androidId
            } else {
                getOrCreateFallbackUuid(appContext)
            }

            val rawFingerprint = try {
                listOf(
                    stableIdentity,
                    Build.BOARD.orEmpty(),
                    Build.BRAND.orEmpty(),
                    Build.DEVICE.orEmpty(),
                    Build.HARDWARE.orEmpty(),
                    Build.MANUFACTURER.orEmpty(),
                    Build.MODEL.orEmpty(),
                    Build.PRODUCT.orEmpty()
                ).joinToString(separator = "|")
            } catch (_: Throwable) {
                stableIdentity
            }

            val hexUpper = try {
                val digest = MessageDigest.getInstance("SHA-256")
                    .digest(rawFingerprint.toByteArray(Charsets.UTF_8))
                digest.joinToString(separator = "") { byte ->
                    "%02X".format(byte)
                }.take(16)
            } catch (_: Throwable) {
                stableIdentity.replace("-", "").uppercase().take(16).padEnd(16, '0')
            }

            "HW-${hexUpper.chunked(4).joinToString("-")}"
        } catch (_: Exception) {
            "HW-0000-0000-0000"
        } catch (_: Throwable) {
            "HW-0000-0000-0000"
        }
    }

    private fun getOrCreateFallbackUuid(context: Context): String {
        return try {
            val prefs = context.getSharedPreferences(FALLBACK_PREFS_NAME, Context.MODE_PRIVATE)
            val existing = prefs.getString(KEY_FALLBACK_UUID, null)?.trim()
            if (!existing.isNullOrBlank()) {
                existing
            } else {
                val generated = UUID.randomUUID().toString()
                try {
                    prefs.edit().putString(KEY_FALLBACK_UUID, generated).apply()
                } catch (_: Throwable) {
                }
                generated
            }
        } catch (_: Throwable) {
            try {
                UUID.randomUUID().toString()
            } catch (_: Throwable) {
                "FALLBACK_DEVICE_ID"
            }
        }
    }

    fun getDeviceSummary(): String {
        return try {
            val brand = Build.MANUFACTURER.orEmpty().replaceFirstChar { it.uppercase() }
            val model = Build.MODEL.orEmpty()
            val androidVer = Build.VERSION.RELEASE.orEmpty()
            "$brand $model (Android $androidVer)".trim()
        } catch (_: Throwable) {
            "Android Device"
        }
    }
}
