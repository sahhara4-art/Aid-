package com.humanitarian.aidmanagement.security

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.provider.Settings
import java.security.MessageDigest

/**
 * أداة استخراج البصمة العتادية الثابتة للجهاز (Hardware Fingerprint).
 * تعتمد على ANDROID_ID مع خصائص العتاد الثابتة في Build لضمان عدم تغيير البصمة
 * إلا عند تغيّر الجهاز الفعلي أو إعادة ضبط المصنع.
 */
object DeviceUtils {

    @SuppressLint("HardwareIds")
    fun getHardwareId(context: Context): String {
        return try {
            val appContext = context.applicationContext ?: context
            val androidId = try {
                Settings.Secure.getString(
                    appContext.contentResolver,
                    Settings.Secure.ANDROID_ID
                )?.trim().orEmpty()
            } catch (_: Throwable) {
                ""
            }

            val rawFingerprint = listOf(
                androidId.ifBlank { "UNKNOWN_ANDROID_ID" },
                Build.BOARD.orEmpty(),
                Build.BRAND.orEmpty(),
                Build.DEVICE.orEmpty(),
                Build.HARDWARE.orEmpty(),
                Build.MANUFACTURER.orEmpty(),
                Build.MODEL.orEmpty(),
                Build.PRODUCT.orEmpty()
            ).joinToString(separator = "|")

            val digest = MessageDigest.getInstance("SHA-256")
                .digest(rawFingerprint.toByteArray(Charsets.UTF_8))

            val hexUpper = digest.joinToString(separator = "") { byte ->
                "%02X".format(byte)
            }.take(16)

            "HW-${hexUpper.chunked(4).joinToString("-")}"
        } catch (_: Throwable) {
            "HW-0000-0000-0000"
        }
    }

    fun getDeviceSummary(): String {
        return try {
            val brand = Build.MANUFACTURER.orEmpty().replaceFirstChar { it.uppercase() }
            val model = Build.MODEL.orEmpty()
            val androidVer = Build.VERSION.RELEASE.orEmpty()
            "$brand $model (Android $androidVer)".trim()
        } catch (_: Throwable) {
            "Android Device"
        }
    }
}
