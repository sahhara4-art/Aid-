package com.humanitarian.aidmanagement.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.DashboardStats
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.ui.components.charts.InteractiveAnalyticsChartsCard
import com.humanitarian.aidmanagement.ui.components.SyncDetailsDialog
import com.humanitarian.aidmanagement.ui.components.SyncStatusBanner

data class AidCategoryUi(
    val id: Int,
    val name: String,
    val count: Int,
    val icon: ImageVector,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigateToFamilies: () -> Unit = {},
    onNavigateToNomination: () -> Unit = {},
    onNavigateToReports: () -> Unit = {},
    onNavigateToDelivery: () -> Unit = {},
    onNavigateToAccounts: () -> Unit = {},
    onNavigateToBackup: () -> Unit = {},
    onNavigateToGeographic: () -> Unit = {},
    onNavigateToProjects: () -> Unit = {},
    onLogout: () -> Unit = {}
) {
    val repository = viewModel.repository
    val uiState by viewModel.uiState.collectAsState()

    val stats = uiState.stats
    val localityStats = uiState.localityStats
    val aidTypeStats = uiState.aidTypeStats
    val categories = uiState.categories

    var fromDate by remember { mutableStateOf("2026-01-01") }
    var toDate by remember { mutableStateOf("2026-12-31") }
    var showSyncDialog by remember { mutableStateOf(false) }
    val syncState by viewModel.syncState.collectAsState()
    val currentUser = uiState.currentUser ?: repository.getCurrentUser()
    val isManager = currentUser == null || currentUser.RoleID == 1 || currentUser.UserName.equals("admin", ignoreCase = true)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. شريط حالة المزامنة والاتصال الحي
            item {
                SyncStatusBanner(
                    repository = repository,
                    onOpenSyncDetails = { showSyncDialog = true }
                )
            }

            // 2. بطاقة ترويسة وهوية المستخدم وتصفية النطاق الزمني
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isManager) Color(0xFFE11D48).copy(alpha = 0.15f)
                                            else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isManager) Icons.Default.Security else Icons.Default.Person,
                                        contentDescription = null,
                                        tint = if (isManager) Color(0xFFE11D48) else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text(
                                            text = currentUser?.fullName ?: "مدير النظام (admin)",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (isManager) Color(0xFFE11D48).copy(alpha = 0.15f) else Color(0xFF10B981).copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = if (isManager) "مدير عام" else "مستخدم معتمد",
                                                color = if (isManager) Color(0xFFE11D48) else Color(0xFF10B981),
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "كافة الصلاحيات مفعلة • مزامنة فورية",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                        maxLines = 1
                                    )
                                }
                            }

                            // أزرار التزامن والإدارة السريعة
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                IconButton(onClick = { showSyncDialog = true }) {
                                    Icon(
                                        imageVector = if (syncState.isOnline) Icons.Default.CloudSync else Icons.Default.CloudOff,
                                        contentDescription = "التزامن",
                                        tint = if (syncState.isOnline) MaterialTheme.colorScheme.primary else Color(0xFFF59E0B)
                                    )
                                }
                                if (isManager) {
                                    IconButton(onClick = onNavigateToAccounts) {
                                        Icon(
                                            Icons.Default.AdminPanelSettings,
                                            contentDescription = "الصلاحيات",
                                            tint = Color(0xFFE11D48)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "نطاق المتابعة وتدفق المساعدات",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = fromDate,
                                onValueChange = { fromDate = it },
                                label = { Text("من تاريخ", style = MaterialTheme.typography.bodySmall) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = toDate,
                                onValueChange = { toDate = it },
                                label = { Text("إلى تاريخ", style = MaterialTheme.typography.bodySmall) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                        }
                    }
                }
            }

            // 3. شبكة بطاقات العمليات الميدانية السريعة (تصميم شبكي مصغر Grid بعمودين)
            item {
                Text(
                    text = "العمليات الميدانية السريعة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // الصف الأول: تسليم وصرف المساعدات (صرف فوري) + العرض المرئي للتوزيع الجغرافي (المناطق الـ 5)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        DashboardActionCard(
                            title = "تسليم المساعدات",
                            badge = "صرف فوري",
                            subtitle = "سندات الصرف والباركود",
                            icon = Icons.Default.CheckCircle,
                            color = Color(0xFF10B981),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToDelivery
                        )

                        DashboardActionCard(
                            title = "التوزيع الجغرافي",
                            badge = "المناطق الـ 5 🇵🇸",
                            subtitle = "كثافة الأسر والمراكز",
                            icon = Icons.Default.Map,
                            color = Color(0xFF047857),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToGeographic
                        )
                    }

                    // الصف الثاني: إدارة الحسابات أو سجل الأسر + كشوفات وتقارير PDF
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (isManager) {
                            DashboardActionCard(
                                title = "إدارة الحسابات",
                                badge = "لوحة المدير",
                                subtitle = "الصلاحيات والأمان",
                                icon = Icons.Default.Security,
                                color = Color(0xFFE11D48),
                                modifier = Modifier.weight(1f),
                                onClick = onNavigateToAccounts
                            )
                        } else {
                            DashboardActionCard(
                                title = "سجل الأسر",
                                badge = "المستفيدين",
                                subtitle = "بحث وتدقيق المستحقين",
                                icon = Icons.Default.FamilyRestroom,
                                color = Color(0xFF0D9488),
                                modifier = Modifier.weight(1f),
                                onClick = onNavigateToFamilies
                            )
                        }

                        DashboardActionCard(
                            title = "كشوفات وتقارير",
                            badge = "PDF معتمد",
                            subtitle = "تصدير كشوفات الطباعة",
                            icon = Icons.Default.PictureAsPdf,
                            color = Color(0xFF0284C7),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToReports
                        )
                    }
                }
            }

            // 4. شبكة البطاقات الإحصائية الست الرئيسية
            item {
                Text(
                    text = "المؤشرات الإحصائية الميدانية",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatCard(
                            title = "إجمالي الأسر",
                            value = "${stats?.totalFamilies ?: 0}",
                            unit = "أسرة",
                            icon = Icons.Default.FamilyRestroom,
                            color = Color(0xFF0D9488),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToFamilies
                        )
                        StatCard(
                            title = "إجمالي المستفيدين",
                            value = "${stats?.totalBeneficiaries ?: 0}",
                            unit = "فرد",
                            icon = Icons.Default.Group,
                            color = Color(0xFF0284C7),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToFamilies
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatCard(
                            title = "إجمالي المساعدات",
                            value = "${stats?.totalAidRecords ?: 0}",
                            unit = "طرد/معونة",
                            icon = Icons.Default.Inventory2,
                            color = Color(0xFF8B5CF6),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToReports
                        )
                        StatCard(
                            title = "المشاريع المنفذة",
                            value = "${stats?.totalProjects ?: 0}",
                            unit = "مشروع",
                            icon = Icons.Default.AssignmentTurnedIn,
                            color = Color(0xFFF59E0B),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToProjects
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatCard(
                            title = "عدد المرشحين",
                            value = "${stats?.totalSelectedCandidates ?: 0}",
                            unit = "مرشح",
                            icon = Icons.Default.HowToReg,
                            color = Color(0xFF10B981),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToNomination
                        )
                        StatCard(
                            title = "المستفيدين المستلمين",
                            value = "${stats?.distinctBeneficiaries ?: 0}",
                            unit = "مستلم فعلي",
                            icon = Icons.Default.CheckCircle,
                            color = Color(0xFFEC4899),
                            modifier = Modifier.weight(1f),
                            onClick = onNavigateToDelivery
                        )
                    }
                }
            }

            // 5. بطاقة الرسوم البيانية التفاعلية لتحليلات التوزيع الميداني
            item {
                InteractiveAnalyticsChartsCard(
                    localityStats = localityStats,
                    aidTypeStats = aidTypeStats,
                    onNavigateToReports = onNavigateToReports
                )
            }

            // 6. قسم تصنيفات المساعدات الإحدى عشرة بالترتيب
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "تصنيفات المساعدات (11 نوعاً)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "التوزيع الميداني حسب نوع المعونة",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                            }
                            FilledTonalButton(
                                onClick = onNavigateToNomination,
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.HowToReg, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("بدء الترشيح", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (categories.isEmpty()) {
                            Text(
                                text = "لا توجد حركات تسليم مساعدات مسجلة بعد في قاعدة البيانات",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                modifier = Modifier.padding(vertical = 12.dp)
                            )
                        } else {
                            categories.forEach { category ->
                                CategoryListItem(category = category)
                                Spacer(modifier = Modifier.height(6.dp))
                            }
                        }

                    }
                }
            }
        }

        if (showSyncDialog) {
            SyncDetailsDialog(
                repository = repository,
                onDismiss = { showSyncDialog = false }
            )
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    unit: String = "",
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .wrapContentHeight()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(color.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (unit.isNotEmpty()) {
                    Text(
                        text = unit,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * بطاقة إجرائية شبكية مدمجة للوحة التحكم
 * تضمن عدم انكسار الشارات (مثل "صرف فوري") رأسياً عبر تخصيص مساحة مستقلة ومنع الـ softWrap
 */
@Composable
fun DashboardActionCard(
    title: String,
    badge: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .wrapContentHeight()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.2.dp, color.copy(alpha = 0.3f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(color.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = color.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = badge,
                        color = color,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun CategoryListItem(category: AidCategoryUi) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(category.color.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    category.icon,
                    contentDescription = null,
                    tint = category.color,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = "${category.id}. ${category.name}",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = category.color.copy(alpha = 0.15f)
            ) {
                Text(
                    text = "${category.count} مساعدة",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = category.color,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }
    }
}

/**
 * دالة توافقية تقبل AidRepository وتنشئ DashboardViewModel تلقائياً
 */
@Composable
fun DashboardScreen(
    repository: AidRepository,
    viewModel: DashboardViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = DashboardViewModel.Factory(repository)
    ),
    onNavigateToFamilies: () -> Unit,
    onNavigateToNomination: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToDelivery: () -> Unit = {},
    onNavigateToAccounts: () -> Unit = {},
    onNavigateToBackup: () -> Unit = {},
    onNavigateToGeographic: () -> Unit = {},
    onNavigateToProjects: () -> Unit = {},
    onLogout: () -> Unit = {}
) {
    DashboardScreen(
        viewModel = viewModel,
        onNavigateToFamilies = onNavigateToFamilies,
        onNavigateToNomination = onNavigateToNomination,
        onNavigateToReports = onNavigateToReports,
        onNavigateToDelivery = onNavigateToDelivery,
        onNavigateToAccounts = onNavigateToAccounts,
        onNavigateToBackup = onNavigateToBackup,
        onNavigateToGeographic = onNavigateToGeographic,
        onNavigateToProjects = onNavigateToProjects,
        onLogout = onLogout
    )
}
