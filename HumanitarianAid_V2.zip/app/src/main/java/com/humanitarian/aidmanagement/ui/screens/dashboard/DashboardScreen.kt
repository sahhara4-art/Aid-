package com.humanitarian.aidmanagement.ui.screens.dashboard

import android.app.DatePickerDialog
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.DashboardStats
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.components.charts.InteractiveAnalyticsChartsCard
import com.humanitarian.aidmanagement.ui.components.SyncDetailsDialog
import com.humanitarian.aidmanagement.ui.components.SyncStatusBanner
import java.util.Calendar
import java.util.Locale

data class AidCategoryUi(
    val id: Int,
    val name: String,
    val count: Int,
    val icon: ImageVector,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigateToFamilies: () -> Unit = {},
    onNavigateToNomination: () -> Unit = {},
    onNavigateToReports: () -> Unit = {},
    onNavigateToDelivery: () -> Unit = {},
    onNavigateToAccounts: () -> Unit = {},
    onNavigateToBackup: () -> Unit = {},
    onNavigateToGeographic: () -> Unit = {},
    onNavigateToProjects: () -> Unit = {},
    onNavigateToExcelImport: () -> Unit = {},
    onNavigateToDynamicReportExport: () -> Unit = {},
    onLogout: () -> Unit = {}
) {
    val repository = viewModel.repository
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val fromDateState by viewModel.fromDate.collectAsStateWithLifecycle()
    val toDateState by viewModel.toDate.collectAsStateWithLifecycle()
    val totalNominees by viewModel.totalNomineesCount.collectAsStateWithLifecycle()
    val actualRecipients by viewModel.actualRecipientsCount.collectAsStateWithLifecycle()
    val totalAids by viewModel.totalAidsCount.collectAsStateWithLifecycle()

    val acmUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val repoUser by repository.currentUserFlow.collectAsStateWithLifecycle()
    val currentUser = acmUser ?: repoUser
    val currentPermissions by repository.currentUserPermissionsFlow.collectAsStateWithLifecycle()
    val sessionPermissions by AccessControlManager.permissionsFlow.collectAsStateWithLifecycle()

    val isSuperAdminUser = currentUser?.UserName?.trim() == "admin"

    val permissions: List<String> = remember(sessionPermissions, currentPermissions, currentUser, isSuperAdminUser) {
        if (isSuperAdminUser) {
            (AccessControlManager.ALL_ACTIONS.map { it.first } + AccessControlManager.ALL_SCREENS.map { it.first }).distinct()
        } else {
            val fromUser = currentUser?.permissions
                ?.split(",", ";", "|", "\n")
                ?.map { it.trim() }
                ?.filter { it.isNotBlank() }
                ?: emptyList()
            if (fromUser.isNotEmpty()) {
                fromUser
            } else {
                (sessionPermissions + currentPermissions).distinct()
            }
        }
    }

    val canViewHomeCards = permissions.contains("CAN_VIEW_HOME_CARDS")
    val canManageUsers = permissions.contains("CAN_MANAGE_USERS")
    val canAccessBiDashboard = permissions.contains("CAN_ACCESS_BI_DASHBOARD")
    val canManageFamilies = permissions.contains("CAN_MANAGE_FAMILIES")
    val canRunFiltration = permissions.contains("CAN_RUN_FILTRATION")
    val canDeliverAid = permissions.contains("CAN_DELIVER_AID")
    val canBackupCloud = permissions.contains("CAN_BACKUP_CLOUD")
    val canBackupLocal = permissions.contains("CAN_BACKUP_LOCAL")
    val canManageProjects = permissions.contains(AccessControlManager.CAN_MANAGE_PROJECTS)

    var showSyncDialog by remember { mutableStateOf(false) }
    val syncState by viewModel.syncState.collectAsStateWithLifecycle()

    // التحكم في طي / توسيع ترويسة إدارة المساعدات لتوفير مساحة الشاشة (Compact / Collapsible Header)
    var isHeaderExpanded by remember { mutableStateOf(false) }

    val context = LocalContext.current

    // دوال فتح منتقي التاريخ التفاعلي (DatePickerDialog)
    fun openDatePicker(isFrom: Boolean) {
        val calendar = Calendar.getInstance()
        val currentStr = if (isFrom) fromDateState else toDateState
        val parts = currentStr.split("-")
        val y = parts.getOrNull(0)?.toIntOrNull() ?: calendar.get(Calendar.YEAR)
        val m = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val d = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(context, { _, year, month, dayOfMonth ->
            val formatted = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth)
            if (isFrom) {
                viewModel.onDateRangeChanged(formatted, toDateState)
            } else {
                viewModel.onDateRangeChanged(fromDateState, formatted)
            }
        }, y, m, d).show()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFF0F9FF),
                            Color(0xFFF5F3FF),
                            Color(0xFFECFDF5)
                        )
                    )
                )
        ) {
            // إضاءات خلفية ناعمة لإبراز التأثير الزجاجي للبطاقات
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = 70.dp, y = (-40).dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF38BDF8).copy(alpha = 0.16f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .align(Alignment.BottomStart)
                    .offset(x = (-80).dp, y = 60.dp)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF10B981).copy(alpha = 0.14f),
                                Color.Transparent
                            )
                        ),
                        shape = CircleShape
                    )
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 1. شريط حالة المزامنة والاتصال الحي (مخفي تماماً إذا لم يمتلك صلاحية النسخ الاحتياطي)
                if (isSuperAdminUser || canBackupCloud || canBackupLocal) {
                    item {
                        SyncStatusBanner(
                            repository = repository,
                            onOpenSyncDetails = { showSyncDialog = true }
                        )
                    }
                }

                // 2. ترويسة مدمجة قابلة للطي
                item {
                    CompactDashboardHeader(
                        fromDate = fromDateState,
                        toDate = toDateState,
                        isExpanded = isHeaderExpanded,
                        onToggleExpand = { isHeaderExpanded = !isHeaderExpanded },
                        onPickFromDate = { openDatePicker(true) },
                        onPickToDate = { openDatePicker(false) },
                        onSelectPreset = { from, to -> viewModel.onDateRangeChanged(from, to) },
                        onOpenSync = { showSyncDialog = true },
                        onNavigateToAccounts = onNavigateToAccounts,
                        isOnline = syncState.isOnline,
                        isManager = isSuperAdminUser,
                        canManageUsers = isSuperAdminUser || canManageUsers,
                        canAccessSync = isSuperAdminUser || canBackupCloud || canBackupLocal,
                        userName = currentUser?.fullName ?: "مستخدم النظام"
                    )
                }

                // 3. محتوى لوحة القيادة بناءً على Sealed Interface UiState
                when (val state = uiState) {
                    is DashboardUiState.Loading -> {
                        item {
                            DashboardLoadingState()
                        }
                    }
                    is DashboardUiState.Error -> {
                        item {
                            DashboardErrorState(
                                message = state.message,
                                onRetry = { viewModel.refresh() }
                            )
                        }
                    }
                    is DashboardUiState.Success -> {
                        item {
                            AnimatedVisibility(
                                visible = true,
                                enter = fadeIn(tween(400)) + expandVertically(tween(400))
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                    // أ) شريط ملخص الفترة الزمنية المحددة والعمليات (بيانات حية 100% من DAO)
                                    if (canViewHomeCards && (canDeliverAid || canAccessBiDashboard || canManageFamilies)) {
                                        Card(
                                            shape = RoundedCornerShape(20.dp),
                                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.75f)),
                                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
                                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                                    Text(
                                                        text = "الفترة: ${state.fromDate} إلى ${state.toDate}",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                }

                                                if (canDeliverAid || canAccessBiDashboard) {
                                                    Surface(
                                                        shape = RoundedCornerShape(10.dp),
                                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                                    ) {
                                                        Text(
                                                            text = "مساعدات الفترة: ${state.totalDeliveriesInPeriod}",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.primary,
                                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                        )
                                                    }
                                                } else if (canManageFamilies) {
                                                    Surface(
                                                        shape = RoundedCornerShape(10.dp),
                                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                                    ) {
                                                        Text(
                                                            text = "إجمالي الأسر: ${state.stats.totalFamilies}",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.primary,
                                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    // ب) قسم المشاريع المطروحة حديثاً التي تتطلب ترشيحاً
                                    if (canViewHomeCards && (canRunFiltration || canManageProjects)) {
                                        ActiveProjectsSection(
                                            projects = state.activeProjects,
                                            onNavigateToNomination = onNavigateToNomination
                                        )
                                    }

                                    // ج) شبكة البطاقات الإحصائية الرئيسية (LazyVerticalGrid عمودين)
                                    if (canViewHomeCards) {
                                        PrimaryStatsGrid(
                                            stats = state.stats,
                                            permissions = permissions,
                                            nomineesCount = totalNominees,
                                            actualRecipientsCount = actualRecipients,
                                            totalAidsCount = totalAids,
                                            onNavigateToFamilies = onNavigateToFamilies,
                                            onNavigateToReports = onNavigateToReports,
                                            onNavigateToProjects = onNavigateToProjects,
                                            onNavigateToNomination = onNavigateToNomination,
                                            onNavigateToDelivery = onNavigateToDelivery
                                        )
                                    }

                                    // د) بطاقة الرسوم البيانية المستقلة والعريضة للمحليات
                                    if (canAccessBiDashboard) {
                                        InteractiveAnalyticsChartsCard(
                                            localityStats = state.localityStats,
                                            aidTypeStats = state.aidTypeStats,
                                            onNavigateToReports = onNavigateToReports
                                        )
                                    }

                                    // هـ) بطاقة التوزيعات والإحصائيات
                                    if (canViewHomeCards && (canManageFamilies || canAccessBiDashboard)) {
                                        DynamicBreakdownsCard(
                                            injuryStats = state.injuryStats,
                                            damageStats = state.damageStats,
                                            approvalStats = state.approvalStats,
                                            residentStats = state.residentStats,
                                            localityStats = state.localityStats,
                                            aidTypeStats = state.aidTypeStats,
                                            aidCategories = state.aidCategories
                                        )
                                    }

                                    // و) قائمة تصنيفات المساعدات الفعلية في LazyColumn ديناميكية
                                    if (canViewHomeCards && (canAccessBiDashboard || canDeliverAid || canManageProjects)) {
                                        AidCategoriesSection(
                                            categories = state.categories,
                                            distinctCategories = state.aidCategories
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // العلامة المائية أسفل الشاشة الرئيسية
                item {
                    Text(
                        text = "تصميم وتطوير: أحمد السحار (أبو محمود)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp, bottom = 24.dp, start = 16.dp, end = 16.dp)
                    )
                }
            }
        }
    }

    if (showSyncDialog) {
        SyncDetailsDialog(
            repository = repository,
            onDismiss = { showSyncDialog = false }
        )
    }
}

/**
 * ترويسة مدمجة ذكية (Compact Collapsible Header)
 */
@Composable
private fun CompactDashboardHeader(
    fromDate: String,
    toDate: String,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onPickFromDate: () -> Unit,
    onPickToDate: () -> Unit,
    onSelectPreset: (String, String) -> Unit,
    onOpenSync: () -> Unit,
    onNavigateToAccounts: () -> Unit,
    isOnline: Boolean,
    isManager: Boolean,
    canManageUsers: Boolean,
    canAccessSync: Boolean,
    userName: String
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.75f)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // الشريط المدمج السطحي الدائم
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                if (isManager) MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isManager) Icons.Default.Security else Icons.Default.Person,
                            contentDescription = null,
                            tint = if (isManager) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column(modifier = Modifier.wrapContentHeight()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = userName,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isManager) MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
                                       else MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                            ) {
                                Text(
                                    text = if (isManager) "مهندس النظام" else "مشرف",
                                    color = if (isManager) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    maxLines = 1
                                )
                            }
                        }
                        Text(
                            text = "نطاق الفلترة: $fromDate إلى $toDate",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // أزرار سريعة ومفتاح طي/توسيع النطاق الزمني
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    if (canAccessSync) {
                        IconButton(onClick = onOpenSync, modifier = Modifier.size(32.dp)) {
                            Icon(
                                imageVector = if (isOnline) Icons.Default.CloudSync else Icons.Default.CloudOff,
                                contentDescription = "التزامن",
                                tint = if (isOnline) MaterialTheme.colorScheme.primary else Color(0xFFF59E0B),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    if (canManageUsers) {
                        IconButton(onClick = onNavigateToAccounts, modifier = Modifier.size(32.dp)) {
                            Icon(
                                Icons.Default.AdminPanelSettings,
                                contentDescription = "الصلاحيات",
                                tint = Color(0xFFE11D48),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // زر التوسيع / الطي
                    IconButton(onClick = onToggleExpand, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "توسيع النطاق الزمني",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // محتوى النطاق الزمني القابل للطي
            AnimatedVisibility(visible = isExpanded) {
                val now = remember { Calendar.getInstance() }
                val curYear = now.get(Calendar.YEAR)
                val curMonth = now.get(Calendar.MONTH) + 1
                val curLastDay = now.getActualMaximum(Calendar.DAY_OF_MONTH)
                val curMonthFrom = String.format(Locale.US, "%04d-%02d-01", curYear, curMonth)
                val curMonthTo = String.format(Locale.US, "%04d-%02d-%02d", curYear, curMonth, curLastDay)
                val threeMonthsAgoCal = remember {
                    (Calendar.getInstance().clone() as Calendar).apply { add(Calendar.MONTH, -2) }
                }
                val threeMonthsFrom = String.format(
                    Locale.US,
                    "%04d-%02d-01",
                    threeMonthsAgoCal.get(Calendar.YEAR),
                    threeMonthsAgoCal.get(Calendar.MONTH) + 1
                )

                Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f))

                    Text(
                        text = "تحديد الفترة الزمنية:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // زر من تاريخ
                        Surface(
                            onClick = onPickFromDate,
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.65f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("من تاريخ", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(fromDate, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }

                        // زر إلى تاريخ
                        Surface(
                            onClick = onPickToDate,
                            shape = RoundedCornerShape(12.dp),
                            color = Color.White.copy(alpha = 0.65f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("إلى تاريخ", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(toDate, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    // خيارات سريعة للنطاق الزمني
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        QuickDateChip(label = "الشهر الحالي") {
                            onSelectPreset(curMonthFrom, curMonthTo)
                        }
                        QuickDateChip(label = "آخر 3 شهور") {
                            onSelectPreset(threeMonthsFrom, curMonthTo)
                        }
                        QuickDateChip(label = "العام $curYear") {
                            onSelectPreset("$curYear-01-01", "$curYear-12-31")
                        }
                        QuickDateChip(label = "كافة الفترات") {
                            onSelectPreset("2020-01-01", "${curYear + 4}-12-31")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickDateChip(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = Color.White.copy(alpha = 0.65f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f))
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

/**
 * حالة التحميل
 */
@Composable
private fun DashboardLoadingState() {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.75f)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(40.dp),
                color = MaterialTheme.colorScheme.primary,
                strokeWidth = 3.dp
            )
            Text(
                text = "جاري تحميل الإحصائيات...",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * حالة الخطأ مع زر إعادة المحاولة
 */
@Composable
private fun DashboardErrorState(message: String, onRetry: () -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2).copy(alpha = 0.85f)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(36.dp))
            Text(text = message, color = Color(0xFFDC2626), fontSize = 12.sp, textAlign = TextAlign.Center)
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("إعادة المحاولة")
            }
        }
    }
}

private data class DashboardStatItem(
    val title: String,
    val value: String,
    val unit: String,
    val icon: ImageVector,
    val color: Color,
    val onClick: () -> Unit
)

/**
 * شبكة البطاقات الإحصائية (تتكيف ديناميكياً وتخفي الأقسام غير المصرح بها تماماً)
 */
@Composable
private fun PrimaryStatsGrid(
    stats: DashboardStats,
    permissions: List<String>,
    onNavigateToFamilies: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToProjects: () -> Unit,
    onNavigateToNomination: () -> Unit,
    onNavigateToDelivery: () -> Unit,
    nomineesCount: Int = stats.totalNomineesCount,
    actualRecipientsCount: Int = stats.actualRecipientsCount,
    totalAidsCount: Int = stats.totalAidRecords
) {
    val statsList = buildList {
        if (permissions.contains("CAN_MANAGE_FAMILIES")) {
            add(DashboardStatItem("إجمالي الأسر", "${stats.totalFamilies}", "أسرة", Icons.Default.FamilyRestroom, Color(0xFF0D9488), onNavigateToFamilies))
            add(DashboardStatItem("إجمالي الأفراد", "${stats.totalBeneficiaries}", "فرد", Icons.Default.Group, Color(0xFF0284C7), onNavigateToFamilies))
        }
        if (permissions.contains("CAN_ACCESS_BI_DASHBOARD") || permissions.contains("CAN_DELIVER_AID")) {
            add(DashboardStatItem("إجمالي المساعدات", "$totalAidsCount", "طرد/سجل", Icons.Default.Inventory2, Color(0xFF8B5CF6), onNavigateToReports))
        }
        if (permissions.contains(AccessControlManager.CAN_MANAGE_PROJECTS) || permissions.contains("CAN_RUN_FILTRATION")) {
            add(DashboardStatItem("المشاريع المنفذة", "${stats.totalProjects}", "مشروع", Icons.Default.AssignmentTurnedIn, Color(0xFFF59E0B), onNavigateToProjects))
        }
        if (permissions.contains("CAN_RUN_FILTRATION")) {
            add(DashboardStatItem("عدد المرشحين", "$nomineesCount", "مرشح", Icons.Default.HowToReg, Color(0xFF10B981), onNavigateToNomination))
        }
        if (permissions.contains("CAN_DELIVER_AID")) {
            add(DashboardStatItem("المستلمون الفعليون", "$actualRecipientsCount", "مستفيد", Icons.Default.CheckCircle, Color(0xFFEC4899), onNavigateToDelivery))
        }
    }

    if (statsList.isEmpty()) return

    val rowCount = (statsList.size + 1) / 2
    val cardHeight = 124.dp
    val gridSpacing = 10.dp
    val gridHeight = cardHeight * rowCount + gridSpacing * (rowCount - 1).coerceAtLeast(0)

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "المؤشرات الإحصائية",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxWidth()
                .height(gridHeight),
            userScrollEnabled = false,
            horizontalArrangement = Arrangement.spacedBy(gridSpacing),
            verticalArrangement = Arrangement.spacedBy(gridSpacing)
        ) {
            items(statsList, key = { it.title }) { stat ->
                StatCard(
                    title = stat.title,
                    value = stat.value,
                    unit = stat.unit,
                    icon = stat.icon,
                    color = stat.color,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(cardHeight),
                    onClick = stat.onClick
                )
            }
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    unit: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.75f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
        modifier = modifier.clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            color.copy(alpha = 0.06f),
                            Color.Transparent
                        )
                    )
                )
                .padding(14.dp)
        ) {
            // أيقونة معبرة ملونة في زاوية البطاقة
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(color.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 4.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(end = 40.dp)
                )

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    AnimatedContent(
                        targetState = value,
                        transitionSpec = {
                            (slideInVertically { height -> height } + fadeIn()).togetherWith(
                                slideOutVertically { height -> -height } + fadeOut()
                            )
                        },
                        label = "statCounterAnim"
                    ) { targetVal ->
                        Text(
                            text = targetVal,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = color,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = unit,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

/**
 * بطاقة التوزيعات والإحصائيات
 */
@Composable
private fun DynamicBreakdownsCard(
    injuryStats: List<KeyCountRecord>,
    damageStats: List<KeyCountRecord>,
    approvalStats: List<KeyCountRecord>,
    residentStats: List<KeyCountRecord>,
    localityStats: List<LocalityDistributionStat>,
    aidTypeStats: List<AidTypeDistributionStat> = emptyList(),
    aidCategories: List<String> = emptyList()
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("المحليات", "التصنيفات", "أضرار الحرب", "حالة الإصابة", "الاعتماد والإقامة")

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.75f)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .wrapContentHeight()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PieChart, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }
                Text("التوزيع والإحصائيات", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
            }

            // تبويبات التبديل بين التوزيعات
            ScrollableTabRow(
                selectedTabIndex = selectedTab.coerceIn(0, tabTitles.size - 1),
                edgePadding = 0.dp,
                divider = {},
                containerColor = Color.Transparent
            ) {
                tabTitles.forEachIndexed { index, title ->
                    val isSelected = selectedTab == index
                    Tab(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

            when (selectedTab) {
                0 -> {
                    // توزيع المحليات
                    val activeLocalities = localityStats.filter { it.familiesCount > 0 }
                    if (activeLocalities.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "التوزيع حسب المحليات",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            activeLocalities.forEach { loc ->
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(loc.localityName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "${loc.familiesCount} أسرة (${String.format(Locale.US, "%.1f%%", loc.quotaPercent)})",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    val targetProgress = (loc.quotaPercent / 100.0).toFloat().coerceIn(0f, 1f)
                                    val animatedProgress by animateFloatAsState(
                                        targetValue = targetProgress,
                                        animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing),
                                        label = "locProgressAnim"
                                    )
                                    LinearProgressIndicator(
                                        progress = { animatedProgress },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = MaterialTheme.colorScheme.primary,
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                    )
                                }
                            }
                        }
                    } else {
                        Text("لا توجد بيانات أسر مسجلة في المحليات بعد", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                1 -> {
                    // التوزيع حسب التصنيف
                    val activeAidTypes = aidTypeStats.filter { it.deliveredCount > 0 }
                    if (activeAidTypes.isNotEmpty()) {
                        val totalDelivered = activeAidTypes.sumOf { it.deliveredCount }.coerceAtLeast(1)
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "التوزيع حسب التصنيف (${activeAidTypes.size})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            activeAidTypes.forEach { cat ->
                                key(cat.aidTypeId) {
                                    val percent = (cat.deliveredCount.toDouble() / totalDelivered.toDouble()) * 100.0
                                    Card(
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.65f)),
                                        border = BorderStroke(1.dp, Color(cat.colorHex).copy(alpha = 0.28f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(10.dp),
                                            verticalArrangement = Arrangement.spacedBy(5.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(cat.aidTypeName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                Text(
                                                    text = "${cat.deliveredCount} مساعدة (${String.format(Locale.US, "%.1f%%", percent)})",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(cat.colorHex)
                                                )
                                            }
                                            val targetCatProgress = (percent / 100.0).toFloat().coerceIn(0f, 1f)
                                            val animatedCatProgress by animateFloatAsState(
                                                targetValue = targetCatProgress,
                                                animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing),
                                                label = "catProgressAnim_${cat.aidTypeId}"
                                            )
                                            LinearProgressIndicator(
                                                progress = { animatedCatProgress },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(6.dp)
                                                    .clip(RoundedCornerShape(3.dp)),
                                                color = Color(cat.colorHex),
                                                trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else if (aidCategories.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            aidCategories.forEach { catName ->
                                key(catName) {
                                    Card(
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.65f)),
                                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 10.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(catName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                                            ) {
                                                Text("0 مساعدة", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Text("لا توجد تصنيفات مساعدات مسجلة بعد", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                2 -> {
                    RenderKeyValueDistribution(
                        items = damageStats,
                        emptyText = "لا توجد بيانات أضرار مسجلة بعد"
                    )
                }
                3 -> {
                    RenderKeyValueDistribution(
                        items = injuryStats,
                        emptyText = "لا توجد بيانات إصابات مسجلة بعد"
                    )
                }
                4 -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("حالة الاعتماد:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        RenderKeyValueDistribution(items = approvalStats, emptyText = "لا توجد بيانات اعتماد")

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("حالة الإقامة:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        RenderKeyValueDistribution(items = residentStats, emptyText = "لا توجد بيانات إقامة")
                    }
                }
            }
        }
    }
}

@Composable
private fun RenderKeyValueDistribution(items: List<KeyCountRecord>, emptyText: String) {
    if (items.isEmpty()) {
        Text(emptyText, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    val total = items.sumOf { it.count }.coerceAtLeast(1)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { record ->
            val percent = (record.count.toDouble() / total.toDouble()) * 100.0
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(record.keyName, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "${record.count} (${String.format(Locale.US, "%.1f%%", percent)})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                val targetKvProgress = (percent / 100.0).toFloat().coerceIn(0f, 1f)
                val animatedKvProgress by animateFloatAsState(
                    targetValue = targetKvProgress,
                    animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing),
                    label = "kvProgressAnim"
                )
                LinearProgressIndicator(
                    progress = { animatedKvProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                )
            }
        }
    }
}

/**
 * قسم تصنيفات المساعدات الديناميكي بالكامل (LazyColumn + بيانات حقيقية من قاعدة البيانات)
 */
@Composable
private fun AidCategoriesSection(
    categories: List<AidCategoryUi>,
    distinctCategories: List<String> = emptyList()
) {
    val nonZeroCategories = remember(categories) { categories.filter { it.count > 0 } }

    var selectedCategoryFilter by remember(nonZeroCategories) { mutableStateOf("الكل") }
    val dynamicCategoryTabs = remember(distinctCategories, nonZeroCategories) {
        val nonZeroNames = nonZeroCategories.map { it.name }.distinct()
        if (nonZeroNames.isEmpty()) emptyList()
        else listOf("الكل") + nonZeroNames
    }
    val filteredCategories = remember(selectedCategoryFilter, nonZeroCategories) {
        if (selectedCategoryFilter == "الكل") nonZeroCategories
        else nonZeroCategories.filter { it.name == selectedCategoryFilter }
    }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.75f)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Category, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                    Text("التوزيع حسب التصنيف", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                }

                if (nonZeroCategories.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = "${nonZeroCategories.size} تصنيف",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            // تبويبات التصنيفات الديناميكية المستمدة من قاعدة البيانات
            if (dynamicCategoryTabs.size > 1) {
                ScrollableTabRow(
                    selectedTabIndex = dynamicCategoryTabs.indexOf(selectedCategoryFilter).coerceAtLeast(0),
                    edgePadding = 0.dp,
                    divider = {},
                    containerColor = Color.Transparent
                ) {
                    dynamicCategoryTabs.forEach { tabName ->
                        val isSelected = selectedCategoryFilter == tabName
                        Tab(
                            selected = isSelected,
                            onClick = { selectedCategoryFilter = tabName },
                            text = {
                                Text(
                                    text = tabName,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

            if (filteredCategories.isEmpty()) {
                Text(
                    text = "لا توجد مساعدات مسلمة في هذه الفترة",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            } else {
                val totalCategoriesCount = nonZeroCategories.sumOf { it.count }.coerceAtLeast(1)
                val maxVisibleRows = 6
                val visibleRows = filteredCategories.size.coerceAtMost(maxVisibleRows)
                val listHeight = 56.dp * visibleRows + 8.dp * (visibleRows - 1).coerceAtLeast(0)

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(listHeight),
                    userScrollEnabled = filteredCategories.size > maxVisibleRows,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredCategories, key = { it.id }) { category ->
                        val pct = (category.count.toDouble() / totalCategoriesCount.toDouble()) * 100.0
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.65f)),
                            border = BorderStroke(1.dp, category.color.copy(alpha = 0.25f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(category.color.copy(alpha = 0.14f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(category.icon, contentDescription = null, tint = category.color, modifier = Modifier.size(18.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = category.name,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = category.color.copy(alpha = 0.14f)
                                ) {
                                    Text(
                                        text = "${category.count} مساعدة (${String.format(Locale.US, "%.1f%%", pct)})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = category.color,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * قسم المشاريع المطروحة حديثاً التي تتطلب ترشيحاً
 */
@Composable
fun ActiveProjectsSection(
    projects: List<com.humanitarian.aidmanagement.data.local.entities.ProjectEntity>,
    onNavigateToNomination: () -> Unit
) {
    if (projects.isEmpty()) return

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.75f)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFFDC2626).copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = null,
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "المشاريع المطروحة حديثاً (تتطلب ترشيحاً)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "مشاريع إغاثية جديدة بحاجة لمفاضلة وترشيح الأسر المستحقة",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Badge أحمر يوضح عدد المشاريع التي تتطلب عملاً وترشيحاً
                BadgedBox(
                    badge = {
                        Badge(
                            containerColor = Color(0xFFDC2626),
                            contentColor = Color.White
                        ) {
                            Text(
                                text = "${projects.size}",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = "تنبيه مشاريع نشطة",
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                projects.take(2).forEach { project ->
                    ActiveProjectItemCard(
                        project = project,
                        onNavigateToNomination = onNavigateToNomination
                    )
                }
            }
        }
    }
}

@Composable
private fun ActiveProjectItemCard(
    project: com.humanitarian.aidmanagement.data.local.entities.ProjectEntity,
    onNavigateToNomination: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDC2626).copy(alpha = 0.25f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Badge أحمر بارز للتنبيه بضرورة الترشيح
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFFDC2626)
                    ) {
                        Text(
                            text = "يتطلب ترشيحاً",
                            color = Color.White,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }

                    Text(
                        text = project.projectName,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "كود: ${project.projectNumber}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(text = "•", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFF1976D2).copy(alpha = 0.1f)
                    ) {
                        Text(
                            text = "الكمية: ${project.quantity} حصة",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1976D2),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                    if (project.fundingInstitution.isNotBlank()) {
                        Text(text = "•", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                        Text(
                            text = "الممول: ${project.fundingInstitution}",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onNavigateToNomination,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text("ترشيح", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * دالة توافقية تقبل AidRepository وتنشئ DashboardViewModel تلقائياً
 */
@Composable
fun DashboardScreen(
    repository: AidRepository,
    viewModel: DashboardViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = DashboardViewModel.Factory(repository)
    ),
    onNavigateToFamilies: () -> Unit,
    onNavigateToNomination: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToDelivery: () -> Unit = {},
    onNavigateToAccounts: () -> Unit = {},
    onNavigateToBackup: () -> Unit = {},
    onNavigateToGeographic: () -> Unit = {},
    onNavigateToProjects: () -> Unit = {},
    onNavigateToExcelImport: () -> Unit = {},
    onNavigateToDynamicReportExport: () -> Unit = {},
    onLogout: () -> Unit = {}
) {
    DashboardScreen(
        viewModel = viewModel,
        onNavigateToFamilies = onNavigateToFamilies,
        onNavigateToNomination = onNavigateToNomination,
        onNavigateToReports = onNavigateToReports,
        onNavigateToDelivery = onNavigateToDelivery,
        onNavigateToAccounts = onNavigateToAccounts,
        onNavigateToBackup = onNavigateToBackup,
        onNavigateToGeographic = onNavigateToGeographic,
        onNavigateToProjects = onNavigateToProjects,
        onNavigateToExcelImport = onNavigateToExcelImport,
        onNavigateToDynamicReportExport = onNavigateToDynamicReportExport,
        onLogout = onLogout
    )
}
