package com.humanitarian.aidmanagement.sync

import android.content.Context
import android.provider.Settings
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AuditLogEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/**
 * FirestoreSyncManager - محرك التزامن السحابي المركزي اللحظي (Google Firebase Firestore Master Node)
 *
 * الهيكلة المعمارية:
 * 1. Offline-First Single Source of Truth: قاعدة بيانات Room المحلية هي مصدر الحقيقة الوحيد للواجهة.
 * 2. Bridge Engine: يستمع لتعديلات Firestore اللحظية عبر SnapshotListeners، ويقوم بتحديث Room في أجزاء من الثانية.
 * 3. Master Node: خوادم جوجل هي النسخة الرسمية المركزية التي يتحكم بها المدير العام.
 * 4. Conflict Resolution: تطبيق شرط Override Priority لصالح حساب المدير.
 */
class FirestoreSyncManager private constructor(private val context: Context) {

    private var firestore: FirebaseFirestore? = null
    @Volatile
    private var isInitialized = false

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _totalUploadedCount = MutableStateFlow(0)
    val totalUploadedCount: StateFlow<Int> = _totalUploadedCount.asStateFlow()

    private val _totalMergedCount = MutableStateFlow(0)
    val totalMergedCount: StateFlow<Int> = _totalMergedCount.asStateFlow()

    private val _adminOverridesCount = MutableStateFlow(0)
    val adminOverridesCount: StateFlow<Int> = _adminOverridesCount.asStateFlow()

    private val _lastMergedDelta = MutableStateFlow<FirestoreSyncDelta?>(null)
    val lastMergedDelta: StateFlow<FirestoreSyncDelta?> = _lastMergedDelta.asStateFlow()

    private val _recentDeltas = MutableStateFlow<List<FirestoreSyncDelta>>(emptyList())
    val recentDeltas: StateFlow<List<FirestoreSyncDelta>> = _recentDeltas.asStateFlow()

    private val _lastSyncError = MutableStateFlow<String?>(null)
    val lastSyncError: StateFlow<String?> = _lastSyncError.asStateFlow()

    private val listenerRegistrations = ConcurrentHashMap<String, ListenerRegistration>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var listenerStartJob: Job? = null

    val deviceId: String by lazy {
        try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
                ?: java.util.UUID.randomUUID().toString()
        } catch (_: Exception) {
            java.util.UUID.randomUUID().toString()
        }
    }

    companion object {
        private const val TAG = "FirestoreSyncManager"
        const val ROOT_COLLECTION = "humanitarian_master"
        const val DELTAS_SUBCOLLECTION = "sync_deltas"
        const val FAMILIES_COLLECTION = "families"
        const val AID_RECORDS_COLLECTION = "aid_records"
        const val PROJECTS_COLLECTION = "projects"

        @Volatile
        private var INSTANCE: FirestoreSyncManager? = null

        fun getInstance(context: Context): FirestoreSyncManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: FirestoreSyncManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    /**
     * تهيئة الاتصال بـ Cloud Firestore وتفعيل التخزين المؤقت المحلي (Offline Persistence)
     */
    fun initialize() {
        if (isInitialized && firestore != null) return

        synchronized(this) {
            if (isInitialized && firestore != null) return
            try {
                if (FirebaseApp.getApps(context).isEmpty()) {
                    FirebaseApp.initializeApp(context)
                }

                val db = FirebaseFirestore.getInstance()
                try {
                    val settings = FirebaseFirestoreSettings.Builder()
                        .setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
                        .build()
                    db.firestoreSettings = settings
                } catch (e: Exception) {
                    Log.w(TAG, "Firestore settings adjustment note: ${e.message}")
                }

                firestore = db
                isInitialized = true
                _isConnected.value = true
                _lastSyncError.value = null
                Log.i(TAG, "Google Cloud Firestore Master Node initialized successfully with offline persistence.")
            } catch (e: Throwable) {
                val msg = "فشل تهيئة Cloud Firestore: ${e.localizedMessage ?: e.message}"
                Log.e(TAG, msg, e)
                _isConnected.value = false
                _lastSyncError.value = msg
            }
        }
    }

    fun getFirestoreInstance(): FirebaseFirestore? {
        if (!isInitialized || firestore == null) initialize()
        return firestore
    }

    /**
     * ضمان مصادقة Firebase (تسجيل الدخول المجهول تلقائياً إذا لم توجد جلسة)
     * لتلبية قاعدة (request.auth != null) في Firestore Security Rules
     */
    suspend fun ensureAuthenticated(): Boolean = withContext(Dispatchers.IO) {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            val auth = FirebaseAuth.getInstance()
            if (auth.currentUser != null) {
                return@withContext true
            }

            suspendCancellableCoroutine { continuation ->
                auth.signInAnonymously()
                    .addOnSuccessListener { result ->
                        _lastSyncError.value = null
                        Log.i(TAG, "Firebase Anonymous Auth active (uid=${result.user?.uid}).")
                        if (continuation.isActive) continuation.resume(true)
                    }
                    .addOnFailureListener { e ->
                        val msg = "فشل مصادقة Firebase المجهولة: ${e.localizedMessage ?: e.message}"
                        _lastSyncError.value = msg
                        Log.e(TAG, msg, e)
                        if (continuation.isActive) continuation.resume(false)
                    }
            }
        } catch (e: Throwable) {
            val msg = "خطأ في مصادقة Firebase: ${e.localizedMessage ?: e.message}"
            _lastSyncError.value = msg
            Log.e(TAG, msg, e)
            false
        }
    }

    /**
     * تشغيل مستمعات SnapshotListeners الحية للمراقبة اللحظية وتحديث Room
     */
    fun startRealtimeListener(database: AidDatabase, userLocalityId: Int = 0) {
        val db = getFirestoreInstance()
        if (db == null) {
            Log.w(TAG, "Firestore instance is null. Cannot start realtime listener.")
            return
        }

        listenerStartJob?.cancel()
        listenerStartJob = scope.launch {
            val authed = ensureAuthenticated()
            if (!authed && FirebaseAuth.getInstance().currentUser == null) {
                Log.w(TAG, "Proceeding to attach Firestore listener failed: FirebaseAuth user is null.")
                return@launch
            }
            attachRealtimeListenerInternal(db, database, userLocalityId)
        }
    }

    private fun attachRealtimeListenerInternal(
        db: FirebaseFirestore,
        database: AidDatabase,
        userLocalityId: Int
    ) {
        stopRealtimeListener()

        try {
            val deltasRef = db.collection(ROOT_COLLECTION)
                .document("deltas_hub")
                .collection(DELTAS_SUBCOLLECTION)

            val query = if (userLocalityId > 0) {
                deltasRef.whereEqualTo("localityId", userLocalityId)
                    .orderBy("clientTimestamp", Query.Direction.DESCENDING)
                    .limit(100)
            } else {
                deltasRef.orderBy("clientTimestamp", Query.Direction.DESCENDING)
                    .limit(100)
            }

            val registration = query.addSnapshotListener { snapshots, error ->
                if (error != null) {
                    val msg = "خطأ مستمع Firestore: ${error.localizedMessage ?: error.message}"
                    Log.e(TAG, msg, error)
                    _isConnected.value = false
                    _isListening.value = false
                    _lastSyncError.value = msg
                    return@addSnapshotListener
                }

                _isConnected.value = true
                _isListening.value = true
                _lastSyncError.value = null
                if (snapshots == null || snapshots.isEmpty) return@addSnapshotListener

                scope.launch {
                    processIncomingSnapshots(snapshots, database)
                }
            }

            listenerRegistrations["DELTAS_HUB"] = registration
            _isListening.value = true
            Log.i(TAG, "SnapshotListener active on Firestore Master Node for locality: $userLocalityId")
        } catch (e: Exception) {
            val msg = "تعذر تشغيل مستمع Firestore: ${e.localizedMessage ?: e.message}"
            Log.e(TAG, msg, e)
            _isListening.value = false
            _lastSyncError.value = msg
        }
    }

    fun stopRealtimeListener() {
        listenerRegistrations.values.forEach { it.remove() }
        listenerRegistrations.clear()
        _isListening.value = false
    }

    /**
     * معالجة الوثائق الواردة وتطبيق خوارزمية حل النزاعات ودمجها في Room
     */
    private suspend fun processIncomingSnapshots(snapshots: QuerySnapshot, database: AidDatabase) {
        for (docChange in snapshots.documentChanges) {
            if (docChange.type == DocumentChange.Type.ADDED || docChange.type == DocumentChange.Type.MODIFIED) {
                val data = docChange.document.data
                val delta = FirestoreSyncDelta.fromFirestoreMap(data)

                // تخطي الحركات الصادرة من هذا الجهاز نفسه لمنع ارتداد الحركات (Echo Prevention)
                if (delta.deviceId.isNotBlank() && delta.deviceId == deviceId) {
                    continue
                }

                val decision = ConflictResolver.resolve(
                    incomingDelta = delta,
                    localRecordRole = null,
                    localTimestamp = null
                )

                when (decision) {
                    ConflictResolver.ConflictDecision.DISCARD -> {
                        Log.d(TAG, "Delta ${delta.deltaId} discarded by ConflictResolver.")
                    }
                    ConflictResolver.ConflictDecision.APPLY,
                    ConflictResolver.ConflictDecision.OVERRIDE_LOCAL -> {
                        if (decision == ConflictResolver.ConflictDecision.OVERRIDE_LOCAL) {
                            _adminOverridesCount.value += 1
                        }
                        mergeDeltaIntoRoom(delta, database)
                    }
                }
            }
        }
    }

    /**
     * دمج التعديل القادم من سحابة Firestore داخل جداول Room DB المحلية
     */
    private suspend fun mergeDeltaIntoRoom(delta: FirestoreSyncDelta, database: AidDatabase) {
        withContext(Dispatchers.IO) {
            try {
                val json = runCatching { JSONObject(delta.payloadJson) }.getOrNull() ?: JSONObject()

                when (delta.entityType) {
                    "AID_RECORD" -> {
                        val recordId = delta.recordId.toLongOrNull() ?: return@withContext
                        if (delta.operation == "DELETE") {
                            database.aidRecordDao().deleteAidRecord(recordId)
                        } else {
                            val existing = database.aidRecordDao().getAidRecordById(recordId)
                            val recipientStatus = json.optString("recipientStatus", "")
                                .ifBlank { json.optString("status", existing?.recipientStatus ?: "مستلم") }
                            val actualDeliveryDate = json.optString("deliveryDate", "")
                                .ifBlank { json.optString("date", existing?.deliveryDate ?: "") }
                                .ifBlank { null }
                            val notes = if (json.has("notes")) json.optString("notes") else existing?.notes

                            if (existing != null) {
                                database.aidRecordDao().updateDeliveryStatus(
                                    recordId = recordId,
                                    status = recipientStatus,
                                    deliveryDate = actualDeliveryDate,
                                    notes = notes
                                )
                            } else if (delta.operation == "INSERT") {
                                val famId = json.optLong("familyID", json.optLong("familyId", 0L))
                                val prjId = json.optLong("projectID", json.optLong("projectId", 0L))
                                val aidTypeId = json.optInt("aidTypeID", json.optInt("aidTypeId", 1))
                                if (famId > 0L && prjId > 0L && !database.aidRecordDao().checkIfAidExists(famId, prjId)) {
                                    val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                                    database.aidRecordDao().insertAidRecord(
                                        AidRecordEntity(
                                            familyID = famId,
                                            aidTypeID = aidTypeId,
                                            projectID = prjId,
                                            aidDate = json.optString("aidDate", today).ifBlank { today },
                                            selectionDate = json.optString("selectionDate", today).ifBlank { today },
                                            recipientStatus = recipientStatus,
                                            warehouse = json.optString("warehouse", "المستودع الرئيسي"),
                                            aidValue = json.optDouble("aidValue", 0.0),
                                            deliveryDate = actualDeliveryDate,
                                            notes = notes
                                        )
                                    )
                                }
                            }
                        }
                        Log.i(TAG, "Merged AID_RECORD #$recordId (${delta.operation}) into Room from Firestore.")
                    }

                    "FAMILY" -> {
                        val familyId = delta.recordId.toLongOrNull() ?: return@withContext
                        val existing = database.familyDao().getFamilyById(familyId)
                        if (delta.operation == "DELETE") {
                            if (existing != null) {
                                database.familyDao().deleteFamily(existing)
                            }
                        } else if (existing != null) {
                            val devApproval = json.optString("developmentApproval", existing.developmentApproval)
                            val resStatus = json.optString("residentStatus", existing.residentStatus)
                            val shelter = json.optString("shelterStatus", existing.shelterStatus)
                            database.familyDao().updateFamilyStatus(
                                familyId = familyId,
                                developmentApproval = devApproval,
                                residentStatus = resStatus,
                                shelterStatus = shelter
                            )
                            val updatedName = json.optString("name", "").ifBlank { existing.name }
                            val updatedPhone = json.optString("primary_phone", "").ifBlank { existing.primary_phone }
                            val updatedMembers = if (json.has("members")) json.optInt("members", existing.familyMembersCount) else existing.familyMembersCount
                            if (updatedName != existing.name || updatedPhone != existing.primary_phone || updatedMembers != existing.familyMembersCount) {
                                database.familyDao().updateFamily(
                                    existing.copy(
                                        name = updatedName,
                                        primary_phone = updatedPhone,
                                        familyMembersCount = updatedMembers,
                                        developmentApproval = devApproval,
                                        residentStatus = resStatus,
                                        shelterStatus = shelter,
                                        modifiedDate = System.currentTimeMillis()
                                    )
                                )
                            }
                        } else if (delta.operation == "INSERT") {
                            val natId = json.optString("nationalID", "").trim()
                            val famName = json.optString("name", "").trim()
                            if (natId.isNotBlank() && famName.isNotBlank()) {
                                database.familyDao().insertFamily(
                                    FamilyEntity(
                                        nationalID = natId,
                                        name = famName,
                                        familyMembersCount = json.optInt("members", 1).coerceAtLeast(1),
                                        primary_phone = json.optString("primary_phone", ""),
                                        localityID = json.optInt("localityID", delta.localityId.coerceAtLeast(1)),
                                        developmentApproval = json.optString("developmentApproval", "معتمد"),
                                        residentStatus = json.optString("residentStatus", "مقيم"),
                                        shelterStatus = json.optString("shelterStatus", "إيواء داخلي")
                                    )
                                )
                            }
                        }
                        Log.i(TAG, "Merged FAMILY #$familyId (${delta.operation}) into Room from Firestore.")
                    }

                    "CHILD" -> {
                        val natId = json.optString("nationalID", "").trim()
                        if (delta.operation == "DELETE") {
                            if (natId.isNotBlank()) {
                                database.childDao().getChildByNationalId(natId)?.let {
                                    database.childDao().deleteChild(it)
                                }
                            }
                        } else {
                            val childName = json.optString("name", "").ifBlank { json.optString("childName", "") }.trim()
                            val famNatId = json.optString("familyNationalId", "").ifBlank { json.optString("familyNationalID", "") }.trim()
                            if (natId.isNotBlank() && childName.isNotBlank() && famNatId.isNotBlank()) {
                                val existingChild = database.childDao().getChildByNationalId(natId)
                                database.childDao().insertChild(
                                    ChildEntity(
                                        childID = existingChild?.childID ?: 0L,
                                        nationalID = natId,
                                        childName = childName,
                                        birthDate = json.optString("birthDate", existingChild?.birthDate ?: "2020-01-01"),
                                        gender = json.optString("gender", existingChild?.gender ?: "ذكر"),
                                        familyNationalID = famNatId,
                                        localityID = json.optInt("localityID", existingChild?.localityID ?: delta.localityId.coerceAtLeast(1)),
                                        shelterStatus = json.optString("shelterStatus", existingChild?.shelterStatus ?: "إيواء داخلي")
                                    )
                                )
                            }
                        }
                        Log.i(TAG, "Merged CHILD #${delta.recordId} (${delta.operation}) into Room from Firestore.")
                    }

                    "PROJECT" -> {
                        val projectId = delta.recordId.toLongOrNull() ?: return@withContext
                        if (delta.operation == "DELETE") {
                            database.projectDao().deleteProjectById(projectId)
                        } else {
                            val existing = database.projectDao().getProjectById(projectId)
                            val isActive = json.optBoolean("isActive", existing?.isActive ?: true)
                            val projectName = json.optString("projectName", existing?.projectName ?: "مشروع إنساني جديد")
                            val projectNumber = json.optString("projectNumber", existing?.projectNumber ?: "")

                            if (existing != null) {
                                if (json.has("isLocked")) {
                                    database.projectDao().setProjectLocked(projectId, json.optBoolean("isLocked", existing.isLocked))
                                }
                                database.projectDao().setProjectActive(projectId, isActive)
                            } else if (delta.operation == "INSERT" && projectName.isNotBlank()) {
                                val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                                database.projectDao().insertProject(
                                    ProjectEntity(
                                        projectID = projectId,
                                        projectNumber = projectNumber.ifBlank { "PRJ-$projectId" },
                                        projectName = projectName,
                                        aidTypeID = json.optInt("aidTypeID", 1),
                                        detailedDescription = json.optString("description", "مشروع متزامن من السحابة"),
                                        projectDate = json.optString("projectDate", today),
                                        fundingInstitution = json.optString("fundingInstitution", "جهة مانحة"),
                                        quantity = json.optInt("quantity", 100),
                                        isActive = isActive,
                                        isLocked = json.optBoolean("isLocked", false)
                                    )
                                )
                            }

                            if (delta.operation == "INSERT") {
                                try {
                                    com.humanitarian.aidmanagement.notifications.AidNotificationHelper.notifyNewProjectCreated(
                                        context = context,
                                        projectName = projectName,
                                        projectNumber = projectNumber
                                    )
                                } catch (e: Exception) {
                                    Log.w(TAG, "Notification failed for project #$projectId: ${e.message}")
                                }
                            }
                        }
                        Log.i(TAG, "Merged PROJECT #$projectId (${delta.operation}) into Room from Firestore.")
                    }
                }

                _lastMergedDelta.value = delta
                _totalMergedCount.value += 1

                val currentList = _recentDeltas.value.toMutableList()
                currentList.add(0, delta)
                if (currentList.size > 50) currentList.removeAt(currentList.lastIndex)
                _recentDeltas.value = currentList

                database.auditLogDao().insertLog(
                    AuditLogEntity(
                        userId = delta.userId,
                        userName = delta.userName,
                        userFullName = if (delta.isMasterAdminOverride) "مدير النظام (Master)" else "مشرف محلية (${delta.localityName})",
                        operationType = "مزامنة لحظية (${delta.operation})",
                        targetTable = delta.entityType,
                        recordId = delta.recordId,
                        description = "تم دمج التعديل لحظياً من Google Firestore: ${delta.operation} على السجل #${delta.recordId}"
                    )
                )
            } catch (e: Exception) {
                Log.e(TAG, "Failed to merge delta into Room: ${e.message}", e)
            }
        }
    }

    /**
     * رفع حركة Delta محلية إلى Google Cloud Firestore مع تأمين المصادقة المجهولة
     */
    suspend fun pushDelta(delta: FirestoreSyncDelta): Boolean = withContext(Dispatchers.IO) {
        val db = getFirestoreInstance() ?: return@withContext false
        val authed = ensureAuthenticated()
        if (!authed && FirebaseAuth.getInstance().currentUser == null) {
            return@withContext false
        }

        suspendCancellableCoroutine { continuation ->
            try {
                val docRef = db.collection(ROOT_COLLECTION)
                    .document("deltas_hub")
                    .collection(DELTAS_SUBCOLLECTION)
                    .document(delta.deltaId)

                docRef.set(delta.toFirestoreMap(), SetOptions.merge())
                    .addOnSuccessListener {
                        _totalUploadedCount.value += 1
                        _isConnected.value = true
                        _lastSyncError.value = null
                        Log.d(TAG, "Delta ${delta.deltaId} pushed to Firestore Master Node successfully.")
                        if (continuation.isActive) continuation.resume(true)
                    }
                    .addOnFailureListener { e ->
                        val msg = "فشل رفع الحركة إلى Firestore: ${e.localizedMessage ?: e.message}"
                        _lastSyncError.value = msg
                        Log.e(TAG, "$msg (${delta.deltaId})", e)
                        if (continuation.isActive) continuation.resume(false)
                    }
            } catch (e: Exception) {
                val msg = "استثناء أثناء الرفع إلى Firestore: ${e.localizedMessage ?: e.message}"
                _lastSyncError.value = msg
                Log.e(TAG, msg, e)
                if (continuation.isActive) continuation.resume(false)
            }
        }
    }

    /**
     * فحص الاتصال بخوادم Google Firestore
     */
    suspend fun pingFirestore(): Boolean = withContext(Dispatchers.IO) {
        val db = getFirestoreInstance() ?: return@withContext false
        val authed = ensureAuthenticated()
        if (!authed && FirebaseAuth.getInstance().currentUser == null) {
            return@withContext false
        }
        suspendCancellableCoroutine { continuation ->
            db.collection(ROOT_COLLECTION).document("health_check")
                .set(mapOf("lastPing" to FieldValue.serverTimestamp(), "deviceId" to deviceId))
                .addOnSuccessListener {
                    _isConnected.value = true
                    _lastSyncError.value = null
                    if (continuation.isActive) continuation.resume(true)
                }
                .addOnFailureListener { e ->
                    val msg = "فشل فحص الاتصال بـ Firestore: ${e.localizedMessage ?: e.message}"
                    _lastSyncError.value = msg
                    _isConnected.value = false
                    if (continuation.isActive) continuation.resume(false)
                }
        }
    }
}
