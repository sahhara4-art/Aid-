package com.humanitarian.aidmanagement.ui.screens.boot

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.humanitarian.aidmanagement.security.LicenseManager
import com.humanitarian.aidmanagement.ui.navigation.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * شاشة التوجيه الآمن والإقلاع غير المتزامن (Safe Asynchronous Boot Router).
 * تقلع فوراً دون أي عمليات تشفير أو I/O متزامنة على الـ Main Thread،
 * وتفحص الترخيص (DRM) في الخلفية عبر Dispatchers.IO ثم توجه المستخدم بأمان.
 */
@Composable
fun BootRouterScreen(navController: NavController) {
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        val isLicensed = withContext(Dispatchers.IO) {
            try {
                val appContext = context.applicationContext ?: context
                val valid = LicenseManager.checkLicenseAsync(appContext)
                if (valid) {
                    try {
                        com.humanitarian.aidmanagement.AidApplication.getInstanceSafely()?.let { app ->
                            app.database
                            app.repository
                        }
                    } catch (_: Throwable) {
                    }
                }
                valid
            } catch (_: Throwable) {
                false
            }
        }

        val targetRoute = if (isLicensed) {
            Screen.Login.route
        } else {
            Screen.LicenseActivation.route
        }

        try {
            navController.navigate(targetRoute) {
                popUpTo(Screen.BootRouter.route) { inclusive = true }
                launchSingleTop = true
            }
        } catch (_: Throwable) {
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF1E293B),
                        Color(0xFF064E3B)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .padding(horizontal = 28.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.18f),
                            Color.White.copy(alpha = 0.06f)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.40f),
                            Color.Transparent
                        )
                    ),
                    shape = RoundedCornerShape(28.dp)
                )
                .padding(horizontal = 32.dp, vertical = 28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF10B981).copy(alpha = 0.18f))
                        .border(
                            width = 1.dp,
                            color = Color(0xFF34D399).copy(alpha = 0.45f),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = null,
                        tint = Color(0xFF6EE7B7),
                        modifier = Modifier.size(32.dp)
                    )
                }

                CircularProgressIndicator(
                    color = Color(0xFF6EE7B7),
                    trackColor = Color.White.copy(alpha = 0.15f),
                    strokeWidth = 3.dp,
                    modifier = Modifier.size(36.dp)
                )

                Text(
                    text = "جاري تهيئة المنظومة والتحقق الأمني...",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
