package com.humanitarian.aidmanagement.ui.screens.warehouse

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.SavedExportResult
import com.humanitarian.aidmanagement.warehouse.*

// ============================================================================
// نافذة تأكيد حفظ ملف PDF في Downloads/HumanitarianAid مع فتح ومشاركة
// ============================================================================

@Composable
internal fun SavedPdfConfirmDialog(
    result: SavedExportResult,
    title: String,
    onOpenFile: () -> Unit,
    onShareFile: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "✅ تم حفظ ملف PDF بنجاح",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = PalestineGreenDark
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = SlateTextPrimary
                )
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFECFDF5),
                    border = BorderStroke(1.dp, Color(0xFF6EE7B7)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "اسم الملف: ${result.fileName}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF065F46)
                        )
                        Text(
                            text = "مسار الحفظ: ${result.humanReadablePath}",
                            fontSize = 11.sp,
                            color = Color(0xFF047857)
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onOpenFile,
                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("📂 فتح الملف", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onShareFile,
                        border = BorderStroke(1.dp, PalestineGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("📤 مشاركة", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق", fontWeight = FontWeight.Bold)
            }
        }
    )
}

// ============================================================================
// 1. نافذة إضافة / تعديل مخزن
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun WarehouseEditorDialog(
    existing: Warehouse?,
    onDismiss: () -> Unit,
    onSave: (Warehouse) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var location by remember { mutableStateOf(existing?.location ?: "") }
    var storageType by remember { mutableStateOf(existing?.storageType?.ifBlank { "جاف" } ?: WarehouseConstants.STORAGE_TYPES.first()) }
    var maxCapacityText by remember { mutableStateOf((existing?.maxCapacity ?: 10000L).toString()) }
    var status by remember { mutableStateOf(existing?.status?.ifBlank { "نشط" } ?: WarehouseConstants.WAREHOUSE_STATUSES.first()) }
    var keeperName by remember { mutableStateOf(existing?.keeperName ?: "") }
    var keeperId by remember { mutableStateOf(existing?.keeperId ?: "") }
    var keeperPhone by remember { mutableStateOf(existing?.keeperPhone ?: "") }
    var equipmentNotes by remember { mutableStateOf(existing?.equipmentNotes ?: "") }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existing == null) "إضافة مخزن جديد" else "تعديل بيانات المخزن",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorText = null },
                    label = { Text("اسم المخزن *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("الموقع / العنوان") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("نوع التخزين:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateTextPrimary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    WarehouseConstants.STORAGE_TYPES.forEach { option ->
                        FilterChip(
                            selected = storageType == option,
                            onClick = { storageType = option },
                            label = { Text(option, fontSize = 11.sp) }
                        )
                    }
                }
                Text("حالة المخزن:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateTextPrimary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    WarehouseConstants.WAREHOUSE_STATUSES.forEach { option ->
                        FilterChip(
                            selected = status == option,
                            onClick = { status = option },
                            label = { Text(option, fontSize = 11.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = maxCapacityText,
                    onValueChange = { maxCapacityText = it.filter { c -> c.isDigit() } },
                    label = { Text("السعة الاستيعابية القصوى (قطعة)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = keeperName,
                    onValueChange = { keeperName = it },
                    label = { Text("اسم أمين المخزن") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = keeperId,
                    onValueChange = { keeperId = it },
                    label = { Text("رقم هوية أمين المخزن") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = keeperPhone,
                    onValueChange = { keeperPhone = it },
                    label = { Text("جوال أمين المخزن") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = equipmentNotes,
                    onValueChange = { equipmentNotes = it },
                    label = { Text("عهدة التجهيزات (طبليات، رافعات، مولدات...)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorText != null) {
                    Text(errorText ?: "", color = PalestineRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.trim().isBlank()) {
                        errorText = "يرجى إدخال اسم المخزن"
                        return@Button
                    }
                    onSave(
                        Warehouse(
                            id = existing?.id ?: "",
                            name = name.trim(),
                            location = location.trim(),
                            storageType = storageType,
                            maxCapacity = maxCapacityText.toLongOrNull()?.coerceAtLeast(1L) ?: 10000L,
                            status = status,
                            keeperName = keeperName.trim(),
                            keeperId = keeperId.trim(),
                            keeperPhone = keeperPhone.trim(),
                            equipmentNotes = equipmentNotes.trim(),
                            createdAt = existing?.createdAt ?: ""
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("حفظ", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ============================================================================
// 2. نافذة إضافة / تعديل عامل في طاقم المخزن
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun WorkerEditorDialog(
    warehouseId: String,
    existing: WarehouseWorker?,
    onDismiss: () -> Unit,
    onSave: (WarehouseWorker) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var role by remember { mutableStateOf(existing?.role?.ifBlank { WarehouseConstants.WORKER_ROLES.first() } ?: WarehouseConstants.WORKER_ROLES.first()) }
    var payType by remember { mutableStateOf(existing?.payType ?: WorkerPayType.MONTHLY) }
    var rateText by remember { mutableStateOf(if (existing != null && existing.rate > 0.0) existing.rate.toString() else "") }
    var isActive by remember { mutableStateOf(existing?.isActive ?: true) }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existing == null) "إضافة عامل لطاقم المخزن" else "تعديل بيانات العامل",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorText = null },
                    label = { Text("اسم العامل الكامل *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("الوظيفة:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    WarehouseConstants.WORKER_ROLES.forEach { r ->
                        FilterChip(
                            selected = role == r,
                            onClick = { role = r },
                            label = { Text(r, fontSize = 11.sp) }
                        )
                    }
                }
                Text("نظام الأجر:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    WorkerPayType.entries.forEach { pt ->
                        FilterChip(
                            selected = payType == pt,
                            onClick = { payType = pt },
                            label = { Text(pt.arabicLabel, fontSize = 11.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = rateText,
                    onValueChange = { rateText = it.filter { c -> c.isDigit() || c == '.' } },
                    label = { Text(if (payType == WorkerPayType.MONTHLY) "الراتب الشهري *" else "الأجر اليومي *") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("على رأس عمله (نشط)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Switch(checked = isActive, onCheckedChange = { isActive = it })
                }
                if (errorText != null) {
                    Text(errorText ?: "", color = PalestineRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val rateVal = rateText.toDoubleOrNull() ?: -1.0
                    if (name.trim().isBlank() || rateVal < 0.0) {
                        errorText = "يرجى إدخال اسم العامل ومبلغ أجر صحيح"
                        return@Button
                    }
                    onSave(
                        WarehouseWorker(
                            id = existing?.id ?: "",
                            warehouseId = warehouseId,
                            name = name.trim(),
                            role = role,
                            payType = payType,
                            rate = rateVal,
                            isActive = isActive
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("حفظ العامل", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ============================================================================
// 3. نافذة تعريف / تعديل صنف بوحدات مزدوجة وربط بمشروع توزيع
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ItemEditorDialog(
    warehouseId: String,
    existing: WarehouseItem?,
    projects: List<ProjectEntity>,
    onDismiss: () -> Unit,
    onSave: (WarehouseItem) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var category by remember { mutableStateOf(existing?.category ?: "طرود غذائية") }
    var majorUnitName by remember { mutableStateOf(existing?.majorUnitName ?: "كرتونة") }
    var minorUnitName by remember { mutableStateOf(existing?.minorUnitName ?: "قطعة") }
    var conversionFactorText by remember { mutableStateOf((existing?.conversionFactor ?: 12).toString()) }
    var minThresholdText by remember { mutableStateOf((existing?.minThreshold ?: 50L).toString()) }
    var expiryDate by remember { mutableStateOf(existing?.expiryDate ?: "") }
    var linkedProjectId by remember { mutableStateOf(existing?.linkedProjectId ?: "") }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (existing == null) "تعريف صنف جديد (جملة / فردي)" else "تعديل بيانات الصنف",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorText = null },
                    label = { Text("اسم الصنف *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("التصنيف (غذائي، صحي، إيواء، مياه...)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = majorUnitName,
                        onValueChange = { majorUnitName = it },
                        label = { Text("الوحدة الكبرى") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minorUnitName,
                        onValueChange = { minorUnitName = it },
                        label = { Text("الوحدة الصغرى") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = conversionFactorText,
                        onValueChange = { conversionFactorText = it.filter { c -> c.isDigit() } },
                        label = { Text("عدد الصغرى بالكبرى") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minThresholdText,
                        onValueChange = { minThresholdText = it.filter { c -> c.isDigit() } },
                        label = { Text("الحد الحرج (صغرى)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = expiryDate,
                    onValueChange = { expiryDate = it },
                    label = { Text("تاريخ انتهاء الصلاحية (yyyy-MM-dd اختياري)") },
                    placeholder = { Text("مثال: 2027-06-30") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "ربط اختياري بمشروع توزيع (للخصم الآلي من شاشة التسليم):",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = PalestineGreenDark
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = linkedProjectId.isBlank(),
                        onClick = { linkedProjectId = "" },
                        label = { Text("بدون ربط", fontSize = 10.5.sp) }
                    )
                    projects.take(10).forEach { prj ->
                        val pid = prj.projectID.toString()
                        FilterChip(
                            selected = linkedProjectId == pid,
                            onClick = { linkedProjectId = pid },
                            label = { Text("${prj.projectName} (#$pid)", fontSize = 10.5.sp) }
                        )
                    }
                }
                if (errorText != null) {
                    Text(errorText ?: "", color = PalestineRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.trim().isBlank()) {
                        errorText = "يرجى إدخال اسم الصنف"
                        return@Button
                    }
                    onSave(
                        WarehouseItem(
                            id = existing?.id ?: "",
                            warehouseId = warehouseId,
                            name = name.trim(),
                            category = category.trim(),
                            majorUnitName = majorUnitName.trim().ifBlank { "كرتونة" },
                            minorUnitName = minorUnitName.trim().ifBlank { "قطعة" },
                            conversionFactor = conversionFactorText.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                            totalMinorQty = existing?.totalMinorQty ?: 0L,
                            minThreshold = minThresholdText.toLongOrNull()?.coerceAtLeast(0L) ?: 0L,
                            expiryDate = expiryDate.trim(),
                            linkedProjectId = linkedProjectId.trim().takeIf { it.isNotBlank() }
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("حفظ الصنف", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ============================================================================
// 4. نافذة سند واردات (GRN) / سند صادرات (GDN) / مناقلة بين مخزنين
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun StockMovementActionDialog(
    mode: StockMovementType, // IN, OUT, TRANSFER
    items: List<WarehouseItem>,
    allWarehouses: List<Warehouse>,
    activeWarehouseId: String,
    projects: List<ProjectEntity>,
    onDismiss: () -> Unit,
    onSubmitGrn: (itemId: String, major: Long, minor: Long, supplier: String, waybill: String, batch: String, linkedProjectId: String?, notes: String, generatePdf: Boolean) -> Unit,
    onSubmitGdn: (itemId: String, major: Long, minor: Long, recipient: String, linkedProjectId: String?, driver: String, plate: String, notes: String, generatePdf: Boolean) -> Unit,
    onSubmitTransfer: (itemId: String, targetWhId: String, major: Long, minor: Long, driver: String, plate: String, notes: String, generatePdf: Boolean) -> Unit
) {
    var selectedItemId by remember { mutableStateOf(items.firstOrNull()?.id ?: "") }
    val selectedItem = items.firstOrNull { it.id == selectedItemId }
    val otherWarehouses = remember(allWarehouses, activeWarehouseId) {
        allWarehouses.filter { it.id != activeWarehouseId }
    }
    var targetWarehouseId by remember { mutableStateOf(otherWarehouses.firstOrNull()?.id ?: "") }
    var majorQtyText by remember { mutableStateOf("0") }
    var minorQtyText by remember { mutableStateOf("0") }
    var supplierOrRecipient by remember { mutableStateOf("") }
    var waybillNo by remember { mutableStateOf("") }
    var batchNo by remember { mutableStateOf("") }
    var driverName by remember { mutableStateOf("") }
    var vehiclePlate by remember { mutableStateOf("") }
    var linkedProjectId by remember { mutableStateOf(selectedItem?.linkedProjectId ?: "") }
    var notes by remember { mutableStateOf("") }
    var generatePdfNow by remember { mutableStateOf(true) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val dialogTitle = when (mode) {
        StockMovementType.IN -> "+ سند استلام واردات (GRN)"
        StockMovementType.OUT -> "- سند إرسال صادرات / تصريح خروج (GDN)"
        else -> "⇄ مناقلة مخزنية بين مخزنين"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialogTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (items.isEmpty()) {
                    Text("يرجى تعريف صنف واحد على الأقل في المخزن أولاً.", color = PalestineRed, fontSize = 12.sp)
                } else {
                    Text("اختر الصنف:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items.forEach { itm ->
                            FilterChip(
                                selected = selectedItemId == itm.id,
                                onClick = {
                                    selectedItemId = itm.id
                                    if (linkedProjectId.isBlank()) linkedProjectId = itm.linkedProjectId ?: ""
                                    errorText = null
                                },
                                label = { Text(itm.name, fontSize = 11.sp) }
                            )
                        }
                    }

                    if (selectedItem != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFECFDF5),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "الرصيد الحالي: ${selectedItem.formatDualQuantity()} (1 ${selectedItem.majorUnitName} = ${selectedItem.safeConversionFactor} ${selectedItem.minorUnitName})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF065F46),
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    if (mode == StockMovementType.TRANSFER) {
                        Text("المخزن المستقبل:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        if (otherWarehouses.isEmpty()) {
                            Text("لا يوجد مخزن آخر متاح للمناقلة إليه.", color = PalestineRed, fontSize = 11.sp)
                        } else {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                otherWarehouses.forEach { wh ->
                                    FilterChip(
                                        selected = targetWarehouseId == wh.id,
                                        onClick = { targetWarehouseId = wh.id },
                                        label = { Text(wh.name, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = majorQtyText,
                            onValueChange = { majorQtyText = it.filter { c -> c.isDigit() }; errorText = null },
                            label = { Text("جملة (${selectedItem?.majorUnitName ?: "كبرى"})") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = minorQtyText,
                            onValueChange = { minorQtyText = it.filter { c -> c.isDigit() }; errorText = null },
                            label = { Text("فردي (${selectedItem?.minorUnitName ?: "قطعة"})") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    when (mode) {
                        StockMovementType.IN -> {
                            OutlinedTextField(
                                value = supplierOrRecipient,
                                onValueChange = { supplierOrRecipient = it },
                                label = { Text("المورد / الجهة المانحة") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = waybillNo,
                                    onValueChange = { waybillNo = it },
                                    label = { Text("رقم البوليصة") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = batchNo,
                                    onValueChange = { batchNo = it },
                                    label = { Text("رقم التشغيلة") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        StockMovementType.OUT -> {
                            OutlinedTextField(
                                value = supplierOrRecipient,
                                onValueChange = { supplierOrRecipient = it },
                                label = { Text("الجهة المستلمة / المشروع") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = driverName,
                                    onValueChange = { driverName = it },
                                    label = { Text("اسم السائق") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = vehiclePlate,
                                    onValueChange = { vehiclePlate = it },
                                    label = { Text("رقم المركبة") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        else -> {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = driverName,
                                    onValueChange = { driverName = it },
                                    label = { Text("اسم السائق") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                OutlinedTextField(
                                    value = vehiclePlate,
                                    onValueChange = { vehiclePlate = it },
                                    label = { Text("رقم المركبة") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    if (mode == StockMovementType.IN || mode == StockMovementType.OUT) {
                        Text("ربط اختياري بمشروع توزيع:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(
                                selected = linkedProjectId.isBlank(),
                                onClick = { linkedProjectId = "" },
                                label = { Text("بدون مشروع", fontSize = 10.sp) }
                            )
                            projects.take(8).forEach { p ->
                                val pid = p.projectID.toString()
                                FilterChip(
                                    selected = linkedProjectId == pid,
                                    onClick = { linkedProjectId = pid },
                                    label = { Text("${p.projectName} (#$pid)", fontSize = 10.sp) }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات السند") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🧾 توليد وطباعة سند PDF فور الحفظ", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                        Switch(checked = generatePdfNow, onCheckedChange = { generatePdfNow = it })
                    }

                    if (errorText != null) {
                        Text(errorText ?: "", color = PalestineRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = items.isNotEmpty() && (mode != StockMovementType.TRANSFER || otherWarehouses.isNotEmpty()),
                onClick = {
                    val maj = majorQtyText.toLongOrNull() ?: 0L
                    val min = minorQtyText.toLongOrNull() ?: 0L
                    if (selectedItemId.isBlank() || (maj <= 0L && min <= 0L)) {
                        errorText = "يرجى تحديد الصنف وإدخال كمية أكبر من صفر"
                        return@Button
                    }
                    when (mode) {
                        StockMovementType.IN -> onSubmitGrn(
                            selectedItemId, maj, min, supplierOrRecipient, waybillNo, batchNo,
                            linkedProjectId.takeIf { it.isNotBlank() }, notes, generatePdfNow
                        )
                        StockMovementType.OUT -> onSubmitGdn(
                            selectedItemId, maj, min, supplierOrRecipient,
                            linkedProjectId.takeIf { it.isNotBlank() }, driverName, vehiclePlate, notes, generatePdfNow
                        )
                        else -> {
                            if (targetWarehouseId.isBlank()) {
                                errorText = "يرجى اختيار المخزن المستقبل"
                                return@Button
                            }
                            onSubmitTransfer(selectedItemId, targetWarehouseId, maj, min, driverName, vehiclePlate, notes, generatePdfNow)
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("اعتماد السند", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ============================================================================
// 5. نافذة تجميع / تفكيك طرود (Kit Assembly / Unbundle)
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun KitAssemblyDialog(
    items: List<WarehouseItem>,
    onDismiss: () -> Unit,
    onExecute: (isAssemble: Boolean, kitItemId: String, kitsCount: Long, components: List<KitComponentSpec>, notes: String) -> Unit
) {
    var isAssemble by remember { mutableStateOf(true) }
    var kitItemId by remember { mutableStateOf(items.firstOrNull()?.id ?: "") }
    var kitsCountText by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }
    var componentQtyMap by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val availableComponents = remember(items, kitItemId) {
        items.filter { it.id != kitItemId }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("📦 تجميع / تفكيك طرود إغاثية", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = isAssemble,
                        onClick = { isAssemble = true },
                        label = { Text("تجميع طرود (Kit)", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = !isAssemble,
                        onClick = { isAssemble = false },
                        label = { Text("تفكيك طرود (Unbundle)", fontSize = 11.sp) }
                    )
                }

                if (items.size < 2) {
                    Text("يتطلب التجميع/التفكيك وجود صنف الطرد وصنف مكون واحد على الأقل.", color = PalestineRed, fontSize = 11.sp)
                } else {
                    Text("اختر صنف الطرد الجاهز:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items.forEach { itm ->
                            FilterChip(
                                selected = kitItemId == itm.id,
                                onClick = { kitItemId = itm.id },
                                label = { Text("${itm.name} (${itm.totalMinorQty})", fontSize = 10.5.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = kitsCountText,
                        onValueChange = { kitsCountText = it.filter { c -> c.isDigit() } },
                        label = { Text("عدد الطرود المطلوب ${if (isAssemble) "تجميعها" else "تفكيكها"}") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("مكونات الطرد الواحد (أدخل الكمية بالوحدة الصغرى لكل طرد):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    availableComponents.forEach { comp ->
                        val valText = componentQtyMap[comp.id] ?: ""
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(comp.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("المتاح: ${comp.totalMinorQty} ${comp.minorUnitName}", fontSize = 10.sp, color = SlateTextSecondary)
                            }
                            OutlinedTextField(
                                value = valText,
                                onValueChange = { input ->
                                    val digits = input.filter { c -> c.isDigit() }
                                    componentQtyMap = componentQtyMap.toMutableMap().apply { put(comp.id, digits) }
                                },
                                label = { Text("للطرد") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.width(86.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (errorText != null) {
                        Text(errorText ?: "", color = PalestineRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                enabled = items.size >= 2,
                onClick = {
                    val count = kitsCountText.toLongOrNull() ?: 0L
                    val specs = availableComponents.mapNotNull { comp ->
                        val q = componentQtyMap[comp.id]?.toLongOrNull() ?: 0L
                        if (q > 0L) KitComponentSpec(comp.id, q) else null
                    }
                    if (kitItemId.isBlank() || count <= 0L || specs.isEmpty()) {
                        errorText = "يرجى تحديد عدد الطرود وكمية مكون واحد على الأقل"
                        return@Button
                    }
                    onExecute(isAssemble, kitItemId, count, specs, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text(if (isAssemble) "تنفيذ التجميع" else "تنفيذ التفكيك", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ============================================================================
// 6. نوافذ التخزين للغير (3PL): عميل + إيداع/سحب/دفعة
// ============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun StorageClientEditorDialog(
    warehouseId: String,
    existing: StorageClient?,
    onDismiss: () -> Unit,
    onSave: (StorageClient) -> Unit
) {
    var clientName by remember { mutableStateOf(existing?.clientName ?: "") }
    var contactPerson by remember { mutableStateOf(existing?.contactPerson ?: "") }
    var phone by remember { mutableStateOf(existing?.phone ?: "") }
    var billingModel by remember { mutableStateOf(existing?.billingModel ?: ClientBillingModel.PER_PIECE_DAY) }
    var unitRateText by remember { mutableStateOf(if (existing != null && existing.unitRate > 0.0) existing.unitRate.toString() else "0.5") }
    var handlingFeeText by remember { mutableStateOf((existing?.handlingFee ?: 0.0).toString()) }
    var graceDaysText by remember { mutableStateOf((existing?.freeGraceDays ?: 0).toString()) }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "إضافة عميل تخزين للغير (3PL)" else "تعديل بيانات العميل", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = clientName,
                    onValueChange = { clientName = it; errorText = null },
                    label = { Text("اسم العميل / الجهة المودِعة *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = contactPerson,
                    onValueChange = { contactPerson = it },
                    label = { Text("مسؤول التواصل") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم الجوال") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                Text("نظام التسعير:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    ClientBillingModel.entries.forEach { m ->
                        FilterChip(
                            selected = billingModel == m,
                            onClick = { billingModel = m },
                            label = { Text(m.arabicLabel, fontSize = 11.sp) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = unitRateText,
                        onValueChange = { unitRateText = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("السعر / التعرفة *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = handlingFeeText,
                        onValueChange = { handlingFeeText = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("رسوم المناولة") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = graceDaysText,
                    onValueChange = { graceDaysText = it.filter { c -> c.isDigit() } },
                    label = { Text("أيام السماح المجانية (Grace Days)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorText != null) {
                    Text(errorText ?: "", color = PalestineRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val rate = unitRateText.toDoubleOrNull() ?: -1.0
                    if (clientName.trim().isBlank() || rate < 0.0) {
                        errorText = "يرجى إدخال اسم العميل وسعر صحيح"
                        return@Button
                    }
                    onSave(
                        StorageClient(
                            id = existing?.id ?: "",
                            warehouseId = warehouseId,
                            clientName = clientName.trim(),
                            contactPerson = contactPerson.trim(),
                            phone = phone.trim(),
                            billingModel = billingModel,
                            unitRate = rate,
                            handlingFee = handlingFeeText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0,
                            freeGraceDays = graceDaysText.toIntOrNull()?.coerceAtLeast(0) ?: 0
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("حفظ العميل", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
internal fun ClientTransactionDialog(
    client: StorageClient,
    txType: ClientStorageTxType,
    onDismiss: () -> Unit,
    onSubmit: (qtyPieces: Long, paymentAmount: Double, itemDesc: String, notes: String, generatePdf: Boolean) -> Unit
) {
    var qtyText by remember { mutableStateOf("") }
    var paymentText by remember { mutableStateOf("") }
    var itemDesc by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var generatePdf by remember { mutableStateOf(txType != ClientStorageTxType.PAYMENT) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val title = when (txType) {
        ClientStorageTxType.DEPOSIT -> "+ إيداع قطع للعميل: ${client.clientName}"
        ClientStorageTxType.WITHDRAWAL -> "- سحب قطع للعميل: ${client.clientName}"
        ClientStorageTxType.PAYMENT -> "💵 تسجيل دفعة سداد: ${client.clientName}"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (txType == ClientStorageTxType.PAYMENT) {
                    OutlinedTextField(
                        value = paymentText,
                        onValueChange = { paymentText = it.filter { c -> c.isDigit() || c == '.' }; errorText = null },
                        label = { Text("مبلغ الدفعة المسددة *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    OutlinedTextField(
                        value = itemDesc,
                        onValueChange = { itemDesc = it },
                        label = { Text("وصف البضاعة / الطرود") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it.filter { c -> c.isDigit() }; errorText = null },
                        label = { Text("عدد القطع *") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("🧾 توليد سند PDF فور التسجيل", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                    Switch(checked = generatePdf, onCheckedChange = { generatePdf = it })
                }
                if (errorText != null) {
                    Text(errorText ?: "", color = PalestineRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (txType == ClientStorageTxType.PAYMENT) {
                        val amt = paymentText.toDoubleOrNull() ?: 0.0
                        if (amt <= 0.0) {
                            errorText = "يرجى إدخال مبلغ أكبر من صفر"
                            return@Button
                        }
                        onSubmit(0L, amt, "", notes, generatePdf)
                    } else {
                        val q = qtyText.toLongOrNull() ?: 0L
                        if (q <= 0L) {
                            errorText = "يرجى إدخال عدد قطع أكبر من صفر"
                            return@Button
                        }
                        onSubmit(q, 0.0, itemDesc, notes, generatePdf)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("اعتماد الحركة", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

// ============================================================================
// 7. نوافذ الموازنة والمصروفات التشغيلية
// ============================================================================

@Composable
internal fun AddBudgetDialog(
    onDismiss: () -> Unit,
    onSave: (amount: Double, source: String, notes: String) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var source by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("+ تخصيص موازنة للمخزن", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' }; errorText = null },
                    label = { Text("قيمة الموازنة المعتمدة *") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = source,
                    onValueChange = { source = it },
                    label = { Text("مصدر التمويل / الجهة الممولة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorText != null) Text(errorText ?: "", color = PalestineRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt <= 0.0) {
                        errorText = "يرجى إدخال مبلغ أكبر من صفر"
                        return@Button
                    }
                    onSave(amt, source, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("اعتماد الموازنة", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun AddExpenseDialog(
    onDismiss: () -> Unit,
    onSave: (category: String, amount: Double, invoiceNo: String, notes: String) -> Unit
) {
    var category by remember { mutableStateOf(WarehouseConstants.EXPENSE_CATEGORIES.first()) }
    var amountText by remember { mutableStateOf("") }
    var invoiceNo by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("+ تسجيل مصروف تشغيلي للمخزن", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("بند المصروف:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    WarehouseConstants.EXPENSE_CATEGORIES.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { c -> c.isDigit() || c == '.' }; errorText = null },
                    label = { Text("المبلغ *") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = invoiceNo,
                    onValueChange = { invoiceNo = it },
                    label = { Text("رقم الفاتورة / الإيصال") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("بيان المصروف وملاحظات") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                if (errorText != null) Text(errorText ?: "", color = PalestineRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull() ?: 0.0
                    if (amt <= 0.0) {
                        errorText = "يرجى إدخال مبلغ أكبر من صفر"
                        return@Button
                    }
                    onSave(category, amt, invoiceNo, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("تسجيل المصروف", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}
