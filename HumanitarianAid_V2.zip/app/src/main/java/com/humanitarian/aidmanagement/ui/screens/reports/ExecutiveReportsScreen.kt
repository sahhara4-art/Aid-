package com.humanitarian.aidmanagement.ui.screens.reports

import android.app.DatePickerDialog
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.ui.components.GlassCard
import com.humanitarian.aidmanagement.ui.components.glassEffect
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.local.entities.targetQuota
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.ExportColumnSelectorDialog
import com.humanitarian.aidmanagement.ui.screens.excel.ExcelImportExportScreen
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*


enum class BreakdownTab(val label: String) {
    SHELTER("حالة الإيواء"),
    DAMAGE("أضرار الحرب"),
    AID_TYPES("أنواع المساعدات")
}

/**
 * شاشة التقرير الإداري التنفيذي المتقدم (Ultimate BI Executive Dashboard)
 * لوحة قيادة استراتيجية تفاعلية مدعومة بمخططات Compose Canvas مخصصة (Bar Charts & Donut Charts)
 * تعتمد حصراً وبشكل صارم على حقل "المنطقة الفرعية الحالية" (currentSubRegion) في كافة التصنيفات والتحليلات،
 * وتدعم التصدير إلى تقرير PDF تنفيذي متعدد الصفحات معتمد وكشوفات CSV فائقة السرعة.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExecutiveReportsScreen(
    repository: AidRepository,
    viewModel: ReportsViewModel = viewModel(factory = ReportsViewModel.Factory(repository)),
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val exporter = remember { ProfessionalReportExporter(context) }

    var selectedBreakdownTab by remember { mutableStateOf(BreakdownTab.SHELTER) }
    var expandedDamageCategory by remember { mutableStateOf<String?>(null) }
    var isFabExpanded by remember { mutableStateOf(false) }

    // نطاق الفلترة الزمنية
    var fromDate by remember { mutableStateOf("2026-01-01") }
    var toDate by remember { mutableStateOf("2026-12-31") }
    var selectedPreset by remember { mutableStateOf("العام الحالي 2026") }

    // ملخص إحصائي فائق السرعة من SQLite مباشرة دون تحميل السجلات في الذاكرة
    var summary by remember { mutableStateOf(com.humanitarian.aidmanagement.data.repository.ExecutiveAggregateSummary()) }
    var isSummaryLoading by remember { mutableStateOf(true) }

    LaunchedEffect(fromDate, toDate) {
        isSummaryLoading = true
        summary = repository.getExecutiveSummary(fromDate, toDate)
        isSummaryLoading = false
    }

    val activeAidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val allProjects by repository.getActiveProjects().collectAsState(initial = emptyList())

    // حالات التصدير
    var isExporting by remember { mutableStateOf(false) }
    var exportStatusMessage by remember { mutableStateOf<String?>(null) }
    var showColumnSelectorDialog by remember { mutableStateOf(false) }
    var pendingSelectedColumns by remember { mutableStateOf<List<String>>(ExportColumnRegistry.DEFAULT_SELECTED_KEYS) }

    // خريطة أسماء أنواع المساعدات
    val aidTypeNamesMap = remember(activeAidTypes) {
        activeAidTypes.associate { it.aidTypeID to it.aidTypeName }
    }

    val totalFamiliesCount = summary.totalFamilies
    val totalIndividualsCount = summary.totalIndividuals
    val totalDeliveredCount = summary.totalDelivered
    val actualBeneficiariesCount = summary.actualBeneficiaries

    val deliveryPercentage = remember(totalFamiliesCount, totalDeliveredCount) {
        if (totalFamiliesCount > 0) {
            (totalDeliveredCount.toDouble() / totalFamiliesCount.toDouble() * 100.0).coerceAtMost(100.0)
        } else 0.0
    }

    // ==========================================
    // 1. التحليل الديموغرافي والجغرافي (حسب currentSubRegion حصراً من استعلام SQLite)
    // ==========================================
    val geoDemographics = remember(summary.geoDemographics, totalFamiliesCount, totalIndividualsCount) {
        summary.geoDemographics.map { item ->
            val famPct = if (totalFamiliesCount > 0) (item.familyCount.toDouble() / totalFamiliesCount * 100.0) else 0.0
            val indivPct = if (totalIndividualsCount > 0) (item.individualCount.toDouble() / totalIndividualsCount * 100.0) else 0.0
            ExecutiveGeoDemographicItem(
                regionName = item.regionName,
                familyCount = item.familyCount,
                familyPercentage = famPct,
                individualCount = item.individualCount,
                individualPercentage = indivPct
            )
        }
    }

    val geoBreakdown = remember(geoDemographics) {
        geoDemographics.map { 
            ExecutiveGeoItem(it.regionName, it.familyCount, it.familyPercentage) 
        }
    }

    // ==========================================
    // 2. تحليل أضرار الحرب (من استعلام SQLite التجميعي)
    // ==========================================
    val damageBreakdown = remember(summary.damageBreakdown, totalFamiliesCount) {
        val total = totalFamiliesCount.toDouble()
        summary.damageBreakdown.map { entry ->
            ExecutiveCategoryItem(
                label = entry.keyName,
                count = entry.count,
                percentage = if (total > 0) (entry.count / total) * 100.0 else 0.0
            )
        }
    }

    val damageDetailsMap by viewModel.damageDetailsByRegion.collectAsState()

    val damageByRegionBreakdown = remember(damageDetailsMap) {
        damageDetailsMap.mapValues { (_, regionMap) ->
            val totalInDamage = regionMap.values.sum().toDouble()
            regionMap.map { (region, count) ->
                ExecutiveCategoryItem(
                    label = region,
                    count = count,
                    percentage = if (totalInDamage > 0) (count.toDouble() / totalInDamage) * 100.0 else 0.0
                )
            }.sortedByDescending { it.count }
        }
    }

    // تصنيف حالة الإيواء (من استعلام SQLite التجميعي)
    val shelterBreakdown = remember(summary.shelterBreakdown, totalFamiliesCount) {
        val total = totalFamiliesCount.toDouble()
        summary.shelterBreakdown.map { entry ->
            ExecutiveCategoryItem(
                label = entry.keyName,
                count = entry.count,
                percentage = if (total > 0) (entry.count / total) * 100.0 else 0.0
            )
        }
    }

    // ==========================================
    // 3. تصنيف أنواع المساعدات الموزعة (من استعلام SQLite التجميعي)
    // ==========================================
    val aidTypesBreakdown = remember(summary.aidTypeBreakdown, totalDeliveredCount) {
        val total = totalDeliveredCount.toDouble()
        summary.aidTypeBreakdown.map { entry ->
            ExecutiveCategoryItem(
                label = entry.keyName,
                count = entry.count,
                percentage = if (total > 0) (entry.count / total) * 100.0 else 0.0
            )
        }
    }

    // ==========================================
    // 4. تقرير أداء وإنجاز المشاريع الإغاثية النشطة
    // ==========================================
    val projectStatsList = remember(allProjects, totalDeliveredCount) {
        allProjects.map { prj ->
            val target = prj.targetQuota
            val pct = if (target > 0) (totalDeliveredCount.toDouble() / target.toDouble() * 100.0).coerceAtMost(100.0) else 0.0
            ProjectPerformanceStat(
                projectId = prj.projectID,
                projectName = prj.projectName,
                aidTypeName = aidTypeNamesMap[prj.aidTypeID] ?: "معونة #${prj.aidTypeID}",
                projectDate = prj.projectDate,
                targetQuota = target,
                deliveredCount = totalDeliveredCount,
                completionPercentage = pct
            )
        }.sortedByDescending { it.targetQuota }
    }

    // ==========================================
    // مشغلات Storage Access Framework (SAF)
    // ==========================================
    val executivePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        if (uri == null) {
            Toast.makeText(context, "تم إلغاء حفظ التقرير الإداري", Toast.LENGTH_SHORT).show()
            return@rememberLauncherForActivityResult
        }
        scope.launch {
            isExporting = true
            try {
                val reportData = ExecutiveReportData(
                    fromDate = fromDate,
                    toDate = toDate,
                    totalFamilies = totalFamiliesCount,
                    totalDelivered = totalDeliveredCount,
                    deliveryPercentage = deliveryPercentage,
                    geoBreakdown = geoBreakdown,
                    shelterBreakdown = shelterBreakdown,
                    damageBreakdown = damageBreakdown,
                    totalIndividuals = totalIndividualsCount,
                    activeProjectsCount = allProjects.size,
                    geoDemographics = geoDemographics,
                    aidTypeBreakdown = aidTypesBreakdown,
                    damageByRegionBreakdown = damageByRegionBreakdown,
                    projectStatsList = projectStatsList,
                    supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات المركزية"
                )
                val result = withContext(Dispatchers.IO) {
                    exporter.exportExecutiveReportPdfToUri(uri, reportData)
                }
                result.onSuccess {
                    exportStatusMessage = "✅ تم تصدير التقرير الإداري التنفيذي (BI PDF) بنجاح وفق معمارية التخزين الآمن."
                    Toast.makeText(context, "تم تصدير تقرير BI بنجاح", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    exportStatusMessage = "❌ فشل تصدير التقرير الإداري: ${err.message}"
                    Toast.makeText(context, "خطأ أثناء التصدير: ${err.message}", Toast.LENGTH_LONG).show()
                }
            } catch (t: Throwable) {
                exportStatusMessage = "❌ خطأ أثناء التصدير: ${t.message}"
                Toast.makeText(context, "خطأ: ${t.message ?: "حدث خطأ غير متوقع"}", Toast.LENGTH_LONG).show()
            } finally {
                isExporting = false
            }
        }
    }

    val dynamicExcelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri: Uri? ->
        if (uri == null) {
            Toast.makeText(context, "تم إلغاء حفظ ملف البيانات", Toast.LENGTH_SHORT).show()
            return@rememberLauncherForActivityResult
        }
        scope.launch {
            isExporting = true
            try {
                val familiesToExport = withContext(Dispatchers.IO) { repository.getAllFamiliesSync() }
                if (familiesToExport.isEmpty()) {
                    Toast.makeText(context, "لا توجد بيانات مستفيدين للتصدير", Toast.LENGTH_LONG).show()
                    return@launch
                }
                val result = withContext(Dispatchers.IO) {
                    exporter.exportDynamicFamiliesExcelToUri(
                        uri = uri,
                        reportTitle = "كشف المستفيدين المعتمد - التقرير التنفيذي",
                        selectedColumnKeys = pendingSelectedColumns,
                        families = familiesToExport
                    )
                }
                result.onSuccess {
                    exportStatusMessage = "✅ تم تصدير كشف البيانات (CSV/Excel) بنجاح (${pendingSelectedColumns.size} عمود محدد)."
                    Toast.makeText(context, "تم تصدير ملف CSV / Excel بنجاح", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    exportStatusMessage = "❌ فشل تصدير البيانات: ${err.message}"
                    Toast.makeText(context, "خطأ أثناء التصدير: ${err.message}", Toast.LENGTH_LONG).show()
                }
            } catch (t: Throwable) {
                exportStatusMessage = "❌ خطأ في تصدير البيانات: ${t.message}"
                Toast.makeText(context, "خطأ: ${t.message ?: "حدث خطأ غير متوقع"}", Toast.LENGTH_LONG).show()
            } finally {
                isExporting = false
            }
        }
    }

    val dynamicPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        if (uri == null) {
            Toast.makeText(context, "تم إلغاء حفظ مستند PDF", Toast.LENGTH_SHORT).show()
            return@rememberLauncherForActivityResult
        }
        scope.launch {
            isExporting = true
            try {
                val familiesToExport = withContext(Dispatchers.IO) { repository.getAllFamiliesSync() }
                if (familiesToExport.isEmpty()) {
                    Toast.makeText(context, "لا توجد بيانات مستفيدين للتصدير", Toast.LENGTH_LONG).show()
                    return@launch
                }
                val result: Result<Unit> = withContext(Dispatchers.IO) {
                    exporter.exportDynamicFamiliesPdfToUri(
                        uri = uri,
                        reportTitle = "كشف المستفيدين المعتمد - التقرير التنفيذي",
                        selectedColumnKeys = pendingSelectedColumns,
                        families = familiesToExport,
                        supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات المركزية"
                    )
                }
                result.onSuccess { _: Unit ->
                    exportStatusMessage = "✅ تم تصدير كشف المستفيدين (PDF) بنجاح (${pendingSelectedColumns.size} عمود)."
                    Toast.makeText(context, "تم تصدير مستند PDF بنجاح", Toast.LENGTH_LONG).show()
                }.onFailure { err: Throwable ->
                    exportStatusMessage = "❌ فشل تصدير PDF: ${err.message}"
                    Toast.makeText(context, "خطأ: ${err.message}", Toast.LENGTH_LONG).show()
                }
            } catch (t: Throwable) {
                exportStatusMessage = "❌ خطأ أثناء تصدير كشف PDF: ${t.message}"
                Toast.makeText(context, "خطأ: ${t.message ?: "حدث خطأ غير متوقع"}", Toast.LENGTH_LONG).show()
            } finally {
                isExporting = false
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "لوحة التقارير التنفيذية وذكاء الأعمال",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF0D9488).copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "BI Dashboard",
                                        color = Color(0xFF0D9488),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "تحليل ديناميكي شامل لمؤشرات السكان والإغاثة وأضرار الحرب",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            floatingActionButton = {
                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AnimatedVisibility(
                        visible = isFabExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // 1. تصدير تقرير BI التنفيذي (PDF)
                            ExtendedFloatingActionButton(
                                onClick = {
                                    isFabExpanded = false
                                    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                    val fileName = "Executive_BI_Report_${fromDate}_to_${toDate}_$timeStamp.pdf"
                                    executivePdfLauncher.launch(fileName)
                                },
                                containerColor = Color(0xFFDC2626),
                                contentColor = Color.White,
                                icon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null) },
                                text = { Text("تصدير تقرير BI التنفيذي (PDF)", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            )

                            // 2. تصدير كشف البيانات المفلترة (CSV)
                            ExtendedFloatingActionButton(
                                onClick = {
                                    isFabExpanded = false
                                    showColumnSelectorDialog = true
                                },
                                containerColor = Color(0xFF0D9488),
                                contentColor = Color.White,
                                icon = { Icon(Icons.Default.TableChart, contentDescription = null) },
                                text = { Text("تصدير كشف البيانات (CSV)", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                    }

                    FloatingActionButton(
                        onClick = { isFabExpanded = !isFabExpanded },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ) {
                        Icon(
                            if (isFabExpanded) Icons.Default.Close else Icons.Default.FileDownload,
                            contentDescription = "خيارات التصدير"
                        )
                    }
                }
            }
        ) { padding ->
            // ==========================================
            // لوحة BI القيادية التنفيذية المتكاملة
            // ==========================================
            LazyColumn(
                    modifier = Modifier
                        .padding(padding)
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // شريط حالة العملية والتصدير
                    if (exportStatusMessage != null) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (exportStatusMessage!!.startsWith("✅")) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                                border = BorderStroke(1.dp, if (exportStatusMessage!!.startsWith("✅")) Color(0xFF86EFAC) else Color(0xFFFCA5A5)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = exportStatusMessage!!,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = if (exportStatusMessage!!.startsWith("✅")) Color(0xFF166534) else Color(0xFF991B1B),
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { exportStatusMessage = null },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }

                    // ==============================================================
                    // القسم العلوي: محدد النطاق الزمني والفلاتر السريعة (Date Pickers)
                    // ==============================================================
                    item {
                        GlassCard(
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                        Text(
                                            text = "النطاق الزمني للتحليل والعمليات الميدانية",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Text(
                                        text = selectedPreset,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                // أزرار الفلترة السريعة (Quick Presets)
                                val presets = listOf("هذا الشهر", "الربع الحالي", "العام الحالي 2026", "كافة الفترات")
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    presets.forEach { preset ->
                                        FilterChip(
                                            selected = selectedPreset == preset,
                                            onClick = {
                                                selectedPreset = preset
                                                when (preset) {
                                                    "هذا الشهر" -> {
                                                        fromDate = "2026-10-01"
                                                        toDate = "2026-10-31"
                                                    }
                                                    "الربع الحالي" -> {
                                                        fromDate = "2026-07-01"
                                                        toDate = "2026-10-31"
                                                    }
                                                    "العام الحالي 2026" -> {
                                                        fromDate = "2026-01-01"
                                                        toDate = "2026-12-31"
                                                    }
                                                    "كافة الفترات" -> {
                                                        fromDate = "2020-01-01"
                                                        toDate = "2030-12-31"
                                                    }
                                                }
                                            },
                                            label = { Text(preset, fontSize = 11.sp) },
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                    }
                                }

                                // حقلا اختيار التاريخ المباشرين
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    // من تاريخ
                                    OutlinedCard(
                                        onClick = {
                                            val cal = Calendar.getInstance()
                                            DatePickerDialog(
                                                context,
                                                { _, year, month, day ->
                                                    fromDate = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                                                    selectedPreset = "مخصص"
                                                },
                                                cal.get(Calendar.YEAR),
                                                cal.get(Calendar.MONTH),
                                                cal.get(Calendar.DAY_OF_MONTH)
                                            ).show()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                            Text("من تاريخ:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                                                Text(fromDate, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    // إلى تاريخ
                                    OutlinedCard(
                                        onClick = {
                                            val cal = Calendar.getInstance()
                                            DatePickerDialog(
                                                context,
                                                { _, year, month, day ->
                                                    toDate = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                                                    selectedPreset = "مخصص"
                                                },
                                                cal.get(Calendar.YEAR),
                                                cal.get(Calendar.MONTH),
                                                cal.get(Calendar.DAY_OF_MONTH)
                                            ).show()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                            Text("إلى تاريخ:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                                                Text(toDate, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ==============================================================
                    // القسم 1: الملخص التنفيذي القيادي (Section 1: Executive Summary)
                    // شبكة 4 بطاقات مضيئة قيادية مع شريط التقدم الشامل
                    // ==============================================================
                    item {
                        GlassCard(
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            modifier = Modifier.size(28.dp).background(Color(0xFF0D9488).copy(alpha = 0.15f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Insights, contentDescription = null, tint = Color(0xFF0D9488), modifier = Modifier.size(16.dp))
                                        }
                                        Text(
                                            text = "المؤشرات القيادية الشاملة (Executive Summary)",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color(0xFF16A34A).copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = "تحديث لحظي",
                                            color = Color(0xFF16A34A),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                // 4 بطاقات مؤشرات أساسية (2x2 Grid)
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        // 1. إجمالي الأسر المسجلة
                                        ExecutiveGlowingCard(
                                            title = "إجمالي الأسر المسجلة",
                                            value = String.format(Locale.US, "%,d", totalFamiliesCount),
                                            unit = "أسرة في النظام",
                                            color = Color(0xFF0D9488),
                                            icon = Icons.Default.FamilyRestroom,
                                            modifier = Modifier.weight(1f)
                                        )

                                        // 2. إجمالي الأفراد
                                        ExecutiveGlowingCard(
                                            title = "إجمالي الأفراد المقيدين",
                                            value = String.format(Locale.US, "%,d", totalIndividualsCount),
                                            unit = "فرد مستهدف",
                                            color = Color(0xFF6366F1),
                                            icon = Icons.Default.Groups,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        // 3. المساعدات المسلمة فعلياً
                                        ExecutiveGlowingCard(
                                            title = "المساعدات المسلمة",
                                            value = String.format(Locale.US, "%,d", totalDeliveredCount),
                                            unit = "طرد / معونة نقدية",
                                            color = Color(0xFF0284C7),
                                            icon = Icons.Default.Inventory2,
                                            modifier = Modifier.weight(1f)
                                        )

                                        // 4. المشاريع الإغاثية النشطة
                                        ExecutiveGlowingCard(
                                            title = "المشاريع الإغاثية",
                                            value = String.format(Locale.US, "%,d", allProjects.size),
                                            unit = "مشروع نشط",
                                            color = Color(0xFF16A34A),
                                            icon = Icons.Default.AssignmentTurnedIn,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                                // شريط التقدم الشامل لمعدل التغطية الميدانية
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("معدل التغطية الميدانية الإجمالي (المساعدات المسلمة / الأسر):", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(String.format(Locale.US, "%.1f%%", deliveryPercentage), fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF16A34A))
                                    }
                                    LinearProgressIndicator(
                                        progress = { (deliveryPercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp)),
                                        color = Color(0xFF16A34A),
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    // ==============================================================
                    // القسم 2: التحليل الديموغرافي والجغرافي (Section 2: Geographic Population)
                    // مخطط شريطي أفقي نقي مرسوم عبر Jetpack Compose Canvas
                    // ويعتمد حصراً على currentSubRegion
                    // ==============================================================
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            modifier = Modifier.size(28.dp).background(Color(0xFF0D9488).copy(alpha = 0.15f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.BarChart, contentDescription = null, tint = Color(0xFF0D9488), modifier = Modifier.size(16.dp))
                                        }
                                        Column {
                                            Text(
                                                text = "التوزيع الديموغرافي بالمحليات (Geographic Population)",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "مقارنة عدد الأسر والأفراد حسب المنطقة الفرعية الحالية (currentSubRegion)",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${geoDemographics.size} منطقة",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0D9488)
                                    )
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                                // المخطط البياني الأفقي المخصص (Compose Canvas Bar Chart)
                                ExecutiveHorizontalBarChart(items = geoDemographics)
                            }
                        }
                    }

                    // ==============================================================
                    // القسم 3: تحليل أضرار الحرب والتوزيع المتداخل (Section 3: Damages Analysis)
                    // مخطط دونات نقي عبر Compose Canvas مع قائمة أكورديون قابلة للتوسيع
                    // ==============================================================
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            modifier = Modifier.size(28.dp).background(Color(0xFFDC2626).copy(alpha = 0.15f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.PieChart, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                        }
                                        Column {
                                            Text(
                                                text = "تحليل وتقييم أضرار الحرب (Damages Analysis)",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "مخطط الدونات ومصفوفة التوزيع المتداخل حسب المحليات",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                                // مخطط الدونات المخصص (Compose Canvas Donut Chart)
                                ExecutiveDonutChart(items = damageBreakdown)

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                                // قائمة تفكيك الأضرار حسب المنطقة الفرعية الحالية (Accordion List)
                                Text(
                                    text = "تفكيك حجم الضرر تفصيلياً حسب المنطقة الفرعية الحالية (اضغط للتوسيع):",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    damageBreakdown.forEach { damageItem ->
                                        val isExpanded = expandedDamageCategory == damageItem.label
                                        OutlinedCard(
                                            onClick = {
                                                expandedDamageCategory = if (isExpanded) null else damageItem.label
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = CardDefaults.outlinedCardColors(
                                                containerColor = if (isExpanded) Color(0xFFFEF2F2) else Color.Transparent
                                            ),
                                            border = BorderStroke(
                                                1.dp,
                                                if (isExpanded) Color(0xFFDC2626) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                                            ),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                        Icon(
                                                            if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                                            contentDescription = null,
                                                            tint = if (isExpanded) Color(0xFFDC2626) else Color.Gray,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                        Text(
                                                            text = damageItem.label,
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (isExpanded) Color(0xFF991B1B) else MaterialTheme.colorScheme.onSurface
                                                        )
                                                    }
                                                    Text(
                                                        text = "${String.format(Locale.US, "%,d", damageItem.count)} أسرة (${String.format(Locale.US, "%.1f%%", damageItem.percentage)})",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFFDC2626)
                                                    )
                                                }

                                                // التوزيع الداخلي حسب currentSubRegion
                                                AnimatedVisibility(visible = isExpanded) {
                                                    Column(
                                                        modifier = Modifier.padding(top = 10.dp),
                                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        HorizontalDivider(color = Color(0xFFFECACA))
                                                        val subList = damageByRegionBreakdown[damageItem.label] ?: emptyList()
                                                        if (subList.isEmpty()) {
                                                            Text("لا توجد تفاصيل مناطق متوفرة", fontSize = 10.sp, color = Color.Gray)
                                                        } else {
                                                            subList.take(5).forEach { sub ->
                                                                Row(
                                                                    modifier = Modifier.fillMaxWidth(),
                                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                                    verticalAlignment = Alignment.CenterVertically
                                                                ) {
                                                                    Text(sub.label, fontSize = 11.sp, color = Color(0xFF334155))
                                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                                        Text(
                                                                            text = "${sub.count} أسرة (${String.format(Locale.US, "%.1f%%", sub.percentage)})",
                                                                            fontSize = 10.sp,
                                                                            fontWeight = FontWeight.Bold,
                                                                            color = Color(0xFFDC2626)
                                                                        )
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ==============================================================
                    // القسم 4: تصنيفات المساعدات الإغاثية (Section 4: Aid Categories)
                    // شبكة بصرية أنيقة بأصناف المساعدات ونسب الحصص
                    // ==============================================================
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Box(
                                            modifier = Modifier.size(28.dp).background(Color(0xFF0284C7).copy(alpha = 0.15f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Category, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(16.dp))
                                        }
                                        Column {
                                            Text(
                                                text = "توزيع المساعدات حسب الأصناف (Aid Categories)",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "المعونات المسلمة فعلياً خلال الفترة التحليلية المحددة",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${aidTypesBreakdown.size} صنف",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0284C7)
                                    )
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                                if (aidTypesBreakdown.isEmpty()) {
                                    Text("لا توجد سجلات تسليم خلال هذا النطاق الزمني", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        aidTypesBreakdown.forEach { aidItem ->
                                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(14.dp))
                                                        Text(aidItem.label, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                    Text(
                                                        text = "${String.format(Locale.US, "%,d", aidItem.count)} طرد / معونة (${String.format(Locale.US, "%.1f%%", aidItem.percentage)})",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = Color(0xFF0284C7)
                                                    )
                                                }
                                                LinearProgressIndicator(
                                                    progress = { (aidItem.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(6.dp)
                                                        .clip(RoundedCornerShape(3.dp)),
                                                    color = Color(0xFF0284C7),
                                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ==============================================================
                    // القسم 5: مصفوفة أداء المشاريع الإغاثية (Section 5: Projects Performance)
                    // قائمة عمودية من البطاقات المنسقة مع مؤشر الإنجاز الملون ديناميكياً
                    // ==============================================================
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier.size(28.dp).background(Color(0xFF16A34A).copy(alpha = 0.15f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Assignment, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(16.dp))
                                        }
                                        Column(modifier = Modifier.weight(1f, fill = false)) {
                                            Text(
                                                text = "مصفوفة أداء المشاريع النشطة (Projects Performance)",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "متابعة الحصة المستهدفة مقابل المسلم الفعلي ونسبة الإنجاز",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFF16A34A).copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = "${projectStatsList.size} مشاريع",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF16A34A),
                                            maxLines = 1,
                                            softWrap = false,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                                if (projectStatsList.isEmpty()) {
                                    Text("لا توجد مشاريع إغاثية نشطة مسجلة في هذا النطاق", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        projectStatsList.forEach { p ->
                                            val progressColor = when {
                                                p.completionPercentage >= 90.0 -> Color(0xFF16A34A) // Green
                                                p.completionPercentage >= 50.0 -> Color(0xFFF59E0B) // Amber
                                                else -> Color(0xFFEF4444) // Red
                                            }

                                            OutlinedCard(
                                                shape = RoundedCornerShape(12.dp),
                                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(12.dp),
                                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(
                                                                text = p.projectName,
                                                                fontSize = 13.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = MaterialTheme.colorScheme.onSurface
                                                            )
                                                            Text(
                                                                text = "صنف المعونة: ${p.aidTypeName} • التاريخ: ${p.projectDate}",
                                                                fontSize = 10.sp,
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                                            )
                                                        }

                                                        // شارة نسبة الإنجاز الملونة
                                                        Surface(
                                                            shape = RoundedCornerShape(8.dp),
                                                            color = progressColor.copy(alpha = 0.12f),
                                                            border = BorderStroke(1.dp, progressColor.copy(alpha = 0.3f))
                                                        ) {
                                                            Text(
                                                                text = "${String.format(Locale.US, "%.1f%%", p.completionPercentage)} إنجاز",
                                                                color = progressColor,
                                                                fontSize = 11.sp,
                                                                fontWeight = FontWeight.ExtraBold,
                                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                                            )
                                                        }
                                                    }

                                                    // أرقام الحصة
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Text(
                                                            text = "المسلم فعلياً: ${String.format(Locale.US, "%,d", p.deliveredCount)}",
                                                            fontSize = 11.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = progressColor
                                                        )
                                                        Text(
                                                            text = "المستهدف الكلي: ${String.format(Locale.US, "%,d", p.targetQuota)}",
                                                            fontSize = 11.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }

                                                    // شريط التقدم الملون ديناميكياً
                                                    LinearProgressIndicator(
                                                        progress = { (p.completionPercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .height(6.dp)
                                                            .clip(RoundedCornerShape(3.dp)),
                                                        color = progressColor,
                                                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // تباعد سفلي مريح للـ FAB
                    item {
                        Spacer(modifier = Modifier.height(60.dp))
                    }
                }
            }
        }

    // ==========================================
    // نافذة اختيار وتخصيص الأعمدة (Column Selector Dialog)
    // ==========================================
    if (showColumnSelectorDialog) {
        ExportColumnSelectorDialog(
            exportFormat = "DUAL",
            reportTitle = "كشف المستفيدين المعتمد ($fromDate إلى $toDate)",
            initialSelectedKeys = ExportColumnRegistry.DEFAULT_SELECTED_KEYS,
            onExportExcel = { chosenKeys ->
                showColumnSelectorDialog = false
                pendingSelectedColumns = chosenKeys
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val fileName = "Beneficiaries_List_${fromDate}_to_${toDate}_$timeStamp.csv"
                dynamicExcelLauncher.launch(fileName)
            },
            onExportPdf = { chosenKeys ->
                showColumnSelectorDialog = false
                pendingSelectedColumns = chosenKeys
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val fileName = "Beneficiaries_List_${fromDate}_to_${toDate}_$timeStamp.pdf"
                dynamicPdfLauncher.launch(fileName)
            },
            onDismiss = {
                showColumnSelectorDialog = false
            }
        )
    }

    // مؤشر التحميل أثناء التصدير والتوليد
    if (isExporting) {
        Dialog(
            onDismissRequest = {},
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(32.dp), strokeWidth = 3.dp)
                    Text("جاري استخراج مؤشرات ذكاء الأعمال وبناء الملف...", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

// =========================================================================
// المكونات البصرية المخصصة (Custom BI Visual Components)
// =========================================================================

/**
 * بطاقة المؤشر القيادي المتوهجة (Executive Glowing Card)
 */
@Composable
private fun ExecutiveGlowingCard(
    title: String,
    value: String,
    unit: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.glassEffect(
            shape = RoundedCornerShape(16.dp),
            surfaceColor = color.copy(alpha = 0.08f),
            borderColor = color.copy(alpha = 0.35f),
            elevation = 2.dp
        ),
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .background(color.copy(alpha = 0.15f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(13.dp))
                }
            }
            Text(
                text = value,
                fontSize = 17.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = unit,
                fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * المخطط البياني الأفقي للمناطق والسكان عبر Compose Canvas
 * (Custom Horizontal Bar Chart strictly using currentSubRegion)
 */
@Composable
private fun ExecutiveHorizontalBarChart(
    items: List<ExecutiveGeoDemographicItem>,
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) {
        Box(modifier = modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد بيانات جغرافية مسجلة", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        return
    }

    val displayItems = items.take(6)
    val maxPct = (displayItems.maxOfOrNull { maxOf(it.familyPercentage, it.individualPercentage) } ?: 100.0).toFloat().coerceAtLeast(10f)

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        displayItems.forEach { item ->
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.regionName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${String.format(Locale.US, "%,d", item.familyCount)} أسرة (${String.format(Locale.US, "%.1f%%", item.familyPercentage)}) • ${String.format(Locale.US, "%,d", item.individualCount)} فرد (${String.format(Locale.US, "%.1f%%", item.individualPercentage)})",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium
                    )
                }

                // رسم شريطي مزدوج عبر Canvas: الأسر (Teal) والأفراد (Indigo)
                Canvas(modifier = Modifier.fillMaxWidth().height(16.dp)) {
                    val w = size.width
                    val trackHeight = 6.dp.toPx()
                    val corner = 3.dp.toPx()

                    // 1. شريط الأسر (Families)
                    val famW = (w * (item.familyPercentage.toFloat() / maxPct)).coerceIn(0f, w)
                    drawRoundRect(
                        color = Color(0xFFE2E8F0),
                        topLeft = Offset(0f, 0f),
                        size = Size(w, trackHeight),
                        cornerRadius = CornerRadius(corner, corner)
                    )
                    if (famW > 0f) {
                        drawRoundRect(
                            color = Color(0xFF0D9488),
                            topLeft = Offset(0f, 0f),
                            size = Size(famW, trackHeight),
                            cornerRadius = CornerRadius(corner, corner)
                        )
                    }

                    // 2. شريط الأفراد (Individuals)
                    val indivW = (w * (item.individualPercentage.toFloat() / maxPct)).coerceIn(0f, w)
                    val top2 = 9.dp.toPx()
                    drawRoundRect(
                        color = Color(0xFFE2E8F0),
                        topLeft = Offset(0f, top2),
                        size = Size(w, trackHeight),
                        cornerRadius = CornerRadius(corner, corner)
                    )
                    if (indivW > 0f) {
                        drawRoundRect(
                            color = Color(0xFF6366F1),
                            topLeft = Offset(0f, top2),
                            size = Size(indivW, trackHeight),
                            cornerRadius = CornerRadius(corner, corner)
                        )
                    }
                }
            }
        }

        // دليل الألوان التوضيحي (Legend)
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(modifier = Modifier.size(10.dp).background(Color(0xFF0D9488), RoundedCornerShape(2.dp)))
                Text("الأسر المسجلة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(modifier = Modifier.size(10.dp).background(Color(0xFF6366F1), RoundedCornerShape(2.dp)))
                Text("الأفراد المستهدفون", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
            }
        }
    }
}

/**
 * مخطط الدونات المخصص لتحليل أضرار الحرب عبر Compose Canvas
 * (Custom Donut Chart with center metric)
 */
@Composable
private fun ExecutiveDonutChart(
    items: List<ExecutiveCategoryItem>,
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) {
        Box(modifier = modifier.fillMaxWidth().height(140.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد بيانات أضرار مسجلة", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        return
    }

    val palette = listOf(
        Color(0xFFDC2626), // Red (كلي غير صالح)
        Color(0xFFEA580C), // Orange (جزئي غير صالح)
        Color(0xFFF59E0B), // Amber (جزئي صالح)
        Color(0xFF8B5CF6), // Purple (بليغ)
        Color(0xFF0284C7), // Blue (طفيف)
        Color(0xFF0D9488)  // Teal (أخرى)
    )

    val totalCount = items.sumOf { it.count }
    val displayItems = items.take(6)

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // مخطط الدونات عبر Canvas مع المركز الرقمي
        Box(
            modifier = Modifier.size(150.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize().padding(10.dp)) {
                val strokeWidth = 24.dp.toPx()
                var startAngle = -90f

                displayItems.forEachIndexed { idx, item ->
                    val sweepAngle = if (totalCount > 0) {
                        (item.count.toFloat() / totalCount.toFloat()) * 360f
                    } else 0f
                    val color = palette[idx % palette.size]

                    if (sweepAngle > 0f) {
                        drawArc(
                            color = color,
                            startAngle = startAngle,
                            sweepAngle = (sweepAngle - 2f).coerceAtLeast(1f), // مسافة أنيقة بين الشرائح
                            useCenter = false,
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                        )
                    }
                    startAngle += sweepAngle
                }
            }

            // النص الرقمي في المركز
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = String.format(Locale.US, "%,d", totalCount),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "أسرة متضررة",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // دليل الألوان والنسب (Legend)
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            displayItems.forEachIndexed { idx, item ->
                val color = palette[idx % palette.size]
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(modifier = Modifier.size(8.dp).background(color, CircleShape))
                        Text(
                            text = item.label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = "${String.format(Locale.US, "%,d", item.count)} (${String.format(Locale.US, "%.1f%%", item.percentage)})",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = color
                    )
                }
            }
        }
    }
}
