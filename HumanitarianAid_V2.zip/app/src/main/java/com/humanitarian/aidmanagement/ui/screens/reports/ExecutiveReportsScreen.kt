package com.humanitarian.aidmanagement.ui.screens.reports

import android.app.DatePickerDialog
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.ExportColumnSelectorDialog
import com.humanitarian.aidmanagement.ui.screens.excel.ExcelImportExportScreen
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

enum class ExecutiveScreenMode {
    EXECUTIVE_DASHBOARD, // لوحة التقرير الإداري التنفيذي والمعاينة الحية
    DATA_IMPORT          // استيراد وتدقيق ملفات الإكسل المعتمدة
}

enum class BreakdownTab(val label: String) {
    SHELTER("حالة الإيواء"),
    DAMAGE("أضرار الحرب")
}

/**
 * شاشة التقرير الإداري التنفيذي الموحد ولوحة المعاينة الحية
 * (Dynamic Executive Reporting Dashboard & Visual Previews)
 * تدعم تجميع البيانات المعقدة ديناميكياً (جغرافياً، معونات، أضرار)،
 * واختيار الأعمدة عبر Dynamic Column Chooser،
 * وتصدير تقارير PDF وإكسل وفق معمارية Cache-First الصارمة لمنع انهيار SAF.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExecutiveReportsScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val exporter = remember { ProfessionalReportExporter(context) }

    var currentMode by remember { mutableStateOf(ExecutiveScreenMode.EXECUTIVE_DASHBOARD) }
    var selectedBreakdownTab by remember { mutableStateOf(BreakdownTab.SHELTER) }

    // نطاق الفلترة الزمنية
    var fromDate by remember { mutableStateOf("2026-01-01") }
    var toDate by remember { mutableStateOf("2026-10-31") }
    var selectedPreset by remember { mutableStateOf("العام الحالي 2026") }

    // جلب البيانات التفاعلية من قاعدة بيانات Room
    val allFamilies by repository.getAllFamiliesFlow().collectAsState(initial = emptyList())
    val allAidRecords by repository.database.aidRecordDao().getAllAidRecords().collectAsState(initial = emptyList())

    // حالات التصدير
    var isExporting by remember { mutableStateOf(false) }
    var exportStatusMessage by remember { mutableStateOf<String?>(null) }
    var showColumnSelectorDialog by remember { mutableStateOf(false) }

    // ملف تم تصديره بنجاح للعرض والمشاركة
    var lastExportedFile by remember { mutableStateOf<File?>(null) }
    var lastExportedMimeType by remember { mutableStateOf("application/pdf") }

    // التصدير المعلق لـ SAF
    var pendingExportType by remember { mutableStateOf<String?>(null) } // "EXECUTIVE_PDF", "DATA_EXCEL", "DATA_PDF"
    var pendingSelectedColumns by remember { mutableStateOf<List<String>>(ExportColumnRegistry.DEFAULT_SELECTED_KEYS) }

    // حساب وتجميع المؤشرات الإحصائية في الخلفية
    val filteredAidRecords = remember(allAidRecords, fromDate, toDate) {
        allAidRecords.filter { record ->
            val date = record.deliveryDate ?: record.aidDate
            date >= fromDate && date <= toDate
        }
    }

    val totalFamiliesCount = allFamilies.size
    val totalDeliveredCount = remember(filteredAidRecords) {
        filteredAidRecords.count { it.recipientStatus.contains("مستلم") || it.recipientStatus.contains("تم التسليم") || it.recipientStatus.contains("مستفيد") }
    }
    val deliveryPercentage = remember(totalFamiliesCount, totalDeliveredCount) {
        if (totalFamiliesCount > 0) {
            (totalDeliveredCount.toDouble() / totalFamiliesCount.toDouble() * 100.0).coerceAtMost(100.0)
        } else 0.0
    }

    // التوزيع الجغرافي (حسب المحليات / النطاق الميداني currentSubRegion أو currentSubArea)
    val geoBreakdown = remember(allFamilies) {
        if (allFamilies.isEmpty()) emptyList()
        else {
            val total = allFamilies.size.toDouble()
            allFamilies.groupingBy { 
                val reg = it.currentSubRegion?.trim().orEmpty()
                val area = it.currentSubArea?.trim().orEmpty()
                when {
                    reg.isNotBlank() -> reg
                    area.isNotBlank() -> area
                    else -> "محلية غير محددة"
                }
            }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .take(8)
            .map { entry ->
                ExecutiveGeoItem(
                    name = entry.key,
                    count = entry.value,
                    percentage = (entry.value / total) * 100.0
                )
            }
        }
    }

    // تصنيف حالة الإيواء (Shelter Status)
    val shelterBreakdown = remember(allFamilies) {
        if (allFamilies.isEmpty()) emptyList()
        else {
            val total = allFamilies.size.toDouble()
            allFamilies.groupingBy { 
                it.shelterStatus?.trim()?.ifBlank { "غير محدد" } ?: "غير محدد"
            }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .map { entry ->
                ExecutiveCategoryItem(
                    label = entry.key,
                    count = entry.value,
                    percentage = (entry.value / total) * 100.0
                )
            }
        }
    }

    // تصنيف أضرار الحرب (Damage Types)
    val damageBreakdown = remember(allFamilies) {
        if (allFamilies.isEmpty()) emptyList()
        else {
            val total = allFamilies.size.toDouble()
            allFamilies.groupingBy { 
                it.damageType?.trim()?.ifBlank { "غير مصنف" } ?: "غير مصنف"
            }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .map { entry ->
                ExecutiveCategoryItem(
                    label = entry.key,
                    count = entry.value,
                    percentage = (entry.value / total) * 100.0
                )
            }
        }
    }

    // مشغلات Storage Access Framework (SAF)
    val executivePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        if (uri == null) {
            Toast.makeText(context, "تم إلغاء حفظ التقرير الإداري", Toast.LENGTH_SHORT).show()
            return@rememberLauncherForActivityResult
        }
        scope.launch {
            isExporting = true
            try {
                val reportData = ExecutiveReportData(
                    fromDate = fromDate,
                    toDate = toDate,
                    totalFamilies = totalFamiliesCount,
                    totalDelivered = totalDeliveredCount,
                    deliveryPercentage = deliveryPercentage,
                    geoBreakdown = geoBreakdown,
                    shelterBreakdown = shelterBreakdown,
                    damageBreakdown = damageBreakdown,
                    supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات المركزية"
                )
                val result = exporter.exportExecutiveReportPdfToUri(uri, reportData)
                result.onSuccess {
                    exportStatusMessage = "✅ تم تصدير التقرير الإداري التنفيذي (PDF) بنجاح وفق معمارية التخزين الآمن."
                    Toast.makeText(context, "تم تصدير التقرير الإداري بنجاح", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    exportStatusMessage = "❌ فشل تصدير التقرير الإداري: ${err.message}"
                    Toast.makeText(context, "خطأ أثناء التصدير: ${err.message}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                exportStatusMessage = "❌ خطأ أثناء التصدير: ${e.message}"
                Toast.makeText(context, "خطأ: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                isExporting = false
            }
        }
    }

    val dynamicExcelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    ) { uri: Uri? ->
        if (uri == null) {
            Toast.makeText(context, "تم إلغاء حفظ ملف الإكسل", Toast.LENGTH_SHORT).show()
            return@rememberLauncherForActivityResult
        }
        scope.launch {
            isExporting = true
            try {
                val result = exporter.exportDynamicFamiliesExcelToUri(
                    uri = uri,
                    reportTitle = "كشف المستفيدين المعتمد - التقرير التنفيذي",
                    selectedColumnKeys = pendingSelectedColumns,
                    families = allFamilies
                )
                result.onSuccess {
                    exportStatusMessage = "✅ تم تصدير كشف الإكسل بنجاح (${pendingSelectedColumns.size} عمود محدد)."
                    Toast.makeText(context, "تم تصدير ملف الإكسل بنجاح", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    exportStatusMessage = "❌ فشل تصدير الإكسل: ${err.message}"
                    Toast.makeText(context, "خطأ أثناء التصدير: ${err.message}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                exportStatusMessage = "❌ خطأ في تصدير الإكسل: ${e.message}"
                Toast.makeText(context, "خطأ: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                isExporting = false
            }
        }
    }

    val dynamicPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        if (uri == null) {
            Toast.makeText(context, "تم إلغاء حفظ مستند PDF", Toast.LENGTH_SHORT).show()
            return@rememberLauncherForActivityResult
        }
        scope.launch {
            isExporting = true
            try {
                val result = exporter.exportDynamicFamiliesPdfToUri(
                    uri = uri,
                    reportTitle = "كشف المستفيدين المعتمد - التقرير التنفيذي",
                    selectedColumnKeys = pendingSelectedColumns,
                    families = allFamilies,
                    supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات المركزية"
                )
                result.onSuccess {
                    exportStatusMessage = "✅ تم تصدير كشف PDF بنجاح (${pendingSelectedColumns.size} عمود محدد)."
                    Toast.makeText(context, "تم تصدير مستند PDF بنجاح", Toast.LENGTH_LONG).show()
                }.onFailure { err ->
                    exportStatusMessage = "❌ فشل تصدير كشف PDF: ${err.message}"
                    Toast.makeText(context, "خطأ أثناء التصدير: ${err.message}", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                exportStatusMessage = "❌ خطأ في تصدير PDF: ${e.message}"
                Toast.makeText(context, "خطأ: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                isExporting = false
            }
        }
    }

    // دوال اختيار التواريخ
    fun openDatePicker(isFrom: Boolean) {
        val calendar = Calendar.getInstance()
        val currentStr = if (isFrom) fromDate else toDate
        val parts = currentStr.split("-")
        val y = parts.getOrNull(0)?.toIntOrNull() ?: calendar.get(Calendar.YEAR)
        val m = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val d = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(context, { _, year, month, dayOfMonth ->
            val formatted = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth)
            if (isFrom) fromDate = formatted else toDate = formatted
            selectedPreset = "مخصص"
        }, y, m, d).show()
    }

    fun applyPreset(preset: String) {
        selectedPreset = preset
        when (preset) {
            "هذا الشهر" -> {
                fromDate = "2026-10-01"
                toDate = "2026-10-31"
            }
            "الربع الثالث 2026" -> {
                fromDate = "2026-07-01"
                toDate = "2026-09-30"
            }
            "العام الحالي 2026" -> {
                fromDate = "2026-01-01"
                toDate = "2026-12-31"
            }
            "كافة الفترات" -> {
                fromDate = "2024-01-01"
                toDate = "2026-12-31"
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "التقرير الإداري التنفيذي الموحد",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(text = "🇵🇸", fontSize = 16.sp)
                            }
                            Text(
                                text = "المعاينة الحية • التحليلات الإحصائية • التصدير المخصص",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = MaterialTheme.colorScheme.primary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            // إذا كان المستخدم في وضع استيراد وتدقيق البيانات، نعرض قسم الاستيراد
            if (currentMode == ExecutiveScreenMode.DATA_IMPORT) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                ) {
                    ExcelImportExportScreen(
                        repository = repository,
                        onNavigateBack = { currentMode = ExecutiveScreenMode.EXECUTIVE_DASHBOARD }
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .padding(paddingValues)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    // 1. أشرطة التبديل العلوية بين (التقرير التنفيذي) و (استيراد الإكسل)
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(4.dp)
                        ) {
                            Surface(
                                modifier = Modifier
                                    .weight(1.3f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { currentMode = ExecutiveScreenMode.EXECUTIVE_DASHBOARD },
                                color = if (currentMode == ExecutiveScreenMode.EXECUTIVE_DASHBOARD) MaterialTheme.colorScheme.surface else Color.Transparent,
                                shadowElevation = if (currentMode == ExecutiveScreenMode.EXECUTIVE_DASHBOARD) 2.dp else 0.dp
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Assessment,
                                        contentDescription = null,
                                        tint = if (currentMode == ExecutiveScreenMode.EXECUTIVE_DASHBOARD) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "التقرير الإداري التنفيذي",
                                        fontWeight = if (currentMode == ExecutiveScreenMode.EXECUTIVE_DASHBOARD) FontWeight.Bold else FontWeight.Normal,
                                        color = if (currentMode == ExecutiveScreenMode.EXECUTIVE_DASHBOARD) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { currentMode = ExecutiveScreenMode.DATA_IMPORT },
                                color = if (currentMode == ExecutiveScreenMode.DATA_IMPORT) MaterialTheme.colorScheme.surface else Color.Transparent,
                                shadowElevation = if (currentMode == ExecutiveScreenMode.DATA_IMPORT) 2.dp else 0.dp
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.FileUpload,
                                        contentDescription = null,
                                        tint = if (currentMode == ExecutiveScreenMode.DATA_IMPORT) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "استيراد وتدقيق البيانات",
                                        fontWeight = if (currentMode == ExecutiveScreenMode.DATA_IMPORT) FontWeight.Bold else FontWeight.Normal,
                                        color = if (currentMode == ExecutiveScreenMode.DATA_IMPORT) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }

                    // 2. القسم العلوي: منتقي النطاق الزمني والفلاتر السريعة
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                        Text(
                                            text = "النطاق الزمني للتحليل الإداري",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = MaterialTheme.colorScheme.primaryContainer
                                    ) {
                                        Text(
                                            text = "$totalDeliveredCount مساعدة منفذة",
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                // أزرار الفترات السريعة (Quick Presets)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    val presets = listOf("هذا الشهر", "الربع الثالث 2026", "العام الحالي 2026", "كافة الفترات")
                                    presets.forEach { p ->
                                        FilterChip(
                                            selected = selectedPreset == p,
                                            onClick = { applyPreset(p) },
                                            label = { Text(p, fontSize = 11.sp) }
                                        )
                                    }
                                }

                                // مربعي التاريخ التفاعليين (من / إلى)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedCard(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { openDatePicker(true) },
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text("من تاريخ:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(fromDate, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                    }

                                    OutlinedCard(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { openDatePicker(false) },
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text("إلى تاريخ:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(toDate, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // إشعار الحالة
                    if (exportStatusMessage != null) {
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = exportStatusMessage ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }

                    // 3. القسم الأوسط: المعاينة الحية للتقرير الإداري التنفيذي (ElevatedCard Visual Preview)
                    item {
                        ElevatedCard(
                            shape = RoundedCornerShape(20.dp),
                            elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp),
                            colors = CardDefaults.elevatedCardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                // ترويسة بطاقة المعاينة التنفيذية
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                            modifier = Modifier.size(40.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Default.RemoveRedEye, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                        Column {
                                            Text(
                                                text = "المعاينة الحية لتقرير الإدارة العليا",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "مؤشرات الإنجاز الميداني • $fromDate إلى $toDate",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color(0xFF16A34A).copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = "مباشر ومحدث",
                                            color = Color(0xFF16A34A),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                                // أ) المؤشرات الأساسية الثلاثة (KPIs Cards)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // 1. إجمالي الأسر
                                    ExecutiveKpiCard(
                                        title = "إجمالي الأسر",
                                        value = String.format(Locale.US, "%,d", totalFamiliesCount),
                                        unit = "أسرة مسجلة",
                                        color = Color(0xFF0D9488),
                                        icon = Icons.Default.FamilyRestroom,
                                        modifier = Modifier.weight(1f)
                                    )

                                    // 2. المساعدات المسلمة
                                    ExecutiveKpiCard(
                                        title = "المساعدات المسلمة",
                                        value = String.format(Locale.US, "%,d", totalDeliveredCount),
                                        unit = "طرد / معونة",
                                        color = Color(0xFF0284C7),
                                        icon = Icons.Default.Inventory2,
                                        modifier = Modifier.weight(1f)
                                    )

                                    // 3. نسبة الإنجاز والتغطية
                                    ExecutiveKpiCard(
                                        title = "نسبة التغطية",
                                        value = String.format(Locale.US, "%.1f%%", deliveryPercentage),
                                        unit = "معدل الإنجاز",
                                        color = Color(0xFF16A34A),
                                        icon = Icons.Default.TrendingUp,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                // شريط التقدم الشامل لنسبة التغطية
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("معدل التغطية الميدانية الإجمالي:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(String.format(Locale.US, "%.1f%%", deliveryPercentage), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF16A34A))
                                    }
                                    LinearProgressIndicator(
                                        progress = { (deliveryPercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp)),
                                        color = Color(0xFF16A34A),
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                // ب) التحليل الجغرافي للمحليات (Geographic Breakdown)
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "التوزيع الجغرافي ونسب التغطية بالمحليات:",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text("${geoBreakdown.size} منطقة رئيسية", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    if (geoBreakdown.isEmpty()) {
                                        Text("لا توجد بيانات جغرافية مسجلة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    } else {
                                        geoBreakdown.take(5).forEach { item ->
                                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(item.name, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                                    Text(
                                                        text = "${String.format(Locale.US, "%,d", item.count)} أسرة (${String.format(Locale.US, "%.1f%%", item.percentage)})",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                                LinearProgressIndicator(
                                                    progress = { (item.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(6.dp)
                                                        .clip(RoundedCornerShape(3.dp)),
                                                    color = Color(0xFF0D9488),
                                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                // ج) تفكيك التصنيفات الميدانية: حالة الإيواء وأضرار الحرب (Categorization Breakdown)
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "تصنيفات الفئات والاحتياج الميداني:",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )

                                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            BreakdownTab.values().forEach { tab ->
                                                FilterChip(
                                                    selected = selectedBreakdownTab == tab,
                                                    onClick = { selectedBreakdownTab = tab },
                                                    label = { Text(tab.label, fontSize = 10.sp) },
                                                    shape = RoundedCornerShape(8.dp)
                                                )
                                            }
                                        }
                                    }

                                    val activeBreakdownList = if (selectedBreakdownTab == BreakdownTab.SHELTER) shelterBreakdown else damageBreakdown
                                    val activeColor = if (selectedBreakdownTab == BreakdownTab.SHELTER) Color(0xFF0284C7) else Color(0xFFEF4444)

                                    if (activeBreakdownList.isEmpty()) {
                                        Text("لا توجد بيانات مسجلة لهذا التصنيف", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    } else {
                                        activeBreakdownList.take(4).forEach { item ->
                                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(item.label, fontSize = 11.sp)
                                                    Text(
                                                        text = "${String.format(Locale.US, "%,d", item.count)} (${String.format(Locale.US, "%.1f%%", item.percentage)})",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = activeColor
                                                    )
                                                }
                                                LinearProgressIndicator(
                                                    progress = { (item.percentage / 100.0).toFloat().coerceIn(0f, 1f) },
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(6.dp)
                                                        .clip(RoundedCornerShape(3.dp)),
                                                    color = activeColor,
                                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 4. القسم السفلي: أزرار التصدير الإدارية والتخصيص
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "إجراءات التصدير المعتمدة وفق معمارية Cache-First:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                // الزر الأول: تصدير التقرير الإداري (PDF)
                                Button(
                                    onClick = {
                                        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                        val fileName = "Executive_Report_${fromDate}_to_${toDate}_$timeStamp.pdf"
                                        executivePdfLauncher.launch(fileName)
                                    },
                                    enabled = !isExporting,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "تصدير التقرير الإداري (PDF)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                // الزر الثاني: تصدير كشوفات البيانات (يفتح نافذة تحديد الأعمدة)
                                Button(
                                    onClick = {
                                        showColumnSelectorDialog = true
                                    },
                                    enabled = !isExporting,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "تصدير كشوفات البيانات (تخصيص الأعمدة)",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة اختيار وتخصيص الأعمدة المطلوبة بالتصدير (Dynamic Column Chooser Dialog)
    if (showColumnSelectorDialog) {
        ExportColumnSelectorDialog(
            exportFormat = "DUAL",
            reportTitle = "كشف المستفيدين المعتمد ($fromDate إلى $toDate)",
            initialSelectedKeys = ExportColumnRegistry.DEFAULT_SELECTED_KEYS,
            onExportExcel = { chosenKeys ->
                showColumnSelectorDialog = false
                pendingSelectedColumns = chosenKeys
                pendingExportType = "DATA_EXCEL"
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val fileName = "Beneficiaries_List_${fromDate}_to_${toDate}_$timeStamp.xlsx"
                dynamicExcelLauncher.launch(fileName)
            },
            onExportPdf = { chosenKeys ->
                showColumnSelectorDialog = false
                pendingSelectedColumns = chosenKeys
                pendingExportType = "DATA_PDF"
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val fileName = "Beneficiaries_List_${fromDate}_to_${toDate}_$timeStamp.pdf"
                dynamicPdfLauncher.launch(fileName)
            },
            onDismiss = {
                showColumnSelectorDialog = false
            }
        )
    }

    // مؤشر التحميل في الخلفية أثناء توليد الملفات
    if (isExporting) {
        Dialog(
            onDismissRequest = {},
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(32.dp), strokeWidth = 3.dp)
                    Text("جاري استخراج البيانات وبناء الملف بأمان...", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun ExecutiveKpiCard(
    title: String,
    value: String,
    unit: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.08f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
            }
            Text(
                text = value,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(unit, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
