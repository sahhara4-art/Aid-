package com.humanitarian.aidmanagement.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index
import androidx.room.DatabaseView

/**
 * tbl_Users - جدول المستخدمين ومنظومة الأمان والتحكم في الدخول
 */
@Entity(
    tableName = "tbl_Users",
    indices = [
        Index(value = ["UserName"], unique = true),
        Index(value = ["NationalID"])
    ]
)
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val UserID: Int = 0,
    val UserName: String,
    val PasswordHash: String,
    @androidx.room.ColumnInfo(name = "FullName")
    val fullName: String,
    val NationalID: String = "",
    val Email: String? = null,
    val PhoneNumber: String? = null,
    val RoleID: Int,
    val RoleName: String = "مدير النظام",
    // ضوابط وقيود الدخول والاستخدام المتقدمة
    val MaxAllowedLogins: Int = 0, // الحد الأقصى لمرات الدخول المسموح بها (0 = غير محدود)
    val ConsumedLogins: Int = 0, // عدد مرات الدخول المستهلكة
    val SessionDurationMinutes: Int = 60, // مدة الجلسة المسموح بها بالدقائق
    val AccountExpiryDate: String? = null, // تاريخ انتهاء صلاحية الحساب (YYYY-MM-DD)
    val AllowedStartTime: String = "08:00", // نافذة بدء ساعات العمل
    val AllowedEndTime: String = "17:00", // نافذة نهاية ساعات العمل
    val AllowedWarehouse: String = "كافة المستودعات", // تقييد المستودع
    val AllowedLocalityID: Int = 0, // تقييد المنطقة/المحلية (0 = الكل)
    val AllowedGroup: String = "كافة المجموعات", // مجموعة العمل والتوزيع الميداني (مجموعة أ، مجموعة ب، فريق المخيمات، إلخ)
    // الصلاحيات الجغرافية المعتمدة على المناطق الفرعية الحالية
    val AllowedViewSubAreas: String = "*", // المناطق الفرعية الحالية المصرح بمشاهدتها (* أو قائمة محددة)
    val AllowedNominationSubAreas: String = "*", // المناطق الفرعية الحالية المصرح بالترشيح فيها
    val AllowedDeliverySubAreas: String = "*", // المناطق الفرعية الحالية المصرح بالتسليم والصرف فيها
    val AllowedEditSubAreas: String = "*", // المناطق الفرعية الحالية المصرح بتعديل أسرها
    val AllowedScreens: String = "dashboard,families,nomination,delivery,reports,excel_import_export,users,backup", // الشاشات المصرح بظهورها واستخدامها
    val IsActive: Boolean = true,
    val IsLocked: Boolean = false,
    val FailedAttempts: Int = 0,
    val LastLogin: Long? = null,
    val MustChangePassword: Boolean = false,
    val CreatedDate: Long = System.currentTimeMillis(),
    val CreatedBy: String = "System",
    val ModifiedDate: Long? = null,
    val ModifiedBy: String? = null,
    val LockedUntil: Long? = null // توقيت انتهاء قفل الحساب عند تجاوز المحاولات الفاشلة
)

/**
 * tbl_User_Permissions - جدول الصلاحيات الدقيقة المفصلة لكل مستخدم
 */
@Entity(
    tableName = "tbl_User_Permissions",
    indices = [
        Index(value = ["UserID", "PermissionKey"], unique = true)
    ]
)
data class UserPermissionEntity(
    @PrimaryKey(autoGenerate = true)
    val PermissionID: Long = 0,
    val UserID: Int,
    val PermissionKey: String, // e.g. "delivery_handover", "nomination_run"
    val Category: String, // أسر، ترشيح، تسليم، مشاريع، تقارير، أمان
    val Description: String,
    val IsGranted: Boolean = true
)

/**
 * tbl_User_Access_Logs - سجل التدقيق الأمني وعمليات الدخول والنشاط
 */
@Entity(
    tableName = "tbl_User_Access_Logs",
    indices = [
        Index(value = ["UserID"]),
        Index(value = ["Timestamp"])
    ]
)
data class UserAccessLogEntity(
    @PrimaryKey(autoGenerate = true)
    val LogID: Long = 0,
    val UserID: Int,
    val UserName: String,
    val ActionType: String, // تسجيل دخول ناجح، محاولة مرفوضة، نفاد الحصة، خارج ساعات الدوام
    val Timestamp: String,
    val IPAddress: String = "192.168.1.100",
    val DeviceName: String = "Android Mobile Terminal",
    val Status: String = "ناجح", // ناجح، مرفوض، تحذير
    val Details: String
)

/**
 * tbl_Roles - جدول الأدوار والصلاحيات
 */
@Entity(tableName = "tbl_Roles")
data class RoleEntity(
    @PrimaryKey
    val RoleID: Int,
    val RoleName: String,
    val Description: String,
    val IsActive: Boolean = true
)

/**
 * tbl_Localities - جدول المحليات
 */
@Entity(tableName = "tbl_Localities")
data class LocalityEntity(
    @PrimaryKey(autoGenerate = true)
    val LocalityID: Int = 0,
    val LocalityName: String,
    val IsActive: Boolean = true
)

/**
 * tbl_UserLocalities - ربط المستخدم بالمحليات المسموح له التعامل معها
 */
@Entity(tableName = "tbl_UserLocalities")
data class UserLocalityEntity(
    @PrimaryKey(autoGenerate = true)
    val UserLocalityID: Int = 0,
    val UserID: Int,
    val LocalityID: Int // 0 يعني كل المحليات
)

/**
 * ثوابت أسماء أعمدة وجدول الأسر (Family Table Constants) لمنع استخدام نصوص ثابتة ومكررة
 */
object FamilyTable {
    const val TABLE_NAME = "families"
    const val COL_FAMILY_ID = "familyID"
    const val COL_NATIONAL_ID = "nationalID"
    const val COL_NAME = "name"
    const val COL_GENDER = "gender"
    const val COL_DATE_OF_BIRTH = "date_of_birth"
    const val COL_MARITAL_STATUS = "maritalStatus"
    const val COL_DEATH_STATUS = "deathStatus"
    const val COL_DEATH_DATE = "deathDate"
    const val COL_PRIMARY_PHONE = "primary_phone"
    const val COL_ALTERNATIVE_PHONE_1 = "alternative_phone_1"
    const val COL_ALTERNATIVE_PHONE_2 = "alternative_phone_2"
    const val COL_WIFE_NAME = "wifeName"
    const val COL_WIFE_NATIONAL_ID = "wifeNationalID"
    const val COL_FAMILY_MEMBERS_COUNT = "familyMembersCount"
    const val COL_DAMAGE_TYPE = "damageType"
    const val COL_DAMAGE_DESCRIPTION = "damageDescription"
    const val COL_INJURY_STATUS = "injuryStatus"
    const val COL_INJURY_DATE = "injuryDate"
    const val COL_INCOME_SOURCE_1 = "incomeSource1"
    const val COL_INCOME_SOURCE_2 = "income_source_2"
    const val COL_RATION_CARD_NUMBER = "rationCardNumber"
    const val COL_ORIGINAL_MAIN_AREA = "originalMainArea"
    const val COL_ORIGINAL_SUB_AREA = "originalSubArea"
    const val COL_ORIGINAL_BRANCH = "originalBranch"
    const val COL_ORIGINAL_MOSQUE = "originalMosque"
    const val COL_CURRENT_MAIN_AREA = "currentMainArea"
    const val COL_CURRENT_SUB_AREA = "currentSubArea"
    const val COL_CURRENT_BRANCH = "currentBranch"
    const val COL_CURRENT_MOSQUE = "currentMosque"
    const val COL_DEVELOPMENT_APPROVAL = "developmentApproval"
    const val COL_LOCALITY_APPROVAL = "localityApproval"
    const val COL_RESIDENT_STATUS = "residentStatus"
    const val COL_WORKS_APPROVAL = "worksApproval"
    const val COL_SHELTER_STATUS = "shelterStatus"
    const val COL_SHELTER_CENTER_NAME = "shelter_center_name"
    const val COL_NOTES = "notes"
    const val COL_LOCALITY_ID = "localityID"
    const val COL_CREATED_DATE = "createdDate"
    const val COL_MODIFIED_DATE = "modifiedDate"
}

/**
 * دالة مساعدة لحساب العمر ديناميكياً بدقة من تاريخ الميلاد بدون تخزينه في قاعدة البيانات
 */
fun calculateAgeFromBirthDate(dobString: String?): Int {
    if (dobString.isNullOrBlank()) return 0
    return try {
        val parts = dobString.trim().split("-", "/")
        if (parts.size >= 3) {
            val year = parts[0].toIntOrNull() ?: return 0
            val month = parts[1].toIntOrNull() ?: 1
            val day = parts[2].toIntOrNull() ?: 1
            val birthCal = java.util.Calendar.getInstance().apply { set(year, month - 1, day) }
            val today = java.util.Calendar.getInstance()
            var calculatedAge = today.get(java.util.Calendar.YEAR) - birthCal.get(java.util.Calendar.YEAR)
            if (today.get(java.util.Calendar.DAY_OF_YEAR) < birthCal.get(java.util.Calendar.DAY_OF_YEAR)) {
                calculatedAge--
            }
            calculatedAge.coerceAtLeast(0)
        } else {
            0
        }
    } catch (_: Exception) {
        0
    }
}

/**
 * families - جدول بيانات المواطنين والأسر المعتمد رسمياً (36 حقلاً شاملاً)
 */
@Entity(
    tableName = FamilyTable.TABLE_NAME,
    indices = [
        Index(value = [FamilyTable.COL_NATIONAL_ID], unique = true),
        Index(value = [FamilyTable.COL_LOCALITY_ID]),
        Index(value = [FamilyTable.COL_DEVELOPMENT_APPROVAL]),
        Index(value = [FamilyTable.COL_RATION_CARD_NUMBER])
    ]
)
data class FamilyEntity(
    @PrimaryKey(autoGenerate = true)
    @androidx.room.ColumnInfo(name = FamilyTable.COL_FAMILY_ID)
    val familyID: Long = 0,
    // 1. رقم الهوية
    @androidx.room.ColumnInfo(name = FamilyTable.COL_NATIONAL_ID)
    val nationalID: String,
    // 2. الاسم رباعي
    @androidx.room.ColumnInfo(name = FamilyTable.COL_NAME)
    val name: String,
    // 3. الجنس (ذكر / أنثى)
    @androidx.room.ColumnInfo(name = FamilyTable.COL_GENDER)
    val gender: String = "ذكر",
    // 4. تاريخ الميلاد
    @androidx.room.ColumnInfo(name = FamilyTable.COL_DATE_OF_BIRTH)
    val date_of_birth: String = "1985-01-01",
    // 5. الحالة الاجتماعية (متزوج / أعزب / أرمل / مطلق)
    @androidx.room.ColumnInfo(name = FamilyTable.COL_MARITAL_STATUS)
    val maritalStatus: String = "متزوج",
    // 6. الوفاة (على قيد الحياة / متوفى)
    @androidx.room.ColumnInfo(name = FamilyTable.COL_DEATH_STATUS)
    val deathStatus: String = "على قيد الحياة",
    // 7. تاريخ الوفاة
    @androidx.room.ColumnInfo(name = FamilyTable.COL_DEATH_DATE)
    val deathDate: String? = null,
    // 8. جوال أساسي
    @androidx.room.ColumnInfo(name = FamilyTable.COL_PRIMARY_PHONE)
    val primary_phone: String = "",
    // 9. جوال بديل ١
    @androidx.room.ColumnInfo(name = FamilyTable.COL_ALTERNATIVE_PHONE_1)
    val alternative_phone_1: String? = null,
    // 10. جوال بديل ٢
    @androidx.room.ColumnInfo(name = FamilyTable.COL_ALTERNATIVE_PHONE_2)
    val alternative_phone_2: String? = null,

    // 👨‍👩‍👧 بيانات الأسرة
    // 11. اسم الزوج/الزوجة
    @androidx.room.ColumnInfo(name = FamilyTable.COL_WIFE_NAME)
    val wifeName: String? = null,
    // 12. هوية الزوج/الزوجة
    @androidx.room.ColumnInfo(name = FamilyTable.COL_WIFE_NATIONAL_ID)
    val wifeNationalID: String? = null,
    // 13. عدد أفراد الأسرة
    @androidx.room.ColumnInfo(name = FamilyTable.COL_FAMILY_MEMBERS_COUNT)
    val familyMembersCount: Int = 1,
    // 14. حالة الضرر (كلي، جزئي بليغ، جزئي غير صالح للسكن، جزئي صالح للسكن، لا يوجد)
    @androidx.room.ColumnInfo(name = FamilyTable.COL_DAMAGE_TYPE)
    val damageType: String = "أضرار كلية",
    // 15. وصف الضرر
    @androidx.room.ColumnInfo(name = FamilyTable.COL_DAMAGE_DESCRIPTION)
    val damageDescription: String? = null,
    // 16. حالة الإصابة (سليم، مصاب، مبتور، شهيد...)
    @androidx.room.ColumnInfo(name = FamilyTable.COL_INJURY_STATUS)
    val injuryStatus: String = "سليم",
    // 17. تاريخ الإصابة
    @androidx.room.ColumnInfo(name = FamilyTable.COL_INJURY_DATE)
    val injuryDate: String? = null,
    // 18. مصدر الدخل ١
    @androidx.room.ColumnInfo(name = FamilyTable.COL_INCOME_SOURCE_1)
    val incomeSource1: String = "بلا عمل",
    // 19. مصدر الدخل الأساسي 2
    @androidx.room.ColumnInfo(name = FamilyTable.COL_INCOME_SOURCE_2, defaultValue = "NULL")
    val income_source_2: String? = null,
    // 20. رقم كرت المؤن
    @androidx.room.ColumnInfo(name = FamilyTable.COL_RATION_CARD_NUMBER)
    val rationCardNumber: String? = null,

    // بيانات المناطق الأصلية
    // 21. المنطقة الرئيسية الأصلية
    @androidx.room.ColumnInfo(name = FamilyTable.COL_ORIGINAL_MAIN_AREA)
    val originalMainArea: String = "",
    // 22. المنطقة الفرعية الأصلية
    @androidx.room.ColumnInfo(name = FamilyTable.COL_ORIGINAL_SUB_AREA)
    val originalSubArea: String = "",
    // 23. الشعبة الأصلية
    @androidx.room.ColumnInfo(name = FamilyTable.COL_ORIGINAL_BRANCH)
    val originalBranch: String = "",
    // 24. المسجد الأصلي
    @androidx.room.ColumnInfo(name = FamilyTable.COL_ORIGINAL_MOSQUE)
    val originalMosque: String = "",

    // بيانات المناطق الحالية
    // 25. المنطقة الرئيسية الحالية
    @androidx.room.ColumnInfo(name = FamilyTable.COL_CURRENT_MAIN_AREA)
    val currentMainArea: String = "",
    // 26. المنطقة الفرعية الحالية
    @androidx.room.ColumnInfo(name = FamilyTable.COL_CURRENT_SUB_AREA)
    val currentSubArea: String = "",
    // 27. الشعبة الحالية
    @androidx.room.ColumnInfo(name = FamilyTable.COL_CURRENT_BRANCH)
    val currentBranch: String = "",
    // 28. المسجد الحالي
    @androidx.room.ColumnInfo(name = FamilyTable.COL_CURRENT_MOSQUE)
    val currentMosque: String = "",

    // حالات الاعتماد والإيواء
    // 29. حالة اعتماد التنمية: معتمد ، حجب اعتماد ، مجمد
    @androidx.room.ColumnInfo(name = FamilyTable.COL_DEVELOPMENT_APPROVAL)
    val developmentApproval: String = "معتمد",
    // 30. حالة اعتماد المناطق
    @androidx.room.ColumnInfo(name = FamilyTable.COL_LOCALITY_APPROVAL)
    val localityApproval: String = "معتمد",
    // 31. مقيم/نازح
    @androidx.room.ColumnInfo(name = FamilyTable.COL_RESIDENT_STATUS)
    val residentStatus: String = "مقيم",
    // 32. حالة اعتماد الأشغال: "اعتماد أشغال" أو فارغ أو ما يكتب في الحقل
    @androidx.room.ColumnInfo(name = FamilyTable.COL_WORKS_APPROVAL)
    val worksApproval: String = "اعتماد أشغال",
    // 33. حالة الإيواء: "إيواء داخلي" أو فارغ (يعني خارج الإيواء)
    @androidx.room.ColumnInfo(name = FamilyTable.COL_SHELTER_STATUS)
    val shelterStatus: String = "إيواء داخلي",
    // 34. اسم المخيم/ مركز الإيواء
    @androidx.room.ColumnInfo(name = FamilyTable.COL_SHELTER_CENTER_NAME, defaultValue = "NULL")
    val shelter_center_name: String? = null,
    // 35. ملاحظات
    @androidx.room.ColumnInfo(name = FamilyTable.COL_NOTES)
    val notes: String? = null,

    @androidx.room.ColumnInfo(name = FamilyTable.COL_LOCALITY_ID)
    val localityID: Int = 1,
    @androidx.room.ColumnInfo(name = FamilyTable.COL_CREATED_DATE)
    val createdDate: Long = System.currentTimeMillis(),
    @androidx.room.ColumnInfo(name = FamilyTable.COL_MODIFIED_DATE)
    val modifiedDate: Long? = null
) {
    // حساب العمر ديناميكياً بدون تخزينه في قاعدة البيانات
    @get:androidx.room.Ignore
    val age: Int get() = calculateAgeFromBirthDate(date_of_birth)
    @get:androidx.room.Ignore
    val birthDate: String get() = date_of_birth
    @get:androidx.room.Ignore
    val primaryPhone: String get() = primary_phone
    @get:androidx.room.Ignore
    val alternativePhone1: String? get() = alternative_phone_1
    @get:androidx.room.Ignore
    val alternativePhone2: String? get() = alternative_phone_2
    @get:androidx.room.Ignore
    val incomeSource2: String? get() = income_source_2
    @get:androidx.room.Ignore
    val campOrCenterName: String? get() = shelter_center_name

    // منشئ إضافي توافقي يقبل المعاملات القديمة لضمان استقرار البناء والتكامل البرمجي
    @androidx.room.Ignore
    constructor(
        familyID: Long = 0,
        nationalID: String,
        name: String,
        gender: String = "ذكر",
        birthDate: String = "1985-01-01",
        age: Int? = null,
        maritalStatus: String = "متزوج",
        deathStatus: String = "على قيد الحياة",
        deathDate: String? = null,
        primaryPhone: String = "",
        alternativePhone1: String? = null,
        alternativePhone2: String? = null,
        wifeName: String? = null,
        wifeNationalID: String? = null,
        familyMembersCount: Int = 1,
        damageType: String = "أضرار كلية",
        damageDescription: String? = null,
        injuryStatus: String = "سليم",
        injuryDate: String? = null,
        incomeSource1: String = "بلا عمل",
        incomeSource2: String? = null,
        rationCardNumber: String? = null,
        originalMainArea: String = "",
        originalSubArea: String = "",
        originalBranch: String = "",
        originalMosque: String = "",
        currentMainArea: String = "",
        currentSubArea: String = "",
        currentBranch: String = "",
        currentMosque: String = "",
        developmentApproval: String = "معتمد",
        localityApproval: String = "معتمد",
        residentStatus: String = "مقيم",
        worksApproval: String = "اعتماد أشغال",
        shelterStatus: String = "إيواء داخلي",
        campOrCenterName: String? = null,
        notes: String? = null,
        localityID: Int = 1,
        createdDate: Long = System.currentTimeMillis(),
        modifiedDate: Long? = null
    ) : this(
        familyID = familyID,
        nationalID = nationalID,
        name = name,
        gender = gender,
        date_of_birth = birthDate,
        maritalStatus = maritalStatus,
        deathStatus = deathStatus,
        deathDate = deathDate,
        primary_phone = primaryPhone,
        alternative_phone_1 = alternativePhone1,
        alternative_phone_2 = alternativePhone2,
        wifeName = wifeName,
        wifeNationalID = wifeNationalID,
        familyMembersCount = familyMembersCount,
        damageType = damageType,
        damageDescription = damageDescription,
        injuryStatus = injuryStatus,
        injuryDate = injuryDate,
        incomeSource1 = incomeSource1,
        income_source_2 = incomeSource2,
        rationCardNumber = rationCardNumber,
        originalMainArea = originalMainArea,
        originalSubArea = originalSubArea,
        originalBranch = originalBranch,
        originalMosque = originalMosque,
        currentMainArea = currentMainArea,
        currentSubArea = currentSubArea,
        currentBranch = currentBranch,
        currentMosque = currentMosque,
        developmentApproval = developmentApproval,
        localityApproval = localityApproval,
        residentStatus = residentStatus,
        worksApproval = worksApproval,
        shelterStatus = shelterStatus,
        shelter_center_name = campOrCenterName,
        notes = notes,
        localityID = localityID,
        createdDate = createdDate,
        modifiedDate = modifiedDate
    )
}

// خصائص مساعدة لتسهيل الوصول والتوافق البرمجي لبيانات الأسرة
val FamilyEntity.familyHeadName: String get() = name
val FamilyEntity.mobileNumber: String get() = primaryPhone
val FamilyEntity.originalAddress: String get() = listOf(originalMainArea, originalSubArea, originalBranch, originalMosque).filter { it.isNotBlank() }.joinToString(" - ").ifEmpty { "غير محدد" }
val FamilyEntity.addressDetails: String get() = currentSubArea
val FamilyEntity.benefitStatus: String get() = developmentApproval

/**
 * =========================================================================
 * أولاً: القاعدة الذهبية الصارمة (The Global Filter View):
 * EligibleFamiliesView - عرض قاعدة البيانات في Room للأسر المؤهلة حصراً
 * يحتوي حصراً على الأسر التي تحقق الشرطين معاً: (اعتماد التنمية = 'معتمد') وَ (صفة الإقامة = 'مقيم')
 * يُمنع منعاً باتاً قراءة الإحصائيات أو عرض التوزيع الجغرافي من الجدول الرئيسي مباشرة
 * =========================================================================
 */
@DatabaseView(
    viewName = "EligibleFamiliesView",
    value = """
        SELECT * FROM families 
        WHERE (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%') 
          AND (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%')
    """
)
data class EligibleFamiliesView(
    val familyID: Long = 0,
    val nationalID: String,
    val name: String,
    val gender: String = "ذكر",
    val date_of_birth: String = "1985-01-01",
    val maritalStatus: String = "متزوج",
    val deathStatus: String = "على قيد الحياة",
    val deathDate: String? = null,
    val primary_phone: String = "",
    val alternative_phone_1: String? = null,
    val alternative_phone_2: String? = null,
    val wifeName: String? = null,
    val wifeNationalID: String? = null,
    val familyMembersCount: Int = 1,
    val damageType: String = "أضرار كلية",
    val damageDescription: String? = null,
    val injuryStatus: String = "سليم",
    val injuryDate: String? = null,
    val incomeSource1: String = "بلا عمل",
    val income_source_2: String? = null,
    val rationCardNumber: String? = null,
    val originalMainArea: String = "",
    val originalSubArea: String = "",
    val originalBranch: String = "",
    val originalMosque: String = "",
    val currentMainArea: String = "",
    val currentSubArea: String = "",
    val currentBranch: String = "",
    val currentMosque: String = "",
    val developmentApproval: String = "معتمد",
    val localityApproval: String = "معتمد",
    val residentStatus: String = "مقيم",
    val worksApproval: String = "اعتماد أشغال",
    val shelterStatus: String = "إيواء داخلي",
    val shelter_center_name: String? = null,
    val notes: String? = null,
    val localityID: Int = 1,
    val createdDate: Long = System.currentTimeMillis(),
    val modifiedDate: Long? = null
)

// خصائص مساعدة ومحسوبة لـ EligibleFamiliesView بدون أي أعمدة إضافية في قاعدة البيانات لضمان توافق KSP
val EligibleFamiliesView.age: Int get() = calculateAgeFromBirthDate(date_of_birth)
val EligibleFamiliesView.birthDate: String get() = date_of_birth
val EligibleFamiliesView.primaryPhone: String get() = primary_phone
val EligibleFamiliesView.alternativePhone1: String? get() = alternative_phone_1
val EligibleFamiliesView.alternativePhone2: String? get() = alternative_phone_2
val EligibleFamiliesView.incomeSource2: String? get() = income_source_2
val EligibleFamiliesView.campOrCenterName: String? get() = shelter_center_name

// تحويل كائن العرض المؤهل إلى كائن الأسرة العادي لسهولة إعادة الاستخدام في الشاشات
fun EligibleFamiliesView.toFamilyEntity(): FamilyEntity = FamilyEntity(
    familyID = familyID,
    nationalID = nationalID,
    name = name,
    gender = gender,
    date_of_birth = date_of_birth,
    maritalStatus = maritalStatus,
    deathStatus = deathStatus,
    deathDate = deathDate,
    primary_phone = primary_phone,
    alternative_phone_1 = alternative_phone_1,
    alternative_phone_2 = alternative_phone_2,
    wifeName = wifeName,
    wifeNationalID = wifeNationalID,
    familyMembersCount = familyMembersCount,
    damageType = damageType,
    damageDescription = damageDescription,
    injuryStatus = injuryStatus,
    injuryDate = injuryDate,
    incomeSource1 = incomeSource1,
    income_source_2 = income_source_2,
    rationCardNumber = rationCardNumber,
    originalMainArea = originalMainArea,
    originalSubArea = originalSubArea,
    originalBranch = originalBranch,
    originalMosque = originalMosque,
    currentMainArea = currentMainArea,
    currentSubArea = currentSubArea,
    currentBranch = currentBranch,
    currentMosque = currentMosque,
    developmentApproval = developmentApproval,
    localityApproval = localityApproval,
    residentStatus = residentStatus,
    worksApproval = worksApproval,
    shelterStatus = shelterStatus,
    shelter_center_name = shelter_center_name,
    notes = notes,
    localityID = localityID,
    createdDate = createdDate,
    modifiedDate = modifiedDate
)

/**
 * نموذج الحصة والنسبة المئوية لكل محلية مستخرجة ديناميكياً بناءً على الـ View كالتالي:
 * (COUNT(المحلية) / إجمالي الأسر في EligibleFamiliesView) * 100
 */
data class LocalityQuotaShare(
    val localityId: Int,
    val localityName: String,
    val eligibleFamiliesCount: Int,
    val totalEligibleSystemWide: Int,
    val percentage: Double
) {
    val formattedPercentage: String get() = String.format(java.util.Locale.US, "%.2f%%", percentage)
}

/**
 * خيارات الفلاتر الديناميكية المستخرجة حصراً عبر SELECT DISTINCT من الجداول الحقيقية
 */
data class DynamicFilterOptions(
    val damageTypes: List<String> = emptyList(),
    val maritalStatuses: List<String> = emptyList(),
    val worksApprovals: List<String> = emptyList(),
    val shelterStatuses: List<String> = emptyList(),
    val incomeSources: List<String> = emptyList(),
    val injuryStatuses: List<String> = emptyList(),
    val subAreas: List<String> = emptyList(),
    val aidTypes: List<AidTypeEntity> = emptyList(),
    val localities: List<LocalityEntity> = emptyList()
)

/**
 * children - جدول الأطفال التابعين للأسرة
 */
@Entity(
    tableName = "children",
    indices = [
        Index(value = ["familyNationalID"]),
        Index(value = ["nationalID"])
    ]
)
data class ChildEntity(
    @PrimaryKey(autoGenerate = true)
    val childID: Long = 0,
    val nationalID: String,
    val childName: String,
    val birthDate: String,
    val gender: String,
    val familyNationalID: String,
    val localityID: Int,
    val shelterStatus: String = "إيواء داخلي"
)

/**
 * aid_types - أنواع المساعدات
 */
@Entity(tableName = "aid_types")
data class AidTypeEntity(
    @PrimaryKey
    val aidTypeID: Int,
    val aidTypeName: String,
    val description: String,
    val defaultExclusionDays: Int = 30, // فترة الاستثناء بالأيام
    val isActive: Boolean = true
)

// خاصية مساعدة لتسهيل الوصول والتوافق البرمجي لاسم المعونة
val AidTypeEntity.typeName: String get() = aidTypeName

/**
 * projects - المشاريع الإنسانية المنفذة
 */
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val projectID: Long = 0,
    val projectNumber: String,
    val projectName: String, // اسم المشروع المكتوب يدوياً
    val aidTypeID: Int,
    val detailedDescription: String,
    val projectDate: String, // تاريخ الترشيح
    val actualNominationDate: String? = null, // تاريخ الترشيح الفعلي مع الوقت
    val fundingInstitution: String, // الجهة الممولة
    val warehouseName: String = "المستودع الرئيسي", // المخزن المنفذ منه
    val aidValue: Double = 0.0, // قيمة المساعدات
    val stageUserName: String? = null, // اسم المستخدم لمراحل الترشيح
    val quantity: Int,
    val notes: String? = null, // ملاحظات الترشيح
    val isActive: Boolean = true
)

/**
 * aid_records - سجلات المساعدات الموزعة
 */
@Entity(
    tableName = "aid_records",
    indices = [
        Index(value = ["familyID"]),
        Index(value = ["aidTypeID"]),
        Index(value = ["projectID"]),
        Index(value = ["familyID", "projectID"], unique = true)
    ]
)
data class AidRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val aidRecordID: Long = 0,
    val familyID: Long,
    val aidTypeID: Int,
    val projectID: Long,
    val aidDate: String,
    val selectionDate: String, // تاريخ الترشيح
    val actualNominationDate: String? = null, // تاريخ الترشيح الفعلي
    val nominationMechanism: String = "آلي", // آلية الترشيح لكل شخص ("يدوي" أو "آلي")
    val stageUserName: String? = null, // اسم المستخدم لمراحل الترشيح
    val recipientStatus: String = "مرشح", // مرشح / مستفيد / مستلم
    val warehouse: String = "المستودع الرئيسي",
    val aidValue: Double = 0.0,
    val deliveryDate: String? = null,
    val deliveryTime: String? = null,
    val notes: String? = null // ملاحظات الترشيح
) {
    val actualDeliveryDate: String? @androidx.room.Ignore get() = deliveryDate
    val actualRecipientName: String? @androidx.room.Ignore get() = null

    // منشئ إضافي توافقي يقبل الحقول الميدانية
    constructor(
        aidRecordID: Long = 0,
        familyID: Long,
        aidTypeID: Int,
        projectID: Long,
        aidDate: String,
        selectionDate: String,
        warehouse: String = "المستودع الرئيسي",
        recipientStatus: String = "مرشح",
        actualDeliveryDate: String? = null,
        actualRecipientName: String? = null,
        aidValue: Double? = 0.0,
        notes: String? = null
    ) : this(
        aidRecordID = aidRecordID,
        familyID = familyID,
        aidTypeID = aidTypeID,
        projectID = projectID,
        aidDate = aidDate,
        selectionDate = selectionDate,
        warehouse = warehouse,
        recipientStatus = recipientStatus,
        aidValue = aidValue ?: 0.0,
        deliveryDate = actualDeliveryDate,
        notes = listOfNotNull(notes, actualRecipientName?.let { "المستلم الفعلي: $it" }).joinToString(" | ").ifEmpty { null }
    )
}

// خاصية مساعدة لتسهيل الوصول والتوافق البرمجي دون التأثير على أعمدة Room
val AidRecordEntity.recordID: Long get() = aidRecordID

/**
 * tbl_Manual_Selection - جدول الترشيح اليدوي
 */
@Entity(tableName = "tbl_Manual_Selection")
data class ManualSelectionEntity(
    @PrimaryKey(autoGenerate = true)
    val ID: Long = 0,
    val CitizenID: Long, // familyID
    val SelectionDate: String,
    val ActualNominationDate: String? = null,
    val UserID: Int,
    val StageUserName: String? = null,
    val AidTypeID: Int = 0,
    val ProjectID: Long = 0,
    val Notes: String? = null
)

/**
 * tbl_Selected_Citizens - جدول المواطنين المرشحين المعتمدين
 */
@Entity(
    tableName = "tbl_Selected_Citizens",
    indices = [
        Index(value = ["CitizenID", "AidTypeID", "ProjectID"])
    ]
)
data class SelectedCitizenEntity(
    @PrimaryKey(autoGenerate = true)
    val ID: Long = 0,
    val CitizenID: Long, // familyID
    val SelectionDate: String, // تاريخ الترشيح
    val ActualNominationDate: String? = null, // تاريخ الترشيح الفعلي
    val SelectionType: String, // آلية الترشيح: "يدوي" أو "آلي"
    val AidTypeID: Int,
    val ProjectID: Long,
    val UserID: Int,
    val StageUserName: String? = null, // اسم المستخدم لمراحل الترشيح
    val NominationNotes: String? = null // ملاحظات الترشيح
)

/**
 * locality_distribution - نسب وتوزيع المحليات
 */
@Entity(tableName = "locality_distribution")
data class LocalityDistributionEntity(
    @PrimaryKey(autoGenerate = true)
    val distributionID: Int = 0,
    val localityID: Int,
    val distributionPercentage: Double, // مثلاً 20.0 لـ 20%
    val distributionCount: Int,
    val isActive: Boolean = true
)

/**
 * system_settings - إعدادات فترات الاستثناء وشروط الترشيح
 */
@Entity(tableName = "system_settings")
data class SystemSettingEntity(
    @PrimaryKey
    val key: String,
    val value: String,
    val description: String
)

/**
 * sync_queue - طابور التزامن المحلي للعمل دون اتصال بالإنترنت (Offline-First Sync Queue)
 */
@Entity(tableName = "sync_queue")
data class SyncQueueEntity(
    @PrimaryKey(autoGenerate = true)
    val syncId: Long = 0,
    val entityType: String,      // "FAMILY", "AID_RECORD", "NOMINATION_SELECTION", "USER"
    val operation: String,       // "INSERT", "UPDATE", "DELETE"
    val recordId: String,        // المعرف المحلي للسجل
    val payloadJson: String,     // محتوى السجل بتنسيق JSON للمزامنة
    val createdAt: Long = System.currentTimeMillis(),
    val status: String = "PENDING", // "PENDING", "SYNCING", "SYNCED", "FAILED"
    val retryCount: Int = 0,
    val errorMessage: String? = null
)

/**
 * sync_log - سجل تاريخ عمليات التزامن التلقائي واليدوي
 */
@Entity(tableName = "sync_log")
data class SyncLogEntity(
    @PrimaryKey(autoGenerate = true)
    val logId: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val syncType: String,        // "AUTO_RECONNECT", "MANUAL", "PERIODIC_BACKGROUND"
    val itemsProcessed: Int,
    val itemsSucceeded: Int,
    val itemsFailed: Int,
    val status: String,          // "SUCCESS", "PARTIAL", "FAILED"
    val summary: String
)

/**
 * tbl_Audit_Logs - جدول سجل التعديلات والعمليات الخاص بكل مستخدم (Audit Log)
 * يقوم بتسجيل أي عملية إضافة أو تعديل أو حذف للبيانات مع الطابع الزمني
 */
@Entity(
    tableName = "tbl_Audit_Logs",
    indices = [
        Index(value = ["userId"]),
        Index(value = ["timestamp"]),
        Index(value = ["operationType"]),
        Index(value = ["targetTable"])
    ]
)
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val logId: Long = 0,
    val userId: Int = 1,
    val userName: String = "النظام",
    val userFullName: String = "",
    val operationType: String = "عملية", // "إضافة" (INSERT) | "تعديل" (UPDATE) | "حذف" (DELETE)
    val targetTable: String = "عام",   // "الأسر" | "المساعدات" | "الأطفال" | "المستخدمين"
    val recordId: String = "",      // معرّف السجل (مثل رقم الهوية أو رقم السجل)
    val description: String = "",   // تفاصيل العملية والتعديل المنفذ
    val timestamp: Long = System.currentTimeMillis(),
    val formattedDate: String = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(timestamp))
) {
    // منشئ إضافي توافقي يقبل (userId, action, targetTable, details)
    constructor(
        userId: Int,
        action: String,
        targetTable: String,
        details: String,
        timestamp: Long = System.currentTimeMillis()
    ) : this(
        userId = userId,
        userName = "مزامنة سحابية",
        userFullName = "Firebase Sync",
        operationType = action,
        targetTable = targetTable,
        recordId = "",
        description = details,
        timestamp = timestamp
    )

    val action: String @androidx.room.Ignore get() = operationType
    val details: String @androidx.room.Ignore get() = description
}

/**
 * tbl_Nomination_Workflows - مسارات وإجراءات الترشيح الديناميكي المعتمدة
 */
@Entity(
    tableName = "tbl_Nomination_Workflows",
    indices = [
        Index(value = ["projectId"]),
        Index(value = ["aidTypeId"]),
        Index(value = ["status"])
    ]
)
data class NominationWorkflowEntity(
    @PrimaryKey(autoGenerate = true)
    val workflowId: Long = 0,
    val projectId: Long,
    val aidTypeId: Int,
    val workflowTitle: String = "خطة الترشيح الميداني",
    val targetQuota: Int = 100,
    val approvedCount: Int = 0,
    val status: String = "ACTIVE", // ACTIVE, COMPLETED, CANCELLED
    val createdDate: Long = System.currentTimeMillis(),
    val notes: String? = null
)

/**
 * tbl_Project_Quotas - الحصص الجغرافية للمشاريع حسب المحليات
 */
@Entity(
    tableName = "tbl_Project_Quotas",
    indices = [
        Index(value = ["projectId", "localityId"], unique = true)
    ]
)
data class ProjectQuotaEntity(
    @PrimaryKey(autoGenerate = true)
    val quotaId: Long = 0,
    val projectId: Long,
    val localityId: Int,
    val localityName: String = "",
    val allocatedCount: Int = 0,
    val fulfilledCount: Int = 0,
    val quotaPercentage: Double = 0.0,
    val isActive: Boolean = true
)

// -------------------------------------------------------------
// أسماء بديلة وتوافقية تامة (Type Aliases) لمنع أخطاء KSP و Unresolved References
// -------------------------------------------------------------
typealias User = UserEntity
typealias Role = RoleEntity
typealias Locality = LocalityEntity
typealias UserLocality = UserLocalityEntity
typealias Family = FamilyEntity
typealias Child = ChildEntity
typealias AidType = AidTypeEntity
typealias Project = ProjectEntity
typealias AidRecord = AidRecordEntity
typealias Selection = SelectedCitizenEntity
typealias SelectedCitizen = SelectedCitizenEntity
typealias ManualSelection = ManualSelectionEntity
typealias LocalityDistribution = LocalityDistributionEntity
typealias SystemSetting = SystemSettingEntity
typealias AuditLog = AuditLogEntity
typealias NominationWorkflow = NominationWorkflowEntity
typealias ProjectQuota = ProjectQuotaEntity

/**
 * tbl_Delivery_Undo_Logs - سجل عمليات التراجع الصارمة عن تسليم المساعدات
 * يوثق رقم المشروع، وهوية الأسرة، ورقم السجل، وسبب التراجع الإلزامي، وهوية المنفذ والتوقيت
 */
@Entity(
    tableName = "tbl_Delivery_Undo_Logs",
    indices = [
        Index(value = ["projectID"]),
        Index(value = ["familyID"]),
        Index(value = ["aidRecordID"])
    ]
)
data class DeliveryUndoLogEntity(
    @PrimaryKey(autoGenerate = true)
    val logId: Long = 0,
    val projectID: Long,
    val familyID: Long,
    val aidRecordID: Long,
    val recipientName: String? = null,
    val undoReason: String,
    val undoByUserId: Int = 1,
    val undoByUserName: String = "مدير النظام",
    val timestamp: Long = System.currentTimeMillis(),
    val formattedDate: String = ""
)

typealias DeliveryUndoLog = DeliveryUndoLogEntity
