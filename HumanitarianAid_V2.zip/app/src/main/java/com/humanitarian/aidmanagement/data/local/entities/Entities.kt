package com.humanitarian.aidmanagement.data.local.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Roles table (الأدوار)
 * Initial roles: مدير النظام (1), مشرف (2), موظف (3), مستخدم (4)
 */
@Entity(tableName = "Roles")
data class Role(
    @PrimaryKey(autoGenerate = true)
    val roleId: Int = 0,
    val roleName: String,
    val isActive: Boolean = true
)

/**
 * Users table (المستخدمون)
 * Includes lockout counter, password hash, and active status.
 */
@Entity(
    tableName = "Users",
    indices = [Index(value = ["userName"], unique = true)]
)
data class User(
    @PrimaryKey(autoGenerate = true)
    val userId: Int = 0,
    val userName: String,
    val passwordHash: String,
    val fullName: String,
    val roleId: Int,
    val isActive: Boolean = true,
    val failedAttempts: Int = 0,
    val lastLogin: Long? = null,
    val mustChangePassword: Boolean = false,
    val createdDate: Long = System.currentTimeMillis(),
    val createdBy: Int? = null,
    val modifiedDate: Long = System.currentTimeMillis(),
    val modifiedBy: Int? = null,
    val lockedUntil: Long? = null
)

/**
 * Localities table (المحليات)
 * e.g., الرمال الشمالي, الشيخ رضوان, الشاطئ الشمالي والنصر, الشاطئ الجنوبي, مشروع عامر
 */
@Entity(tableName = "Localities")
data class Locality(
    @PrimaryKey(autoGenerate = true)
    val localityId: Int = 0,
    val localityName: String,
    val isActive: Boolean = true,
    val sortOrder: Int = 0
)

/**
 * User Localities table (نطاق المستخدم الجغرافي)
 * User can have 1, multiple, or all localities.
 */
@Entity(
    tableName = "UserLocalities",
    primaryKeys = ["userId", "localityId"],
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = Locality::class,
            parentColumns = ["localityId"],
            childColumns = ["localityId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("userId"), Index("localityId")]
)
data class UserLocality(
    val userId: Int,
    val localityId: Int
)

/**
 * Families table (بيانات الأسر)
 * Includes NationalID uniqueness, demographic, approval, and shelter status.
 */
@Entity(
    tableName = "Families",
    indices = [
        Index(value = ["nationalID"], unique = true),
        Index("localityID"),
        Index("residentStatus"),
        Index("shelterStatus")
    ]
)
data class Family(
    @PrimaryKey(autoGenerate = true)
    val familyID: Int = 0,
    val name: String,
    val nationalID: String,
    val birthDate: Long, // timestamp
    val gender: String, // ذكر / أنثى
    val maritalStatus: String, // متزوج / أعزب / أرمل / مطلق
    val familyMembersCount: Int,
    val wifeName: String? = null,
    val wifeNationalID: String? = null,
    val deathStatus: Boolean = false,
    val deathDate: Long? = null,
    val workplace1: String? = null,
    val workplace2: String? = null,
    val developmentApproval: String = "غير معتمد", // معتمد / غير معتمد / قيد المراجعة
    val localityApproval: String = "معتمد",
    val workApproval: String = "غير معتمد", // معتمد أشغال / غير معتمد
    val residentStatus: String = "مقيم", // مقيم / نازح
    val damageType: String = "كلي", // كلي / جزئي غير صالح / جزئي صالح / سليم
    val shelterStatus: String = "إيواء داخلي", // إيواء داخلي / إيواء خارجي / مستضاف / منزل
    val localityID: Int,
    val localityName: String? = null,
    val notes: String? = null,
    val createdDate: Long = System.currentTimeMillis(),
    val modifiedDate: Long = System.currentTimeMillis()
)

/**
 * Children table (أبناء الأسرة)
 * Unique ChildNationalID and linked to FamilyID.
 */
@Entity(
    tableName = "Children",
    indices = [
        Index(value = ["childNationalID"], unique = true),
        Index("familyID"),
        Index("localityID")
    ],
    foreignKeys = [
        ForeignKey(
            entity = Family::class,
            parentColumns = ["familyID"],
            childColumns = ["familyID"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class Child(
    @PrimaryKey(autoGenerate = true)
    val childID: Int = 0,
    val familyID: Int,
    val childNationalID: String,
    val childName: String,
    val birthDate: Long,
    val gender: String, // ذكر / أنثى
    val status: String = "أعزب",
    val shelterStatus: String = "إيواء داخلي",
    val localityID: Int
)

/**
 * Aid Types table (أنواع المساعدات)
 * 11 Standard Types in precise order.
 */
@Entity(tableName = "AidTypes")
data class AidType(
    @PrimaryKey(autoGenerate = true)
    val aidTypeID: Int = 0,
    val aidTypeName: String,
    val isActive: Boolean = true,
    val sortOrder: Int = 0
)

/**
 * Projects table (المشاريع الإنسانية)
 */
@Entity(tableName = "Projects")
data class Project(
    @PrimaryKey(autoGenerate = true)
    val projectID: Int = 0,
    val projectName: String,
    val projectNumber: String,
    val detailedDescription: String? = null,
    val fundingOrganization: String,
    val startDate: Long,
    val endDate: Long? = null,
    val isActive: Boolean = true
)

/**
 * Aid Records table (سجلات المساعدات المسلمة)
 */
@Entity(
    tableName = "AidRecords",
    indices = [
        Index("familyID"),
        Index("nationalID"),
        Index("aidTypeID"),
        Index("projectID"),
        Index("localityID"),
        Index("aidDate")
    ]
)
data class AidRecord(
    @PrimaryKey(autoGenerate = true)
    val aidRecordID: Int = 0,
    val familyID: Int,
    val nationalID: String,
    val aidTypeID: Int,
    val projectID: Int,
    val detailedDescription: String? = null,
    val aidDate: Long, // timestamp
    val fundingOrganization: String? = null,
    val candidateStatus: String = "مستفيد",
    val beneficiaryStatus: String = "مستلم",
    val warehouse: String? = null,
    val aidValue: Double = 0.0,
    val receivingDateTime: Long? = null,
    val receivingNotes: String? = null,
    val localityID: Int,
    val createdBy: Int,
    val createdDate: Long = System.currentTimeMillis()
)

/**
 * Selections table (سجلات الترشيح)
 * SelectionType: "يدوي" أو "آلي"
 */
@Entity(
    tableName = "Selections",
    indices = [
        Index("familyID"),
        Index("aidTypeID"),
        Index("projectID"),
        Index("localityID"),
        Index("selectionDate")
    ]
)
data class Selection(
    @PrimaryKey(autoGenerate = true)
    val selectionID: Int = 0,
    val familyID: Int,
    val nationalID: String,
    val aidTypeID: Int,
    val projectID: Int,
    val selectionDate: Long = System.currentTimeMillis(),
    val selectionType: String, // "يدوي" or "آلي"
    val localityID: Int,
    val selectedBy: Int
)
