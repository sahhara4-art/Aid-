package com.humanitarian.aidmanagement.engine

import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.Family
import com.humanitarian.aidmanagement.data.local.entities.Selection

data class CandidateEvaluation(
    val family: Family,
    val isEligible: Boolean,
    val rejectionReason: String? = null,
    val childrenCount: Int = 0,
    val priorityScore: Int = 0
)

data class ChildrenNominationCriteria(
    val minChildrenCount: Int = 1,
    val maxAgeInYears: Int = 18,
    val requiredShelterStatus: String? = null
)

class NominationEngine(private val database: AidDatabase) {

    /**
     * Runs automated nomination based on default humanitarian rules:
     * 1. DevelopmentApproval = "معتمد"
     * 2. ResidentStatus = "مقيم"
     * 3. WorkApproval = "معتمد أشغال"
     * 4. ShelterStatus = "إيواء داخلي"
     * 5. User locality scope enforcement
     * 6. Duplicate prevention across AidRecords and Selections
     */
    suspend fun runAutoNomination(
        localityId: Int?,
        aidTypeId: Int,
        projectId: Int,
        requiredCount: Int,
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        userId: Int
    ): List<CandidateEvaluation> {
        // Enforce locality scope
        if (!isSuperAdmin && localityId != null && !allowedLocalityIds.contains(localityId)) {
            throw SecurityException("لا تملك صلاحية الوصول إلى هذه المحلية المحددة.")
        }

        // Fetch candidate pool
        val candidatePool = database.familyDao().getCandidatesForAutoNomination(
            isSuperAdmin = isSuperAdmin,
            allowedLocalityIds = allowedLocalityIds,
            localityId = localityId
        )

        val results = mutableListOf<CandidateEvaluation>()
        val acceptedList = mutableListOf<Selection>()

        for (family in candidatePool) {
            // Check previous aid receipt of same type
            val alreadyReceived = database.aidRecordDao().countAidByFamilyAndType(family.familyID, aidTypeId) > 0
            if (alreadyReceived) {
                results.add(
                    CandidateEvaluation(
                        family = family,
                        isEligible = false,
                        rejectionReason = "سبق للأسرة استلام مساعدة من نفس النوع ($aidTypeId) مسبقاً."
                    )
                )
                continue
            }

            // Check if already nominated
            val alreadySelected = database.selectionDao().countSelectionByFamilyAndType(family.familyID, aidTypeId) > 0
            if (alreadySelected) {
                results.add(
                    CandidateEvaluation(
                        family = family,
                        isEligible = false,
                        rejectionReason = "الأسرة مدرجة بالفعل في قوائم الترشيح الحالية لهذا النوع."
                    )
                )
                continue
            }

            val childrenCount = database.childDao().getChildrenCountForFamily(family.familyID)
            val score = family.familyMembersCount * 2 + childrenCount * 3

            results.add(
                CandidateEvaluation(
                    family = family,
                    isEligible = true,
                    rejectionReason = null,
                    childrenCount = childrenCount,
                    priorityScore = score
                )
            )
        }

        // Sort accepted candidates by priority (highest member count & children first)
        val eligible = results.filter { it.isEligible }.sortedByDescending { it.priorityScore }.take(requiredCount)

        return results
    }

    /**
     * Nomination based on children demographics (count, ages, shelter)
     */
    suspend fun runChildrenBasedNomination(
        localityId: Int?,
        aidTypeId: Int,
        projectId: Int,
        criteria: ChildrenNominationCriteria,
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>
    ): List<CandidateEvaluation> {
        val now = System.currentTimeMillis()
        val maxAgeMillis = criteria.maxAgeInYears * 365.25 * 24 * 3600 * 1000

        val candidatePool = database.familyDao().getCandidatesForAutoNomination(
            isSuperAdmin = isSuperAdmin,
            allowedLocalityIds = allowedLocalityIds,
            localityId = localityId
        )

        val results = mutableListOf<CandidateEvaluation>()

        for (family in candidatePool) {
            // Check duplicates
            val received = database.aidRecordDao().countAidByFamilyAndType(family.familyID, aidTypeId) > 0
            if (received) {
                results.add(CandidateEvaluation(family, false, "مستبعدة: استلمت مساعدة سابقة من نفس النوع"))
                continue
            }

            // Children criteria inspection
            val childrenFlow = database.childDao().getChildrenCountForFamily(family.familyID)
            if (childrenFlow < criteria.minChildrenCount) {
                results.add(CandidateEvaluation(family, false, "مستبعدة: عدد الأبناء أقل من الحد المطلوب (${criteria.minChildrenCount})"))
                continue
            }

            results.add(
                CandidateEvaluation(
                    family = family,
                    isEligible = true,
                    childrenCount = childrenFlow,
                    priorityScore = childrenFlow * 5 + family.familyMembersCount
                )
            )
        }

        return results.sortedWith(compareByDescending<CandidateEvaluation> { it.isEligible }.thenByDescending { it.priorityScore })
    }

    /**
     * Migrates (ترحيل) selected candidates to AidRecords upon delivery/confirmation
     */
    suspend fun migrateSelectionsToAidRecords(
        selections: List<Selection>,
        warehouse: String,
        aidValue: Double,
        currentUserId: Int
    ) {
        val aidRecords = selections.map { sel ->
            com.humanitarian.aidmanagement.data.local.entities.AidRecord(
                familyID = sel.familyID,
                nationalID = sel.nationalID,
                aidTypeID = sel.aidTypeID,
                projectID = sel.projectID,
                detailedDescription = "تم الترحيل من الترشيح (${sel.selectionType})",
                aidDate = System.currentTimeMillis(),
                fundingOrganization = null,
                candidateStatus = "مستفيد معتمد",
                beneficiaryStatus = "مستلم",
                warehouse = warehouse,
                aidValue = aidValue,
                receivingDateTime = System.currentTimeMillis(),
                localityID = sel.localityID,
                createdBy = currentUserId
            )
        }
        database.aidRecordDao().insertAidRecords(aidRecords)
        database.selectionDao().deleteSelections(selections.map { it.selectionID })
    }
}
