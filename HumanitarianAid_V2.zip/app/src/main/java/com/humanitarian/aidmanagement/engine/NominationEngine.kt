package com.humanitarian.aidmanagement.engine

import com.humanitarian.aidmanagement.data.local.dao.*
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityDistributionEntity
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.floor

data class NominationCriteria(
    val developmentApprovalRequired: Boolean = true, // معتمد تنمية بشكل دائم
    val requireChildren: Boolean = false, // اشتراط وجود أطفال
    val maxChildAge: Int? = null, // تحديد عمر الطفل (إن وجد)
    val shelterStatus: String? = null, // حالة الإيواء
    val worksApproval: String? = null, // اعتماد الأشغال
    val damageType: String? = null, // حالة الضرر
    val minFamilyMembers: Int = 1, // الحد الأدنى لعدد أفراد الأسرة
    val exclusionMode: String = "DAYS", // "DAYS" أو "DATE"
    val exclusionDays: Int = 30, // فترة الاستثناء بالأيام
    val exclusionDateCutoff: String? = null, // تاريخ استثناء محدد يكتبه المستخدم (YYYY-MM-DD)
    val aidTypeIds: List<Int> = listOf(1) // قائمة التصنيفات المفحوصة والمستثناة
)

data class CategoryBenefitHistory(
    val categoryId: Int,
    val categoryName: String,
    val lastDate: String?, // تاريخ آخر استفادة أو null
    val detail: String? = null
)

data class ProjectDispatchInfo(
    val targetAidTypeId: Int, // أي تصنيف يتم ترحيله إليه
    val projectNumber: String, // رقم المشروع
    val nominationDate: String, // تاريخ الترشيح وهو تاريخ اليوم
    val aidTypeName: String, // نوع المساعدة
    val fundingOrganization: String, // المؤسسة الممولة
    val warehouseName: String, // المخزن
    val aidValue: String // قيمة المساعدة
)

data class NominationCandidate(
    val family: FamilyEntity,
    val selectionType: String, // "يدوي" أو "آلي"
    val childrenCount: Int = 0,
    val priorityScore: Double = 0.0,
    val lastAidDate: String? = null,
    val categoryHistories: List<CategoryBenefitHistory> = emptyList()
)

data class LocalityQuota(
    val localityId: Int,
    val localityName: String,
    val percentage: Double,
    val allocatedCount: Int
)

class NominationEngine(
    private val familyDao: FamilyDao,
    private val childDao: ChildDao,
    private val aidRecordDao: AidRecordDao,
    private val nominationDao: NominationDao,
    private val localityDao: LocalityDao,
    private val systemSettingDao: SystemSettingDao,
    private val aidTypeDao: AidTypeDao? = null
) {
    constructor(database: com.humanitarian.aidmanagement.data.local.AidDatabase) : this(
        familyDao = database.familyDao(),
        childDao = database.childDao(),
        aidRecordDao = database.aidRecordDao(),
        nominationDao = database.nominationDao(),
        localityDao = database.localityDao(),
        systemSettingDao = database.systemSettingDao(),
        aidTypeDao = database.aidTypeDao()
    )

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    /**
     * حساب حصص المحليات باستخدام خوارزمية أكبر الكسور المتبقية (Largest Remainder Method)
     */
    fun calculateLocalityQuotas(
        totalRequired: Int,
        distributions: List<LocalityDistributionEntity>,
        localitiesMap: Map<Int, String>
    ): List<LocalityQuota> {
        if (distributions.isEmpty() || totalRequired <= 0) return emptyList()

        val totalPercentage = distributions.sumOf { it.distributionPercentage }
        val normalizedList = distributions.map { dist ->
            val effectivePercent = if (totalPercentage > 0) (dist.distributionPercentage / totalPercentage) * 100.0 else 0.0
            val exactFloatShare = (effectivePercent / 100.0) * totalRequired
            val floorShare = floor(exactFloatShare).toInt()
            val remainder = exactFloatShare - floorShare
            dist to Pair(floorShare, remainder)
        }

        var assignedTotal = normalizedList.sumOf { it.second.first }
        var deficit = totalRequired - assignedTotal

        val sortedByRemainder = normalizedList.sortedByDescending { it.second.second }.toMutableList()
        val finalAllocations = mutableMapOf<Int, Int>()
        for (item in sortedByRemainder) {
            val dist = item.first
            var share = item.second.first
            if (deficit > 0) {
                share += 1
                deficit -= 1
            }
            finalAllocations[dist.localityID] = share
        }

        return distributions.map { dist ->
            LocalityQuota(
                localityId = dist.localityID,
                localityName = localitiesMap[dist.localityID] ?: "محلية #${dist.localityID}",
                percentage = dist.distributionPercentage,
                allocatedCount = finalAllocations[dist.localityID] ?: 0
            )
        }
    }

    /**
     * استخراج سجل الاستفادة من التصنيفات الفعلية في قاعدة البيانات وتاريخ آخر استفادة لكل تصنيف
     */
    private suspend fun buildCategoryHistories(familyId: Long): List<CategoryBenefitHistory> {
        val activeTypes = aidTypeDao?.getAllActiveAidTypesSync() ?: emptyList()
        if (activeTypes.isEmpty()) return emptyList()
        return activeTypes.mapNotNull { type ->
            val latest = aidRecordDao.getLatestAidForFamilyAndType(familyId, type.aidTypeID)
            if (latest != null) {
                val dateStr = latest.deliveryDate ?: latest.aidDate
                CategoryBenefitHistory(
                    categoryId = type.aidTypeID,
                    categoryName = type.aidTypeName,
                    lastDate = dateStr,
                    detail = latest.notes
                )
            } else null
        }
    }

    /**
     * تنفيذ الترشيح المتكامل بناءً على معايير المستخدم وفترة الاستثناء وشاشة الترحيل
     */
    suspend fun executeCriteriaNomination(
        localityId: Int?,
        criteria: NominationCriteria,
        projectId: Long,
        requiredCount: Int,
        userId: Int,
        allowedLocalityIds: List<Int>,
        regionalQuotaCap: Int? = null
    ): List<NominationCandidate> {
        val acm = com.humanitarian.aidmanagement.security.AccessControlManager
        val isRestricted = acm.isGeoRestrictedUser()
        val effectiveCap = if (regionalQuotaCap != null) {
            if (isRestricted && requiredCount > regionalQuotaCap) {
                throw IllegalStateException(
                    "تجاوز الحصة الإقليمية: العدد المطلوب ($requiredCount) يتجاوز المتبقي المخصص لمنطقتك ($regionalQuotaCap)."
                )
            }
            minOf(requiredCount, regionalQuotaCap).coerceAtLeast(0)
        } else {
            requiredCount.coerceAtLeast(0)
        }

        val results = mutableListOf<NominationCandidate>()
        val selectedFamilyIds = mutableSetOf<Long>()
        if (projectId > 0) {
            selectedFamilyIds.addAll(aidRecordDao.getNominatedFamilyIdsForProjectSync(projectId))
        }

        // 1. جلب الاختيارات اليدوية أولاً للتصنيفات المحددة
        for (aidId in criteria.aidTypeIds) {
            val manualSelections = nominationDao.getManualSelections(aidId, projectId)
            for (manual in manualSelections) {
                val family = familyDao.getFamilyById(manual.CitizenID) ?: continue
                if (allowedLocalityIds.isNotEmpty() && !allowedLocalityIds.contains(0) && !allowedLocalityIds.contains(family.localityID)) {
                    continue
                }

                if (!selectedFamilyIds.contains(family.familyID)) {
                    val childrenCount = childDao.getChildrenCountForFamily(family.nationalID)
                    val histories = buildCategoryHistories(family.familyID)
                    results.add(
                        NominationCandidate(
                            family = family,
                            selectionType = "يدوي",
                            childrenCount = childrenCount,
                            priorityScore = 9999.0,
                            categoryHistories = histories
                        )
                    )
                    selectedFamilyIds.add(family.familyID)
                }
            }
        }

        if (results.size >= effectiveCap) {
            return results.take(effectiveCap)
        }

        // 2. إكمال المتبقي بالترشيح الآلي مع تطبيق شروط الاستثناء والمعايير المخصصة والسقف الإقليمي
        val remainingCount = (effectiveCap - results.size).coerceAtLeast(0)
        val autoSelected = nominateWithCriteriaAutomatically(
            localityId = localityId,
            criteria = criteria,
            requiredCount = remainingCount,
            excludedFamilyIds = selectedFamilyIds,
            allowedLocalityIds = allowedLocalityIds,
            projectId = projectId,
            regionalLimit = regionalQuotaCap ?: remainingCount
        )

        results.addAll(autoSelected)
        return results.take(effectiveCap)
    }

    suspend fun nominateWithCriteriaAutomatically(
        localityId: Int?,
        criteria: NominationCriteria,
        requiredCount: Int,
        excludedFamilyIds: Set<Long> = emptySet(),
        allowedLocalityIds: List<Int> = emptyList(),
        projectId: Long = 0L,
        regionalLimit: Int = -1
    ): List<NominationCandidate> {
        if (requiredCount <= 0 || criteria.aidTypeIds.isEmpty()) return emptyList()

        val acm = com.humanitarian.aidmanagement.security.AccessControlManager
        val isRestricted = acm.isGeoRestrictedUser()
        val allowedLocs = acm.getCleanAllowedLocalities().ifEmpty { listOf("__ALL__") }
        val ignoreLocs = if (isRestricted && allowedLocs.any { it != "__ALL__" }) 0 else 1
        val allowedBrs = acm.getCleanAllowedBranches().ifEmpty { listOf("__ALL__") }
        val ignoreBrs = if (isRestricted && allowedBrs.any { it != "__ALL__" }) 0 else 1
        val effectiveSqlLimit = when {
            regionalLimit >= 0 -> minOf(requiredCount, regionalLimit)
            isRestricted -> requiredCount
            else -> -1
        }

        val candidateFamilies = if (projectId > 0) {
            familyDao.getEligibleFamiliesForProjectNomination(
                localityId = localityId,
                projectId = projectId,
                ignoreAllowedLocalities = ignoreLocs,
                allowedLocalities = allowedLocs,
                ignoreAllowedBranches = ignoreBrs,
                allowedBranches = allowedBrs,
                regionalLimit = effectiveSqlLimit
            )
        } else {
            familyDao.getEligibleFamiliesForNomination(
                localityId = localityId,
                ignoreAllowedLocalities = ignoreLocs,
                allowedLocalities = allowedLocs,
                ignoreAllowedBranches = ignoreBrs,
                allowedBranches = allowedBrs,
                regionalLimit = effectiveSqlLimit
            )
        }
        val scoredCandidates = mutableListOf<NominationCandidate>()
        val currentTime = System.currentTimeMillis()

        for (family in candidateFamilies) {
            if (excludedFamilyIds.contains(family.familyID)) continue
            if (projectId > 0 && aidRecordDao.isFamilyAlreadyNominatedForProject(family.familyID, projectId)) continue

            if (allowedLocalityIds.isNotEmpty() && !allowedLocalityIds.contains(0) && !allowedLocalityIds.contains(family.localityID)) {
                continue
            }

            // الشرط 1: اعتماد التنمية بشكل دائم وإلزامي
            if (family.developmentApproval != "معتمد") continue

            // الشرط 2: حالة الإيواء
            if (!criteria.shelterStatus.isNullOrEmpty() && criteria.shelterStatus != "الكل") {
                if (family.shelterStatus != criteria.shelterStatus) continue
            }

            // الشرط 3: اعتماد الأشغال
            if (!criteria.worksApproval.isNullOrEmpty() && criteria.worksApproval != "الكل") {
                if (family.worksApproval != criteria.worksApproval) continue
            }

            // الشرط 4: حالة الضرر
            if (!criteria.damageType.isNullOrEmpty() && criteria.damageType != "الكل") {
                if (family.damageType != criteria.damageType) continue
            }

            // الشرط 5: الحد الأدنى لعدد أفراد الأسرة
            if (family.familyMembersCount < criteria.minFamilyMembers) continue

            // الشرط 6: الأطفال وعمر الطفل
            val childrenCount = childDao.getChildrenCountForFamily(family.nationalID)
            if (criteria.requireChildren) {
                if (childrenCount == 0) continue
                // إذا حدد عمر الطفل، يتم التحقق أن لدى الأسرة أطفال ضمن العمر المحدد
                // إذا لم يختر عمر الابن، يعتبر شرط وجود أطفال محققاً بدون فحص العمر
            }

            // الشرط 7: فحص الاستثناء لجميع التصنيفات المختارة
            var isExcluded = false
            var minDaysSinceLastAid = 9999L
            var lastAidRecordDate: String? = null

            for (aidTypeId in criteria.aidTypeIds) {
                val latestAid = aidRecordDao.getLatestAidForFamilyAndType(family.familyID, aidTypeId)
                if (latestAid != null) {
                    try {
                        val dateStr = latestAid.deliveryDate ?: latestAid.aidDate
                        if (criteria.exclusionMode == "DATE" && !criteria.exclusionDateCutoff.isNullOrEmpty()) {
                            // الاستثناء بتاريخ يكتبه بنفسه (في أو بعد التاريخ المحدد)
                            if (dateStr >= criteria.exclusionDateCutoff) {
                                isExcluded = true
                                break
                            }
                        } else {
                            // الاستثناء بالأيام
                            val recordDate = dateFormat.parse(dateStr)
                            if (recordDate != null) {
                                val diffMillis = currentTime - recordDate.time
                                val days = TimeUnit.MILLISECONDS.toDays(diffMillis)
                                if (days < minDaysSinceLastAid) {
                                    minDaysSinceLastAid = days
                                    lastAidRecordDate = dateStr
                                }
                                if (days < criteria.exclusionDays) {
                                    isExcluded = true
                                    break
                                }
                            }
                        }
                    } catch (_: Exception) {}
                }
            }

            if (isExcluded) continue

            val familySizeWeight = family.familyMembersCount * 10.0
            val childrenWeight = childrenCount * 5.0
            val damageWeight = if (family.damageType == "أضرار كلية") 20.0 else 10.0
            val timeElapsedWeight = (minDaysSinceLastAid.coerceAtMost(365) / 365.0) * 15.0
            val totalScore = familySizeWeight + childrenWeight + damageWeight + timeElapsedWeight

            val histories = buildCategoryHistories(family.familyID)
            scoredCandidates.add(
                NominationCandidate(
                    family = family,
                    selectionType = "آلي",
                    childrenCount = childrenCount,
                    priorityScore = totalScore,
                    lastAidDate = lastAidRecordDate,
                    categoryHistories = histories
                )
            )
        }

        return scoredCandidates
            .sortedByDescending { it.priorityScore }
            .take(requiredCount)
    }

    // توافق مع الاستدعاء القديم
    suspend fun executeFullNomination(
        localityId: Int?,
        aidTypeIds: List<Int>,
        projectId: Long,
        requiredCount: Int,
        userId: Int,
        allowedLocalityIds: List<Int>,
        customExclusionDays: Int = 30
    ): List<NominationCandidate> {
        val criteria = NominationCriteria(
            aidTypeIds = aidTypeIds,
            exclusionDays = customExclusionDays
        )
        return executeCriteriaNomination(localityId, criteria, projectId, requiredCount, userId, allowedLocalityIds)
    }

    suspend fun executeFullNomination(
        localityId: Int?,
        aidTypeId: Int,
        projectId: Long,
        requiredCount: Int,
        userId: Int,
        allowedLocalityIds: List<Int>
    ): List<NominationCandidate> {
        return executeFullNomination(
            localityId = localityId,
            aidTypeIds = listOf(aidTypeId),
            projectId = projectId,
            requiredCount = requiredCount,
            userId = userId,
            allowedLocalityIds = allowedLocalityIds,
            customExclusionDays = 30
        )
    }
}
