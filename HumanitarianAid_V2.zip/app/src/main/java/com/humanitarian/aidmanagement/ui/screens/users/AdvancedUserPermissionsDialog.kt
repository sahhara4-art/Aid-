package com.humanitarian.aidmanagement.ui.screens.users

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddCircle
import androidx.compose.material.icons.rounded.AlternateEmail
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.HourglassBottom
import androidx.compose.material.icons.rounded.LocalShipping
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Login
import androidx.compose.material.icons.rounded.ManageAccounts
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.AidApplication
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.RoleEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.theme.AmberWarning
import com.humanitarian.aidmanagement.ui.theme.EmeraldSuccess
import com.humanitarian.aidmanagement.ui.theme.PalestineGreen
import com.humanitarian.aidmanagement.ui.theme.PalestineGreenDark
import com.humanitarian.aidmanagement.ui.theme.RoseDanger
import com.humanitarian.aidmanagement.ui.theme.SkyBlue
import com.humanitarian.aidmanagement.ui.theme.SlateTextPrimary
import com.humanitarian.aidmanagement.ui.theme.SlateTextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.ceil

enum class PermissionDialogTab(val title: String, val icon: ImageVector) {
    TIME_RESTRICTIONS("القيود الزمنية", Icons.Rounded.Schedule),
    GEOGRAPHIC_SCOPE("النطاق الجغرافي", Icons.Rounded.Map),
    SCREEN_ACCESS("الوصول للشاشات", Icons.Rounded.DesktopWindows),
    ACTION_PERMISSIONS("صلاحيات العمليات", Icons.Rounded.Bolt)
}

private const val MILLIS_PER_DAY = 24L * 60L * 60L * 1000L

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AdvancedUserPermissionsDialog(
    user: UserEntity?, // null = إضافة مستخدم جديد, non-null = تعديل مستخدم قائم
    roles: List<RoleEntity>,
    localities: List<LocalityEntity>,
    groups: List<String>,
    onDismiss: () -> Unit,
    onSave: (UserEntity) -> Unit
) {
    val isEditMode = user != null
    var activeTab by remember { mutableStateOf(PermissionDialogTab.TIME_RESTRICTIONS) }
    // عند التعديل تُطوى بطاقة الهوية مبدئياً لإعطاء مساحة واسعة لتبويبات الصلاحيات، وتُفتح بضغطة واحدة
    var isAccountSectionExpanded by remember { mutableStateOf(!isEditMode) }
    var validationError by remember { mutableStateOf<String?>(null) }

    // الحقول الأساسية
    var username by remember { mutableStateOf(user?.UserName ?: "") }
    var password by remember { mutableStateOf(user?.PasswordHash ?: "") }
    var fullName by remember { mutableStateOf(user?.fullName ?: "") }
    var selectedRoleId by remember { mutableStateOf(user?.RoleID ?: (roles.firstOrNull()?.RoleID ?: 2)) }
    var isActive by remember { mutableStateOf(user?.IsActive ?: true) }

    // Tab 1: القيود الزمنية ومرات الدخول
    var accountExpiryTimestamp by remember { mutableStateOf(user?.accountExpiryDate ?: 0L) }
    var maxLogins by remember { mutableStateOf(user?.maxLogins ?: 0) }
    var currentLogins by remember { mutableStateOf(user?.currentLogins ?: 0) }

    // الوصول إلى Repository لجلب المحليات المعتمدة والمناطق الفرعية الحقيقية من قاعدة البيانات حصراً
    val context = LocalContext.current
    val repository = remember(context) {
        (context.applicationContext as? AidApplication)?.repository
    }

    val dbDistinctLocalities by (
        repository?.getDistinctLocalities() ?: remember { flowOf(emptyList()) }
    ).collectAsStateWithLifecycle(initialValue = emptyList())

    // المحليات المعتمدة حصراً من tbl_Localities ومن سجل الأسر في قاعدة البيانات (بدون أي قيم ثابتة وهمية)
    val approvedLocalities = remember(localities, dbDistinctLocalities) {
        (localities.filter { it.IsActive }.map { it.LocalityName.trim() } +
            dbDistinctLocalities.map { it.trim() })
            .filter { it.isNotBlank() && it != "*" && it != "الكل" }
            .distinct()
            .sorted()
    }

    var allowedLocalitiesSet by remember {
        mutableStateOf(
            user?.allowedLocalities
                ?.map { it.trim() }
                ?.filter { it.isNotBlank() && it != "*" && it != "الكل" }
                ?.toMutableSet() ?: mutableSetOf()
        )
    }

    var allowedBranchesSet by remember {
        mutableStateOf(
            user?.allowedBranches
                ?.map { it.trim() }
                ?.filter { it.isNotBlank() && it != "*" && it != "الكل" }
                ?.toMutableSet() ?: mutableSetOf()
        )
    }

    // جلب الشعب/المناطق الفرعية المعتمدة ديناميكياً من قاعدة البيانات حسب المحليات المختارة
    var approvedBranches by remember { mutableStateOf<List<String>>(emptyList()) }
    var isLoadingBranches by remember { mutableStateOf(false) }

    LaunchedEffect(allowedLocalitiesSet, repository) {
        if (repository == null) {
            approvedBranches = emptyList()
            isLoadingBranches = false
            return@LaunchedEffect
        }
        isLoadingBranches = true
        approvedBranches = withContext(Dispatchers.IO) {
            if (allowedLocalitiesSet.isEmpty()) {
                repository.getAllDistinctBranches()
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .distinct()
                    .sorted()
            } else {
                allowedLocalitiesSet
                    .flatMap { loc -> repository.getDistinctBranchesForLocality(loc) }
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .distinct()
                    .sorted()
            }
        }
        isLoadingBranches = false
    }

    // Tab 3: الوصول للشاشات
    var screenPermissionsSet by remember {
        mutableStateOf(
            if (user != null) {
                user.screenPermissions.toMutableSet().ifEmpty {
                    user.AllowedScreens.split(",").map { it.trim().lowercase() }.filter { it.isNotBlank() }.toMutableSet()
                }
            } else {
                mutableSetOf("dashboard", "families", "nomination", "delivery", "reports")
            }
        )
    }

    // Tab 4: صلاحيات العمليات الدقيقة
    var actionPermissionsSet by remember {
        mutableStateOf(
            if (user != null) {
                user.actionPermissions.toMutableSet()
            } else {
                mutableSetOf(
                    AccessControlManager.ACTION_ADD,
                    AccessControlManager.ACTION_EDIT,
                    AccessControlManager.ACTION_EXPORT
                )
            }
        )
    }

    val selectedRoleName = roles.firstOrNull { it.RoleID == selectedRoleId }?.RoleName ?: "مستخدم"

    val isDark = isSystemInDarkTheme()
    val dialogGlassColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.90f) else Color.White.copy(alpha = 0.88f)
    val dialogGlassBorder = if (isDark) Color.White.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.60f)
    val innerGlassCardColor = if (isDark) Color(0xFF1E293B).copy(alpha = 0.72f) else Color.White.copy(alpha = 0.74f)
    val innerGlassBorder = if (isDark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.85f)
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else SlateTextPrimary
    val textSecondary = if (isDark) Color(0xFFCBD5E1) else SlateTextSecondary
    val subtleDividerColor = if (isDark) Color.White.copy(alpha = 0.12f) else Color(0xFFE2E8F0).copy(alpha = 0.85f)

    val activeBannerBg by animateColorAsState(
        targetValue = if (isActive) {
            if (isDark) EmeraldSuccess.copy(alpha = 0.20f) else Color(0xFFECFDF5).copy(alpha = 0.92f)
        } else {
            if (isDark) RoseDanger.copy(alpha = 0.20f) else Color(0xFFFEF2F2).copy(alpha = 0.92f)
        },
        animationSpec = tween(300),
        label = "ActiveBannerBg"
    )
    val activeBannerBorder by animateColorAsState(
        targetValue = if (isActive) EmeraldSuccess.copy(alpha = 0.45f) else RoseDanger.copy(alpha = 0.45f),
        animationSpec = tween(300),
        label = "ActiveBannerBorder"
    )
    val activeStatusColor by animateColorAsState(
        targetValue = if (isActive) EmeraldSuccess else RoseDanger,
        animationSpec = tween(300),
        label = "ActiveStatusColor"
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.96f)
                    .widthIn(max = 880.dp)
                    .fillMaxHeight(0.94f)
                    .shadow(
                        elevation = 20.dp,
                        shape = RoundedCornerShape(24.dp),
                        ambientColor = Color.Black.copy(alpha = 0.20f),
                        spotColor = PalestineGreen.copy(alpha = 0.18f)
                    ),
                shape = RoundedCornerShape(24.dp),
                color = dialogGlassColor,
                border = BorderStroke(1.dp, dialogGlassBorder),
                shadowElevation = 10.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    PalestineGreen.copy(alpha = if (isDark) 0.11f else 0.055f),
                                    Color.Transparent,
                                    SkyBlue.copy(alpha = if (isDark) 0.09f else 0.045f)
                                )
                            )
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 14.dp)
                    ) {
                        // 1. رأس النافذة الزجاجي
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .shadow(6.dp, CircleShape, spotColor = PalestineGreen.copy(alpha = 0.4f))
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                colors = listOf(PalestineGreen, EmeraldSuccess)
                                            )
                                        )
                                        .border(1.dp, Color.White.copy(alpha = 0.55f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Security,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = if (isEditMode) "إدارة الصلاحيات: @${user?.UserName}" else "إنشاء حساب مؤسسي (ABAC)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = textPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = PalestineGreen.copy(alpha = 0.14f),
                                            border = BorderStroke(0.5.dp, PalestineGreen.copy(alpha = 0.35f))
                                        ) {
                                            Text(
                                                text = if (isEditMode) "تعديل" else "جديد",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "القيود الزمنية • العزل الجغرافي المعتمد • الوصول للشاشات • العمليات",
                                        fontSize = 11.sp,
                                        color = textSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Surface(
                                shape = CircleShape,
                                color = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFF1F5F9).copy(alpha = 0.85f),
                                border = BorderStroke(1.dp, innerGlassBorder),
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .clickable(onClick = onDismiss)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "إغلاق",
                                        tint = textSecondary,
                                        modifier = Modifier.size(19.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 2. بطاقة معلومات الحساب الأساسية الزجاجية (قابلة للطي بانسيابية لتوسيع مساحة التبويبات)
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = innerGlassCardColor,
                            border = BorderStroke(1.dp, innerGlassBorder),
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .animateContentSize(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                )
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { isAccountSectionExpanded = !isAccountSectionExpanded }
                                        .padding(vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.ManageAccounts,
                                            contentDescription = null,
                                            tint = PalestineGreen,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = if (isAccountSectionExpanded) {
                                                "البيانات الأساسية والدور الوظيفي"
                                            } else {
                                                "${fullName.ifBlank { "الحساب" }} • $selectedRoleName"
                                            },
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = textPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        if (!isAccountSectionExpanded) {
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = activeStatusColor.copy(alpha = 0.14f),
                                                border = BorderStroke(0.5.dp, activeStatusColor.copy(alpha = 0.35f))
                                            ) {
                                                Text(
                                                    text = if (isActive) "نشط" else "معطل",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = activeStatusColor,
                                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = if (isAccountSectionExpanded) "طي" else "تعديل الهوية",
                                            fontSize = 11.sp,
                                            color = PalestineGreen,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Icon(
                                            imageVector = if (isAccountSectionExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                            contentDescription = null,
                                            tint = PalestineGreen,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                AnimatedVisibility(
                                    visible = isAccountSectionExpanded,
                                    enter = expandVertically(animationSpec = tween(220)) + fadeIn(animationSpec = tween(220)),
                                    exit = shrinkVertically(animationSpec = tween(180)) + fadeOut(animationSpec = tween(150))
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        val fieldColors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = PalestineGreen,
                                            unfocusedBorderColor = if (isDark) Color.White.copy(alpha = 0.22f) else Color(0xFFCBD5E1),
                                            focusedContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.55f) else Color.White.copy(alpha = 0.80f),
                                            unfocusedContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.35f) else Color.White.copy(alpha = 0.58f),
                                            disabledContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.25f) else Color(0xFFF1F5F9).copy(alpha = 0.65f),
                                            focusedTextColor = textPrimary,
                                            unfocusedTextColor = textPrimary,
                                            focusedLabelColor = PalestineGreen,
                                            unfocusedLabelColor = textSecondary
                                        )

                                        BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                                            if (maxWidth >= 560.dp) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    OutlinedTextField(
                                                        value = fullName,
                                                        onValueChange = {
                                                            fullName = it
                                                            validationError = null
                                                        },
                                                        label = { Text("الاسم الكامل", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                        leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                                        modifier = Modifier.weight(1.25f),
                                                        singleLine = true,
                                                        shape = RoundedCornerShape(14.dp),
                                                        colors = fieldColors
                                                    )
                                                    OutlinedTextField(
                                                        value = username,
                                                        onValueChange = {
                                                            username = it
                                                            validationError = null
                                                        },
                                                        label = { Text("اسم المستخدم", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                        leadingIcon = { Icon(Icons.Rounded.AlternateEmail, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                                        enabled = !isEditMode,
                                                        modifier = Modifier.weight(1f),
                                                        singleLine = true,
                                                        shape = RoundedCornerShape(14.dp),
                                                        colors = fieldColors
                                                    )
                                                    OutlinedTextField(
                                                        value = password,
                                                        onValueChange = { password = it },
                                                        label = { Text(if (isEditMode) "كلمة المرور (تحديث)" else "كلمة المرور", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                        leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                                        modifier = Modifier.weight(1f),
                                                        singleLine = true,
                                                        shape = RoundedCornerShape(14.dp),
                                                        colors = fieldColors
                                                    )
                                                }
                                            } else {
                                                Column(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    OutlinedTextField(
                                                        value = fullName,
                                                        onValueChange = {
                                                            fullName = it
                                                            validationError = null
                                                        },
                                                        label = { Text("الاسم الكامل", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                        leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                                        modifier = Modifier.fillMaxWidth(),
                                                        singleLine = true,
                                                        shape = RoundedCornerShape(14.dp),
                                                        colors = fieldColors
                                                    )
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        OutlinedTextField(
                                                            value = username,
                                                            onValueChange = {
                                                                username = it
                                                                validationError = null
                                                            },
                                                            label = { Text("اسم المستخدم", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                            leadingIcon = { Icon(Icons.Rounded.AlternateEmail, contentDescription = null, modifier = Modifier.size(17.dp)) },
                                                            enabled = !isEditMode,
                                                            modifier = Modifier.weight(1f),
                                                            singleLine = true,
                                                            shape = RoundedCornerShape(14.dp),
                                                            colors = fieldColors
                                                        )
                                                        OutlinedTextField(
                                                            value = password,
                                                            onValueChange = { password = it },
                                                            label = { Text("كلمة المرور", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                            leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(17.dp)) },
                                                            modifier = Modifier.weight(1f),
                                                            singleLine = true,
                                                            shape = RoundedCornerShape(14.dp),
                                                            colors = fieldColors
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        HorizontalDivider(color = subtleDividerColor)

                                        Column(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Badge,
                                                    contentDescription = null,
                                                    tint = textSecondary,
                                                    modifier = Modifier.size(15.dp)
                                                )
                                                Text(
                                                    text = "الدور الوظيفي الأساسي:",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = textPrimary
                                                )
                                            }

                                            FlowRow(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                roles.forEach { role ->
                                                    val isRoleSelected = selectedRoleId == role.RoleID
                                                    val chipContainerColor by animateColorAsState(
                                                        targetValue = if (isRoleSelected) PalestineGreen.copy(alpha = 0.16f) else Color.Transparent,
                                                        animationSpec = tween(220),
                                                        label = "RoleChipBg"
                                                    )
                                                    FilterChip(
                                                        selected = isRoleSelected,
                                                        onClick = { selectedRoleId = role.RoleID },
                                                        label = {
                                                            Text(
                                                                text = role.RoleName,
                                                                fontSize = 11.sp,
                                                                fontWeight = if (isRoleSelected) FontWeight.Bold else FontWeight.Medium,
                                                                maxLines = 1
                                                            )
                                                        },
                                                        leadingIcon = if (isRoleSelected) {
                                                            {
                                                                Icon(
                                                                    imageVector = Icons.Rounded.Check,
                                                                    contentDescription = null,
                                                                    modifier = Modifier.size(15.dp)
                                                                )
                                                            }
                                                        } else null,
                                                        shape = RoundedCornerShape(12.dp),
                                                        colors = FilterChipDefaults.filterChipColors(
                                                            selectedContainerColor = chipContainerColor,
                                                            selectedLabelColor = if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark,
                                                            selectedLeadingIconColor = if (isDark) Color(0xFF6EE7B7) else PalestineGreen
                                                        )
                                                    )
                                                }
                                            }

                                            Surface(
                                                shape = RoundedCornerShape(14.dp),
                                                color = activeBannerBg,
                                                border = BorderStroke(1.dp, activeBannerBorder),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(14.dp))
                                                    .clickable { isActive = !isActive }
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 12.dp, vertical = 6.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        modifier = Modifier.weight(1f),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = if (isActive) Icons.Rounded.VerifiedUser else Icons.Rounded.Block,
                                                            contentDescription = null,
                                                            tint = activeStatusColor,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                        Text(
                                                            text = if (isActive) "الحساب نشط ومفعل للدخول" else "الحساب معطل وموقوف مؤقتاً",
                                                            fontSize = 12.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            color = activeStatusColor,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                    }
                                                    Switch(
                                                        checked = isActive,
                                                        onCheckedChange = { isActive = it },
                                                        colors = SwitchDefaults.colors(
                                                            checkedThumbColor = Color.White,
                                                            checkedTrackColor = EmeraldSuccess,
                                                            uncheckedThumbColor = Color.White,
                                                            uncheckedTrackColor = RoseDanger.copy(alpha = 0.65f)
                                                        )
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        AnimatedVisibility(visible = validationError != null) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = RoseDanger.copy(alpha = 0.14f),
                                border = BorderStroke(1.dp, RoseDanger.copy(alpha = 0.45f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.ErrorOutline,
                                        contentDescription = null,
                                        tint = RoseDanger,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = validationError ?: "",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = RoseDanger
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 3. شريط التبويبات الزجاجي المتجاوب (يملأ العرض على الشاشات الواسعة ويمرر بسلاسة على الهواتف)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = innerGlassCardColor,
                            border = BorderStroke(1.dp, innerGlassBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                                val useScrollableTabs = maxWidth < 560.dp
                                val tabItems = PermissionDialogTab.values()

                                if (useScrollableTabs) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState())
                                            .padding(5.dp),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        tabItems.forEach { tab ->
                                            PermissionTabButton(
                                                tab = tab,
                                                isSelected = activeTab == tab,
                                                badgeText = tabBadgeText(
                                                    tab = tab,
                                                    accountExpiryTimestamp = accountExpiryTimestamp,
                                                    allowedLocalitiesCount = allowedLocalitiesSet.size,
                                                    allowedBranchesCount = allowedBranchesSet.size,
                                                    screensCount = screenPermissionsSet.size,
                                                    actionsCount = actionPermissionsSet.size
                                                ),
                                                isDark = isDark,
                                                textSecondary = textSecondary,
                                                onClick = { activeTab = tab }
                                            )
                                        }
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(5.dp),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        tabItems.forEach { tab ->
                                            PermissionTabButton(
                                                tab = tab,
                                                isSelected = activeTab == tab,
                                                badgeText = tabBadgeText(
                                                    tab = tab,
                                                    accountExpiryTimestamp = accountExpiryTimestamp,
                                                    allowedLocalitiesCount = allowedLocalitiesSet.size,
                                                    allowedBranchesCount = allowedBranchesSet.size,
                                                    screensCount = screenPermissionsSet.size,
                                                    actionsCount = actionPermissionsSet.size
                                                ),
                                                isDark = isDark,
                                                textSecondary = textSecondary,
                                                modifier = Modifier.weight(1f),
                                                onClick = { activeTab = tab }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 4. مساحة محتوى التبويب الموسعة مع حركة انتقال انسيابية و LazyColumn داخل كل تبويب
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            AnimatedContent(
                                targetState = activeTab,
                                transitionSpec = {
                                    val direction = if (targetState.ordinal >= initialState.ordinal) 1 else -1
                                    (fadeIn(animationSpec = tween(240)) +
                                        slideInHorizontally(animationSpec = tween(240)) { width -> direction * (width / 10) })
                                        .togetherWith(
                                            fadeOut(animationSpec = tween(180)) +
                                                slideOutHorizontally(animationSpec = tween(180)) { width -> -direction * (width / 12) }
                                        )
                                },
                                label = "PermissionTabContentTransition"
                            ) { currentTab ->
                                when (currentTab) {
                                    PermissionDialogTab.TIME_RESTRICTIONS -> {
                                        TimeRestrictionsTabContent(
                                            accountExpiryTimestamp = accountExpiryTimestamp,
                                            onExpiryChanged = { accountExpiryTimestamp = it },
                                            maxLogins = maxLogins,
                                            onMaxLoginsChanged = { maxLogins = it },
                                            currentLogins = currentLogins,
                                            onResetLogins = { currentLogins = 0 },
                                            isDark = isDark
                                        )
                                    }
                                    PermissionDialogTab.GEOGRAPHIC_SCOPE -> {
                                        GeographicScopeTabContent(
                                            approvedLocalities = approvedLocalities,
                                            selectedLocalities = allowedLocalitiesSet,
                                            onToggleLocality = { loc ->
                                                val newSet = allowedLocalitiesSet.toMutableSet()
                                                if (newSet.contains(loc)) newSet.remove(loc) else newSet.add(loc)
                                                allowedLocalitiesSet = newSet
                                            },
                                            onSelectAllLocalities = {
                                                allowedLocalitiesSet = mutableSetOf() // فارغ = نطاق مفتوح لكافة المحليات المعتمدة
                                            },
                                            approvedBranches = approvedBranches,
                                            isLoadingBranches = isLoadingBranches,
                                            selectedBranches = allowedBranchesSet,
                                            onToggleBranch = { branch ->
                                                val newSet = allowedBranchesSet.toMutableSet()
                                                if (newSet.contains(branch)) newSet.remove(branch) else newSet.add(branch)
                                                allowedBranchesSet = newSet
                                            },
                                            onSelectAllBranches = {
                                                allowedBranchesSet = mutableSetOf() // فارغ = نطاق مفتوح لكافة المناطق الفرعية المعتمدة
                                            },
                                            isDark = isDark
                                        )
                                    }
                                    PermissionDialogTab.SCREEN_ACCESS -> {
                                        ScreenAccessTabContent(
                                            selectedScreens = screenPermissionsSet,
                                            onToggleScreen = { screenId ->
                                                val newSet = screenPermissionsSet.toMutableSet()
                                                if (newSet.contains(screenId)) newSet.remove(screenId) else newSet.add(screenId)
                                                screenPermissionsSet = newSet
                                            },
                                            onSelectAllScreens = {
                                                screenPermissionsSet = AccessControlManager.ALL_SCREENS.map { it.first }.toMutableSet()
                                            },
                                            onClearAllScreens = {
                                                screenPermissionsSet = mutableSetOf()
                                            },
                                            isDark = isDark
                                        )
                                    }
                                    PermissionDialogTab.ACTION_PERMISSIONS -> {
                                        ActionPermissionsTabContent(
                                            selectedActions = actionPermissionsSet,
                                            onToggleAction = { actionKey ->
                                                val newSet = actionPermissionsSet.toMutableSet()
                                                if (newSet.contains(actionKey)) newSet.remove(actionKey) else newSet.add(actionKey)
                                                actionPermissionsSet = newSet
                                            },
                                            onSelectAllActions = {
                                                actionPermissionsSet = AccessControlManager.ALL_ACTIONS.map { it.first }.toMutableSet()
                                            },
                                            onClearAllActions = {
                                                actionPermissionsSet = mutableSetOf()
                                            },
                                            isDark = isDark
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = subtleDividerColor)
                        Spacer(modifier = Modifier.height(10.dp))

                        // 5. شريط الملخص وأزرار الحفظ والإلغاء
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Shield,
                                    contentDescription = null,
                                    tint = PalestineGreen,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "$selectedRoleName • ${screenPermissionsSet.size} شاشات • ${actionPermissionsSet.size} عمليات",
                                    fontSize = 11.sp,
                                    color = textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = onDismiss,
                                    shape = RoundedCornerShape(14.dp),
                                    border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.25f) else Color(0xFFCBD5E1))
                                ) {
                                    Text("إلغاء", color = textSecondary, fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        if (fullName.isBlank() || username.isBlank()) {
                                            isAccountSectionExpanded = true
                                            validationError = "يرجى إدخال الاسم الكامل واسم المستخدم قبل الحفظ."
                                            return@Button
                                        }
                                        val finalUser = (user ?: UserEntity(
                                            UserName = username.trim(),
                                            PasswordHash = password.trim().ifBlank { "123456" },
                                            fullName = fullName.trim(),
                                            RoleID = selectedRoleId,
                                            CreatedBy = "مدير النظام"
                                        )).copy(
                                            fullName = fullName.trim(),
                                            PasswordHash = if (password.isNotBlank()) password.trim() else (user?.PasswordHash ?: "123456"),
                                            RoleID = selectedRoleId,
                                            IsActive = isActive,
                                            allowedLocalities = allowedLocalitiesSet.toList(),
                                            allowedBranches = allowedBranchesSet.toList(),
                                            screenPermissions = screenPermissionsSet.toList(),
                                            actionPermissions = actionPermissionsSet.toList(),
                                            accountExpiryDate = accountExpiryTimestamp,
                                            maxLogins = maxLogins,
                                            currentLogins = currentLogins,
                                            AllowedScreens = screenPermissionsSet.joinToString(",")
                                        )
                                        onSave(finalUser)
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.Transparent,
                                        contentColor = Color.White
                                    ),
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier.shadow(
                                        elevation = 6.dp,
                                        shape = RoundedCornerShape(14.dp),
                                        spotColor = PalestineGreen.copy(alpha = 0.45f)
                                    )
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                brush = Brush.horizontalGradient(
                                                    colors = listOf(PalestineGreen, EmeraldSuccess)
                                                ),
                                                shape = RoundedCornerShape(14.dp)
                                            )
                                            .padding(horizontal = 16.dp, vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(17.dp)
                                            )
                                            Text(
                                                text = if (isEditMode) "حفظ الصلاحيات" else "إنشاء الحساب",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = Color.White,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PermissionTabButton(
    tab: PermissionDialogTab,
    isSelected: Boolean,
    badgeText: String,
    isDark: Boolean,
    textSecondary: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tabBg by animateColorAsState(
        targetValue = if (isSelected) PalestineGreen else Color.Transparent,
        animationSpec = tween(250),
        label = "TabBg"
    )
    val tabContentColor by animateColorAsState(
        targetValue = if (isSelected) Color.White else textSecondary,
        animationSpec = tween(250),
        label = "TabContent"
    )
    val tabBorderColor by animateColorAsState(
        targetValue = if (isSelected) Color.White.copy(alpha = 0.45f) else Color.Transparent,
        animationSpec = tween(250),
        label = "TabBorder"
    )

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = tabBg,
        border = BorderStroke(1.dp, tabBorderColor),
        shadowElevation = if (isSelected) 3.dp else 0.dp,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = tab.icon,
                contentDescription = null,
                tint = tabContentColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = tab.title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = tabContentColor,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
            if (badgeText.isNotBlank()) {
                Spacer(modifier = Modifier.width(5.dp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isSelected) Color.White.copy(alpha = 0.22f) else {
                        if (isDark) Color.White.copy(alpha = 0.10f) else Color(0xFFE2E8F0)
                    }
                ) {
                    Text(
                        text = badgeText,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else textSecondary,
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                        maxLines = 1
                    )
                }
            }
        }
    }
}

private fun tabBadgeText(
    tab: PermissionDialogTab,
    accountExpiryTimestamp: Long,
    allowedLocalitiesCount: Int,
    allowedBranchesCount: Int,
    screensCount: Int,
    actionsCount: Int
): String = when (tab) {
    PermissionDialogTab.TIME_RESTRICTIONS -> if (accountExpiryTimestamp > 0L) "مؤقت" else "دائم"
    PermissionDialogTab.GEOGRAPHIC_SCOPE -> {
        val totalRestrictions = allowedLocalitiesCount + allowedBranchesCount
        if (totalRestrictions == 0) "الكل" else "$totalRestrictions"
    }
    PermissionDialogTab.SCREEN_ACCESS -> "$screensCount/${AccessControlManager.ALL_SCREENS.size}"
    PermissionDialogTab.ACTION_PERMISSIONS -> "$actionsCount/${AccessControlManager.ALL_ACTIONS.size}"
}

/**
 * Tab 1: محتوى القيود الزمنية وحدود الجلسات (مع DatePicker + إدخال عدد الأيام + التمديد السريع + LazyColumn)
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
private fun TimeRestrictionsTabContent(
    accountExpiryTimestamp: Long,
    onExpiryChanged: (Long) -> Unit,
    maxLogins: Int,
    onMaxLoginsChanged: (Int) -> Unit,
    currentLogins: Int,
    onResetLogins: () -> Unit,
    isDark: Boolean
) {
    val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US) }
    var showDatePicker by remember { mutableStateOf(false) }

    val now = System.currentTimeMillis()
    val isExpired = accountExpiryTimestamp > 0L && now > accountExpiryTimestamp
    val daysRemaining = if (accountExpiryTimestamp > 0L && !isExpired) {
        ceil((accountExpiryTimestamp - now).toDouble() / MILLIS_PER_DAY.toDouble()).toInt().coerceAtLeast(1)
    } else null

    // مزامنة حقل عدد الأيام عند تعديله عبر التقويم أو الاختيارات السريعة
    var customDaysInput by remember {
        mutableStateOf(
            if (accountExpiryTimestamp > 0L && accountExpiryTimestamp > now) {
                ceil((accountExpiryTimestamp - now).toDouble() / MILLIS_PER_DAY.toDouble()).toInt().coerceAtLeast(1).toString()
            } else {
                ""
            }
        )
    }

    val textPrimary = if (isDark) Color(0xFFF8FAFC) else SlateTextPrimary
    val textSecondary = if (isDark) Color(0xFFCBD5E1) else SlateTextSecondary
    val glassSurface = if (isDark) Color(0xFF1E293B).copy(alpha = 0.72f) else Color.White.copy(alpha = 0.78f)
    val glassBorder = if (isDark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.85f)
    val dividerColor = if (isDark) Color.White.copy(alpha = 0.12f) else Color(0xFFE2E8F0).copy(alpha = 0.85f)

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = PalestineGreen,
        unfocusedBorderColor = if (isDark) Color.White.copy(alpha = 0.22f) else Color(0xFFCBD5E1),
        focusedContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.55f) else Color.White.copy(alpha = 0.80f),
        unfocusedContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.35f) else Color.White.copy(alpha = 0.60f),
        disabledContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.25f) else Color(0xFFF1F5F9).copy(alpha = 0.65f),
        focusedTextColor = textPrimary,
        unfocusedTextColor = textPrimary,
        focusedLabelColor = PalestineGreen,
        unfocusedLabelColor = textSecondary
    )

    val expiryCardColor by animateColorAsState(
        targetValue = if (isExpired) {
            if (isDark) RoseDanger.copy(alpha = 0.18f) else Color(0xFFFEF2F2).copy(alpha = 0.90f)
        } else {
            if (isDark) EmeraldSuccess.copy(alpha = 0.15f) else Color(0xFFECFDF5).copy(alpha = 0.88f)
        },
        animationSpec = tween(300),
        label = "ExpiryCardBg"
    )
    val expiryBorderColor by animateColorAsState(
        targetValue = if (isExpired) RoseDanger.copy(alpha = 0.45f) else EmeraldSuccess.copy(alpha = 0.45f),
        animationSpec = tween(300),
        label = "ExpiryCardBorder"
    )

    val applyDaysDuration: (Int) -> Unit = { days ->
        val safeDays = days.coerceIn(1, 36500)
        customDaysInput = safeDays.toString()
        val cal = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, safeDays)
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }
        onExpiryChanged(cal.timeInMillis)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. بطاقة حالة الصلاحية الزمنية ومنتقي التاريخ وحاسبة الأيام
        item(key = "expiry_card") {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = expiryCardColor),
                border = BorderStroke(1.dp, expiryBorderColor),
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize(animationSpec = spring())
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // رأس الحالة الزمنية
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isExpired) RoseDanger.copy(alpha = 0.18f) else EmeraldSuccess.copy(alpha = 0.18f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Event,
                                    contentDescription = null,
                                    tint = if (isExpired) RoseDanger else EmeraldSuccess,
                                    modifier = Modifier.size(21.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "تاريخ انتهاء صلاحية الحساب",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = textPrimary
                                )
                                Text(
                                    text = when {
                                        accountExpiryTimestamp <= 0L -> "الحساب دائم وغير مقيد بتاريخ انتهاء"
                                        isExpired -> "انتهت الصلاحية بتاريخ ${sdf.format(Date(accountExpiryTimestamp))}"
                                        else -> "ساري المفعول حتى ${sdf.format(Date(accountExpiryTimestamp))}"
                                    },
                                    fontSize = 11.sp,
                                    color = if (isExpired) RoseDanger else if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark
                                )
                            }
                        }

                        if (daysRemaining != null) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = EmeraldSuccess,
                                contentColor = Color.White
                            ) {
                                Text(
                                    text = "متبقي $daysRemaining يوم",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = dividerColor)

                    // منتقي التاريخ المباشر (DatePicker) + حقل إدخال عدد الأيام المخصص
                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        val isWide = maxWidth >= 500.dp
                        if (isWide) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                DatePickerTriggerCard(
                                    formattedDate = if (accountExpiryTimestamp > 0L) sdf.format(Date(accountExpiryTimestamp)) else "غير محدد (دائم)",
                                    hasExpiry = accountExpiryTimestamp > 0L,
                                    isDark = isDark,
                                    textPrimary = textPrimary,
                                    textSecondary = textSecondary,
                                    modifier = Modifier.weight(1.1f),
                                    onOpenPicker = { showDatePicker = true },
                                    onClearExpiry = {
                                        customDaysInput = ""
                                        onExpiryChanged(0L)
                                    }
                                )
                                OutlinedTextField(
                                    value = customDaysInput,
                                    onValueChange = { raw ->
                                        val digits = raw.filter { it.isDigit() }.take(5)
                                        customDaysInput = digits
                                        val parsedDays = digits.toIntOrNull()
                                        if (parsedDays != null && parsedDays > 0) {
                                            val safeDays = parsedDays.coerceAtMost(36500)
                                            val cal = Calendar.getInstance().apply {
                                                add(Calendar.DAY_OF_YEAR, safeDays)
                                                set(Calendar.HOUR_OF_DAY, 23)
                                                set(Calendar.MINUTE, 59)
                                                set(Calendar.SECOND, 59)
                                                set(Calendar.MILLISECOND, 999)
                                            }
                                            onExpiryChanged(cal.timeInMillis)
                                        } else if (digits.isEmpty()) {
                                            onExpiryChanged(0L)
                                        }
                                    },
                                    label = { Text("عدد أيام الصلاحية (مثال: 15، 45)", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    placeholder = { Text("أدخل عدد الأيام...", fontSize = 11.sp) },
                                    leadingIcon = { Icon(Icons.Rounded.HourglassBottom, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                    suffix = { Text("يوم", fontSize = 11.sp, color = textSecondary) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = fieldColors,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                DatePickerTriggerCard(
                                    formattedDate = if (accountExpiryTimestamp > 0L) sdf.format(Date(accountExpiryTimestamp)) else "غير محدد (دائم)",
                                    hasExpiry = accountExpiryTimestamp > 0L,
                                    isDark = isDark,
                                    textPrimary = textPrimary,
                                    textSecondary = textSecondary,
                                    modifier = Modifier.fillMaxWidth(),
                                    onOpenPicker = { showDatePicker = true },
                                    onClearExpiry = {
                                        customDaysInput = ""
                                        onExpiryChanged(0L)
                                    }
                                )
                                OutlinedTextField(
                                    value = customDaysInput,
                                    onValueChange = { raw ->
                                        val digits = raw.filter { it.isDigit() }.take(5)
                                        customDaysInput = digits
                                        val parsedDays = digits.toIntOrNull()
                                        if (parsedDays != null && parsedDays > 0) {
                                            val safeDays = parsedDays.coerceAtMost(36500)
                                            val cal = Calendar.getInstance().apply {
                                                add(Calendar.DAY_OF_YEAR, safeDays)
                                                set(Calendar.HOUR_OF_DAY, 23)
                                                set(Calendar.MINUTE, 59)
                                                set(Calendar.SECOND, 59)
                                                set(Calendar.MILLISECOND, 999)
                                            }
                                            onExpiryChanged(cal.timeInMillis)
                                        } else if (digits.isEmpty()) {
                                            onExpiryChanged(0L)
                                        }
                                    },
                                    label = { Text("عدد أيام الصلاحية (مثال: 15، 45)", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    placeholder = { Text("أدخل عدد الأيام لاحتساب الانتهاء تلقائياً", fontSize = 11.sp) },
                                    leadingIcon = { Icon(Icons.Rounded.HourglassBottom, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                    suffix = { Text("يوم", fontSize = 11.sp, color = textSecondary) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = fieldColors,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = dividerColor)

                    Text(
                        text = "خيارات التمديد والتحديد السريع:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = textPrimary
                    )

                    val selectedDaysNumber = customDaysInput.toIntOrNull()

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = accountExpiryTimestamp == 0L,
                            onClick = {
                                customDaysInput = ""
                                onExpiryChanged(0L)
                            },
                            label = { Text("دائم (بدون انتهاء)", fontSize = 11.sp) },
                            leadingIcon = if (accountExpiryTimestamp == 0L) {
                                { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                            } else null,
                            shape = RoundedCornerShape(12.dp)
                        )
                        listOf(
                            15 to "15 يوماً",
                            30 to "30 يوماً",
                            45 to "45 يوماً",
                            90 to "90 يوماً",
                            365 to "عام كامل"
                        ).forEach { (presetDays, presetLabel) ->
                            val isPresetSelected = accountExpiryTimestamp > 0L && selectedDaysNumber == presetDays
                            FilterChip(
                                selected = isPresetSelected,
                                onClick = { applyDaysDuration(presetDays) },
                                label = { Text(presetLabel, fontSize = 11.sp) },
                                leadingIcon = if (isPresetSelected) {
                                    { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                } else null,
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }
            }
        }

        // 2. بطاقة عداد مرات تسجيل الدخول المسموحة
        item(key = "login_quota_card") {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = glassSurface),
                border = BorderStroke(1.dp, glassBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize(animationSpec = spring())
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(SkyBlue.copy(alpha = 0.16f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Login,
                                    contentDescription = null,
                                    tint = SkyBlue,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "رصيد تسجيلات الدخول المسموحة",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = textPrimary
                                )
                                Text(
                                    text = "تقييد عدد مرات دخول المندوب أو الباحث الميداني للنظام",
                                    fontSize = 11.sp,
                                    color = textSecondary
                                )
                            }
                        }

                        if (maxLogins > 0) {
                            val remaining = (maxLogins - currentLogins).coerceAtLeast(0)
                            val quotaBadgeColor by animateColorAsState(
                                targetValue = if (remaining > 5) SkyBlue else RoseDanger,
                                animationSpec = tween(250),
                                label = "QuotaBadgeColor"
                            )
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = quotaBadgeColor,
                                contentColor = Color.White
                            ) {
                                Text(
                                    text = "المتبقي: $remaining / $maxLogins",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = dividerColor)

                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                        if (maxWidth >= 460.dp) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = if (maxLogins == 0) "" else maxLogins.toString(),
                                    onValueChange = { onMaxLoginsChanged(it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0) },
                                    label = { Text("الحد الأقصى (0 = غير محدود)", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1.2f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = fieldColors
                                )
                                OutlinedTextField(
                                    value = currentLogins.toString(),
                                    onValueChange = {},
                                    enabled = false,
                                    label = { Text("المستهلك", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    modifier = Modifier.weight(0.8f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = fieldColors
                                )
                                FilledTonalButton(
                                    onClick = onResetLogins,
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تصفير", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = if (maxLogins == 0) "" else maxLogins.toString(),
                                        onValueChange = { onMaxLoginsChanged(it.filter { ch -> ch.isDigit() }.toIntOrNull() ?: 0) },
                                        label = { Text("الحد الأقصى (0 = مفتوح)", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        modifier = Modifier.weight(1.2f),
                                        singleLine = true,
                                        shape = RoundedCornerShape(14.dp),
                                        colors = fieldColors
                                    )
                                    OutlinedTextField(
                                        value = currentLogins.toString(),
                                        onValueChange = {},
                                        enabled = false,
                                        label = { Text("المستهلك", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                        modifier = Modifier.weight(0.8f),
                                        singleLine = true,
                                        shape = RoundedCornerShape(14.dp),
                                        colors = fieldColors
                                    )
                                }
                                FilledTonalButton(
                                    onClick = onResetLogins,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("تصفير العداد", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة منتقي التاريخ (Material 3 DatePickerDialog)
    if (showDatePicker) {
        val initialSelectedMillis = remember(accountExpiryTimestamp) {
            if (accountExpiryTimestamp > 0L) {
                val localCal = Calendar.getInstance().apply { timeInMillis = accountExpiryTimestamp }
                Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                    clear()
                    set(
                        localCal.get(Calendar.YEAR),
                        localCal.get(Calendar.MONTH),
                        localCal.get(Calendar.DAY_OF_MONTH)
                    )
                }.timeInMillis
            } else null
        }
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = initialSelectedMillis)

        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val pickedUtcMillis = datePickerState.selectedDateMillis
                        if (pickedUtcMillis != null) {
                            val utcCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                                timeInMillis = pickedUtcMillis
                            }
                            val localEndOfDay = Calendar.getInstance().apply {
                                set(Calendar.YEAR, utcCal.get(Calendar.YEAR))
                                set(Calendar.MONTH, utcCal.get(Calendar.MONTH))
                                set(Calendar.DAY_OF_MONTH, utcCal.get(Calendar.DAY_OF_MONTH))
                                set(Calendar.HOUR_OF_DAY, 23)
                                set(Calendar.MINUTE, 59)
                                set(Calendar.SECOND, 59)
                                set(Calendar.MILLISECOND, 999)
                            }
                            val targetMillis = localEndOfDay.timeInMillis
                            onExpiryChanged(targetMillis)
                            val diffDays = ceil((targetMillis - System.currentTimeMillis()).toDouble() / MILLIS_PER_DAY.toDouble()).toInt()
                            customDaysInput = if (diffDays > 0) diffDays.toString() else ""
                        }
                        showDatePicker = false
                    }
                ) {
                    Text("تأكيد التاريخ", fontWeight = FontWeight.Bold, color = PalestineGreen)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("إلغاء", color = textSecondary)
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@Composable
private fun DatePickerTriggerCard(
    formattedDate: String,
    hasExpiry: Boolean,
    isDark: Boolean,
    textPrimary: Color,
    textSecondary: Color,
    modifier: Modifier = Modifier,
    onOpenPicker: () -> Unit,
    onClearExpiry: () -> Unit
) {
    val containerBg = if (isDark) Color(0xFF0F172A).copy(alpha = 0.50f) else Color.White.copy(alpha = 0.78f)
    val borderColor = if (hasExpiry) PalestineGreen.copy(alpha = 0.5f) else {
        if (isDark) Color.White.copy(alpha = 0.22f) else Color(0xFFCBD5E1)
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = containerBg,
        border = BorderStroke(1.dp, borderColor),
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onOpenPicker)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.CalendarMonth,
                    contentDescription = null,
                    tint = PalestineGreen,
                    modifier = Modifier.size(20.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "تاريخ الانتهاء المحدد (التقويم)",
                        fontSize = 10.sp,
                        color = textSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = formattedDate,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (hasExpiry) {
                    IconButton(
                        onClick = onClearExpiry,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Clear,
                            contentDescription = "إلغاء التاريخ",
                            tint = RoseDanger,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Text(
                    text = "تغيير",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = PalestineGreen,
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
        }
    }
}

/**
 * Tab 2: محتوى النطاق الجغرافي المعتمد حصراً على قاعدة البيانات (Row-Level Security)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GeographicScopeTabContent(
    approvedLocalities: List<String>,
    selectedLocalities: Set<String>,
    onToggleLocality: (String) -> Unit,
    onSelectAllLocalities: () -> Unit,
    approvedBranches: List<String>,
    isLoadingBranches: Boolean,
    selectedBranches: Set<String>,
    onToggleBranch: (String) -> Unit,
    onSelectAllBranches: () -> Unit,
    isDark: Boolean
) {
    var searchQuery by remember { mutableStateOf("") }
    val isAllLocalities = selectedLocalities.isEmpty() || selectedLocalities.contains("*")
    val isAllBranches = selectedBranches.isEmpty() || selectedBranches.contains("*")

    val filteredLocalities = remember(approvedLocalities, searchQuery) {
        val q = searchQuery.trim()
        if (q.isBlank()) approvedLocalities
        else approvedLocalities.filter { it.contains(q, ignoreCase = true) }
    }
    val filteredBranches = remember(approvedBranches, searchQuery) {
        val q = searchQuery.trim()
        if (q.isBlank()) approvedBranches
        else approvedBranches.filter { it.contains(q, ignoreCase = true) }
    }

    val textPrimary = if (isDark) Color(0xFFF8FAFC) else SlateTextPrimary
    val textSecondary = if (isDark) Color(0xFFCBD5E1) else SlateTextSecondary
    val glassSurface = if (isDark) Color(0xFF1E293B).copy(alpha = 0.72f) else Color.White.copy(alpha = 0.78f)
    val glassBorder = if (isDark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.85f)
    val dividerColor = if (isDark) Color.White.copy(alpha = 0.12f) else Color(0xFFE2E8F0).copy(alpha = 0.85f)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // شريط البحث السريع داخل النطاق الجغرافي المعتمد
        item(key = "geo_search_bar") {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("ابحث في المحليات المعتمدة أو المناطق الفرعية...", fontSize = 11.sp) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                trailingIcon = if (searchQuery.isNotEmpty()) {
                    {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Rounded.Clear, contentDescription = "مسح", modifier = Modifier.size(16.dp))
                        }
                    }
                } else null,
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PalestineGreen,
                    unfocusedBorderColor = if (isDark) Color.White.copy(alpha = 0.22f) else Color(0xFFCBD5E1),
                    focusedContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.55f) else Color.White.copy(alpha = 0.82f),
                    unfocusedContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.35f) else Color.White.copy(alpha = 0.62f),
                    focusedTextColor = textPrimary,
                    unfocusedTextColor = textPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 1. بطاقة المحليات المعتمدة من قاعدة البيانات
        item(key = "approved_localities_card") {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = glassSurface),
                border = BorderStroke(1.dp, glassBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize(animationSpec = spring())
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.LocationOn,
                                contentDescription = null,
                                tint = PalestineGreen,
                                modifier = Modifier.size(20.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "1. المحليات المعتمدة في قاعدة البيانات (${approvedLocalities.size})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = textPrimary
                                )
                                Text(
                                    text = if (isAllLocalities) {
                                        "نطاق مفتوح: مصرح برؤية وترشيح كافة المحليات المعتمدة"
                                    } else {
                                        "مقيد بـ ${selectedLocalities.size} محليات محددة"
                                    },
                                    fontSize = 11.sp,
                                    color = if (isAllLocalities) EmeraldSuccess else AmberWarning
                                )
                            }
                        }

                        TextButton(onClick = onSelectAllLocalities) {
                            Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isAllLocalities) "الكل مفعّل" else "فتح للكل",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    HorizontalDivider(color = dividerColor)

                    if (filteredLocalities.isEmpty()) {
                        GeoEmptyStateBanner(
                            message = if (approvedLocalities.isEmpty()) {
                                "لا توجد محليات معتمدة مسجلة في قاعدة البيانات بعد. يتم تغذية القائمة تلقائياً من جدول المحليات وسجل الأسر."
                            } else {
                                "لا توجد محلية معتمدة تطابق البحث \"$searchQuery\"."
                            },
                            textSecondary = textSecondary,
                            isDark = isDark
                        )
                    } else {
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            filteredLocalities.forEach { loc ->
                                val isChecked = isAllLocalities || selectedLocalities.contains(loc)
                                val locBgColor by animateColorAsState(
                                    targetValue = if (isChecked) {
                                        if (isDark) EmeraldSuccess.copy(alpha = 0.22f) else Color(0xFFECFDF5)
                                    } else {
                                        if (isDark) Color(0xFF0F172A).copy(alpha = 0.45f) else Color.White.copy(alpha = 0.72f)
                                    },
                                    animationSpec = tween(220),
                                    label = "LocBg"
                                )
                                val locBorderColor by animateColorAsState(
                                    targetValue = if (isChecked) EmeraldSuccess.copy(alpha = 0.6f) else glassBorder,
                                    animationSpec = tween(220),
                                    label = "LocBorder"
                                )

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = locBgColor,
                                    border = BorderStroke(1.dp, locBorderColor),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { onToggleLocality(loc) }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = { onToggleLocality(loc) },
                                            colors = CheckboxDefaults.colors(checkedColor = EmeraldSuccess)
                                        )
                                        Text(
                                            text = loc,
                                            fontSize = 12.sp,
                                            fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isChecked) (if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark) else textPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. بطاقة المناطق الفرعية والشعب المعتمدة من قاعدة البيانات
        item(key = "approved_branches_card") {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = glassSurface),
                border = BorderStroke(1.dp, glassBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize(animationSpec = spring())
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Place,
                                contentDescription = null,
                                tint = SkyBlue,
                                modifier = Modifier.size(20.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "2. الشعب والمناطق الفرعية المعتمدة (${approvedBranches.size})",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = textPrimary
                                )
                                Text(
                                    text = if (isAllBranches) {
                                        "نطاق مفتوح: مصرح بكافة الشعب المسجلة ضمن المحليات المعتمدة"
                                    } else {
                                        "مقيد بـ ${selectedBranches.size} شعبة / منطقة فرعية"
                                    },
                                    fontSize = 11.sp,
                                    color = if (isAllBranches) EmeraldSuccess else AmberWarning
                                )
                            }
                        }

                        TextButton(onClick = onSelectAllBranches) {
                            Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isAllBranches) "الكل مفعّل" else "فتح للكل",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    HorizontalDivider(color = dividerColor)

                    if (isLoadingBranches) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = PalestineGreen
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "جاري تحميل المناطق الفرعية المعتمدة من قاعدة البيانات...",
                                fontSize = 11.sp,
                                color = textSecondary
                            )
                        }
                    } else if (filteredBranches.isEmpty()) {
                        GeoEmptyStateBanner(
                            message = when {
                                approvedBranches.isEmpty() && selectedLocalities.isNotEmpty() ->
                                    "لا توجد شعب أو مناطق فرعية مسجلة في قاعدة البيانات ضمن المحليات المختارة حالياً."
                                approvedBranches.isEmpty() ->
                                    "لا توجد شعب أو مناطق فرعية مسجلة في سجل الأسر بقاعدة البيانات حتى الآن."
                                else ->
                                    "لا توجد شعبة أو منطقة فرعية تطابق البحث \"$searchQuery\"."
                            },
                            textSecondary = textSecondary,
                            isDark = isDark
                        )
                    } else {
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            filteredBranches.forEach { branch ->
                                val isChecked = isAllBranches || selectedBranches.contains(branch)
                                val chipBg by animateColorAsState(
                                    targetValue = if (isChecked) EmeraldSuccess.copy(alpha = 0.16f) else Color.Transparent,
                                    animationSpec = tween(200),
                                    label = "BranchChipBg"
                                )
                                FilterChip(
                                    selected = isChecked,
                                    onClick = { onToggleBranch(branch) },
                                    label = {
                                        Text(
                                            text = branch,
                                            fontSize = 11.sp,
                                            fontWeight = if (isChecked) FontWeight.SemiBold else FontWeight.Normal
                                        )
                                    },
                                    leadingIcon = if (isChecked) {
                                        {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = null,
                                                modifier = Modifier.size(14.dp),
                                                tint = EmeraldSuccess
                                            )
                                        }
                                    } else null,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = chipBg,
                                        selectedLabelColor = if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GeoEmptyStateBanner(
    message: String,
    textSecondary: Color,
    isDark: Boolean
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isDark) Color(0xFF0F172A).copy(alpha = 0.45f) else Color(0xFFF8FAFC),
        border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.10f) else Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Public,
                contentDescription = null,
                tint = textSecondary,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = message,
                fontSize = 11.sp,
                color = textSecondary
            )
        }
    }
}

/**
 * Tab 3: محتوى الوصول للشاشات (Screen Access Toggles عبر LazyColumn واسعة)
 */
@Composable
private fun ScreenAccessTabContent(
    selectedScreens: Set<String>,
    onToggleScreen: (String) -> Unit,
    onSelectAllScreens: () -> Unit,
    onClearAllScreens: () -> Unit,
    isDark: Boolean
) {
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else SlateTextPrimary
    val textSecondary = if (isDark) Color(0xFFCBD5E1) else SlateTextSecondary

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "screen_header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "الشاشات والوحدات المصرح بالدخول إليها:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = textPrimary
                    )
                    Text(
                        text = "مفعّل ${selectedScreens.size} من أصل ${AccessControlManager.ALL_SCREENS.size} شاشات",
                        fontSize = 11.sp,
                        color = textSecondary
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = onClearAllScreens) {
                        Text("إلغاء الكل", fontSize = 11.sp, color = RoseDanger)
                    }
                    TextButton(onClick = onSelectAllScreens) {
                        Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("منح الكل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        items(AccessControlManager.ALL_SCREENS, key = { it.first }) { (screenKey, screenTitle) ->
            val isEnabled = selectedScreens.contains(screenKey)

            val cardBg by animateColorAsState(
                targetValue = if (isEnabled) {
                    if (isDark) EmeraldSuccess.copy(alpha = 0.16f) else Color(0xFFECFDF5).copy(alpha = 0.88f)
                } else {
                    if (isDark) RoseDanger.copy(alpha = 0.14f) else Color(0xFFFEF2F2).copy(alpha = 0.84f)
                },
                animationSpec = tween(260),
                label = "ScreenCardBg"
            )
            val cardBorder by animateColorAsState(
                targetValue = if (isEnabled) EmeraldSuccess.copy(alpha = 0.45f) else RoseDanger.copy(alpha = 0.40f),
                animationSpec = tween(260),
                label = "ScreenCardBorder"
            )
            val badgeBg by animateColorAsState(
                targetValue = if (isEnabled) EmeraldSuccess.copy(alpha = 0.18f) else RoseDanger.copy(alpha = 0.18f),
                animationSpec = tween(260),
                label = "ScreenBadgeBg"
            )
            val accentColor by animateColorAsState(
                targetValue = if (isEnabled) EmeraldSuccess else RoseDanger,
                animationSpec = tween(260),
                label = "ScreenAccent"
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = BorderStroke(1.dp, cardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize(animationSpec = spring())
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onToggleScreen(screenKey) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(badgeBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isEnabled) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = screenTitle,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = textPrimary
                            )
                            Text(
                                text = "معرف الشاشة: $screenKey • ${if (isEnabled) "مصرح بظهور الشاشة" else "محظورة ومخفية كلياً"}",
                                fontSize = 11.sp,
                                color = if (isEnabled) (if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark) else RoseDanger
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { onToggleScreen(screenKey) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = EmeraldSuccess,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = RoseDanger.copy(alpha = 0.65f)
                        )
                    )
                }
            }
        }
    }
}

/**
 * Tab 4: محتوى صلاحيات العمليات الدقيقة (Fine-grained Action Permissions عبر LazyColumn واسعة)
 */
@Composable
private fun ActionPermissionsTabContent(
    selectedActions: Set<String>,
    onToggleAction: (String) -> Unit,
    onSelectAllActions: () -> Unit,
    onClearAllActions: () -> Unit,
    isDark: Boolean
) {
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else SlateTextPrimary
    val textSecondary = if (isDark) Color(0xFFCBD5E1) else SlateTextSecondary

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "actions_header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "الأوامر والصلاحيات الإجرائية الدقيقة (CRUD):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = textPrimary
                    )
                    Text(
                        text = "ممنوح ${selectedActions.size} من أصل ${AccessControlManager.ALL_ACTIONS.size} صلاحيات",
                        fontSize = 11.sp,
                        color = textSecondary
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = onClearAllActions) {
                        Text("سحب الكل", fontSize = 11.sp, color = RoseDanger)
                    }
                    TextButton(onClick = onSelectAllActions) {
                        Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("منح الكل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        items(AccessControlManager.ALL_ACTIONS, key = { it.first }) { (actionKey, actionDesc) ->
            val isGranted = selectedActions.contains(actionKey)

            val actionIcon = when (actionKey) {
                AccessControlManager.ACTION_ADD -> Icons.Rounded.AddCircle
                AccessControlManager.ACTION_EDIT -> Icons.Rounded.Edit
                AccessControlManager.ACTION_DELETE -> Icons.Rounded.Delete
                AccessControlManager.ACTION_EXPORT -> Icons.Rounded.FileDownload
                AccessControlManager.ACTION_DELIVER -> Icons.Rounded.LocalShipping
                AccessControlManager.ACTION_NOMINATE -> Icons.Rounded.CheckCircle
                else -> Icons.Rounded.Security
            }

            val cardBg by animateColorAsState(
                targetValue = if (isGranted) {
                    if (isDark) EmeraldSuccess.copy(alpha = 0.16f) else Color(0xFFECFDF5).copy(alpha = 0.88f)
                } else {
                    if (isDark) RoseDanger.copy(alpha = 0.14f) else Color(0xFFFEF2F2).copy(alpha = 0.84f)
                },
                animationSpec = tween(260),
                label = "ActionCardBg"
            )
            val cardBorder by animateColorAsState(
                targetValue = if (isGranted) EmeraldSuccess.copy(alpha = 0.45f) else RoseDanger.copy(alpha = 0.40f),
                animationSpec = tween(260),
                label = "ActionCardBorder"
            )
            val accentColor by animateColorAsState(
                targetValue = if (isGranted) EmeraldSuccess else RoseDanger,
                animationSpec = tween(260),
                label = "ActionAccent"
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = BorderStroke(1.dp, cardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize(animationSpec = spring())
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onToggleAction(actionKey) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(accentColor.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = actionIcon,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = actionKey,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isGranted) (if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark) else RoseDanger
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = accentColor,
                                    contentColor = Color.White
                                ) {
                                    Text(
                                        text = if (isGranted) "مصرّح" else "محظور",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = actionDesc,
                                fontSize = 11.sp,
                                color = textSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Switch(
                        checked = isGranted,
                        onCheckedChange = { onToggleAction(actionKey) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = EmeraldSuccess,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = RoseDanger.copy(alpha = 0.65f)
                        )
                    )
                }
            }
        }
    }
}
