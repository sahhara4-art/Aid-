package com.humanitarian.aidmanagement.ui.screens.users

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.RoleEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

enum class PermissionDialogTab(val title: String, val icon: ImageVector) {
    TIME_RESTRICTIONS("القيود الزمنية", Icons.Rounded.Schedule),
    GEOGRAPHIC_SCOPE("النطاق الجغرافي", Icons.Rounded.Map),
    SCREEN_ACCESS("الوصول للشاشات", Icons.Rounded.DesktopWindows),
    ACTION_PERMISSIONS("صلاحيات العمليات", Icons.Rounded.Bolt)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdvancedUserPermissionsDialog(
    user: UserEntity?, // null = إضافة مستخدم جديد, non-null = تعديل مستخدم قائم
    roles: List<RoleEntity>,
    localities: List<LocalityEntity>,
    groups: List<String>,
    onDismiss: () -> Unit,
    onSave: (UserEntity) -> Unit
) {
    var activeTab by remember { mutableStateOf(PermissionDialogTab.TIME_RESTRICTIONS) }
    var isAccountSectionExpanded by remember { mutableStateOf(true) }

    // الحقول الأساسية
    var username by remember { mutableStateOf(user?.UserName ?: "") }
    var password by remember { mutableStateOf(user?.PasswordHash ?: "") }
    var fullName by remember { mutableStateOf(user?.fullName ?: "") }
    var selectedRoleId by remember { mutableStateOf(user?.RoleID ?: (roles.firstOrNull()?.RoleID ?: 2)) }
    var isActive by remember { mutableStateOf(user?.IsActive ?: true) }

    // Tab 1: القيود الزمنية ومرات الدخول
    var accountExpiryTimestamp by remember { mutableStateOf(user?.accountExpiryDate ?: 0L) }
    var maxLogins by remember { mutableStateOf(user?.maxLogins ?: 0) }
    var currentLogins by remember { mutableStateOf(user?.currentLogins ?: 0) }

    // Tab 2: النطاق الجغرافي (محليات وشعب)
    val allLocalityNames = remember(localities) {
        val names = localities.map { it.LocalityName.trim() }.filter { it.isNotBlank() }
        if (names.isEmpty()) listOf("شمال غزة", "غزة", "دير البلح والوسطى", "خان يونس", "رفح") else names
    }
    var allowedLocalitiesSet by remember {
        mutableStateOf(user?.allowedLocalities?.toMutableSet() ?: mutableSetOf())
    }

    val sampleBranches = remember {
        listOf(
            "الشاطئ", "الرمال", "الشيخ رضوان", "التفاح والدرج", "الشجاعية", "الزيتون", "تل الهوا",
            "مخيم جباليا", "جباليا البلد", "بيت لاهيا", "بيت حانون",
            "النصيرات", "البريج", "المغازي", "دير البلح", "الزويدة",
            "خانيونس البلد", "المعسكر", "القرارة", "بني سهيلا", "الفخاري",
            "تل السلطان", "الشابورة", "الجنينة", "يبنا", "حي السلام"
        )
    }
    var allowedBranchesSet by remember {
        mutableStateOf(user?.allowedBranches?.toMutableSet() ?: mutableSetOf())
    }

    // Tab 3: الوصول للشاشات
    var screenPermissionsSet by remember {
        mutableStateOf(
            if (user != null) {
                user.screenPermissions.toMutableSet().ifEmpty {
                    user.AllowedScreens.split(",").map { it.trim().lowercase() }.filter { it.isNotBlank() }.toMutableSet()
                }
            } else {
                mutableSetOf("dashboard", "families", "nomination", "delivery", "reports")
            }
        )
    }

    // Tab 4: صلاحيات العمليات الدقيقة
    var actionPermissionsSet by remember {
        mutableStateOf(
            if (user != null) {
                user.actionPermissions.toMutableSet()
            } else {
                mutableSetOf(
                    AccessControlManager.ACTION_ADD,
                    AccessControlManager.ACTION_EDIT,
                    AccessControlManager.ACTION_EXPORT
                )
            }
        )
    }

    val isEditMode = user != null
    val selectedRoleName = roles.firstOrNull { it.RoleID == selectedRoleId }?.RoleName ?: "مستخدم"

    val isDark = isSystemInDarkTheme()
    val dialogGlassColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.88f) else Color.White.copy(alpha = 0.85f)
    val dialogGlassBorder = if (isDark) Color.White.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.5f)
    val innerGlassCardColor = if (isDark) Color(0xFF1E293B).copy(alpha = 0.72f) else Color.White.copy(alpha = 0.72f)
    val innerGlassBorder = if (isDark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.85f)
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else SlateTextPrimary
    val textSecondary = if (isDark) Color(0xFFCBD5E1) else SlateTextSecondary
    val subtleDividerColor = if (isDark) Color.White.copy(alpha = 0.12f) else Color(0xFFE2E8F0).copy(alpha = 0.8f)

    val activeBannerBg by animateColorAsState(
        targetValue = if (isActive) {
            if (isDark) EmeraldSuccess.copy(alpha = 0.20f) else Color(0xFFECFDF5).copy(alpha = 0.90f)
        } else {
            if (isDark) RoseDanger.copy(alpha = 0.20f) else Color(0xFFFEF2F2).copy(alpha = 0.90f)
        },
        animationSpec = tween(300),
        label = "ActiveBannerBg"
    )
    val activeBannerBorder by animateColorAsState(
        targetValue = if (isActive) EmeraldSuccess.copy(alpha = 0.45f) else RoseDanger.copy(alpha = 0.45f),
        animationSpec = tween(300),
        label = "ActiveBannerBorder"
    )
    val activeStatusColor by animateColorAsState(
        targetValue = if (isActive) EmeraldSuccess else RoseDanger,
        animationSpec = tween(300),
        label = "ActiveStatusColor"
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.92f)
                    .shadow(
                        elevation = 18.dp,
                        shape = RoundedCornerShape(24.dp),
                        ambientColor = Color.Black.copy(alpha = 0.18f),
                        spotColor = PalestineGreen.copy(alpha = 0.15f)
                    ),
                shape = RoundedCornerShape(24.dp),
                color = dialogGlassColor,
                border = BorderStroke(1.dp, dialogGlassBorder),
                shadowElevation = 10.dp
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    PalestineGreen.copy(alpha = if (isDark) 0.10f else 0.05f),
                                    Color.Transparent,
                                    SkyBlue.copy(alpha = if (isDark) 0.08f else 0.04f)
                                )
                            )
                        )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 18.dp, vertical = 16.dp)
                    ) {
                        // 1. رأس النافذة الزجاجي الاحترافي
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .shadow(6.dp, CircleShape, spotColor = PalestineGreen.copy(alpha = 0.4f))
                                        .clip(CircleShape)
                                        .background(
                                            Brush.linearGradient(
                                                colors = listOf(PalestineGreen, EmeraldSuccess)
                                            )
                                        )
                                        .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Security,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = if (isEditMode) "إدارة الصلاحيات: @${user?.UserName}" else "إنشاء حساب مؤسسي (ABAC)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp,
                                            color = textPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        Surface(
                                            shape = CircleShape,
                                            color = PalestineGreen.copy(alpha = 0.14f),
                                            border = BorderStroke(0.5.dp, PalestineGreen.copy(alpha = 0.35f))
                                        ) {
                                            Text(
                                                text = if (isEditMode) "تعديل" else "جديد",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "العزل الجغرافي • القيود الزمنية • الوصول للشاشات • الأوامر الإجرائية",
                                        fontSize = 11.sp,
                                        color = textSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            Surface(
                                shape = CircleShape,
                                color = if (isDark) Color.White.copy(alpha = 0.08f) else Color(0xFFF1F5F9).copy(alpha = 0.8f),
                                border = BorderStroke(1.dp, innerGlassBorder),
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .clickable(onClick = onDismiss)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "إغلاق",
                                        tint = textSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // 2. بطاقة معلومات الحساب الأساسية الزجاجية (قابلة للطي بانسيابية لتوفير المساحة)
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = innerGlassCardColor,
                            border = BorderStroke(1.dp, innerGlassBorder),
                            shadowElevation = 2.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .animateContentSize(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                )
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // شريط عنوان البطاقة مع زر طي/توسيع أنيق
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { isAccountSectionExpanded = !isAccountSectionExpanded }
                                        .padding(vertical = 2.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.ManageAccounts,
                                            contentDescription = null,
                                            tint = PalestineGreen,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Text(
                                            text = "البيانات الأساسية والدور الوظيفي",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = textPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (!isAccountSectionExpanded && fullName.isNotBlank()) {
                                            Text(
                                                text = "• $fullName ($selectedRoleName)",
                                                fontSize = 11.sp,
                                                color = textSecondary,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    Icon(
                                        imageVector = if (isAccountSectionExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                                        contentDescription = null,
                                        tint = textSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                if (isAccountSectionExpanded) {
                                    // حقول الإدخال بتوزيع متجاوب يمنع تداخل أو انقطاع النصوص
                                    val fieldColors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = PalestineGreen,
                                        unfocusedBorderColor = if (isDark) Color.White.copy(alpha = 0.22f) else Color(0xFFCBD5E1),
                                        focusedContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.55f) else Color.White.copy(alpha = 0.78f),
                                        unfocusedContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.35f) else Color.White.copy(alpha = 0.55f),
                                        disabledContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.25f) else Color(0xFFF1F5F9).copy(alpha = 0.65f),
                                        focusedTextColor = textPrimary,
                                        unfocusedTextColor = textPrimary,
                                        focusedLabelColor = PalestineGreen,
                                        unfocusedLabelColor = textSecondary
                                    )

                                    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                                        if (maxWidth >= 560.dp) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                                            ) {
                                                OutlinedTextField(
                                                    value = fullName,
                                                    onValueChange = { fullName = it },
                                                    label = { Text("الاسم الكامل", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                    leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                                    modifier = Modifier.weight(1.25f),
                                                    singleLine = true,
                                                    shape = RoundedCornerShape(16.dp),
                                                    colors = fieldColors
                                                )
                                                OutlinedTextField(
                                                    value = username,
                                                    onValueChange = { username = it },
                                                    label = { Text("اسم المستخدم", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                    leadingIcon = { Icon(Icons.Rounded.AlternateEmail, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                                    enabled = !isEditMode,
                                                    modifier = Modifier.weight(1f),
                                                    singleLine = true,
                                                    shape = RoundedCornerShape(16.dp),
                                                    colors = fieldColors
                                                )
                                                OutlinedTextField(
                                                    value = password,
                                                    onValueChange = { password = it },
                                                    label = { Text(if (isEditMode) "كلمة المرور (تحديث)" else "كلمة المرور", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                    leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                                    modifier = Modifier.weight(1f),
                                                    singleLine = true,
                                                    shape = RoundedCornerShape(16.dp),
                                                    colors = fieldColors
                                                )
                                            }
                                        } else {
                                            Column(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                OutlinedTextField(
                                                    value = fullName,
                                                    onValueChange = { fullName = it },
                                                    label = { Text("الاسم الكامل", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                    leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, modifier = Modifier.size(18.dp)) },
                                                    modifier = Modifier.fillMaxWidth(),
                                                    singleLine = true,
                                                    shape = RoundedCornerShape(16.dp),
                                                    colors = fieldColors
                                                )
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    OutlinedTextField(
                                                        value = username,
                                                        onValueChange = { username = it },
                                                        label = { Text("اسم المستخدم", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                        leadingIcon = { Icon(Icons.Rounded.AlternateEmail, contentDescription = null, modifier = Modifier.size(17.dp)) },
                                                        enabled = !isEditMode,
                                                        modifier = Modifier.weight(1f),
                                                        singleLine = true,
                                                        shape = RoundedCornerShape(16.dp),
                                                        colors = fieldColors
                                                    )
                                                    OutlinedTextField(
                                                        value = password,
                                                        onValueChange = { password = it },
                                                        label = { Text(if (isEditMode) "كلمة المرور" else "كلمة المرور", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                        leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, modifier = Modifier.size(17.dp)) },
                                                        modifier = Modifier.weight(1f),
                                                        singleLine = true,
                                                        shape = RoundedCornerShape(16.dp),
                                                        colors = fieldColors
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    HorizontalDivider(color = subtleDividerColor)

                                    // فصل قسم الأدوار عن زر تفعيل الحساب تماماً لمنع التداخل
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Badge,
                                                contentDescription = null,
                                                tint = textSecondary,
                                                modifier = Modifier.size(15.dp)
                                            )
                                            Text(
                                                text = "الدور الوظيفي الأساسي:",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = textPrimary
                                            )
                                        }

                                        FlowRow(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            roles.forEach { role ->
                                                val isRoleSelected = selectedRoleId == role.RoleID
                                                val chipContainerColor by animateColorAsState(
                                                    targetValue = if (isRoleSelected) PalestineGreen.copy(alpha = 0.16f) else Color.Transparent,
                                                    animationSpec = tween(220),
                                                    label = "RoleChipBg"
                                                )
                                                FilterChip(
                                                    selected = isRoleSelected,
                                                    onClick = { selectedRoleId = role.RoleID },
                                                    label = {
                                                        Text(
                                                            text = role.RoleName,
                                                            fontSize = 11.sp,
                                                            fontWeight = if (isRoleSelected) FontWeight.Bold else FontWeight.Medium,
                                                            maxLines = 1
                                                        )
                                                    },
                                                    leadingIcon = if (isRoleSelected) {
                                                        {
                                                            Icon(
                                                                imageVector = Icons.Rounded.Check,
                                                                contentDescription = null,
                                                                modifier = Modifier.size(15.dp)
                                                            )
                                                        }
                                                    } else null,
                                                    shape = RoundedCornerShape(12.dp),
                                                    colors = FilterChipDefaults.filterChipColors(
                                                        selectedContainerColor = chipContainerColor,
                                                        selectedLabelColor = if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark,
                                                        selectedLeadingIconColor = if (isDark) Color(0xFF6EE7B7) else PalestineGreen
                                                    )
                                                )
                                            }
                                        }

                                        // شريط حالة تفعيل الحساب المنفصل بانسيابية
                                        Surface(
                                            shape = RoundedCornerShape(14.dp),
                                            color = activeBannerBg,
                                            border = BorderStroke(1.dp, activeBannerBorder),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(14.dp))
                                                .clickable { isActive = !isActive }
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    modifier = Modifier.weight(1f),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (isActive) Icons.Rounded.VerifiedUser else Icons.Rounded.Block,
                                                        contentDescription = null,
                                                        tint = activeStatusColor,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Text(
                                                        text = if (isActive) "الحساب نشط ومفعل للدخول" else "الحساب معطل وموقوف مؤقتاً",
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = activeStatusColor,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                                Switch(
                                                    checked = isActive,
                                                    onCheckedChange = { isActive = it },
                                                    colors = SwitchDefaults.colors(
                                                        checkedThumbColor = Color.White,
                                                        checkedTrackColor = EmeraldSuccess,
                                                        uncheckedThumbColor = Color.White,
                                                        uncheckedTrackColor = RoseDanger.copy(alpha = 0.65f)
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // 3. شريط التبويبات الزجاجي القابل للتمرير الأفقي لمنع التفاف أو انقطاع النصوص
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = innerGlassCardColor,
                            border = BorderStroke(1.dp, innerGlassBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(5.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                PermissionDialogTab.values().forEach { tab ->
                                    val isSelected = activeTab == tab
                                    val tabBg by animateColorAsState(
                                        targetValue = if (isSelected) PalestineGreen else Color.Transparent,
                                        animationSpec = tween(250),
                                        label = "TabBg"
                                    )
                                    val tabContentColor by animateColorAsState(
                                        targetValue = if (isSelected) Color.White else textSecondary,
                                        animationSpec = tween(250),
                                        label = "TabContent"
                                    )
                                    val tabBorderColor by animateColorAsState(
                                        targetValue = if (isSelected) Color.White.copy(alpha = 0.4f) else Color.Transparent,
                                        animationSpec = tween(250),
                                        label = "TabBorder"
                                    )

                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = tabBg,
                                        border = BorderStroke(1.dp, tabBorderColor),
                                        shadowElevation = if (isSelected) 3.dp else 0.dp,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { activeTab = tab }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = tab.icon,
                                                contentDescription = null,
                                                tint = tabContentColor,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = tab.title,
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                color = tabContentColor,
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // 4. محتوى التبويب المختار مع انتقال حركي انسيابي (AnimatedContent)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            AnimatedContent(
                                targetState = activeTab,
                                transitionSpec = {
                                    fadeIn(animationSpec = tween(240)) togetherWith fadeOut(animationSpec = tween(180))
                                },
                                label = "PermissionTabContentTransition"
                            ) { currentTab ->
                                when (currentTab) {
                                    PermissionDialogTab.TIME_RESTRICTIONS -> {
                                        TimeRestrictionsTabContent(
                                            accountExpiryTimestamp = accountExpiryTimestamp,
                                            onExpiryChanged = { accountExpiryTimestamp = it },
                                            maxLogins = maxLogins,
                                            onMaxLoginsChanged = { maxLogins = it },
                                            currentLogins = currentLogins,
                                            onResetLogins = { currentLogins = 0 },
                                            isDark = isDark
                                        )
                                    }
                                    PermissionDialogTab.GEOGRAPHIC_SCOPE -> {
                                        GeographicScopeTabContent(
                                            allLocalities = allLocalityNames,
                                            selectedLocalities = allowedLocalitiesSet,
                                            onToggleLocality = { loc ->
                                                val newSet = allowedLocalitiesSet.toMutableSet()
                                                if (newSet.contains(loc)) newSet.remove(loc) else newSet.add(loc)
                                                allowedLocalitiesSet = newSet
                                            },
                                            onSelectAllLocalities = {
                                                allowedLocalitiesSet = mutableSetOf() // فارغ = كل المحليات
                                            },
                                            sampleBranches = sampleBranches,
                                            selectedBranches = allowedBranchesSet,
                                            onToggleBranch = { branch ->
                                                val newSet = allowedBranchesSet.toMutableSet()
                                                if (newSet.contains(branch)) newSet.remove(branch) else newSet.add(branch)
                                                allowedBranchesSet = newSet
                                            },
                                            onSelectAllBranches = {
                                                allowedBranchesSet = mutableSetOf() // فارغ = كل الشعب
                                            },
                                            isDark = isDark
                                        )
                                    }
                                    PermissionDialogTab.SCREEN_ACCESS -> {
                                        ScreenAccessTabContent(
                                            selectedScreens = screenPermissionsSet,
                                            onToggleScreen = { screenId ->
                                                val newSet = screenPermissionsSet.toMutableSet()
                                                if (newSet.contains(screenId)) newSet.remove(screenId) else newSet.add(screenId)
                                                screenPermissionsSet = newSet
                                            },
                                            onSelectAllScreens = {
                                                screenPermissionsSet = AccessControlManager.ALL_SCREENS.map { it.first }.toMutableSet()
                                            },
                                            isDark = isDark
                                        )
                                    }
                                    PermissionDialogTab.ACTION_PERMISSIONS -> {
                                        ActionPermissionsTabContent(
                                            selectedActions = actionPermissionsSet,
                                            onToggleAction = { actionKey ->
                                                val newSet = actionPermissionsSet.toMutableSet()
                                                if (newSet.contains(actionKey)) newSet.remove(actionKey) else newSet.add(actionKey)
                                                actionPermissionsSet = newSet
                                            },
                                            onSelectAllActions = {
                                                actionPermissionsSet = AccessControlManager.ALL_ACTIONS.map { it.first }.toMutableSet()
                                            },
                                            isDark = isDark
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = subtleDividerColor)
                        Spacer(modifier = Modifier.height(10.dp))

                        // 5. شريط الملخص وأزرار الحفظ والإلغاء المتجاوب
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Shield,
                                    contentDescription = null,
                                    tint = PalestineGreen,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "الملخص: $selectedRoleName • ${screenPermissionsSet.size} شاشات • ${actionPermissionsSet.size} أوامر إجرائية",
                                    fontSize = 11.sp,
                                    color = textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = onDismiss,
                                    shape = CircleShape,
                                    border = BorderStroke(1.dp, if (isDark) Color.White.copy(alpha = 0.25f) else Color(0xFFCBD5E1))
                                ) {
                                    Text("إلغاء", color = textSecondary, fontSize = 12.sp)
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Button(
                                    onClick = {
                                        if (username.isNotBlank() && fullName.isNotBlank()) {
                                            val finalUser = (user ?: UserEntity(
                                                UserName = username.trim(),
                                                PasswordHash = password.trim().ifBlank { "123456" },
                                                fullName = fullName.trim(),
                                                RoleID = selectedRoleId,
                                                CreatedBy = "مدير النظام"
                                            )).copy(
                                                fullName = fullName.trim(),
                                                PasswordHash = if (password.isNotBlank()) password.trim() else (user?.PasswordHash ?: "123456"),
                                                RoleID = selectedRoleId,
                                                IsActive = isActive,
                                                // تحديث الصلاحيات المؤسسية والعزل الجغرافي
                                                allowedLocalities = allowedLocalitiesSet.toList(),
                                                allowedBranches = allowedBranchesSet.toList(),
                                                screenPermissions = screenPermissionsSet.toList(),
                                                actionPermissions = actionPermissionsSet.toList(),
                                                accountExpiryDate = accountExpiryTimestamp,
                                                maxLogins = maxLogins,
                                                currentLogins = currentLogins,
                                                AllowedScreens = screenPermissionsSet.joinToString(",")
                                            )
                                            onSave(finalUser)
                                        }
                                    },
                                    shape = CircleShape,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.Transparent,
                                        contentColor = Color.White
                                    ),
                                    contentPadding = PaddingValues(0.dp),
                                    modifier = Modifier
                                        .shadow(
                                            elevation = 6.dp,
                                            shape = CircleShape,
                                            spotColor = PalestineGreen.copy(alpha = 0.45f)
                                        )
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                brush = Brush.horizontalGradient(
                                                    colors = listOf(PalestineGreen, EmeraldSuccess)
                                                ),
                                                shape = CircleShape
                                            )
                                            .padding(horizontal = 18.dp, vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Text(
                                                text = if (isEditMode) "حفظ وتطبيق الصلاحيات" else "إنشاء وتفعيل الحساب",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = Color.White,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Tab 1: محتوى القيود الزمنية وحدود الجلسات
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TimeRestrictionsTabContent(
    accountExpiryTimestamp: Long,
    onExpiryChanged: (Long) -> Unit,
    maxLogins: Int,
    onMaxLoginsChanged: (Int) -> Unit,
    currentLogins: Int,
    onResetLogins: () -> Unit,
    isDark: Boolean
) {
    val scrollState = rememberScrollState()
    val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }

    val isExpired = accountExpiryTimestamp > 0L && System.currentTimeMillis() > accountExpiryTimestamp
    val daysRemaining = if (accountExpiryTimestamp > 0L && !isExpired) {
        ((accountExpiryTimestamp - System.currentTimeMillis()) / (1000 * 60 * 60 * 24)).toInt()
    } else null

    val textPrimary = if (isDark) Color(0xFFF8FAFC) else SlateTextPrimary
    val textSecondary = if (isDark) Color(0xFFCBD5E1) else SlateTextSecondary
    val glassSurface = if (isDark) Color(0xFF1E293B).copy(alpha = 0.72f) else Color.White.copy(alpha = 0.75f)
    val glassBorder = if (isDark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.85f)
    val dividerColor = if (isDark) Color.White.copy(alpha = 0.12f) else Color(0xFFE2E8F0).copy(alpha = 0.8f)

    val expiryCardColor by animateColorAsState(
        targetValue = if (isExpired) {
            if (isDark) RoseDanger.copy(alpha = 0.18f) else Color(0xFFFEF2F2).copy(alpha = 0.88f)
        } else {
            if (isDark) EmeraldSuccess.copy(alpha = 0.15f) else Color(0xFFECFDF5).copy(alpha = 0.85f)
        },
        animationSpec = tween(300),
        label = "ExpiryCardBg"
    )
    val expiryBorderColor by animateColorAsState(
        targetValue = if (isExpired) RoseDanger.copy(alpha = 0.45f) else EmeraldSuccess.copy(alpha = 0.45f),
        animationSpec = tween(300),
        label = "ExpiryCardBorder"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // بطاقة تاريخ انتهاء الصلاحية
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = expiryCardColor),
            border = BorderStroke(1.dp, expiryBorderColor),
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize(animationSpec = spring())
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isExpired) RoseDanger.copy(alpha = 0.18f) else EmeraldSuccess.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Event,
                                contentDescription = null,
                                tint = if (isExpired) RoseDanger else EmeraldSuccess,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "تاريخ انتهاء صلاحية الحساب",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = textPrimary
                            )
                            Text(
                                text = if (accountExpiryTimestamp <= 0L) "الحساب دائم وغير مقيد بتاريخ انتهاء"
                                else if (isExpired) "الحساب منتهي الصلاحية أمنياً"
                                else "ساري المفعول (ينتهي في ${sdf.format(Date(accountExpiryTimestamp))})",
                                fontSize = 11.sp,
                                color = if (isExpired) RoseDanger else if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark
                            )
                        }
                    }

                    if (daysRemaining != null) {
                        Surface(
                            shape = CircleShape,
                            color = EmeraldSuccess,
                            contentColor = Color.White
                        ) {
                            Text(
                                text = "متبقي $daysRemaining يوم",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(color = dividerColor)

                Text("خيارات التمديد والانتهاء السريع:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = textPrimary)

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = accountExpiryTimestamp == 0L,
                        onClick = { onExpiryChanged(0L) },
                        label = { Text("دائم (بدون انتهاء)", fontSize = 11.sp) },
                        leadingIcon = if (accountExpiryTimestamp == 0L) {
                            { Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        } else null,
                        shape = RoundedCornerShape(12.dp)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { onExpiryChanged(System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000) },
                        label = { Text("30 يوماً", fontSize = 11.sp) },
                        shape = RoundedCornerShape(12.dp)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { onExpiryChanged(System.currentTimeMillis() + 90L * 24 * 60 * 60 * 1000) },
                        label = { Text("90 يوماً", fontSize = 11.sp) },
                        shape = RoundedCornerShape(12.dp)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { onExpiryChanged(System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000) },
                        label = { Text("عام كامل", fontSize = 11.sp) },
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // بطاقة عداد مرات تسجيل الدخول المتبقية
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = glassSurface),
            border = BorderStroke(1.dp, glassBorder),
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize(animationSpec = spring())
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(SkyBlue.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Login,
                                contentDescription = null,
                                tint = SkyBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "رصيد تسجيلات الدخول المسموحة",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = textPrimary
                            )
                            Text(
                                text = "تقييد عدد مرات دخول المندوب أو الباحث الميداني للنظام",
                                fontSize = 11.sp,
                                color = textSecondary
                            )
                        }
                    }

                    if (maxLogins > 0) {
                        val remaining = (maxLogins - currentLogins).coerceAtLeast(0)
                        val quotaBadgeColor by animateColorAsState(
                            targetValue = if (remaining > 5) SkyBlue else RoseDanger,
                            animationSpec = tween(250),
                            label = "QuotaBadgeColor"
                        )
                        Surface(
                            shape = CircleShape,
                            color = quotaBadgeColor,
                            contentColor = Color.White
                        ) {
                            Text(
                                text = "المتبقي: $remaining / $maxLogins",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(color = dividerColor)

                val quotaFieldColors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PalestineGreen,
                    unfocusedBorderColor = if (isDark) Color.White.copy(alpha = 0.22f) else Color(0xFFCBD5E1),
                    focusedContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.55f) else Color.White.copy(alpha = 0.78f),
                    unfocusedContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.35f) else Color.White.copy(alpha = 0.55f),
                    disabledContainerColor = if (isDark) Color(0xFF0F172A).copy(alpha = 0.25f) else Color(0xFFF1F5F9).copy(alpha = 0.65f),
                    focusedTextColor = textPrimary,
                    unfocusedTextColor = textPrimary
                )

                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    if (maxWidth >= 460.dp) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = if (maxLogins == 0) "" else maxLogins.toString(),
                                onValueChange = { onMaxLoginsChanged(it.toIntOrNull() ?: 0) },
                                label = { Text("الحد الأقصى (0 = غير محدود)", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                modifier = Modifier.weight(1.2f),
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                colors = quotaFieldColors
                            )
                            OutlinedTextField(
                                value = currentLogins.toString(),
                                onValueChange = {},
                                enabled = false,
                                label = { Text("المستهلك", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                modifier = Modifier.weight(0.8f),
                                singleLine = true,
                                shape = RoundedCornerShape(16.dp),
                                colors = quotaFieldColors
                            )
                            FilledTonalButton(
                                onClick = onResetLogins,
                                shape = CircleShape
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تصفير", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedTextField(
                                    value = if (maxLogins == 0) "" else maxLogins.toString(),
                                    onValueChange = { onMaxLoginsChanged(it.toIntOrNull() ?: 0) },
                                    label = { Text("الحد الأقصى (0 = مفتوح)", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    modifier = Modifier.weight(1.2f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(16.dp),
                                    colors = quotaFieldColors
                                )
                                OutlinedTextField(
                                    value = currentLogins.toString(),
                                    onValueChange = {},
                                    enabled = false,
                                    label = { Text("المستهلك", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                    modifier = Modifier.weight(0.8f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(16.dp),
                                    colors = quotaFieldColors
                                )
                            }
                            FilledTonalButton(
                                onClick = onResetLogins,
                                shape = CircleShape,
                                modifier = Modifier.align(Alignment.End)
                            ) {
                                Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تصفير العداد", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Tab 2: محتوى النطاق الجغرافي (Row-Level Security)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GeographicScopeTabContent(
    allLocalities: List<String>,
    selectedLocalities: Set<String>,
    onToggleLocality: (String) -> Unit,
    onSelectAllLocalities: () -> Unit,
    sampleBranches: List<String>,
    selectedBranches: Set<String>,
    onToggleBranch: (String) -> Unit,
    onSelectAllBranches: () -> Unit,
    isDark: Boolean
) {
    val scrollState = rememberScrollState()
    val isAllLocalities = selectedLocalities.isEmpty() || selectedLocalities.contains("*")
    val isAllBranches = selectedBranches.isEmpty() || selectedBranches.contains("*")

    val textPrimary = if (isDark) Color(0xFFF8FAFC) else SlateTextPrimary
    val glassSurface = if (isDark) Color(0xFF1E293B).copy(alpha = 0.72f) else Color.White.copy(alpha = 0.75f)
    val glassBorder = if (isDark) Color.White.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.85f)
    val dividerColor = if (isDark) Color.White.copy(alpha = 0.12f) else Color(0xFFE2E8F0).copy(alpha = 0.8f)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // بطاقة المحليات المصرح برؤيتها
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = glassSurface),
            border = BorderStroke(1.dp, glassBorder),
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize(animationSpec = spring())
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.LocationOn,
                            contentDescription = null,
                            tint = PalestineGreen,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "1. المحليات المعتمدة المصرح برؤيتها",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = textPrimary
                            )
                            Text(
                                text = if (isAllLocalities) "نطاق مفتوح: مصرح برؤية وترشيح كافة المحليات"
                                else "مقيد بـ ${selectedLocalities.size} محليات فقط",
                                fontSize = 11.sp,
                                color = if (isAllLocalities) EmeraldSuccess else AmberWarning
                            )
                        }
                    }

                    TextButton(onClick = onSelectAllLocalities) {
                        Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isAllLocalities) "إلغاء التحديد" else "تحديد الكل",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                HorizontalDivider(color = dividerColor)

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    allLocalities.forEach { loc ->
                        val isChecked = isAllLocalities || selectedLocalities.contains(loc)
                        val locBgColor by animateColorAsState(
                            targetValue = if (isChecked) {
                                if (isDark) EmeraldSuccess.copy(alpha = 0.22f) else Color(0xFFECFDF5)
                            } else {
                                if (isDark) Color(0xFF0F172A).copy(alpha = 0.45f) else Color.White.copy(alpha = 0.7f)
                            },
                            animationSpec = tween(220),
                            label = "LocBg"
                        )
                        val locBorderColor by animateColorAsState(
                            targetValue = if (isChecked) EmeraldSuccess.copy(alpha = 0.6f) else glassBorder,
                            animationSpec = tween(220),
                            label = "LocBorder"
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = locBgColor,
                            border = BorderStroke(1.dp, locBorderColor),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onToggleLocality(loc) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { onToggleLocality(loc) },
                                    colors = CheckboxDefaults.colors(checkedColor = EmeraldSuccess)
                                )
                                Text(
                                    text = loc,
                                    fontSize = 11.sp,
                                    fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isChecked) (if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark) else textPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // بطاقة الشعب المصرح برؤيتها
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = glassSurface),
            border = BorderStroke(1.dp, glassBorder),
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize(animationSpec = spring())
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Place,
                            contentDescription = null,
                            tint = SkyBlue,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "2. الشعب الميدانية المصرح بها",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = textPrimary
                            )
                            Text(
                                text = if (isAllBranches) "نطاق مفتوح: مصرح بكافة الشعب والمخيمات"
                                else "مقيد بـ ${selectedBranches.size} شعبة ميدانية",
                                fontSize = 11.sp,
                                color = if (isAllBranches) EmeraldSuccess else AmberWarning
                            )
                        }
                    }

                    TextButton(onClick = onSelectAllBranches) {
                        Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isAllBranches) "إلغاء التحديد" else "تحديد الكل",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                HorizontalDivider(color = dividerColor)

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    sampleBranches.forEach { branch ->
                        val isChecked = isAllBranches || selectedBranches.contains(branch)
                        val chipBg by animateColorAsState(
                            targetValue = if (isChecked) EmeraldSuccess.copy(alpha = 0.16f) else Color.Transparent,
                            animationSpec = tween(200),
                            label = "BranchChipBg"
                        )
                        FilterChip(
                            selected = isChecked,
                            onClick = { onToggleBranch(branch) },
                            label = {
                                Text(
                                    text = branch,
                                    fontSize = 11.sp,
                                    fontWeight = if (isChecked) FontWeight.SemiBold else FontWeight.Normal
                                )
                            },
                            leadingIcon = if (isChecked) {
                                {
                                    Icon(
                                        imageVector = Icons.Rounded.Check,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = EmeraldSuccess
                                    )
                                }
                            } else null,
                            shape = RoundedCornerShape(12.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = chipBg,
                                selectedLabelColor = if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark
                            )
                        )
                    }
                }
            }
        }
    }
}

/**
 * Tab 3: محتوى الوصول للشاشات (Screen Access Toggles)
 */
@Composable
private fun ScreenAccessTabContent(
    selectedScreens: Set<String>,
    onToggleScreen: (String) -> Unit,
    onSelectAllScreens: () -> Unit,
    isDark: Boolean
) {
    val scrollState = rememberScrollState()
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else SlateTextPrimary

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الشاشات والوحدات المصرح بالدخول إليها:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = textPrimary,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onSelectAllScreens) {
                Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("منح الوصول للكل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        AccessControlManager.ALL_SCREENS.forEach { (screenKey, screenTitle) ->
            val isEnabled = selectedScreens.contains(screenKey)

            val cardBg by animateColorAsState(
                targetValue = if (isEnabled) {
                    if (isDark) EmeraldSuccess.copy(alpha = 0.16f) else Color(0xFFECFDF5).copy(alpha = 0.85f)
                } else {
                    if (isDark) RoseDanger.copy(alpha = 0.14f) else Color(0xFFFEF2F2).copy(alpha = 0.82f)
                },
                animationSpec = tween(260),
                label = "ScreenCardBg"
            )
            val cardBorder by animateColorAsState(
                targetValue = if (isEnabled) EmeraldSuccess.copy(alpha = 0.45f) else RoseDanger.copy(alpha = 0.40f),
                animationSpec = tween(260),
                label = "ScreenCardBorder"
            )
            val badgeBg by animateColorAsState(
                targetValue = if (isEnabled) EmeraldSuccess.copy(alpha = 0.18f) else RoseDanger.copy(alpha = 0.18f),
                animationSpec = tween(260),
                label = "ScreenBadgeBg"
            )
            val accentColor by animateColorAsState(
                targetValue = if (isEnabled) EmeraldSuccess else RoseDanger,
                animationSpec = tween(260),
                label = "ScreenAccent"
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = BorderStroke(1.dp, cardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize(animationSpec = spring())
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onToggleScreen(screenKey) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(badgeBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isEnabled) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = screenTitle,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = textPrimary
                            )
                            Text(
                                text = "معرف الشاشة: $screenKey • ${if (isEnabled) "مصرح بظهور الشاشة" else "محظورة ومخفية كلياً"}",
                                fontSize = 11.sp,
                                color = if (isEnabled) (if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark) else RoseDanger
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { onToggleScreen(screenKey) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = EmeraldSuccess,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = RoseDanger.copy(alpha = 0.65f)
                        )
                    )
                }
            }
        }
    }
}

/**
 * Tab 4: محتوى صلاحيات العمليات الدقيقة (Fine-grained Action Permissions)
 */
@Composable
private fun ActionPermissionsTabContent(
    selectedActions: Set<String>,
    onToggleAction: (String) -> Unit,
    onSelectAllActions: () -> Unit,
    isDark: Boolean
) {
    val scrollState = rememberScrollState()
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else SlateTextPrimary
    val textSecondary = if (isDark) Color(0xFFCBD5E1) else SlateTextSecondary

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الأوامر والصلاحيات الإجرائية الدقيقة (CRUD):",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = textPrimary,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onSelectAllActions) {
                Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("منح الكل", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        AccessControlManager.ALL_ACTIONS.forEach { (actionKey, actionDesc) ->
            val isGranted = selectedActions.contains(actionKey)

            val actionIcon = when (actionKey) {
                AccessControlManager.ACTION_ADD -> Icons.Rounded.AddCircle
                AccessControlManager.ACTION_EDIT -> Icons.Rounded.Edit
                AccessControlManager.ACTION_DELETE -> Icons.Rounded.Delete
                AccessControlManager.ACTION_EXPORT -> Icons.Rounded.FileDownload
                AccessControlManager.ACTION_DELIVER -> Icons.Rounded.LocalShipping
                AccessControlManager.ACTION_NOMINATE -> Icons.Rounded.CheckCircle
                else -> Icons.Rounded.Security
            }

            val cardBg by animateColorAsState(
                targetValue = if (isGranted) {
                    if (isDark) EmeraldSuccess.copy(alpha = 0.16f) else Color(0xFFECFDF5).copy(alpha = 0.85f)
                } else {
                    if (isDark) RoseDanger.copy(alpha = 0.14f) else Color(0xFFFEF2F2).copy(alpha = 0.82f)
                },
                animationSpec = tween(260),
                label = "ActionCardBg"
            )
            val cardBorder by animateColorAsState(
                targetValue = if (isGranted) EmeraldSuccess.copy(alpha = 0.45f) else RoseDanger.copy(alpha = 0.40f),
                animationSpec = tween(260),
                label = "ActionCardBorder"
            )
            val accentColor by animateColorAsState(
                targetValue = if (isGranted) EmeraldSuccess else RoseDanger,
                animationSpec = tween(260),
                label = "ActionAccent"
            )

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = BorderStroke(1.dp, cardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize(animationSpec = spring())
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onToggleAction(actionKey) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(accentColor.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = actionIcon,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = actionKey,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isGranted) (if (isDark) Color(0xFF6EE7B7) else PalestineGreenDark) else RoseDanger
                                )
                                Surface(
                                    shape = CircleShape,
                                    color = accentColor,
                                    contentColor = Color.White
                                ) {
                                    Text(
                                        text = if (isGranted) "مصرّح" else "محظور",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = actionDesc,
                                fontSize = 11.sp,
                                color = textSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Switch(
                        checked = isGranted,
                        onCheckedChange = { onToggleAction(actionKey) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = EmeraldSuccess,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = RoseDanger.copy(alpha = 0.65f)
                        )
                    )
                }
            }
        }
    }
}
