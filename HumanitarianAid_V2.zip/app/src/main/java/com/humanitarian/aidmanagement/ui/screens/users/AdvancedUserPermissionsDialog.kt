package com.humanitarian.aidmanagement.ui.screens.users

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.RoleEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

enum class PermissionDialogTab(val title: String, val icon: String) {
    TIME_RESTRICTIONS("القيود الزمنية", "⏱️"),
    GEOGRAPHIC_SCOPE("النطاق الجغرافي", "📍"),
    SCREEN_ACCESS("الوصول للشاشات", "🖥️"),
    ACTION_PERMISSIONS("صلاحيات العمليات", "⚡")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdvancedUserPermissionsDialog(
    user: UserEntity?, // null = إضافة مستخدم جديد, non-null = تعديل مستخدم قائم
    roles: List<RoleEntity>,
    localities: List<LocalityEntity>,
    groups: List<String>,
    onDismiss: () -> Unit,
    onSave: (UserEntity) -> Unit
) {
    var activeTab by remember { mutableStateOf(PermissionDialogTab.TIME_RESTRICTIONS) }

    // الحقول الأساسية
    var username by remember { mutableStateOf(user?.UserName ?: "") }
    var password by remember { mutableStateOf(user?.PasswordHash ?: "") }
    var fullName by remember { mutableStateOf(user?.fullName ?: "") }
    var selectedRoleId by remember { mutableStateOf(user?.RoleID ?: (roles.firstOrNull()?.RoleID ?: 2)) }
    var isActive by remember { mutableStateOf(user?.IsActive ?: true) }

    // Tab 1: القيود الزمنية ومرات الدخول
    var accountExpiryTimestamp by remember { mutableStateOf(user?.accountExpiryDate ?: 0L) }
    var maxLogins by remember { mutableStateOf(user?.maxLogins ?: 0) }
    var currentLogins by remember { mutableStateOf(user?.currentLogins ?: 0) }

    // Tab 2: النطاق الجغرافي (محليات وشعب)
    val allLocalityNames = remember(localities) {
        val names = localities.map { it.LocalityName.trim() }.filter { it.isNotBlank() }
        if (names.isEmpty()) listOf("شمال غزة", "غزة", "دير البلح والوسطى", "خان يونس", "رفح") else names
    }
    var allowedLocalitiesSet by remember {
        mutableStateOf(user?.allowedLocalities?.toMutableSet() ?: mutableSetOf())
    }

    val sampleBranches = remember {
        listOf(
            "الشاطئ", "الرمال", "الشيخ رضوان", "التفاح والدرج", "الشجاعية", "الزيتون", "تل الهوا",
            "مخيم جباليا", "جباليا البلد", "بيت لاهيا", "بيت حانون",
            "النصيرات", "البريج", "المغازي", "دير البلح", "الزويدة",
            "خانيونس البلد", "المعسكر", "القرارة", "بني سهيلا", "الفخاري",
            "تل السلطان", "الشابورة", "الجنينة", "يبنا", "حي السلام"
        )
    }
    var allowedBranchesSet by remember {
        mutableStateOf(user?.allowedBranches?.toMutableSet() ?: mutableSetOf())
    }

    // Tab 3: الوصول للشاشات
    var screenPermissionsSet by remember {
        mutableStateOf(
            if (user != null) {
                user.screenPermissions.toMutableSet().ifEmpty {
                    user.AllowedScreens.split(",").map { it.trim().lowercase() }.filter { it.isNotBlank() }.toMutableSet()
                }
            } else {
                mutableSetOf("dashboard", "families", "nomination", "delivery", "reports")
            }
        )
    }

    // Tab 4: صلاحيات العمليات الدقيقة
    var actionPermissionsSet by remember {
        mutableStateOf(
            if (user != null) {
                user.actionPermissions.toMutableSet()
            } else {
                mutableSetOf(
                    AccessControlManager.ACTION_ADD,
                    AccessControlManager.ACTION_EDIT,
                    AccessControlManager.ACTION_EXPORT
                )
            }
        )
    }

    val isEditMode = user != null
    val selectedRoleName = roles.firstOrNull { it.RoleID == selectedRoleId }?.RoleName ?: "مستخدم"

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.95f)
                    .fillMaxHeight(0.92f)
                    .clip(RoundedCornerShape(20.dp)),
                color = PalestineWhite,
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // 1. رأس النافذة الاحترافي مع بطاقة المستخدم
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(PalestineGreenContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = PalestineGreen,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = if (isEditMode) "إدارة الصلاحيات: @${user?.UserName}" else "إنشاء حساب بنظام الصلاحيات المؤسسي (ABAC)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = SlateTextPrimary
                                    )
                                    Text("🇵🇸", fontSize = 16.sp)
                                }
                                Text(
                                    text = "العزل الجغرافي • القيود الزمنية • الأوامر الإجرائية • حماية العمليات",
                                    fontSize = 11.sp,
                                    color = SlateTextSecondary
                                )
                            }
                        }

                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = SlateTextSecondary)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2. بطاقة معلومات الحساب الأساسية
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SlateSurfaceVariant.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorderLight),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = fullName,
                                    onValueChange = { fullName = it },
                                    label = { Text("الاسم الكامل", fontSize = 11.sp) },
                                    modifier = Modifier.weight(1.2f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                OutlinedTextField(
                                    value = username,
                                    onValueChange = { username = it },
                                    label = { Text("اسم المستخدم", fontSize = 11.sp) },
                                    enabled = !isEditMode, // لا يتم تعديل اسم المستخدم عند التحرير
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                OutlinedTextField(
                                    value = password,
                                    onValueChange = { password = it },
                                    label = { Text(if (isEditMode) "كلمة المرور (تحديث)" else "كلمة المرور", fontSize = 11.sp) },
                                    modifier = Modifier.weight(1f),
                                    singleLine = true,
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("الدور الأساسي:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateTextPrimary)
                                    roles.forEach { role ->
                                        FilterChip(
                                            selected = selectedRoleId == role.RoleID,
                                            onClick = { selectedRoleId = role.RoleID },
                                            label = { Text(role.RoleName, fontSize = 10.sp) },
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = if (isActive) "الحساب نشط ومفعل" else "الحساب معطل",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isActive) PalestineGreenDark else PalestineRed
                                    )
                                    Switch(
                                        checked = isActive,
                                        onCheckedChange = { isActive = it },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = PalestineWhite,
                                            checkedTrackColor = PalestineGreen,
                                            uncheckedThumbColor = PalestineWhite,
                                            uncheckedTrackColor = PalestineRed.copy(alpha = 0.5f)
                                        )
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3. شريط التبويبات الأربعة (4 Tabs)
                    TabRow(
                        selectedTabIndex = activeTab.ordinal,
                        containerColor = PalestineWhite,
                        contentColor = PalestineGreen,
                        divider = { HorizontalDivider(color = SlateBorderLight) }
                    ) {
                        PermissionDialogTab.values().forEach { tab ->
                            val isSelected = activeTab == tab
                            Tab(
                                selected = isSelected,
                                onClick = { activeTab = tab },
                                text = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(tab.icon, fontSize = 13.sp)
                                        Text(
                                            text = tab.title,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) PalestineGreenDark else SlateTextSecondary
                                        )
                                    }
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4. محتوى التبويب المختار
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        when (activeTab) {
                            PermissionDialogTab.TIME_RESTRICTIONS -> {
                                TimeRestrictionsTabContent(
                                    accountExpiryTimestamp = accountExpiryTimestamp,
                                    onExpiryChanged = { accountExpiryTimestamp = it },
                                    maxLogins = maxLogins,
                                    onMaxLoginsChanged = { maxLogins = it },
                                    currentLogins = currentLogins,
                                    onResetLogins = { currentLogins = 0 }
                                )
                            }
                            PermissionDialogTab.GEOGRAPHIC_SCOPE -> {
                                GeographicScopeTabContent(
                                    allLocalities = allLocalityNames,
                                    selectedLocalities = allowedLocalitiesSet,
                                    onToggleLocality = { loc ->
                                        val newSet = allowedLocalitiesSet.toMutableSet()
                                        if (newSet.contains(loc)) newSet.remove(loc) else newSet.add(loc)
                                        allowedLocalitiesSet = newSet
                                    },
                                    onSelectAllLocalities = {
                                        allowedLocalitiesSet = mutableSetOf() // فارغ = كل المحليات
                                    },
                                    sampleBranches = sampleBranches,
                                    selectedBranches = allowedBranchesSet,
                                    onToggleBranch = { branch ->
                                        val newSet = allowedBranchesSet.toMutableSet()
                                        if (newSet.contains(branch)) newSet.remove(branch) else newSet.add(branch)
                                        allowedBranchesSet = newSet
                                    },
                                    onSelectAllBranches = {
                                        allowedBranchesSet = mutableSetOf() // فارغ = كل الشعب
                                    }
                                )
                            }
                            PermissionDialogTab.SCREEN_ACCESS -> {
                                ScreenAccessTabContent(
                                    selectedScreens = screenPermissionsSet,
                                    onToggleScreen = { screenId ->
                                        val newSet = screenPermissionsSet.toMutableSet()
                                        if (newSet.contains(screenId)) newSet.remove(screenId) else newSet.add(screenId)
                                        screenPermissionsSet = newSet
                                    },
                                    onSelectAllScreens = {
                                        screenPermissionsSet = AccessControlManager.ALL_SCREENS.map { it.first }.toMutableSet()
                                    }
                                )
                            }
                            PermissionDialogTab.ACTION_PERMISSIONS -> {
                                ActionPermissionsTabContent(
                                    selectedActions = actionPermissionsSet,
                                    onToggleAction = { actionKey ->
                                        val newSet = actionPermissionsSet.toMutableSet()
                                        if (newSet.contains(actionKey)) newSet.remove(actionKey) else newSet.add(actionKey)
                                        actionPermissionsSet = newSet
                                    },
                                    onSelectAllActions = {
                                        actionPermissionsSet = AccessControlManager.ALL_ACTIONS.map { it.first }.toMutableSet()
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = SlateBorderLight)
                    Spacer(modifier = Modifier.height(10.dp))

                    // 5. شريط أزرار الحفظ والإلغاء
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نظام الأمان المؤسسي: ${selectedRoleName} • ${screenPermissionsSet.size} شاشات • ${actionPermissionsSet.size} أوامر إجرائية",
                            fontSize = 11.sp,
                            color = SlateTextSecondary
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onDismiss,
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("إلغاء", color = SlateTextSecondary)
                            }

                            Button(
                                onClick = {
                                    if (username.isNotBlank() && fullName.isNotBlank()) {
                                        val finalUser = (user ?: UserEntity(
                                            UserName = username.trim(),
                                            PasswordHash = password.trim().ifBlank { "123456" },
                                            fullName = fullName.trim(),
                                            RoleID = selectedRoleId,
                                            CreatedBy = "مدير النظام"
                                        )).copy(
                                            fullName = fullName.trim(),
                                            PasswordHash = if (password.isNotBlank()) password.trim() else (user?.PasswordHash ?: "123456"),
                                            RoleID = selectedRoleId,
                                            IsActive = isActive,
                                            // تحديث الصلاحيات المؤسسية والعزل الجغرافي
                                            allowedLocalities = allowedLocalitiesSet.toList(),
                                            allowedBranches = allowedBranchesSet.toList(),
                                            screenPermissions = screenPermissionsSet.toList(),
                                            actionPermissions = actionPermissionsSet.toList(),
                                            accountExpiryDate = accountExpiryTimestamp,
                                            maxLogins = maxLogins,
                                            currentLogins = currentLogins,
                                            AllowedScreens = screenPermissionsSet.joinToString(",")
                                        )
                                        onSave(finalUser)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = PalestineWhite, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (isEditMode) "حفظ وتطبيق الصلاحيات" else "إنشاء الحساب وتفعيل الصلاحيات", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Tab 1: محتوى القيود الزمنية وحدود الجلسات
 */
@Composable
private fun TimeRestrictionsTabContent(
    accountExpiryTimestamp: Long,
    onExpiryChanged: (Long) -> Unit,
    maxLogins: Int,
    onMaxLoginsChanged: (Int) -> Unit,
    currentLogins: Int,
    onResetLogins: () -> Unit
) {
    val scrollState = rememberScrollState()
    val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }

    val isExpired = accountExpiryTimestamp > 0L && System.currentTimeMillis() > accountExpiryTimestamp
    val daysRemaining = if (accountExpiryTimestamp > 0L && !isExpired) {
        ((accountExpiryTimestamp - System.currentTimeMillis()) / (1000 * 60 * 60 * 24)).toInt()
    } else null

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // بطاقة تاريخ انتهاء الصلاحية
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = if (isExpired) PalestineRedLight else PalestineGreenLight.copy(alpha = 0.5f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, if (isExpired) PalestineRed.copy(alpha = 0.4f) else PalestineGreen.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = null,
                            tint = if (isExpired) PalestineRed else PalestineGreenDark
                        )
                        Column {
                            Text(
                                text = "تاريخ انتهاء صلاحية الحساب (Account Expiration)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateTextPrimary
                            )
                            Text(
                                text = if (accountExpiryTimestamp <= 0L) "الحساب دائم وغير مقيد بتاريخ انتهاء" 
                                       else if (isExpired) "الحساب منتهي الصلاحية أمنياً" 
                                       else "ساري المفعول (ينتهي في ${sdf.format(Date(accountExpiryTimestamp))})",
                                fontSize = 11.sp,
                                color = if (isExpired) PalestineRed else PalestineGreenDark
                            )
                        }
                    }

                    if (daysRemaining != null) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PalestineGreen,
                            contentColor = PalestineWhite
                        ) {
                            Text(
                                text = "متبقي $daysRemaining يوم",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(color = SlateBorderLight)

                Text("خيارات التمديد والانتهاء السريع:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateTextPrimary)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = accountExpiryTimestamp == 0L,
                        onClick = { onExpiryChanged(0L) },
                        label = { Text("دائم (بدون انتهاء)", fontSize = 10.sp) },
                        shape = RoundedCornerShape(6.dp)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { onExpiryChanged(System.currentTimeMillis() + 30L * 24 * 60 * 60 * 1000) },
                        label = { Text("30 يوماً", fontSize = 10.sp) },
                        shape = RoundedCornerShape(6.dp)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { onExpiryChanged(System.currentTimeMillis() + 90L * 24 * 60 * 60 * 1000) },
                        label = { Text("90 يوماً", fontSize = 10.sp) },
                        shape = RoundedCornerShape(6.dp)
                    )
                    FilterChip(
                        selected = false,
                        onClick = { onExpiryChanged(System.currentTimeMillis() + 365L * 24 * 60 * 60 * 1000) },
                        label = { Text("عام كامل", fontSize = 10.sp) },
                        shape = RoundedCornerShape(6.dp)
                    )
                }
            }
        }

        // بطاقة عداد مرات تسجيل الدخول المتبقية
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.Login, contentDescription = null, tint = Color(0xFF2563EB))
                        Column {
                            Text(
                                text = "رصيد تسجيلات الدخول المسموحة (Max Logins Quota)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateTextPrimary
                            )
                            Text(
                                text = "تقييد عدد مرات دخول المندوب أو الباحث الميداني للنظام",
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }
                    }

                    if (maxLogins > 0) {
                        val remaining = (maxLogins - currentLogins).coerceAtLeast(0)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (remaining > 5) Color(0xFF2563EB) else PalestineRed,
                            contentColor = PalestineWhite
                        ) {
                            Text(
                                text = "المتبقي: $remaining من $maxLogins",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                HorizontalDivider(color = SlateBorderLight)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = if (maxLogins == 0) "" else maxLogins.toString(),
                        onValueChange = { onMaxLoginsChanged(it.toIntOrNull() ?: 0) },
                        label = { Text("الحد الأقصى (0 = غير محدود)", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    OutlinedTextField(
                        value = currentLogins.toString(),
                        onValueChange = {},
                        enabled = false,
                        label = { Text("الدخول المستهلك", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Button(
                        onClick = onResetLogins,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2E8F0), contentColor = SlateTextPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("تصفير العداد", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

/**
 * Tab 2: محتوى النطاق الجغرافي (Row-Level Security)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun GeographicScopeTabContent(
    allLocalities: List<String>,
    selectedLocalities: Set<String>,
    onToggleLocality: (String) -> Unit,
    onSelectAllLocalities: () -> Unit,
    sampleBranches: List<String>,
    selectedBranches: Set<String>,
    onToggleBranch: (String) -> Unit,
    onSelectAllBranches: () -> Unit
) {
    val scrollState = rememberScrollState()
    val isAllLocalities = selectedLocalities.isEmpty() || selectedLocalities.contains("*")
    val isAllBranches = selectedBranches.isEmpty() || selectedBranches.contains("*")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // بطاقة المحليات المصرح برؤيتها
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("1. المحليات المعتمدة المصرح برؤيتها (Allowed Localities)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateTextPrimary)
                        Text(if (isAllLocalities) "نطاق مفتوح: مصرح برؤية وترشيح كافة المحليات" else "مقيد بـ ${selectedLocalities.size} محليات فقط", fontSize = 11.sp, color = if (isAllLocalities) PalestineGreenDark else Color(0xFFD97706))
                    }

                    TextButton(onClick = onSelectAllLocalities) {
                        Text(if (isAllLocalities) "إلغاء التحديد العام" else "تحديد كافة المحليات", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider(color = SlateBorderLight)

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    allLocalities.forEach { loc ->
                        val isChecked = isAllLocalities || selectedLocalities.contains(loc)
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isChecked) PalestineGreenLight else PalestineWhite,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isChecked) PalestineGreen else SlateBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onToggleLocality(loc) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { onToggleLocality(loc) },
                                    colors = CheckboxDefaults.colors(checkedColor = PalestineGreen)
                                )
                                Text(
                                    text = loc,
                                    fontSize = 11.sp,
                                    fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isChecked) PalestineGreenDark else SlateTextPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // بطاقة الشعب المصرح برؤيتها
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("2. الشعب الميدانية المصرح بها (Allowed Branches)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateTextPrimary)
                        Text(if (isAllBranches) "نطاق مفتوح: مصرح بكافة الشعب والمخيمات" else "مقيد بـ ${selectedBranches.size} شعبة ميدانية", fontSize = 11.sp, color = if (isAllBranches) PalestineGreenDark else Color(0xFFD97706))
                    }

                    TextButton(onClick = onSelectAllBranches) {
                        Text(if (isAllBranches) "إلغاء التحديد العام" else "تحديد كافة الشعب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider(color = SlateBorderLight)

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    sampleBranches.forEach { branch ->
                        val isChecked = isAllBranches || selectedBranches.contains(branch)
                        FilterChip(
                            selected = isChecked,
                            onClick = { onToggleBranch(branch) },
                            label = { Text(branch, fontSize = 10.sp) },
                            leadingIcon = {
                                if (isChecked) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp), tint = PalestineGreen)
                                }
                            },
                            shape = RoundedCornerShape(6.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Tab 3: محتوى الوصول للشاشات (Screen Access Toggles)
 */
@Composable
private fun ScreenAccessTabContent(
    selectedScreens: Set<String>,
    onToggleScreen: (String) -> Unit,
    onSelectAllScreens: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الشاشات والوحدات المصرح بالدخول إليها في التطبيق:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SlateTextPrimary
            )
            TextButton(onClick = onSelectAllScreens) {
                Text("منح الوصول لكافة الشاشات", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        AccessControlManager.ALL_SCREENS.forEach { (screenKey, screenTitle) ->
            val isEnabled = selectedScreens.contains(screenKey)
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isEnabled) PalestineGreenLight.copy(alpha = 0.5f) else PalestineRedLight.copy(alpha = 0.3f)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isEnabled) PalestineGreen.copy(alpha = 0.4f) else PalestineRed.copy(alpha = 0.3f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleScreen(screenKey) }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isEnabled) PalestineGreenContainer else PalestineRedLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isEnabled) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = if (isEnabled) PalestineGreen else PalestineRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Text(
                                text = screenTitle,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateTextPrimary
                            )
                            Text(
                                text = "معرف الشاشة: $screenKey • ${if (isEnabled) "مصرح بظهور الشاشة واستخدامها" else "محظورة ومخفية كلياً"}",
                                fontSize = 11.sp,
                                color = if (isEnabled) PalestineGreenDark else PalestineRed
                            )
                        }
                    }

                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { onToggleScreen(screenKey) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = PalestineWhite,
                            checkedTrackColor = PalestineGreen,
                            uncheckedThumbColor = PalestineWhite,
                            uncheckedTrackColor = PalestineRed.copy(alpha = 0.5f)
                        )
                    )
                }
            }
        }
    }
}

/**
 * Tab 4: محتوى صلاحيات العمليات الدقيقة (Fine-grained Action Permissions)
 */
@Composable
private fun ActionPermissionsTabContent(
    selectedActions: Set<String>,
    onToggleAction: (String) -> Unit,
    onSelectAllActions: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "الأوامر والصلاحيات الإجرائية الدقيقة (CRUD & Actions):",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SlateTextPrimary
            )
            TextButton(onClick = onSelectAllActions) {
                Text("منح كافة الصلاحيات الإجرائية", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        AccessControlManager.ALL_ACTIONS.forEach { (actionKey, actionDesc) ->
            val isGranted = selectedActions.contains(actionKey)

            val actionIcon = when (actionKey) {
                AccessControlManager.ACTION_ADD -> Icons.Default.AddCircle
                AccessControlManager.ACTION_EDIT -> Icons.Default.Edit
                AccessControlManager.ACTION_DELETE -> Icons.Default.Delete
                AccessControlManager.ACTION_EXPORT -> Icons.Default.FileDownload
                AccessControlManager.ACTION_DELIVER -> Icons.Default.LocalShipping
                AccessControlManager.ACTION_NOMINATE -> Icons.Default.CheckCircle
                else -> Icons.Default.Security
            }

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isGranted) PalestineGreenLight.copy(alpha = 0.5f) else PalestineRedLight.copy(alpha = 0.3f)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isGranted) PalestineGreen.copy(alpha = 0.4f) else PalestineRed.copy(alpha = 0.3f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleAction(actionKey) }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isGranted) PalestineGreenContainer else PalestineRedLight),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = actionIcon,
                                contentDescription = null,
                                tint = if (isGranted) PalestineGreen else PalestineRed,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = actionKey,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isGranted) PalestineGreenDark else PalestineRed
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (isGranted) PalestineGreen else PalestineRed,
                                    contentColor = PalestineWhite
                                ) {
                                    Text(
                                        text = if (isGranted) "مصرّح" else "محظور",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = actionDesc,
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }
                    }

                    Switch(
                        checked = isGranted,
                        onCheckedChange = { onToggleAction(actionKey) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = PalestineWhite,
                            checkedTrackColor = PalestineGreen,
                            uncheckedThumbColor = PalestineWhite,
                            uncheckedTrackColor = PalestineRed.copy(alpha = 0.5f)
                        )
                    )
                }
            }
        }
    }
}
