package com.humanitarian.aidmanagement.data.repository

import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.dao.*
import com.humanitarian.aidmanagement.data.local.entities.*
import com.humanitarian.aidmanagement.engine.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.Locale

class AidRepository(
    private val database: AidDatabase,
    private val nominationEngine: NominationEngine = NominationEngine(
        database.familyDao(),
        database.childDao(),
        database.aidRecordDao(),
        database.nominationDao(),
        database.localityDao(),
        database.systemSettingDao()
    )
) {
    private val _currentUserFlow = MutableStateFlow<UserEntity?>(null)
    val currentUserFlow: StateFlow<UserEntity?> = _currentUserFlow.asStateFlow()

    private val _currentUserPermissionsFlow = MutableStateFlow<Set<String>>(emptySet())
    val currentUserPermissionsFlow: StateFlow<Set<String>> = _currentUserPermissionsFlow.asStateFlow()

    @get:JvmName("currentUserProperty")
    @set:JvmName("setCurrentUserProperty")
    var currentUser: UserEntity? = null
        get() = field ?: _currentUserFlow.value

    private var currentUserLocalityIds: List<Int> = emptyList()

    suspend fun setCurrentUser(user: UserEntity?, localityIds: List<Int>) {
        this.currentUser = user
        this.currentUserLocalityIds = localityIds
        this._currentUserFlow.value = user

        if (user != null) {
            if (user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true)) {
                _currentUserPermissionsFlow.value = setOf(
                    "families_view", "families_create", "families_edit", "families_delete", "families_export",
                    "children_view", "children_manage",
                    "nomination_run", "nomination_manual", "nomination_criteria", "nomination_approve",
                    "delivery_view", "delivery_handover", "delivery_receipt_print", "delivery_undo", "delivery_scanner",
                    "projects_manage", "warehouse_manage",
                    "reports_view", "reports_pdf_export", "print",
                    "users_manage", "permissions_edit", "security_policies", "audit_logs_view",
                    "backup_restore", "sync_manage", "settings_edit"
                )
            } else {
                val dbPermissions = database.userDao().getGrantedPermissionKeys(user.UserID)
                _currentUserPermissionsFlow.value = dbPermissions.toSet()
            }
        } else {
            _currentUserPermissionsFlow.value = emptySet()
        }
    }

    fun setCurrentUserSync(user: UserEntity?, localityIds: List<Int>) {
        this.currentUser = user
        this.currentUserLocalityIds = localityIds
        this._currentUserFlow.value = user
        if (user != null && (user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true))) {
            _currentUserPermissionsFlow.value = setOf(
                "families_view", "families_create", "families_edit", "families_delete", "families_export",
                "children_view", "children_manage",
                "nomination_run", "nomination_manual", "nomination_criteria", "nomination_approve",
                "delivery_view", "delivery_handover", "delivery_receipt_print", "delivery_undo", "delivery_scanner",
                "projects_manage", "warehouse_manage",
                "reports_view", "reports_pdf_export", "print",
                "users_manage", "permissions_edit", "security_policies", "audit_logs_view",
                "backup_restore", "sync_manage", "settings_edit"
            )
        } else if (user == null) {
            _currentUserPermissionsFlow.value = emptySet()
        }
    }

    fun logout() {
        setCurrentUserSync(null, emptyList())
    }

    fun getCurrentUser(): UserEntity? = currentUser ?: _currentUserFlow.value
    fun getCurrentUserLocalityIds(): List<Int> = currentUserLocalityIds

    fun isSuperAdmin():
