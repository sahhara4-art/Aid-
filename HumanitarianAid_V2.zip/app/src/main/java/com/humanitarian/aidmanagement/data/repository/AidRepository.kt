package com.humanitarian.aidmanagement.data.repository

import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.dao.*
import com.humanitarian.aidmanagement.data.local.entities.*
import com.humanitarian.aidmanagement.engine.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.Locale

class AidRepository(
    private val database: AidDatabase,
    private val nominationEngine: NominationEngine = NominationEngine(database)
) {
    // المستخدم الحالي المسجل وحالته التفاعلية
    private val _currentUserFlow = MutableStateFlow<UserEntity?>(null)
    val currentUserFlow: StateFlow<UserEntity?> = _currentUserFlow.asStateFlow()

    private val _currentUserPermissionsFlow = MutableStateFlow<Set<String>>(emptySet())
    val currentUserPermissionsFlow: StateFlow<Set<String>> = _currentUserPermissionsFlow.asStateFlow()

    @get:JvmName("currentUserProperty")
    @set:JvmName("setCurrentUserProperty")
    var currentUser: UserEntity? = null
        get() = field ?: _currentUserFlow.value

    private var currentUserLocalityIds: List<Int> = emptyList()

    suspend fun setCurrentUser(user: UserEntity?, localityIds: List<Int>) {
        this.currentUser = user
        this.currentUserLocalityIds = localityIds
        this._currentUserFlow.value = user

        if (user != null) {
            if (user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true)) {
                // مدير النظام العام يحصل على كافة الصلاحيات بدون أي استثناء
                _currentUserPermissionsFlow.value = setOf(
                    "families_view", "families_create", "families_edit", "families_delete", "families_export",
                    "children_view", "children_manage",
                    "nomination_run", "nomination_manual", "nomination_criteria", "nomination_approve",
                    "delivery_view", "delivery_handover", "delivery_receipt_print", "delivery_undo", "delivery_scanner",
                    "projects_manage", "warehouse_manage",
                    "reports_view", "reports_pdf_export", "print",
                    "users_manage", "permissions_edit", "security_policies", "audit_logs_view",
                    "backup_restore", "sync_manage", "settings_edit"
                )
            } else {
                val dbPermissions = database.userDao().getGrantedPermissionKeys(user.UserID)
                _currentUserPermissionsFlow.value = dbPermissions.toSet()
            }
        } else {
            _currentUserPermissionsFlow.value = emptySet()
        }
    }

    fun setCurrentUserSync(user: UserEntity?, localityIds: List<Int>) {
        this.currentUser = user
        this.currentUserLocalityIds = localityIds
        this._currentUserFlow.value = user
        if (user != null && (user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true))) {
            _currentUserPermissionsFlow.value = setOf(
                "families_view", "families_create", "families_edit", "families_delete", "families_export",
                "children_view", "children_manage",
                "nomination_run", "nomination_manual", "nomination_criteria", "nomination_approve",
                "delivery_view", "delivery_handover", "delivery_receipt_print", "delivery_undo", "delivery_scanner",
                "projects_manage", "warehouse_manage",
                "reports_view", "reports_pdf_export", "print",
                "users_manage", "permissions_edit", "security_policies", "audit_logs_view",
                "backup_restore", "sync_manage", "settings_edit"
            )
        } else if (user == null) {
            _currentUserPermissionsFlow.value = emptySet()
        }
    }

    fun logout() {
        setCurrentUserSync(null, emptyList())
    }

    fun getCurrentUser(): UserEntity? = currentUser ?: _currentUserFlow.value
    fun getCurrentUserLocalityIds(): List<Int> = currentUserLocalityIds

    fun isSuperAdmin(): Boolean {
        val user = getCurrentUser() ?: return false
        return user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true)
    }

    fun hasPermission(permissionKey: String): Boolean {
        if (isSuperAdmin()) return true
        return _currentUserPermissionsFlow.value.contains(permissionKey)
    }

    fun canManageAllLocalities(): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        if (user.AllowedLocalityID != 0) return false
        return currentUserLocalityIds.contains(0) || currentUserLocalityIds.isEmpty()
    }

    fun canAccessLocality(localityId: Int): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        if (user.AllowedLocalityID != 0) {
            return user.AllowedLocalityID == localityId
        }
        if (currentUserLocalityIds.isNotEmpty() && !currentUserLocalityIds.contains(0)) {
            return currentUserLocalityIds.contains(localityId)
        }
        return true
    }

    fun getAllowedLocalitiesFlow(): Flow<List<LocalityEntity>> {
        return database.localityDao().getAllLocalities().map { list ->
            val user = getCurrentUser()
            val allowedLoc = user?.AllowedLocalityID ?: 0
            if (allowedLoc != 0 && !isSuperAdmin()) {
                list.filter { it.LocalityID == allowedLoc }
            } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
                list.filter { currentUserLocalityIds.contains(it.LocalityID) }
            } else {
                list
            }
        }
    }

    suspend fun getAllowedLocalitiesSync(): List<LocalityEntity> = withContext(Dispatchers.IO) {
        val all = database.localityDao().getAllLocalitiesSync()
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        if (allowedLoc != 0 && !isSuperAdmin()) {
            all.filter { it.LocalityID == allowedLoc }
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            all.filter { currentUserLocalityIds.contains(it.LocalityID) }
        } else {
            all
        }
    }

    fun canModifyFamily(family: FamilyEntity): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val hasEditPerm = hasPermission("families_edit") || hasPermission("family_edit") || hasPermission("families_manage")
        if (!hasEditPerm) return false
        if (!canAccessLocality(family.localityID)) return false
        return canUserEditFamily(family)
    }

    fun canDeleteFamily(family: FamilyEntity): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val hasDeletePerm = hasPermission("families_delete") || hasPermission("family_delete") || hasPermission("families_manage")
        if (!hasDeletePerm) return false
        if (!canAccessLocality(family.localityID)) return false
        return canUserDeleteFamily(family)
    }

    fun canAddFamilyInLocality(localityId: Int): Boolean {
        if (isSuperAdmin()) return true
        val hasCreatePerm = hasPermission("families_create") || hasPermission("families_manage")
        if (!hasCreatePerm) return false
        return canAccessLocality(localityId)
    }

    fun canAccessScreen(screenRoute: String): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val allowedScreens = user.AllowedScreens.split(",").map { it.trim().lowercase() }
        val normalizedRoute = screenRoute.lowercase()
        return allowedScreens.contains(normalizedRoute) || allowedScreens.contains("*")
    }

    fun getAllowedScreensForCurrentUser(): Set<String> {
        val user = getCurrentUser() ?: return emptySet()
        if (isSuperAdmin()) return setOf("dashboard", "families", "nomination", "delivery", "reports", "excel_import_export", "users", "backup")
        return user.AllowedScreens.split(",").map { it.trim().lowercase() }.toSet()
    }

    fun getAllowedGroupForCurrentUser(): String {
        return getCurrentUser()?.AllowedGroup ?: "كافة المجموعات"
    }

    fun getAvailableGroups(): List<String> = listOf(
        "كافة المجموعات",
        "مجموعة الشمال أ (إغاثة عاجلة)",
        "مجموعة مدينة غزة ب (توزيع رئيسي)",
        "مجموعة الوسطى ودير البلح ج (إيواء)",
        "مجموعة خان يونس د (ميداني)",
        "مجموعة رفح هـ (مخيمات)",
        "فريق الإسناد والطوارئ و"
    )

    fun canUserViewSubArea(subArea: String?): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val allowed = user.AllowedViewSubAreas
        if (allowed == "*" || allowed.isBlank()) return true
        if (subArea.isNullOrBlank()) return true
        val allowedList = allowed.split(",").map { it.trim().lowercase() }
        val target = subArea.trim().lowercase()
        return allowedList.contains("*") || allowedList.contains(target) || allowedList.any { it.isNotEmpty() && (target.contains(it) || it.contains(target)) }
    }

    fun canUserEditFamily(family: FamilyEntity): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val hasEditPerm = hasPermission("family_edit") || hasPermission("families_manage") || hasPermission("families_edit") || user.RoleID == 1
        if (!hasEditPerm) return false
        val allowed = user.AllowedEditSubAreas
        if (allowed == "*" || allowed.isBlank()) return true
        val target = family.currentSubArea.trim().lowercase()
        if (target.isBlank()) return true
        val allowedList = allowed.split(",").map { it.trim().lowercase() }
        return allowedList.contains("*") || allowedList.contains(target) || allowedList.any { it.isNotEmpty() && (target.contains(it) || it.contains(target)) }
    }

    fun canUserDeleteFamily(family: FamilyEntity): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val hasDeletePerm = hasPermission("family_delete") || hasPermission("families_manage") || hasPermission("families_delete") || user.RoleID == 1
        if (!hasDeletePerm) return false
        val allowed = user.AllowedEditSubAreas
        if (allowed == "*" || allowed.isBlank()) return true
        val target = family.currentSubArea.trim().lowercase()
        if (target.isBlank()) return true
        val allowedList = allowed.split(",").map { it.trim().lowercase() }
        return allowedList.contains("*") || allowedList.contains(target) || allowedList.any { it.isNotEmpty() && (target.contains(it) || it.contains(target)) }
    }

    fun getFamilies(query: String = "", localityId: Int? = null, shelterStatus: String? = null): Flow<List<FamilyEntity>> {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val effectiveLocalityId = if (allowedLoc != 0 && !isSuperAdmin()) {
            allowedLoc
        } else if (localityId != null && localityId != 0) {
            localityId
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            currentUserLocalityIds.first()
        } else {
            0
        }
        return database.familyDao().searchFamilies(query, effectiveLocalityId, shelterStatus).map { list ->
            if (isSuperAdmin()) {
                list
            } else {
                list.filter { canAccessLocality(it.localityID) && canUserViewSubArea(it.currentSubArea) }
            }
        }
    }

    suspend fun getFamiliesPaged(
        query: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null,
        limit: Int = 50,
        offset: Int = 0
    ): List<FamilyEntity> = withContext(Dispatchers.IO) {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val effectiveLocalityId = if (allowedLoc != 0 && !isSuperAdmin()) {
            allowedLoc
        } else if (localityId != null && localityId != 0) {
            localityId
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            currentUserLocalityIds.first()
        } else {
            0
        }
        val pagedList = database.familyDao().searchFamiliesPaged(
            query = query.trim(),
            localityId = effectiveLocalityId,
            shelterStatus = shelterStatus,
            limit = limit,
            offset = offset
        )
        if (isSuperAdmin()) {
            pagedList
        } else {
            pagedList.filter { canAccessLocality(it.localityID) && canUserViewSubArea(it.currentSubArea) }
        }
    }

    suspend fun getFamiliesCount(
        query: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null
    ): Int = withContext(Dispatchers.IO) {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val effectiveLocalityId = if (allowedLoc != 0 && !isSuperAdmin()) {
            allowedLoc
        } else if (localityId != null && localityId != 0) {
            localityId
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            currentUserLocalityIds.first()
        } else {
            0
        }
        database.familyDao().countFamiliesSearch(query.trim(), effectiveLocalityId, shelterStatus)
    }

    fun getFamiliesCountFlow(
        query: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null
    ): Flow<Int> {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val effectiveLocalityId = if (allowedLoc != 0 && !isSuperAdmin()) {
            allowedLoc
        } else if (localityId != null && localityId != 0) {
            localityId
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            currentUserLocalityIds.first()
        } else {
            0
        }
        return database.familyDao().countFamiliesSearchFlow(query.trim(), effectiveLocalityId, shelterStatus)
    }

    suspend fun resolveLocalityId(
        rawInput: String?,
        subAreaHint: String? = null
    ): Int? = withContext(Dispatchers.IO) {
        val allLocalities = database.localityDao().getAllLocalitiesSync().map { it.LocalityID to it.LocalityName }
        val result = com.humanitarian.aidmanagement.util.ExcelParserHelper.resolveLocalityStrict(rawInput, allLocalities)
        if (!result.isError && result.localityId != null) {
            return@withContext result.localityId
        }

        if (!subAreaHint.isNullOrBlank()) {
            val subResult = com.humanitarian.aidmanagement.util.ExcelParserHelper.resolveLocalityStrict(subAreaHint, allLocalities)
            if (!subResult.isError && subResult.localityId != null) {
                return@withContext subResult.localityId
            }
        }

        val currentUser = getCurrentUser()
        if ((currentUser?.AllowedLocalityID ?: 0) != 0 && !isSuperAdmin()) {
            return@withContext currentUser!!.AllowedLocalityID
        }

        null
    }

    suspend fun getOrCreateLocalityId(localityName: String): Int = withContext(Dispatchers.IO) {
        resolveLocalityId(localityName) ?: 1
    }

    suspend fun getFamilyByNationalId(nationalId: String): FamilyEntity? = withContext(Dispatchers.IO) {
        database.familyDao().getFamilyByNationalId(nationalId.trim())
    }

    suspend fun insertFamily(family: FamilyEntity): Long {
        val id = database.familyDao().insertFamily(family)
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "FAMILY",
            operation = "INSERT",
            recordId = id.toString(),
            payloadJson = "{\"name\":\"${family.name}\",\"nationalID\":\"${family.nationalID}\",\"members\":${family.familyMembersCount}}"
        )
        return id
    }

    suspend fun updateFamily(family: FamilyEntity) {
        database.familyDao().updateFamily(family)
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "FAMILY",
            operation = "UPDATE",
            recordId = family.familyID.toString(),
            payloadJson = "{\"name\":\"${family.name}\",\"nationalID\":\"${family.nationalID}\"}"
        )
    }

    suspend fun deleteFamily(family: FamilyEntity) {
        database.familyDao().deleteFamily(family)
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "FAMILY",
            operation = "DELETE",
            recordId = family.familyID.toString(),
            payloadJson = "{}"
        )
    }

    suspend fun getAllFamiliesSync(): List<FamilyEntity> {
        return database.familyDao().getAllFamiliesSync()
    }

    suspend fun getLastAidForFamily(familyId: Long): AidRecordEntity? {
        return database.aidRecordDao().getLastAidForFamily(familyId)
    }

    fun getFamilyById(id: Long): Flow<FamilyEntity?> = database.familyDao().getFamilyByIdFlow(id)
    suspend fun getFamilyByIdSync(id: Long): FamilyEntity? = database.familyDao().getFamilyById(id)
    fun getAidRecordsForFamily(familyId: Long): Flow<List<AidRecordEntity>> = database.aidRecordDao().getAidRecordsForFamilyFlow(familyId)
    suspend fun getAidRecordsForFamilySync(familyId: Long): List<AidRecordEntity> = database.aidRecordDao().getAidRecordsForFamily(familyId)

    fun getChildrenByFamily(familyNationalId: String): Flow<List<ChildEntity>> {
        return database.childDao().getChildrenByFamilyNationalId(familyNationalId)
    }

    fun searchChildren(query: String): Flow<List<ChildEntity>> {
        return database.childDao().searchChildren(query)
    }

    suspend fun insertChild(child: ChildEntity): Long {
        return database.childDao().insertChild(child)
    }

    suspend fun deleteChild(child: ChildEntity) {
        database.childDao().deleteChild(child)
    }

    fun getActiveAidTypes(): Flow<List<AidTypeEntity>> = database.aidTypeDao().getAllActiveAidTypes()
    fun getActiveProjects(): Flow<List<ProjectEntity>> = database.projectDao().getAllActiveProjects()
    fun getLocalities(): Flow<List<LocalityEntity>> = database.localityDao().getAllLocalities()
    fun getDistributions(): Flow<List<LocalityDistributionEntity>> = database.localityDao().getDistributions()

    suspend fun insertProject(project: ProjectEntity): Long = database.projectDao().insertProject(project)

    suspend fun getProjectById(projectId: Long): ProjectEntity? = withContext(Dispatchers.IO) {
        database.projectDao().getProjectById(projectId)
    }

    suspend fun getProjectsWithStats(): List<ProjectWithStats> = withContext(Dispatchers.IO) {
        val projects = database.projectDao().getAllActiveProjectsSync()
        val aidTypes = database.aidTypeDao().getAllActiveAidTypesSync().associateBy { it.aidTypeID }
        val allRecords = database.aidRecordDao().getAllAidRecordsSync()
        val allFamilies = database.familyDao().getAllFamiliesSync().associateBy { it.familyID }

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocRestricted = allowedLoc != 0 && !isSuperAdmin()

        val targetProjects = if (isLocRestricted) {
            projects.filter { prj ->
                val prjRecords = allRecords.filter { it.projectID == prj.projectID }
                prjRecords.any { rec -> allFamilies[rec.familyID]?.localityID == allowedLoc }
            }
        } else {
            projects
        }

        targetProjects.map { prj ->
            val prjRecords = allRecords.filter { rec ->
                rec.projectID == prj.projectID && (!isLocRestricted || allFamilies[rec.familyID]?.localityID == allowedLoc)
            }
            val candCount = prjRecords.size
            val delivCount = prjRecords.count { it.recipientStatus == "مستلم" || it.recipientStatus == "مستفيد" || it.deliveryDate != null }
            val typeName = aidTypes[prj.aidTypeID]?.aidTypeName ?: "مساعدة عامة"
            ProjectWithStats(
                project = prj,
                aidTypeName = typeName,
                candidatesCount = candCount,
                deliveredCount = delivCount
            )
        }
    }

    suspend fun getProjectBeneficiaries(projectId: Long): List<ProjectBeneficiaryItem> = withContext(Dispatchers.IO) {
        val records = database.aidRecordDao().getAidRecordsForProjectSync(projectId)
        val allFamilies = database.familyDao().getAllFamiliesSync().associateBy { it.familyID }

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocRestricted = allowedLoc != 0 && !isSuperAdmin()

        records
            .filter { rec ->
                !isLocRestricted || (allFamilies[rec.familyID]?.localityID == allowedLoc)
            }
            .map { rec ->
                val fam = allFamilies[rec.familyID]
                ProjectBeneficiaryItem(
                    recordId = rec.aidRecordID,
                    familyId = rec.familyID,
                    familyName = fam?.name ?: "مستفيد #${rec.familyID}",
                    nationalId = fam?.nationalID ?: "",
                    phone = fam?.primaryPhone ?: "",
                    subArea = fam?.currentSubArea ?: "",
                    membersCount = fam?.familyMembersCount ?: 1,
                    status = rec.recipientStatus,
                    deliveryDate = rec.deliveryDate,
                    stageUserName = rec.stageUserName ?: "النظام"
                )
            }
    }

    suspend fun getDashboardStats(): DashboardStats = withContext(Dispatchers.IO) {
        val totalFamilies = database.familyDao().getTotalFamiliesCount()
        val totalBeneficiaries = database.familyDao().getTotalBeneficiariesCount() ?: 0
        val eligibleFamilies = database.familyDao().getExactEligibleFamiliesTotal()
        val eligibleBeneficiaries = database.familyDao().getEligibleBeneficiariesTotal() ?: 0
        val totalAidRecords = database.aidRecordDao().getTotalEligibleAidRecordsCount()
        val totalProjects = database.projectDao().getTotalProjectsCount()
        val totalSelected = database.nominationDao().getTotalSelectedCount()
        val distinctBeneficiaries = database.aidRecordDao().getDistinctEligibleBeneficiariesCount()

        DashboardStats(
            totalFamilies = totalFamilies,
            totalBeneficiaries = totalBeneficiaries,
            totalAidRecords = totalAidRecords,
            totalProjects = totalProjects,
            totalSelectedCandidates = totalSelected,
            distinctBeneficiaries = distinctBeneficiaries,
            eligibleFamilies = eligibleFamilies,
            eligibleBeneficiaries = eligibleBeneficiaries
        )
    }

    suspend fun getLocalityDistributionStats(): List<LocalityDistributionStat> = withContext(Dispatchers.IO) {
        val localities: List<LocalityEntity> = database.localityDao().getAllLocalities().first()
        val distributions: List<LocalityDistributionEntity> = database.localityDao().getDistributions().first()
        
        val eligibleCountsMap = database.familyDao().getEligibleFamiliesCountGroupedByLocality().associate { it.localityID to it.count }
        val totalCountsMap = database.familyDao().getTotalFamiliesCountGroupedByLocality().associate { it.localityID to it.count }
        val deliveredCountsMap = database.aidRecordDao().getEligibleDeliveredCountGroupedByLocality().associate { it.localityID to it.deliveredCount }

        localities.map { loc: LocalityEntity ->
            val dist = distributions.find { it.localityID == loc.LocalityID }
            val quota: Double = dist?.distributionPercentage ?: (100.0 / localities.size.coerceAtLeast(1))
            val eligibleInLoc: Int = eligibleCountsMap[loc.LocalityID] ?: 0
            val totalInLoc: Int = totalCountsMap[loc.LocalityID] ?: 0
            val deliveredCount: Int = deliveredCountsMap[loc.LocalityID] ?: 0
            
            val completion: Int = if (eligibleInLoc > 0) {
                ((deliveredCount.toDouble() / eligibleInLoc.toDouble()) * 100).toInt().coerceIn(0, 100)
            } else if (totalInLoc > 0) {
                ((deliveredCount.toDouble() / totalInLoc.toDouble()) * 100).toInt().coerceIn(0, 100)
            } else 0

            LocalityDistributionStat(
                localityId = loc.LocalityID,
                localityName = loc.LocalityName,
                quotaPercent = quota,
                deliveredAidCount = deliveredCount,
                familiesCount = eligibleInLoc,
                completionPercent = completion
            )
        }
    }

    suspend fun getSubAreaDistributionRatios(): List<SubAreaShareRecord> = withContext(Dispatchers.IO) {
        database.familyDao().calculateSubAreaDistributionRatios()
    }

    suspend fun calculateSubAreaBenefitRatios(): List<SubAreaBenefitRatioStat> = withContext(Dispatchers.IO) {
        val subAreas = database.familyDao().getAllSubAreasSync()
        if (subAreas.isNotEmpty()) {
            subAreas.map { subArea ->
                val eligibleCount = database.familyDao().getEligibleFamiliesCountForSubArea(subArea)
                val totalCount = database.familyDao().getTotalFamiliesCountForSubArea(subArea)
                val deliveredCount = database.aidRecordDao().getDeliveredBeneficiariesCountForSubArea(subArea)
                val ratio = if (eligibleCount > 0) {
                    ((deliveredCount.toDouble() / eligibleCount.toDouble()) * 100.0).coerceIn(0.0, 100.0)
                } else 0.0

                SubAreaBenefitRatioStat(
                    subAreaName = subArea,
                    eligibleFamiliesCount = eligibleCount,
                    totalFamiliesCount = totalCount,
                    deliveredBeneficiariesCount = deliveredCount,
                    ratioPercentage = ratio,
                    formattedRatio = String.format(Locale.US, "%.1f%%", ratio)
                )
            }
        } else {
            val localities = database.localityDao().getAllLocalities().first()
            val eligibleMap = database.familyDao().getEligibleFamiliesCountGroupedByLocality().associate { it.localityID to it.count }
            val totalMap = database.familyDao().getTotalFamiliesCountGroupedByLocality().associate { it.localityID to it.count }
            val deliveredMap = database.aidRecordDao().getEligibleDeliveredCountGroupedByLocality().associate { it.localityID to it.deliveredCount }

            localities.map { loc ->
                val eligibleCount = eligibleMap[loc.LocalityID] ?: 0
                val totalCount = totalMap[loc.LocalityID] ?: 0
                val deliveredCount = deliveredMap[loc.LocalityID] ?: 0
                val ratio = if (eligibleCount > 0) {
                    ((deliveredCount.toDouble() / eligibleCount.toDouble()) * 100.0).coerceIn(0.0, 100.0)
                } else 0.0

                SubAreaBenefitRatioStat(
                    subAreaName = loc.LocalityName,
                    eligibleFamiliesCount = eligibleCount,
                    totalFamiliesCount = totalCount,
                    deliveredBeneficiariesCount = deliveredCount,
                    ratioPercentage = ratio,
                    formattedRatio = String.format(Locale.US, "%.1f%%", ratio)
                )
            }
        }
    }

    suspend fun getFamiliesByLocalitySync(localityId: Int): List<FamilyEntity> = withContext(Dispatchers.IO) {
        database.familyDao().getFamiliesByLocalitySync(localityId)
    }

    suspend fun getFamiliesByLocalitySync(locality: String): List<FamilyEntity> = withContext(Dispatchers.IO) {
        database.familyDao().getFamiliesByLocalitySync(locality)
    }

    suspend fun getAidTypeDistributionStats(): List<AidTypeDistributionStat> = withContext(Dispatchers.IO) {
        val types: List<AidTypeEntity> = database.aidTypeDao().getAllActiveAidTypes().first()
        val deliveryStats = database.aidRecordDao().getEligibleDeliveriesGroupedByAidType().associateBy { it.aidTypeID }

        val colorPalette: List<Long> = listOf(
            0xFF10B981L, 0xFF84CC16L, 0xFFEF4444L, 0xFFF59E0BL,
            0xFF6366F1L, 0xFF06B6D4L, 0xFF8B5CF6L, 0xFFEC4899L,
            0xFF14B8A6L, 0xFF3B82F6L, 0xFFF97316L
        )

        val totalDelivered = deliveryStats.values.sumOf { it.deliveryCount }
        val avgTargetPerType = if (types.isNotEmpty() && totalDelivered > 0) {
            (totalDelivered / types.size).coerceAtLeast(1)
        } else {
            50
        }

        types.mapIndexed { index: Int, type: AidTypeEntity ->
            val record = deliveryStats[type.aidTypeID]
            val count: Int = record?.deliveryCount ?: 0
            val colorIndex: Int = index % colorPalette.size
            AidTypeDistributionStat(
                aidTypeId = type.aidTypeID,
                aidTypeName = type.aidTypeName,
                deliveredCount = count,
                quotaTarget = avgTargetPerType,
                colorHex = colorPalette[colorIndex]
            )
        }
    }

    suspend fun getEligibleFamiliesForManual(localityId: Int?): List<FamilyEntity> {
        val families = database.familyDao().getEligibleFamiliesForNomination(localityId)
        return if (canManageAllLocalities()) {
            families
        } else {
            families.filter { currentUserLocalityIds.contains(it.localityID) }
        }
    }

    suspend fun addManualSelection(familyId: Long, aidTypeId: Int, projectId: Long, userId: Int) {
        val selection = ManualSelectionEntity(
            CitizenID = familyId,
            SelectionDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()),
            UserID = userId,
            AidTypeID = aidTypeId,
            ProjectID = projectId
        )
        database.nominationDao().insertManualSelection(selection)
    }

    suspend fun removeManualSelection(familyId: Long, aidTypeId: Int, projectId: Long) {
        database.nominationDao().removeManualSelection(familyId, aidTypeId, projectId)
    }

    suspend fun clearManualSelections(aidTypeId: Int, projectId: Long) {
        database.nominationDao().clearManualSelections(aidTypeId, projectId)
    }

    suspend fun runNomination(
        localityId: Int?,
        aidTypeIds: List<Int>,
        projectId: Long,
        requiredCount: Int,
        customExclusionDays: Int = 30
    ): List<NominationCandidate> {
        val userId = currentUser?.UserID ?: 1
        return nominationEngine.executeFullNomination(
            localityId = localityId,
            aidTypeIds = aidTypeIds,
            projectId = projectId,
            requiredCount = requiredCount,
            userId = userId,
            allowedLocalityIds = currentUserLocalityIds,
            customExclusionDays = customExclusionDays
        )
    }

    suspend fun runNomination(
        localityId: Int?,
        aidTypeId: Int,
        projectId: Long,
        requiredCount: Int
    ): List<NominationCandidate> {
        return runNomination(
            localityId = localityId,
            aidTypeIds = listOf(aidTypeId),
            projectId = projectId,
            requiredCount = requiredCount,
            customExclusionDays = 30
        )
    }

    suspend fun calculateQuotas(totalRequired: Int): List<LocalityQuota> {
        val distributions = database.localityDao().getDistributions().first()
        val localities = database.localityDao().getAllLocalities().first().associate { it.LocalityID to it.LocalityName }
        return nominationEngine.calculateLocalityQuotas(totalRequired, distributions, localities)
    }

    private var latestCandidatesCache: List<NominationCandidate>? = null

    fun getLatestNominatedCandidates(): List<NominationCandidate>? = latestCandidatesCache

    suspend fun runNominationWithCriteria(
        localityId: Int?,
        criteria: com.humanitarian.aidmanagement.engine.NominationCriteria,
        projectId: Long,
        requiredCount: Int
    ): List<NominationCandidate> {
        val userId = currentUser?.UserID ?: 1
        val results = nominationEngine.executeCriteriaNomination(
            localityId = localityId,
            criteria = criteria,
            projectId = projectId,
            requiredCount = requiredCount,
            userId = userId,
            allowedLocalityIds = currentUserLocalityIds
        )
        latestCandidatesCache = results
        return results
    }

    val dynamicNominationEngine by lazy {
        com.humanitarian.aidmanagement.engine.DynamicNominationEngine(database)
    }

    suspend fun runDynamicNomination(
        criteria: com.humanitarian.aidmanagement.engine.DynamicNominationCriteria
    ): com.humanitarian.aidmanagement.engine.DynamicNominationResult {
        return dynamicNominationEngine.runDynamicNomination(criteria)
    }

    suspend fun approveDynamicNomination(
        candidates: List<com.humanitarian.aidmanagement.engine.DynamicCandidateModel>,
        projectId: Long,
        aidTypeId: Int
    ): Int {
        val userId = currentUser?.UserID ?: 1
        return dynamicNominationEngine.approveNominationBatch(candidates, projectId, aidTypeId, userId)
    }

    fun getActiveNominationWorkflows(): Flow<List<NominationWorkflowEntity>> = 
        database.nominationWorkflowDao().getActiveWorkflows()

    suspend fun getNominationWorkflowByProject(projectId: Long): NominationWorkflowEntity? = 
        database.nominationWorkflowDao().getWorkflowByProject(projectId)

    suspend fun saveNominationWorkflow(workflow: NominationWorkflowEntity): Long = 
        database.nominationWorkflowDao().insertWorkflow(workflow)

    suspend fun updateNominationWorkflow(workflow: NominationWorkflowEntity) = 
        database.nominationWorkflowDao().updateWorkflow(workflow)

    suspend fun deleteNominationWorkflow(id: Long) = 
        database.nominationWorkflowDao().deleteWorkflow(id)

    fun getProjectQuotas(projectId: Long): Flow<List<ProjectQuotaEntity>> = 
        database.projectQuotaDao().getQuotasByProject(projectId)

    suspend fun getProjectQuotasSync(projectId: Long): List<ProjectQuotaEntity> = 
        database.projectQuotaDao().getQuotasByProjectSync(projectId)

    suspend fun saveProjectQuotas(quotas: List<ProjectQuotaEntity>) = 
        database.projectQuotaDao().insertQuotas(quotas)

    suspend fun deleteProjectQuotas(projectId: Long) = 
        database.projectQuotaDao().deleteQuotasByProject(projectId)

    suspend fun dispatchNominatedAid(
        candidates: List<NominationCandidate>,
        dispatchInfo: com.humanitarian.aidmanagement.engine.ProjectDispatchInfo
    ) {
        val userId = currentUser?.UserID ?: 1
        val selectedEntities = candidates.map {
            SelectedCitizenEntity(
                CitizenID = it.family.familyID,
                SelectionDate = dispatchInfo.nominationDate,
                SelectionType = it.selectionType,
                AidTypeID = dispatchInfo.targetAidTypeId,
                ProjectID = dispatchInfo.projectNumber.filter { c -> c.isDigit() }.toLongOrNull() ?: 1L,
                UserID = userId
            )
        }
        database.nominationDao().insertSelectedCitizens(selectedEntities)

        val parsedVal = dispatchInfo.aidValue.filter { c -> c.isDigit() || c == '.' }.toDoubleOrNull() ?: 50.0
        candidates.forEach { candidate ->
            val aidRecord = AidRecordEntity(
                familyID = candidate.family.familyID,
                aidTypeID = dispatchInfo.targetAidTypeId,
                projectID = dispatchInfo.projectNumber.filter { c -> c.isDigit() }.toLongOrNull() ?: 1L,
                aidDate = dispatchInfo.nominationDate,
                selectionDate = dispatchInfo.nominationDate,
                deliveryDate = dispatchInfo.nominationDate,
                recipientStatus = "معتمد للترحيل والتسليم",
                warehouse = dispatchInfo.warehouseName,
                aidValue = parsedVal,
                notes = "المشروع: ${dispatchInfo.projectNumber} - الممول: ${dispatchInfo.fundingOrganization} - نوع المساعدة: ${dispatchInfo.aidTypeName}"
            )
            database.aidRecordDao().insertAidRecord(aidRecord)
        }
    }

    suspend fun confirmAndCommitNomination(
        candidates: List<NominationCandidate>,
        aidTypeId: Int,
        projectId: Long
    ) {
        val userId = currentUser?.UserID ?: 1
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())

        val selectedEntities = candidates.map {
            SelectedCitizenEntity(
                CitizenID = it.family.familyID,
                SelectionDate = today,
                SelectionType = it.selectionType,
                AidTypeID = aidTypeId,
                ProjectID = projectId,
                UserID = userId
            )
        }
        database.nominationDao().insertSelectedCitizens(selectedEntities)

        candidates.forEach { candidate ->
            val aidRecord = AidRecordEntity(
                familyID = candidate.family.familyID,
                aidTypeID = aidTypeId,
                projectID = projectId,
                aidDate = today,
                selectionDate = today,
                recipientStatus = "مرشح",
                warehouse = "المستودع المركزي",
                aidValue = 50.0
            )
            database.aidRecordDao().insertAidRecord(aidRecord)
        }

        database.nominationDao().clearManualSelections(aidTypeId, projectId)
    }

    fun getAllAidRecords(): Flow<List<AidRecordEntity>> = database.aidRecordDao().getAllAidRecords()

    suspend fun deliverAid(recordId: Long, recipientName: String?, notes: String? = null) {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        if (allowedLoc != 0 && !isSuperAdmin()) {
            val record = database.aidRecordDao().getAidRecordById(recordId)
            if (record != null) {
                val family = database.familyDao().getFamilyById(record.familyID)
                if (family != null && family.localityID != allowedLoc) {
                    throw SecurityException("عفواً، لا تملك صلاحية تسليم مساعدة لأسرة تتبع لمحلية أخرى (${family.localityID}) خارج نطاق صلاحيتك.")
                }
            }
        }

        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        val combinedNotes = if (!recipientName.isNullOrBlank()) {
            "المستلم الفعلي: $recipientName${if (!notes.isNullOrBlank()) " | $notes" else ""}"
        } else {
            notes ?: "تم التسليم بنجاح"
        }
        database.aidRecordDao().updateDeliveryStatus(recordId, "تم التسليم", today, combinedNotes)
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "AID_RECORD",
            operation = "DELIVER",
            recordId = recordId.toString(),
            payloadJson = "{\"status\":\"تم التسليم\",\"recipient\":\"$recipientName\",\"date\":\"$today\"}"
        )
    }

    suspend fun undoDelivery(recordId: Long) {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        database.aidRecordDao().updateDeliveryStatus(recordId, "مرشح", today, "تم التراجع عن التسليم")
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "AID_RECORD",
            operation = "UNDO_DELIVERY",
            recordId = recordId.toString(),
            payloadJson = "{\"status\":\"مرشح\",\"date\":\"$today\"}"
        )
    }

    suspend fun deleteAidRecord(recordId: Long) {
        database.aidRecordDao().deleteAidRecord(recordId)
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "AID_RECORD",
            operation = "DELETE",
            recordId = recordId.toString(),
            payloadJson = "{}"
        )
    }

    fun getPendingSyncCount() = database.syncQueueDao().getPendingCountFlow()
    fun getPendingSyncItems() = database.syncQueueDao().getPendingSyncItemsFlow()
    fun getRecentSyncLogs() = database.syncQueueDao().getRecentSyncLogs()
    fun triggerSyncNow() = com.humanitarian.aidmanagement.sync.SyncManager.triggerImmediateSync("MANUAL")
    fun toggleOfflineSimulation() = com.humanitarian.aidmanagement.sync.SyncManager.toggleSimulatedOffline()
    fun getSyncState() = com.humanitarian.aidmanagement.sync.SyncManager.syncState
    fun startMasterSyncListener(targetLocalityId: Int = 0) = com.humanitarian.aidmanagement.sync.SyncManager.startMasterSyncListener(targetLocalityId)
    fun stopMasterSyncListener() = com.humanitarian.aidmanagement.sync.SyncManager.stopMasterSyncListener()
    fun getRecentMergedDeltas() = com.humanitarian.aidmanagement.sync.SyncManager.getRecentMergedDeltas()
    fun getRecentUploadedDeltas() = com.humanitarian.aidmanagement.sync.SyncManager.getRecentUploadedDeltas()
    fun configureFirebaseDatabaseUrl(customUrl: String?) = com.humanitarian.aidmanagement.sync.SyncManager.configureFirebaseDatabaseUrl(customUrl)

    fun getAllUsers(): Flow<List<UserEntity>> = database.userDao().getAllUsers()
    fun getAllRoles(): Flow<List<RoleEntity>> = database.userDao().getAllRoles()

    suspend fun insertUser(user: UserEntity): Long = database.userDao().insertUser(user)
    suspend fun updateUser(user: UserEntity) = database.userDao().updateUser(user)
    suspend fun deleteUser(userId: Int) = database.userDao().deleteUserById(userId)
    suspend fun toggleUserActive(userId: Int, isActive: Boolean) = database.userDao().setUserActive(userId, isActive)
    suspend fun unlockUser(userId: Int) = database.userDao().resetFailedAttempts(userId, System.currentTimeMillis())

    suspend fun recordAuditLog(
        operationType: String,
        targetTable: String,
        recordId: String,
        description: String
    ) {
        val user = getCurrentUser()
        val log = AuditLogEntity(
            userId = user?.UserID ?: 1,
            userName = user?.UserName ?: "admin",
            userFullName = user?.fullName ?: "مدير النظام",
            operationType = operationType,
            targetTable = targetTable,
            recordId = recordId,
            description = description
        )
        database.auditLogDao().insertLog(log)
    }

    fun getAllAuditLogs(): Flow<List<AuditLogEntity>> = database.auditLogDao().getAllLogs()

    enum class DuplicateHandlingMode {
        UPDATE_EXISTING,
        SKIP_DUPLICATES
    }

    data class BatchImportResult(
        val totalProcessed: Int,
        val insertedCount: Int,
        val updatedCount: Int,
        val skippedCount: Int,
        val failedCount: Int,
        val errors: List<String> = emptyList()
    )

    suspend fun importFamiliesBatch(
        families: List<FamilyEntity>,
        duplicateMode: DuplicateHandlingMode = DuplicateHandlingMode.UPDATE_EXISTING,
        onProgress: (progress: Float, current: Int, total: Int) -> Unit
    ): BatchImportResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        var inserted = 0
        var updated = 0
        var skipped = 0
        var failed = 0
        val errors = mutableListOf<String>()
        val total = families.size

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocalityRestricted = allowedLoc != 0 && !isSuperAdmin()

        var processedCount = 0
        families.chunked(2000).forEach { chunk ->
            val validChunk = if (isLocalityRestricted) {
                chunk.filter { fam ->
                    if (fam.localityID != allowedLoc) {
                        skipped++
                        errors.add("تخطي هوية ${fam.nationalID}: تتبع لمحلية (${fam.localityID}) غير مصرح بها لحسابك")
                        false
                    } else true
                }
            } else {
                chunk
            }

            if (validChunk.isNotEmpty()) {
                try {
                    val (chunkInserted, chunkUpdated) = database.familyDao().upsertFamiliesChunk(validChunk)
                    inserted += chunkInserted
                    updated += chunkUpdated
                } catch (e: Exception) {
                    failed += validChunk.size
                    errors.add("خطأ في معالجة الدفعة (${validChunk.size} سجل): ${e.message}")
                }
            }

            processedCount += chunk.size
            onProgress(processedCount.toFloat() / total, processedCount, total)
            kotlinx.coroutines.yield()
        }

        recordAuditLog(
            operationType = "استيراد إكسل آمن",
            targetTable = "الأسر",
            recordId = "${inserted + updated} أسرة",
            description = "استيراد وحفظ دفعات أسر: تم إضافة $inserted جديد، وتحديث $updated (Upsert)، وتخطي $skipped، وفشل $failed"
        )

        BatchImportResult(
            totalProcessed = total,
            insertedCount = inserted,
            updatedCount = updated,
            skippedCount = skipped,
            failedCount = failed,
            errors = errors
        )
    }

    suspend fun importChildrenBatch(
        children: List<ChildEntity>,
        onProgress: (progress: Float, current: Int, total: Int) -> Unit
    ): BatchImportResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        var inserted = 0
        var skipped = 0
        var failed = 0
        val errors = mutableListOf<String>()
        val total = children.size

        val validFamilyNationalIds = database.familyDao().getAllFamilyNationalIdsSync().toHashSet()

        val validChildren = mutableListOf<ChildEntity>()
        for (child in children) {
            val famId = child.familyNationalID.trim()
            if (famId.isBlank() || !validFamilyNationalIds.contains(famId)) {
                skipped++
                errors.add("تخطي الطفل [${child.childName} - هوية ${child.nationalID}]: رقم هوية الأسرة المعيلة (${child.familyNationalID}) غير مسجل في جدول الأسر")
            } else {
                validChildren.add(child)
            }
        }

        var processedCount = 0
        validChildren.chunked(2000).forEach { chunk ->
            try {
                val insertedIds = database.childDao().insertChildren(chunk)
                inserted += insertedIds.size
            } catch (e: Exception) {
                failed += chunk.size
                errors.add("خطأ في معالجة دفعة الأبناء (${chunk.size} سجل): ${e.message}")
            }
            processedCount += chunk.size
            val currentProgress = if (total > 0) (processedCount + skipped).toFloat() / total else 1.0f
            onProgress(currentProgress, processedCount + skipped, total)
            kotlinx.coroutines.yield()
        }

        if (validChildren.isEmpty() && skipped > 0) {
            onProgress(1.0f, total, total)
        }

        recordAuditLog(
            operationType = "استيراد إكسل أبناء (Relational)",
            targetTable = "الأبناء",
            recordId = "$inserted طفل",
            description = "استيراد وحفظ دفعات الأبناء: تم إدخال $inserted بنجاح، وتخطي $skipped لعدم مطابقة هوية الأسرة، وفشل $failed"
        )

        BatchImportResult(
            totalProcessed = total,
            insertedCount = inserted,
            updatedCount = 0,
            skippedCount = skipped,
            failedCount = failed,
            errors = errors
        )
    }

    data class AidRecordImportItem(
        val familyNationalID: String = "",
        val familyID: Long? = null,
        val aidTypeID: Int = 1,
        val aidTypeName: String? = null,
        val projectID: Long = 1L,
        val projectName: String? = null,
        val aidDate: String = "",
        val selectionDate: String = "",
        val warehouse: String = "",
        val recipientStatus: String = "مستلم",
        val actualDeliveryDate: String? = null,
        val actualRecipientName: String? = null,
        val aidValue: Double? = null,
        val notes: String? = null
    )

    suspend fun importAidRecordsImportItemsBatch(
        items: List<AidRecordImportItem>,
        onProgress: (progress: Float, current: Int, total: Int) -> Unit
    ): BatchImportResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        var inserted = 0
        var skipped = 0
        var failed = 0
        val errors = mutableListOf<String>()
        val total = items.size

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocalityRestricted = allowedLoc != 0 && !isSuperAdmin()

        val familyRefs = database.familyDao().getAllFamilyReferencesSync()
        val nationalIdMap = familyRefs.associateBy { it.nationalID.trim() }
        val familyIdMap = familyRefs.associateBy { it.familyID }

        val validRecords = mutableListOf<AidRecordEntity>()
        for (item in items) {
            val famNat = item.familyNationalID.trim()
            val famRef = if (famNat.isNotBlank() && nationalIdMap.containsKey(famNat)) {
                nationalIdMap[famNat]
            } else if (item.familyID != null && familyIdMap.containsKey(item.familyID)) {
                familyIdMap[item.familyID]
            } else null

            if (famRef == null) {
                skipped++
                val refStr = if (famNat.isNotBlank()) "رقم هوية $famNat" else "معرف #${item.familyID ?: ""}"
                errors.add("تخطي سجل مساعدة: الأسرة المعنية ($refStr) غير مسجلة في جدول الأسر")
            } else if (isLocalityRestricted && famRef.localityID != allowedLoc) {
                skipped++
                errors.add("تخطي سجل مساعدة للأسرة [هوية: ${famRef.nationalID}]: تتبع لمحلية (${famRef.localityID}) خارج نطاق صلاحيتك")
            } else {
                validRecords.add(
                    AidRecordEntity(
                        familyID = famRef.familyID,
                        aidTypeID = item.aidTypeID,
                        projectID = item.projectID,
                        aidDate = item.aidDate.ifBlank { "2026-10-14" },
                        selectionDate = item.selectionDate.ifBlank { item.aidDate.ifBlank { "2026-10-14" } },
                        warehouse = item.warehouse.ifBlank { "المستودع الميداني" },
                        recipientStatus = item.recipientStatus.ifBlank { "مستلم" },
                        deliveryDate = item.actualDeliveryDate ?: item.aidDate.ifBlank { null },
                        aidValue = item.aidValue ?: 0.0,
                        notes = listOfNotNull(item.notes, item.actualRecipientName?.let { "المستلم: $it" }).joinToString(" | ").ifEmpty { null }
                    )
                )
            }
        }

        var processedCount = 0
        validRecords.chunked(2000).forEach { chunk ->
            try {
                val insertedIds = database.aidRecordDao().insertAidRecords(chunk)
                inserted += insertedIds.size
            } catch (e: Exception) {
                failed += chunk.size
                errors.add("خطأ في معالجة دفعة سجلات المساعدات (${chunk.size} سجل): ${e.message}")
            }
            processedCount += chunk.size
            val currentProgress = if (total > 0) (processedCount + skipped).toFloat() / total else 1.0f
            onProgress(currentProgress, processedCount + skipped, total)
            kotlinx.coroutines.yield()
        }

        if (validRecords.isEmpty() && skipped > 0) {
            onProgress(1.0f, total, total)
        }

        recordAuditLog(
            operationType = "استيراد إكسل مساعدات (Relational)",
            targetTable = "سجلات المساعدات",
            recordId = "$inserted سجل",
            description = "استيراد دفعات سجلات المساعدات: تم إدخال $inserted بنجاح، وتخطي $skipped لعدم وجود الأسرة أو قيود الصلاحية، وفشل $failed"
        )

        BatchImportResult(
            totalProcessed = total,
            insertedCount = inserted,
            updatedCount = 0,
            skippedCount = skipped,
            failedCount = failed,
            errors = errors
        )
    }

    suspend fun importAidRecordsBatch(
        records: List<AidRecordEntity>,
        onProgress: (progress: Float, current: Int, total: Int) -> Unit
    ): BatchImportResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        var inserted = 0
        var skipped = 0
        var failed = 0
        val errors = mutableListOf<String>()
        val total = records.size

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocalityRestricted = allowedLoc != 0 && !isSuperAdmin()

        val familyRefs = database.familyDao().getAllFamilyReferencesSync()
        val familyIdMap = familyRefs.associateBy { it.familyID }

        val validRecords = mutableListOf<AidRecordEntity>()
        for (record in records) {
            val famRef = familyIdMap[record.familyID]
            if (famRef == null) {
                skipped++
                errors.add("تخطي سجل مساعدة: معرف الأسرة (#${record.familyID}) غير موجود في جدول الأسر")
            } else if (isLocalityRestricted && famRef.localityID != allowedLoc) {
                skipped++
                errors.add("تخطي سجل مساعدة للأسرة (#${record.familyID}): تتبع لمحلية (${famRef.localityID}) خارج نطاق صلاحيتك")
            } else {
                validRecords.add(record)
            }
        }

        var processedCount = 0
        validRecords.chunked(2000).forEach { chunk ->
            try {
                val insertedIds = database.aidRecordDao().insertAidRecords(chunk)
                inserted += insertedIds.size
            } catch (e: Exception) {
                failed += chunk.size
                errors.add("خطأ في معالجة دفعة سجلات المساعدات (${chunk.size} سجل): ${e.message}")
            }
            processedCount += chunk.size
            val currentProgress = if (total > 0) (processedCount + skipped).toFloat() / total else 1.0f
            onProgress(currentProgress, processedCount + skipped, total)
            kotlinx.coroutines.yield()
        }

        if (validRecords.isEmpty() && skipped > 0) {
            onProgress(1.0f, total, total)
        }

        recordAuditLog(
            operationType = "استيراد إكسل مساعدات (Relational)",
            targetTable = "سجلات المساعدات",
            recordId = "$inserted سجل",
            description = "استيراد دفعات سجلات المساعدات: تم إدخال $inserted بنجاح، وتخطي $skipped لعدم وجود الأسرة أو قيود الصلاحية، وفشل $failed"
        )

        BatchImportResult(
            totalProcessed = total,
            insertedCount = inserted,
            updatedCount = 0,
            skippedCount = skipped,
            failedCount = failed,
            errors = errors
        )
    }

    suspend fun insertFamilies(families: List<FamilyEntity>): List<Long> {
        return database.familyDao().insertFamilies(families)
    }

    suspend fun insertAidRecords(records: List<AidRecordEntity>): List<Long> {
        return database.aidRecordDao().insertAidRecords(records)
    }

    suspend fun insertChildren(children: List<ChildEntity>): List<Long> {
        return database.childDao().insertChildren(children)
    }

    suspend fun getAllAidRecordsSync(): List<AidRecordEntity> {
        return database.aidRecordDao().getAllAidRecordsSync()
    }
}

data class DashboardStats(
    val totalFamilies: Int,
    val totalBeneficiaries: Int,
    val totalAidRecords: Int,
    val totalProjects: Int,
    val totalSelectedCandidates: Int,
    val distinctBeneficiaries: Int,
    val eligibleFamilies: Int = 0,
    val eligibleBeneficiaries: Int = 0
)

data class LocalityDistributionStat(
    val localityId: Int,
    val localityName: String,
    val quotaPercent: Double,
    val deliveredAidCount: Int,
    val familiesCount: Int,
    val completionPercent: Int
)

data class AidTypeDistributionStat(
    val aidTypeId: Int,
    val aidTypeName: String,
    val deliveredCount: Int,
    val quotaTarget: Int,
    val colorHex: Long
)

data class SubAreaBenefitRatioStat(
    val subAreaName: String,
    val eligibleFamiliesCount: Int,
    val totalFamiliesCount: Int,
    val deliveredBeneficiariesCount: Int,
    val ratioPercentage: Double,
    val formattedRatio: String
)

data class ProjectWithStats(
    val project: ProjectEntity,
    val aidTypeName: String,
    val candidatesCount: Int,
    val deliveredCount: Int
)

data class ProjectBeneficiaryItem(
    val recordId: Long,
    val familyId: Long,
    val familyName: String,
    val nationalId: String,
    val phone: String,
    val subArea: String,
    val membersCount: Int,
    val status: String,
    val deliveryDate: String?,
    val stageUserName: String?
)
