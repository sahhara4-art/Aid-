package com.humanitarian.aidmanagement.data.repository

import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.*
import com.humanitarian.aidmanagement.data.security.HashUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class AidRepository(private val database: AidDatabase) {

    // --- Authentication & Session ---
    suspend fun authenticate(username: String, pass: String): Result<User> {
        val user = database.userDao().getUserByUsername(username)
            ?: return Result.failure(Exception("اسم المستخدم أو كلمة المرور غير صحيحة"))

        // Check if account is locked
        val now = System.currentTimeMillis()
        user.lockedUntil?.let { lockedUntil ->
            if (now < lockedUntil) {
                val remainingMinutes = ((lockedUntil - now) / 60000).coerceAtLeast(1)
                return Result.failure(Exception("الحساب مقفل مؤقتاً بسبب تكرار المحاولات الفاشلة. يرجى المحاولة بعد $remainingMinutes دقيقة."))
            }
        }

        if (!user.isActive) {
            return Result.failure(Exception("هذا الحساب معطل، يرجى مراجعة مدير النظام."))
        }

        val isValid = HashUtils.verifyPassword(pass, user.passwordHash)
        if (!isValid) {
            val newAttempts = user.failedAttempts + 1
            var lockedTime: Long? = null
            if (newAttempts >= 5) {
                // Lock account for 15 minutes after 5 failed attempts
                lockedTime = now + (15 * 60 * 1000)
            }
            database.userDao().updateFailedAttempts(user.userId, newAttempts, lockedTime)

            val remaining = (5 - newAttempts).coerceAtLeast(0)
            return Result.failure(
                Exception(
                    if (remaining > 0) "كلمة المرور غير صحيحة. متبقي $remaining محاولات قبل القفل المؤقت."
                    else "تم تجاوز الحد الأقصى للمحاولات. تم قفل الحساب لمدة 15 دقيقة."
                )
            )
        }

        // Login success: reset lockout and update lastLogin
        database.userDao().resetLockoutAndSetLogin(user.userId, now)
        return Result.success(user)
    }

    suspend fun getUserScope(user: User): Pair<Boolean, List<Int>> {
        // Role 1 = مدير النظام (Super Admin with access to all localities)
        if (user.roleId == 1) {
            val allLocs = database.localityDao().getAllLocalities()
            return Pair(true, emptyList())
        }
        val allowed = database.userDao().getUserLocalityIds(user.userId)
        return Pair(false, allowed)
    }

    // --- Localities ---
    fun getLocalities(): Flow<List<Locality>> = database.localityDao().getAllLocalities()

    // --- Families ---
    fun getFamiliesFiltered(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        query: String = "",
        localityId: Int? = null,
        gender: String? = null,
        maritalStatus: String? = null,
        residentStatus: String? = null,
        devApproval: String? = null,
        workApproval: String? = null,
        shelterStatus: String? = null
    ): Flow<List<Family>> = database.familyDao().getFamiliesFiltered(
        isSuperAdmin, allowedLocalityIds, query, localityId, gender,
        maritalStatus, residentStatus, devApproval, workApproval, shelterStatus
    )

    suspend fun getFamilyById(id: Int) = database.familyDao().getFamilyById(id)

    suspend fun addFamily(family: Family, isSuperAdmin: Boolean, allowedLocalityIds: List<Int>): Result<Long> {
        if (!isSuperAdmin && !allowedLocalityIds.contains(family.localityID)) {
            return Result.failure(SecurityException("لا تملك صلاحية إضافة أسرة في هذه المحلية."))
        }
        val existing = database.familyDao().getFamilyByNationalId(family.nationalID)
        if (existing != null) {
            return Result.failure(Exception("رقم الهوية (${family.nationalID}) مسجل مسبقاً لأسرة أخرى!"))
        }
        val id = database.familyDao().insertFamily(family)
        return Result.success(id)
    }

    suspend fun updateFamily(family: Family, isSuperAdmin: Boolean, allowedLocalityIds: List<Int>): Result<Unit> {
        if (!isSuperAdmin && !allowedLocalityIds.contains(family.localityID)) {
            return Result.failure(SecurityException("لا تملك صلاحية تعديل بيانات هذه المحلية."))
        }
        database.familyDao().updateFamily(family.copy(modifiedDate = System.currentTimeMillis()))
        return Result.success(Unit)
    }

    suspend fun deleteFamily(family: Family, isSuperAdmin: Boolean, allowedLocalityIds: List<Int>): Result<Unit> {
        if (!isSuperAdmin && !allowedLocalityIds.contains(family.localityID)) {
            return Result.failure(SecurityException("لا تملك صلاحية حذف أسرة في هذه المحلية."))
        }
        database.familyDao().deleteFamily(family)
        return Result.success(Unit)
    }

    // --- Children ---
    fun getChildrenByFamily(familyId: Int): Flow<List<Child>> = database.childDao().getChildrenByFamily(familyId)

    suspend fun addChild(child: Child): Result<Long> {
        val existing = database.childDao().getChildByNationalId(child.childNationalID)
        if (existing != null) {
            return Result.failure(Exception("رقم هوية الابن (${child.childNationalID}) مسجل مسبقاً!"))
        }
        val id = database.childDao().insertChild(child)
        return Result.success(id)
    }

    suspend fun updateChild(child: Child): Result<Unit> {
        database.childDao().updateChild(child)
        return Result.success(Unit)
    }

    suspend fun deleteChild(child: Child): Result<Unit> {
        database.childDao().deleteChild(child)
        return Result.success(Unit)
    }

    // --- Aid Types & Projects ---
    fun getAidTypes(): Flow<List<AidType>> = database.aidTypeDao().getAllActiveAidTypes()
    fun getProjects(): Flow<List<Project>> = database.projectDao().getAllActiveProjects()

    // --- Aid Records ---
    fun getAidRecords(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        aidTypeId: Int? = null,
        projectId: Int? = null,
        localityId: Int? = null,
        startDate: Long? = null,
        endDate: Long? = null
    ): Flow<List<AidRecord>> = database.aidRecordDao().getAidRecordsFiltered(
        isSuperAdmin, allowedLocalityIds, aidTypeId, projectId, localityId, startDate, endDate
    )

    fun getFamilyAidHistory(familyId: Int): Flow<List<AidRecord>> = database.aidRecordDao().getAidRecordsByFamily(familyId)

    suspend fun addAidRecord(record: AidRecord): Long = database.aidRecordDao().insertAidRecord(record)

    // --- Dashboard Stats with Date Range Filter ---
    fun getDashboardStats(
        isSuperAdmin: Boolean,
        allowedLocalityIds: List<Int>,
        startDate: Long?,
        endDate: Long?
    ) = object {
        val totalFamilies = database.familyDao().countFamilies(isSuperAdmin, allowedLocalityIds, startDate, endDate)
        val totalBeneficiaries = database.familyDao().countBeneficiaries(isSuperAdmin, allowedLocalityIds, startDate, endDate)
        val totalAids = database.aidRecordDao().countTotalAids(isSuperAdmin, allowedLocalityIds, startDate, endDate)
        val totalSelections = database.selectionDao().countSelections(isSuperAdmin, allowedLocalityIds)
        val totalProjects = database.projectDao().countActiveProjects()
    }
}
