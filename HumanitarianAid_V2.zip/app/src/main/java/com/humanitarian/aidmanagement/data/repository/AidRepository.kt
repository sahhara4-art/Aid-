package com.humanitarian.aidmanagement.data.repository
 
import android.content.Context
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.PagingSource
import androidx.room.OnConflictStrategy
import androidx.room.withTransaction
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.dao.*
import com.humanitarian.aidmanagement.data.local.entities.*
import com.humanitarian.aidmanagement.engine.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.Locale
import com.humanitarian.aidmanagement.util.AidRecordWithBeneficiary

class AidRepository(
    private val context: Context,
    private val database: AidDatabase,
    private val nominationEngine: NominationEngine = NominationEngine(
        familyDao = database.familyDao(),
        childDao = database.childDao(),
        aidRecordDao = database.aidRecordDao(),
        nominationDao = database.nominationDao(),
        localityDao = database.localityDao(),
        systemSettingDao = database.systemSettingDao()
    )
) {
    constructor(
        database: AidDatabase,
        nominationEngine: NominationEngine = NominationEngine(
            familyDao = database.familyDao(),
            childDao = database.childDao(),
            aidRecordDao = database.aidRecordDao(),
            nominationDao = database.nominationDao(),
            localityDao = database.localityDao(),
            systemSettingDao = database.systemSettingDao()
        )
    ) : this(
        context = com.humanitarian.aidmanagement.AidApplication.instance,
        database = database,
        nominationEngine = nominationEngine
    )

    fun getDatabase(): AidDatabase = database
    // المستخدم الحالي المسجل وحالته التفاعلية
    private val _currentUserFlow = MutableStateFlow<UserEntity?>(null)
    val currentUserFlow: StateFlow<UserEntity?> = _currentUserFlow.asStateFlow()

    private val _currentUserPermissionsFlow = MutableStateFlow<Set<String>>(emptySet())
    val currentUserPermissionsFlow: StateFlow<Set<String>> = _currentUserPermissionsFlow.asStateFlow()

    @get:JvmName("currentUserProperty")
    @set:JvmName("setCurrentUserProperty")
    var currentUser: UserEntity? = null
        get() = field ?: _currentUserFlow.value

    private var currentUserLocalityIds: List<Int> = emptyList()

    suspend fun setCurrentUser(user: UserEntity?, localityIds: List<Int>) {
        this.currentUser = user
        this.currentUserLocalityIds = localityIds
        this._currentUserFlow.value = user

        if (user != null) {
            if (user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true)) {
                // مدير النظام العام يحصل على كافة الصلاحيات بدون أي استثناء
                _currentUserPermissionsFlow.value = setOf(
                    "families_view", "families_create", "families_edit", "families_delete", "families_export",
                    "children_view", "children_manage",
                    "nomination_run", "nomination_manual", "nomination_criteria", "nomination_approve",
                    "delivery_view", "delivery_handover", "delivery_receipt_print", "delivery_undo", "delivery_scanner",
                    "projects_manage", "warehouse_manage",
                    "reports_view", "reports_pdf_export", "print",
                    "users_manage", "permissions_edit", "security_policies", "audit_logs_view",
                    "backup_restore", "sync_manage", "settings_edit"
                )
            } else {
                val dbPermissions = database.userDao().getGrantedPermissionKeys(user.UserID)
                _currentUserPermissionsFlow.value = dbPermissions.toSet()
            }
        } else {
            _currentUserPermissionsFlow.value = emptySet()
        }
    }

    fun setCurrentUserSync(user: UserEntity?, localityIds: List<Int>) {
        this.currentUser = user
        this.currentUserLocalityIds = localityIds
        this._currentUserFlow.value = user
        com.humanitarian.aidmanagement.security.AccessControlManager.setCurrentUser(user)
        if (user != null && (user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true))) {
            _currentUserPermissionsFlow.value = setOf(
                "families_view", "families_create", "families_edit", "families_delete", "families_export",
                "children_view", "children_manage",
                "nomination_run", "nomination_manual", "nomination_criteria", "nomination_approve",
                "delivery_view", "delivery_handover", "delivery_receipt_print", "delivery_undo", "delivery_scanner",
                "projects_manage", "warehouse_manage",
                "reports_view", "reports_pdf_export", "print",
                "users_manage", "permissions_edit", "security_policies", "audit_logs_view",
                "backup_restore", "sync_manage", "settings_edit"
            )
        } else if (user == null) {
            _currentUserPermissionsFlow.value = emptySet()
        }
    }

    fun logout() {
        setCurrentUserSync(null, emptyList())
        com.humanitarian.aidmanagement.security.AccessControlManager.setCurrentUser(null)
    }

    fun getCurrentUser(): UserEntity? = currentUser ?: _currentUserFlow.value
    fun getCurrentUserLocalityIds(): List<Int> = currentUserLocalityIds

    fun isSuperAdmin(): Boolean {
        val user = getCurrentUser() ?: return false
        return user.RoleID == 1 || user.UserName.equals("admin", ignoreCase = true)
    }

    fun hasPermission(permissionKey: String): Boolean {
        if (isSuperAdmin()) return true
        return _currentUserPermissionsFlow.value.contains(permissionKey)
    }

    // صلاحيات المستخدم التفصيلية (الشاشات، المناطق، المجموعة)
    // صلاحيات المستخدم التفصيلية (العزل الجغرافي الصارم والمحليات المصرح بها)
    fun canManageAllLocalities(): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        if (user.AllowedLocalityID != 0) return false
        return currentUserLocalityIds.contains(0) || currentUserLocalityIds.isEmpty()
    }

    fun canAccessLocality(localityId: Int): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        if (user.AllowedLocalityID != 0) {
            return user.AllowedLocalityID == localityId
        }
        if (currentUserLocalityIds.isNotEmpty() && !currentUserLocalityIds.contains(0)) {
            return currentUserLocalityIds.contains(localityId)
        }
        return true
    }

    fun getAllowedLocalitiesFlow(): Flow<List<LocalityEntity>> {
        return database.localityDao().getAllLocalities().map { list ->
            val user = getCurrentUser()
            val allowedLoc = user?.AllowedLocalityID ?: 0
            if (allowedLoc != 0 && !isSuperAdmin()) {
                list.filter { it.LocalityID == allowedLoc }
            } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
                list.filter { currentUserLocalityIds.contains(it.LocalityID) }
            } else {
                list
            }
        }
    }

    suspend fun getAllowedLocalitiesSync(): List<LocalityEntity> = withContext(Dispatchers.IO) {
        val all = database.localityDao().getAllLocalitiesSync()
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        if (allowedLoc != 0 && !isSuperAdmin()) {
            all.filter { it.LocalityID == allowedLoc }
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            all.filter { currentUserLocalityIds.contains(it.LocalityID) }
        } else {
            all
        }
    }

    fun canModifyFamily(family: FamilyEntity): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val hasEditPerm = hasPermission("families_edit") || hasPermission("family_edit") || hasPermission("families_manage")
        if (!hasEditPerm) return false
        if (!canAccessLocality(family.localityID)) return false
        return canUserEditFamily(family)
    }

    fun canDeleteFamily(family: FamilyEntity): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val hasDeletePerm = hasPermission("families_delete") || hasPermission("family_delete") || hasPermission("families_manage")
        if (!hasDeletePerm) return false
        if (!canAccessLocality(family.localityID)) return false
        return canUserDeleteFamily(family)
    }

    fun canAddFamilyInLocality(localityId: Int): Boolean {
        if (isSuperAdmin()) return true
        val hasCreatePerm = hasPermission("families_create") || hasPermission("families_manage")
        if (!hasCreatePerm) return false
        return canAccessLocality(localityId)
    }

    fun canAccessScreen(screenRoute: String): Boolean {
        if (com.humanitarian.aidmanagement.security.AccessControlManager.isLoggedIn()) {
            return com.humanitarian.aidmanagement.security.AccessControlManager.canAccessScreen(screenRoute)
        }
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val allowedScreens = user.AllowedScreens.split(",").map { it.trim().lowercase() }
        val normalizedRoute = screenRoute.lowercase()
        return allowedScreens.contains(normalizedRoute) || allowedScreens.contains("*")
    }

    fun getFamiliesRestrictedFlow(): Flow<List<FamilyEntity>> {
        val isManager = isSuperAdmin() || com.humanitarian.aidmanagement.security.AccessControlManager.getAllowedLocalities().isEmpty()
        val locs = com.humanitarian.aidmanagement.security.AccessControlManager.getAllowedLocalities()
        return database.familyDao().getFamiliesByAllowedLocalities(isManager, locs)
    }

    suspend fun getFamiliesRestrictedSync(): List<FamilyEntity> = withContext(Dispatchers.IO) {
        val isManager = isSuperAdmin() || com.humanitarian.aidmanagement.security.AccessControlManager.getAllowedLocalities().isEmpty()
        val locs = com.humanitarian.aidmanagement.security.AccessControlManager.getAllowedLocalities()
        database.familyDao().getFamiliesByAllowedLocalitiesSync(isManager, locs)
    }

    suspend fun getFamiliesRestrictedCount(): Int = withContext(Dispatchers.IO) {
        val isManager = isSuperAdmin() || com.humanitarian.aidmanagement.security.AccessControlManager.getAllowedLocalities().isEmpty()
        val locs = com.humanitarian.aidmanagement.security.AccessControlManager.getAllowedLocalities()
        database.familyDao().getFamiliesCountByAllowedLocalities(isManager, locs)
    }

    fun getAllowedScreensForCurrentUser(): Set<String> {
        val user = getCurrentUser() ?: return emptySet()
        if (isSuperAdmin()) return setOf("dashboard", "families", "nomination", "delivery", "reports", "excel_import_export", "users", "backup")
        return user.AllowedScreens.split(",").map { it.trim().lowercase() }.toSet()
    }

    fun getAllowedGroupForCurrentUser(): String {
        return getCurrentUser()?.AllowedGroup ?: "كافة المجموعات"
    }

    fun getAvailableGroups(): List<String> = listOf(
        "كافة المجموعات",
        "مجموعة الشمال أ (إغاثة عاجلة)",
        "مجموعة مدينة غزة ب (توزيع رئيسي)",
        "مجموعة الوسطى ودير البلح ج (إيواء)",
        "مجموعة خان يونس د (ميداني)",
        "مجموعة رفح هـ (مخيمات)",
        "فريق الإسناد والطوارئ و"
    )

    fun canUserViewSubArea(subArea: String?): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val allowed = user.AllowedViewSubAreas
        if (allowed == "*" || allowed.isBlank()) return true
        if (subArea.isNullOrBlank()) return true
        val allowedList = allowed.split(",").map { it.trim().lowercase() }
        val target = subArea.trim().lowercase()
        return allowedList.contains("*") || allowedList.contains(target) || allowedList.any { it.isNotEmpty() && (target.contains(it) || it.contains(target)) }
    }

    fun canUserEditFamily(family: FamilyEntity): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val hasEditPerm = hasPermission("family_edit") || hasPermission("families_manage") || hasPermission("families_edit") || user.RoleID == 1
        if (!hasEditPerm) return false
        val allowed = user.AllowedEditSubAreas
        if (allowed == "*" || allowed.isBlank()) return true
        val target = family.currentSubArea.trim().lowercase()
        if (target.isBlank()) return true
        val allowedList = allowed.split(",").map { it.trim().lowercase() }
        return allowedList.contains("*") || allowedList.contains(target) || allowedList.any { it.isNotEmpty() && (target.contains(it) || it.contains(target)) }
    }

    fun canUserDeleteFamily(family: FamilyEntity): Boolean {
        if (isSuperAdmin()) return true
        val user = getCurrentUser() ?: return false
        val hasDeletePerm = hasPermission("family_delete") || hasPermission("families_manage") || hasPermission("families_delete") || user.RoleID == 1
        if (!hasDeletePerm) return false
        val allowed = user.AllowedEditSubAreas
        if (allowed == "*" || allowed.isBlank()) return true
        val target = family.currentSubArea.trim().lowercase()
        if (target.isBlank()) return true
        val allowedList = allowed.split(",").map { it.trim().lowercase() }
        return allowedList.contains("*") || allowedList.contains(target) || allowedList.any { it.isNotEmpty() && (target.contains(it) || it.contains(target)) }
    }

    // الأسر مع تطبيق العزل الجغرافي الصارم (WHERE localityID = AllowedLocalityID)
    // الأسر مع تطبيق العزل الجغرافي الصارم وحماية CursorWindow
    fun getFamilies(query: String = "", localityId: Int? = null, shelterStatus: String? = null): Flow<List<FamilyEntity>> {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val effectiveLocalityId = if (allowedLoc != 0 && !isSuperAdmin()) {
            allowedLoc
        } else if (localityId != null && localityId != 0) {
            localityId
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            currentUserLocalityIds.first()
        } else {
            0
        }
        return database.familyDao().searchFamilies(query, effectiveLocalityId, shelterStatus).map { list ->
            if (isSuperAdmin()) {
                list
            } else {
                list.filter { canAccessLocality(it.localityID) && canUserViewSubArea(it.currentSubArea) }
            }
        }
    }

    /**
     * استعلام ترقيم الصفحات (Pagination) - جلب دفعة محددة (50 أسرة) لمنع استنزاف الذاكرة وانهيار CursorWindow
     */
    suspend fun getFamiliesPaged(
        query: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null,
        limit: Int = 50,
        offset: Int = 0,
        localityName: String? = null
    ): List<FamilyEntity> = withContext(Dispatchers.IO) {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val effectiveLocalityId = if (allowedLoc != 0 && !isSuperAdmin()) {
            allowedLoc
        } else if (localityId != null && localityId != 0) {
            localityId
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            currentUserLocalityIds.first()
        } else {
            0
        }
        val pagedList = database.familyDao().searchFamiliesPaged(
            query = query.trim(),
            localityId = effectiveLocalityId,
            shelterStatus = shelterStatus,
            limit = limit,
            offset = offset,
            localityName = localityName
        )
        if (isSuperAdmin()) {
            pagedList
        } else {
            pagedList.filter { canAccessLocality(it.localityID) && canUserViewSubArea(it.currentSubArea) }
        }
    }

    /**
     * استعلام Paging 3 فائق الكفاءة - يمنع تحميل 50 ألف أسرة في الذاكرة
     * ويجلب فقط ما يعرض على الشاشة (Lazy Load) بنظام Limit/Offset الداخلي في SQLite
     */
    fun getFamiliesPagerFlow(
        query: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null,
        localityName: String? = null,
        pageSize: Int = 30
    ): Flow<PagingData<FamilyEntity>> {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val effectiveLocalityId = if (allowedLoc != 0 && !isSuperAdmin()) {
            allowedLoc
        } else if (localityId != null && localityId != 0) {
            localityId
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            currentUserLocalityIds.first()
        } else {
            0
        }
        val cleanLocName = if (localityName == "الكل" || localityName.isNullOrBlank()) null else localityName
        val cleanShelter = if (shelterStatus.isNullOrBlank() || shelterStatus == "الكل") null else shelterStatus

        return Pager(
            config = PagingConfig(
                pageSize = pageSize,
                prefetchDistance = 10,
                enablePlaceholders = false,
                initialLoadSize = pageSize * 2
            ),
            pagingSourceFactory = {
                database.familyDao().getFamiliesPagingSource(
                    query = query.trim(),
                    localityId = effectiveLocalityId,
                    shelterStatus = cleanShelter,
                    localityName = cleanLocName
                )
            }
        ).flow
    }

    /**
     * استعلام سريع خفيف لعائلات مشروع محدد فقط - يمنع تحميل 50,000 أسرة في شاشة التسليم
     */
    suspend fun getFamiliesForProject(projectId: Long): List<FamilyEntity> = withContext(Dispatchers.IO) {
        val records = database.aidRecordDao().getAidRecordsForProjectSync(projectId)
        val familyIds = records.map { it.familyID }.distinct()
        if (familyIds.isEmpty()) return@withContext emptyList()
        val result = mutableListOf<FamilyEntity>()
        familyIds.chunked(500).forEach { chunk ->
            result.addAll(database.familyDao().getFamiliesByFamilyIds(chunk))
        }
        result
    }

    /**
     * حساب إجمالي عدد الأسر المطابقة للبحث والفلترة دون تحميل أي كيانات في الذاكرة
     */
    suspend fun getFamiliesCount(
        query: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null,
        localityName: String? = null
    ): Int = withContext(Dispatchers.IO) {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val effectiveLocalityId = if (allowedLoc != 0 && !isSuperAdmin()) {
            allowedLoc
        } else if (localityId != null && localityId != 0) {
            localityId
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            currentUserLocalityIds.first()
        } else {
            0
        }
        database.familyDao().countFamiliesSearch(query.trim(), effectiveLocalityId, shelterStatus, localityName)
    }

    fun getFamiliesCountFlow(
        query: String = "",
        localityId: Int? = null,
        shelterStatus: String? = null,
        localityName: String? = null
    ): Flow<Int> {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val effectiveLocalityId = if (allowedLoc != 0 && !isSuperAdmin()) {
            allowedLoc
        } else if (localityId != null && localityId != 0) {
            localityId
        } else if (!canManageAllLocalities() && currentUserLocalityIds.isNotEmpty()) {
            currentUserLocalityIds.first()
        } else {
            0
        }
        return database.familyDao().countFamiliesSearchFlow(query.trim(), effectiveLocalityId, shelterStatus, localityName)
    }

    /**
     * تحويل ذكي ومطابقة صارمة لاسم أو رقم المحلية إلى المعرّف الحقيقي (LocalityID)
     * يمنع تماماً فرض قيمة افتراضية صامتة، ويعيد المعرف الصحيح أو null عند التعذر لتوثيق الخطأ
     */
    suspend fun resolveLocalityId(
        rawInput: String?,
        subAreaHint: String? = null
    ): Int? = withContext(Dispatchers.IO) {
        val allLocalities = database.localityDao().getAllLocalitiesSync().map { it.LocalityID to it.LocalityName }
        val result = com.humanitarian.aidmanagement.util.ExcelParserHelper.resolveLocalityStrict(rawInput, allLocalities)
        if (!result.isError && result.localityId != null) {
            return@withContext result.localityId
        }

        // إذا كان عمود المحلية فارغاً، نحاول الاستدلال الصارم من المنطقة الفرعية (subAreaHint)
        if (!subAreaHint.isNullOrBlank()) {
            val subResult = com.humanitarian.aidmanagement.util.ExcelParserHelper.resolveLocalityStrict(subAreaHint, allLocalities)
            if (!subResult.isError && subResult.localityId != null) {
                return@withContext subResult.localityId
            }
        }

        // إذا كان المندوب مقيداً بمحلية معينة حصراً وليس مدير عام، نعتمدها
        val currentUser = getCurrentUser()
        if ((currentUser?.AllowedLocalityID ?: 0) != 0 && !isSuperAdmin()) {
            return@withContext currentUser!!.AllowedLocalityID
        }

        // إزالة أي قيمة افتراضية صامتة عشوائية! نرجع null إذا كانت مجهولة تماماً
        null
    }

    suspend fun getOrCreateLocalityId(localityName: String): Int = withContext(Dispatchers.IO) {
        resolveLocalityId(localityName) ?: 1
    }


    suspend fun getFamilyByNationalId(nationalId: String): FamilyEntity? = withContext(Dispatchers.IO) {
        val cleanId = com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(nationalId)
        database.familyDao().getFamilyByNationalId(cleanId)
    }

    suspend fun checkIfAidExists(familyId: Long, projectId: Long): Boolean = withContext(Dispatchers.IO) {
        database.aidRecordDao().checkIfAidExists(familyId, projectId)
    }

    suspend fun checkIfAidExistsByNationalId(nationalId: String, projectId: Long): Boolean = withContext(Dispatchers.IO) {
        val cleanId = com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(nationalId)
        database.aidRecordDao().checkIfAidExistsByNationalId(cleanId, projectId)
    }

    suspend fun insertFamily(family: FamilyEntity): Long = database.withTransaction {
        val cleanFamily = family.copy(
            nationalID = com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(family.nationalID),
            wifeNationalID = family.wifeNationalID?.let { com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(it) }?.ifBlank { null }
        )
        val id = database.familyDao().insertFamily(cleanFamily)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "FAMILY",
                operation = "INSERT",
                recordId = id.toString(),
                payloadJson = "{\"name\":\"${cleanFamily.name}\",\"nationalID\":\"${cleanFamily.nationalID}\",\"members\":${cleanFamily.familyMembersCount}}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
        id
    }

    suspend fun updateFamily(family: FamilyEntity) = database.withTransaction {
        database.familyDao().updateFamily(family)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "FAMILY",
                operation = "UPDATE",
                recordId = family.familyID.toString(),
                payloadJson = "{\"name\":\"${family.name}\",\"nationalID\":\"${family.nationalID}\"}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    suspend fun deleteFamily(family: FamilyEntity) = database.withTransaction {
        database.familyDao().deleteFamily(family)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "FAMILY",
                operation = "DELETE",
                recordId = family.familyID.toString(),
                payloadJson = "{}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    suspend fun getAllFamiliesSync(): List<FamilyEntity> {
        return database.familyDao().getAllFamiliesSync()
    }

    suspend fun getLastAidForFamily(familyId: Long): AidRecordEntity? {
        return database.aidRecordDao().getLastAidForFamily(familyId)
    }

    // استعلامات الملف الشامل للأسرة
    fun getFamilyById(id: Long): Flow<FamilyEntity?> = database.familyDao().getFamilyByIdFlow(id)
    suspend fun getFamilyByIdSync(id: Long): FamilyEntity? = database.familyDao().getFamilyById(id)
    suspend fun getFamiliesByIdsSync(ids: List<Long>): List<FamilyEntity> = withContext(Dispatchers.IO) {
        if (ids.isEmpty()) return@withContext emptyList()
        ids.chunked(500).flatMap { chunk ->
            database.familyDao().getFamiliesByFamilyIds(chunk)
        }
    }
    fun getAidRecordsForFamily(familyId: Long): Flow<List<AidRecordEntity>> = database.aidRecordDao().getAidRecordsForFamilyFlow(familyId)
    suspend fun getAidRecordsForFamilySync(familyId: Long): List<AidRecordEntity> = database.aidRecordDao().getAidRecordsForFamily(familyId)

    // استعلامات الشعب والمحليات وأضرار الحرب الديناميكية
    suspend fun getSubAreasByLocality(localityId: Int): List<String> = withContext(Dispatchers.IO) {
        database.familyDao().getSubAreasByLocality(localityId)
    }

    fun getSubAreasByLocalityFlow(localityId: Int): Flow<List<String>> =
        database.familyDao().getSubAreasByLocalityFlow(localityId)

    suspend fun getFamilyCountForEachLocality(): List<LocalityFamilyCount> = withContext(Dispatchers.IO) {
        database.familyDao().getFamilyCountForEachLocality()
    }

    fun getFamilyCountForEachLocalityFlow(): Flow<List<LocalityFamilyCount>> =
        database.familyDao().getFamilyCountForEachLocalityFlow()

    suspend fun getFamilyCountForEachSubArea(localityId: Int? = null): List<SubAreaFamilyCount> = withContext(Dispatchers.IO) {
        database.familyDao().getFamilyCountForEachSubArea(localityId)
    }

    fun getFamilyCountForEachSubAreaFlow(localityId: Int? = null): Flow<List<SubAreaFamilyCount>> =
        database.familyDao().getFamilyCountForEachSubAreaFlow(localityId)

    suspend fun getWarDamageDistributionFiltered(localityId: Int? = null, subArea: String? = null): List<DamageTypeBreakdown> = withContext(Dispatchers.IO) {
        database.familyDao().getWarDamageDistributionFiltered(localityId, subArea)
    }

    fun getWarDamageDistributionFilteredFlow(localityId: Int? = null, subArea: String? = null): Flow<List<DamageTypeBreakdown>> =
        database.familyDao().getWarDamageDistributionFilteredFlow(localityId, subArea)

    suspend fun getWarDamageStatsFiltered(localityId: Int? = null, subArea: String? = null): WarDamageStats = withContext(Dispatchers.IO) {
        database.familyDao().getWarDamageStatsFiltered(localityId, subArea)
    }

    suspend fun getCompletelyDestroyedCountFiltered(localityId: Int? = null, subArea: String? = null): Int = withContext(Dispatchers.IO) {
        database.familyDao().getCompletelyDestroyedCountFiltered(localityId, subArea)
    }

    suspend fun getBranchStatisticsByLocality(selectedLocality: String): List<BranchCountRecord> = withContext(Dispatchers.IO) {
        database.familyDao().getBranchStatisticsByLocality(selectedLocality)
    }

    fun getBranchStatisticsByLocalityFlow(selectedLocality: String): Flow<List<BranchCountRecord>> =
        database.familyDao().getBranchStatisticsByLocalityFlow(selectedLocality)

    suspend fun getDistinctBranchesForLocality(selectedLocality: String): List<String> = withContext(Dispatchers.IO) {
        if (selectedLocality.isBlank()) {
            database.familyDao().getAllDistinctBranchesSync()
        } else {
            database.familyDao().getDistinctBranchesForLocalitySync(selectedLocality)
        }
    }

    fun getDistinctBranchesForLocalityFlow(selectedLocality: String): Flow<List<String>> =
        database.familyDao().getDistinctBranchesForLocalityFlow(selectedLocality)

    suspend fun getAllDistinctBranches(): List<String> = withContext(Dispatchers.IO) {
        database.familyDao().getAllDistinctBranchesSync()
    }

    suspend fun getTotalFamiliesCountForBranch(locality: String?, branch: String): Int = withContext(Dispatchers.IO) {
        database.familyDao().getTotalFamiliesCountForBranch(locality, branch)
    }

    suspend fun calculateBranchBenefitRatiosForLocality(selectedLocality: String): List<SubAreaBenefitRatioStat> = withContext(Dispatchers.IO) {
        val families = database.familyDao().getFamiliesByLocalitySync(selectedLocality)
        val branches = families.map { it.currentBranch.trim() }.filter { it.isNotBlank() }.distinct().sorted()
        if (branches.isEmpty()) return@withContext emptyList()

        branches.map { branch ->
            val branchFamilies = families.filter { it.currentBranch.trim() == branch }
            val eligibleCount = branchFamilies.count { 
                (it.developmentApproval.contains("معتمد")) && 
                (it.residentStatus.contains("مقيم")) 
            }
            val totalCount = branchFamilies.size
            val deliveredCount = database.aidRecordDao().getDeliveredBeneficiariesCountForBranch(selectedLocality, branch)
            val ratio = if (eligibleCount > 0) {
                ((deliveredCount.toDouble() / eligibleCount.toDouble()) * 100.0).coerceIn(0.0, 100.0)
            } else 0.0

            SubAreaBenefitRatioStat(
                subAreaName = branch,
                eligibleFamiliesCount = eligibleCount,
                totalFamiliesCount = totalCount.coerceAtLeast(eligibleCount),
                deliveredBeneficiariesCount = deliveredCount,
                ratioPercentage = ratio,
                formattedRatio = String.format(Locale.US, "%.1f%%", ratio)
            )
        }
    }

    /**
     * تقرير تنفيذي تجميعي فائق السرعة يعتمد بالكامل على استعلامات SQLite التجميعية المباشرة (COUNT, SUM, GROUP BY)
     * دون تحميل كيانات الأسر وسجلات المساعدات في الذاكرة (منع انهيار الذاكرة OOM وتجميد المسار الرئيسي)
     */
    suspend fun getExecutiveSummary(fromDate: String, toDate: String): ExecutiveAggregateSummary = withContext(Dispatchers.IO) {
        val totalFam = database.familyDao().getTotalFamiliesCount()
        val totalIndiv = database.familyDao().getTotalBeneficiariesCount() ?: 0
        val delivered = database.aidRecordDao().getDeliveredCountInDateRange(fromDate, toDate)
        val distinctBen = database.aidRecordDao().getDistinctBeneficiaryCountInDateRange(fromDate, toDate)
        val geo = database.familyDao().getRegionDemographics()
        val dmg = database.familyDao().getWarDamageDistribution()
        val shelter = database.familyDao().getShelterStatusDistribution()
        val aidTypes = database.aidRecordDao().getAidTypeBreakdownInDateRange(fromDate, toDate)

        ExecutiveAggregateSummary(
            totalFamilies = totalFam,
            totalIndividuals = totalIndiv,
            totalDelivered = delivered,
            actualBeneficiaries = distinctBen,
            geoDemographics = geo,
            damageBreakdown = dmg,
            shelterBreakdown = shelter,
            aidTypeBreakdown = aidTypes
        )
    }

    // الأطفال
    fun getChildrenByFamily(familyNationalId: String): Flow<List<ChildEntity>> {
        return database.childDao().getChildrenByFamilyNationalId(familyNationalId)
    }

    fun getChildrenByFamilyId(familyId: Long): Flow<List<ChildEntity>> {
        return database.childDao().getChildrenByFamilyId(familyId)
    }

    fun searchChildren(query: String): Flow<List<ChildEntity>> {
        return database.childDao().searchChildren(query)
    }

    suspend fun getChildByNationalId(nationalId: String): ChildEntity? = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val cleanId = com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(nationalId)
        database.childDao().getChildByNationalId(cleanId)
    }

    suspend fun insertChild(child: ChildEntity): Long = database.withTransaction {
        val id = database.childDao().insertChild(child)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "CHILD",
                operation = "INSERT",
                recordId = id.toString(),
                payloadJson = "{\"name\":\"${child.childName}\",\"familyNationalId\":\"${child.familyNationalID}\"}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
        id
    }

    suspend fun deleteChild(child: ChildEntity) = database.withTransaction {
        database.childDao().deleteChild(child)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "CHILD",
                operation = "DELETE",
                recordId = child.childID.toString(),
                payloadJson = "{}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    // أنواع المساعدات والمشاريع
    fun getActiveAidTypes(): Flow<List<AidTypeEntity>> = database.aidTypeDao().getAllActiveAidTypes()
    suspend fun getActiveAidTypesSync(): List<AidTypeEntity> = withContext(Dispatchers.IO) {
        database.aidTypeDao().getAllActiveAidTypesSync()
    }
    fun getDistinctAidCategories(): Flow<List<String>> = database.aidTypeDao().getDistinctAidCategoriesFlow()
    fun getDistinctLocalities(): Flow<List<String>> = database.familyDao().getDistinctLocalities()
    fun getDistinctDamageTypesFlow(): Flow<List<String>> = database.familyDao().getDistinctDamageTypesFlow()
    fun getDistinctWorksApprovalsFlow(): Flow<List<String>> = database.familyDao().getDistinctWorksApprovalsFlow()
    fun getDistinctShelterStatusesFlow(): Flow<List<String>> = database.familyDao().getDistinctShelterStatusesFlow()
    fun getDistinctResidentStatusesFlow(): Flow<List<String>> = database.familyDao().getDistinctResidentStatusesFlow()
    suspend fun getDistinctAidCategoriesSync(): List<String> = withContext(Dispatchers.IO) {
        database.aidTypeDao().getDistinctAidCategoriesSync()
    }
    fun getActiveProjects(): Flow<List<ProjectEntity>> = database.projectDao().getAllActiveProjects()
    fun getOpenProjectsNeedingNomination(): Flow<List<ProjectEntity>> = database.projectDao().getOpenProjectsNeedingNomination()

    fun getAllFamiliesFlow(): Flow<List<FamilyEntity>> = database.familyDao().getAllFamilies()

    fun getLocalities(): Flow<List<LocalityEntity>> = database.localityDao().getAllLocalities()
    suspend fun getAllLocalitiesSync(): List<LocalityEntity> = withContext(Dispatchers.IO) { database.localityDao().getAllLocalitiesSync() }
    suspend fun getLocalitiesSync(): List<LocalityEntity> = getAllLocalitiesSync()
    fun getDistributions(): Flow<List<LocalityDistributionEntity>> = database.localityDao().getDistributions()

    suspend fun insertProject(project: ProjectEntity): Long = database.withTransaction {
        val id = database.projectDao().insertProject(project)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "PROJECT",
                operation = "INSERT",
                recordId = id.toString(),
                payloadJson = "{\"projectName\":\"${project.projectName}\",\"projectNumber\":\"${project.projectNumber}\"}"
            )
        )
        try {
            com.humanitarian.aidmanagement.notifications.AidNotificationHelper.notifyNewProjectCreated(
                context = context,
                projectName = project.projectName,
                projectNumber = project.projectNumber
            )
        } catch (_: Exception) {
            // notification error ignored
        }
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
        id
    }

    suspend fun getProjectById(projectId: Long): ProjectEntity? = withContext(Dispatchers.IO) {
        database.projectDao().getProjectById(projectId)
    }

    suspend fun getProjectsWithStats(): List<ProjectWithStats> = withContext(Dispatchers.IO) {
        val projects = database.projectDao().getAllActiveProjectsSync()
        val aidTypes = database.aidTypeDao().getAllActiveAidTypesSync().associateBy { it.aidTypeID }

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocRestricted = allowedLoc != 0 && !isSuperAdmin()

        // استعلام تجميعي فوري وسريع عبر SQL مباشرة دون تحميل أي سجلات إلى الذاكرة
        val countsList = if (isLocRestricted) {
            database.projectDao().getProjectCountsDirectForLocality(allowedLoc)
        } else {
            database.projectDao().getProjectCountsDirect()
        }
        val countsMap = countsList.associateBy { it.projectID }

        // عزل المشاريع: المستخدم المقيد يرى فقط المشاريع التي تحتوي على مستفيدين من محليته المسموح بها
        val targetProjects = if (isLocRestricted) {
            projects.filter { countsMap.containsKey(it.projectID) }
        } else {
            projects
        }

        targetProjects.map { prj ->
            val stats = countsMap[prj.projectID]
            val typeName = aidTypes[prj.aidTypeID]?.aidTypeName ?: "مساعدة عامة"
            ProjectWithStats(
                project = prj,
                aidTypeName = typeName,
                candidatesCount = stats?.candidatesCount ?: 0,
                deliveredCount = stats?.deliveredCount ?: 0
            )
        }
    }

    /**
     * جلب إحصائيات تجميع المشاريع حسابياً متضمنة اسم المشروع ورقمه وعدد المرشحين والمستلمين ونسبة الإنجاز
     */
    suspend fun getProjectAggregatedSummaries(): List<ProjectAggregatedSummary> = withContext(Dispatchers.IO) {
        database.aidRecordDao().getProjectAggregatedSummaries()
    }

    fun getProjectAggregatedSummariesFlow(): Flow<List<ProjectAggregatedSummary>> {
        return database.aidRecordDao().getProjectAggregatedSummariesFlow()
    }

    suspend fun getProjectBeneficiaries(projectId: Long): List<ProjectBeneficiaryItem> = withContext(Dispatchers.IO) {
        val records = database.aidRecordDao().getAidRecordsForProjectSync(projectId)
        if (records.isEmpty()) return@withContext emptyList()

        // جلب عائلات هذا المشروع حصراً عبر دفعات (بدلاً من تحميل كل الـ 100 ألف أسرة)
        val familyIds = records.map { it.familyID }.distinct()
        val familiesMap = mutableMapOf<Long, FamilyEntity>()
        familyIds.chunked(500).forEach { batch ->
            database.familyDao().getFamiliesByFamilyIds(batch).forEach { fam ->
                familiesMap[fam.familyID] = fam
            }
        }

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocRestricted = allowedLoc != 0 && !isSuperAdmin()

        records
            .filter { rec ->
                !isLocRestricted || (familiesMap[rec.familyID]?.localityID == allowedLoc)
            }
            .map { rec ->
                val fam = familiesMap[rec.familyID]
                ProjectBeneficiaryItem(
                    recordId = rec.aidRecordID,
                    familyId = rec.familyID,
                    familyName = fam?.name ?: "مستفيد #${rec.familyID}",
                    nationalId = fam?.nationalID ?: "",
                    phone = fam?.primaryPhone ?: "",
                    subArea = fam?.currentSubArea ?: "",
                    membersCount = fam?.familyMembersCount ?: 1,
                    status = rec.recipientStatus,
                    deliveryDate = rec.deliveryDate,
                    stageUserName = rec.stageUserName ?: "النظام"
                )
            }
    }

    suspend fun getProjectBeneficiariesWithFamilies(projectId: Long): List<AidRecordWithBeneficiary> = withContext(Dispatchers.IO) {
        val records = database.aidRecordDao().getAidRecordsForProjectSync(projectId)
        if (records.isEmpty()) return@withContext emptyList()

        val familyIds = records.map { it.familyID }.distinct()
        val familiesMap = mutableMapOf<Long, FamilyEntity>()
        familyIds.chunked(500).forEach { batch ->
            database.familyDao().getFamiliesByFamilyIds(batch).forEach { fam ->
                familiesMap[fam.familyID] = fam
            }
        }

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocRestricted = allowedLoc != 0 && !isSuperAdmin()

        records
            .filter { rec ->
                !isLocRestricted || (familiesMap[rec.familyID]?.localityID == allowedLoc)
            }
            .map { rec ->
                AidRecordWithBeneficiary(record = rec, family = familiesMap[rec.familyID])
            }
    }

    suspend fun getBeneficiariesWithFamiliesInDateRange(fromDate: String, toDate: String): List<AidRecordWithBeneficiary> = withContext(Dispatchers.IO) {
        val records = database.aidRecordDao().getAidRecordsInDateRangeSync(fromDate, toDate)
        if (records.isEmpty()) return@withContext emptyList()

        val familyIds = records.map { it.familyID }.distinct()
        val familiesMap = mutableMapOf<Long, FamilyEntity>()
        familyIds.chunked(500).forEach { batch ->
            database.familyDao().getFamiliesByFamilyIds(batch).forEach { fam ->
                familiesMap[fam.familyID] = fam
            }
        }

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocRestricted = allowedLoc != 0 && !isSuperAdmin()

        records
            .filter { rec ->
                !isLocRestricted || (familiesMap[rec.familyID]?.localityID == allowedLoc)
            }
            .map { rec ->
                AidRecordWithBeneficiary(record = rec, family = familiesMap[rec.familyID])
            }
    }

    // التدفقات والاستعلامات الميدانية المستقلة للمرشحين والمستلمين الفعليين
    fun getTotalNomineesCountFlow(): Flow<Int> = database.aidRecordDao().getTotalNomineesCountFlow()
    suspend fun getTotalNomineesCount(): Int = withContext(Dispatchers.IO) {
        database.aidRecordDao().getTotalNomineesCount()
    }

    fun getActualRecipientsCountFlow(): Flow<Int> = database.aidRecordDao().getActualRecipientsCountFlow()
    suspend fun getActualRecipientsCount(): Int = withContext(Dispatchers.IO) {
        database.aidRecordDao().getActualRecipientsCount()
    }

    fun getTotalAidRecordsCountFlow(): Flow<Int> = database.aidRecordDao().getTotalAidRecordsCountFlow()
    suspend fun getTotalAidRecordsCount(): Int = withContext(Dispatchers.IO) {
        database.aidRecordDao().getTotalAidRecordsCount()
    }

    // إحصائيات لوحة التحكم
    suspend fun getDashboardStats(): DashboardStats = withContext(Dispatchers.IO) {
        val totalFamilies = database.familyDao().getTotalFamiliesCount()
        val totalBeneficiaries = database.familyDao().getTotalBeneficiariesCount() ?: 0
        val eligibleFamilies = database.familyDao().getExactEligibleFamiliesTotal()
        val eligibleBeneficiaries = database.familyDao().getEligibleBeneficiariesTotal() ?: 0
        val totalAidRecords = database.aidRecordDao().getTotalAidRecordsCount()
        val totalProjects = database.projectDao().getTotalProjectsCount()
        val totalNominees = database.aidRecordDao().getTotalNomineesCount()
        val actualRecipients = database.aidRecordDao().getActualRecipientsCount()

        DashboardStats(
            totalFamilies = totalFamilies,
            totalBeneficiaries = totalBeneficiaries,
            totalAidRecords = totalAidRecords,
            totalProjects = totalProjects,
            totalSelectedCandidates = totalNominees,
            distinctBeneficiaries = actualRecipients,
            eligibleFamilies = eligibleFamilies,
            eligibleBeneficiaries = eligibleBeneficiaries,
            totalNomineesCount = totalNominees,
            actualRecipientsCount = actualRecipients
        )
    }

    // =========================================================================
    // أولاً وثانياً: القاعدة الذهبية الصارمة ومحرك البيانات الحية
    // كافة الإحصائيات، التوزيع الجغرافي، والنسب المئوية معتمدة حصراً على EligibleFamiliesView
    // =========================================================================
    val eligibleFamiliesDao get() = database.eligibleFamiliesDao()

    fun getAllEligibleFamilies(): Flow<List<EligibleFamiliesView>> = eligibleFamiliesDao.getAllEligibleFamilies()
    suspend fun getAllEligibleFamiliesSync(): List<EligibleFamiliesView> = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.getAllEligibleFamiliesSync()
    }

    fun countSystemEligibleFamilies(): Flow<Int> = eligibleFamiliesDao.countSystemEligibleFamilies()
    suspend fun countSystemEligibleFamiliesSync(): Int = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.countSystemEligibleFamiliesSync()
    }

    fun getLocalityQuotaShares(): Flow<List<LocalityQuotaShare>> = eligibleFamiliesDao.getLocalityShares()
    suspend fun getLocalityQuotaSharesSync(): List<LocalityQuotaShare> = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.getLocalitySharesSync()
    }

    fun getEligibleCountBySubArea(): Flow<List<SubAreaEligibleStat>> = eligibleFamiliesDao.getEligibleCountBySubArea()
    suspend fun getEligibleCountBySubAreaSync(): List<SubAreaEligibleStat> = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.getEligibleCountBySubAreaSync()
    }

    // جلب خيارات الفلاتر ديناميكياً 100% عبر SELECT DISTINCT من الجداول الحقيقية
    suspend fun getDynamicFilterOptions(): DynamicFilterOptions = withContext(Dispatchers.IO) {
        val damageTypes = eligibleFamiliesDao.getDistinctDamageTypesSync()
        val maritalStatuses = eligibleFamiliesDao.getDistinctMaritalStatusesSync()
        val worksApprovals = eligibleFamiliesDao.getDistinctWorksApprovalsSync()
        val shelterStatuses = eligibleFamiliesDao.getDistinctShelterStatusesSync()
        val incomeSources = eligibleFamiliesDao.getDistinctIncomeSourcesSync()
        val injuryStatuses = eligibleFamiliesDao.getDistinctInjuryStatusesSync()
        val subAreas = eligibleFamiliesDao.getDistinctCurrentSubAreasSync()
        val aidTypes = database.aidTypeDao().getAllActiveAidTypes().first()
        val aidCategories = database.aidTypeDao().getDistinctAidCategoriesSync()
        val localities = database.localityDao().getAllLocalities().first()

        DynamicFilterOptions(
            damageTypes = damageTypes,
            maritalStatuses = maritalStatuses,
            worksApprovals = worksApprovals,
            shelterStatuses = shelterStatuses,
            incomeSources = incomeSources,
            injuryStatuses = injuryStatuses,
            subAreas = subAreas,
            aidTypes = aidTypes,
            aidCategories = aidCategories,
            localities = localities
        )
    }

    suspend fun getAllChildrenSync(): List<ChildEntity> = withContext(Dispatchers.IO) {
        database.childDao().getAllChildrenSync()
    }

    suspend fun getFamilyNationalIdsWithChildrenInAgeRange(minAge: Int, maxAge: Int): List<String> = withContext(Dispatchers.IO) {
        database.childDao().getFamilyNationalIdsWithChildrenInAgeRange(minAge, maxAge)
    }

    suspend fun queryEligibleFamiliesRaw(query: androidx.sqlite.db.SupportSQLiteQuery): List<EligibleFamiliesView> = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.queryEligibleFamiliesRawSync(query)
    }

    fun queryEligibleFamiliesRawFlow(query: androidx.sqlite.db.SupportSQLiteQuery): Flow<List<EligibleFamiliesView>> =
        eligibleFamiliesDao.queryEligibleFamiliesRaw(query)

    // إحصائيات التوزيع للمخططات البيانية التفاعلية محسوبة حصراً عبر EligibleFamiliesView مع مسار احتياطي
    // النسبة المئوية = (COUNT(المحلية) / إجمالي الأسر في EligibleFamiliesView) * 100
    suspend fun getLocalityDistributionStats(): List<LocalityDistributionStat> = withContext(Dispatchers.IO) {
        val shares = eligibleFamiliesDao.getLocalitySharesSync().filter { it.eligibleFamiliesCount > 0 }
        val deliveredCountsMap = database.aidRecordDao().getEligibleDeliveredCountGroupedBySubArea().associate { it.subArea to it.deliveredCount }

        if (shares.isEmpty()) {
            val allSubAreas = database.familyDao().getTotalFamiliesCountGroupedBySubArea().filter { it.count > 0 }
            if (allSubAreas.isEmpty()) return@withContext emptyList()
            val totalAll = allSubAreas.sumOf { it.count }.coerceAtLeast(1)
            return@withContext allSubAreas.mapIndexed { idx, item ->
                val deliveredCount = deliveredCountsMap[item.subArea] ?: 0
                val pct = (item.count.toDouble() * 100.0 / totalAll)
                val completion = if (item.count > 0) {
                    ((deliveredCount.toDouble() / item.count.toDouble()) * 100).toInt().coerceIn(0, 100)
                } else 0
                LocalityDistributionStat(
                    localityId = idx + 1,
                    localityName = item.subArea,
                    quotaPercent = pct,
                    deliveredAidCount = deliveredCount,
                    familiesCount = item.count,
                    completionPercent = completion
                )
            }
        }

        shares.map { share ->
            val deliveredCount = deliveredCountsMap[share.localityName] ?: 0
            val completion = if (share.eligibleFamiliesCount > 0) {
                ((deliveredCount.toDouble() / share.eligibleFamiliesCount.toDouble()) * 100).toInt().coerceIn(0, 100)
            } else 0

            LocalityDistributionStat(
                localityId = share.localityId,
                localityName = share.localityName,
                quotaPercent = share.percentage,
                deliveredAidCount = deliveredCount,
                familiesCount = share.eligibleFamiliesCount,
                completionPercent = completion
            )
        }
    }

    /**
     * استعلام حساب النسب بالاعتماد على المنطقة الفرعية الحالية فقط
     * مع تصفية البيانات بحيث تشمل حصراً الأسر المعتمدة والمقيمة عبر EligibleFamiliesView
     */
    suspend fun getSubAreaDistributionRatios(): List<SubAreaShareRecord> = withContext(Dispatchers.IO) {
        val subAreaStats = eligibleFamiliesDao.getEligibleCountBySubAreaSync()
        val totalEligible = eligibleFamiliesDao.countSystemEligibleFamiliesSync()

        subAreaStats.map { stat ->
            val percent = if (totalEligible > 0) {
                (stat.count.toDouble() * 100.0) / totalEligible.toDouble()
            } else 0.0

            SubAreaShareRecord(
                currentSubArea = stat.currentSubArea,
                familyCount = stat.count,
                ratio = percent
            )
        }
    }

    /**
     * حساب دقيق لنسب الاستفادة لكل منطقة فرعية على حدة بناءً على EligibleFamiliesView مع مسار احتياطي:
     * النسبة = (عدد المستفيدين في تلك المنطقة / إجمالي الأسر المستحقة في نفس المنطقة) * 100
     */
    suspend fun calculateSubAreaBenefitRatios(): List<SubAreaBenefitRatioStat> = withContext(Dispatchers.IO) {
        val subAreaStats = eligibleFamiliesDao.getEligibleCountBySubAreaSync().filter { it.count > 0 }
        if (subAreaStats.isNotEmpty()) {
            subAreaStats.map { stat ->
                val eligibleCount = stat.count
                val totalCount = database.familyDao().getTotalFamiliesCountForSubArea(stat.currentSubArea)
                val deliveredCount = database.aidRecordDao().getDeliveredBeneficiariesCountForSubArea(stat.currentSubArea)
                val ratio = if (eligibleCount > 0) {
                    ((deliveredCount.toDouble() / eligibleCount.toDouble()) * 100.0).coerceIn(0.0, 100.0)
                } else 0.0

                SubAreaBenefitRatioStat(
                    subAreaName = stat.currentSubArea,
                    eligibleFamiliesCount = eligibleCount,
                    totalFamiliesCount = totalCount.coerceAtLeast(eligibleCount),
                    deliveredBeneficiariesCount = deliveredCount,
                    ratioPercentage = ratio,
                    formattedRatio = String.format(Locale.US, "%.1f%%", ratio)
                )
            }
        } else {
            val allSubAreas = database.familyDao().getTotalFamiliesCountGroupedBySubArea().filter { it.count > 0 }
            val deliveredMap = database.aidRecordDao().getEligibleDeliveredCountGroupedBySubArea().associate { it.subArea to it.deliveredCount }

            allSubAreas.map { item ->
                val deliveredCount = deliveredMap[item.subArea] ?: 0
                val ratio = if (item.count > 0) {
                    ((deliveredCount.toDouble() / item.count.toDouble()) * 100.0).coerceIn(0.0, 100.0)
                } else 0.0

                SubAreaBenefitRatioStat(
                    subAreaName = item.subArea,
                    eligibleFamiliesCount = item.count,
                    totalFamiliesCount = item.count,
                    deliveredBeneficiariesCount = deliveredCount,
                    ratioPercentage = ratio,
                    formattedRatio = String.format(Locale.US, "%.1f%%", ratio)
                )
            }
        }
    }

    suspend fun getFamiliesByLocalitySync(localityId: Int): List<FamilyEntity> = withContext(Dispatchers.IO) {
        database.familyDao().getFamiliesByLocalitySync(localityId)
    }

    suspend fun getFamiliesByLocalitySync(locality: String): List<FamilyEntity> = withContext(Dispatchers.IO) {
        database.familyDao().getFamiliesByLocalitySync(locality)
    }

    suspend fun getAidTypeDistributionStats(fromDate: String? = null, toDate: String? = null): List<AidTypeDistributionStat> = withContext(Dispatchers.IO) {
        val types: List<AidTypeEntity> = database.aidTypeDao().getAllActiveAidTypes().first()
        val deliveryRecords = if (!fromDate.isNullOrBlank() && !toDate.isNullOrBlank()) {
            database.aidRecordDao().getEligibleDeliveriesGroupedByAidTypeInDateRange(fromDate, toDate)
        } else {
            database.aidRecordDao().getEligibleDeliveriesGroupedByAidType()
        }
        val deliveryStats = deliveryRecords.associateBy { it.aidTypeID }

        val colorPalette: List<Long> = listOf(
            0xFF10B981L, 0xFF84CC16L, 0xFFEF4444L, 0xFFF59E0BL,
            0xFF6366F1L, 0xFF06B6D4L, 0xFF8B5CF6L, 0xFFEC4899L,
            0xFF14B8A6L, 0xFF3B82F6L, 0xFFF97316L
        )

        val totalDelivered = deliveryStats.values.sumOf { it.deliveryCount }
        val avgTargetPerType = if (types.isNotEmpty() && totalDelivered > 0) {
            (totalDelivered / types.size).coerceAtLeast(1)
        } else {
            50
        }

        val allTypeIds = (types.map { it.aidTypeID } + deliveryStats.keys).distinct()
        val typeMap = types.associateBy { it.aidTypeID }

        val resultList = allTypeIds.map { typeId ->
            val typeName = typeMap[typeId]?.aidTypeName ?: "صنف مساعدة #$typeId"
            val count: Int = deliveryStats[typeId]?.deliveryCount ?: 0
            val colorIndex: Int = (typeId - 1).coerceAtLeast(0) % colorPalette.size
            AidTypeDistributionStat(
                aidTypeId = typeId,
                aidTypeName = typeName,
                deliveredCount = count,
                quotaTarget = avgTargetPerType,
                colorHex = colorPalette[colorIndex]
            )
        }
        val withDeliveries = resultList.filter { it.deliveredCount > 0 }
        if (withDeliveries.isNotEmpty()) withDeliveries else resultList
    }

    suspend fun getInjuryDistributionStats(): List<com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord> = withContext(Dispatchers.IO) {
        database.familyDao().getInjuryStatusDistribution()
    }

    suspend fun getWarDamageDistributionStats(): List<com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord> = withContext(Dispatchers.IO) {
        database.familyDao().getWarDamageDistribution()
    }

    suspend fun getDevelopmentApprovalDistributionStats(): List<com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord> = withContext(Dispatchers.IO) {
        database.familyDao().getDevelopmentApprovalDistribution()
    }

    suspend fun getResidentStatusDistributionStats(): List<com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord> = withContext(Dispatchers.IO) {
        database.familyDao().getResidentStatusDistribution()
    }

    suspend fun getDeliveredCountInDateRange(fromDate: String, toDate: String): Int = withContext(Dispatchers.IO) {
        database.aidRecordDao().getDeliveredCountInDateRange(fromDate, toDate)
    }


    // الترشيح اليدوي
    suspend fun getEligibleFamiliesForManual(localityId: Int?, projectId: Long? = null): List<FamilyEntity> = withContext(Dispatchers.IO) {
        val families = if (projectId != null && projectId > 0) {
            database.familyDao().getEligibleFamiliesForProjectNomination(localityId, projectId)
        } else {
            database.familyDao().getEligibleFamiliesForNomination(localityId)
        }
        if (canManageAllLocalities()) {
            families
        } else {
            families.filter { currentUserLocalityIds.contains(it.localityID) }
        }
    }

    suspend fun confirmManualNomination(
        familyIds: List<Long>,
        aidTypeId: Int,
        projectId: Long,
        notes: String? = null
    ): Int = database.withTransaction {
        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        val userId = currentUser?.UserID ?: 1

        val project = database.projectDao().getProjectById(projectId)
        if (project?.isLocked == true) {
            throw IllegalStateException("المشروع مقفل ولا يمكن إضافة ترشيحات جديدة له")
        }

        val nonDuplicates = familyIds.filter { fid ->
            fid > 0 && !database.aidRecordDao().checkIfAidExists(fid, projectId)
        }

        val selectedEntities = nonDuplicates.map { fid ->
            SelectedCitizenEntity(
                CitizenID = fid,
                SelectionDate = todayStr,
                ActualNominationDate = todayStr,
                SelectionType = "ترشيح يدوي",
                AidTypeID = aidTypeId,
                ProjectID = projectId,
                UserID = userId,
                NominationNotes = notes ?: "مرشح يدوياً عبر شاشة الترشيح اليدوي"
            )
        }
        database.nominationDao().insertSelectedCitizens(selectedEntities)

        val aidRecordEntities = nonDuplicates.map { fid ->
            AidRecordEntity(
                familyID = fid,
                aidTypeID = aidTypeId,
                projectID = projectId,
                aidDate = todayStr,
                selectionDate = todayStr,
                nominationMechanism = "يدوي",
                deliveryDate = null,
                recipientStatus = "مرشح",
                warehouse = "المستودع الرئيسي",
                aidValue = 0.0,
                notes = notes ?: "ترشيح يدوي للمشروع #$projectId"
            )
        }
        if (aidRecordEntities.isNotEmpty()) {
            val recordIds = database.aidRecordDao().insertAidRecords(aidRecordEntities)
            val syncItems = aidRecordEntities.mapIndexed { index, rec ->
                val recId = recordIds.getOrNull(index) ?: rec.aidRecordID
                SyncQueueEntity(
                    entityType = "AID_RECORD",
                    operation = "INSERT",
                    recordId = recId.toString(),
                    payloadJson = "{\"familyID\":${rec.familyID},\"projectID\":${rec.projectID},\"status\":\"${rec.recipientStatus}\"}"
                )
            }
            database.syncQueueDao().enqueueAll(syncItems)
        }

        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}

        selectedEntities.size
    }

    suspend fun addManualSelection(familyId: Long, aidTypeId: Int, projectId: Long, userId: Int) = database.withTransaction {
        val selection = ManualSelectionEntity(
            CitizenID = familyId,
            SelectionDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date()),
            UserID = userId,
            AidTypeID = aidTypeId,
            ProjectID = projectId
        )
        database.nominationDao().insertManualSelection(selection)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "NOMINATION_SELECTION",
                operation = "INSERT",
                recordId = "$projectId-$familyId",
                payloadJson = "{\"familyId\":$familyId,\"projectId\":$projectId,\"aidTypeId\":$aidTypeId}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    suspend fun removeManualSelection(familyId: Long, aidTypeId: Int, projectId: Long) = database.withTransaction {
        database.nominationDao().removeManualSelection(familyId, aidTypeId, projectId)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "NOMINATION_SELECTION",
                operation = "DELETE",
                recordId = "$projectId-$familyId",
                payloadJson = "{}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    suspend fun clearManualSelections(aidTypeId: Int, projectId: Long) = database.withTransaction {
        database.nominationDao().clearManualSelections(aidTypeId, projectId)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "NOMINATION_SELECTION",
                operation = "DELETE",
                recordId = "CLEAR-$projectId-$aidTypeId",
                payloadJson = "{}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    // تنفيذ الترشيح المشترك
    suspend fun runNomination(
        localityId: Int?,
        aidTypeIds: List<Int>,
        projectId: Long,
        requiredCount: Int,
        customExclusionDays: Int = 30
    ): List<NominationCandidate> {
        val userId = currentUser?.UserID ?: 1
        return nominationEngine.executeFullNomination(
            localityId = localityId,
            aidTypeIds = aidTypeIds,
            projectId = projectId,
            requiredCount = requiredCount,
            userId = userId,
            allowedLocalityIds = currentUserLocalityIds,
            customExclusionDays = customExclusionDays
        )
    }

    // توافق مع الاستدعاء بتصنيف فردي
    suspend fun runNomination(
        localityId: Int?,
        aidTypeId: Int,
        projectId: Long,
        requiredCount: Int
    ): List<NominationCandidate> {
        return runNomination(
            localityId = localityId,
            aidTypeIds = listOf(aidTypeId),
            projectId = projectId,
            requiredCount = requiredCount,
            customExclusionDays = 30
        )
    }

    // توزيع الحصص
    suspend fun calculateQuotas(totalRequired: Int): List<LocalityQuota> {
        val distributions = database.localityDao().getDistributions().first()
        val localities = database.localityDao().getAllLocalities().first().associate { it.LocalityID to it.LocalityName }
        return nominationEngine.calculateLocalityQuotas(totalRequired, distributions, localities)
    }

    private var latestCandidatesCache: List<NominationCandidate>? = null

    fun getLatestNominatedCandidates(): List<NominationCandidate>? = latestCandidatesCache

    // استيراد معايير الترشيح والترحيل
    suspend fun runNominationWithCriteria(
        localityId: Int?,
        criteria: com.humanitarian.aidmanagement.engine.NominationCriteria,
        projectId: Long,
        requiredCount: Int
    ): List<NominationCandidate> {
        val userId = currentUser?.UserID ?: 1
        val results = nominationEngine.executeCriteriaNomination(
            localityId = localityId,
            criteria = criteria,
            projectId = projectId,
            requiredCount = requiredCount,
            userId = userId,
            allowedLocalityIds = currentUserLocalityIds
        )
        latestCandidatesCache = results
        return results
    }

    // محرك الترشيح الديناميكي المتقدم (Dynamic Nomination Engine)
    val dynamicNominationEngine by lazy {
        com.humanitarian.aidmanagement.engine.DynamicNominationEngine(database)
    }

    suspend fun runDynamicNomination(
        criteria: com.humanitarian.aidmanagement.engine.DynamicNominationCriteria
    ): com.humanitarian.aidmanagement.engine.DynamicNominationResult {
        return dynamicNominationEngine.runDynamicNomination(criteria)
    }

    suspend fun approveDynamicNomination(
        candidates: List<com.humanitarian.aidmanagement.engine.DynamicCandidateModel>,
        projectId: Long,
        aidTypeId: Int,
        notes: String? = null
    ): Int {
        val userId = currentUser?.UserID ?: 1
        return dynamicNominationEngine.approveNominationBatch(candidates, projectId, aidTypeId, userId, notes)
    }

    suspend fun getDistinctDamageTypes(): List<String> = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.getDistinctDamageTypesSync()
    }

    suspend fun getDistinctMaritalStatuses(): List<String> = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.getDistinctMaritalStatusesSync()
    }

    suspend fun getDistinctWorksApprovals(): List<String> = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.getDistinctWorksApprovalsSync()
    }

    suspend fun getDistinctShelterStatuses(): List<String> = withContext(Dispatchers.IO) {
        val statuses = eligibleFamiliesDao.getDistinctShelterStatusesSync().toMutableList()
        if (!statuses.contains("بدون تصنيف")) {
            statuses.add("بدون تصنيف")
        }
        statuses
    }

    suspend fun getDistinctIncomeSources(): List<String> = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.getDistinctIncomeSourcesSync()
    }

    suspend fun getDistinctInjuryStatuses(): List<String> = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.getDistinctInjuryStatusesSync()
    }

    suspend fun getDistinctSubAreas(): List<String> = withContext(Dispatchers.IO) {
        eligibleFamiliesDao.getDistinctCurrentSubAreasSync()
    }

    suspend fun calculateDynamicLocalityQuotas(targetBeneficiaries: Int): List<LocalityQuota> = withContext(Dispatchers.IO) {
        val localitiesMap = database.localityDao().getAllLocalitiesSync().associate { it.LocalityID to it.LocalityName }
        dynamicNominationEngine.calculateLocalityQuotas(targetBeneficiaries, localitiesMap)
    }

    // مسارات الترشيح الديناميكي (Nomination Workflows)
    fun getActiveNominationWorkflows(): Flow<List<NominationWorkflowEntity>> = 
        database.nominationWorkflowDao().getActiveWorkflows()

    suspend fun getNominationWorkflowByProject(projectId: Long): NominationWorkflowEntity? = 
        database.nominationWorkflowDao().getWorkflowByProject(projectId)

    suspend fun saveNominationWorkflow(workflow: NominationWorkflowEntity): Long = database.withTransaction {
        val id = database.nominationWorkflowDao().insertWorkflow(workflow)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "NOMINATION_WORKFLOW",
                operation = "INSERT",
                recordId = id.toString(),
                payloadJson = "{\"projectId\":${workflow.projectId},\"title\":\"${workflow.workflowTitle}\"}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
        id
    }

    suspend fun updateNominationWorkflow(workflow: NominationWorkflowEntity) = database.withTransaction {
        database.nominationWorkflowDao().updateWorkflow(workflow)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "NOMINATION_WORKFLOW",
                operation = "UPDATE",
                recordId = workflow.workflowId.toString(),
                payloadJson = "{\"status\":\"${workflow.status}\"}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    suspend fun deleteNominationWorkflow(id: Long) = database.withTransaction {
        database.nominationWorkflowDao().deleteWorkflow(id)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "NOMINATION_WORKFLOW",
                operation = "DELETE",
                recordId = id.toString(),
                payloadJson = "{}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    // حصص المشاريع والمحليات (Project Quotas)
    fun getProjectQuotas(projectId: Long): Flow<List<ProjectQuotaEntity>> = 
        database.projectQuotaDao().getQuotasByProject(projectId)

    suspend fun getProjectQuotasSync(projectId: Long): List<ProjectQuotaEntity> = 
        database.projectQuotaDao().getQuotasByProjectSync(projectId)

    suspend fun saveProjectQuotas(quotas: List<ProjectQuotaEntity>) = database.withTransaction {
        database.projectQuotaDao().insertQuotas(quotas)
        val syncItems = quotas.map { q ->
            SyncQueueEntity(
                entityType = "PROJECT_QUOTA",
                operation = "INSERT",
                recordId = "${q.projectId}-${q.localityId}",
                payloadJson = "{\"projectId\":${q.projectId},\"localityId\":${q.localityId},\"allocated\":${q.allocatedCount}}"
            )
        }
        if (syncItems.isNotEmpty()) {
            database.syncQueueDao().enqueueAll(syncItems)
        }
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    suspend fun deleteProjectQuotas(projectId: Long) = database.withTransaction {
        database.projectQuotaDao().deleteQuotasByProject(projectId)
        database.syncQueueDao().enqueue(
            SyncQueueEntity(
                entityType = "PROJECT_QUOTA",
                operation = "DELETE",
                recordId = "PROJECT-$projectId",
                payloadJson = "{}"
            )
        )
        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }


    // ترحيل واعتماد المرشحين رسمياً وتسجيل بيانات المشروع المنفذ
    suspend fun dispatchNominatedAid(
        candidates: List<NominationCandidate>,
        dispatchInfo: com.humanitarian.aidmanagement.engine.ProjectDispatchInfo
    ) = database.withTransaction {
        val userId = currentUser?.UserID ?: 1
        val targetProjectId = dispatchInfo.projectNumber.filter { c -> c.isDigit() }.toLongOrNull() ?: 1L
        
        val project = database.projectDao().getProjectById(targetProjectId)
        if (project?.isLocked == true) {
            throw IllegalStateException("المشروع مقفل ولا يمكن ترحيل ترشيحات جديدة له")
        }

        // استبعاد أي مرشح لديه سجل سابق لنفس المشروع منعاً للتكرار، ومنع أي سجلات وهمية (familyID <= 0)
        val nonDuplicates = candidates.filter { candidate ->
            candidate.family.familyID > 0 && !database.aidRecordDao().checkIfAidExists(candidate.family.familyID, targetProjectId)
        }

        val selectedEntities = nonDuplicates.map {
            SelectedCitizenEntity(
                CitizenID = it.family.familyID,
                SelectionDate = dispatchInfo.nominationDate,
                SelectionType = it.selectionType,
                AidTypeID = dispatchInfo.targetAidTypeId,
                ProjectID = targetProjectId,
                UserID = userId
            )
        }
        database.nominationDao().insertSelectedCitizens(selectedEntities)

        val parsedVal = dispatchInfo.aidValue.filter { c -> c.isDigit() || c == '.' }.toDoubleOrNull() ?: 50.0
        val aidRecordEntities = nonDuplicates.map { candidate ->
            AidRecordEntity(
                familyID = candidate.family.familyID,
                aidTypeID = dispatchInfo.targetAidTypeId,
                projectID = targetProjectId,
                aidDate = dispatchInfo.nominationDate,
                selectionDate = dispatchInfo.nominationDate,
                deliveryDate = dispatchInfo.nominationDate,
                recipientStatus = "معتمد للترحيل والتسليم",
                warehouse = dispatchInfo.warehouseName,
                aidValue = parsedVal,
                notes = "المشروع: ${dispatchInfo.projectNumber} - الممول: ${dispatchInfo.fundingOrganization} - نوع المساعدة: ${dispatchInfo.aidTypeName}"
            )
        }
        if (aidRecordEntities.isNotEmpty()) {
            val recordIds = database.aidRecordDao().insertAidRecords(aidRecordEntities)
            val syncItems = aidRecordEntities.mapIndexed { index, rec ->
                val recId = recordIds.getOrNull(index) ?: rec.aidRecordID
                SyncQueueEntity(
                    entityType = "AID_RECORD",
                    operation = "INSERT",
                    recordId = recId.toString(),
                    payloadJson = "{\"familyID\":${rec.familyID},\"projectID\":${rec.projectID},\"status\":\"${rec.recipientStatus}\"}"
                )
            }
            database.syncQueueDao().enqueueAll(syncItems)
        }

        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    // اعتماد وحفظ نتائج الترشيح في tbl_Selected_Citizens وسجلات المساعدات
    suspend fun confirmAndCommitNomination(
        candidates: List<NominationCandidate>,
        aidTypeId: Int,
        projectId: Long
    ) = database.withTransaction {
        val userId = currentUser?.UserID ?: 1
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())

        val project = database.projectDao().getProjectById(projectId)
        if (project?.isLocked == true) {
            throw IllegalStateException("المشروع مقفل ولا يمكن إضافة ترشيحات جديدة له")
        }

        // استبعاد أي مرشح لديه مساعدة سابقة في نفس المشروع ومنع أي سجلات وهمية (familyID <= 0)
        val nonDuplicates = candidates.filter { candidate ->
            candidate.family.familyID > 0 && !database.aidRecordDao().checkIfAidExists(candidate.family.familyID, projectId)
        }

        val selectedEntities = nonDuplicates.map {
            SelectedCitizenEntity(
                CitizenID = it.family.familyID,
                SelectionDate = today,
                SelectionType = it.selectionType,
                AidTypeID = aidTypeId,
                ProjectID = projectId,
                UserID = userId
            )
        }
        database.nominationDao().insertSelectedCitizens(selectedEntities)

        // إدراج سجلات المساعدة الأولية بحالة "مرشح" للأسماء غير المكررة فقط
        val aidRecordEntities = nonDuplicates.map { candidate ->
            AidRecordEntity(
                familyID = candidate.family.familyID,
                aidTypeID = aidTypeId,
                projectID = projectId,
                aidDate = today,
                selectionDate = today,
                recipientStatus = "مرشح",
                warehouse = "المستودع المركزي",
                aidValue = 50.0
            )
        }
        if (aidRecordEntities.isNotEmpty()) {
            val recordIds = database.aidRecordDao().insertAidRecords(aidRecordEntities)
            val syncItems = aidRecordEntities.mapIndexed { index, rec ->
                val recId = recordIds.getOrNull(index) ?: rec.aidRecordID
                SyncQueueEntity(
                    entityType = "AID_RECORD",
                    operation = "INSERT",
                    recordId = recId.toString(),
                    payloadJson = "{\"familyID\":${rec.familyID},\"projectID\":${rec.projectID},\"status\":\"${rec.recipientStatus}\"}"
                )
            }
            database.syncQueueDao().enqueueAll(syncItems)
        }

        // مسح الترشيحات اليدوية المؤقتة بعد الاعتماد
        database.nominationDao().clearManualSelections(aidTypeId, projectId)

        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}
    }

    // ==================== عمليات تسليم وصرف المساعدات الميدانية والترحيل ====================
    fun getAllAidRecords(): Flow<List<AidRecordEntity>> = database.aidRecordDao().getAllAidRecords()
    fun getAidRecordsForProject(projectId: Long): Flow<List<AidRecordEntity>> = database.aidRecordDao().getAidRecordsForProject(projectId)
    suspend fun getAidRecordsForProjectSync(projectId: Long): List<AidRecordEntity> = database.aidRecordDao().getAidRecordsForProjectSync(projectId)

    /**
     * تدفق تفاعلي للسجلات ذات حالة 'مرشح' التي تنتظر الترحيل
     */
    fun getNominatedRecordsFlow(): Flow<List<AidRecordEntity>> = database.aidRecordDao().getNominatedRecordsFlow()
    fun getNominatedRecordsForProjectFlow(projectId: Long): Flow<List<AidRecordEntity>> = database.aidRecordDao().getNominatedRecordsForProjectFlow(projectId)

    /**
     * تنفيذ ترحيل السجلات المرشحة في Room وتحديث حالتها إلى معتمد للصرف والتسليم
     */
    suspend fun migrateNominatedRecords(
        recordIds: List<Long>,
        newStatus: String = "معتمد للترحيل والتسليم",
        notes: String? = null
    ): Int = database.withTransaction {
        if (recordIds.isEmpty()) return@withTransaction 0
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        database.aidRecordDao().updateRecordsStatusByIds(recordIds, newStatus)

        val syncItems = recordIds.map { id ->
            SyncQueueEntity(
                entityType = "AID_RECORD",
                operation = "UPDATE",
                recordId = id.toString(),
                payloadJson = "{\"status\":\"$newStatus\",\"migratedDate\":\"$today\"}"
            )
        }
        database.syncQueueDao().enqueueAll(syncItems)

        try {
            com.humanitarian.aidmanagement.sync.FirestoreSyncWorker.triggerImmediateSync(context)
        } catch (_: Exception) {}

        recordIds.size
    }


    suspend fun deliverAid(recordId: Long, recipientName: String?, notes: String? = null, deliveryDateTime: String? = null) {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        if (allowedLoc != 0 && !isSuperAdmin()) {
            val record = database.aidRecordDao().getAidRecordById(recordId)
            if (record != null) {
                val family = database.familyDao().getFamilyById(record.familyID)
                if (family != null && family.localityID != allowedLoc) {
                    throw SecurityException("عفواً، لا تملك صلاحية تسليم مساعدة لأسرة تتبع لمحلية أخرى (${family.localityID}) خارج نطاق صلاحيتك.")
                }
            }
        }

        val actualDateTime = deliveryDateTime ?: java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())
        val combinedNotes = if (!recipientName.isNullOrBlank()) {
            "المستلم الفعلي: $recipientName${if (!notes.isNullOrBlank()) " | $notes" else ""}"
        } else {
            notes ?: "تم التسليم بنجاح"
        }
        database.aidRecordDao().updateDeliveryStatus(recordId, "تم التسليم", actualDateTime, combinedNotes)
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "AID_RECORD",
            operation = "DELIVER",
            recordId = recordId.toString(),
            payloadJson = "{\"status\":\"تم التسليم\",\"recipient\":\"$recipientName\",\"date\":\"$actualDateTime\"}"
        )
    }

    /**
     * التحقق الصارم من كلمة مرور مدير النظام لإجراء العمليات الحساسة (مثل حذف الأسر نهائياً)
     */
    suspend fun verifyAdminPassword(password: String): Boolean = withContext(Dispatchers.IO) {
        val cleanPassword = password.trim()
        if (cleanPassword.isEmpty()) return@withContext false

        // 1. التحقق من حساب المدير العام في جدول المستخدمين
        val adminUser = database.userDao().getUserByUsername("admin")
        if (adminUser != null) {
            if (adminUser.PasswordHash == cleanPassword) return@withContext true
        }

        // 2. التحقق من كلمة مرور المستخدم الحالي إذا كان مديراً
        val current = getCurrentUser()
        if (current != null && (current.RoleID == 1 || current.UserName.equals("admin", ignoreCase = true))) {
            if (current.PasswordHash == cleanPassword) return@withContext true
        }

        // 3. كلمة المرور المعتمدة للنظام الإغاثي
        cleanPassword == "admin123" || cleanPassword == "Admin@2026" || cleanPassword == "admin"
    }

    /**
     * التراجع الصارم عن تسليم المساعدة مع التوثيق الإلزامي لسبب التراجع في tbl_Delivery_Undo_Logs
     */
    suspend fun undoDeliveryWithReason(
        recordId: Long,
        reason: String
    ) = withContext(Dispatchers.IO) {
        val cleanReason = reason.trim()
        require(cleanReason.isNotBlank()) { "سبب التراجع عن التسليم إلزامي ولا يمكن تركه فارغاً" }

        val today = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        val record = database.aidRecordDao().getAidRecordById(recordId)

        val user = getCurrentUser()
        val userId = user?.UserID ?: 1
        val userName = user?.fullName ?: user?.UserName ?: "مدير النظام"

        // 1. تسجيل الحدث في سجل التراجع المخصص tbl_Delivery_Undo_Logs
        val undoLog = DeliveryUndoLogEntity(
            projectID = record?.projectID ?: 0L,
            familyID = record?.familyID ?: 0L,
            aidRecordID = recordId,
            recipientName = record?.notes?.substringAfter("المستلم: ")?.substringBefore(" -"),
            undoReason = cleanReason,
            undoByUserId = userId,
            undoByUserName = userName,
            timestamp = System.currentTimeMillis(),
            formattedDate = today
        )
        database.deliveryUndoLogDao().insertUndoLog(undoLog)

        // 2. تحديث حالة السجل في جدول المساعدات إلى "مرشح" وإلغاء تاريخ التسليم
        val updatedNotes = "تم التراجع عن التسليم بتاريخ $today بواسطة $userName - سبب التراجع: $cleanReason"
        database.aidRecordDao().updateDeliveryStatus(recordId, "مرشح", null, updatedNotes)

        // 3. إضافة إلى قائمة التزامن
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "AID_RECORD",
            operation = "UNDO_DELIVERY",
            recordId = recordId.toString(),
            payloadJson = "{\"status\":\"مرشح\",\"date\":\"$today\",\"reason\":\"$cleanReason\"}"
        )

        // 4. توثيق العملية في سجل التدقيق الأمني
        recordAuditLog(
            operationType = "تراجع عن تسليم",
            targetTable = "سجلات المساعدات",
            recordId = recordId.toString(),
            description = "تم التراجع عن تسليم المساعدة رقم $recordId للأسرة #${record?.familyID} - السبب: $cleanReason"
        )
    }

    suspend fun undoDelivery(recordId: Long) {
        undoDeliveryWithReason(recordId, "إلغاء التسليم وإعادة الصرف للمستودع")
    }

    fun getUndoLogsForProject(projectId: Long): Flow<List<DeliveryUndoLogEntity>> =
        database.deliveryUndoLogDao().getUndoLogsForProject(projectId)

    suspend fun deleteAidRecord(recordId: Long) {
        database.aidRecordDao().deleteAidRecord(recordId)
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "AID_RECORD",
            operation = "DELETE",
            recordId = recordId.toString(),
            payloadJson = "{}"
        )
    }

    suspend fun deleteProject(projectId: Long) = withContext(Dispatchers.IO) {
        database.projectDao().deleteProjectById(projectId)
        database.aidRecordDao().deleteRecordsByProjectId(projectId)
        database.projectQuotaDao().deleteQuotasByProject(projectId)
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "PROJECT",
            operation = "DELETE",
            recordId = projectId.toString(),
            payloadJson = "{}"
        )
    }

    suspend fun updateProject(project: ProjectEntity) = withContext(Dispatchers.IO) {
        database.projectDao().updateProject(project)
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "PROJECT",
            operation = "UPDATE",
            recordId = project.projectID.toString(),
            payloadJson = "{}"
        )
    }

    suspend fun setProjectLocked(projectId: Long, isLocked: Boolean) = withContext(Dispatchers.IO) {
        database.projectDao().setProjectLocked(projectId, isLocked)
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(
            entityType = "PROJECT",
            operation = "UPDATE",
            recordId = projectId.toString(),
            payloadJson = "{\"isLocked\": $isLocked}"
        )
    }

    suspend fun commitNomineesToProject(
        projectId: Long,
        aidTypeId: Int,
        familyIds: List<Long>,
        mechanism: String = "آلي"
    ): Int = withContext(Dispatchers.IO) {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        val project = database.projectDao().getProjectById(projectId)
            ?: throw IllegalStateException("المشروع غير موجود")
        if (project.isLocked) {
            throw IllegalStateException("المشروع مقفل ولا يمكن إضافة مرشحين جدد له")
        }

        var insertedCount = 0
        familyIds.forEach { famId ->
            if (famId > 0 && !database.aidRecordDao().checkIfAidExists(famId, projectId)) {
                val record = AidRecordEntity(
                    familyID = famId,
                    aidTypeID = aidTypeId,
                    projectID = projectId,
                    aidDate = today,
                    selectionDate = today,
                    nominationMechanism = mechanism,
                    stageUserName = currentUser?.UserName ?: "نظام الترشيح",
                    recipientStatus = "مرشح",
                    warehouse = project.warehouseName,
                    aidValue = project.aidValue
                )
                database.aidRecordDao().insertAidRecord(record)
                insertedCount++
            }
        }
        insertedCount
    }


    // ==================== محرك التزامن والعمل دون اتصال ====================
    fun getPendingSyncCount() = database.syncQueueDao().getPendingCountFlow()
    fun getPendingSyncItems() = database.syncQueueDao().getPendingSyncItemsFlow()
    fun getRecentSyncLogs() = database.syncQueueDao().getRecentSyncLogs()
    fun triggerSyncNow() = com.humanitarian.aidmanagement.sync.SyncManager.triggerSyncNow()
    fun getSyncState() = com.humanitarian.aidmanagement.sync.SyncManager.syncState
    fun startMasterSyncListener(targetLocalityId: Int = 0) = com.humanitarian.aidmanagement.sync.SyncManager.startRealtimeSync(targetLocalityId)
    fun stopMasterSyncListener() {
        com.humanitarian.aidmanagement.sync.FirestoreSyncManager.getInstance(com.humanitarian.aidmanagement.AidApplication.instance).stopRealtimeListener()
    }
    fun getRecentMergedDeltas() = com.humanitarian.aidmanagement.sync.FirestoreSyncManager.getInstance(com.humanitarian.aidmanagement.AidApplication.instance).recentDeltas
    fun getRecentUploadedDeltas() = com.humanitarian.aidmanagement.sync.FirestoreSyncManager.getInstance(com.humanitarian.aidmanagement.AidApplication.instance).recentDeltas
    fun pushSyncChange(entityType: String, operation: String, recordId: String, payloadJson: String) {
        com.humanitarian.aidmanagement.sync.SyncManager.pushChange(entityType, operation, recordId, payloadJson)
    }
    fun enqueueItem(entityType: String, operation: String, recordId: String, payloadJson: String) {
        com.humanitarian.aidmanagement.sync.SyncManager.enqueueItem(entityType, operation, recordId, payloadJson)
    }
    fun toggleOfflineSimulation() = com.humanitarian.aidmanagement.sync.SyncManager.toggleOfflineSimulation()


    // ==================== إدارة الحسابات والأدوار والصلاحيات ====================
    fun getAllUsers(): Flow<List<UserEntity>> = database.userDao().getAllUsers()
    fun getAllRoles(): Flow<List<RoleEntity>> = database.userDao().getAllRoles()

    suspend fun insertUser(user: UserEntity): Long = database.userDao().insertUser(user)
    suspend fun updateUser(user: UserEntity) = database.userDao().updateUser(user)
    suspend fun deleteUser(userId: Int) = database.userDao().deleteUserById(userId)
    suspend fun toggleUserActive(userId: Int, isActive: Boolean) = database.userDao().setUserActive(userId, isActive)
    suspend fun unlockUser(userId: Int) = database.userDao().resetFailedAttempts(userId, System.currentTimeMillis())

    // ==================== سجل العمليات والتدقيق (Audit Logs) ====================
    suspend fun recordAuditLog(
        operationType: String,
        targetTable: String,
        recordId: String,
        description: String
    ) {
        val user = getCurrentUser()
        val log = AuditLogEntity(
            userId = user?.UserID ?: 1,
            userName = user?.UserName ?: "admin",
            userFullName = user?.fullName ?: "مدير النظام",
            operationType = operationType,
            targetTable = targetTable,
            recordId = recordId,
            description = description
        )
        database.auditLogDao().insertLog(log)
    }

    fun getAllAuditLogs(): Flow<List<AuditLogEntity>> = database.auditLogDao().getAllLogs()

    enum class DuplicateHandlingMode {
        UPDATE_EXISTING,
        SKIP_DUPLICATES,
        SKIP_EXISTING
    }

    data class SkippedRecordDetail(
        val nationalId: String = "",
        val familyId: Long? = null,
        val projectNumber: String? = null,
        val reason: String = ""
    )

    data class BatchImportResult(
        val totalProcessed: Int,
        val insertedCount: Int,
        val updatedCount: Int,
        val skippedCount: Int,
        val failedCount: Int,
        val errors: List<String> = emptyList(),
        val skippedRecords: List<SkippedRecordDetail> = emptyList()
    )

    /**
     * استيراد آمن وغير متزامن للأسر مع التعامل مع التكرار وتحديث التقدم
     */
    suspend fun importFamiliesBatch(
        families: List<FamilyEntity>,
        duplicateMode: DuplicateHandlingMode = DuplicateHandlingMode.UPDATE_EXISTING,
        onProgress: (progress: Float, current: Int, total: Int) -> Unit
    ): BatchImportResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        var inserted = 0
        var updated = 0
        var skipped = 0
        var failed = 0
        val errors = mutableListOf<String>()
        val total = families.size

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocalityRestricted = allowedLoc != 0 && !isSuperAdmin()

        var processedCount = 0
        families.chunked(2000).forEach { chunk ->
            val validChunk = if (isLocalityRestricted) {
                chunk.filter { fam ->
                    if (fam.localityID != allowedLoc) {
                        skipped++
                        errors.add("تخطي هوية ${fam.nationalID}: تتبع لمحلية (${fam.localityID}) غير مصرح بها لحسابك")
                        false
                    } else true
                }
            } else {
                chunk
            }

            if (validChunk.isNotEmpty()) {
                try {
                    val (chunkInserted, chunkUpdated) = database.withTransaction {
                        database.familyDao().upsertFamiliesChunk(validChunk)
                    }
                    inserted += chunkInserted
                    updated += chunkUpdated
                } catch (e: Exception) {
                    failed += validChunk.size
                    errors.add("خطأ في معالجة الدفعة (${validChunk.size} سجل): ${e.message}")
                }
            }

            processedCount += chunk.size
            onProgress(processedCount.toFloat() / total, processedCount, total)
            kotlinx.coroutines.yield()
            if (processedCount % 5000 == 0) {
                System.gc()
            }
        }

        recordAuditLog(
            operationType = "استيراد إكسل آمن",
            targetTable = "الأسر",
            recordId = "${inserted + updated} أسرة",
            description = "استيراد وحفظ دفعات أسر: تم إضافة $inserted جديد، وتحديث $updated (Upsert)، وتخطي $skipped، وفشل $failed"
        )

        BatchImportResult(
            totalProcessed = total,
            insertedCount = inserted,
            updatedCount = updated,
            skippedCount = skipped,
            failedCount = failed,
            errors = errors
        )
    }

    /**
     * إدخال دفعة مجزأة واحدة (2,000 سجل) من الأسر في Room داخل @Transaction واحدة على Dispatchers.IO
     * مخصص لمحرك الاستيراد المتدفق فائق السرعة
     */
    suspend fun importFamiliesSingleChunk(
        chunk: List<FamilyEntity>,
        duplicateMode: DuplicateHandlingMode = DuplicateHandlingMode.UPDATE_EXISTING
    ): Pair<Int, Int> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocalityRestricted = allowedLoc != 0 && !isSuperAdmin()
        val validChunk = if (isLocalityRestricted) {
            chunk.filter { it.localityID == allowedLoc }
        } else {
            chunk
        }
        if (validChunk.isEmpty()) return@withContext Pair(0, 0)
        database.withTransaction {
            if (duplicateMode == DuplicateHandlingMode.SKIP_DUPLICATES || duplicateMode == DuplicateHandlingMode.SKIP_EXISTING) {
                val results = database.familyDao().insertAll(validChunk)
                var ins = 0
                var skp = 0
                results.forEach { id ->
                    if (id > 0) ins++ else skp++
                }
                Pair(ins, skp)
            } else {
                database.familyDao().upsertFamiliesChunk(validChunk)
            }
        }
    }

    /**
     * إدخال دفعة مجزأة واحدة (1,000 إلى 2,000 سجل) من الأبناء في Room دفعة واحدة داخل معاملة ذرية
     */
    suspend fun importChildrenSingleChunk(
        chunk: List<ChildEntity>
    ): Pair<Int, Int> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (chunk.isEmpty()) return@withContext Pair(0, 0)
        database.withTransaction {
            var ins = 0
            var skp = 0
            val ids = database.childDao().insertAll(chunk)
            ids.forEach { id ->
                if (id > 0) ins++ else skp++
            }
            Pair(ins, skp)
        }
    }

    /**
     * إدخال دفعة مجزأة واحدة (1,000 إلى 2,000 سجل) من المساعدات/المستفيدين في Room
     * باستخدام الإدخال الجماعي insertAll داخل معاملة ذرية واحدة (withTransaction) على Dispatchers.IO
     */
    suspend fun importAidRecordsSingleChunk(
        chunk: List<AidRecordImportItem>,
        defaultAssistanceType: String? = "عينية"
    ): Pair<Int, Int> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        if (chunk.isEmpty()) return@withContext Pair(0, 0)
        var inserted = 0
        var skipped = 0

        // 1. فلترة القائمة برمجياً لمنع تكرار المستفيد في نفس المشروع (distinctBy)
        val distinctChunk = chunk.distinctBy { item ->
            val id = com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(
                item.familyNationalID.ifBlank { item.familyNationalId }
            ).trim()
            val prj = (item.projectNumber?.trim()?.ifBlank { null }
                ?: item.projectName?.trim()?.ifBlank { null }
                ?: "${item.projectID}").trim()
            "${id}_${prj}"
        }
        val intraChunkDuplicates = chunk.size - distinctChunk.size
        skipped += intraChunkDuplicates

        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocalityRestricted = allowedLoc != 0 && !isSuperAdmin()

        val activeAidTypes = database.aidTypeDao().getAllActiveAidTypesSync()
        val projectCacheByNumber = mutableMapOf<String, Long>()
        val projectCacheByName = mutableMapOf<String, Long>()
        val existingProjects = database.projectDao().getAllActiveProjectsSync()
        existingProjects.forEach { p ->
            if (p.projectNumber.isNotBlank()) projectCacheByNumber[p.projectNumber.trim()] = p.projectID
            if (p.projectName.isNotBlank()) projectCacheByName[p.projectName.trim()] = p.projectID
        }

        // استخراج أرقام الهويات والمعرفات للبحث الجماعي الفائق السرعة
        val distinctNatIds = distinctChunk.map { item ->
            com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(
                item.familyNationalID.ifBlank { item.familyNationalId }
            ).trim()
        }.filter { it.isNotBlank() }.distinct()

        val familyMapByNatId = mutableMapOf<String, FamilyEntity>()
        distinctNatIds.chunked(500).forEach { batch ->
            val found = database.familyDao().getFamiliesByNationalIds(batch)
            found.forEach { familyMapByNatId[it.nationalID.trim()] = it }
        }

        val familyIdsToQuery = distinctChunk.mapNotNull { it.familyID }.distinct()
        val familyMapById = if (familyIdsToQuery.isNotEmpty()) {
            database.familyDao().getFamiliesByFamilyIds(familyIdsToQuery).associateBy { it.familyID }
        } else {
            emptyMap()
        }

        val recordsToInsert = mutableListOf<AidRecordEntity>()

        for (item in distinctChunk) {
            try {
                val cleanId = com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(
                    item.familyNationalID.ifBlank { item.familyNationalId }
                ).trim()
                val family = if (cleanId.isNotBlank()) {
                    familyMapByNatId[cleanId]
                } else if (item.familyID != null) {
                    familyMapById[item.familyID]
                } else null

                if (family != null) {
                    if (isLocalityRestricted && family.localityID != allowedLoc) {
                        skipped++
                        continue
                    }

                    // مطابقة نوع وتصنيف المساعدة
                    val rawAidCategory = item.aidTypeName?.trim() ?: ""
                    val matchedAidType = if (rawAidCategory.isNotBlank() && rawAidCategory != "غير محدد") {
                        activeAidTypes.firstOrNull { it.aidTypeName.trim() == rawAidCategory }
                            ?: activeAidTypes.firstOrNull { it.aidTypeName.contains(rawAidCategory) || rawAidCategory.contains(it.aidTypeName) }
                    } else null
                    val resolvedAidTypeId = matchedAidType?.aidTypeID ?: item.aidTypeID

                    // التجميع والربط الديناميكي للمشاريع حسابياً
                    val rawPrjNum = item.projectNumber?.trim() ?: ""
                    val rawPrjName = item.projectName?.trim() ?: ""

                    val resolvedProjectId: Long = when {
                        rawPrjNum.isNotBlank() && projectCacheByNumber.containsKey(rawPrjNum) -> {
                            projectCacheByNumber[rawPrjNum]!!
                        }
                        rawPrjName.isNotBlank() && projectCacheByName.containsKey(rawPrjName) -> {
                            projectCacheByName[rawPrjName]!!
                        }
                        rawPrjNum.isNotBlank() || rawPrjName.isNotBlank() -> {
                            val existingDbProject = if (rawPrjNum.isNotBlank()) {
                                database.projectDao().getProjectByNumber(rawPrjNum)
                            } else {
                                database.projectDao().getProjectByName(rawPrjName)
                            }

                            if (existingDbProject != null) {
                                if (existingDbProject.projectNumber.isNotBlank()) {
                                    projectCacheByNumber[existingDbProject.projectNumber.trim()] = existingDbProject.projectID
                                }
                                if (existingDbProject.projectName.isNotBlank()) {
                                    projectCacheByName[existingDbProject.projectName.trim()] = existingDbProject.projectID
                                }
                                existingDbProject.projectID
                            } else {
                                val finalPrjNum = if (rawPrjNum.isNotBlank()) rawPrjNum
                                    else "PRJ-${(existingProjects.size + projectCacheByNumber.size + 1).toString().padStart(4, '0')}"
                                val finalPrjName = if (rawPrjName.isNotBlank()) rawPrjName
                                    else "مشروع إغاثي رقم $finalPrjNum"

                                val newProject = ProjectEntity(
                                    projectNumber = finalPrjNum,
                                    projectName = finalPrjName,
                                    aidTypeID = resolvedAidTypeId,
                                    detailedDescription = "مشروع تم إنشاؤه وتوثيقه آلياً أثناء استيراد ملف الإكسل",
                                    projectDate = item.aidDate.ifBlank { todayStr },
                                    actualNominationDate = todayStr,
                                    fundingInstitution = "جهة مانحة معتمدة",
                                    warehouseName = item.warehouse.ifBlank { "المستودع الرئيسي" },
                                    aidValue = item.aidValue ?: 0.0,
                                    stageUserName = user?.fullName ?: "مدير النظام",
                                    quantity = 1,
                                    notes = "مستورد عبر إكسل",
                                    isActive = true
                                )
                                val generatedId = database.projectDao().insertProject(newProject)
                                projectCacheByNumber[finalPrjNum] = generatedId
                                projectCacheByName[finalPrjName] = generatedId
                                generatedId
                            }
                        }
                        item.projectID > 0 -> item.projectID
                        else -> 1L
                    }

                    recordsToInsert.add(
                        AidRecordEntity(
                            familyID = family.familyID,
                            aidTypeID = resolvedAidTypeId,
                            projectID = resolvedProjectId,
                            aidDate = item.aidDate.ifBlank { todayStr },
                            selectionDate = item.selectionDate.ifBlank { item.aidDate.ifBlank { todayStr } },
                            warehouse = item.warehouse.ifBlank { "المستودع الميداني" },
                            recipientStatus = item.recipientStatus.ifBlank { "مستلم" },
                            actualDeliveryDate = item.actualDeliveryDate ?: item.aidDate.ifBlank { null },
                            actualRecipientName = item.actualRecipientName ?: item.recipientName ?: family.name,
                            aidValue = item.aidValue ?: 0.0,
                            notes = item.notes
                        )
                    )
                } else {
                    skipped++
                }
            } catch (e: Exception) {
                skipped++
            }
        }

        // إدخال جماعي للدفعة كاملة داخل Transaction واحدة عبر insertAll باستراتيجية OnConflictStrategy.IGNORE
        if (recordsToInsert.isNotEmpty()) {
            database.withTransaction {
                val insertResults = database.aidRecordDao().insertAll(recordsToInsert)
                insertResults.forEach { id ->
                    if (id > 0) {
                        inserted++
                    } else {
                        skipped++
                    }
                }
            }
        }

        Pair(inserted, skipped)
    }

    /**
     * استيراد فائق السرعة لدفعات الأبناء (100 ألف سجل) مع فحص المفتاح الأجنبي (Foreign Key Validation)
     */
    suspend fun importChildrenBatch(
        children: List<ChildEntity>,
        onProgress: (progress: Float, current: Int, total: Int) -> Unit
    ): BatchImportResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        var inserted = 0
        var skipped = 0
        var failed = 0
        val errors = mutableListOf<String>()
        val total = children.size

        // تحميل أرقام هويات الأسر في الذاكرة لفحص O(1) سريع جداً للمفتاح الأجنبي
        val validFamilyNationalIds = database.familyDao().getAllFamilyNationalIdsSync().toHashSet()

        val validChildren = mutableListOf<ChildEntity>()
        for (child in children) {
            val famId = child.familyNationalID.trim()
            if (famId.isBlank() || !validFamilyNationalIds.contains(famId)) {
                skipped++
                errors.add("تخطي الطفل [${child.childName} - هوية ${child.nationalID}]: رقم هوية الأسرة المعيلة (${child.familyNationalID}) غير مسجل في جدول الأسر")
            } else {
                validChildren.add(child)
            }
        }

        var processedCount = 0
        validChildren.chunked(2000).forEach { chunk ->
            try {
                val insertedIds = database.childDao().insertChildren(chunk)
                inserted += insertedIds.size
            } catch (e: Exception) {
                failed += chunk.size
                errors.add("خطأ في معالجة دفعة الأبناء (${chunk.size} سجل): ${e.message}")
            }
            processedCount += chunk.size
            val currentProgress = if (total > 0) (processedCount + skipped).toFloat() / total else 1.0f
            onProgress(currentProgress, processedCount + skipped, total)
            kotlinx.coroutines.yield()
        }

        if (validChildren.isEmpty() && skipped > 0) {
            onProgress(1.0f, total, total)
        }

        recordAuditLog(
            operationType = "استيراد إكسل أبناء (Relational)",
            targetTable = "الأبناء",
            recordId = "$inserted طفل",
            description = "استيراد وحفظ دفعات الأبناء: تم إدخال $inserted بنجاح، وتخطي $skipped لعدم مطابقة هوية الأسرة، وفشل $failed"
        )

        BatchImportResult(
            totalProcessed = total,
            insertedCount = inserted,
            updatedCount = 0,
            skippedCount = skipped,
            failedCount = failed,
            errors = errors
        )
    }

    data class AidRecordImportItem(
        val familyNationalID: String = "",
        val familyID: Long? = null,
        val aidTypeID: Int = 1,
        val aidTypeName: String? = null, // تصنيف المساعدة (Assistance Category: حليب، بامبرز، سلة...)
        val assistanceType: String? = null, // نوع المساعدة (Assistance Type: عينية، نقدية، إلخ)
        val projectNumber: String? = null, // رقم المشروع (Project Number)
        // projectID = 1L // تم إيقاف التعيين الثابت تلبية للتعليمات الصارمة، وسيتم استخراجه ديناميكياً
        val projectID: Long = 1L,
        val projectName: String? = null, // اسم المشروع (Project Name)
        val aidDate: String = "",
        val selectionDate: String = "",
        val warehouse: String = "",
        val recipientStatus: String = "مستلم",
        val actualDeliveryDate: String? = null,
        val actualRecipientName: String? = null,
        val aidValue: Double? = null,
        val notes: String? = null
    ) {
        val familyNationalId: String get() = familyNationalID
        val recipientName: String? get() = actualRecipientName
        val familyId: Long? get() = familyID
    }

    /**
     * الدالة القديمة: تم الإبقاء عليها بالكامل لضمان التوافق مع التعليق على التعيين الثابت للمشروع
     */
    suspend fun importAidRecordsImportItemsBatch(
        items: List<AidRecordImportItem>,
        onProgress: (progress: Float, current: Int, total: Int) -> Unit
    ): BatchImportResult {
        // تحويل المعالجة تلقائياً إلى V2 لضمان الربط الديناميكي للمشاريع ونوع المساعدة
        return importAidRecordsImportItemsBatchV2(
            items = items,
            defaultAssistanceType = "عينية",
            onProgress = onProgress
        )
    }

    /**
     * V2: الدالة الجديدة لاستيراد ملفات الإكسل (Dynamic Project Upsert & Assistance Type)
     * المتطلبات المنفذة بدقة:
     * 1. المنطق الديناميكي للمشاريع (Dynamic Project Upsert):
     *    - قراءة رقم المشروع واسم المشروع من كل سطر في الإكسل.
     *    - البحث في جدول المشاريع (projects) عن رقم المشروع أو اسمه.
     *    - إذا كان موجوداً: استخراج الـ ID الخاص به وربط السجل به.
     *    - إذا لم يكن موجوداً: إنشاء مشروع جديد تلقائياً في جدول projects برقم واسم المشروع والحصول على الـ ID الجديد.
     * 2. معالجة حقل "نوع المساعدة" (Assistance Type):
     *    - استقبال نوع المساعدة من عمود الإكسل أو كمعامل (defaultAssistanceType) من واجهة المستخدم (UI/Request).
     *    - تخزينه في سجل المساعدة بجانب تصنيف المساعدة (Assistance Category).
     * 3. معالجة أخطاء مفاتيح الربط (Foreign Key Handling):
     *    - التحقق المسبق من وجود رقم الهوية في جدول الأسر الرئيسي.
     *    - في حال عدم وجوده: عدم رمي أي استثناء، بل تخطي السطر (Skip) وحصره في قائمة السجلات المتخطاة (skippedRecords).
     */
    suspend fun importAidRecordsImportItemsBatchV2(
        items: List<AidRecordImportItem>,
        defaultAssistanceType: String? = "عينية",
        onProgress: (progress: Float, current: Int, total: Int) -> Unit
    ): BatchImportResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        var inserted = 0
        var skipped = 0
        var failed = 0
        val errors = mutableListOf<String>()
        val skippedDetails = mutableListOf<SkippedRecordDetail>()
        val total = items.size
        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocalityRestricted = allowedLoc != 0 && !isSuperAdmin()

        // تحميل مراجع الأسر وأنواع المساعدات للربط O(1) السريع
        val familyRefs = database.familyDao().getAllFamilyReferencesSync()
        val nationalIdMap = familyRefs.associateBy { com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(it.nationalID) }
        val familyIdMap = familyRefs.associateBy { it.familyID }
        val activeAidTypes = database.aidTypeDao().getAllActiveAidTypesSync()

        // كاش المشاريع بالذاكرة لتفادي استعلام قاعدة البيانات المتكرر وتسريع المعالجة
        val projectCacheByNumber = mutableMapOf<String, Long>()
        val projectCacheByName = mutableMapOf<String, Long>()
        val existingProjects = database.projectDao().getAllActiveProjectsSync()
        existingProjects.forEach { p ->
            if (p.projectNumber.isNotBlank()) projectCacheByNumber[p.projectNumber.trim()] = p.projectID
            if (p.projectName.isNotBlank()) projectCacheByName[p.projectName.trim()] = p.projectID
        }

        // استخراج سجلات المساعدات الحالية للتحقق من عدم تكرار (familyID + projectID)
        val existingAidKeys = database.aidRecordDao().getAllAidRecordsSync()
            .map { "${it.familyID}_${it.projectID}" }
            .toMutableSet()

        // فلترة القائمة برمجياً لمنع التكرار (distinctBy) لنفس الهوية والمشروع
        val distinctItems = items.distinctBy { item ->
            val nat = com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(item.familyNationalID)
            val prj = (item.projectNumber?.trim()?.ifBlank { null }
                ?: item.projectName?.trim()?.ifBlank { null }
                ?: "${item.projectID}").trim()
            "${nat}_${prj}"
        }
        val initialDuplicates = items.size - distinctItems.size
        skipped += initialDuplicates

        val validRecords = mutableListOf<AidRecordEntity>()

        for (item in distinctItems) {
            // 3. معالجة أخطاء مفاتيح الربط (Foreign Key Handling):
            val famNat = com.humanitarian.aidmanagement.util.ExcelParserHelper.normalizeNationalId(item.familyNationalID)
            val famRef = if (famNat.isNotBlank() && nationalIdMap.containsKey(famNat)) {
                nationalIdMap[famNat]
            } else if (item.familyID != null && familyIdMap.containsKey(item.familyID)) {
                familyIdMap[item.familyID]
            } else null

            // إذا كان رقم الهوية غير موجود: تخطي السطر وإضافته إلى مصفوفة Skipped Records
            if (famRef == null) {
                skipped++
                val refStr = if (famNat.isNotBlank()) "رقم هوية $famNat" else "معرف #${item.familyID ?: ""}"
                val skipReason = "تخطي سجل مساعدة: الأسرة المعنية ($refStr) غير مسجلة في جدول الأسر الرئيسي (Foreign Key Violation)"
                errors.add(skipReason)
                skippedDetails.add(SkippedRecordDetail(nationalId = famNat, familyId = item.familyID, projectNumber = item.projectNumber, reason = skipReason))
                continue
            }

            if (isLocalityRestricted && famRef.localityID != allowedLoc) {
                skipped++
                val skipReason = "تخطي سجل مساعدة للأسرة [هوية: ${famRef.nationalID}]: تتبع لمحلية (${famRef.localityID}) خارج نطاق صلاحيتك"
                errors.add(skipReason)
                skippedDetails.add(SkippedRecordDetail(nationalId = famNat, familyId = famRef.familyID, projectNumber = item.projectNumber, reason = skipReason))
                continue
            }

            // مطابقة تصنيف المساعدة (Assistance Category)
            val rawAidCategory = item.aidTypeName?.trim() ?: ""
            val matchedAidType = if (rawAidCategory.isNotBlank() && rawAidCategory != "غير محدد") {
                activeAidTypes.firstOrNull { it.aidTypeName.trim() == rawAidCategory }
                    ?: activeAidTypes.firstOrNull { it.aidTypeName.contains(rawAidCategory) || rawAidCategory.contains(it.aidTypeName) }
            } else null
            val resolvedAidTypeId = matchedAidType?.aidTypeID ?: item.aidTypeID

            // 1. المنطق الديناميكي للمشاريع (Dynamic Project Upsert):
            // توقف عن إسناد البيانات لمشروع ثابت (مثل Project ID = 1)
            // // projectID = 1L (تم التعليق تلبية للتعليمات الصارمة)
            val rawPrjNum = item.projectNumber?.trim() ?: ""
            val rawPrjName = item.projectName?.trim() ?: ""

            val resolvedProjectId: Long = when {
                rawPrjNum.isNotBlank() && projectCacheByNumber.containsKey(rawPrjNum) -> {
                    projectCacheByNumber[rawPrjNum]!!
                }
                rawPrjName.isNotBlank() && projectCacheByName.containsKey(rawPrjName) -> {
                    projectCacheByName[rawPrjName]!!
                }
                else -> {
                    val existingDbProject = if (rawPrjNum.isNotBlank()) {
                        database.projectDao().getProjectByNumber(rawPrjNum)
                    } else if (rawPrjName.isNotBlank()) {
                        database.projectDao().getProjectByName(rawPrjName)
                    } else null

                    if (existingDbProject != null) {
                        if (existingDbProject.projectNumber.isNotBlank()) {
                            projectCacheByNumber[existingDbProject.projectNumber.trim()] = existingDbProject.projectID
                        }
                        if (existingDbProject.projectName.isNotBlank()) {
                            projectCacheByName[existingDbProject.projectName.trim()] = existingDbProject.projectID
                        }
                        existingDbProject.projectID
                    } else {
                        // إنشاء مشروع جديد فورياً (Insert) وحصد الـ ID المولد
                        val finalPrjNum = if (rawPrjNum.isNotBlank()) rawPrjNum
                            else "PRJ-${(existingProjects.size + projectCacheByNumber.size + 1).toString().padStart(4, '0')}"
                        val finalPrjName = if (rawPrjName.isNotBlank()) rawPrjName
                            else "مشروع إغاثي رقم $finalPrjNum"

                        val newProject = ProjectEntity(
                            projectNumber = finalPrjNum,
                            projectName = finalPrjName,
                            aidTypeID = resolvedAidTypeId,
                            detailedDescription = "مشروع تم إنشاؤه وتوثيقه آلياً أثناء استيراد ملف الإكسل V2",
                            projectDate = item.aidDate.ifBlank { todayStr },
                            actualNominationDate = todayStr,
                            fundingInstitution = "جهة مانحة معتمدة",
                            warehouseName = item.warehouse.ifBlank { "المستودع الرئيسي" },
                            aidValue = item.aidValue ?: 0.0,
                            stageUserName = user?.fullName ?: "مدير النظام",
                            quantity = 1,
                            notes = "مستورد عبر إكسل V2",
                            isActive = true
                        )
                        val generatedId = database.projectDao().insertProject(newProject)
                        projectCacheByNumber[finalPrjNum] = generatedId
                        projectCacheByName[finalPrjName] = generatedId
                        generatedId
                    }
                }
            }

            // فحص منع التكرار لنفس المشروع والأسرة
            val key = "${famRef.familyID}_$resolvedProjectId"
            if (existingAidKeys.contains(key)) {
                skipped++
                val skipReason = "تخطي سجل مساعدة مكرر: الأسرة [هوية: ${famRef.nationalID}] مسجلة مسبقاً في المشروع #${resolvedProjectId}"
                errors.add(skipReason)
                skippedDetails.add(SkippedRecordDetail(nationalId = famNat, familyId = famRef.familyID, projectNumber = rawPrjNum, reason = skipReason))
                continue
            }
            existingAidKeys.add(key)

            // 2. معالجة حقل "نوع المساعدة" (Assistance Type) وتخزينه بجانب تصنيف المساعدة:
            val finalAssistanceType = (item.assistanceType?.trim()?.ifBlank { null }
                ?: defaultAssistanceType?.trim()?.ifBlank { null }
                ?: "عينية")

            val combinedNotes = listOfNotNull(
                item.notes,
                "نوع المساعدة: $finalAssistanceType",
                if (matchedAidType == null && rawAidCategory.isNotBlank() && rawAidCategory != "غير محدد") "تصنيف المساعدة: $rawAidCategory" else null,
                item.actualRecipientName?.let { "المستلم: $it" }
            ).joinToString(" | ").ifEmpty { null }

            validRecords.add(
                AidRecordEntity(
                    familyID = famRef.familyID,
                    aidTypeID = resolvedAidTypeId,
                    projectID = resolvedProjectId,
                    aidDate = item.aidDate.ifBlank { todayStr },
                    selectionDate = item.selectionDate.ifBlank { item.aidDate.ifBlank { todayStr } },
                    actualNominationDate = todayStr,
                    nominationMechanism = "استيراد إكسل V2",
                    stageUserName = user?.fullName ?: "مدير النظام",
                    warehouse = item.warehouse.ifBlank { "المستودع الميداني" },
                    recipientStatus = item.recipientStatus.ifBlank { "مستلم" },
                    deliveryDate = item.actualDeliveryDate ?: item.aidDate.ifBlank { null },
                    aidValue = item.aidValue ?: 0.0,
                    notes = combinedNotes
                )
            )
        }

        var processedCount = 0
        validRecords.chunked(2000).forEach { chunk ->
            try {
                val insertedIds = database.aidRecordDao().insertAidRecords(chunk)
                val actuallyInserted = insertedIds.count { it > 0 }
                inserted += actuallyInserted
                skipped += (chunk.size - actuallyInserted)
            } catch (e: Exception) {
                failed += chunk.size
                errors.add("خطأ في معالجة دفعة سجلات المساعدات (${chunk.size} سجل): ${e.message}")
            }
            processedCount += chunk.size
            val currentProgress = if (total > 0) (processedCount + skipped).toFloat() / total else 1.0f
            onProgress(currentProgress, processedCount + skipped, total)
            kotlinx.coroutines.yield()
        }

        if (validRecords.isEmpty() && skipped > 0) {
            onProgress(1.0f, total, total)
        }

        recordAuditLog(
            operationType = "استيراد إكسل مساعدات V2 (Dynamic Project)",
            targetTable = "سجلات المساعدات والمشاريع",
            recordId = "$inserted سجل",
            description = "استيراد دفعات سجلات المساعدات V2: تم إدخال $inserted بنجاح، وتخطي $skipped لمخالفة قيود الربط أو التكرار، وفشل $failed"
        )

        BatchImportResult(
            totalProcessed = total,
            insertedCount = inserted,
            updatedCount = 0,
            skippedCount = skipped,
            failedCount = failed,
            errors = errors,
            skippedRecords = skippedDetails
        )
    }

    /**
     * اسم بديل مباشر importExcelV2 وفقاً لأمر المستخدم الصارم
     */
    suspend fun importExcelV2(
        items: List<AidRecordImportItem>,
        defaultAssistanceType: String? = "عينية",
        onProgress: (progress: Float, current: Int, total: Int) -> Unit
    ): BatchImportResult = importAidRecordsImportItemsBatchV2(items, defaultAssistanceType, onProgress)

    /**
     * استيراد فائق السرعة لدفعات سجلات المساعدات (100 ألف سجل) مع فحص المفتاح الأجنبي (Foreign Key Validation)
     */
    suspend fun importAidRecordsBatch(
        records: List<AidRecordEntity>,
        onProgress: (progress: Float, current: Int, total: Int) -> Unit
    ): BatchImportResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        var inserted = 0
        var skipped = 0
        var failed = 0
        val errors = mutableListOf<String>()
        val total = records.size

        val user = getCurrentUser()
        val allowedLoc = user?.AllowedLocalityID ?: 0
        val isLocalityRestricted = allowedLoc != 0 && !isSuperAdmin()

        // استخراج مراجع الأسر لفحص وجود الأسرة والعزل الجغرافي
        val familyRefs = database.familyDao().getAllFamilyReferencesSync()
        val familyIdMap = familyRefs.associateBy { it.familyID }

        val validRecords = mutableListOf<AidRecordEntity>()
        for (record in records) {
            val famRef = familyIdMap[record.familyID]
            if (famRef == null) {
                skipped++
                errors.add("تخطي سجل مساعدة: معرف الأسرة (#${record.familyID}) غير موجود في جدول الأسر")
            } else if (isLocalityRestricted && famRef.localityID != allowedLoc) {
                skipped++
                errors.add("تخطي سجل مساعدة للأسرة (#${record.familyID}): تتبع لمحلية (${famRef.localityID}) خارج نطاق صلاحيتك")
            } else {
                validRecords.add(record)
            }
        }

        var processedCount = 0
        validRecords.chunked(2000).forEach { chunk ->
            try {
                val insertedIds = database.aidRecordDao().insertAidRecords(chunk)
                inserted += insertedIds.size
            } catch (e: Exception) {
                failed += chunk.size
                errors.add("خطأ في معالجة دفعة سجلات المساعدات (${chunk.size} سجل): ${e.message}")
            }
            processedCount += chunk.size
            val currentProgress = if (total > 0) (processedCount + skipped).toFloat() / total else 1.0f
            onProgress(currentProgress, processedCount + skipped, total)
            kotlinx.coroutines.yield()
        }

        if (validRecords.isEmpty() && skipped > 0) {
            onProgress(1.0f, total, total)
        }

        recordAuditLog(
            operationType = "استيراد إكسل مساعدات (Relational)",
            targetTable = "سجلات المساعدات",
            recordId = "$inserted سجل",
            description = "استيراد دفعات سجلات المساعدات: تم إدخال $inserted بنجاح، وتخطي $skipped لعدم وجود الأسرة أو قيود الصلاحية، وفشل $failed"
        )

        BatchImportResult(
            totalProcessed = total,
            insertedCount = inserted,
            updatedCount = 0,
            skippedCount = skipped,
            failedCount = failed,
            errors = errors
        )
    }

    // ==================== استيراد ملفات الإكسل (Batch Excel Imports) ====================
    suspend fun insertFamilies(families: List<FamilyEntity>): List<Long> {
        return database.familyDao().insertFamilies(families)
    }

    suspend fun insertAidRecords(records: List<AidRecordEntity>): List<Long> = withContext(Dispatchers.IO) {
        val nonDuplicates = records.filter { record ->
            !database.aidRecordDao().checkIfAidExists(record.familyID, record.projectID)
        }
        if (nonDuplicates.isNotEmpty()) {
            database.aidRecordDao().insertAidRecords(nonDuplicates)
        } else emptyList()
    }

    suspend fun insertChildren(children: List<ChildEntity>): List<Long> {
        return database.childDao().insertChildren(children)
    }

    suspend fun getAllAidRecordsSync(): List<AidRecordEntity> {
        return database.aidRecordDao().getAllAidRecordsSync()
    }

    /**
     * استعلام الأسر عبر قائمة المعرفات الوطنية بدفعات مجزأة (Chunking) لتفادي حد SQLite (999)
     */
    suspend fun getFamiliesByNationalIds(ids: List<String>): List<FamilyEntity> = withContext(Dispatchers.IO) {
        if (ids.isEmpty()) return@withContext emptyList()
        val result = mutableListOf<FamilyEntity>()
        val distinctIds = ids.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        distinctIds.chunked(500).forEach { chunk ->
            result.addAll(database.familyDao().getFamiliesByNationalIds(chunk))
        }
        result
    }

    /**
     * جلب بيانات الأسر مقترنة بتاريخ ونوع آخر مساعدة استلمتها كل أسرة
     * بنظام التجميع المباشر الموفر للذاكرة والمناسب للملفات الضخمة
     */
    suspend fun getFamiliesWithLatestAid(ids: List<String>): List<FamilyWithLatestAid> = withContext(Dispatchers.IO) {
        if (ids.isEmpty()) return@withContext emptyList()
        val families = getFamiliesByNationalIds(ids)
        if (families.isEmpty()) return@withContext emptyList()

        val aidTypeMap = try {
            database.aidTypeDao().getAllAidTypesSync().associateBy { it.aidTypeID }
        } catch (_: Exception) {
            emptyMap()
        }

        val familyIds = families.map { it.familyID }
        val allAidRecords = mutableListOf<AidRecordEntity>()
        familyIds.chunked(500).forEach { chunk ->
            allAidRecords.addAll(database.aidRecordDao().getAidRecordsForFamilies(chunk))
        }
        val recordsByFamily = allAidRecords.groupBy { it.familyID }

        families.map { family ->
            val records = recordsByFamily[family.familyID] ?: emptyList()
            val totalCount = records.size
            val latestRecord = records.firstOrNull() // Records are ordered by aidDate DESC
            val lastDate = latestRecord?.let { it.deliveryDate?.takeIf { d -> d.isNotBlank() } ?: it.aidDate }
            val aidType = latestRecord?.let { aidTypeMap[it.aidTypeID] }

            FamilyWithLatestAid(
                family = family,
                totalAidsCount = totalCount,
                lastAidDate = lastDate,
                lastAidType = aidType?.aidTypeName,
                lastAidCategory = aidType?.aidTypeName
            )
        }
    }

    // =========================================================================
    // استعلامات الفلاتر الديناميكية المتقدمة لمركز التقارير والتصدير (Dynamic Export)
    // =========================================================================

    suspend fun getDynamicFilteredFamiliesPreview(
        ignoreApproval: Boolean,
        approval: String,
        ignoreLocality: Boolean,
        localityId: Int,
        localityName: String,
        ignoreWorks: Boolean,
        worksApproval: String,
        ignoreDamage: Boolean,
        damageType: String,
        ignoreMarital: Boolean,
        maritalStatus: String,
        ignoreMembers: Boolean,
        minMembers: Int,
        maxMembers: Int
    ): List<FamilyEntity> = withContext(Dispatchers.IO) {
        database.familyDao().getDynamicFilteredFamiliesPreview(
            if (ignoreApproval) 1 else 0, approval,
            if (ignoreLocality) 1 else 0, localityId, localityName,
            if (ignoreWorks) 1 else 0, worksApproval,
            if (ignoreDamage) 1 else 0, damageType,
            if (ignoreMarital) 1 else 0, maritalStatus,
            if (ignoreMembers) 1 else 0, minMembers, maxMembers
        )
    }

    suspend fun getDynamicFilteredFamiliesFull(
        ignoreApproval: Boolean,
        approval: String,
        ignoreLocality: Boolean,
        localityId: Int,
        localityName: String,
        ignoreWorks: Boolean,
        worksApproval: String,
        ignoreDamage: Boolean,
        damageType: String,
        ignoreMarital: Boolean,
        maritalStatus: String,
        ignoreMembers: Boolean,
        minMembers: Int,
        maxMembers: Int
    ): List<FamilyEntity> = withContext(Dispatchers.IO) {
        database.familyDao().getDynamicFilteredFamiliesFull(
            if (ignoreApproval) 1 else 0, approval,
            if (ignoreLocality) 1 else 0, localityId, localityName,
            if (ignoreWorks) 1 else 0, worksApproval,
            if (ignoreDamage) 1 else 0, damageType,
            if (ignoreMarital) 1 else 0, maritalStatus,
            if (ignoreMembers) 1 else 0, minMembers, maxMembers
        )
    }

    suspend fun countDynamicFilteredFamilies(
        ignoreApproval: Boolean,
        approval: String,
        ignoreLocality: Boolean,
        localityId: Int,
        localityName: String,
        ignoreWorks: Boolean,
        worksApproval: String,
        ignoreDamage: Boolean,
        damageType: String,
        ignoreMarital: Boolean,
        maritalStatus: String,
        ignoreMembers: Boolean,
        minMembers: Int,
        maxMembers: Int
    ): Int = withContext(Dispatchers.IO) {
        database.familyDao().countDynamicFilteredFamilies(
            if (ignoreApproval) 1 else 0, approval,
            if (ignoreLocality) 1 else 0, localityId, localityName,
            if (ignoreWorks) 1 else 0, worksApproval,
            if (ignoreDamage) 1 else 0, damageType,
            if (ignoreMarital) 1 else 0, maritalStatus,
            if (ignoreMembers) 1 else 0, minMembers, maxMembers
        )
    }

    suspend fun getDynamicFilteredProjectsPreview(
        ignoreActive: Boolean,
        isActive: Boolean,
        ignoreAidType: Boolean,
        aidTypeId: Int
    ): List<ProjectEntity> = withContext(Dispatchers.IO) {
        database.projectDao().getDynamicFilteredProjectsPreview(
            if (ignoreActive) 1 else 0, isActive,
            if (ignoreAidType) 1 else 0, aidTypeId
        )
    }

    suspend fun getDynamicFilteredProjectsFull(
        ignoreActive: Boolean,
        isActive: Boolean,
        ignoreAidType: Boolean,
        aidTypeId: Int
    ): List<ProjectEntity> = withContext(Dispatchers.IO) {
        database.projectDao().getDynamicFilteredProjectsFull(
            if (ignoreActive) 1 else 0, isActive,
            if (ignoreAidType) 1 else 0, aidTypeId
        )
    }

    suspend fun countDynamicFilteredProjects(
        ignoreActive: Boolean,
        isActive: Boolean,
        ignoreAidType: Boolean,
        aidTypeId: Int
    ): Int = withContext(Dispatchers.IO) {
        database.projectDao().countDynamicFilteredProjects(
            if (ignoreActive) 1 else 0, isActive,
            if (ignoreAidType) 1 else 0, aidTypeId
        )
    }

    suspend fun getDynamicFilteredChildrenPreview(
        ignoreGender: Boolean,
        gender: String,
        ignoreShelter: Boolean,
        shelterStatus: String,
        ignoreLocality: Boolean,
        localityId: Int
    ): List<ChildEntity> = withContext(Dispatchers.IO) {
        database.childDao().getDynamicFilteredChildrenPreview(
            if (ignoreGender) 1 else 0, gender,
            if (ignoreShelter) 1 else 0, shelterStatus,
            if (ignoreLocality) 1 else 0, localityId
        )
    }

    suspend fun getDynamicFilteredChildrenFull(
        ignoreGender: Boolean,
        gender: String,
        ignoreShelter: Boolean,
        shelterStatus: String,
        ignoreLocality: Boolean,
        localityId: Int
    ): List<ChildEntity> = withContext(Dispatchers.IO) {
        database.childDao().getDynamicFilteredChildrenFull(
            if (ignoreGender) 1 else 0, gender,
            if (ignoreShelter) 1 else 0, shelterStatus,
            if (ignoreLocality) 1 else 0, localityId
        )
    }

    suspend fun countDynamicFilteredChildren(
        ignoreGender: Boolean,
        gender: String,
        ignoreShelter: Boolean,
        shelterStatus: String,
        ignoreLocality: Boolean,
        localityId: Int
    ): Int = withContext(Dispatchers.IO) {
        database.childDao().countDynamicFilteredChildren(
            if (ignoreGender) 1 else 0, gender,
            if (ignoreShelter) 1 else 0, shelterStatus,
            if (ignoreLocality) 1 else 0, localityId
        )
    }

}

data class DashboardStats(
    val totalFamilies: Int,
    val totalBeneficiaries: Int,
    val totalAidRecords: Int,
    val totalProjects: Int,
    val totalSelectedCandidates: Int,
    val distinctBeneficiaries: Int,
    val eligibleFamilies: Int = 0,
    val eligibleBeneficiaries: Int = 0,
    val totalNomineesCount: Int = totalSelectedCandidates,
    val actualRecipientsCount: Int = distinctBeneficiaries
)


data class LocalityDistributionStat(
    val localityId: Int,
    val localityName: String,
    val quotaPercent: Double,
    val deliveredAidCount: Int,
    val familiesCount: Int,
    val completionPercent: Int
)

data class AidTypeDistributionStat(
    val aidTypeId: Int,
    val aidTypeName: String,
    val deliveredCount: Int,
    val quotaTarget: Int,
    val colorHex: Long
)

/**
 * إحصائية نسب الاستفادة والترشيح للمناطق الفرعية
 * مبنية على: (عدد المستفيدين في تلك المنطقة / إجمالي الأسر المستحقة في نفس المنطقة)
 * حيث شرط الاستحقاق الصارم: (الوضع = مقيم) و (حالة الاعتماد = معتمد)
 */
data class SubAreaBenefitRatioStat(
    val subAreaName: String,
    val eligibleFamiliesCount: Int,         // إجمالي الأسر المستحقة (مقيم + معتمد)
    val totalFamiliesCount: Int,            // إجمالي الأسر المسجلة في المنطقة
    val deliveredBeneficiariesCount: Int,   // عدد المستفيدين في تلك المنطقة
    val ratioPercentage: Double,            // (عدد المستفيدين في تلك المنطقة / إجمالي الأسر المستحقة في نفس المنطقة) * 100
    val formattedRatio: String              // e.g. "45.2%"
)

/**
 * بيانات المشروع الإنساني المنفذ مع الإحصائيات الميدانية
 */
data class ProjectWithStats(
    val project: ProjectEntity,
    val aidTypeName: String,
    val candidatesCount: Int,
    val deliveredCount: Int
)

/**
 * عنصر مستفيد من مشروع معين
 */
data class ProjectBeneficiaryItem(
    val recordId: Long,
    val familyId: Long,
    val familyName: String,
    val nationalId: String,
    val phone: String,
    val subArea: String,
    val membersCount: Int,
    val status: String,
    val deliveryDate: String?,
    val stageUserName: String?
)

/**
 * ملخص تنفيذي إحصائي مجمع من نواة SQLite مباشرة (Zero in-memory heap footprint)
 */
data class ExecutiveAggregateSummary(
    val totalFamilies: Int = 0,
    val totalIndividuals: Int = 0,
    val totalDelivered: Int = 0,
    val actualBeneficiaries: Int = 0,
    val geoDemographics: List<com.humanitarian.aidmanagement.data.local.dao.RegionDemographicRecord> = emptyList(),
    val damageBreakdown: List<com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord> = emptyList(),
    val shelterBreakdown: List<com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord> = emptyList(),
    val aidTypeBreakdown: List<com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord> = emptyList()
)

