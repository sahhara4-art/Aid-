package com.humanitarian.aidmanagement.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

object AidNotificationChannels {
    const val CHANNEL_SYNC_ID = "aid_sync_channel"
    const val CHANNEL_SYNC_NAME = "مزامنة المساعدات"
    const val CHANNEL_ALERTS_ID = "aid_alerts_channel"
    const val CHANNEL_ALERTS_NAME = "تنبيهات الترشيح والاستلام"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val syncChannel = NotificationChannel(
                CHANNEL_SYNC_ID,
                CHANNEL_SYNC_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعارات مزامنة بيانات الأسر والمساعدات بالخلفية"
            }

            val alertsChannel = NotificationChannel(
                CHANNEL_ALERTS_ID,
                CHANNEL_ALERTS_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات هامة للمرشحين والطرود الجديدة"
            }

            notificationManager.createNotificationChannel(syncChannel)
            notificationManager.createNotificationChannel(alertsChannel)
        }
    }
}
