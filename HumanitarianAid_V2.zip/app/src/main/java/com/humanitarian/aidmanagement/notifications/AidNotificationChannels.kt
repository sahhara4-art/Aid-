package com.humanitarian.aidmanagement.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.graphics.Color
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build

object AidNotificationChannels {

    const val CHANNEL_UPCOMING_DISTRIBUTIONS = "channel_upcoming_distributions"
    const val CHANNEL_EXCLUSION_EXPIRING = "channel_exclusion_expiring"
    const val CHANNEL_URGENT_ALERTS = "channel_urgent_alerts"

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build()

            // 1. قناة تذكيرات مواعيد التوزيعات القادمة
            val distChannel = NotificationChannel(
                CHANNEL_UPCOMING_DISTRIBUTIONS,
                "تذكيرات مواعيد التوزيع القادمة",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات تذكيرية بمواعيد وجداول تسليم المساعدات الإغاثية ومواقع المستودعات"
                enableLights(true)
                lightColor = Color.parseColor("#10B981") // Emerald Green
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
                setSound(defaultSoundUri, audioAttributes)
            }

            // 2. قناة تنبيهات اقتراب انتهاء فترات الاستثناء للمرشحين
            val exclusionChannel = NotificationChannel(
                CHANNEL_EXCLUSION_EXPIRING,
                "تنبيهات انتهاء فترات الاستثناء والاستحقاق",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات فورية عند اقتراب انتهاء مدة منع/استثناء أي أسرة مستفيدة وإعادة إدراجها للمفاضلة والترشيح"
                enableLights(true)
                lightColor = Color.parseColor("#3B82F6") // Blue
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 100, 200)
                setSound(defaultSoundUri, audioAttributes)
            }

            // 3. قناة التنبيهات العاجلة والطوارئ
            val urgentChannel = NotificationChannel(
                CHANNEL_URGENT_ALERTS,
                "تنبيهات المشاريع والعمليات العاجلة",
                NotificationManager.IMPORTANCE_MAX
            ).apply {
                description = "إشعارات استثنائية وعمليات الترحيل والاعتماد الرسمي للمرشحين"
                enableLights(true)
                lightColor = Color.parseColor("#EF4444") // Red
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400, 200, 400)
                setSound(defaultSoundUri, audioAttributes)
            }

            notificationManager.createNotificationChannels(
                listOf(distChannel, exclusionChannel, urgentChannel)
            )
        }
    }
}
