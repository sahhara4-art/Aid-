package com.humanitarian.aidmanagement.ui.screens.backup

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInStatusCodes
import com.google.android.gms.common.api.ApiException
import com.humanitarian.aidmanagement.data.backup.CloudBackupItem
import com.humanitarian.aidmanagement.data.backup.GoogleDriveBackupManager
import com.humanitarian.aidmanagement.data.backup.GoogleDriveManager
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * BackupUiState - حالة واجهة النسخ الاحتياطي
 */
data class BackupUiState(
    val isLocalDatabaseExists: Boolean = false,
    val isCloudProcessing: Boolean = false,
    val cloudStatusMessage: String? = null,
    val cloudBackupsList: List<CloudBackupItem> = emptyList()
)

/**
 * BackupViewModel - إدارة حالة النسخ الاحتياطي السحابي والمحلي
 * ومصادقة Google Sign-In و Google Drive API
 */
class BackupViewModel(
    private val context: Context,
    val database: AidDatabase,
    val repository: AidRepository? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(BackupUiState())
    val uiState: StateFlow<BackupUiState> = _uiState.asStateFlow()

    val cloudBackupManager = GoogleDriveBackupManager(context, database)

    private val _googleAccount = MutableStateFlow<GoogleSignInAccount?>(null)
    val googleAccount: StateFlow<GoogleSignInAccount?> = _googleAccount.asStateFlow()

    val isConnected: StateFlow<Boolean> = _googleAccount.map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val userEmail: StateFlow<String?> = _googleAccount.map { it?.email }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _driveManager = MutableStateFlow<GoogleDriveManager?>(null)
    val driveManager: StateFlow<GoogleDriveManager?> = _driveManager.asStateFlow()

    private val _isCloudProcessing = MutableStateFlow(false)
    val isCloudProcessing: StateFlow<Boolean> = _isCloudProcessing.asStateFlow()

    private val _cloudStatusMessage = MutableStateFlow<String?>("جاهز لإجراء النسخ السحابي")
    val cloudStatusMessage: StateFlow<String?> = _cloudStatusMessage.asStateFlow()

    private val _cloudBackupsList = MutableStateFlow<List<CloudBackupItem>>(emptyList())
    val cloudBackupsList: StateFlow<List<CloudBackupItem>> = _cloudBackupsList.asStateFlow()

    init {
        checkLocalDatabaseExists(context)
        // فحص آخر حساب مسجل للدخول مسبقاً
        cloudBackupManager.getSignedInAccount()?.let { acc ->
            _googleAccount.value = acc
            _driveManager.value = GoogleDriveManager(context, acc)
            _cloudStatusMessage.value = "متصل بخوادم Google: ${acc.email}"
            refreshCloudBackups()
        }
    }

    fun checkLocalDatabaseExists(context: android.content.Context) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val dbFile = context.getDatabasePath(com.humanitarian.aidmanagement.data.local.AidDatabase.DATABASE_NAME)
                val exists = dbFile.exists() && dbFile.length() > 0L
                _uiState.update { it.copy(isLocalDatabaseExists = exists) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLocalDatabaseExists = false) }
            }
        }
    }

    /**
     * تهيئة عميل تسجيل الدخول بحساب Google مع صلاحيات Drive File وطلب ID Token
     */
    fun getGoogleSignInClient(webClientId: String = GoogleDriveBackupManager.WEB_CLIENT_ID): GoogleSignInClient {
        return cloudBackupManager.getGoogleSignInClient(webClientId)
    }

    /**
     * معالجة نتيجة Activity Result لتسجيل الدخول بحساب Google
     * والتقاط أخطاء ApiException وعرض رمز الحالة بدقة (Error: 10)
     */
    fun handleSignInResult(
        data: Intent?,
        onSuccess: (GoogleSignInAccount) -> Unit = {},
        onError: (statusCode: Int, message: String) -> Unit = { _, _ -> }
    ) {
        val task = GoogleSignIn.getSignedInAccountFromIntent(data)
        try {
            val account = task.getResult(ApiException::class.java)
            if (account != null) {
                _googleAccount.value = account
                _driveManager.value = GoogleDriveManager(context, account)
                _cloudStatusMessage.value = "متصل بخوادم Google: ${account.email}"
                onSuccess(account)
                refreshCloudBackups()
            } else {
                _cloudStatusMessage.value = "فشل الحصول على بيانات الحساب"
                onError(-1, "الحساب فارغ")
            }
        } catch (e: ApiException) {
            val statusCode = e.statusCode
            val statusString = GoogleSignInStatusCodes.getStatusCodeString(statusCode)
            val errorMsg = "Error: $statusCode ($statusString)"
            _cloudStatusMessage.value = "فشل الاتصال: $errorMsg"
            onError(statusCode, errorMsg)
        } catch (e: Exception) {
            val errorMsg = "خطأ غير متوقع: ${e.localizedMessage ?: e.message}"
            _cloudStatusMessage.value = errorMsg
            onError(-2, errorMsg)
        }
    }

    /**
     * رفع نسخة احتياطية سحابية جديدة
     */
    fun uploadCloudBackup(onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val account = _googleAccount.value ?: run {
            _cloudStatusMessage.value = "يرجى تسجيل الدخول بحساب Google أولاً"
            onComplete(false, "غير متصل")
            return
        }

        val dbFile = context.getDatabasePath(AidDatabase.DATABASE_NAME)
        val isDbExists = dbFile.exists() && dbFile.length() > 0L
        if (!isDbExists) {
            val msg = "لم يتم العثور على ملف قاعدة البيانات المحلي (${AidDatabase.DATABASE_NAME})"
            _cloudStatusMessage.value = msg
            onComplete(false, msg)
            return
        }

        viewModelScope.launch {
            _isCloudProcessing.value = true
            _cloudStatusMessage.value = "جاري رفع النسخة الاحتياطية إلى Google Drive..."
            val result = cloudBackupManager.backupToGoogleDrive(account)
            _cloudStatusMessage.value = result.message
            if (result.success) {
                refreshCloudBackups()
            }
            _isCloudProcessing.value = false
            onComplete(result.success, result.message)
        }
    }

    /**
     * تحديث قائمة النسخ السحابية
     */
    fun refreshCloudBackups() {
        val account = _googleAccount.value ?: return
        viewModelScope.launch {
            _isCloudProcessing.value = true
            val list = cloudBackupManager.listGoogleDriveBackups(account)
            _cloudBackupsList.value = list
            _isCloudProcessing.value = false
        }
    }

    /**
     * استعادة نسخة سحابية من Google Drive
     */
    fun restoreFromCloud(fileId: String, onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val account = _googleAccount.value ?: run {
            _cloudStatusMessage.value = "يرجى تسجيل الدخول بحساب Google أولاً"
            onComplete(false, "غير متصل")
            return
        }
        viewModelScope.launch {
            _isCloudProcessing.value = true
            _cloudStatusMessage.value = "جاري استعادة النسخة الاحتياطية من Google Drive..."
            val result = cloudBackupManager.restoreFromGoogleDrive(account, fileId)
            _cloudStatusMessage.value = result.message
            _isCloudProcessing.value = false
            onComplete(result.success, result.message)
        }
    }

    /**
     * تسجيل الخروج وفصل الحساب السحابي
     */
    fun signOut(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            val client = getGoogleSignInClient()
            client.signOut().addOnCompleteListener {
                _googleAccount.value = null
                _driveManager.value = null
                _cloudBackupsList.value = emptyList()
                _cloudStatusMessage.value = "تم تسجيل الخروج بنجاح"
                onComplete()
            }
        }
    }

    class Factory(
        private val context: Context,
        private val database: AidDatabase,
        private val repository: AidRepository? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return BackupViewModel(context, database, repository) as T
        }
    }
}
