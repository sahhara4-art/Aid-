package com.humanitarian.aidmanagement.ui.screens.backup

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInStatusCodes
import com.google.android.gms.common.api.ApiException
import com.humanitarian.aidmanagement.data.backup.CloudBackupItem
import com.humanitarian.aidmanagement.data.backup.GoogleDriveBackupManager
import com.humanitarian.aidmanagement.data.backup.GoogleDriveManager
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * BackupUiState - حالة واجهة النسخ الاحتياطي
 */
data class BackupUiState(
    val isLocalDatabaseExists: Boolean = false,
    val isCloudProcessing: Boolean = false,
    val isUploading: Boolean = false,
    val uploadProgress: Float = 0f,
    val cloudStatusMessage: String? = null,
    val cloudBackupsList: List<CloudBackupItem> = emptyList()
)

/**
 * BackupViewModel - إدارة حالة النسخ الاحتياطي السحابي والمحلي
 * ومصادقة Google Sign-In و Google Drive API
 */
class BackupViewModel(
    private val context: Context,
    val database: AidDatabase,
    val repository: AidRepository? = null
) : ViewModel() {

    private val _uiState = MutableStateFlow(BackupUiState())
    val uiState: StateFlow<BackupUiState> = _uiState.asStateFlow()

    private var cloudBackupsJob: Job? = null
    private var uploadJob: Job? = null
    private var restoreJob: Job? = null

    val cloudBackupManager = GoogleDriveBackupManager(context, database)

    private val _googleAccount = MutableStateFlow<GoogleSignInAccount?>(null)
    val googleAccount: StateFlow<GoogleSignInAccount?> = _googleAccount.asStateFlow()

    val isConnected: StateFlow<Boolean> = _googleAccount.map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val userEmail: StateFlow<String?> = _googleAccount.map { it?.email }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _driveManager = MutableStateFlow<GoogleDriveManager?>(null)
    val driveManager: StateFlow<GoogleDriveManager?> = _driveManager.asStateFlow()

    private val _isCloudProcessing = MutableStateFlow(false)
    val isCloudProcessing: StateFlow<Boolean> = _isCloudProcessing.asStateFlow()

    private val _isUploading = MutableStateFlow(false)
    val isUploading: StateFlow<Boolean> = _isUploading.asStateFlow()

    private val _uploadProgress = MutableStateFlow(0f)
    val uploadProgress: StateFlow<Float> = _uploadProgress.asStateFlow()

    private val _cloudStatusMessage = MutableStateFlow<String?>("سجل الدخول لحفظ واسترجاع ملفات قاعدة البيانات سحابياً")
    val cloudStatusMessage: StateFlow<String?> = _cloudStatusMessage.asStateFlow()

    private val _cloudBackupsList = MutableStateFlow<List<CloudBackupItem>>(emptyList())
    val cloudBackupsList: StateFlow<List<CloudBackupItem>> = _cloudBackupsList.asStateFlow()

    init {
        checkLocalDatabaseExists(context)
        // فحص آخر حساب مسجل للدخول مسبقاً
        cloudBackupManager.getSignedInAccount()?.let { acc ->
            _googleAccount.value = acc
            _driveManager.value = GoogleDriveManager(context, acc)
            _cloudStatusMessage.value = "متصل بخوادم Google: ${acc.email}"
            refreshCloudBackups()
        }
    }

    fun checkLocalDatabaseExists(context: android.content.Context) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val dbFile = context.getDatabasePath(com.humanitarian.aidmanagement.data.local.AidDatabase.DATABASE_NAME)
                val exists = dbFile.exists() && dbFile.length() > 0L
                _uiState.update { it.copy(isLocalDatabaseExists = exists) }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLocalDatabaseExists = false) }
            }
        }
    }

    /**
     * تهيئة عميل تسجيل الدخول بحساب Google مع صلاحيات Drive File وطلب ID Token
     */
    fun getGoogleSignInClient(webClientId: String = GoogleDriveBackupManager.WEB_CLIENT_ID): GoogleSignInClient {
        return cloudBackupManager.getGoogleSignInClient(webClientId)
    }

    fun setCloudStatusMessage(message: String?) {
        _cloudStatusMessage.value = message
    }

    /**
     * معالجة نتيجة Activity Result لتسجيل الدخول بحساب Google
     * والتقاط أخطاء ApiException وعرض رمز الحالة بدقة (Error: 10)
     */
    fun handleSignInResult(
        data: Intent?,
        onSuccess: (GoogleSignInAccount) -> Unit = {},
        onError: (statusCode: Int, message: String) -> Unit = { _, _ -> }
    ) {
        if (data == null) {
            _cloudStatusMessage.value = "تم إلغاء عملية تسجيل الدخول بحساب Google (لم يتم استلام استجابة)"
            onError(GoogleSignInStatusCodes.SIGN_IN_CANCELLED, "تم إلغاء عملية اختيار الحساب")
            return
        }
        val task = GoogleSignIn.getSignedInAccountFromIntent(data)
        try {
            val account = task.getResult(ApiException::class.java)
            if (account != null) {
                _googleAccount.value = account
                _driveManager.value = GoogleDriveManager(context, account)
                _cloudStatusMessage.value = "متصل بخوادم Google: ${account.email ?: account.displayName ?: "مستخدم معتمد"}"
                onSuccess(account)
                refreshCloudBackups()
            } else {
                _cloudStatusMessage.value = "فشل تسجيل الدخول: الحساب فارغ"
                onError(-1, "الحساب فارغ")
            }
        } catch (e: ApiException) {
            val statusCode = e.statusCode
            val statusString = GoogleSignInStatusCodes.getStatusCodeString(statusCode)
            val diagnosis = when (statusCode) {
                GoogleSignInStatusCodes.DEVELOPER_ERROR -> "خطأ في التكوين (Code 10: DEVELOPER_ERROR). يرجى التأكد من إضافة بصمة SHA-1 الخاصة بهذا الـ APK في Firebase Console."
                GoogleSignInStatusCodes.SIGN_IN_CANCELLED -> "تم إلغاء اختيار الحساب من قِبل المستخدم (Code 12501)."
                GoogleSignInStatusCodes.SIGN_IN_FAILED -> "فشل تسجيل الدخول (Code 12500). تأكد من تفعيل Google Drive API في Google Cloud Console."
                GoogleSignInStatusCodes.NETWORK_ERROR -> "خطأ في الشبكة (Code 7). تحقق من الاتصال بالإنترنت."
                else -> "كود الخطأ: $statusCode ($statusString)"
            }
            _cloudStatusMessage.value = "فشل الاتصال: $diagnosis"
            onError(statusCode, "Error: $statusCode ($statusString)")
        } catch (e: Exception) {
            val errorMsg = "خطأ غير متوقع: ${e.localizedMessage ?: e.message}"
            _cloudStatusMessage.value = errorMsg
            onError(-2, errorMsg)
        }
    }

    /**
     * رفع نسخة احتياطية سحابية جديدة مع تتبع نسبة التقدم لحظياً
     */
    fun uploadCloudBackup(onComplete: (Boolean, String) -> Unit = { _, _ -> }) {
        val account = _googleAccount.value ?: run {
            _cloudStatusMessage.value = "يرجى تسجيل الدخول بحساب Google أولاً"
            onComplete(false, "غير متصل")
            return
        }

        val dbFile = context.getDatabasePath(AidDatabase.DATABASE_NAME)
        val isDbExists = dbFile.exists() && dbFile.length() > 0L
        if (!isDbExists) {
            val msg = "لم يتم العثور على ملف قاعدة البيانات المحلي (${AidDatabase.DATABASE_NAME})"
            _cloudStatusMessage.value = msg
            onComplete(false, msg)
            return
        }

        uploadJob?.cancel()
        uploadJob = viewModelScope.launch(Dispatchers.IO) {
            _isCloudProcessing.value = true
            _isUploading.value = true
            _uploadProgress.value = 0f
            _cloudStatusMessage.value = "جاري رفع النسخة السحابية إلى Google Drive..."
            try {
                val result = cloudBackupManager.backupToGoogleDrive(account) { progress ->
                    val clamped = progress.coerceIn(0f, 1f)
                    _uploadProgress.value = clamped
                }
                _isUploading.value = false
                _uploadProgress.value = 0f
                _cloudStatusMessage.value = result.message
                if (result.success) {
                    val list = cloudBackupManager.listGoogleDriveBackups(account)
                    _cloudBackupsList.value = list
                }
                withContext(Dispatchers.Main) {
                    onComplete(result.success, result.message)
                }
            } finally {
                _isUploading.value = false
                _uploadProgress.value = 0f
                _isCloudProcessing.value = false
            }
        }
    }

    /**
     * تحديث قائمة النسخ السحابية
     */
    fun refreshCloudBackups(onLoaded: (List<CloudBackupItem>) -> Unit = {}) {
        val account = _googleAccount.value ?: return
        cloudBackupsJob?.cancel()
        cloudBackupsJob = viewModelScope.launch(Dispatchers.IO) {
            _isCloudProcessing.value = true
            try {
                val list = cloudBackupManager.listGoogleDriveBackups(account)
                _cloudBackupsList.value = list
                withContext(Dispatchers.Main) {
                    onLoaded(list)
                }
            } finally {
                _isCloudProcessing.value = false
            }
        }
    }

    /**
     * استعادة نسخة سحابية من Google Drive
     */
    fun restoreFromCloud(fileId: String, onComplete: (Boolean, String, Boolean) -> Unit = { _, _, _ -> }) {
        val account = _googleAccount.value ?: run {
            _cloudStatusMessage.value = "يرجى تسجيل الدخول بحساب Google أولاً"
            onComplete(false, "غير متصل", false)
            return
        }
        restoreJob?.cancel()
        restoreJob = viewModelScope.launch(Dispatchers.IO) {
            _isCloudProcessing.value = true
            _cloudStatusMessage.value = "جاري استعادة النسخة الاحتياطية من Google Drive..."
            try {
                val result = cloudBackupManager.restoreFromGoogleDrive(account, fileId)
                _cloudStatusMessage.value = result.message
                withContext(Dispatchers.Main) {
                    onComplete(result.success, result.message, result.requiresRestart)
                }
            } finally {
                _isCloudProcessing.value = false
            }
        }
    }

    /**
     * تسجيل الخروج وفصل الحساب السحابي
     */
    fun signOut(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            val client = getGoogleSignInClient()
            client.signOut().addOnCompleteListener {
                _googleAccount.value = null
                _driveManager.value = null
                _cloudBackupsList.value = emptyList()
                _uploadProgress.value = 0f
                _isUploading.value = false
                _cloudStatusMessage.value = "تم تسجيل الخروج من Google Drive"
                onComplete()
            }
        }
    }

    fun clearState() {
        cloudBackupsJob?.cancel()
        uploadJob?.cancel()
        restoreJob?.cancel()
        _isCloudProcessing.value = false
        _isUploading.value = false
        _uploadProgress.value = 0f
        _cloudBackupsList.value = emptyList()
    }

    override fun onCleared() {
        clearState()
        super.onCleared()
    }

    class Factory(
        private val context: Context,
        private val database: AidDatabase,
        private val repository: AidRepository? = null
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return BackupViewModel(context, database, repository) as T
        }
    }
}
