package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.humanitarian.aidmanagement.util.ExportColumnDef
import com.humanitarian.aidmanagement.util.ExportColumnRegistry

/**
 * نافذة حوار مخصصة لاختيار الأعمدة المطلوبة في التصدير (Dynamic Column Chooser Dialog)
 * تتيح للمستخدم تحديد الحقول المراد إدراجها في ملفات Excel أو PDF ديناميكياً
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportColumnSelectorDialog(
    exportFormat: String = "EXCEL", // "EXCEL", "PDF", or "DUAL"
    reportTitle: String = "كشف المستفيدين المعتمد",
    initialSelectedKeys: List<String> = ExportColumnRegistry.DEFAULT_SELECTED_KEYS,
    onConfirm: ((selectedKeys: List<String>) -> Unit)? = null,
    onExportExcel: ((selectedKeys: List<String>) -> Unit)? = null,
    onExportPdf: ((selectedKeys: List<String>) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    // حالة المفاتيح المختارة
    var selectedKeys by remember { mutableStateOf(initialSelectedKeys.toSet()) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("الكل") }

    val categories = remember {
        listOf("الكل") + ExportColumnRegistry.ALL_COLUMNS.map { it.category }.distinct()
    }

    val filteredColumns = remember(searchQuery, selectedCategory) {
        ExportColumnRegistry.ALL_COLUMNS.filter { col ->
            val matchesCategory = (selectedCategory == "الكل" || col.category == selectedCategory)
            val matchesSearch = if (searchQuery.isBlank()) true else {
                col.label.contains(searchQuery.trim(), ignoreCase = true) ||
                col.key.contains(searchQuery.trim(), ignoreCase = true)
            }
            matchesCategory && matchesSearch
        }
    }

    val isDual = onExportExcel != null && onExportPdf != null || exportFormat.uppercase() == "DUAL"
    val formatColor = when {
        isDual -> Color(0xFF0D9488)
        exportFormat.uppercase() == "PDF" -> Color(0xFFDC2626)
        else -> Color(0xFF16A34A)
    }
    val formatBadgeText = when {
        isDual -> "تصدير كشوفات البيانات (Excel & PDF)"
        exportFormat.uppercase() == "PDF" -> "مستند PDF (A4)"
        else -> "جداول إكسل (Excel .xlsx)"
    }
    val formatIcon = when {
        isDual -> Icons.Default.FileDownload
        exportFormat.uppercase() == "PDF" -> Icons.Default.PictureAsPdf
        else -> Icons.Default.TableChart
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Dialog(
            onDismissRequest = onDismiss,
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.94f)
                    .fillMaxHeight(0.88f),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                shadowElevation = 16.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // 1. ترويسة الحوار والخيارات
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = formatColor.copy(alpha = 0.12f),
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = formatIcon,
                                        contentDescription = null,
                                        tint = formatColor,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                            Column {
                                Text(
                                    text = "تخصيص أعمدة التصدير",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "$formatBadgeText • $reportTitle",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق")
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2. حقل البحث السريع
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("بحث عن اسم الحقل أو العمود...", fontSize = 13.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotBlank()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "مسح")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 3. أشرطة التصنيفات السريعة (Category Chips)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categories.forEach { cat ->
                            val isSelected = cat == selectedCategory
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                shape = RoundedCornerShape(8.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 4. أزرار التحكم الجماعي (تحديد الكل / إلغاء التحديد / الافتراضي)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // زر تحديد الكل
                            OutlinedButton(
                                onClick = {
                                    selectedKeys = ExportColumnRegistry.ALL_COLUMNS.map { it.key }.toSet()
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تحديد الكل", fontSize = 11.sp)
                            }

                            // زر إلغاء تحديد الكل
                            OutlinedButton(
                                onClick = { selectedKeys = emptySet() },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.RemoveDone, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إلغاء التحديد", fontSize = 11.sp)
                            }

                            // زر الاستعادة للافتراضي
                            TextButton(
                                onClick = {
                                    selectedKeys = ExportColumnRegistry.DEFAULT_SELECTED_KEYS.toSet()
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("الافتراضي (8)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }

                        // عداد الحقول المختارة
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.padding(start = 4.dp)
                        ) {
                            Text(
                                text = "${selectedKeys.size} من ${ExportColumnRegistry.ALL_COLUMNS.size}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // 5. قائمة الأعمدة القابلة للتحديد
                    LazyColumn(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(filteredColumns, key = { it.key }) { col ->
                            val isChecked = selectedKeys.contains(col.key)
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isChecked) MaterialTheme.colorScheme.primary.copy(alpha = 0.07f) else Color.Transparent,
                                border = if (isChecked) {
                                    androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
                                } else {
                                    androidx.compose.foundation.BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable {
                                        selectedKeys = if (isChecked) {
                                            selectedKeys - col.key
                                        } else {
                                            selectedKeys + col.key
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = { checked ->
                                                selectedKeys = if (checked) {
                                                    selectedKeys + col.key
                                                } else {
                                                    selectedKeys - col.key
                                                }
                                            },
                                            colors = CheckboxDefaults.colors(checkedColor = formatColor)
                                        )
                                        Column {
                                            Text(
                                                text = col.label,
                                                fontSize = 13.sp,
                                                fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "${col.category} • [${col.key}]",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    if (col.isDefault) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
                                        ) {
                                            Text(
                                                text = "أساسي",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(12.dp))

                    // 6. أزرار التأكيد والإلغاء
                    val orderedKeys = remember(selectedKeys) {
                        ExportColumnRegistry.ALL_COLUMNS
                            .map { it.key }
                            .filter { selectedKeys.contains(it) }
                    }

                    if (onExportExcel != null && onExportPdf != null) {
                        // أزرار التصدير الثنائية المطلوبة (Excel & PDF)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = onDismiss,
                                modifier = Modifier.weight(0.8f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("إلغاء", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    if (orderedKeys.isNotEmpty()) {
                                        onExportExcel(orderedKeys)
                                    }
                                },
                                enabled = orderedKeys.isNotEmpty(),
                                modifier = Modifier.weight(1.3f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                            ) {
                                Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "تصدير (Excel)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = {
                                    if (orderedKeys.isNotEmpty()) {
                                        onExportPdf(orderedKeys)
                                    }
                                },
                                enabled = orderedKeys.isNotEmpty(),
                                modifier = Modifier.weight(1.3f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                            ) {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "تصدير (PDF)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = onDismiss,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("إلغاء", fontSize = 13.sp)
                            }

                            Button(
                                onClick = {
                                    if (orderedKeys.isNotEmpty()) {
                                        onConfirm?.invoke(orderedKeys)
                                    }
                                },
                                enabled = orderedKeys.isNotEmpty(),
                                modifier = Modifier.weight(2f),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = formatColor)
                            ) {
                                Icon(formatIcon, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "متابعة التصدير (${orderedKeys.size} عمود)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
