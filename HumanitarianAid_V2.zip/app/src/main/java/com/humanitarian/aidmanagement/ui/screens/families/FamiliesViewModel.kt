package com.humanitarian.aidmanagement.ui.screens.families

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.util.ExcelParserHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class FamilyFilterState(
    val searchQuery: String = "",
    val selectedLocalityId: Int = 0,
    val selectedLocalityName: String = "",
    val selectedShelterStatus: String = ""
)

data class FamiliesUiState(
    val families: List<FamilyEntity> = emptyList(),
    val totalCount: Int = 0,
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val hasMorePages: Boolean = false,
    val currentPage: Int = 0,
    val searchQuery: String = "",
    val selectedLocalityId: Int = 0,
    val selectedLocalityName: String = "",
    val selectedShelterStatus: String = "",
    val errorMessage: String? = null
)

class FamiliesViewModel(
    private val repository: AidRepository
) : ViewModel() {

    private val _filterState = MutableStateFlow(FamilyFilterState())
    val filterState: StateFlow<FamilyFilterState> = _filterState.asStateFlow()

    private val _uiState = MutableStateFlow(FamiliesUiState())
    val uiState: StateFlow<FamiliesUiState> = _uiState.asStateFlow()

    // تدفق Paging 3 فائق الكفاءة - يمنع احتجاز 50 ألف سجل في الذاكرة
    @OptIn(ExperimentalCoroutinesApi::class)
    val pagedFamilies: Flow<PagingData<FamilyEntity>> = _filterState
        .flatMapLatest { filter ->
            repository.getFamiliesPagerFlow(
                query = filter.searchQuery,
                localityId = filter.selectedLocalityId,
                shelterStatus = filter.selectedShelterStatus,
                localityName = filter.selectedLocalityName,
                pageSize = 30
            )
        }
        .cachedIn(viewModelScope)

    // قائمة المحليات الديناميكية المستخرجة حصراً من قاعدة البيانات
    val dynamicLocalities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { list -> list.filter { it.isNotBlank() } }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        val user = repository.getCurrentUser()
        val initialLoc = if ((user?.AllowedLocalityID ?: 0) != 0 && !repository.isSuperAdmin()) {
            user?.AllowedLocalityID ?: 0
        } else 0
        _filterState.update { it.copy(selectedLocalityId = initialLoc) }
        _uiState.update { it.copy(selectedLocalityId = initialLoc) }
        updateTotalCount()
    }

    fun onSearchQueryChanged(newQuery: String) {
        val cleanQuery = ExcelParserHelper.convertEasternToArabicDigits(newQuery).trim()
        if (_filterState.value.searchQuery == cleanQuery) return
        _filterState.update { it.copy(searchQuery = cleanQuery) }
        _uiState.update { it.copy(searchQuery = cleanQuery) }
        updateTotalCount()
    }

    fun onLocalitySelected(localityId: Int) {
        if (_filterState.value.selectedLocalityId == localityId && _filterState.value.selectedLocalityName.isEmpty()) return
        _filterState.update { it.copy(selectedLocalityId = localityId, selectedLocalityName = "") }
        _uiState.update { it.copy(selectedLocalityId = localityId, selectedLocalityName = "") }
        updateTotalCount()
    }

    fun onLocalityNameSelected(localityName: String) {
        val clean = if (localityName == "الكل") "" else localityName
        if (_filterState.value.selectedLocalityName == clean && (_filterState.value.selectedLocalityId == 0 || clean.isNotEmpty())) return
        _filterState.update { it.copy(selectedLocalityName = clean, selectedLocalityId = 0) }
        _uiState.update { it.copy(selectedLocalityName = clean, selectedLocalityId = 0) }
        updateTotalCount()
    }

    fun onShelterStatusSelected(shelterStatus: String) {
        if (_filterState.value.selectedShelterStatus == shelterStatus) return
        _filterState.update { it.copy(selectedShelterStatus = shelterStatus) }
        _uiState.update { it.copy(selectedShelterStatus = shelterStatus) }
        updateTotalCount()
    }

    private var countJob: Job? = null

    private fun updateTotalCount() {
        countJob?.cancel()
        countJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val state = _filterState.value
                val shelter = if (state.selectedShelterStatus.isBlank()) null else state.selectedShelterStatus
                val locName = if (state.selectedLocalityName.isBlank() || state.selectedLocalityName == "الكل") null else state.selectedLocalityName
                val total = repository.getFamiliesCount(
                    query = state.searchQuery,
                    localityId = state.selectedLocalityId,
                    shelterStatus = shelter,
                    localityName = locName
                )
                _uiState.update { it.copy(totalCount = total) }
            } catch (_: Exception) {}
        }
    }

    fun refresh() {
        updateTotalCount()
    }

    fun loadInitialPage() {
        updateTotalCount()
    }

    fun loadNextPage() {
        // يتم إدارته آلياً عبر Paging 3
    }

    /**
     * حساب العمر الدقيق ديناميكياً من تاريخ الميلاد date_of_birth بدون أي قيم ثابتة
     */
    fun calculateAge(birthDateString: String?): Int? {
        if (birthDateString.isNullOrBlank()) return null
        return try {
            val parts = birthDateString.trim().split("-", "/")
            if (parts.size >= 3) {
                val year = parts[0].toIntOrNull() ?: return null
                val month = parts[1].toIntOrNull() ?: 1
                val day = parts[2].toIntOrNull() ?: 1
                val birthCal = java.util.Calendar.getInstance().apply { set(year, month - 1, day) }
                val today = java.util.Calendar.getInstance()
                var calculatedAge = today.get(java.util.Calendar.YEAR) - birthCal.get(java.util.Calendar.YEAR)
                if (today.get(java.util.Calendar.DAY_OF_YEAR) < birthCal.get(java.util.Calendar.DAY_OF_YEAR)) {
                    calculatedAge--
                }
                calculatedAge.coerceAtLeast(0)
            } else null
        } catch (_: Exception) {
            null
        }
    }

    /**
     * توحيد صيغة رقم الهوية الوطنية بتحويل الأرقام المشرقية لإنجليزي وإزالة الفراغات
     */
    fun normalizeNationalId(id: String?): String {
        return ExcelParserHelper.normalizeNationalId(id)
    }

    /**
     * فحص وجود الأسرة برقم الهوية قبل الحفظ (مع توحيد صيغة الأرقام تلقائياً) لمنع التكرار
     */
    suspend fun checkFamilyExistsByNationalId(nationalId: String): Boolean {
        val cleanId = ExcelParserHelper.normalizeNationalId(nationalId)
        if (cleanId.isBlank()) return false
        return repository.getFamilyByNationalId(cleanId) != null
    }

    /**
     * حفظ الأسرة مع فرض توحيد صيغة أرقام الهوية (رب الأسرة والزوجة) قبل الحفظ في قاعدة البيانات
     */
    suspend fun saveFamily(family: FamilyEntity): Long {
        val isNew = family.familyID == 0L
        if (isNew && !com.humanitarian.aidmanagement.security.AccessControlManager.hasActionPermission(com.humanitarian.aidmanagement.security.AccessControlManager.ACTION_ADD)) {
            throw SecurityException("ليس لديك صلاحية إضافة أسر جديدة (ممنوع بموجب سياسة الأمان المؤسسية)")
        }
        if (!isNew && !com.humanitarian.aidmanagement.security.AccessControlManager.hasActionPermission(com.humanitarian.aidmanagement.security.AccessControlManager.ACTION_EDIT)) {
            throw SecurityException("ليس لديك صلاحية تعديل بيانات المواطنين (ممنوع بموجب سياسة الأمان المؤسسية)")
        }

        val normalized = family.copy(
            nationalID = ExcelParserHelper.normalizeNationalId(family.nationalID),
            wifeNationalID = family.wifeNationalID?.let { ExcelParserHelper.normalizeNationalId(it) }?.ifBlank { null }
        )
        val id = repository.insertFamily(normalized)
        refresh()
        return id
    }

    suspend fun deleteFamily(family: FamilyEntity) {
        if (!com.humanitarian.aidmanagement.security.AccessControlManager.hasActionPermission(com.humanitarian.aidmanagement.security.AccessControlManager.ACTION_DELETE)) {
            throw SecurityException("ليس لديك صلاحية حذف سجلات الأسر (ممنوع بموجب سياسة الأمان المؤسسية)")
        }
        repository.deleteFamily(family)
        refresh()
    }

    fun resetFilters() {
        val user = repository.getCurrentUser()
        val initialLoc = if ((user?.AllowedLocalityID ?: 0) != 0 && !repository.isSuperAdmin()) {
            user?.AllowedLocalityID ?: 0
        } else 0
        _filterState.value = FamilyFilterState(selectedLocalityId = initialLoc)
        _uiState.update {
            it.copy(
                searchQuery = "",
                selectedLocalityId = initialLoc,
                selectedLocalityName = "",
                selectedShelterStatus = "",
                errorMessage = null
            )
        }
    }

    fun clearState() {
        countJob?.cancel()
        resetFilters()
        _uiState.value = FamiliesUiState(selectedLocalityId = _filterState.value.selectedLocalityId)
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return FamiliesViewModel(repository) as T
        }
    }
}
