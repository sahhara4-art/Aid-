package com.humanitarian.aidmanagement.ui.screens.families

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.humanitarian.aidmanagement.data.local.dao.FamilySearchQueryBuilder
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.util.AgeExportCriteria
import com.humanitarian.aidmanagement.util.AgeExportFormat
import com.humanitarian.aidmanagement.util.AgeExportProgress
import com.humanitarian.aidmanagement.util.AgeExportReportType
import com.humanitarian.aidmanagement.util.AgeExportResult
import com.humanitarian.aidmanagement.util.AgeFilteredChildrenExporter
import com.humanitarian.aidmanagement.util.ExactAgeUtil
import com.humanitarian.aidmanagement.util.ExcelParserHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean

data class AgeFilterState(
    val isActive: Boolean = false,
    val minYears: Int = 0,
    val minMonths: Int = 0,
    val maxYears: Int = 1,
    val maxMonths: Int = 0,
    val gender: String = "الكل",
    val presetLabel: String? = null
) {
    val cleanGender: String?
        get() = gender.trim().takeIf { it.isNotEmpty() && it != "الكل" }

    val isAnyChildFilterActive: Boolean
        get() = isActive || cleanGender != null

    fun computeBirthDateRange(): Pair<String, String>? {
        if (!isActive) return null
        return ExactAgeUtil.computeBirthDateRangeForAgeFilter(
            minYears = minYears,
            minMonths = minMonths,
            maxYears = maxYears,
            maxMonths = maxMonths
        )
    }

    fun buildSummaryLabel(): String {
        if (!isAnyChildFilterActive) return "فلتر العمر"
        val ageText = if (isActive) {
            presetLabel?.takeIf { it.isNotBlank() } ?: run {
                val from = formatAgePart(minYears, minMonths)
                val to = formatAgePart(maxYears, maxMonths)
                "من $from إلى $to"
            }
        } else {
            "جميع الأعمار"
        }
        val genderText = cleanGender?.let { " • $it" } ?: ""
        return "$ageText$genderText"
    }

    private fun formatAgePart(years: Int, months: Int): String = when {
        years > 0 && months > 0 -> "$years س $months ش"
        years > 0 -> "$years سنة"
        months > 0 -> "$months شهر"
        else -> "0"
    }
}

data class FamilyFilterState(
    val searchQuery: String = "",
    val selectedLocalityId: Int = 0,
    val selectedLocalityName: String = "",
    val selectedBranchName: String = "",
    val selectedShelterStatus: String = "",
    val ageFilter: AgeFilterState = AgeFilterState(),
    val refreshTrigger: Int = 0
)

data class FamiliesUiState(
    val families: List<FamilyEntity> = emptyList(),
    val totalCount: Int = 0,
    val matchedChildrenCount: Int = 0,
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val hasMorePages: Boolean = false,
    val currentPage: Int = 0,
    val searchQuery: String = "",
    val selectedLocalityId: Int = 0,
    val selectedLocalityName: String = "",
    val selectedBranchName: String = "",
    val selectedShelterStatus: String = "",
    val ageFilter: AgeFilterState = AgeFilterState(),
    val isExporting: Boolean = false,
    val exportProgress: AgeExportProgress? = null,
    val lastExportResult: AgeExportResult? = null,
    val exportError: String? = null,
    val isBulkSyncRunning: Boolean = false,
    val bulkSyncProgress: AidRepository.BulkChildrenSyncProgress? = null,
    val bulkSyncReport: AidRepository.BulkChildrenSyncReport? = null,
    val errorMessage: String? = null
)

@OptIn(FlowPreview::class)
class FamiliesViewModel(
    private val repository: AidRepository
) : ViewModel() {

    private val _filterState = MutableStateFlow(FamilyFilterState())
    val filterState: StateFlow<FamilyFilterState> = _filterState.asStateFlow()

    private val _uiState = MutableStateFlow(FamiliesUiState())
    val uiState: StateFlow<FamiliesUiState> = _uiState.asStateFlow()

    // تدفق إدخال البحث الخام لتطبيق Debounce 350ms وإلغاء الاستعلامات السابقة فوراً
    private val _rawSearchQueryFlow = MutableStateFlow("")

    // خريطة الأبناء المطابقين لكل أسرة مرئية (فلتر العمر + البحث بالابن في دفعة IO واحدة بدون N+1)
    private val _matchedChildrenByFamilyId = MutableStateFlow<Map<String, List<ChildEntity>>>(emptyMap())
    val matchedChildrenByFamilyId: StateFlow<Map<String, List<ChildEntity>>> = _matchedChildrenByFamilyId.asStateFlow()

    private val _familyChildrenMatchByParentId =
        MutableStateFlow<Map<String, AidRepository.OfficialFamilyChildrenMatch>>(emptyMap())
    val familyChildrenMatchByParentId: StateFlow<Map<String, AidRepository.OfficialFamilyChildrenMatch>> =
        _familyChildrenMatchByParentId.asStateFlow()

    private val requestedChildrenLock = Any()
    private val requestedFamilyIdsForCurrentFilter = HashSet<String>()
    @Volatile
    private var currentChildrenFilterSignature: String = ""

    val assignedSubArea: StateFlow<String?> = AccessControlManager.assignedSubAreaFlow
    val assignedDivisions: StateFlow<List<String>> = AccessControlManager.assignedDivisionsFlow

    // تدفق Paging 3 فائق الكفاءة - يمنع احتجاز 50 ألف سجل في الذاكرة ويدعم الفلترة المفهرسة بالعمر
    @OptIn(ExperimentalCoroutinesApi::class)
    val pagedFamilies: Flow<PagingData<FamilyEntity>> = _filterState
        .flatMapLatest { filter ->
            val dateRange = filter.ageFilter.computeBirthDateRange()
            repository.getFamiliesPagerFlow(
                query = filter.searchQuery,
                localityId = filter.selectedLocalityId,
                shelterStatus = filter.selectedShelterStatus,
                localityName = filter.selectedLocalityName,
                pageSize = 30,
                branchName = filter.selectedBranchName,
                childBirthDateMin = dateRange?.first,
                childBirthDateMax = dateRange?.second,
                childGender = filter.ageFilter.cleanGender
            )
        }
        .cachedIn(viewModelScope)

    // قائمة المحليات الديناميكية المستخرجة حصراً من قاعدة البيانات (مقيدة بنطاق المستخدم)
    val dynamicLocalities: StateFlow<List<String>> = combine(
        repository.currentUserFlow,
        repository.getDistinctLocalities(),
        repository.getAllowedLocalitiesFlow()
    ) { user, dbLocalities, allowedLocEntities ->
        val cleanDb = dbLocalities.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val cleanAllowedNames = AccessControlManager.getCleanAllowedLocalities()
        val hasLocIdRestriction = (user?.AllowedLocalityID ?: 0) > 0 ||
            repository.getCurrentUserLocalityIds().any { it > 0 }
        val resolvedAllowedNames = cleanAllowedNames.ifEmpty {
            if (hasLocIdRestriction) allowedLocEntities.map { it.LocalityName.trim() }.filter { it.isNotBlank() } else emptyList()
        }.distinct()

        if (resolvedAllowedNames.isEmpty() && !hasLocIdRestriction) {
            cleanDb.sorted()
        } else {
            cleanDb.filter { loc ->
                resolvedAllowedNames.any { it.equals(loc, ignoreCase = true) }
            }.sorted()
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val canViewAllLocalities: StateFlow<Boolean> = combine(
        repository.currentUserFlow,
        repository.getAllowedLocalitiesFlow()
    ) { user, _ ->
        val cleanAllowedNames = AccessControlManager.getCleanAllowedLocalities()
        val hasLocIdRestriction = (user?.AllowedLocalityID ?: 0) > 0 ||
            repository.getCurrentUserLocalityIds().any { it > 0 }
        cleanAllowedNames.isEmpty() && !hasLocIdRestriction
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val lockedLocalityName: StateFlow<String?> = combine(
        repository.currentUserFlow,
        repository.getAllowedLocalitiesFlow(),
        dynamicLocalities
    ) { user, allowedLocEntities, dynLocs ->
        val cleanAllowedNames = AccessControlManager.getCleanAllowedLocalities()
        val hasLocIdRestriction = (user?.AllowedLocalityID ?: 0) > 0 ||
            repository.getCurrentUserLocalityIds().any { it > 0 }
        val resolvedNames = cleanAllowedNames.ifEmpty {
            if (hasLocIdRestriction) allowedLocEntities.map { it.LocalityName.trim() }.filter { it.isNotBlank() } else emptyList()
        }.distinct()
        when {
            resolvedNames.size == 1 -> resolvedNames.first()
            hasLocIdRestriction && dynLocs.size == 1 -> dynLocs.first()
            else -> null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isLocalityLocked: StateFlow<Boolean> = lockedLocalityName
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val lockedBranchName: StateFlow<String?> = combine(
        repository.currentUserFlow,
        assignedDivisions
    ) { user, divisions ->
        if (user == null) {
            null
        } else {
            val cleanAllowed = divisions.ifEmpty { AccessControlManager.getCleanAllowedBranches() }
            if (cleanAllowed.size == 1) cleanAllowed.first() else null
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val isBranchLocked: StateFlow<Boolean> = lockedBranchName
        .map { it != null }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val canViewAllBranches: StateFlow<Boolean> = combine(
        repository.currentUserFlow,
        assignedDivisions
    ) { user, divisions ->
        if (user == null) {
            true
        } else {
            divisions.isEmpty() && AccessControlManager.getCleanAllowedBranches().isEmpty()
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val allowedBranches: StateFlow<List<String>> = combine(
        repository.currentUserFlow,
        assignedDivisions
    ) { user, divisions ->
        if (user == null) {
            emptyList()
        } else {
            val allowed = divisions.ifEmpty { AccessControlManager.getCleanAllowedBranches() }
            if (allowed.isEmpty()) {
                emptyList()
            } else {
                val dbBranches = repository.getAllDistinctBranches()
                val matched = dbBranches.filter { br -> allowed.any { it.equals(br, ignoreCase = true) } }
                if (matched.isNotEmpty()) matched else allowed
            }
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val availableBranches: StateFlow<List<String>> = combine(
        repository.currentUserFlow,
        _filterState.map { it.selectedLocalityName }.distinctUntilChanged(),
        lockedLocalityName,
        assignedDivisions
    ) { user, selectedLoc, lockedLoc, divisions ->
        val activeLoc = lockedLoc ?: selectedLoc
        val dbBranches = repository.getDistinctBranchesForLocality(activeLoc)
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
        if (user == null) {
            dbBranches.sorted()
        } else {
            val allowed = divisions.ifEmpty { AccessControlManager.getCleanAllowedBranches() }
            if (allowed.isEmpty()) {
                dbBranches.sorted()
            } else {
                val filtered = dbBranches.filter { br -> allowed.any { it.equals(br, ignoreCase = true) } }
                (if (filtered.isNotEmpty()) filtered else allowed).distinct().sorted()
            }
        }
    }
        .flowOn(Dispatchers.IO)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            combine(
                repository.currentUserFlow,
                dynamicLocalities,
                lockedLocalityName,
                canViewAllLocalities,
                lockedBranchName
            ) { user, dynLocs, lockedName, allowAll, lockedBranch ->
                val initialLoc = if ((user?.AllowedLocalityID ?: 0) != 0) {
                    user?.AllowedLocalityID ?: 0
                } else 0
                val currentName = _filterState.value.selectedLocalityName
                val effectiveName = when {
                    lockedName != null -> lockedName
                    !allowAll && dynLocs.isNotEmpty() && (currentName.isBlank() || dynLocs.none { it.equals(currentName, ignoreCase = true) }) ->
                        dynLocs.first()
                    else -> currentName
                }
                val currentBranch = _filterState.value.selectedBranchName
                val allowedDivs = AccessControlManager.getCleanAllowedBranches()
                val effectiveBranch = when {
                    lockedBranch != null -> lockedBranch
                    allowedDivs.isNotEmpty() && currentBranch.isNotBlank() && allowedDivs.none { it.equals(currentBranch, ignoreCase = true) } -> ""
                    else -> currentBranch
                }
                Triple(initialLoc, effectiveName, effectiveBranch)
            }.collect { (initialLoc, effectiveName, effectiveBranch) ->
                val cur = _filterState.value
                if (cur.selectedLocalityId != initialLoc || cur.selectedLocalityName != effectiveName || cur.selectedBranchName != effectiveBranch) {
                    _filterState.update {
                        it.copy(
                            selectedLocalityId = initialLoc,
                            selectedLocalityName = effectiveName,
                            selectedBranchName = effectiveBranch
                        )
                    }
                    _uiState.update {
                        it.copy(
                            selectedLocalityId = initialLoc,
                            selectedLocalityName = effectiveName,
                            selectedBranchName = effectiveBranch
                        )
                    }
                }
                updateTotalCount()
            }
        }

        // Debounce 350ms لمدخل البحث في الأسر الرسمية لمنع تقطع الكتابة أو تكدس الاستعلامات
        viewModelScope.launch {
            _rawSearchQueryFlow
                .debounce(350L)
                .map { formatSearchQuery(it) }
                .distinctUntilChanged()
                .collect { normalizedQuery ->
                    if (_filterState.value.searchQuery != normalizedQuery) {
                        val currentFilter = _filterState.value
                        resetMatchedChildrenCache(normalizedQuery, currentFilter.ageFilter, currentFilter.refreshTrigger)
                        _filterState.update { it.copy(searchQuery = normalizedQuery) }
                        updateTotalCount()
                    }
                }
        }
    }

    fun formatSearchQuery(rawQuery: String): String {
        return FamilySearchQueryBuilder.normalizeArabicText(rawQuery)
    }

    fun onSearchQueryChanged(newQuery: String) {
        countJob?.cancel()
        _uiState.update { it.copy(searchQuery = newQuery) }
        _rawSearchQueryFlow.value = newQuery
    }

    fun onLocalitySelected(localityId: Int) {
        if (isLocalityLocked.value) return
        val lockedId = if ((repository.getCurrentUser()?.AllowedLocalityID ?: 0) != 0) {
            repository.getCurrentUser()?.AllowedLocalityID ?: 0
        } else localityId
        val nextBranch = lockedBranchName.value ?: ""
        if (_filterState.value.selectedLocalityId == lockedId &&
            _filterState.value.selectedLocalityName.isEmpty() &&
            _filterState.value.selectedBranchName == nextBranch
        ) return
        _filterState.update { it.copy(selectedLocalityId = lockedId, selectedLocalityName = "", selectedBranchName = nextBranch) }
        _uiState.update { it.copy(selectedLocalityId = lockedId, selectedLocalityName = "", selectedBranchName = nextBranch) }
        updateTotalCount()
    }

    fun onLocalityNameSelected(localityName: String) {
        if (isLocalityLocked.value) return
        if (!canViewAllLocalities.value && (localityName == "الكل" || localityName.isBlank())) return
        val allowed = dynamicLocalities.value
        val clean = if (localityName == "الكل") "" else localityName
        if (!canViewAllLocalities.value && allowed.isNotEmpty() && allowed.none { it.equals(clean, ignoreCase = true) }) {
            return
        }
        val lockedId = if ((repository.getCurrentUser()?.AllowedLocalityID ?: 0) != 0) {
            repository.getCurrentUser()?.AllowedLocalityID ?: 0
        } else 0
        val nextBranch = lockedBranchName.value ?: ""
        if (_filterState.value.selectedLocalityName == clean &&
            _filterState.value.selectedLocalityId == lockedId &&
            _filterState.value.selectedBranchName == nextBranch
        ) return
        _filterState.update { it.copy(selectedLocalityName = clean, selectedLocalityId = lockedId, selectedBranchName = nextBranch) }
        _uiState.update { it.copy(selectedLocalityName = clean, selectedLocalityId = lockedId, selectedBranchName = nextBranch) }
        updateTotalCount()
    }

    fun onBranchSelected(branchName: String) {
        if (isBranchLocked.value) return
        val clean = if (branchName == "الكل" || branchName == "كافة الشعب" || branchName == "جميع الشعب المصرح بها") "" else branchName.trim()
        val allowedDivs = AccessControlManager.getCleanAllowedBranches()
        if (allowedDivs.isNotEmpty() && clean.isNotBlank() && allowedDivs.none { it.equals(clean, ignoreCase = true) }) {
            return
        }
        if (_filterState.value.selectedBranchName == clean) return
        _filterState.update { it.copy(selectedBranchName = clean) }
        _uiState.update { it.copy(selectedBranchName = clean) }
        updateTotalCount()
    }

    fun onShelterStatusSelected(shelterStatus: String) {
        if (_filterState.value.selectedShelterStatus == shelterStatus) return
        _filterState.update { it.copy(selectedShelterStatus = shelterStatus) }
        _uiState.update { it.copy(selectedShelterStatus = shelterStatus) }
        updateTotalCount()
    }

    /**
     * تطبيق فلتر العمر والجنس المفهرس (مع إعادة بناء خريطة الأبناء المطابقين فوراً)
     */
    fun applyAgeFilter(newAgeFilter: AgeFilterState) {
        val current = _filterState.value
        resetMatchedChildrenCache(current.searchQuery, newAgeFilter, current.refreshTrigger)
        _filterState.update { it.copy(ageFilter = newAgeFilter) }
        _uiState.update { it.copy(ageFilter = newAgeFilter) }
        updateTotalCount()
    }

    fun clearAgeFilter() {
        val cleared = AgeFilterState()
        val current = _filterState.value
        resetMatchedChildrenCache(current.searchQuery, cleared, current.refreshTrigger)
        _filterState.update { it.copy(ageFilter = cleared) }
        _uiState.update { it.copy(ageFilter = cleared, matchedChildrenCount = 0) }
        updateTotalCount()
    }

    private fun buildChildrenFilterSignature(
        searchQuery: String,
        ageFilter: AgeFilterState,
        refreshTrigger: Int
    ): String {
        val range = ageFilter.computeBirthDateRange()
        return "${searchQuery.trim()}|${ageFilter.isActive}|${range?.first.orEmpty()}|${range?.second.orEmpty()}|${ageFilter.cleanGender.orEmpty()}|$refreshTrigger"
    }

    private fun resetMatchedChildrenCache(
        searchQuery: String,
        ageFilter: AgeFilterState,
        refreshTrigger: Int
    ) {
        val sig = buildChildrenFilterSignature(searchQuery, ageFilter, refreshTrigger)
        synchronized(requestedChildrenLock) {
            currentChildrenFilterSignature = sig
            requestedFamilyIdsForCurrentFilter.clear()
        }
        _matchedChildrenByFamilyId.value = emptyMap()
        _familyChildrenMatchByParentId.value = emptyMap()
    }

    /**
     * تحميل دفعي غير معطل (Batch IO) للأبناء المرتبطين بالأسر الظاهرة حالياً في القائمة
     * (يدعم إبراز الابن المطابق للبحث وإبراز الأبناء المطابقين لفلتر العمر معاً في استعلام واحد).
     */
    fun ensureMatchedChildrenLoaded(familyNationalIds: List<String>) {
        val filter = _filterState.value
        val ageFilter = filter.ageFilter
        val activeSearch = filter.searchQuery.trim()
        if (!ageFilter.isAnyChildFilterActive && activeSearch.isEmpty()) return
        if (familyNationalIds.isEmpty()) return

        val sig = buildChildrenFilterSignature(activeSearch, ageFilter, filter.refreshTrigger)
        val missingIds = synchronized(requestedChildrenLock) {
            if (currentChildrenFilterSignature != sig) {
                currentChildrenFilterSignature = sig
                requestedFamilyIdsForCurrentFilter.clear()
            }
            familyNationalIds
                .map { it.trim() }
                .filter { it.isNotBlank() && requestedFamilyIdsForCurrentFilter.add(it) }
        }
        if (missingIds.isEmpty()) return

        val dateRange = ageFilter.computeBirthDateRange()
        val gender = ageFilter.cleanGender

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val loadedMatches = repository.getFamilyChildrenMatchesForIds(
                    familyNationalIds = missingIds,
                    rawSearchQuery = activeSearch,
                    minBirthDateIso = dateRange?.first,
                    maxBirthDateIso = dateRange?.second,
                    gender = gender
                )
                if (currentChildrenFilterSignature != sig) return@launch
                _familyChildrenMatchByParentId.update { existing ->
                    val next = HashMap<String, AidRepository.OfficialFamilyChildrenMatch>(existing.size + missingIds.size)
                    next.putAll(existing)
                    for (fid in missingIds) {
                        next[fid] = loadedMatches[fid] ?: AidRepository.OfficialFamilyChildrenMatch()
                    }
                    next
                }
                _matchedChildrenByFamilyId.update { existing ->
                    val next = HashMap<String, List<ChildEntity>>(existing.size + missingIds.size)
                    next.putAll(existing)
                    for (fid in missingIds) {
                        next[fid] = loadedMatches[fid]?.ageFilteredChildren.orEmpty()
                    }
                    next
                }
            } catch (_: Throwable) {
                synchronized(requestedChildrenLock) {
                    if (currentChildrenFilterSignature == sig) {
                        requestedFamilyIdsForCurrentFilter.removeAll(missingIds.toSet())
                    }
                }
            }
        }
    }

    private var countJob: Job? = null

    private fun updateTotalCount() {
        countJob?.cancel()
        countJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val state = _filterState.value
                val shelter = if (state.selectedShelterStatus.isBlank()) null else state.selectedShelterStatus
                val locName = if (state.selectedLocalityName.isBlank() || state.selectedLocalityName == "الكل") null else state.selectedLocalityName
                val branch = if (state.selectedBranchName.isBlank() || state.selectedBranchName == "الكل") null else state.selectedBranchName
                val dateRange = state.ageFilter.computeBirthDateRange()
                val childGender = state.ageFilter.cleanGender

                val total = repository.getFamiliesCount(
                    query = state.searchQuery,
                    localityId = state.selectedLocalityId,
                    shelterStatus = shelter,
                    localityName = locName,
                    branchName = branch,
                    childBirthDateMin = dateRange?.first,
                    childBirthDateMax = dateRange?.second,
                    childGender = childGender
                )

                val matchedChildren = if (state.ageFilter.isAnyChildFilterActive) {
                    repository.getMatchedChildrenCount(
                        query = state.searchQuery,
                        localityId = state.selectedLocalityId,
                        shelterStatus = shelter,
                        localityName = locName,
                        branchName = branch,
                        childBirthDateMin = dateRange?.first,
                        childBirthDateMax = dateRange?.second,
                        childGender = childGender
                    )
                } else {
                    0
                }

                _uiState.update {
                    it.copy(
                        totalCount = total,
                        matchedChildrenCount = matchedChildren
                    )
                }
            } catch (_: Exception) {
            }
        }
    }

    // ==================== التصدير المخصص حسب الفلتر الحالي ====================

    private var exportJob: Job? = null

    fun startFilteredExport(
        context: Context,
        reportType: AgeExportReportType,
        format: AgeExportFormat
    ) {
        if (_uiState.value.isExporting) return
        val filter = _filterState.value
        val dateRange = filter.ageFilter.computeBirthDateRange()
        val criteria = AgeExportCriteria(
            searchQuery = filter.searchQuery,
            localityId = filter.selectedLocalityId,
            localityName = filter.selectedLocalityName,
            branchName = filter.selectedBranchName,
            shelterStatus = filter.selectedShelterStatus,
            ageFilterActive = filter.ageFilter.isActive,
            minYears = filter.ageFilter.minYears,
            minMonths = filter.ageFilter.minMonths,
            maxYears = filter.ageFilter.maxYears,
            maxMonths = filter.ageFilter.maxMonths,
            minBirthDateIso = dateRange?.first,
            maxBirthDateIso = dateRange?.second,
            gender = filter.ageFilter.gender
        )

        _uiState.update {
            it.copy(
                isExporting = true,
                exportProgress = AgeExportProgress(0, it.totalCount, 0),
                lastExportResult = null,
                exportError = null
            )
        }

        exportJob?.cancel()
        exportJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = AgeFilteredChildrenExporter.export(
                    context = context.applicationContext,
                    repository = repository,
                    criteria = criteria,
                    reportType = reportType,
                    format = format,
                    onProgress = { prog ->
                        _uiState.update { it.copy(exportProgress = prog) }
                    }
                )
                _uiState.update {
                    it.copy(
                        isExporting = false,
                        exportProgress = null,
                        lastExportResult = result,
                        exportError = null
                    )
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                _uiState.update { it.copy(isExporting = false, exportProgress = null) }
                throw ce
            } catch (t: Throwable) {
                _uiState.update {
                    it.copy(
                        isExporting = false,
                        exportProgress = null,
                        exportError = t.localizedMessage ?: "تعذر إنشاء ملف التصدير."
                    )
                }
            }
        }
    }

    fun clearExportState() {
        exportJob?.cancel()
        _uiState.update {
            it.copy(
                isExporting = false,
                exportProgress = null,
                lastExportResult = null,
                exportError = null
            )
        }
    }

    // ==================== التحديث الجماعي للأبناء دفعة واحدة ====================

    private val bulkSyncCancelFlag = AtomicBoolean(false)
    private var bulkSyncJob: Job? = null

    fun startBulkChildrenSync(
        allAges: Boolean,
        minYears: Int,
        minMonths: Int,
        maxYears: Int,
        maxMonths: Int,
        updateMode: AidRepository.BulkChildrenUpdateMode
    ) {
        if (_uiState.value.isBulkSyncRunning) return
        bulkSyncCancelFlag.set(false)

        _uiState.update {
            it.copy(
                isBulkSyncRunning = true,
                bulkSyncProgress = AidRepository.BulkChildrenSyncProgress(
                    processedFamilies = 0,
                    totalFamilies = 0,
                    addedChildren = 0,
                    updatedChildren = 0,
                    skippedChildren = 0,
                    affectedFamilies = 0,
                    stageMessage = "جاري التحضير للاتصال بقاعدة السجل المدني..."
                ),
                bulkSyncReport = null
            )
        }

        bulkSyncJob?.cancel()
        bulkSyncJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val report = repository.bulkSyncAllFamiliesChildrenFromCivilRegistry(
                    allAges = allAges,
                    minYears = minYears,
                    minMonths = minMonths,
                    maxYears = maxYears,
                    maxMonths = maxMonths,
                    updateMode = updateMode,
                    shouldCancel = { bulkSyncCancelFlag.get() },
                    onProgress = { progress ->
                        _uiState.update { it.copy(bulkSyncProgress = progress) }
                    }
                )
                val nextTrigger = _filterState.value.refreshTrigger + 1
                resetMatchedChildrenCache(_filterState.value.searchQuery, _filterState.value.ageFilter, nextTrigger)
                _filterState.update { it.copy(refreshTrigger = nextTrigger) }
                _uiState.update {
                    it.copy(
                        isBulkSyncRunning = false,
                        bulkSyncProgress = null,
                        bulkSyncReport = report
                    )
                }
                updateTotalCount()
            } catch (ce: kotlinx.coroutines.CancellationException) {
                _uiState.update {
                    it.copy(
                        isBulkSyncRunning = false,
                        bulkSyncProgress = null
                    )
                }
                throw ce
            } catch (t: Throwable) {
                _uiState.update {
                    it.copy(
                        isBulkSyncRunning = false,
                        bulkSyncProgress = null,
                        bulkSyncReport = AidRepository.BulkChildrenSyncReport(
                            totalFamiliesChecked = 0,
                            affectedFamiliesCount = 0,
                            addedChildrenCount = 0,
                            updatedChildrenCount = 0,
                            skippedChildrenCount = 0,
                            errorMessage = t.localizedMessage ?: "فشلت عملية التحديث الجماعي للأبناء."
                        )
                    )
                }
            }
        }
    }

    fun cancelBulkChildrenSync() {
        bulkSyncCancelFlag.set(true)
        _uiState.update { state ->
            val current = state.bulkSyncProgress
            if (current != null) {
                state.copy(
                    bulkSyncProgress = current.copy(stageMessage = "جاري إنهاء الدفعة الحالية وإيقاف العملية بأمان...")
                )
            } else {
                state
            }
        }
    }

    fun dismissBulkSyncReport() {
        _uiState.update { it.copy(bulkSyncReport = null) }
    }

    fun refresh() {
        val nextTrigger = _filterState.value.refreshTrigger + 1
        resetMatchedChildrenCache(_filterState.value.searchQuery, _filterState.value.ageFilter, nextTrigger)
        _filterState.update { it.copy(refreshTrigger = nextTrigger) }
        updateTotalCount()
    }

    fun loadInitialPage() {
        updateTotalCount()
    }

    fun loadNextPage() {
        // يتم إدارته آلياً عبر Paging 3
    }

    fun calculateAge(birthDateString: String?): Int? {
        if (birthDateString.isNullOrBlank()) return null
        return ExactAgeUtil.calculateCalendarAge(birthDateString)?.years
    }

    fun normalizeNationalId(id: String?): String {
        return ExcelParserHelper.normalizeNationalId(id)
    }

    suspend fun checkFamilyExistsByNationalId(nationalId: String): Boolean {
        val cleanId = ExcelParserHelper.normalizeNationalId(nationalId)
        if (cleanId.isBlank()) return false
        return repository.getFamilyByNationalId(cleanId) != null
    }

    suspend fun saveFamily(family: FamilyEntity): Long {
        val isNew = family.familyID == 0L
        if (isNew && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_ADD)) {
            throw SecurityException("ليس لديك صلاحية إضافة أسر جديدة (ممنوع بموجب سياسة الأمان المؤسسية)")
        }
        if (!isNew && !AccessControlManager.hasActionPermission(AccessControlManager.ACTION_EDIT)) {
            throw SecurityException("ليس لديك صلاحية تعديل بيانات المواطنين (ممنوع بموجب سياسة الأمان المؤسسية)")
        }

        val normalized = family.copy(
            nationalID = ExcelParserHelper.normalizeNationalId(family.nationalID),
            wifeNationalID = family.wifeNationalID?.let { ExcelParserHelper.normalizeNationalId(it) }?.ifBlank { null }
        )
        val id = repository.insertFamily(normalized)
        refresh()
        return id
    }

    suspend fun deleteFamily(family: FamilyEntity) {
        if (!AccessControlManager.hasActionPermission(AccessControlManager.ACTION_DELETE)) {
            throw SecurityException("ليس لديك صلاحية حذف سجلات الأسر (ممنوع بموجب سياسة الأمان المؤسسية)")
        }
        repository.deleteFamily(family)
        refresh()
    }

    fun resetFilters() {
        val user = repository.getCurrentUser()
        val initialLoc = if ((user?.AllowedLocalityID ?: 0) != 0) {
            user?.AllowedLocalityID ?: 0
        } else 0
        val defaultLocName = lockedLocalityName.value
            ?: if (!canViewAllLocalities.value) dynamicLocalities.value.firstOrNull() ?: "" else ""
        val defaultBranchName = lockedBranchName.value ?: ""
        val clearedAge = AgeFilterState()
        _rawSearchQueryFlow.value = ""
        resetMatchedChildrenCache("", clearedAge, 0)
        _filterState.value = FamilyFilterState(
            selectedLocalityId = initialLoc,
            selectedLocalityName = defaultLocName,
            selectedBranchName = defaultBranchName,
            ageFilter = clearedAge
        )
        _uiState.update {
            it.copy(
                searchQuery = "",
                selectedLocalityId = initialLoc,
                selectedLocalityName = defaultLocName,
                selectedBranchName = defaultBranchName,
                selectedShelterStatus = "",
                ageFilter = clearedAge,
                matchedChildrenCount = 0,
                errorMessage = null
            )
        }
        updateTotalCount()
    }

    fun clearState() {
        countJob?.cancel()
        exportJob?.cancel()
        bulkSyncCancelFlag.set(true)
        bulkSyncJob?.cancel()
        resetFilters()
        _uiState.value = FamiliesUiState(selectedLocalityId = _filterState.value.selectedLocalityId)
    }

    override fun onCleared() {
        super.onCleared()
        clearState()
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return FamiliesViewModel(repository) as T
        }
    }
}
