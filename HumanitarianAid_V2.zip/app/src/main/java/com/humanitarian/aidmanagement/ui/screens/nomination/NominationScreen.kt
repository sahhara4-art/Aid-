package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.local.entities.donor
import com.humanitarian.aidmanagement.data.local.entities.isOpen
import com.humanitarian.aidmanagement.data.local.entities.targetQuota
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.GlassButton
import com.humanitarian.aidmanagement.ui.components.GlassCard
import com.humanitarian.aidmanagement.ui.components.GlassStatusBadge
import com.humanitarian.aidmanagement.engine.ExclusionMode
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * MASTER ARCHITECTURE V3.0: THE ULTIMATE HYBRID NOMINATION SCREEN
 * شاشة الترشيح العملياتية الموحدة:
 * 1. اختيار المشروع المفتوح حصراً (isOpen == true)
 * 2. فلاتر الشرائح ثلاثية الحالات (Multi-State Chips) والاستثناء الزمني بالمفكرة
 * 3. التوزيع النسبي العادل ولوحة مراجعة الحصص (Calculated vs Nominated)
 * 4. الترشيح الهجين (آلي حتى سقف الحصة + إضافة واستبعاد يدوي)
 * 5. حماية وضع القراءة فقط، والأقفال الصارمة لمنع تجاوز سقف المشروع.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NominationScreen(
    repository: AidRepository,
    nominationViewModel: NominationViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToManualSelection: (aidTypeId: Int, projectId: Long) -> Unit,
    onNavigateToResults: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current

    // حالة المستخدم والمنطقة المخصصة (RBAC)
    val currentUser by repository.currentUserFlow.collectAsStateWithLifecycle(initialValue = repository.getCurrentUser())
    val userAssignedRegion = remember(currentUser) {
        val region = currentUser?.AllowedNominationSubAreas?.trim() ?: "All"
        if (region == "*" || region.isBlank()) "All" else region
    }

    LaunchedEffect(userAssignedRegion) {
        nominationViewModel.setAssignedSubRegion(userAssignedRegion)
    }

    // بيانات المشاريع والوضع العام
    val openProjects by nominationViewModel.openProjects.collectAsStateWithLifecycle()
    val allProjects by nominationViewModel.allActiveProjects.collectAsStateWithLifecycle()
    val selectedProject by nominationViewModel.selectedProject.collectAsStateWithLifecycle()
    val isReadOnlyMode by nominationViewModel.isReadOnlyMode.collectAsStateWithLifecycle()

    LaunchedEffect(openProjects) {
        if (selectedProject == null && openProjects.isNotEmpty()) {
            nominationViewModel.selectedProject.value = openProjects.first()
        }
    }

    // تدفقات الفلاتر والحصص والمرشحين والصلاحيات الجغرافية
    val filteredFamilies by nominationViewModel.filteredFamilies.collectAsStateWithLifecycle()
    val selectedNominees by nominationViewModel.selectedNominees.collectAsStateWithLifecycle()
    val localityQuotaStats by nominationViewModel.localityQuotaStats.collectAsStateWithLifecycle()
    val canViewAllLocalities by nominationViewModel.canViewAllLocalities.collectAsStateWithLifecycle()
    val isLocalityLocked by nominationViewModel.isLocalityLocked.collectAsStateWithLifecycle()
    val lockedLocalityName by nominationViewModel.lockedLocalityName.collectAsStateWithLifecycle()
    val allowedBranches by nominationViewModel.allowedBranches.collectAsStateWithLifecycle()
    val canNominate by nominationViewModel.canNominate.collectAsStateWithLifecycle()

    // خيارات الفلاتر الديناميكية
    val shelterOptions by nominationViewModel.dynamicShelterOptions.collectAsStateWithLifecycle()
    val worksApprovalOptions by nominationViewModel.dynamicWorksApprovalOptions.collectAsStateWithLifecycle()
    val damageOptions by nominationViewModel.dynamicDamageOptions.collectAsStateWithLifecycle()
    val incomeOptions by nominationViewModel.dynamicIncomeOptions.collectAsStateWithLifecycle()
    val subAreaOptions by nominationViewModel.dynamicSubAreaOptions.collectAsStateWithLifecycle()
    val maritalStatusOptions by nominationViewModel.dynamicMaritalStatusOptions.collectAsStateWithLifecycle()

    // حالات الشرائح
    val shelterChips by nominationViewModel.shelterChipStates.collectAsStateWithLifecycle()
    val worksApprovalChips by nominationViewModel.worksApprovalChipStates.collectAsStateWithLifecycle()
    val damageChips by nominationViewModel.damageChipStates.collectAsStateWithLifecycle()
    val incomeChips by nominationViewModel.incomeChipStates.collectAsStateWithLifecycle()
    val localityChips by nominationViewModel.localityChipStates.collectAsStateWithLifecycle()
    val selectedMaritalStatuses by nominationViewModel.selectedMaritalStatuses.collectAsStateWithLifecycle()
    val excludeMaritalStatuses by nominationViewModel.excludeMaritalStatuses.collectAsStateWithLifecycle()

    // مفاتيح تجاوز الفلاتر (Bypass Switches)
    val shelterFilterEnabled by nominationViewModel.shelterFilterEnabled.collectAsStateWithLifecycle()
    val worksApprovalFilterEnabled by nominationViewModel.worksApprovalFilterEnabled.collectAsStateWithLifecycle()
    val damageFilterEnabled by nominationViewModel.damageFilterEnabled.collectAsStateWithLifecycle()
    val incomeFilterEnabled by nominationViewModel.incomeFilterEnabled.collectAsStateWithLifecycle()
    val localityFilterEnabled by nominationViewModel.localityFilterEnabled.collectAsStateWithLifecycle()
    val maritalStatusFilterEnabled by nominationViewModel.maritalStatusFilterEnabled.collectAsStateWithLifecycle()

    // فلترة الأطفال ونطاق الأعمار
    val hasChildrenOnly by nominationViewModel.hasChildrenOnly.collectAsStateWithLifecycle()
    val minChildAgeText by nominationViewModel.minChildAgeText.collectAsStateWithLifecycle()
    val maxChildAgeText by nominationViewModel.maxChildAgeText.collectAsStateWithLifecycle()

    // MISSION 2: الفلتر الثنائي لمصدر الدخل (Binary Income)
    val binaryIncomeOption by nominationViewModel.binaryIncomeOption.collectAsStateWithLifecycle()

    // الاستثناء الزمني
    val exclusionMode by nominationViewModel.exclusionMode.collectAsStateWithLifecycle()
    val exclusionDays by nominationViewModel.exclusionDaysText.collectAsStateWithLifecycle()
    val exclusionDateCutoff by nominationViewModel.exclusionDateCutoffText.collectAsStateWithLifecycle()
    val minFamilyMembers by nominationViewModel.minFamilyMembers.collectAsStateWithLifecycle()

    // خطوات المعالج (0: المشروع، 1: الفلاتر، 2: الحصص والاختيار، 3: المراجعة والاعتماد)
    var currentStep by remember { mutableIntStateOf(0) }

    // BottomSheet للإضافة اليدوية
    var showManualAddSheet by remember { mutableStateOf(false) }
    var manualSearchQuery by remember { mutableStateOf("") }

    // حوار التقويم لاختيار تاريخ محدد (DatePickerDialog)
    var showDatePickerDialog by remember { mutableStateOf(false) }

    // حالة إشعار أو رسالة نتيجة الاعتماد
    var commitSuccessCount by remember { mutableStateOf<Int?>(null) }
    var isCommitting by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "محرك الترشيح الهجين الذكي V3.0",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (lockedLocalityName != null || userAssignedRegion != "All") {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = PalestineGreen.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = if (isLocalityLocked) "المحلية: ${lockedLocalityName ?: userAssignedRegion} 🔒" else "المنطقة المخصصة: $userAssignedRegion",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PalestineGreen,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (allowedBranches.isNotEmpty()) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF0F766E).copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = "الشعبة: ${allowedBranches.joinToString("، ")}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF0F766E),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (isReadOnlyMode) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = PalestineRed.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "وضع القراءة فقط (مغلق)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PalestineRed,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            nominationViewModel.resetFilters()
                            onNavigateBack()
                        }) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = { nominationViewModel.clearAllFilterChips() }) {
                            Icon(Icons.Default.RestartAlt, contentDescription = "إعادة ضبط", tint = PalestineGreen)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            bottomBar = {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (currentStep > 0) {
                            OutlinedButton(
                                onClick = { currentStep-- },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("السابق")
                            }
                        } else {
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        if (currentStep < 3) {
                            Button(
                                onClick = { currentStep++ },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                            ) {
                                Text("التالي")
                            }
                        } else {
                            // زر الاعتماد والترحيل النهائي بتأثير الزجاج العاكس
                            GlassButton(
                                onClick = {
                                    coroutineScope.launch {
                                        isCommitting = true
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        val result = nominationViewModel.commitNomination()
                                        isCommitting = false
                                        result.onSuccess { count ->
                                            commitSuccessCount = count
                                        }.onFailure { err ->
                                            android.widget.Toast.makeText(context, err.message ?: "فشل الاعتماد", android.widget.Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                enabled = canNominate && selectedNominees.isNotEmpty() && !isReadOnlyMode && !isCommitting,
                                containerColor = PalestineGreen,
                                icon = if (isCommitting) null else Icons.Default.Verified
                            ) {
                                if (isCommitting) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("جاري الاعتماد والترحيل...")
                                } else {
                                    Text("اعتماد وترحيل (${selectedNominees.size} أسرة)", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
            ) {
                // شريط المراحل التفاعلي (Step Indicator)
                TabRow(
                    selectedTabIndex = currentStep,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = PalestineGreen
                ) {
                    Tab(
                        selected = currentStep == 0,
                        onClick = { currentStep = 0 },
                        text = { Text("١. المشروع", fontWeight = if (currentStep == 0) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.FolderSpecial, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = currentStep == 1,
                        onClick = { currentStep = 1 },
                        text = { Text("٢. الفلاتر", fontWeight = if (currentStep == 1) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = currentStep == 2,
                        onClick = { currentStep = 2 },
                        text = { Text("٣. الحصص", fontWeight = if (currentStep == 2) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.PieChart, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = currentStep == 3,
                        onClick = { currentStep = 3 },
                        text = { Text("٤. المراجعة", fontWeight = if (currentStep == 3) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                // محتوى الخطوات مع الانتقال الحركي السلس
                AnimatedContent(
                    targetState = currentStep,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(slideOutHorizontally { width -> width } + fadeOut())
                        } else {
                            (slideInHorizontally { width -> width } + fadeIn()).togetherWith(slideOutHorizontally { width -> -width } + fadeOut())
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { step ->
                    when (step) {
                        0 -> Step0ProjectSelection(
                            openProjects = openProjects,
                            allProjects = allProjects,
                            selectedProject = selectedProject,
                            isReadOnlyMode = isReadOnlyMode,
                            onSelectProject = { nominationViewModel.selectedProject.value = it },
                            onNext = { currentStep = 1 }
                        )
                        1 -> Step1SuperDynamicFilters(
                            filteredFamiliesCount = filteredFamilies.size,
                            shelterOptions = shelterOptions,
                            worksApprovalOptions = worksApprovalOptions,
                            damageOptions = damageOptions,
                            incomeOptions = incomeOptions,
                            subAreaOptions = subAreaOptions,
                            maritalStatusOptions = maritalStatusOptions,
                            shelterChips = shelterChips,
                            worksApprovalChips = worksApprovalChips,
                            damageChips = damageChips,
                            incomeChips = incomeChips,
                            localityChips = localityChips,
                            selectedMaritalStatuses = selectedMaritalStatuses,
                            excludeMaritalStatuses = excludeMaritalStatuses,
                            shelterFilterEnabled = shelterFilterEnabled,
                            worksApprovalFilterEnabled = worksApprovalFilterEnabled,
                            damageFilterEnabled = damageFilterEnabled,
                            incomeFilterEnabled = incomeFilterEnabled,
                            localityFilterEnabled = localityFilterEnabled,
                            maritalStatusFilterEnabled = maritalStatusFilterEnabled,
                            binaryIncomeOption = binaryIncomeOption,
                            onToggleShelterEnabled = { nominationViewModel.setShelterFilterEnabled(it) },
                            onToggleWorksApprovalEnabled = { nominationViewModel.setWorksApprovalFilterEnabled(it) },
                            onToggleDamageEnabled = { nominationViewModel.setDamageFilterEnabled(it) },
                            onToggleIncomeEnabled = { nominationViewModel.setIncomeFilterEnabled(it) },
                            onToggleLocalityEnabled = { nominationViewModel.setLocalityFilterEnabled(it) },
                            onToggleMaritalStatusEnabled = { nominationViewModel.setMaritalStatusFilterEnabled(it) },
                            onToggleMaritalStatusOption = { nominationViewModel.toggleMaritalStatus(it) },
                            onToggleExcludeMaritalStatuses = { nominationViewModel.setExcludeMaritalStatuses(it) },
                            onClearMaritalStatuses = { nominationViewModel.clearMaritalStatuses() },
                            onSelectBinaryIncomeOption = { nominationViewModel.toggleBinaryIncomeOption(it) },
                            hasChildrenOnly = hasChildrenOnly,
                            minChildAgeText = minChildAgeText,
                            maxChildAgeText = maxChildAgeText,
                            onToggleChildrenEnabled = { nominationViewModel.setHasChildrenOnly(it) },
                            onMinChildAgeChange = { nominationViewModel.minChildAgeText.value = it },
                            onMaxChildAgeChange = { nominationViewModel.maxChildAgeText.value = it },
                            exclusionMode = exclusionMode,
                            exclusionDays = exclusionDays,
                            exclusionDateCutoff = exclusionDateCutoff,
                            minFamilyMembers = minFamilyMembers,
                            onCycleChip = { cat, key -> nominationViewModel.cycleChipState(cat, key) },
                            onSetExclusionMode = { nominationViewModel.exclusionMode.value = it },
                            onSetExclusionDays = { nominationViewModel.exclusionDaysText.value = it },
                            onOpenDatePicker = { showDatePickerDialog = true },
                            onSetMinMembers = { nominationViewModel.minFamilyMembers.value = it },
                            onResetFilters = { nominationViewModel.clearAllFilterChips() }
                        )
                        2 -> Step2HybridSelectionAndQuotas(
                            selectedProject = selectedProject,
                            isReadOnlyMode = isReadOnlyMode || !canNominate,
                            filteredFamiliesCount = filteredFamilies.size,
                            selectedNomineesCount = selectedNominees.size,
                            quotaStats = localityQuotaStats,
                            onAutoNominate = { nominationViewModel.runAutoNomination() },
                            onOpenManualAdd = { showManualAddSheet = true },
                            onClearNominees = { nominationViewModel.clearNominees() }
                        )
                        3 -> Step3FinalReviewAndCommit(
                            selectedProject = selectedProject,
                            selectedNominees = selectedNominees.toList(),
                            isReadOnlyMode = isReadOnlyMode,
                            onRemoveNominee = { nominationViewModel.removeNominee(it) }
                        )
                    }
                }
            }
        }

        // نافذة مفكرة التاريخ (Material 3 DatePicker)
        if (showDatePickerDialog) {
            val datePickerState = rememberDatePickerState()
            DatePickerDialog(
                onDismissRequest = { showDatePickerDialog = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val selectedMillis = datePickerState.selectedDateMillis
                            if (selectedMillis != null) {
                                val cal = Calendar.getInstance().apply { timeInMillis = selectedMillis }
                                val formatted = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                nominationViewModel.exclusionDateCutoffText.value = formatted
                            }
                            showDatePickerDialog = false
                        }
                    ) {
                        Text("تأكيد التاريخ")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDatePickerDialog = false }) {
                        Text("إلغاء")
                    }
                }
            ) {
                DatePicker(state = datePickerState)
            }
        }

        // BottomSheet للإضافة اليدوية: الدليل التفاعلي الذكي المصنف جغرافياً مع العدادات
        if (showManualAddSheet) {
            val currentProject = selectedProject
            val currentTarget = currentProject?.targetQuota ?: 0
            val isFull = selectedNominees.size >= currentTarget

            // MISSION 3: Dynamic locality tabs generated strictly from families.map { it.currentSubRegion }.distinct()
            val distinctSubRegions = remember(filteredFamilies) {
                filteredFamilies.map { it.currentSubRegion }.distinct().filter { it.isNotBlank() }
            }
            val distinctSubRegionsWithCounts = remember(filteredFamilies, distinctSubRegions) {
                distinctSubRegions.map { region ->
                    region to filteredFamilies.count { it.currentSubRegion == region }
                }.sortedByDescending { it.second }
            }

            val directoryTabs = remember(filteredFamilies, distinctSubRegionsWithCounts, canViewAllLocalities) {
                if (canViewAllLocalities) {
                    listOf("الكل" to filteredFamilies.size) + distinctSubRegionsWithCounts
                } else {
                    distinctSubRegionsWithCounts
                }
            }

            var selectedDirectoryTab by remember(directoryTabs) {
                mutableStateOf(directoryTabs.firstOrNull()?.first ?: "")
            }

            ModalBottomSheet(
                onDismissRequest = { 
                    showManualAddSheet = false
                    manualSearchQuery = ""
                    selectedDirectoryTab = directoryTabs.firstOrNull()?.first ?: ""
                },
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "دليل الإضافة اليدوية للأسر المؤهلة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "دليل تفاعلي مصنف حسب المحلية مع إحصائيات فورية",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextMuted
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isFull) PalestineRed.copy(alpha = 0.15f) else PalestineGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${selectedNominees.size} / $currentTarget مرشح",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isFull) PalestineRed else PalestineGreen,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (isFull) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PalestineRed.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ تم استيفاء الحصة الكلية للمشروع بالكامل ($currentTarget). لا يمكن إضافة أسر جديدة قبل استبعاد أسر أخرى.",
                                color = PalestineRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 1. UI Layout Top: حقل البحث (فلتر ثانوي على القائمة)
                    OutlinedTextField(
                        value = manualSearchQuery,
                        onValueChange = { manualSearchQuery = it },
                        placeholder = { Text("بحث بالاسم، رقم الهوية، أو المنطقة...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = PalestineGreen) },
                        trailingIcon = {
                            if (manualSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { manualSearchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "مسح")
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 2. UI Layout Middle (NEW): شريط التبويبات الفئوية الجغرافية مع العدادات
                    val activeTabIndex = directoryTabs.indexOfFirst { it.first == selectedDirectoryTab }.coerceAtLeast(0)
                    ScrollableTabRow(
                        selectedTabIndex = activeTabIndex,
                        edgePadding = 4.dp,
                        containerColor = Color.Transparent,
                        contentColor = PalestineGreen,
                        divider = {}
                    ) {
                        directoryTabs.forEachIndexed { index, (tabName, count) ->
                            val isSelected = activeTabIndex == index
                            Tab(
                                selected = isSelected,
                                onClick = { selectedDirectoryTab = tabName },
                                text = {
                                    Text(
                                        text = "$tabName ($count)",
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        color = if (isSelected) PalestineGreen else SlateTextMuted
                                    )
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // 3. UI Layout Bottom: القائمة المعروضة المصفاة حسب التبويب والبحث
                    val displayedDirectoryFamilies = remember(filteredFamilies, selectedNominees, manualSearchQuery, selectedDirectoryTab) {
                        val query = manualSearchQuery.trim().lowercase()
                        filteredFamilies.filter { fam ->
                            val matchesTab = if (selectedDirectoryTab == "الكل") {
                                true
                            } else {
                                fam.currentSubRegion == selectedDirectoryTab
                            }

                            val matchesSearch = query.isEmpty() ||
                                    fam.name.lowercase().contains(query) ||
                                    fam.nationalID.contains(query) ||
                                    fam.currentSubRegion.lowercase().contains(query) ||
                                    fam.primary_phone.contains(query)

                            matchesTab && matchesSearch
                        }
                    }

                    if (displayedDirectoryFamilies.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.SearchOff, contentDescription = null, tint = SlateTextMuted, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("لا توجد أسر مؤهلة مطابقة في هذا التصنيف", color = SlateTextMuted, fontSize = 13.sp)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(displayedDirectoryFamilies, key = { it.familyID }) { family ->
                                val isNominated = selectedNominees.contains(family)
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isNominated) PalestineGreen.copy(alpha = 0.08f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    ),
                                    border = if (isNominated) androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.4f)) else null,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text(text = family.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                if (isNominated) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = PalestineGreen.copy(alpha = 0.15f)
                                                    ) {
                                                        Text("مرشح بالفعل ✓", color = PalestineGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                    }
                                                }
                                            }
                                            Text(
                                                text = "هوية: ${family.nationalID} • أفراد: ${family.familyMembersCount} • المنطقة: ${family.currentSubRegion}",
                                                fontSize = 11.sp,
                                                color = SlateTextMuted
                                            )
                                        }
                                        if (isNominated) {
                                            IconButton(
                                                onClick = { nominationViewModel.removeNominee(family) },
                                                enabled = !isReadOnlyMode
                                            ) {
                                                Icon(Icons.Default.Close, contentDescription = "استبعاد", tint = PalestineRed)
                                            }
                                        } else {
                                            Button(
                                                onClick = {
                                                    nominationViewModel.addNomineeManually(family)
                                                },
                                                enabled = !isFull && !isReadOnlyMode,
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                                            ) {
                                                Text("إضافة", fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // نافذة نجاح الاعتماد الاحتفالية
        if (commitSuccessCount != null) {
            AlertDialog(
                onDismissRequest = { commitSuccessCount = null },
                icon = {
                    Icon(
                        Icons.Default.Verified,
                        contentDescription = null,
                        tint = PalestineGreen,
                        modifier = Modifier.size(54.dp)
                    )
                },
                title = {
                    Text(
                        text = "تم اعتماد وترحيل الترشيح بنجاح!",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "تم ترحيل $commitSuccessCount أسرة رسمياً إلى سجلات المساعدات للمشروع (${selectedProject?.projectName}).",
                            textAlign = TextAlign.Center,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "أصبحت الأسماء الآن جاهزة للصرف والتسليم الميداني مع الباركود والإيصالات.",
                            textAlign = TextAlign.Center,
                            fontSize = 12.sp,
                            color = SlateTextMuted
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            commitSuccessCount = null
                            onNavigateToResults()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                    ) {
                        Text("عرض النتائج وسجلات المشروع")
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { commitSuccessCount = null }) {
                        Text("البقاء هنا")
                    }
                }
            )
        }
    }
}

/**
 * الخطوة 0: اختيار المشروع المفتوح حصراً (Step 0: Project Selection)
 */
@Composable
fun Step0ProjectSelection(
    openProjects: List<ProjectEntity>,
    allProjects: List<ProjectEntity>,
    selectedProject: ProjectEntity?,
    isReadOnlyMode: Boolean,
    onSelectProject: (ProjectEntity) -> Unit,
    onNext: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "الخطوة الأولى: اختيار المشروع الإنساني المستهدف",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "تقتصر عمليات الترشيح العملياتية فقط على المشاريع المفتوحة النشطة (isOpen == true).",
                style = MaterialTheme.typography.bodySmall,
                color = SlateTextMuted
            )
        }

        if (openProjects.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = PalestineRed, modifier = Modifier.size(36.dp))
                        Text(
                            text = "لا توجد حالياً مشاريع مفتوحة للترشيح",
                            fontWeight = FontWeight.Bold,
                            color = PalestineRed
                        )
                        Text(
                            text = "كافة المشاريع مغلقة أو مكتملة. يرجى من مدير النظام (Admin) فتح أو طرح مشروع جديد من شاشة إدارة المشاريع.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF991B1B)
                        )
                    }
                }
            }
        } else {
            item {
                Text(
                    text = "المشاريع المتاحة للترشيح:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            items(openProjects, key = { it.projectID }) { project ->
                val isSelected = selectedProject?.projectID == project.projectID
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectProject(project) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) PalestineGreen.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        if (isSelected) 2.dp else 1.dp,
                        if (isSelected) PalestineGreen else SlateBorder
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = project.projectName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isSelected) PalestineGreen else MaterialTheme.colorScheme.onSurface
                                )
                                if (isSelected) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "رقم: ${project.projectNumber} • المانح: ${project.fundingInstitution}",
                                fontSize = 12.sp,
                                color = SlateTextMuted
                            )
                            Text(
                                text = "الحصة المستهدفة: ${project.targetQuota} أسرة • المخزن: ${project.warehouseName}",
                                fontSize = 11.sp,
                                color = PalestineGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        RadioButton(
                            selected = isSelected,
                            onClick = { onSelectProject(project) },
                            colors = RadioButtonDefaults.colors(selectedColor = PalestineGreen)
                        )
                    }
                }
            }
        }

        // تفاصيل المشروع المختار وزر المتابعة
        selectedProject?.let { prj ->
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = PalestineGreen)
                            Text("ملخص المشروع المختار", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Divider(color = SlateBorder)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الاسم:", color = SlateTextMuted, fontSize = 12.sp)
                            Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الحصة الكلية:", color = SlateTextMuted, fontSize = 12.sp)
                            Text("${prj.targetQuota} مستفيد", fontWeight = FontWeight.Bold, color = PalestineGreen, fontSize = 12.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الجهة المانحة:", color = SlateTextMuted, fontSize = 12.sp)
                            Text(prj.fundingInstitution, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

/**
 * الخطوة 1: محرك الفلاتر الديناميكي الفائق (Step 1: Super Dynamic Filter Engine)
 */
@Composable
fun Step1SuperDynamicFilters(
    filteredFamiliesCount: Int,
    shelterOptions: List<String>,
    worksApprovalOptions: List<String>,
    damageOptions: List<String>,
    incomeOptions: List<String>,
    subAreaOptions: List<String>,
    maritalStatusOptions: List<String>,
    shelterChips: Map<String, ChipFilterState>,
    worksApprovalChips: Map<String, ChipFilterState>,
    damageChips: Map<String, ChipFilterState>,
    incomeChips: Map<String, ChipFilterState>,
    localityChips: Map<String, ChipFilterState>,
    selectedMaritalStatuses: List<String>,
    excludeMaritalStatuses: Boolean,
    shelterFilterEnabled: Boolean,
    worksApprovalFilterEnabled: Boolean,
    damageFilterEnabled: Boolean,
    incomeFilterEnabled: Boolean,
    localityFilterEnabled: Boolean,
    maritalStatusFilterEnabled: Boolean,
    binaryIncomeOption: String?,
    onToggleShelterEnabled: (Boolean) -> Unit,
    onToggleWorksApprovalEnabled: (Boolean) -> Unit,
    onToggleDamageEnabled: (Boolean) -> Unit,
    onToggleIncomeEnabled: (Boolean) -> Unit,
    onToggleLocalityEnabled: (Boolean) -> Unit,
    onToggleMaritalStatusEnabled: (Boolean) -> Unit,
    onToggleMaritalStatusOption: (String) -> Unit,
    onToggleExcludeMaritalStatuses: (Boolean) -> Unit,
    onClearMaritalStatuses: () -> Unit,
    onSelectBinaryIncomeOption: (String) -> Unit,
    hasChildrenOnly: Boolean,
    minChildAgeText: String,
    maxChildAgeText: String,
    onToggleChildrenEnabled: (Boolean) -> Unit,
    onMinChildAgeChange: (String) -> Unit,
    onMaxChildAgeChange: (String) -> Unit,
    exclusionMode: ExclusionMode,
    exclusionDays: String,
    exclusionDateCutoff: String,
    minFamilyMembers: Int,
    onCycleChip: (String, String) -> Unit,
    onSetExclusionMode: (ExclusionMode) -> Unit,
    onSetExclusionDays: (String) -> Unit,
    onOpenDatePicker: () -> Unit,
    onSetMinMembers: (Int) -> Unit,
    onResetFilters: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // شريط العداد الحي للأسر المطابقة للشروط الصارمة
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PalestineGreen.copy(alpha = 0.12f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("الأسر المطابقة للشروط الصارمة", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PalestineGreen)
                        Text("(معتمد بالشؤون AND مقيم) مع كافة الفلاتر", fontSize = 11.sp, color = SlateTextMuted)
                    }
                    Text(
                        text = "$filteredFamiliesCount أسرة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = PalestineGreen
                    )
                }
            }
        }

        // دليل حالات الشرائح ومفاتيح التجاوز
        item {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("انقر على الشريحة للتبديل:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(modifier = Modifier.size(10.dp).background(PalestineGreen, CircleShape))
                        Text("تضمين [✓]", fontSize = 10.sp, color = PalestineGreen, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(modifier = Modifier.size(10.dp).background(PalestineRed, CircleShape))
                        Text("استثناء [✕]", fontSize = 10.sp, color = PalestineRed, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.ToggleOn, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                        Text("مفتاح التجاوز", fontSize = 10.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 1. فلتر حالة اعتماد الأشغال (Works Approval Status) مع مفتاح التجاوز
        item {
            FilterCategorySection(
                title = "حالة اعتماد الأشغال (Works Approval)",
                options = worksApprovalOptions,
                chipStates = worksApprovalChips,
                isEnabled = worksApprovalFilterEnabled,
                onToggleEnabled = onToggleWorksApprovalEnabled,
                onChipClick = { onCycleChip("worksApproval", it) }
            )
        }

        // 2. فلتر حالة الإيواء (Shelter Status) مع مفتاح التجاوز
        item {
            FilterCategorySection(
                title = "حالة الإيواء ومراكز النزوح (Shelter)",
                options = shelterOptions,
                chipStates = shelterChips,
                isEnabled = shelterFilterEnabled,
                onToggleEnabled = onToggleShelterEnabled,
                onChipClick = { onCycleChip("shelter", it) }
            )
        }

        // 3. فلتر نوع الضرر (Damage Types) مع مفتاح التجاوز
        item {
            FilterCategorySection(
                title = "حالة أضرار الحرب والمنازل (Damage)",
                options = damageOptions,
                chipStates = damageChips,
                isEnabled = damageFilterEnabled,
                onToggleEnabled = onToggleDamageEnabled,
                onChipClick = { onCycleChip("damage", it) }
            )
        }

        // 3.5 فلتر الحالة الاجتماعية (Marital Status) بتصميم زجاجي مع تعدد الاختيار ومفتاح الاستثناء
        item {
            MaritalStatusFilterSection(
                options = maritalStatusOptions,
                selectedStatuses = selectedMaritalStatuses,
                excludeSelected = excludeMaritalStatuses,
                isEnabled = maritalStatusFilterEnabled,
                onToggleEnabled = onToggleMaritalStatusEnabled,
                onToggleOption = onToggleMaritalStatusOption,
                onExcludeChange = onToggleExcludeMaritalStatuses,
                onClear = onClearMaritalStatuses
            )
        }

        // 4. فلتر شرط وجود الأبناء ونطاق الأعمار (Children & Age Range Filter) مع مفتاح التجاوز
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.ChildCare, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(20.dp))
                            Column {
                                Text("شرط وجود الأبناء ونطاق الأعمار", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("فلترة الأسر التي لديها أبناء في نطاق عمري محدد", fontSize = 11.sp, color = SlateTextMuted)
                            }
                        }
                        Switch(
                            checked = hasChildrenOnly,
                            onCheckedChange = onToggleChildrenEnabled,
                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = PalestineGreen)
                        )
                    }

                    AnimatedVisibility(
                        visible = hasChildrenOnly,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("نطاق عمر الابن (بالسنوات):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = SlateTextMuted)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = minChildAgeText,
                                    onValueChange = onMinChildAgeChange,
                                    label = { Text("من عمر") },
                                    placeholder = { Text("0") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                )
                                OutlinedTextField(
                                    value = maxChildAgeText,
                                    onValueChange = onMaxChildAgeChange,
                                    label = { Text("إلى عمر") },
                                    placeholder = { Text("18") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. فلتر مصادر الدخل الديناميكي (مستمد بالكامل من قاعدة البيانات) مع مفتاح التجاوز
        item {
            FilterCategorySection(
                title = "حالة العمل ومصدر الدخل (Income)",
                options = incomeOptions,
                chipStates = incomeChips,
                isEnabled = incomeFilterEnabled,
                onToggleEnabled = onToggleIncomeEnabled,
                onChipClick = { onCycleChip("income", it) }
            )
        }

        // 6. فلتر المناطق والمحليات الفرعية (Sub-Areas) مع مفتاح التجاوز
        item {
            FilterCategorySection(
                title = "المناطق والمحليات الفرعية (Sub-Areas)",
                options = subAreaOptions,
                chipStates = localityChips,
                isEnabled = localityFilterEnabled,
                onToggleEnabled = onToggleLocalityEnabled,
                onChipClick = { onCycleChip("locality", it) }
            )
        }

        // 6. الاستثناء الزمني المتقدم (Date Exclusion)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("الاستثناء الزمني للمساعدات السابقة (Date Exclusion)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = exclusionMode == ExclusionMode.DAYS,
                            onClick = { onSetExclusionMode(ExclusionMode.DAYS) },
                            label = { Text("آخر X أيام") }
                        )
                        FilterChip(
                            selected = exclusionMode == ExclusionMode.DATE,
                            onClick = { onSetExclusionMode(ExclusionMode.DATE) },
                            label = { Text("تاريخ قاطع محدد (Calendar)") }
                        )
                    }

                    if (exclusionMode == ExclusionMode.DAYS) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("15", "30", "60", "90").forEach { d ->
                                FilterChip(
                                    selected = exclusionDays == d,
                                    onClick = { onSetExclusionDays(d) },
                                    label = { Text("$d يوم") }
                                )
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = onOpenDatePicker,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.DateRange, contentDescription = null, tint = PalestineGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (exclusionDateCutoff.isNotBlank()) "التاريخ المختار: $exclusionDateCutoff" else "فتح المفكرة لاختيار التاريخ القاطع",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 7. حد أفراد الأسرة
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الحد الأدنى لعدد أفراد الأسرة: $minFamilyMembers أفراد فما فوق", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Slider(
                        value = minFamilyMembers.toFloat(),
                        onValueChange = { onSetMinMembers(it.toInt()) },
                        valueRange = 1f..15f,
                        steps = 13,
                        colors = SliderDefaults.colors(thumbColor = PalestineGreen, activeTrackColor = PalestineGreen)
                    )
                }
            }
        }
    }
}

/**
 * مكون عرض شرائح التصنيف الواحد متعددة الحالات مع مفتاح التجاوز (Switch)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FilterCategorySection(
    title: String,
    options: List<String>,
    chipStates: Map<String, ChipFilterState>,
    isEnabled: Boolean = true,
    onToggleEnabled: ((Boolean) -> Unit)? = null,
    onChipClick: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isEnabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(if (isEnabled) 1.dp else 0.dp),
        border = if (!isEnabled) androidx.compose.foundation.BorderStroke(1.dp, SlateBorder) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isEnabled) MaterialTheme.colorScheme.onSurface else SlateTextMuted
                    )
                    if (!isEnabled) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = SlateBorder
                        ) {
                            Text(
                                text = "تجاوز (معطل)",
                                fontSize = 10.sp,
                                color = SlateTextMuted,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                if (onToggleEnabled != null) {
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = onToggleEnabled,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PalestineGreen,
                            uncheckedThumbColor = SlateTextMuted,
                            uncheckedTrackColor = SlateBorder
                        ),
                        modifier = Modifier.scale(0.85f)
                    )
                }
            }

            AnimatedVisibility(visible = isEnabled) {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    options.forEach { opt ->
                        val state = chipStates[opt] ?: ChipFilterState.UNSELECTED
                        TriStateFilterChip(
                            label = opt,
                            state = state,
                            onClick = { onChipClick(opt) }
                        )
                    }
                }
            }
        }
    }
}



/**
 * قسم فلتر الحالة الاجتماعية بتصميم زجاجي (Glassmorphism) يدعم التحديد المتعدد عبر FilterChip
 * ومفتاح تبديل "استثناء المحدد" (Exclude Selected)
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MaritalStatusFilterSection(
    options: List<String>,
    selectedStatuses: List<String>,
    excludeSelected: Boolean,
    isEnabled: Boolean = true,
    onToggleEnabled: (Boolean) -> Unit,
    onToggleOption: (String) -> Unit,
    onExcludeChange: (Boolean) -> Unit,
    onClear: () -> Unit
) {
    val activeAccent by animateColorAsState(
        targetValue = when {
            !isEnabled -> SlateTextMuted
            excludeSelected -> PalestineRed
            else -> PalestineGreen
        },
        label = "maritalAccent"
    )
    val glassBgColor by animateColorAsState(
        targetValue = when {
            !isEnabled -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            selectedStatuses.isNotEmpty() && excludeSelected -> Color(0xFFFFF1F2).copy(alpha = 0.90f)
            selectedStatuses.isNotEmpty() -> Color(0xFFF0FDF4).copy(alpha = 0.90f)
            else -> GlassSurfaceLight
        },
        label = "maritalGlassBg"
    )
    val glassBorderColor by animateColorAsState(
        targetValue = when {
            !isEnabled -> SlateBorder
            selectedStatuses.isNotEmpty() -> activeAccent.copy(alpha = 0.45f)
            else -> GlassBorderLight
        },
        label = "maritalGlassBorder"
    )

    GlassCard(
        shape = RoundedCornerShape(18.dp),
        surfaceColor = glassBgColor,
        borderColor = glassBorderColor,
        elevation = if (isEnabled) 4.dp else 0.dp,
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(activeAccent.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.People,
                            contentDescription = null,
                            tint = activeAccent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "الحالة الاجتماعية (Marital Status)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (isEnabled) MaterialTheme.colorScheme.onSurface else SlateTextMuted
                            )
                            if (isEnabled && selectedStatuses.isNotEmpty()) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = activeAccent.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = if (excludeSelected) "استثناء (${selectedStatuses.size})" else "تضمين (${selectedStatuses.size})",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = activeAccent,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            } else if (!isEnabled) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = SlateBorder
                                ) {
                                    Text(
                                        text = "تجاوز (معطل)",
                                        fontSize = 10.sp,
                                        color = SlateTextMuted,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = if (selectedStatuses.isEmpty()) "اختيار متعدد • اترك فارغاً لتشمل جميع الحالات"
                            else if (excludeSelected) "يتم استبعاد الحالات المحددة (NOT IN)"
                            else "يتم تضمين الحالات المحددة فقط (IN)",
                            fontSize = 11.sp,
                            color = if (selectedStatuses.isNotEmpty() && excludeSelected) PalestineRed else SlateTextMuted
                        )
                    }
                }

                Switch(
                    checked = isEnabled,
                    onCheckedChange = onToggleEnabled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = PalestineGreen,
                        uncheckedThumbColor = SlateTextMuted,
                        uncheckedTrackColor = SlateBorder
                    ),
                    modifier = Modifier.scale(0.85f)
                )
            }

            AnimatedVisibility(visible = isEnabled) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // شريط مفتاح استثناء المحدد + زر المسح
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (excludeSelected) PalestineRed.copy(alpha = 0.08f) else GlassSurfaceSubtle,
                        border = androidx.compose.foundation.BorderStroke(
                            width = 1.dp,
                            color = if (excludeSelected) PalestineRed.copy(alpha = 0.35f) else SlateBorder.copy(alpha = 0.7f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = if (excludeSelected) Icons.Default.Block else Icons.Default.FilterAlt,
                                    contentDescription = null,
                                    tint = if (excludeSelected) PalestineRed else PalestineGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "استثناء المحدد",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (excludeSelected) PalestineRed else MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (selectedStatuses.isNotEmpty()) {
                                    TextButton(
                                        onClick = onClear,
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Text(
                                            text = "مسح (${selectedStatuses.size})",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PalestineRed
                                        )
                                    }
                                }
                                Switch(
                                    checked = excludeSelected,
                                    onCheckedChange = onExcludeChange,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = PalestineRed,
                                        uncheckedThumbColor = Color.White,
                                        uncheckedTrackColor = SlateBorderSubtle
                                    ),
                                    modifier = Modifier.scale(0.85f)
                                )
                            }
                        }
                    }

                    // شرائح الاختيار المتعدد (FilterChip FlowRow)
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        options.forEach { statusOption ->
                            val isSelected = selectedStatuses.contains(statusOption)
                            val chipBg by animateColorAsState(
                                targetValue = when {
                                    isSelected && excludeSelected -> PalestineRed.copy(alpha = 0.14f)
                                    isSelected -> PalestineGreen.copy(alpha = 0.14f)
                                    else -> Color.White.copy(alpha = 0.72f)
                                },
                                label = "maritalChipBg"
                            )
                            val chipBorder by animateColorAsState(
                                targetValue = when {
                                    isSelected && excludeSelected -> PalestineRed
                                    isSelected -> PalestineGreen
                                    else -> SlateBorder
                                },
                                label = "maritalChipBorder"
                            )
                            val chipContentColor = when {
                                isSelected && excludeSelected -> PalestineRed
                                isSelected -> PalestineGreen
                                else -> MaterialTheme.colorScheme.onSurface
                            }

                            FilterChip(
                                selected = isSelected,
                                onClick = { onToggleOption(statusOption) },
                                label = {
                                    Text(
                                        text = statusOption,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                leadingIcon = if (isSelected) {
                                    {
                                        Icon(
                                            imageVector = if (excludeSelected) Icons.Default.Block else Icons.Default.Check,
                                            contentDescription = null,
                                            tint = chipContentColor,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                } else null,
                                shape = RoundedCornerShape(10.dp),
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = Color.White.copy(alpha = 0.72f),
                                    labelColor = MaterialTheme.colorScheme.onSurface,
                                    selectedContainerColor = chipBg,
                                    selectedLabelColor = chipContentColor,
                                    selectedLeadingIconColor = chipContentColor
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = chipBorder,
                                    selectedBorderColor = chipBorder,
                                    borderWidth = 1.dp,
                                    selectedBorderWidth = 1.5.dp
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * شريحة الفلترة ثلاثية الحالات (Tri-State Chip)
 */
@Composable
fun TriStateFilterChip(
    label: String,
    state: ChipFilterState,
    onClick: () -> Unit
) {
    val bgColor = when (state) {
        ChipFilterState.UNSELECTED -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ChipFilterState.INCLUDED -> PalestineGreen.copy(alpha = 0.15f)
        ChipFilterState.EXCLUDED -> PalestineRed.copy(alpha = 0.15f)
    }
    val borderColor = when (state) {
        ChipFilterState.UNSELECTED -> SlateBorder
        ChipFilterState.INCLUDED -> PalestineGreen
        ChipFilterState.EXCLUDED -> PalestineRed
    }
    val textColor = when (state) {
        ChipFilterState.UNSELECTED -> MaterialTheme.colorScheme.onSurface
        ChipFilterState.INCLUDED -> PalestineGreen
        ChipFilterState.EXCLUDED -> PalestineRed
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            when (state) {
                ChipFilterState.INCLUDED -> Icon(Icons.Default.Check, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(14.dp))
                ChipFilterState.EXCLUDED -> Icon(Icons.Default.Close, contentDescription = null, tint = PalestineRed, modifier = Modifier.size(14.dp))
                ChipFilterState.UNSELECTED -> {}
            }
            Text(text = label, fontSize = 12.sp, fontWeight = if (state != ChipFilterState.UNSELECTED) FontWeight.Bold else FontWeight.Normal, color = textColor)
        }
    }
}

/**
 * الخطوة 2: الاختيار الهجين ولوحة الحصص (Step 2: Hybrid Selection & Quotas Dashboard)
 */
@Composable
fun Step2HybridSelectionAndQuotas(
    selectedProject: ProjectEntity?,
    isReadOnlyMode: Boolean,
    filteredFamiliesCount: Int,
    selectedNomineesCount: Int,
    quotaStats: List<LocalityQuotaStatsItem>,
    onAutoNominate: () -> Unit,
    onOpenManualAdd: () -> Unit,
    onClearNominees: () -> Unit
) {
    val targetQuota = selectedProject?.targetQuota ?: 100
    val progress = (selectedNomineesCount.toFloat() / targetQuota.toFloat()).coerceIn(0f, 1f)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // بطاقة ملخص الحصة الكلية والتقدم
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("المرشحون الحاليون / سقف الحصة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("المشروع: ${selectedProject?.projectName ?: "عام"}", fontSize = 11.sp, color = SlateTextMuted)
                        }
                        Text(
                            text = "$selectedNomineesCount / $targetQuota",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = if (selectedNomineesCount >= targetQuota) PalestineGreen else Color(0xFF2563EB)
                        )
                    }

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = if (selectedNomineesCount >= targetQuota) PalestineGreen else Color(0xFF2563EB),
                        trackColor = SlateBorder
                    )

                    // أزرار التحكم والترشيح الآلي/اليدوي
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onAutoNominate,
                            enabled = !isReadOnlyMode && filteredFamiliesCount > 0,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                        ) {
                            Icon(Icons.Default.AutoMode, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ترشيح آلي عادل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onOpenManualAdd,
                            enabled = !isReadOnlyMode && selectedNomineesCount < targetQuota,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة يدوية", fontSize = 12.sp)
                        }

                        IconButton(
                            onClick = onClearNominees,
                            enabled = !isReadOnlyMode && selectedNomineesCount > 0
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "تفريغ", tint = PalestineRed)
                        }
                    }
                }
            }
        }

        // عنوان لوحة الحصص
        item {
            Text(
                text = "لوحة مراجعة الحصص النسبية بالمحليات (Locality Quota Review)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        // قائمة المحليات مع الحصة المحسوبة والمرشحين والعجز/الفائض
        items(quotaStats, key = { it.localityName }) { stat ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = stat.localityName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = "الأسر المؤهلة: ${stat.baseX} (${stat.formattedPercentage})",
                            fontSize = 11.sp,
                            color = SlateTextMuted
                        )
                    }

                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "الحصة: ${stat.targetQuota} • المرشحون: ${stat.nominatedCount}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )

                        // شارة العجز أو الفائض
                        val diff = stat.shortageExcess
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = when {
                                diff < 0 -> PalestineRed.copy(alpha = 0.12f)
                                diff == 0 -> PalestineGreen.copy(alpha = 0.12f)
                                else -> Color(0xFFF59E0B).copy(alpha = 0.12f)
                            }
                        ) {
                            Text(
                                text = when {
                                    diff < 0 -> "عجز: ${-diff}"
                                    diff == 0 -> "مكتمل ✓"
                                    else -> "زيادة: +$diff"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    diff < 0 -> PalestineRed
                                    diff == 0 -> PalestineGreen
                                    else -> Color(0xFFD97706)
                                },
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * الخطوة 3: المراجعة النهائية والاعتماد (Step 3: Final Review & Commit)
 */
@Composable
fun Step3FinalReviewAndCommit(
    selectedProject: ProjectEntity?,
    selectedNominees: List<FamilyEntity>,
    isReadOnlyMode: Boolean,
    onRemoveNominee: (FamilyEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("كشف المرشحين النهائي الجاهز للترحيل", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("المشروع: ${selectedProject?.projectName} • إجمالي المرشحين: ${selectedNominees.size} أسرة", fontSize = 12.sp, color = PalestineGreen, fontWeight = FontWeight.Bold)
                    if (isReadOnlyMode) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = PalestineRed.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ هذا المشروع مغلق ومكتمل. لا يمكن ترحيل أو تعديل أسماء إضافية.",
                                color = PalestineRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }

        if (selectedNominees.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لم يتم اختيار أي مرشحين حتى الآن. يرجى العودة للخطوة السابقة والضغط على (ترشيح آلي عادل) أو الإضافة يدوياً.",
                        textAlign = TextAlign.Center,
                        color = SlateTextMuted,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(selectedNominees, key = { it.familyID }) { nominee ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = nominee.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "هوية: ${nominee.nationalID} • جوال: ${nominee.primary_phone} • أفراد: ${nominee.familyMembersCount}",
                                fontSize = 11.sp,
                                color = SlateTextMuted
                            )
                            Text(
                                text = "المنطقة الحالية: ${nominee.currentSubRegion} • الإيواء: ${nominee.shelterStatus}",
                                fontSize = 11.sp,
                                color = PalestineGreen
                            )
                        }

                        if (!isReadOnlyMode) {
                            IconButton(onClick = { onRemoveNominee(nominee) }) {
                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "استبعاد", tint = PalestineRed)
                            }
                        }
                    }
                }
            }
        }
    }
}
