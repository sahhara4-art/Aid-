package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.local.entities.donor
import com.humanitarian.aidmanagement.data.local.entities.isOpen
import com.humanitarian.aidmanagement.data.local.entities.targetQuota
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.GlassButton
import com.humanitarian.aidmanagement.ui.components.GlassCard
import com.humanitarian.aidmanagement.ui.components.GlassStatusBadge
import com.humanitarian.aidmanagement.engine.ExclusionMode
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * MASTER ARCHITECTURE V3.0: THE ULTIMATE HYBRID NOMINATION SCREEN
 * شاشة الترشيح العملياتية الموحدة:
 * 1. اختيار المشروع المفتوح حصراً (isOpen == true)
 * 2. فلاتر الشرائح ثلاثية الحالات (Multi-State Chips) والاستثناء الزمني بالمفكرة
 * 3. التوزيع النسبي العادل ولوحة مراجعة الحصص (Calculated vs Nominated)
 * 4. الترشيح الهجين (آلي حتى سقف الحصة + إضافة واستبعاد يدوي)
 * 5. حماية وضع القراءة فقط، والأقفال الصارمة لمنع تجاوز سقف المشروع.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NominationScreen(
    repository: AidRepository,
    nominationViewModel: NominationViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToManualSelection: (aidTypeId: Int, projectId: Long) -> Unit,
    onNavigateToResults: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current

    // حالة المستخدم والمنطقة المخصصة (RBAC)
    val currentUser by repository.currentUserFlow.collectAsStateWithLifecycle(initialValue = repository.getCurrentUser())
    val userAssignedRegion = remember(currentUser) {
        val region = currentUser?.AllowedNominationSubAreas?.trim() ?: "All"
        if (region == "*" || region.isBlank()) "All" else region
    }

    LaunchedEffect(userAssignedRegion) {
        nominationViewModel.setAssignedSubRegion(userAssignedRegion)
    }

    LaunchedEffect(Unit) {
        nominationViewModel.refreshDynamicFilterOptions()
    }

    // بيانات المشاريع والوضع العام
    val openProjects by nominationViewModel.openProjects.collectAsStateWithLifecycle()
    val allProjects by nominationViewModel.allActiveProjects.collectAsStateWithLifecycle()
    val selectedProject by nominationViewModel.selectedProject.collectAsStateWithLifecycle()
    val isReadOnlyMode by nominationViewModel.isReadOnlyMode.collectAsStateWithLifecycle()

    LaunchedEffect(openProjects) {
        if (selectedProject == null && openProjects.isNotEmpty()) {
            nominationViewModel.selectProject(openProjects.first())
        }
    }

    // تدفقات الفلاتر والحصص والمرشحين والصلاحيات الجغرافية
    val filteredFamilies by nominationViewModel.filteredFamilies.collectAsStateWithLifecycle()
    val selectedNominees by nominationViewModel.selectedNominees.collectAsStateWithLifecycle()
    val alreadyNominatedCount by nominationViewModel.alreadyNominatedCount.collectAsStateWithLifecycle()
    val visibleTargetQuota by nominationViewModel.visibleTargetQuota.collectAsStateWithLifecycle()
    val projectRegionalQuotas by nominationViewModel.projectRegionalQuotasMap.collectAsStateWithLifecycle()
    val remainingQuota by nominationViewModel.remainingQuota.collectAsStateWithLifecycle()
    val isGeoRestrictedUser by nominationViewModel.isGeoRestrictedUser.collectAsStateWithLifecycle()
    val effectiveUserRegion by nominationViewModel.effectiveUserRegion.collectAsStateWithLifecycle()
    val effectiveUserSubRegion by nominationViewModel.effectiveUserSubRegion.collectAsStateWithLifecycle()
    val scopeDisplayLabel = remember(effectiveUserRegion, effectiveUserSubRegion, userAssignedRegion) {
        when {
            effectiveUserRegion != "ALL" && effectiveUserSubRegion != "ALL" -> "$effectiveUserRegion — $effectiveUserSubRegion"
            effectiveUserRegion != "ALL" -> effectiveUserRegion
            effectiveUserSubRegion != "ALL" -> effectiveUserSubRegion
            userAssignedRegion != "All" -> userAssignedRegion
            else -> "النطاق المخصص"
        }
    }
    val localityQuotaStats by nominationViewModel.localityQuotaStats.collectAsStateWithLifecycle()
    val canViewAllLocalities by nominationViewModel.canViewAllLocalities.collectAsStateWithLifecycle()
    val isLocalityLocked by nominationViewModel.isLocalityLocked.collectAsStateWithLifecycle()
    val lockedLocalityName by nominationViewModel.lockedLocalityName.collectAsStateWithLifecycle()
    val assignedSubArea by nominationViewModel.assignedSubArea.collectAsStateWithLifecycle()
    val allowedBranches by nominationViewModel.allowedBranches.collectAsStateWithLifecycle()
    val availableBranches by nominationViewModel.availableBranches.collectAsStateWithLifecycle()
    val isBranchLocked by nominationViewModel.isBranchLocked.collectAsStateWithLifecycle()
    val lockedBranchName by nominationViewModel.lockedBranchName.collectAsStateWithLifecycle()
    val canViewAllBranches by nominationViewModel.canViewAllBranches.collectAsStateWithLifecycle()
    val selectedLocalitiesFilter by nominationViewModel.selectedLocalitiesFilter.collectAsStateWithLifecycle()
    val selectedBranchesFilter by nominationViewModel.selectedBranchesFilter.collectAsStateWithLifecycle()
    val dynamicLocalitiesList by nominationViewModel.pureLocalities.collectAsStateWithLifecycle()
    val canNominate by nominationViewModel.canNominate.collectAsStateWithLifecycle()

    // صفة الإقامة الديناميكية (الشرط الإلزامي الوحيد) وحالة التفعيل الحصرية لزر الترشيح
    val residencyStatusOptions by nominationViewModel.dynamicResidencyStatusOptions.collectAsStateWithLifecycle()
    val selectedResidencyStatus by nominationViewModel.selectedResidencyStatus.collectAsStateWithLifecycle()
    val isSubmitEnabled by nominationViewModel.isSubmitEnabled.collectAsStateWithLifecycle()

    // خيارات الفلاتر الديناميكية الاختيارية
    val shelterOptions by nominationViewModel.dynamicShelterOptions.collectAsStateWithLifecycle()
    val worksApprovalOptions by nominationViewModel.dynamicWorksApprovalOptions.collectAsStateWithLifecycle()
    val damageOptions by nominationViewModel.dynamicDamageOptions.collectAsStateWithLifecycle()
    val aidCategoryOptions by nominationViewModel.dynamicAidCategoryOptions.collectAsStateWithLifecycle()
    val maritalStatusOptions by nominationViewModel.dynamicMaritalStatusOptions.collectAsStateWithLifecycle()

    // حالات الشرائح
    val shelterChips by nominationViewModel.shelterChipStates.collectAsStateWithLifecycle()
    val worksApprovalChips by nominationViewModel.worksApprovalChipStates.collectAsStateWithLifecycle()
    val damageChips by nominationViewModel.damageChipStates.collectAsStateWithLifecycle()
    val aidCategoryChips by nominationViewModel.aidCategoryChipStates.collectAsStateWithLifecycle()
    val selectedMaritalStatuses by nominationViewModel.selectedMaritalStatuses.collectAsStateWithLifecycle()
    val excludeMaritalStatuses by nominationViewModel.excludeMaritalStatuses.collectAsStateWithLifecycle()

    // مفاتيح تجاوز الفلاتر (Bypass Switches)
    val shelterFilterEnabled by nominationViewModel.shelterFilterEnabled.collectAsStateWithLifecycle()
    val worksApprovalFilterEnabled by nominationViewModel.worksApprovalFilterEnabled.collectAsStateWithLifecycle()
    val damageFilterEnabled by nominationViewModel.damageFilterEnabled.collectAsStateWithLifecycle()
    val incomeFilterEnabled by nominationViewModel.incomeFilterEnabled.collectAsStateWithLifecycle()
    val aidCategoryFilterEnabled by nominationViewModel.aidCategoryFilterEnabled.collectAsStateWithLifecycle()
    val maritalStatusFilterEnabled by nominationViewModel.maritalStatusFilterEnabled.collectAsStateWithLifecycle()

    // فلترة الأطفال ونطاق الأعمار
    val hasChildrenOnly by nominationViewModel.hasChildrenOnly.collectAsStateWithLifecycle()
    val minChildAgeText by nominationViewModel.minChildAgeText.collectAsStateWithLifecycle()
    val maxChildAgeText by nominationViewModel.maxChildAgeText.collectAsStateWithLifecycle()

    // فلتر حالة العمل المنطقي الذكي (الكل / يعمل (لديه دخل) / لا يعمل (بدون دخل))
    val workStatusFilter by nominationViewModel.workStatusFilter.collectAsStateWithLifecycle()

    // الاستثناء الزمني
    val exclusionMode by nominationViewModel.exclusionMode.collectAsStateWithLifecycle()
    val exclusionDays by nominationViewModel.exclusionDaysText.collectAsStateWithLifecycle()
    val exclusionDateCutoff by nominationViewModel.exclusionDateCutoffText.collectAsStateWithLifecycle()
    val minFamilyMembers by nominationViewModel.minFamilyMembers.collectAsStateWithLifecycle()

    // خطوات المعالج (0: المشروع، 1: الفلاتر، 2: الحصص والاختيار، 3: المراجعة والاعتماد)
    var currentStep by remember { mutableIntStateOf(0) }

    // BottomSheet للإضافة اليدوية
    var showManualAddSheet by remember { mutableStateOf(false) }
    var manualSearchQuery by remember { mutableStateOf("") }

    // حوار التقويم لاختيار تاريخ محدد (DatePickerDialog)
    var showDatePickerDialog by remember { mutableStateOf(false) }

    // حالة إشعار أو رسالة نتيجة الاعتماد
    var commitSuccessCount by remember { mutableStateOf<Int?>(null) }
    var isCommitting by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "محرك الترشيح الهجين الذكي V3.0",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (lockedLocalityName != null || userAssignedRegion != "All") {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = PalestineGreen.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = if (isLocalityLocked) "المحلية: ${lockedLocalityName ?: userAssignedRegion} 🔒" else "المنطقة المخصصة: $userAssignedRegion",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PalestineGreen,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (allowedBranches.isNotEmpty()) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF0F766E).copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = "الشعبة: ${allowedBranches.joinToString("، ")}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF0F766E),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (isReadOnlyMode) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = PalestineRed.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "وضع القراءة فقط (مغلق)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PalestineRed,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            nominationViewModel.resetFilters()
                            onNavigateBack()
                        }) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = { nominationViewModel.clearAllFilterChips() }) {
                            Icon(Icons.Default.RestartAlt, contentDescription = "إعادة ضبط", tint = PalestineGreen)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            bottomBar = {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (currentStep > 0) {
                            OutlinedButton(
                                onClick = { currentStep-- },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("السابق")
                            }
                        } else {
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        if (currentStep == 1) {
                            Button(
                                onClick = {
                                    if (selectedProject == null && openProjects.isNotEmpty()) {
                                        nominationViewModel.selectProject(openProjects.first())
                                    }
                                    nominationViewModel.runAutoNomination()
                                    currentStep = 2
                                },
                                enabled = isSubmitEnabled,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PalestineGreen,
                                    disabledContainerColor = SlateBorder,
                                    disabledContentColor = SlateTextMuted
                                )
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("بدء الترشيح", fontWeight = FontWeight.Bold)
                            }
                        } else if (currentStep < 3) {
                            Button(
                                onClick = { currentStep++ },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                            ) {
                                Text("التالي")
                            }
                        } else {
                            // زر الاعتماد والترحيل النهائي بتأثير الزجاج العاكس
                            GlassButton(
                                onClick = {
                                    coroutineScope.launch {
                                        isCommitting = true
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        val result = nominationViewModel.commitNomination()
                                        isCommitting = false
                                        result.onSuccess { count ->
                                            commitSuccessCount = count
                                        }.onFailure { err ->
                                            android.widget.Toast.makeText(context, err.message ?: "فشل الاعتماد", android.widget.Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                enabled = canNominate && selectedNominees.isNotEmpty() && !isReadOnlyMode && !isCommitting,
                                containerColor = PalestineGreen,
                                icon = if (isCommitting) null else Icons.Default.Verified
                            ) {
                                if (isCommitting) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("جاري الاعتماد والترحيل...")
                                } else {
                                    Text("اعتماد وترحيل (${selectedNominees.size} أسرة)", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
            ) {
                // شريط المراحل التفاعلي (Step Indicator)
                TabRow(
                    selectedTabIndex = currentStep,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = PalestineGreen
                ) {
                    Tab(
                        selected = currentStep == 0,
                        onClick = { currentStep = 0 },
                        text = { Text("١. المشروع", fontWeight = if (currentStep == 0) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.FolderSpecial, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = currentStep == 1,
                        onClick = { currentStep = 1 },
                        text = { Text("٢. الفلاتر", fontWeight = if (currentStep == 1) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = currentStep == 2,
                        onClick = { currentStep = 2 },
                        text = { Text("٣. الحصص", fontWeight = if (currentStep == 2) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.PieChart, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = currentStep == 3,
                        onClick = { currentStep = 3 },
                        text = { Text("٤. المراجعة", fontWeight = if (currentStep == 3) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                // محتوى الخطوات مع الانتقال الحركي السلس
                AnimatedContent(
                    targetState = currentStep,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(slideOutHorizontally { width -> width } + fadeOut())
                        } else {
                            (slideInHorizontally { width -> width } + fadeIn()).togetherWith(slideOutHorizontally { width -> -width } + fadeOut())
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { step ->
                    when (step) {
                        0 -> Step0ProjectSelection(
                            openProjects = openProjects,
                            allProjects = allProjects,
                            selectedProject = selectedProject,
                            visibleTargetQuota = visibleTargetQuota,
                            projectRegionalQuotas = projectRegionalQuotas,
                            alreadyNominatedCount = alreadyNominatedCount,
                            remainingQuota = remainingQuota,
                            isGeoRestrictedUser = isGeoRestrictedUser,
                            scopeLabel = scopeDisplayLabel,
                            isReadOnlyMode = isReadOnlyMode,
                            onSelectProject = { nominationViewModel.selectProject(it) },
                            onNext = { currentStep = 1 }
                        )
                        1 -> Step1SuperDynamicFilters(
                            filteredFamiliesCount = filteredFamilies.size,
                            residencyStatusOptions = residencyStatusOptions,
                            selectedResidencyStatus = selectedResidencyStatus,
                            onSelectResidencyStatus = { nominationViewModel.setSelectedResidencyStatus(it) },
                            isSubmitEnabled = isSubmitEnabled,
                            onStartNomination = {
                                if (selectedProject == null && openProjects.isNotEmpty()) {
                                    nominationViewModel.selectProject(openProjects.first())
                                }
                                nominationViewModel.runAutoNomination()
                                currentStep = 2
                            },
                            shelterOptions = shelterOptions,
                            worksApprovalOptions = worksApprovalOptions,
                            damageOptions = damageOptions,
                            aidCategoryOptions = aidCategoryOptions,
                            maritalStatusOptions = maritalStatusOptions,
                            shelterChips = shelterChips,
                            worksApprovalChips = worksApprovalChips,
                            damageChips = damageChips,
                            aidCategoryChips = aidCategoryChips,
                            selectedMaritalStatuses = selectedMaritalStatuses,
                            excludeMaritalStatuses = excludeMaritalStatuses,
                            shelterFilterEnabled = shelterFilterEnabled,
                            worksApprovalFilterEnabled = worksApprovalFilterEnabled,
                            damageFilterEnabled = damageFilterEnabled,
                            incomeFilterEnabled = incomeFilterEnabled,
                            aidCategoryFilterEnabled = aidCategoryFilterEnabled,
                            maritalStatusFilterEnabled = maritalStatusFilterEnabled,
                            workStatusFilter = workStatusFilter,
                            onToggleShelterEnabled = { nominationViewModel.setShelterFilterEnabled(it) },
                            onToggleWorksApprovalEnabled = { nominationViewModel.setWorksApprovalFilterEnabled(it) },
                            onToggleDamageEnabled = { nominationViewModel.setDamageFilterEnabled(it) },
                            onToggleIncomeEnabled = { nominationViewModel.setIncomeFilterEnabled(it) },
                            onToggleAidCategoryEnabled = { nominationViewModel.setAidCategoryFilterEnabled(it) },
                            onToggleMaritalStatusEnabled = { nominationViewModel.setMaritalStatusFilterEnabled(it) },
                            onToggleMaritalStatusOption = { nominationViewModel.toggleMaritalStatus(it) },
                            onToggleExcludeMaritalStatuses = { nominationViewModel.setExcludeMaritalStatuses(it) },
                            onClearMaritalStatuses = { nominationViewModel.clearMaritalStatuses() },
                            onSelectWorkStatusFilter = { nominationViewModel.setWorkStatusFilter(it) },
                            hasChildrenOnly = hasChildrenOnly,
                            minChildAgeText = minChildAgeText,
                            maxChildAgeText = maxChildAgeText,
                            onToggleChildrenEnabled = { nominationViewModel.setHasChildrenOnly(it) },
                            onMinChildAgeChange = { nominationViewModel.minChildAgeText.value = it },
                            onMaxChildAgeChange = { nominationViewModel.maxChildAgeText.value = it },
                            exclusionMode = exclusionMode,
                            exclusionDays = exclusionDays,
                            exclusionDateCutoff = exclusionDateCutoff,
                            minFamilyMembers = minFamilyMembers,
                            onCycleChip = { cat, key -> nominationViewModel.cycleChipState(cat, key) },
                            onSetExclusionMode = { nominationViewModel.exclusionMode.value = it },
                            onSetExclusionDays = { nominationViewModel.exclusionDaysText.value = it },
                            onOpenDatePicker = { showDatePickerDialog = true },
                            onSetMinMembers = { nominationViewModel.minFamilyMembers.value = it },
                            onResetFilters = { nominationViewModel.clearAllFilterChips() },
                            localityOptions = dynamicLocalitiesList,
                            selectedLocalitiesFilter = selectedLocalitiesFilter,
                            isLocalityLocked = isLocalityLocked || assignedSubArea != null,
                            lockedLocalityName = lockedLocalityName ?: assignedSubArea,
                            canViewAllLocalities = canViewAllLocalities,
                            onToggleLocalityFilter = { nominationViewModel.toggleLocalityFilterOption(it) },
                            onClearLocalitiesFilter = { nominationViewModel.clearLocalitiesFilter() },
                            branchOptions = availableBranches,
                            selectedBranchesFilter = selectedBranchesFilter,
                            isBranchLocked = isBranchLocked,
                            lockedBranchName = lockedBranchName,
                            canViewAllBranches = canViewAllBranches,
                            onToggleBranchFilter = { nominationViewModel.toggleBranchFilterOption(it) },
                            onClearBranchesFilter = { nominationViewModel.clearBranchesFilter() }
                        )
                        2 -> Step2HybridSelectionAndQuotas(
                            selectedProject = selectedProject,
                            isReadOnlyMode = isReadOnlyMode || !canNominate,
                            isSubmitEnabled = isSubmitEnabled,
                            filteredFamiliesCount = filteredFamilies.size,
                            selectedNomineesCount = selectedNominees.size,
                            visibleTargetQuota = visibleTargetQuota,
                            alreadyNominatedCount = alreadyNominatedCount,
                            remainingQuota = remainingQuota,
                            isGeoRestrictedUser = isGeoRestrictedUser,
                            scopeLabel = scopeDisplayLabel,
                            quotaStats = localityQuotaStats,
                            onAutoNominate = { nominationViewModel.runAutoNomination() },
                            onOpenManualAdd = { showManualAddSheet = true },
                            onClearNominees = { nominationViewModel.clearNominees() }
                        )
                        3 -> Step3FinalReviewAndCommit(
                            selectedProject = selectedProject,
                            selectedNominees = selectedNominees.toList(),
                            alreadyNominatedCount = alreadyNominatedCount,
                            remainingQuota = remainingQuota,
                            isReadOnlyMode = isReadOnlyMode,
                            onRemoveNominee = { nominationViewModel.removeNominee(it) }
                        )
                    }
                }
            }
        }

        // نافذة مفكرة التاريخ (Material 3 DatePicker)
        if (showDatePickerDialog) {
            val datePickerState = rememberDatePickerState()
            DatePickerDialog(
                onDismissRequest = { showDatePickerDialog = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val selectedMillis = datePickerState.selectedDateMillis
                            if (selectedMillis != null) {
                                val cal = Calendar.getInstance().apply { timeInMillis = selectedMillis }
                                val formatted = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                nominationViewModel.exclusionDateCutoffText.value = formatted
                            }
                            showDatePickerDialog = false
                        }
                    ) {
                        Text("تأكيد التاريخ")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDatePickerDialog = false }) {
                        Text("إلغاء")
                    }
                }
            ) {
                DatePicker(state = datePickerState)
            }
        }

        // BottomSheet للإضافة اليدوية: الدليل التفاعلي الذكي المصنف جغرافياً مع العدادات
        if (showManualAddSheet) {
            val currentProject = selectedProject
            val currentTarget = if (isGeoRestrictedUser) visibleTargetQuota else (currentProject?.targetQuota ?: 0)
            val effectiveRemaining = remainingQuota
            val isFull = selectedNominees.size >= effectiveRemaining

            // MISSION 3: Dynamic locality tabs generated strictly from families.map { it.currentSubRegion }.distinct()
            val distinctSubRegions = remember(filteredFamilies) {
                filteredFamilies.map { it.currentSubRegion }.distinct().filter { it.isNotBlank() }
            }
            val distinctSubRegionsWithCounts = remember(filteredFamilies, distinctSubRegions) {
                distinctSubRegions.map { region ->
                    region to filteredFamilies.count { it.currentSubRegion == region }
                }.sortedByDescending { it.second }
            }

            val directoryTabs = remember(filteredFamilies, distinctSubRegionsWithCounts, canViewAllLocalities) {
                if (canViewAllLocalities) {
                    listOf("الكل" to filteredFamilies.size) + distinctSubRegionsWithCounts
                } else {
                    distinctSubRegionsWithCounts
                }
            }

            var selectedDirectoryTab by remember(directoryTabs) {
                mutableStateOf(directoryTabs.firstOrNull()?.first ?: "")
            }

            ModalBottomSheet(
                onDismissRequest = { 
                    showManualAddSheet = false
                    manualSearchQuery = ""
                    selectedDirectoryTab = directoryTabs.firstOrNull()?.first ?: ""
                },
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "دليل الإضافة اليدوية للأسر المؤهلة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "تم ترشيح ($alreadyNominatedCount) سابقاً | المتبقي للترشيح: ($effectiveRemaining)",
                                style = MaterialTheme.typography.bodySmall,
                                color = PalestineGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isFull) PalestineRed.copy(alpha = 0.15f) else PalestineGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${selectedNominees.size} / $effectiveRemaining متبقي",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isFull) PalestineRed else PalestineGreen,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (isFull) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PalestineRed.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (effectiveRemaining <= 0) {
                                    if (isGeoRestrictedUser) "⚠️ تم استيفاء العدد المخصص لمنطقتك بالكامل ($currentTarget). تم ترشيح ($alreadyNominatedCount) سابقاً والمتبقي: (0)."
                                    else "⚠️ تم استيفاء الحصة الكلية للمشروع بالكامل ($currentTarget). تم ترشيح ($alreadyNominatedCount) سابقاً والمتبقي: (0)."
                                } else {
                                    "⚠️ تم بلوغ الحد المتبقي للحصة ($effectiveRemaining). لا يمكن إضافة أسر جديدة قبل استبعاد أسر من الدفعة الحالية."
                                },
                                color = PalestineRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 1. UI Layout Top: حقل البحث (فلتر ثانوي على القائمة)
                    OutlinedTextField(
                        value = manualSearchQuery,
                        onValueChange = { manualSearchQuery = it },
                        placeholder = { Text("بحث بالاسم، رقم الهوية، أو المنطقة...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = PalestineGreen) },
                        trailingIcon = {
                            if (manualSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { manualSearchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "مسح")
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 2. UI Layout Middle (NEW): شريط التبويبات الفئوية الجغرافية مع العدادات
                    val activeTabIndex = directoryTabs.indexOfFirst { it.first == selectedDirectoryTab }.coerceAtLeast(0)
                    ScrollableTabRow(
                        selectedTabIndex = activeTabIndex,
                        edgePadding = 4.dp,
                        containerColor = Color.Transparent,
                        contentColor = PalestineGreen,
                        divider = {}
                    ) {
                        directoryTabs.forEachIndexed { index, (tabName, count) ->
                            val isSelected = activeTabIndex == index
                            Tab(
                                selected = isSelected,
                                onClick = { selectedDirectoryTab = tabName },
                                text = {
                                    Text(
                                        text = "$tabName ($count)",
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        color = if (isSelected) PalestineGreen else SlateTextMuted
                                    )
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // 3. UI Layout Bottom: القائمة المعروضة المصفاة حسب التبويب والبحث
                    val displayedDirectoryFamilies = remember(filteredFamilies, selectedNominees, manualSearchQuery, selectedDirectoryTab) {
                        val query = manualSearchQuery.trim().lowercase()
                        filteredFamilies.filter { fam ->
                            val matchesTab = if (selectedDirectoryTab == "الكل") {
                                true
                            } else {
                                fam.currentSubRegion == selectedDirectoryTab
                            }

                            val matchesSearch = query.isEmpty() ||
                                    fam.name.lowercase().contains(query) ||
                                    fam.nationalID.contains(query) ||
                                    fam.currentSubRegion.lowercase().contains(query) ||
                                    fam.primary_phone.contains(query)

                            matchesTab && matchesSearch
                        }
                    }

                    if (displayedDirectoryFamilies.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.SearchOff, contentDescription = null, tint = SlateTextMuted, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("لا توجد أسر مؤهلة مطابقة في هذا التصنيف", color = SlateTextMuted, fontSize = 13.sp)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(displayedDirectoryFamilies, key = { it.familyID }) { family ->
                                val isNominated = selectedNominees.contains(family)
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isNominated) PalestineGreen.copy(alpha = 0.08f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    ),
                                    border = if (isNominated) androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.4f)) else null,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text(text = family.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                if (isNominated) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = PalestineGreen.copy(alpha = 0.15f)
                                                    ) {
                                                        Text("مرشح بالفعل ✓", color = PalestineGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                    }
                                                }
                                            }
                                            Text(
                                                text = "هوية: ${family.nationalID} • أفراد: ${family.familyMembersCount} • المنطقة: ${family.currentSubRegion}",
                                                fontSize = 11.sp,
                                                color = SlateTextMuted
                                            )
                                        }
                                        if (isNominated) {
                                            IconButton(
                                                onClick = { nominationViewModel.removeNominee(family) },
                                                enabled = !isReadOnlyMode
                                            ) {
                                                Icon(Icons.Default.Close, contentDescription = "استبعاد", tint = PalestineRed)
                                            }
                                        } else {
                                            Button(
                                                onClick = {
                                                    nominationViewModel.addNomineeManually(family)
                                                },
                                                enabled = !isFull && !isReadOnlyMode,
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                                            ) {
                                                Text("إضافة", fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // نافذة نجاح الاعتماد الاحتفالية
        if (commitSuccessCount != null) {
            AlertDialog(
                onDismissRequest = { commitSuccessCount = null },
                icon = {
                    Icon(
                        Icons.Default.Verified,
                        contentDescription = null,
                        tint = PalestineGreen,
                        modifier = Modifier.size(54.dp)
                    )
                },
                title = {
                    Text(
                        text = "تم اعتماد وترحيل الترشيح بنجاح!",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "تم ترحيل $commitSuccessCount أسرة رسمياً إلى سجلات المساعدات للمشروع (${selectedProject?.projectName}).",
                            textAlign = TextAlign.Center,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "أصبحت الأسماء الآن جاهزة للصرف والتسليم الميداني مع الباركود والإيصالات.",
                            textAlign = TextAlign.Center,
                            fontSize = 12.sp,
                            color = SlateTextMuted
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            commitSuccessCount = null
                            onNavigateToResults()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                    ) {
                        Text("عرض النتائج وسجلات المشروع")
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { commitSuccessCount = null }) {
                        Text("البقاء هنا")
                    }
                }
            )
        }
    }
}

/**
 * الخطوة 0: اختيار المشروع المفتوح حصراً (Step 0: Project Selection)
 */
@Composable
fun Step0ProjectSelection(
    openProjects: List<ProjectEntity>,
    allProjects: List<ProjectEntity>,
    selectedProject: ProjectEntity?,
    visibleTargetQuota: Int,
    projectRegionalQuotas: Map<Long, Int>,
    alreadyNominatedCount: Int,
    remainingQuota: Int,
    isGeoRestrictedUser: Boolean,
    scopeLabel: String,
    isReadOnlyMode: Boolean,
    onSelectProject: (ProjectEntity) -> Unit,
    onNext: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "الخطوة الأولى: اختيار المشروع الإنساني المستهدف",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "تقتصر عمليات الترشيح العملياتية فقط على المشاريع المفتوحة النشطة (isOpen == true).",
                style = MaterialTheme.typography.bodySmall,
                color = SlateTextMuted
            )
        }

        if (openProjects.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = PalestineRed, modifier = Modifier.size(36.dp))
                        Text(
                            text = "لا توجد حالياً مشاريع مفتوحة للترشيح",
                            fontWeight = FontWeight.Bold,
                            color = PalestineRed
                        )
                        Text(
                            text = "كافة المشاريع مغلقة أو مكتملة. يرجى من مدير النظام (Admin) فتح أو طرح مشروع جديد من شاشة إدارة المشاريع.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF991B1B)
                        )
                    }
                }
            }
        } else {
            item {
                Text(
                    text = "المشاريع المتاحة للترشيح:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            items(openProjects, key = { it.projectID }) { project ->
                val isSelected = selectedProject?.projectID == project.projectID
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectProject(project) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) PalestineGreen.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        if (isSelected) 2.dp else 1.dp,
                        if (isSelected) PalestineGreen else SlateBorder
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = project.projectName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isSelected) PalestineGreen else MaterialTheme.colorScheme.onSurface
                                )
                                if (isSelected) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "رقم: ${project.projectNumber} • المانح: ${project.fundingInstitution}",
                                fontSize = 12.sp,
                                color = SlateTextMuted
                            )
                            val regionalQuotaForCard = projectRegionalQuotas[project.projectID] ?: if (isSelected) visibleTargetQuota else 0
                            Text(
                                text = if (isGeoRestrictedUser) {
                                    "العدد المخصص لمنطقتك: $regionalQuotaForCard • المخزن: ${project.warehouseName}"
                                } else {
                                    "الحصة المستهدفة: ${project.targetQuota} أسرة • المخزن: ${project.warehouseName}"
                                },
                                fontSize = 11.sp,
                                color = PalestineGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        RadioButton(
                            selected = isSelected,
                            onClick = { onSelectProject(project) },
                            colors = RadioButtonDefaults.colors(selectedColor = PalestineGreen)
                        )
                    }
                }
            }
        }

        // تفاصيل المشروع المختار وزر المتابعة
        selectedProject?.let { prj ->
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = PalestineGreen)
                            Text("ملخص المشروع المختار", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Divider(color = SlateBorder)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الاسم:", color = SlateTextMuted, fontSize = 12.sp)
                            Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (isGeoRestrictedUser) "العدد المخصص لمنطقتك:" else "الحصة الكلية:", color = SlateTextMuted, fontSize = 12.sp)
                            Text(
                                text = "${if (isGeoRestrictedUser) visibleTargetQuota else prj.targetQuota} مستفيد",
                                fontWeight = FontWeight.Bold,
                                color = PalestineGreen,
                                fontSize = 12.sp
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (remainingQuota <= 0) PalestineRed.copy(alpha = 0.10f) else PalestineGreen.copy(alpha = 0.10f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "تم ترشيح ($alreadyNominatedCount) سابقاً | المتبقي للترشيح: ($remainingQuota)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (remainingQuota <= 0) PalestineRed else PalestineGreen,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الجهة المانحة:", color = SlateTextMuted, fontSize = 12.sp)
                            Text(prj.fundingInstitution, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

/**
 * الخطوة 1: محرك الفلاتر الديناميكي الفائق (Step 1: Super Dynamic Filter Engine)
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun Step1SuperDynamicFilters(
    filteredFamiliesCount: Int,
    residencyStatusOptions: List<String>,
    selectedResidencyStatus: String?,
    onSelectResidencyStatus: (String?) -> Unit,
    isSubmitEnabled: Boolean,
    onStartNomination: () -> Unit,
    shelterOptions: List<String>,
    worksApprovalOptions: List<String>,
    damageOptions: List<String>,
    aidCategoryOptions: List<String>,
    maritalStatusOptions: List<String>,
    shelterChips: Map<String, ChipFilterState>,
    worksApprovalChips: Map<String, ChipFilterState>,
    damageChips: Map<String, ChipFilterState>,
    aidCategoryChips: Map<String, ChipFilterState>,
    selectedMaritalStatuses: List<String>,
    excludeMaritalStatuses: Boolean,
    shelterFilterEnabled: Boolean,
    worksApprovalFilterEnabled: Boolean,
    damageFilterEnabled: Boolean,
    incomeFilterEnabled: Boolean,
    aidCategoryFilterEnabled: Boolean,
    maritalStatusFilterEnabled: Boolean,
    workStatusFilter: String,
    onToggleShelterEnabled: (Boolean) -> Unit,
    onToggleWorksApprovalEnabled: (Boolean) -> Unit,
    onToggleDamageEnabled: (Boolean) -> Unit,
    onToggleIncomeEnabled: (Boolean) -> Unit,
    onToggleAidCategoryEnabled: (Boolean) -> Unit,
    onToggleMaritalStatusEnabled: (Boolean) -> Unit,
    onToggleMaritalStatusOption: (String) -> Unit,
    onToggleExcludeMaritalStatuses: (Boolean) -> Unit,
    onClearMaritalStatuses: () -> Unit,
    onSelectWorkStatusFilter: (String) -> Unit,
    hasChildrenOnly: Boolean,
    minChildAgeText: String,
    maxChildAgeText: String,
    onToggleChildrenEnabled: (Boolean) -> Unit,
    onMinChildAgeChange: (String) -> Unit,
    onMaxChildAgeChange: (String) -> Unit,
    exclusionMode: ExclusionMode,
    exclusionDays: String,
    exclusionDateCutoff: String,
    minFamilyMembers: Int,
    onCycleChip: (String, String) -> Unit,
    onSetExclusionMode: (ExclusionMode) -> Unit,
    onSetExclusionDays: (String) -> Unit,
    onOpenDatePicker: () -> Unit,
    onSetMinMembers: (Int) -> Unit,
    onResetFilters: () -> Unit,
    localityOptions: List<String> = emptyList(),
    selectedLocalitiesFilter: Set<String> = emptySet(),
    isLocalityLocked: Boolean = false,
    lockedLocalityName: String? = null,
    canViewAllLocalities: Boolean = true,
    onToggleLocalityFilter: (String) -> Unit = {},
    onClearLocalitiesFilter: () -> Unit = {},
    branchOptions: List<String> = emptyList(),
    selectedBranchesFilter: Set<String> = emptySet(),
    isBranchLocked: Boolean = false,
    lockedBranchName: String? = null,
    canViewAllBranches: Boolean = true,
    onToggleBranchFilter: (String) -> Unit = {},
    onClearBranchesFilter: () -> Unit = {}
) {
    var localityMenuExpanded by remember { mutableStateOf(false) }
    var branchMenuExpanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFE6F7F0),
                        Color(0xFFEBF5FF),
                        Color(0xFFF3F6FB),
                        Color(0xFFF8FAFC)
                    )
                )
            )
    ) {
        // هالات إضاءة خلفية ناعمة لإبراز شفافية البطاقات الزجاجية
        Box(
            modifier = Modifier
                .size(220.dp)
                .align(Alignment.TopStart)
                .offset(x = (-60).dp, y = (-40).dp)
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0x3310B981),
                            Color.Transparent
                        )
                    )
                )
        )
        Box(
            modifier = Modifier
                .size(260.dp)
                .align(Alignment.BottomEnd)
                .offset(x = 70.dp, y = 60.dp)
                .clip(CircleShape)
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0x2E0284C7),
                            Color.Transparent
                        )
                    )
                )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // شريط العداد الحي للأسر المطابقة للشروط
            item {
                GlassFilterCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            FilterHeaderBadge(
                                icon = Icons.Default.Groups,
                                accentColor = Color(0xFF10B981)
                            )
                            Column {
                                Text(
                                    text = "الأسر المطابقة لمعايير الترشيح",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = SlateTextPrimary
                                )
                                Text(
                                    text = if (selectedResidencyStatus.isNullOrBlank()) {
                                        "يرجى اختيار صفة الإقامة أدناه (اعتماد التنمية مطبق تلقائياً)"
                                    } else {
                                        "صفة الإقامة: $selectedResidencyStatus • اعتماد التنمية مطبق تلقائياً"
                                    },
                                    fontSize = 11.sp,
                                    color = if (selectedResidencyStatus.isNullOrBlank()) Color(0xFFB45309) else SlateTextMuted
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFF10B981).copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.35f))
                        ) {
                            Text(
                                text = "$filteredFamiliesCount أسرة",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = Color(0xFF047857),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // 0. الشرط الإلزامي الوحيد في الواجهة: صفة الإقامة الديناميكية (Residency Status)
            item {
                val hasSelection = !selectedResidencyStatus.isNullOrBlank()
                val accentColor = if (hasSelection) Color(0xFF10B981) else Color(0xFFD97706)
                GlassFilterCard(modifier = Modifier.animateContentSize()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            FilterHeaderBadge(
                                icon = if (hasSelection) Icons.Default.VerifiedUser else Icons.Default.Badge,
                                accentColor = accentColor
                            )
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "صفة الإقامة (Residency Status)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = SlateTextPrimary
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (hasSelection) Color(0xFF10B981).copy(alpha = 0.15f) else PalestineRed.copy(alpha = 0.12f)
                                    ) {
                                        Text(
                                            text = "إلزامي *",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (hasSelection) Color(0xFF047857) else PalestineRed,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = if (hasSelection) {
                                        "تم تحديد ($selectedResidencyStatus) • جميع الفلاتر الأخرى اختيارية"
                                    } else {
                                        "الشرط الوحيد الإلزامي لتفعيل زر بدء الترشيح"
                                    },
                                    fontSize = 11.sp,
                                    color = accentColor,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        if (hasSelection) {
                            TextButton(
                                onClick = { onSelectResidencyStatus(null) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text(
                                    text = "مسح",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PalestineRed
                                )
                            }
                        }
                    }

                    if (residencyStatusOptions.isEmpty()) {
                        Text(
                            text = "جاري تحميل خيارات صفة الإقامة من قاعدة البيانات...",
                            fontSize = 12.sp,
                            color = SlateTextMuted
                        )
                    } else {
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            residencyStatusOptions.forEach { option ->
                                val isSelected = selectedResidencyStatus.equals(option, ignoreCase = true)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        onSelectResidencyStatus(if (isSelected) null else option)
                                    },
                                    label = {
                                        Text(
                                            text = option,
                                            fontSize = 13.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    },
                                    leadingIcon = if (isSelected) {
                                        {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    } else null,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = FilterChipDefaults.filterChipColors(
                                        containerColor = Color.White.copy(alpha = 0.55f),
                                        labelColor = SlateTextPrimary,
                                        selectedContainerColor = Color(0xFF10B981),
                                        selectedLabelColor = Color.White,
                                        selectedLeadingIconColor = Color.White
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = isSelected,
                                        borderColor = if (isSelected) Color(0xFF10B981) else Color.White.copy(alpha = 0.85f),
                                        selectedBorderColor = Color(0xFF10B981),
                                        borderWidth = 1.dp,
                                        selectedBorderWidth = 1.dp
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // بطاقة العزل والنطاق الجغرافي الموحدة (اختيار متعدد للمحليات والشعب الميدانية مع الأقفال)
            if (localityOptions.isNotEmpty() || branchOptions.isNotEmpty() || isLocalityLocked || isBranchLocked) {
                item {
                    val locDisplay = lockedLocalityName
                        ?: when {
                            selectedLocalitiesFilter.isEmpty() ->
                                if (canViewAllLocalities) "جميع المحليات" else localityOptions.firstOrNull() ?: "غير محدد"
                            selectedLocalitiesFilter.size == 1 -> selectedLocalitiesFilter.first()
                            else -> "${selectedLocalitiesFilter.size} محليات مختارة"
                        }
                    val branchDisplay = lockedBranchName
                        ?: when {
                            selectedBranchesFilter.isEmpty() ->
                                if (canViewAllBranches) "جميع الشعب" else "كافة الشعب المصرح بها"
                            selectedBranchesFilter.size == 1 -> selectedBranchesFilter.first()
                            else -> "${selectedBranchesFilter.size} شعب مختارة"
                        }

                    GlassFilterCard {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                FilterHeaderBadge(
                                    icon = Icons.Default.Public,
                                    accentColor = Color(0xFF0284C7)
                                )
                                Column {
                                    Text(
                                        text = "النطاق الجغرافي للترشيح",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = SlateTextPrimary
                                    )
                                    Text(
                                        text = "المحلية والشعبة الميدانية",
                                        fontSize = 11.sp,
                                        color = SlateTextMuted
                                    )
                                }
                            }
                            if ((!isLocalityLocked && canViewAllLocalities && selectedLocalitiesFilter.isNotEmpty()) ||
                                (!isBranchLocked && selectedBranchesFilter.isNotEmpty())
                            ) {
                                TextButton(
                                    onClick = {
                                        if (!isLocalityLocked && canViewAllLocalities) onClearLocalitiesFilter()
                                        if (!isBranchLocked) onClearBranchesFilter()
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text("تحديد الكل", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0284C7))
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            ExposedDropdownMenuBox(
                                expanded = localityMenuExpanded && !isLocalityLocked,
                                onExpandedChange = { if (!isLocalityLocked) localityMenuExpanded = !localityMenuExpanded },
                                modifier = Modifier.weight(1f)
                            ) {
                                OutlinedTextField(
                                    value = locDisplay,
                                    onValueChange = {},
                                    readOnly = true,
                                    enabled = !isLocalityLocked,
                                    singleLine = true,
                                    label = { Text(if (isLocalityLocked) "المحلية (مقفلة)" else "المحليات (متعدد)", fontSize = 11.sp) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = if (isLocalityLocked) Icons.Default.Lock else Icons.Default.LocationOn,
                                            contentDescription = null,
                                            tint = if (isLocalityLocked) Color(0xFFB45309) else Color(0xFF10B981),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    },
                                    trailingIcon = {
                                        if (!isLocalityLocked) ExposedDropdownMenuDefaults.TrailingIcon(expanded = localityMenuExpanded)
                                    },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color.White.copy(alpha = 0.6f),
                                        unfocusedContainerColor = Color.White.copy(alpha = 0.5f),
                                        disabledContainerColor = Color.White.copy(alpha = 0.35f),
                                        focusedBorderColor = Color(0xFF10B981),
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.9f)
                                    ),
                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    textStyle = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                                )
                                if (!isLocalityLocked) {
                                    ExposedDropdownMenu(
                                        expanded = localityMenuExpanded,
                                        onDismissRequest = { localityMenuExpanded = false }
                                    ) {
                                        if (canViewAllLocalities) {
                                            val allSelected = selectedLocalitiesFilter.isEmpty()
                                            DropdownMenuItem(
                                                text = {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Checkbox(
                                                            checked = allSelected,
                                                            onCheckedChange = null,
                                                            colors = CheckboxDefaults.colors(checkedColor = PalestineGreen)
                                                        )
                                                        Text("جميع المحليات", fontWeight = FontWeight.Bold)
                                                    }
                                                },
                                                onClick = { onClearLocalitiesFilter() }
                                            )
                                        }
                                        localityOptions.forEach { loc ->
                                            val isChecked = selectedLocalitiesFilter.any { it.equals(loc, ignoreCase = true) }
                                            DropdownMenuItem(
                                                text = {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Checkbox(
                                                            checked = isChecked,
                                                            onCheckedChange = null,
                                                            colors = CheckboxDefaults.colors(checkedColor = PalestineGreen)
                                                        )
                                                        Text(loc, fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal)
                                                    }
                                                },
                                                onClick = { onToggleLocalityFilter(loc) }
                                            )
                                        }
                                        HorizontalDivider()
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    "تم (${if (selectedLocalitiesFilter.isEmpty()) "الكل" else selectedLocalitiesFilter.size})",
                                                    fontWeight = FontWeight.Bold,
                                                    color = PalestineGreen,
                                                    modifier = Modifier.fillMaxWidth(),
                                                    textAlign = TextAlign.Center
                                                )
                                            },
                                            onClick = { localityMenuExpanded = false }
                                        )
                                    }
                                }
                            }

                            ExposedDropdownMenuBox(
                                expanded = branchMenuExpanded && !isBranchLocked,
                                onExpandedChange = {
                                    if (!isBranchLocked && branchOptions.isNotEmpty()) {
                                        branchMenuExpanded = !branchMenuExpanded
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                OutlinedTextField(
                                    value = branchDisplay,
                                    onValueChange = {},
                                    readOnly = true,
                                    enabled = !isBranchLocked && branchOptions.isNotEmpty(),
                                    singleLine = true,
                                    label = { Text(if (isBranchLocked) "الشعبة (مقفلة)" else "الشعب (متعدد)", fontSize = 11.sp) },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = if (isBranchLocked) Icons.Default.Lock else Icons.Default.AccountTree,
                                            contentDescription = null,
                                            tint = if (isBranchLocked) Color(0xFFB45309) else Color(0xFF0284C7),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    },
                                    trailingIcon = {
                                        if (!isBranchLocked && branchOptions.isNotEmpty()) {
                                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = branchMenuExpanded)
                                        }
                                    },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color.White.copy(alpha = 0.6f),
                                        unfocusedContainerColor = Color.White.copy(alpha = 0.5f),
                                        disabledContainerColor = Color.White.copy(alpha = 0.35f),
                                        focusedBorderColor = Color(0xFF0284C7),
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.9f)
                                    ),
                                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    textStyle = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                                )
                                if (!isBranchLocked && branchOptions.isNotEmpty()) {
                                    ExposedDropdownMenu(
                                        expanded = branchMenuExpanded,
                                        onDismissRequest = { branchMenuExpanded = false }
                                    ) {
                                        val allBranchesSelected = selectedBranchesFilter.isEmpty()
                                        DropdownMenuItem(
                                            text = {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Checkbox(
                                                        checked = allBranchesSelected,
                                                        onCheckedChange = null,
                                                        colors = CheckboxDefaults.colors(checkedColor = Color(0xFF0284C7))
                                                    )
                                                    Text(
                                                        if (canViewAllBranches) "جميع الشعب" else "كافة الشعب المصرح بها",
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            },
                                            onClick = { onClearBranchesFilter() }
                                        )
                                        branchOptions.forEach { br ->
                                            val isChecked = selectedBranchesFilter.any { it.equals(br, ignoreCase = true) }
                                            DropdownMenuItem(
                                                text = {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Checkbox(
                                                            checked = isChecked,
                                                            onCheckedChange = null,
                                                            colors = CheckboxDefaults.colors(checkedColor = Color(0xFF0284C7))
                                                        )
                                                        Text(br, fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal)
                                                    }
                                                },
                                                onClick = { onToggleBranchFilter(br) }
                                            )
                                        }
                                        HorizontalDivider()
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    "تم (${if (selectedBranchesFilter.isEmpty()) "الكل" else selectedBranchesFilter.size})",
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF0284C7),
                                                    modifier = Modifier.fillMaxWidth(),
                                                    textAlign = TextAlign.Center
                                                )
                                            },
                                            onClick = { branchMenuExpanded = false }
                                        )
                                    }
                                }
                            }
                        }

                        if ((!isLocalityLocked && selectedLocalitiesFilter.isNotEmpty()) ||
                            (!isBranchLocked && selectedBranchesFilter.isNotEmpty())
                        ) {
                            FlowRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (!isLocalityLocked) {
                                    selectedLocalitiesFilter.sorted().forEach { loc ->
                                        val canRemove = canViewAllLocalities || selectedLocalitiesFilter.size > 1
                                        InputChip(
                                            selected = true,
                                            onClick = { if (canRemove) onToggleLocalityFilter(loc) },
                                            label = { Text("محلية: $loc", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                                            trailingIcon = if (canRemove) {
                                                {
                                                    Icon(
                                                        imageVector = Icons.Default.Close,
                                                        contentDescription = null,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            } else null,
                                            shape = RoundedCornerShape(12.dp),
                                            colors = InputChipDefaults.inputChipColors(
                                                selectedContainerColor = Color(0xFF10B981),
                                                selectedLabelColor = Color.White,
                                                selectedTrailingIconColor = Color.White
                                            )
                                        )
                                    }
                                }
                                if (!isBranchLocked) {
                                    selectedBranchesFilter.sorted().forEach { br ->
                                        InputChip(
                                            selected = true,
                                            onClick = { onToggleBranchFilter(br) },
                                            label = { Text("شعبة: $br", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                                            trailingIcon = {
                                                Icon(
                                                    imageVector = Icons.Default.Close,
                                                    contentDescription = null,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = InputChipDefaults.inputChipColors(
                                                selectedContainerColor = Color(0xFF0284C7),
                                                selectedLabelColor = Color.White,
                                                selectedTrailingIconColor = Color.White
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // دليل حالات الشرائح ومفاتيح التجاوز (فلاتر اختيارية)
            item {
                GlassFilterCard {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "الفلاتر الاختيارية (Optional) • تركها فارغة لا يمنع بدء الترشيح:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SlateTextSecondary
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("انقر للتبديل:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SlateTextPrimary)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(modifier = Modifier.size(10.dp).background(Color(0xFF10B981), CircleShape))
                            Text("تضمين [✓]", fontSize = 10.sp, color = Color(0xFF047857), fontWeight = FontWeight.Bold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(modifier = Modifier.size(10.dp).background(Color(0xFFEF4444), CircleShape))
                            Text("استثناء [✕]", fontSize = 10.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.ToggleOn, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                            Text("تجاوز", fontSize = 10.sp, color = SlateTextSecondary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 1. فلتر حالة اعتماد الأشغال (Works Approval Status) مع مفتاح التجاوز
            item {
                FilterCategorySection(
                    title = "حالة اعتماد الأشغال (Works Approval)",
                    options = worksApprovalOptions,
                    chipStates = worksApprovalChips,
                    isEnabled = worksApprovalFilterEnabled,
                    onToggleEnabled = onToggleWorksApprovalEnabled,
                    onChipClick = { onCycleChip("worksApproval", it) },
                    icon = Icons.Default.Engineering,
                    iconTint = Color(0xFF0284C7)
                )
            }

            // 2. فلتر حالة الإيواء (Shelter Status) مع مفتاح التجاوز
            item {
                FilterCategorySection(
                    title = "حالة الإيواء ومراكز النزوح (Shelter)",
                    options = shelterOptions,
                    chipStates = shelterChips,
                    isEnabled = shelterFilterEnabled,
                    onToggleEnabled = onToggleShelterEnabled,
                    onChipClick = { onCycleChip("shelter", it) },
                    icon = Icons.Default.HomeWork,
                    iconTint = Color(0xFF0F766E)
                )
            }

            // 3. فلتر نوع الضرر (Damage Types) مع مفتاح التجاوز
            item {
                FilterCategorySection(
                    title = "حالة أضرار الحرب والمنازل (Damage)",
                    options = damageOptions,
                    chipStates = damageChips,
                    isEnabled = damageFilterEnabled,
                    onToggleEnabled = onToggleDamageEnabled,
                    onChipClick = { onCycleChip("damage", it) },
                    icon = Icons.Default.DomainDisabled,
                    iconTint = Color(0xFFD97706)
                )
            }

            // 3.5 فلتر الحالة الاجتماعية (Marital Status) بتصميم زجاجي مع تعدد الاختيار ومفتاح الاستثناء
            item {
                MaritalStatusFilterSection(
                    options = maritalStatusOptions,
                    selectedStatuses = selectedMaritalStatuses,
                    excludeSelected = excludeMaritalStatuses,
                    isEnabled = maritalStatusFilterEnabled,
                    onToggleEnabled = onToggleMaritalStatusEnabled,
                    onToggleOption = onToggleMaritalStatusOption,
                    onExcludeChange = onToggleExcludeMaritalStatuses,
                    onClear = onClearMaritalStatuses
                )
            }

            // 4. فلتر شرط وجود الأبناء ونطاق الأعمار (Children & Age Range Filter) مع مفتاح التجاوز
            item {
                GlassFilterCard(modifier = Modifier.animateContentSize()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            FilterHeaderBadge(
                                icon = Icons.Default.ChildCare,
                                accentColor = Color(0xFF0284C7)
                            )
                            Column {
                                Text(
                                    text = "شرط وجود الأبناء ونطاق الأعمار",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = SlateTextPrimary
                                )
                                Text(
                                    text = "فلترة الأسر التي لديها أبناء في نطاق عمري محدد",
                                    fontSize = 11.sp,
                                    color = SlateTextMuted
                                )
                            }
                        }
                        Switch(
                            checked = hasChildrenOnly,
                            onCheckedChange = onToggleChildrenEnabled,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF10B981),
                                uncheckedThumbColor = SlateTextMuted,
                                uncheckedTrackColor = SlateBorder
                            ),
                            modifier = Modifier.scale(0.85f)
                        )
                    }

                    AnimatedVisibility(
                        visible = hasChildrenOnly,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("نطاق عمر الابن (بالسنوات):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = SlateTextMuted)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                OutlinedTextField(
                                    value = minChildAgeText,
                                    onValueChange = { onMinChildAgeChange(it.filter { c -> c.isDigit() }) },
                                    label = { Text("من عمر (اختياري)") },
                                    placeholder = { Text("0") },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color.White.copy(alpha = 0.6f),
                                        unfocusedContainerColor = Color.White.copy(alpha = 0.5f),
                                        focusedBorderColor = Color(0xFF0284C7),
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.9f)
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(14.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                )
                                OutlinedTextField(
                                    value = maxChildAgeText,
                                    onValueChange = { onMaxChildAgeChange(it.filter { c -> c.isDigit() }) },
                                    label = { Text("إلى عمر (اختياري)") },
                                    placeholder = { Text("18") },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = Color.White.copy(alpha = 0.6f),
                                        unfocusedContainerColor = Color.White.copy(alpha = 0.5f),
                                        focusedBorderColor = Color(0xFF0284C7),
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.9f)
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(14.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                )
                            }
                        }
                    }
                }
            }

            // 5. فلتر حالة العمل المنطقي الذكي (الكل / يعمل (لديه دخل) / لا يعمل (بدون دخل)) بتصميم زجاجي
            item {
                WorkStatusFilterSection(
                    selectedOption = workStatusFilter,
                    isEnabled = incomeFilterEnabled,
                    onToggleEnabled = onToggleIncomeEnabled,
                    onSelectOption = onSelectWorkStatusFilter
                )
            }

            // 6. فلتر نوع المساعدة السابقة الديناميكي 100% من SQLite (تضمين / استثناء) مع مفتاح التجاوز
            item {
                FilterCategorySection(
                    title = "فلتر نوع المساعدة السابقة",
                    options = aidCategoryOptions,
                    chipStates = aidCategoryChips,
                    isEnabled = aidCategoryFilterEnabled,
                    onToggleEnabled = onToggleAidCategoryEnabled,
                    onChipClick = { onCycleChip("aidCategory", it) },
                    emptyMessage = "لا توجد تصنيفات مساعدات مسجلة في قاعدة البيانات",
                    icon = Icons.Default.Inventory2,
                    iconTint = Color(0xFF10B981)
                )
            }

            // 7. الاستثناء الزمني المتقدم (Date Exclusion) بتصميم زجاجي
            item {
                GlassFilterCard {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterHeaderBadge(
                            icon = Icons.Default.DateRange,
                            accentColor = Color(0xFF0284C7)
                        )
                        Column {
                            Text(
                                text = "الاستثناء الزمني للمساعدات السابقة",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = SlateTextPrimary
                            )
                            Text(
                                text = "تحديد فترة منع التكرار بالأيام أو بتاريخ قاطع (Date Exclusion)",
                                fontSize = 11.sp,
                                color = SlateTextMuted
                            )
                        }
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val isDaysMode = exclusionMode == ExclusionMode.DAYS
                        FilterChip(
                            selected = isDaysMode,
                            onClick = { onSetExclusionMode(ExclusionMode.DAYS) },
                            label = {
                                Text(
                                    text = "آخر X أيام",
                                    fontSize = 12.sp,
                                    fontWeight = if (isDaysMode) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            leadingIcon = if (isDaysMode) {
                                {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                                }
                            } else null,
                            shape = RoundedCornerShape(12.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Color.White.copy(alpha = 0.55f),
                                labelColor = SlateTextPrimary,
                                selectedContainerColor = Color(0xFF0284C7),
                                selectedLabelColor = Color.White,
                                selectedLeadingIconColor = Color.White
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isDaysMode,
                                borderColor = if (isDaysMode) Color(0xFF0284C7) else Color.White.copy(alpha = 0.85f),
                                selectedBorderColor = Color(0xFF0284C7),
                                borderWidth = 1.dp,
                                selectedBorderWidth = 1.dp
                            )
                        )

                        val isDateMode = exclusionMode == ExclusionMode.DATE
                        FilterChip(
                            selected = isDateMode,
                            onClick = { onSetExclusionMode(ExclusionMode.DATE) },
                            label = {
                                Text(
                                    text = "تاريخ قاطع محدد (Calendar)",
                                    fontSize = 12.sp,
                                    fontWeight = if (isDateMode) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            leadingIcon = if (isDateMode) {
                                {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                                }
                            } else null,
                            shape = RoundedCornerShape(12.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Color.White.copy(alpha = 0.55f),
                                labelColor = SlateTextPrimary,
                                selectedContainerColor = Color(0xFF0284C7),
                                selectedLabelColor = Color.White,
                                selectedLeadingIconColor = Color.White
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isDateMode,
                                borderColor = if (isDateMode) Color(0xFF0284C7) else Color.White.copy(alpha = 0.85f),
                                selectedBorderColor = Color(0xFF0284C7),
                                borderWidth = 1.dp,
                                selectedBorderWidth = 1.dp
                            )
                        )
                    }

                    if (exclusionMode == ExclusionMode.DAYS) {
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("15", "30", "60", "90").forEach { d ->
                                val isDaySelected = exclusionDays == d
                                FilterChip(
                                    selected = isDaySelected,
                                    onClick = { onSetExclusionDays(d) },
                                    label = {
                                        Text(
                                            text = "$d يوم",
                                            fontSize = 12.sp,
                                            fontWeight = if (isDaySelected) FontWeight.Bold else FontWeight.Medium
                                        )
                                    },
                                    leadingIcon = if (isDaySelected) {
                                        {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                                        }
                                    } else null,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = FilterChipDefaults.filterChipColors(
                                        containerColor = Color.White.copy(alpha = 0.55f),
                                        labelColor = SlateTextPrimary,
                                        selectedContainerColor = Color(0xFF10B981),
                                        selectedLabelColor = Color.White,
                                        selectedLeadingIconColor = Color.White
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = isDaySelected,
                                        borderColor = if (isDaySelected) Color(0xFF10B981) else Color.White.copy(alpha = 0.85f),
                                        selectedBorderColor = Color(0xFF10B981),
                                        borderWidth = 1.dp,
                                        selectedBorderWidth = 1.dp
                                    )
                                )
                            }
                        }
                    } else {
                        Surface(
                            onClick = onOpenDatePicker,
                            shape = RoundedCornerShape(14.dp),
                            color = Color.White.copy(alpha = 0.55f),
                            border = BorderStroke(1.dp, Color(0xFF0284C7).copy(alpha = 0.45f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Default.DateRange, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (exclusionDateCutoff.isNotBlank()) "التاريخ المختار: $exclusionDateCutoff" else "فتح المفكرة لاختيار التاريخ القاطع",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0284C7),
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }

            // 8. حد أفراد الأسرة
            item {
                GlassFilterCard {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FilterHeaderBadge(
                            icon = Icons.Default.FamilyRestroom,
                            accentColor = Color(0xFF10B981)
                        )
                        Column {
                            Text(
                                text = "الحد الأدنى لعدد أفراد الأسرة",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = SlateTextPrimary
                            )
                            Text(
                                text = "$minFamilyMembers أفراد فما فوق",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF047857)
                            )
                        }
                    }
                    Slider(
                        value = minFamilyMembers.toFloat(),
                        onValueChange = { onSetMinMembers(it.toInt()) },
                        valueRange = 1f..15f,
                        steps = 13,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF10B981),
                            activeTrackColor = Color(0xFF10B981),
                            inactiveTrackColor = Color.White.copy(alpha = 0.8f)
                        )
                    )
                }
            }

            // زر بدء الترشيح الرئيسي (يعتمد تفعيله حصراً على اختيار صفة الإقامة)
            item {
                Button(
                    onClick = onStartNomination,
                    enabled = isSubmitEnabled,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .shadow(
                            elevation = if (isSubmitEnabled) 6.dp else 0.dp,
                            shape = RoundedCornerShape(18.dp),
                            ambientColor = Color(0x3310B981),
                            spotColor = Color(0x4010B981)
                        ),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF10B981),
                        disabledContainerColor = SlateBorder,
                        disabledContentColor = SlateTextMuted
                    )
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "بدء الترشيح",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

/**
 * حاوية البطاقة الزجاجية الموحدة (Glassmorphism V3.0)
 * خلفية بيضاء شبه شفافة (0.65f)، حدود مضيئة (0.8f)، زوايا دائرية 24dp وظل ناعم
 */
@Composable
private fun GlassFilterCard(
    modifier: Modifier = Modifier,
    isEnabled: Boolean = true,
    content: @Composable ColumnScope.() -> Unit
) {
    val cardShape = RoundedCornerShape(24.dp)
    Surface(
        shape = cardShape,
        color = if (isEnabled) Color.White.copy(alpha = 0.65f) else Color.White.copy(alpha = 0.42f),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.8f)),
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = if (isEnabled) 4.dp else 1.dp,
                shape = cardShape,
                clip = false,
                ambientColor = Color(0x140F172A),
                spotColor = Color(0x1E0F172A)
            )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
private fun FilterHeaderBadge(
    icon: ImageVector,
    accentColor: Color
) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(accentColor.copy(alpha = 0.14f))
            .border(1.dp, accentColor.copy(alpha = 0.28f), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(20.dp)
        )
    }
}

/**
 * مكون عرض شرائح التصنيف الواحد متعددة الحالات مع مفتاح التجاوز (Switch) بتصميم زجاجي V3.0
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FilterCategorySection(
    title: String,
    options: List<String>,
    chipStates: Map<String, ChipFilterState>,
    isEnabled: Boolean = true,
    onToggleEnabled: ((Boolean) -> Unit)? = null,
    onChipClick: (String) -> Unit,
    emptyMessage: String? = null,
    icon: ImageVector = Icons.Default.Category,
    iconTint: Color = Color(0xFF10B981)
) {
    GlassFilterCard(
        isEnabled = isEnabled,
        modifier = Modifier.animateContentSize()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                FilterHeaderBadge(
                    icon = icon,
                    accentColor = if (isEnabled) iconTint else SlateTextMuted
                )
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (isEnabled) SlateTextPrimary else SlateTextMuted
                        )
                        if (!isEnabled) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = SlateBorder.copy(alpha = 0.8f)
                            ) {
                                Text(
                                    text = "تجاوز (معطل)",
                                    fontSize = 10.sp,
                                    color = SlateTextMuted,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    val activeChipsCount = chipStates.count { it.value != ChipFilterState.UNSELECTED }
                    if (isEnabled && activeChipsCount > 0) {
                        Text(
                            text = "تم تحديد ($activeChipsCount) خيار",
                            fontSize = 11.sp,
                            color = iconTint,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            if (onToggleEnabled != null) {
                Switch(
                    checked = isEnabled,
                    onCheckedChange = onToggleEnabled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF10B981),
                        uncheckedThumbColor = SlateTextMuted,
                        uncheckedTrackColor = SlateBorder
                    ),
                    modifier = Modifier.scale(0.85f)
                )
            }
        }

        AnimatedVisibility(visible = isEnabled) {
            if (options.isEmpty() && emptyMessage != null) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.55f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.85f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = SlateTextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = emptyMessage,
                            fontSize = 12.sp,
                            color = SlateTextMuted
                        )
                    }
                }
            } else {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    options.forEach { opt ->
                        val state = chipStates[opt] ?: ChipFilterState.UNSELECTED
                        TriStateFilterChip(
                            label = opt,
                            state = state,
                            onClick = { onChipClick(opt) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * قسم فلتر الحالة الاجتماعية بتصميم زجاجي (Glassmorphism V3.0) يدعم التحديد المتعدد عبر FilterChip
 * ومفتاح تبديل "استثناء المحدد" (Exclude Selected)
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MaritalStatusFilterSection(
    options: List<String>,
    selectedStatuses: List<String>,
    excludeSelected: Boolean,
    isEnabled: Boolean = true,
    onToggleEnabled: (Boolean) -> Unit,
    onToggleOption: (String) -> Unit,
    onExcludeChange: (Boolean) -> Unit,
    onClear: () -> Unit
) {
    val activeAccent by animateColorAsState(
        targetValue = when {
            !isEnabled -> SlateTextMuted
            excludeSelected -> Color(0xFFEF4444)
            else -> Color(0xFF10B981)
        },
        label = "maritalAccent"
    )

    GlassFilterCard(
        isEnabled = isEnabled,
        modifier = Modifier.animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                FilterHeaderBadge(
                    icon = Icons.Default.People,
                    accentColor = activeAccent
                )
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "الحالة الاجتماعية (Marital Status)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (isEnabled) SlateTextPrimary else SlateTextMuted
                        )
                        if (isEnabled && selectedStatuses.isNotEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = activeAccent.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = if (excludeSelected) "استثناء (${selectedStatuses.size})" else "تضمين (${selectedStatuses.size})",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = activeAccent,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        } else if (!isEnabled) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = SlateBorder.copy(alpha = 0.8f)
                            ) {
                                Text(
                                    text = "تجاوز (معطل)",
                                    fontSize = 10.sp,
                                    color = SlateTextMuted,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = if (selectedStatuses.isEmpty()) "اختيار متعدد • اترك فارغاً لتشمل جميع الحالات"
                        else if (excludeSelected) "يتم استبعاد الحالات المحددة (NOT IN)"
                        else "يتم تضمين الحالات المحددة فقط (IN)",
                        fontSize = 11.sp,
                        color = if (selectedStatuses.isNotEmpty() && excludeSelected) Color(0xFFDC2626) else SlateTextMuted
                    )
                }
            }

            Switch(
                checked = isEnabled,
                onCheckedChange = onToggleEnabled,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Color(0xFF10B981),
                    uncheckedThumbColor = SlateTextMuted,
                    uncheckedTrackColor = SlateBorder
                ),
                modifier = Modifier.scale(0.85f)
            )
        }

        AnimatedVisibility(visible = isEnabled) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // شريط مفتاح استثناء المحدد + زر المسح
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (excludeSelected) Color(0xFFEF4444).copy(alpha = 0.10f) else Color.White.copy(alpha = 0.55f),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (excludeSelected) Color(0xFFEF4444).copy(alpha = 0.35f) else Color.White.copy(alpha = 0.85f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (excludeSelected) Icons.Default.Block else Icons.Default.FilterAlt,
                                contentDescription = null,
                                tint = if (excludeSelected) Color(0xFFEF4444) else Color(0xFF10B981),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "استثناء المحدد",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (excludeSelected) Color(0xFFDC2626) else SlateTextPrimary
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (selectedStatuses.isNotEmpty()) {
                                TextButton(
                                    onClick = onClear,
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text(
                                        text = "مسح (${selectedStatuses.size})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFEF4444)
                                    )
                                }
                            }
                            Switch(
                                checked = excludeSelected,
                                onCheckedChange = onExcludeChange,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFFEF4444),
                                    uncheckedThumbColor = Color.White,
                                    uncheckedTrackColor = SlateBorderSubtle
                                ),
                                modifier = Modifier.scale(0.85f)
                            )
                        }
                    }
                }

                // شرائح الاختيار المتعدد (FilterChip FlowRow)
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    options.forEach { statusOption ->
                        val isSelected = selectedStatuses.contains(statusOption)
                        val selectedFill = if (excludeSelected) Color(0xFFEF4444) else Color(0xFF10B981)
                        val chipBg by animateColorAsState(
                            targetValue = if (isSelected) selectedFill else Color.White.copy(alpha = 0.55f),
                            label = "maritalChipBg"
                        )
                        val chipBorder by animateColorAsState(
                            targetValue = if (isSelected) selectedFill else Color.White.copy(alpha = 0.85f),
                            label = "maritalChipBorder"
                        )
                        val chipContentColor = if (isSelected) Color.White else SlateTextPrimary

                        FilterChip(
                            selected = isSelected,
                            onClick = { onToggleOption(statusOption) },
                            label = {
                                Text(
                                    text = statusOption,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            leadingIcon = if (isSelected) {
                                {
                                    Icon(
                                        imageVector = if (excludeSelected) Icons.Default.Block else Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            } else null,
                            shape = RoundedCornerShape(12.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Color.White.copy(alpha = 0.55f),
                                labelColor = SlateTextPrimary,
                                selectedContainerColor = chipBg,
                                selectedLabelColor = chipContentColor,
                                selectedLeadingIconColor = chipContentColor
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = chipBorder,
                                selectedBorderColor = chipBorder,
                                borderWidth = 1.dp,
                                selectedBorderWidth = 1.dp
                            )
                        )
                    }
                }
            }
        }
    }
}

/**
 * قسم فلتر حالة العمل المنطقي الذكي بتصميم زجاجي (Glassmorphism V3.0)
 * يتيح الاختيار بين 3 خيارات:
 * ["الكل", "يعمل (لديه دخل)", "لا يعمل (بدون دخل)"]
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun WorkStatusFilterSection(
    selectedOption: String,
    isEnabled: Boolean = true,
    onToggleEnabled: (Boolean) -> Unit,
    onSelectOption: (String) -> Unit
) {
    val workOptions = remember {
        listOf("الكل", "يعمل (لديه دخل)", "لا يعمل (بدون دخل)")
    }

    val activeAccent by animateColorAsState(
        targetValue = when {
            !isEnabled -> SlateTextMuted
            selectedOption == "يعمل (لديه دخل)" -> Color(0xFF10B981)
            selectedOption == "لا يعمل (بدون دخل)" -> Color(0xFFD97706)
            else -> Color(0xFF0284C7)
        },
        label = "workStatusAccent"
    )

    GlassFilterCard(
        isEnabled = isEnabled,
        modifier = Modifier.animateContentSize(animationSpec = spring(stiffness = Spring.StiffnessMediumLow))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                FilterHeaderBadge(
                    icon = when (selectedOption) {
                        "لا يعمل (بدون دخل)" -> Icons.Default.WorkOff
                        else -> Icons.Default.Work
                    },
                    accentColor = activeAccent
                )
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "حالة العمل ومصدر الدخل (يعمل / لا يعمل)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (isEnabled) SlateTextPrimary else SlateTextMuted
                        )
                        if (!isEnabled) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = SlateBorder.copy(alpha = 0.8f)
                            ) {
                                Text(
                                    text = "تجاوز (معطل)",
                                    fontSize = 10.sp,
                                    color = SlateTextMuted,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        } else if (selectedOption != "الكل") {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = activeAccent.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = selectedOption,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = activeAccent,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Text(
                        text = when (selectedOption) {
                            "يعمل (لديه دخل)" -> "يشمل كل أسرة لديها مصدر دخل حقيقي في أحد الحقلين"
                            "لا يعمل (بدون دخل)" -> "يشمل الأسر التي لا تملك دخلاً في كلا الحقلين (مع تنظيف القيم الوهمية)"
                            else -> "تصفية منطقية ذكية للعمل والدخل • الافتراضي: الكل"
                        },
                        fontSize = 11.sp,
                        color = if (isEnabled && selectedOption != "الكل") activeAccent else SlateTextMuted
                    )
                }
            }

            Switch(
                checked = isEnabled,
                onCheckedChange = onToggleEnabled,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Color(0xFF10B981),
                    uncheckedThumbColor = SlateTextMuted,
                    uncheckedTrackColor = SlateBorder
                ),
                modifier = Modifier.scale(0.85f)
            )
        }

        AnimatedVisibility(visible = isEnabled) {
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                workOptions.forEach { option ->
                    val isSelected = selectedOption == option
                    val optionAccent = when (option) {
                        "يعمل (لديه دخل)" -> Color(0xFF10B981)
                        "لا يعمل (بدون دخل)" -> Color(0xFFD97706)
                        else -> Color(0xFF0284C7)
                    }
                    val chipBg by animateColorAsState(
                        targetValue = if (isSelected) optionAccent else Color.White.copy(alpha = 0.55f),
                        label = "workChipBg"
                    )
                    val chipBorder by animateColorAsState(
                        targetValue = if (isSelected) optionAccent else Color.White.copy(alpha = 0.85f),
                        label = "workChipBorder"
                    )
                    val chipTextColor = if (isSelected) Color.White else SlateTextPrimary

                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectOption(option) },
                        label = {
                            Text(
                                text = option,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        leadingIcon = if (isSelected) {
                            {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        } else null,
                        shape = RoundedCornerShape(12.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color.White.copy(alpha = 0.55f),
                            labelColor = SlateTextPrimary,
                            selectedContainerColor = chipBg,
                            selectedLabelColor = chipTextColor,
                            selectedLeadingIconColor = chipTextColor
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = chipBorder,
                            selectedBorderColor = chipBorder,
                            borderWidth = 1.dp,
                            selectedBorderWidth = 1.dp
                        )
                    )
                }
            }
        }
    }
}

/**
 * شريحة الفلترة ثلاثية الحالات (Tri-State Chip) بتصميم زجاجي V3.0
 */
@Composable
fun TriStateFilterChip(
    label: String,
    state: ChipFilterState,
    onClick: () -> Unit
) {
    val bgColor by animateColorAsState(
        targetValue = when (state) {
            ChipFilterState.UNSELECTED -> Color.White.copy(alpha = 0.55f)
            ChipFilterState.INCLUDED -> Color(0xFF10B981)
            ChipFilterState.EXCLUDED -> Color(0xFFEF4444)
        },
        label = "triChipBg"
    )
    val borderColor by animateColorAsState(
        targetValue = when (state) {
            ChipFilterState.UNSELECTED -> Color.White.copy(alpha = 0.85f)
            ChipFilterState.INCLUDED -> Color(0xFF10B981)
            ChipFilterState.EXCLUDED -> Color(0xFFEF4444)
        },
        label = "triChipBorder"
    )
    val textColor = when (state) {
        ChipFilterState.UNSELECTED -> SlateTextPrimary
        ChipFilterState.INCLUDED, ChipFilterState.EXCLUDED -> Color.White
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier.shadow(
            elevation = if (state != ChipFilterState.UNSELECTED) 2.dp else 0.dp,
            shape = RoundedCornerShape(12.dp),
            clip = false,
            ambientColor = borderColor.copy(alpha = 0.25f),
            spotColor = borderColor.copy(alpha = 0.35f)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            when (state) {
                ChipFilterState.INCLUDED -> Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                ChipFilterState.EXCLUDED -> Icon(Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                ChipFilterState.UNSELECTED -> {}
            }
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = if (state != ChipFilterState.UNSELECTED) FontWeight.Bold else FontWeight.Medium,
                color = textColor
            )
        }
    }
}

/**
 * الخطوة 2: الاختيار الهجين ولوحة الحصص (Step 2: Hybrid Selection & Quotas Dashboard)
 */
@Composable
fun Step2HybridSelectionAndQuotas(
    selectedProject: ProjectEntity?,
    isReadOnlyMode: Boolean,
    isSubmitEnabled: Boolean,
    filteredFamiliesCount: Int,
    selectedNomineesCount: Int,
    visibleTargetQuota: Int,
    alreadyNominatedCount: Int,
    remainingQuota: Int,
    isGeoRestrictedUser: Boolean,
    scopeLabel: String,
    quotaStats: List<LocalityQuotaStatsItem>,
    onAutoNominate: () -> Unit,
    onOpenManualAdd: () -> Unit,
    onClearNominees: () -> Unit
) {
    val targetQuota = if (isGeoRestrictedUser) visibleTargetQuota else (selectedProject?.targetQuota ?: 100)
    val totalCovered = alreadyNominatedCount + selectedNomineesCount
    val progress = if (targetQuota > 0) (totalCovered.toFloat() / targetQuota.toFloat()).coerceIn(0f, 1f) else 0f

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // بطاقة ملخص الحصة (معزولة بنطاق المستخدم إن كان مقيداً) والتقدم التراكمي
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isGeoRestrictedUser) "العدد المخصص لمنطقتك: $visibleTargetQuota" else "الإنجاز التراكمي / سقف الحصة",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text("المشروع: ${selectedProject?.projectName ?: "عام"} • الدفعة الحالية: $selectedNomineesCount", fontSize = 11.sp, color = SlateTextMuted)
                        }
                        Text(
                            text = "$totalCovered / $targetQuota",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = if (totalCovered >= targetQuota && targetQuota > 0) PalestineGreen else Color(0xFF2563EB)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (remainingQuota <= 0) PalestineRed.copy(alpha = 0.12f) else PalestineGreen.copy(alpha = 0.10f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "تم ترشيح ($alreadyNominatedCount) سابقاً | المتبقي للترشيح: ($remainingQuota)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (remainingQuota <= 0) PalestineRed else PalestineGreen,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = if (totalCovered >= targetQuota && targetQuota > 0) PalestineGreen else Color(0xFF2563EB),
                        trackColor = SlateBorder
                    )

                    // أزرار التحكم والترشيح الآلي/اليدوي
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onAutoNominate,
                            enabled = isSubmitEnabled && !isReadOnlyMode && filteredFamiliesCount > 0 && remainingQuota > 0,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                        ) {
                            Icon(Icons.Default.AutoMode, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ترشيح آلي عادل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onOpenManualAdd,
                            enabled = !isReadOnlyMode && selectedNomineesCount < remainingQuota,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة يدوية", fontSize = 12.sp)
                        }

                        IconButton(
                            onClick = onClearNominees,
                            enabled = !isReadOnlyMode && selectedNomineesCount > 0
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "تفريغ", tint = PalestineRed)
                        }
                    }
                }
            }
        }

        // عنوان لوحة الحصص
        item {
            Text(
                text = if (isGeoRestrictedUser) "مراجعة حصة نطاقك الجغرافي ($scopeLabel)" else "لوحة مراجعة الحصص النسبية بالمحليات (Locality Quota Review)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        // قائمة المحليات مع الحصة المحسوبة والمرشحين والعجز/الفائض
        items(quotaStats, key = { it.localityName }) { stat ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = stat.localityName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = "الأسر المؤهلة: ${stat.baseX} (${stat.formattedPercentage})",
                            fontSize = 11.sp,
                            color = SlateTextMuted
                        )
                    }

                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "الحصة: ${stat.targetQuota} • المرشحون: ${stat.nominatedCount}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )

                        // شارة العجز أو الفائض
                        val diff = stat.shortageExcess
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = when {
                                diff < 0 -> PalestineRed.copy(alpha = 0.12f)
                                diff == 0 -> PalestineGreen.copy(alpha = 0.12f)
                                else -> Color(0xFFF59E0B).copy(alpha = 0.12f)
                            }
                        ) {
                            Text(
                                text = when {
                                    diff < 0 -> "عجز: ${-diff}"
                                    diff == 0 -> "مكتمل ✓"
                                    else -> "زيادة: +$diff"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    diff < 0 -> PalestineRed
                                    diff == 0 -> PalestineGreen
                                    else -> Color(0xFFD97706)
                                },
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * الخطوة 3: المراجعة النهائية والاعتماد (Step 3: Final Review & Commit)
 */
@Composable
fun Step3FinalReviewAndCommit(
    selectedProject: ProjectEntity?,
    selectedNominees: List<FamilyEntity>,
    alreadyNominatedCount: Int,
    remainingQuota: Int,
    isReadOnlyMode: Boolean,
    onRemoveNominee: (FamilyEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("كشف المرشحين النهائي الجاهز للترحيل", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("المشروع: ${selectedProject?.projectName} • مرشحو هذه الدفعة: ${selectedNominees.size} أسرة", fontSize = 12.sp, color = PalestineGreen, fontWeight = FontWeight.Bold)
                    Text(
                        text = "تم ترشيح ($alreadyNominatedCount) سابقاً | المتبقي للترشيح: ($remainingQuota)",
                        fontSize = 11.sp,
                        color = SlateTextMuted,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (isReadOnlyMode) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = PalestineRed.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ هذا المشروع مغلق ومكتمل. لا يمكن ترحيل أو تعديل أسماء إضافية.",
                                color = PalestineRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }

        if (selectedNominees.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لم يتم اختيار أي مرشحين حتى الآن. يرجى العودة للخطوة السابقة والضغط على (ترشيح آلي عادل) أو الإضافة يدوياً.",
                        textAlign = TextAlign.Center,
                        color = SlateTextMuted,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(selectedNominees, key = { it.familyID }) { nominee ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = nominee.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "هوية: ${nominee.nationalID} • جوال: ${nominee.primary_phone} • أفراد: ${nominee.familyMembersCount}",
                                fontSize = 11.sp,
                                color = SlateTextMuted
                            )
                            Text(
                                text = "المنطقة الحالية: ${nominee.currentSubRegion} • الإيواء: ${nominee.shelterStatus}",
                                fontSize = 11.sp,
                                color = PalestineGreen
                            )
                        }

                        if (!isReadOnlyMode) {
                            IconButton(onClick = { onRemoveNominee(nominee) }) {
                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "استبعاد", tint = PalestineRed)
                            }
                        }
                    }
                }
            }
        }
    }
}
