package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.local.entities.donor
import com.humanitarian.aidmanagement.data.local.entities.isOpen
import com.humanitarian.aidmanagement.data.local.entities.targetQuota
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.ExclusionMode
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * MASTER ARCHITECTURE V3.0: THE ULTIMATE HYBRID NOMINATION SCREEN
 * شاشة الترشيح العملياتية الموحدة:
 * 1. اختيار المشروع المفتوح حصراً (isOpen == true)
 * 2. فلاتر الشرائح ثلاثية الحالات (Multi-State Chips) والاستثناء الزمني بالمفكرة
 * 3. التوزيع النسبي العادل ولوحة مراجعة الحصص (Calculated vs Nominated)
 * 4. الترشيح الهجين (آلي حتى سقف الحصة + إضافة واستبعاد يدوي)
 * 5. حماية وضع القراءة فقط، والأقفال الصارمة لمنع تجاوز سقف المشروع.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NominationScreen(
    repository: AidRepository,
    nominationViewModel: NominationViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToManualSelection: (aidTypeId: Int, projectId: Long) -> Unit,
    onNavigateToResults: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current

    // حالة المستخدم والمنطقة المخصصة (RBAC)
    val currentUser by repository.currentUserFlow.collectAsState(initial = repository.getCurrentUser())
    val userAssignedRegion = remember(currentUser) {
        val region = currentUser?.AllowedNominationSubAreas?.trim() ?: "All"
        if (region == "*" || region.isBlank()) "All" else region
    }

    LaunchedEffect(userAssignedRegion) {
        nominationViewModel.setAssignedSubRegion(userAssignedRegion)
    }

    // بيانات المشاريع والوضع العام
    val openProjects by nominationViewModel.openProjects.collectAsState()
    val allProjects by nominationViewModel.allActiveProjects.collectAsState()
    val selectedProject by nominationViewModel.selectedProject.collectAsState()
    val isReadOnlyMode by nominationViewModel.isReadOnlyMode.collectAsState()

    // تدفقات الفلاتر والحصص والمرشحين
    val filteredFamilies by nominationViewModel.filteredFamilies.collectAsState()
    val selectedNominees by nominationViewModel.selectedNominees.collectAsState()
    val localityQuotaStats by nominationViewModel.localityQuotaStats.collectAsState()

    // خيارات الفلاتر الديناميكية
    val shelterOptions by nominationViewModel.dynamicShelterOptions.collectAsState()
    val injuryOptions by nominationViewModel.dynamicInjuryOptions.collectAsState()
    val damageOptions by nominationViewModel.dynamicDamageOptions.collectAsState()
    val incomeOptions by nominationViewModel.dynamicIncomeOptions.collectAsState()
    val subAreaOptions by nominationViewModel.dynamicSubAreaOptions.collectAsState()

    // حالات الشرائح
    val shelterChips by nominationViewModel.shelterChipStates.collectAsState()
    val injuryChips by nominationViewModel.injuryChipStates.collectAsState()
    val damageChips by nominationViewModel.damageChipStates.collectAsState()
    val incomeChips by nominationViewModel.incomeChipStates.collectAsState()
    val localityChips by nominationViewModel.localityChipStates.collectAsState()

    // MISSION 1: مفاتيح تجاوز الفلاتر (Bypass Switches)
    val shelterFilterEnabled by nominationViewModel.shelterFilterEnabled.collectAsState()
    val damageFilterEnabled by nominationViewModel.damageFilterEnabled.collectAsState()
    val injuryFilterEnabled by nominationViewModel.injuryFilterEnabled.collectAsState()
    val incomeFilterEnabled by nominationViewModel.incomeFilterEnabled.collectAsState()
    val localityFilterEnabled by nominationViewModel.localityFilterEnabled.collectAsState()

    // MISSION 2: الفلتر الثنائي لمصدر الدخل (Binary Income)
    val binaryIncomeOption by nominationViewModel.binaryIncomeOption.collectAsState()

    // الاستثناء الزمني
    val exclusionMode by nominationViewModel.exclusionMode.collectAsState()
    val exclusionDays by nominationViewModel.exclusionDaysText.collectAsState()
    val exclusionDateCutoff by nominationViewModel.exclusionDateCutoffText.collectAsState()
    val minFamilyMembers by nominationViewModel.minFamilyMembers.collectAsState()

    // خطوات المعالج (0: المشروع، 1: الفلاتر، 2: الحصص والاختيار، 3: المراجعة والاعتماد)
    var currentStep by remember { mutableIntStateOf(0) }

    // BottomSheet للإضافة اليدوية
    var showManualAddSheet by remember { mutableStateOf(false) }
    var manualSearchQuery by remember { mutableStateOf("") }

    // حوار التقويم لاختيار تاريخ محدد (DatePickerDialog)
    var showDatePickerDialog by remember { mutableStateOf(false) }

    // حالة إشعار أو رسالة نتيجة الاعتماد
    var commitSuccessCount by remember { mutableStateOf<Int?>(null) }
    var isCommitting by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "محرك الترشيح الهجين الذكي V3.0",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (userAssignedRegion != "All") {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = PalestineGreen.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "المنطقة المخصصة: $userAssignedRegion",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PalestineGreen,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (isReadOnlyMode) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = PalestineRed.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "وضع القراءة فقط (مغلق)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = PalestineRed,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = { nominationViewModel.clearAllFilterChips() }) {
                            Icon(Icons.Default.RestartAlt, contentDescription = "إعادة ضبط", tint = PalestineGreen)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            bottomBar = {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (currentStep > 0) {
                            OutlinedButton(
                                onClick = { currentStep-- },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("السابق")
                            }
                        } else {
                            Spacer(modifier = Modifier.width(8.dp))
                        }

                        if (currentStep < 3) {
                            Button(
                                onClick = { currentStep++ },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                            ) {
                                Text("التالي")
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                        } else {
                            // زر الاعتماد والترحيل النهائي
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        isCommitting = true
                                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        val result = nominationViewModel.commitNomination()
                                        isCommitting = false
                                        result.onSuccess { count ->
                                            commitSuccessCount = count
                                        }.onFailure { err ->
                                            android.widget.Toast.makeText(context, err.message ?: "فشل الاعتماد", android.widget.Toast.LENGTH_LONG).show()
                                        }
                                    }
                                },
                                enabled = selectedNominees.isNotEmpty() && !isReadOnlyMode && !isCommitting,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                            ) {
                                if (isCommitting) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                                } else {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("اعتماد وترحيل (${selectedNominees.size} أسرة)", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
            ) {
                // شريط المراحل التفاعلي (Step Indicator)
                TabRow(
                    selectedTabIndex = currentStep,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = PalestineGreen
                ) {
                    Tab(
                        selected = currentStep == 0,
                        onClick = { currentStep = 0 },
                        text = { Text("١. المشروع", fontWeight = if (currentStep == 0) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.FolderSpecial, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = currentStep == 1,
                        onClick = { currentStep = 1 },
                        text = { Text("٢. الفلاتر", fontWeight = if (currentStep == 1) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = currentStep == 2,
                        onClick = { currentStep = 2 },
                        text = { Text("٣. الحصص", fontWeight = if (currentStep == 2) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.PieChart, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                    Tab(
                        selected = currentStep == 3,
                        onClick = { currentStep = 3 },
                        text = { Text("٤. المراجعة", fontWeight = if (currentStep == 3) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) },
                        icon = { Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    )
                }

                // محتوى الخطوات مع الانتقال الحركي السلس
                AnimatedContent(
                    targetState = currentStep,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(slideOutHorizontally { width -> width } + fadeOut())
                        } else {
                            (slideInHorizontally { width -> width } + fadeIn()).togetherWith(slideOutHorizontally { width -> -width } + fadeOut())
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { step ->
                    when (step) {
                        0 -> Step0ProjectSelection(
                            openProjects = openProjects,
                            allProjects = allProjects,
                            selectedProject = selectedProject,
                            isReadOnlyMode = isReadOnlyMode,
                            onSelectProject = { nominationViewModel.selectedProject.value = it },
                            onNext = { currentStep = 1 }
                        )
                        1 -> Step1SuperDynamicFilters(
                            filteredFamiliesCount = filteredFamilies.size,
                            shelterOptions = shelterOptions,
                            injuryOptions = injuryOptions,
                            damageOptions = damageOptions,
                            incomeOptions = incomeOptions,
                            subAreaOptions = subAreaOptions,
                            shelterChips = shelterChips,
                            injuryChips = injuryChips,
                            damageChips = damageChips,
                            incomeChips = incomeChips,
                            localityChips = localityChips,
                            shelterFilterEnabled = shelterFilterEnabled,
                            damageFilterEnabled = damageFilterEnabled,
                            injuryFilterEnabled = injuryFilterEnabled,
                            incomeFilterEnabled = incomeFilterEnabled,
                            localityFilterEnabled = localityFilterEnabled,
                            binaryIncomeOption = binaryIncomeOption,
                            onToggleShelterEnabled = { nominationViewModel.setShelterFilterEnabled(it) },
                            onToggleDamageEnabled = { nominationViewModel.setDamageFilterEnabled(it) },
                            onToggleInjuryEnabled = { nominationViewModel.setInjuryFilterEnabled(it) },
                            onToggleIncomeEnabled = { nominationViewModel.setIncomeFilterEnabled(it) },
                            onToggleLocalityEnabled = { nominationViewModel.setLocalityFilterEnabled(it) },
                            onSelectBinaryIncomeOption = { nominationViewModel.toggleBinaryIncomeOption(it) },
                            exclusionMode = exclusionMode,
                            exclusionDays = exclusionDays,
                            exclusionDateCutoff = exclusionDateCutoff,
                            minFamilyMembers = minFamilyMembers,
                            onCycleChip = { cat, key -> nominationViewModel.cycleChipState(cat, key) },
                            onSetExclusionMode = { nominationViewModel.exclusionMode.value = it },
                            onSetExclusionDays = { nominationViewModel.exclusionDaysText.value = it },
                            onOpenDatePicker = { showDatePickerDialog = true },
                            onSetMinMembers = { nominationViewModel.minFamilyMembers.value = it },
                            onResetFilters = { nominationViewModel.clearAllFilterChips() }
                        )
                        2 -> Step2HybridSelectionAndQuotas(
                            selectedProject = selectedProject,
                            isReadOnlyMode = isReadOnlyMode,
                            filteredFamiliesCount = filteredFamilies.size,
                            selectedNomineesCount = selectedNominees.size,
                            quotaStats = localityQuotaStats,
                            onAutoNominate = { nominationViewModel.runAutoNomination() },
                            onOpenManualAdd = { showManualAddSheet = true },
                            onClearNominees = { nominationViewModel.clearNominees() }
                        )
                        3 -> Step3FinalReviewAndCommit(
                            selectedProject = selectedProject,
                            selectedNominees = selectedNominees.toList(),
                            isReadOnlyMode = isReadOnlyMode,
                            onRemoveNominee = { nominationViewModel.removeNominee(it) }
                        )
                    }
                }
            }
        }

        // نافذة مفكرة التاريخ (Material 3 DatePicker)
        if (showDatePickerDialog) {
            val datePickerState = rememberDatePickerState()
            DatePickerDialog(
                onDismissRequest = { showDatePickerDialog = false },
                confirmButton = {
                    TextButton(
                        onClick = {
                            val selectedMillis = datePickerState.selectedDateMillis
                            if (selectedMillis != null) {
                                val cal = Calendar.getInstance().apply { timeInMillis = selectedMillis }
                                val formatted = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
                                nominationViewModel.exclusionDateCutoffText.value = formatted
                            }
                            showDatePickerDialog = false
                        }
                    ) {
                        Text("تأكيد التاريخ")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDatePickerDialog = false }) {
                        Text("إلغاء")
                    }
                }
            ) {
                DatePicker(state = datePickerState)
            }
        }

        // BottomSheet للإضافة اليدوية: الدليل التفاعلي الذكي المصنف جغرافياً مع العدادات
        if (showManualAddSheet) {
            val currentProject = selectedProject
            val currentTarget = currentProject?.targetQuota ?: 0
            val isFull = selectedNominees.size >= currentTarget

            // استخراج المناطق الفرعية الحالية ديناميكياً مع حساب عدادات الأسر المؤهلة
            val distinctSubRegionsWithCounts = remember(filteredFamilies) {
                val groups = filteredFamilies.groupBy { it.currentSubRegion.ifBlank { "منطقة غير محددة" }.trim() }
                groups.map { (region, list) -> region to list.size }
                    .sortedByDescending { it.second }
            }

            val directoryTabs = remember(filteredFamilies, distinctSubRegionsWithCounts) {
                listOf("الكل" to filteredFamilies.size) + distinctSubRegionsWithCounts
            }

            var selectedDirectoryTab by remember { mutableStateOf("الكل") }

            ModalBottomSheet(
                onDismissRequest = { 
                    showManualAddSheet = false
                    manualSearchQuery = ""
                    selectedDirectoryTab = "الكل"
                },
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "دليل الإضافة اليدوية للأسر المؤهلة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "دليل تفاعلي مصنف حسب المحلية مع إحصائيات فورية",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextMuted
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isFull) PalestineRed.copy(alpha = 0.15f) else PalestineGreen.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "${selectedNominees.size} / $currentTarget مرشح",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isFull) PalestineRed else PalestineGreen,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (isFull) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = PalestineRed.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ تم استيفاء الحصة الكلية للمشروع بالكامل ($currentTarget). لا يمكن إضافة أسر جديدة قبل استبعاد أسر أخرى.",
                                color = PalestineRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 1. UI Layout Top: حقل البحث (فلتر ثانوي على القائمة)
                    OutlinedTextField(
                        value = manualSearchQuery,
                        onValueChange = { manualSearchQuery = it },
                        placeholder = { Text("بحث بالاسم، رقم الهوية، أو المنطقة...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = PalestineGreen) },
                        trailingIcon = {
                            if (manualSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { manualSearchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "مسح")
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 2. UI Layout Middle (NEW): شريط التبويبات الفئوية الجغرافية مع العدادات
                    val activeTabIndex = directoryTabs.indexOfFirst { it.first == selectedDirectoryTab }.coerceAtLeast(0)
                    ScrollableTabRow(
                        selectedTabIndex = activeTabIndex,
                        edgePadding = 4.dp,
                        containerColor = Color.Transparent,
                        contentColor = PalestineGreen,
                        divider = {}
                    ) {
                        directoryTabs.forEachIndexed { index, (tabName, count) ->
                            val isSelected = activeTabIndex == index
                            Tab(
                                selected = isSelected,
                                onClick = { selectedDirectoryTab = tabName },
                                text = {
                                    Text(
                                        text = "$tabName ($count)",
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        color = if (isSelected) PalestineGreen else SlateTextMuted
                                    )
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // 3. UI Layout Bottom: القائمة المعروضة المصفاة حسب التبويب والبحث
                    val displayedDirectoryFamilies = remember(filteredFamilies, selectedNominees, manualSearchQuery, selectedDirectoryTab) {
                        val query = manualSearchQuery.trim().lowercase()
                        filteredFamilies.filter { fam ->
                            val matchesTab = if (selectedDirectoryTab == "الكل") {
                                true
                            } else {
                                val reg = fam.currentSubRegion.ifBlank { "منطقة غير محددة" }.trim()
                                reg == selectedDirectoryTab
                            }

                            val matchesSearch = query.isEmpty() ||
                                    fam.name.lowercase().contains(query) ||
                                    fam.nationalID.contains(query) ||
                                    fam.currentSubRegion.lowercase().contains(query) ||
                                    fam.primary_phone.contains(query)

                            matchesTab && matchesSearch
                        }
                    }

                    if (displayedDirectoryFamilies.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.SearchOff, contentDescription = null, tint = SlateTextMuted, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("لا توجد أسر مؤهلة مطابقة في هذا التصنيف", color = SlateTextMuted, fontSize = 13.sp)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 420.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(displayedDirectoryFamilies, key = { it.familyID }) { family ->
                                val isNominated = selectedNominees.contains(family)
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isNominated) PalestineGreen.copy(alpha = 0.08f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    ),
                                    border = if (isNominated) androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.4f)) else null,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text(text = family.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                if (isNominated) {
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = PalestineGreen.copy(alpha = 0.15f)
                                                    ) {
                                                        Text("مرشح بالفعل ✓", color = PalestineGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                    }
                                                }
                                            }
                                            Text(
                                                text = "هوية: ${family.nationalID} • أفراد: ${family.familyMembersCount} • المنطقة: ${family.currentSubRegion}",
                                                fontSize = 11.sp,
                                                color = SlateTextMuted
                                            )
                                        }
                                        if (isNominated) {
                                            IconButton(
                                                onClick = { nominationViewModel.removeNominee(family) },
                                                enabled = !isReadOnlyMode
                                            ) {
                                                Icon(Icons.Default.Close, contentDescription = "استبعاد", tint = PalestineRed)
                                            }
                                        } else {
                                            Button(
                                                onClick = {
                                                    nominationViewModel.addNomineeManually(family)
                                                },
                                                enabled = !isFull && !isReadOnlyMode,
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                                            ) {
                                                Text("إضافة", fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // نافذة نجاح الاعتماد الاحتفالية
        if (commitSuccessCount != null) {
            AlertDialog(
                onDismissRequest = { commitSuccessCount = null },
                icon = {
                    Icon(
                        Icons.Default.Verified,
                        contentDescription = null,
                        tint = PalestineGreen,
                        modifier = Modifier.size(54.dp)
                    )
                },
                title = {
                    Text(
                        text = "تم اعتماد وترحيل الترشيح بنجاح!",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                },
                text = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "تم ترحيل $commitSuccessCount أسرة رسمياً إلى سجلات المساعدات للمشروع (${selectedProject?.projectName}).",
                            textAlign = TextAlign.Center,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "أصبحت الأسماء الآن جاهزة للصرف والتسليم الميداني مع الباركود والإيصالات.",
                            textAlign = TextAlign.Center,
                            fontSize = 12.sp,
                            color = SlateTextMuted
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            commitSuccessCount = null
                            onNavigateToResults()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                    ) {
                        Text("عرض النتائج وسجلات المشروع")
                    }
                },
                dismissButton = {
                    OutlinedButton(onClick = { commitSuccessCount = null }) {
                        Text("البقاء هنا")
                    }
                }
            )
        }
    }
}

/**
 * الخطوة 0: اختيار المشروع المفتوح حصراً (Step 0: Project Selection)
 */
@Composable
fun Step0ProjectSelection(
    openProjects: List<ProjectEntity>,
    allProjects: List<ProjectEntity>,
    selectedProject: ProjectEntity?,
    isReadOnlyMode: Boolean,
    onSelectProject: (ProjectEntity) -> Unit,
    onNext: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "الخطوة الأولى: اختيار المشروع الإنساني المستهدف",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "تقتصر عمليات الترشيح العملياتية فقط على المشاريع المفتوحة النشطة (isOpen == true).",
                style = MaterialTheme.typography.bodySmall,
                color = SlateTextMuted
            )
        }

        if (openProjects.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = PalestineRed, modifier = Modifier.size(36.dp))
                        Text(
                            text = "لا توجد حالياً مشاريع مفتوحة للترشيح",
                            fontWeight = FontWeight.Bold,
                            color = PalestineRed
                        )
                        Text(
                            text = "كافة المشاريع مغلقة أو مكتملة. يرجى من مدير النظام (Admin) فتح أو طرح مشروع جديد من شاشة إدارة المشاريع.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF991B1B)
                        )
                    }
                }
            }
        } else {
            item {
                Text(
                    text = "المشاريع المتاحة للترشيح:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            items(openProjects, key = { it.projectID }) { project ->
                val isSelected = selectedProject?.projectID == project.projectID
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectProject(project) },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) PalestineGreen.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        if (isSelected) 2.dp else 1.dp,
                        if (isSelected) PalestineGreen else SlateBorder
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = project.projectName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isSelected) PalestineGreen else MaterialTheme.colorScheme.onSurface
                                )
                                if (isSelected) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "رقم: ${project.projectNumber} • المانح: ${project.fundingInstitution}",
                                fontSize = 12.sp,
                                color = SlateTextMuted
                            )
                            Text(
                                text = "الحصة المستهدفة: ${project.targetQuota} أسرة • المخزن: ${project.warehouseName}",
                                fontSize = 11.sp,
                                color = PalestineGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        RadioButton(
                            selected = isSelected,
                            onClick = { onSelectProject(project) },
                            colors = RadioButtonDefaults.colors(selectedColor = PalestineGreen)
                        )
                    }
                }
            }
        }

        // تفاصيل المشروع المختار وزر المتابعة
        selectedProject?.let { prj ->
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = PalestineGreen)
                            Text("ملخص المشروع المختار", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Divider(color = SlateBorder)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الاسم:", color = SlateTextMuted, fontSize = 12.sp)
                            Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الحصة الكلية:", color = SlateTextMuted, fontSize = 12.sp)
                            Text("${prj.targetQuota} مستفيد", fontWeight = FontWeight.Bold, color = PalestineGreen, fontSize = 12.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("الجهة المانحة:", color = SlateTextMuted, fontSize = 12.sp)
                            Text(prj.fundingInstitution, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

/**
 * الخطوة 1: محرك الفلاتر الديناميكي الفائق (Step 1: Super Dynamic Filter Engine)
 */
@Composable
fun Step1SuperDynamicFilters(
    filteredFamiliesCount: Int,
    shelterOptions: List<String>,
    injuryOptions: List<String>,
    damageOptions: List<String>,
    incomeOptions: List<String>,
    subAreaOptions: List<String>,
    shelterChips: Map<String, ChipFilterState>,
    injuryChips: Map<String, ChipFilterState>,
    damageChips: Map<String, ChipFilterState>,
    incomeChips: Map<String, ChipFilterState>,
    localityChips: Map<String, ChipFilterState>,
    shelterFilterEnabled: Boolean,
    damageFilterEnabled: Boolean,
    injuryFilterEnabled: Boolean,
    incomeFilterEnabled: Boolean,
    localityFilterEnabled: Boolean,
    binaryIncomeOption: String?,
    onToggleShelterEnabled: (Boolean) -> Unit,
    onToggleDamageEnabled: (Boolean) -> Unit,
    onToggleInjuryEnabled: (Boolean) -> Unit,
    onToggleIncomeEnabled: (Boolean) -> Unit,
    onToggleLocalityEnabled: (Boolean) -> Unit,
    onSelectBinaryIncomeOption: (String) -> Unit,
    exclusionMode: ExclusionMode,
    exclusionDays: String,
    exclusionDateCutoff: String,
    minFamilyMembers: Int,
    onCycleChip: (String, String) -> Unit,
    onSetExclusionMode: (ExclusionMode) -> Unit,
    onSetExclusionDays: (String) -> Unit,
    onOpenDatePicker: () -> Unit,
    onSetMinMembers: (Int) -> Unit,
    onResetFilters: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // شريط العداد الحي للأسر المطابقة للشروط الصارمة
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PalestineGreen.copy(alpha = 0.12f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("الأسر المطابقة للشروط الصارمة", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = PalestineGreen)
                        Text("(معتمد بالشؤون AND مقيم) مع كافة الفلاتر", fontSize = 11.sp, color = SlateTextMuted)
                    }
                    Text(
                        text = "$filteredFamiliesCount أسرة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = PalestineGreen
                    )
                }
            }
        }

        // دليل حالات الشرائح ومفاتيح التجاوز
        item {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("انقر على الشريحة للتبديل:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(modifier = Modifier.size(10.dp).background(PalestineGreen, CircleShape))
                        Text("تضمين [✓]", fontSize = 10.sp, color = PalestineGreen, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(modifier = Modifier.size(10.dp).background(PalestineRed, CircleShape))
                        Text("استثناء [✕]", fontSize = 10.sp, color = PalestineRed, fontWeight = FontWeight.Bold)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.ToggleOn, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                        Text("مفتاح التجاوز", fontSize = 10.sp, color = Color(0xFF334155), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // 1. فلتر حالة الإيواء (Shelter Status) مع مفتاح التجاوز
        item {
            FilterCategorySection(
                title = "حالة الإيواء ومراكز النزوح (Shelter)",
                options = shelterOptions,
                chipStates = shelterChips,
                isEnabled = shelterFilterEnabled,
                onToggleEnabled = onToggleShelterEnabled,
                onChipClick = { onCycleChip("shelter", it) }
            )
        }

        // 2. فلتر نوع الضرر (Damage Types) مع مفتاح التجاوز
        item {
            FilterCategorySection(
                title = "حالة أضرار الحرب والمنازل (Damage)",
                options = damageOptions,
                chipStates = damageChips,
                isEnabled = damageFilterEnabled,
                onToggleEnabled = onToggleDamageEnabled,
                onChipClick = { onCycleChip("damage", it) }
            )
        }

        // 3. فلتر حالة الإصابة (Injury Status) مع مفتاح التجاوز
        item {
            FilterCategorySection(
                title = "حالة الإصابة والشهداء (Injury)",
                options = injuryOptions,
                chipStates = injuryChips,
                isEnabled = injuryFilterEnabled,
                onToggleEnabled = onToggleInjuryEnabled,
                onChipClick = { onCycleChip("injury", it) }
            )
        }

        // 4. MISSION 2: فلتر الدخل الثنائي (Binary Income Filter: يعمل / لا يعمل) مع مفتاح التجاوز
        item {
            BinaryIncomeFilterSection(
                isEnabled = incomeFilterEnabled,
                onToggleEnabled = onToggleIncomeEnabled,
                selectedOption = binaryIncomeOption,
                onSelectOption = onSelectBinaryIncomeOption
            )
        }

        // 5. فلتر المناطق والمحليات الفرعية (Sub-Areas) مع مفتاح التجاوز
        item {
            FilterCategorySection(
                title = "المناطق والمحليات الفرعية (Sub-Areas)",
                options = subAreaOptions,
                chipStates = localityChips,
                isEnabled = localityFilterEnabled,
                onToggleEnabled = onToggleLocalityEnabled,
                onChipClick = { onCycleChip("locality", it) }
            )
        }

        // 6. الاستثناء الزمني المتقدم (Date Exclusion)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("الاستثناء الزمني للمساعدات السابقة (Date Exclusion)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = exclusionMode == ExclusionMode.DAYS,
                            onClick = { onSetExclusionMode(ExclusionMode.DAYS) },
                            label = { Text("آخر X أيام") }
                        )
                        FilterChip(
                            selected = exclusionMode == ExclusionMode.DATE,
                            onClick = { onSetExclusionMode(ExclusionMode.DATE) },
                            label = { Text("تاريخ قاطع محدد (Calendar)") }
                        )
                    }

                    if (exclusionMode == ExclusionMode.DAYS) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("15", "30", "60", "90").forEach { d ->
                                FilterChip(
                                    selected = exclusionDays == d,
                                    onClick = { onSetExclusionDays(d) },
                                    label = { Text("$d يوم") }
                                )
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = onOpenDatePicker,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.DateRange, contentDescription = null, tint = PalestineGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (exclusionDateCutoff.isNotBlank()) "التاريخ المختار: $exclusionDateCutoff" else "فتح المفكرة لاختيار التاريخ القاطع",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 7. حد أفراد الأسرة
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("الحد الأدنى لعدد أفراد الأسرة: $minFamilyMembers أفراد فما فوق", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Slider(
                        value = minFamilyMembers.toFloat(),
                        onValueChange = { onSetMinMembers(it.toInt()) },
                        valueRange = 1f..15f,
                        steps = 13,
                        colors = SliderDefaults.colors(thumbColor = PalestineGreen, activeTrackColor = PalestineGreen)
                    )
                }
            }
        }
    }
}

/**
 * مكون عرض شرائح التصنيف الواحد متعددة الحالات مع مفتاح التجاوز (Switch)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FilterCategorySection(
    title: String,
    options: List<String>,
    chipStates: Map<String, ChipFilterState>,
    isEnabled: Boolean = true,
    onToggleEnabled: ((Boolean) -> Unit)? = null,
    onChipClick: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isEnabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(if (isEnabled) 1.dp else 0.dp),
        border = if (!isEnabled) androidx.compose.foundation.BorderStroke(1.dp, SlateBorder) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isEnabled) MaterialTheme.colorScheme.onSurface else SlateTextMuted
                    )
                    if (!isEnabled) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = SlateBorder
                        ) {
                            Text(
                                text = "تجاوز (معطل)",
                                fontSize = 10.sp,
                                color = SlateTextMuted,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                if (onToggleEnabled != null) {
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = onToggleEnabled,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PalestineGreen,
                            uncheckedThumbColor = SlateTextMuted,
                            uncheckedTrackColor = SlateBorder
                        ),
                        modifier = Modifier.scale(0.85f)
                    )
                }
            }

            AnimatedVisibility(visible = isEnabled) {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    options.forEach { opt ->
                        val state = chipStates[opt] ?: ChipFilterState.UNSELECTED
                        TriStateFilterChip(
                            label = opt,
                            state = state,
                            onClick = { onChipClick(opt) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * MISSION 2: مكون فلتر الدخل الثنائي (Binary Income Filter Section)
 * خياران حصراً: "يعمل" (Has Income) و "لا يعمل" (No Income) مع مفتاح تجاوز الفلتر بالكامل
 */
@Composable
fun BinaryIncomeFilterSection(
    isEnabled: Boolean,
    onToggleEnabled: (Boolean) -> Unit,
    selectedOption: String?,
    onSelectOption: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isEnabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(if (isEnabled) 1.dp else 0.dp),
        border = if (!isEnabled) androidx.compose.foundation.BorderStroke(1.dp, SlateBorder) else null,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "فلتر حالة العمل ومصدر الدخل (Income)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isEnabled) MaterialTheme.colorScheme.onSurface else SlateTextMuted
                    )
                    if (!isEnabled) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = SlateBorder
                        ) {
                            Text(
                                text = "تجاوز (معطل)",
                                fontSize = 10.sp,
                                color = SlateTextMuted,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                Switch(
                    checked = isEnabled,
                    onCheckedChange = onToggleEnabled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = PalestineGreen,
                        uncheckedThumbColor = SlateTextMuted,
                        uncheckedTrackColor = SlateBorder
                    ),
                    modifier = Modifier.scale(0.85f)
                )
            }

            AnimatedVisibility(visible = isEnabled) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val isNoWorkSelected = selectedOption == "لا يعمل"
                    FilterChip(
                        selected = isNoWorkSelected,
                        onClick = { onSelectOption("لا يعمل") },
                        label = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (isNoWorkSelected) Icons.Default.CheckCircle else Icons.Default.WorkOff,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text("لا يعمل (بدون دخل)", fontWeight = if (isNoWorkSelected) FontWeight.Bold else FontWeight.Normal)
                            }
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PalestineRed.copy(alpha = 0.15f),
                            selectedLabelColor = PalestineRed,
                            selectedLeadingIconColor = PalestineRed
                        ),
                        modifier = Modifier.weight(1f)
                    )

                    val isWorkSelected = selectedOption == "يعمل"
                    FilterChip(
                        selected = isWorkSelected,
                        onClick = { onSelectOption("يعمل") },
                        label = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (isWorkSelected) Icons.Default.CheckCircle else Icons.Default.Work,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text("يعمل (لديه دخل)", fontWeight = if (isWorkSelected) FontWeight.Bold else FontWeight.Normal)
                            }
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PalestineGreen.copy(alpha = 0.15f),
                            selectedLabelColor = PalestineGreen,
                            selectedLeadingIconColor = PalestineGreen
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

/**
 * شريحة الفلترة ثلاثية الحالات (Tri-State Chip)
 */
@Composable
fun TriStateFilterChip(
    label: String,
    state: ChipFilterState,
    onClick: () -> Unit
) {
    val bgColor = when (state) {
        ChipFilterState.UNSELECTED -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ChipFilterState.INCLUDED -> PalestineGreen.copy(alpha = 0.15f)
        ChipFilterState.EXCLUDED -> PalestineRed.copy(alpha = 0.15f)
    }
    val borderColor = when (state) {
        ChipFilterState.UNSELECTED -> SlateBorder
        ChipFilterState.INCLUDED -> PalestineGreen
        ChipFilterState.EXCLUDED -> PalestineRed
    }
    val textColor = when (state) {
        ChipFilterState.UNSELECTED -> MaterialTheme.colorScheme.onSurface
        ChipFilterState.INCLUDED -> PalestineGreen
        ChipFilterState.EXCLUDED -> PalestineRed
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            when (state) {
                ChipFilterState.INCLUDED -> Icon(Icons.Default.Check, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(14.dp))
                ChipFilterState.EXCLUDED -> Icon(Icons.Default.Close, contentDescription = null, tint = PalestineRed, modifier = Modifier.size(14.dp))
                ChipFilterState.UNSELECTED -> {}
            }
            Text(text = label, fontSize = 12.sp, fontWeight = if (state != ChipFilterState.UNSELECTED) FontWeight.Bold else FontWeight.Normal, color = textColor)
        }
    }
}

/**
 * الخطوة 2: الاختيار الهجين ولوحة الحصص (Step 2: Hybrid Selection & Quotas Dashboard)
 */
@Composable
fun Step2HybridSelectionAndQuotas(
    selectedProject: ProjectEntity?,
    isReadOnlyMode: Boolean,
    filteredFamiliesCount: Int,
    selectedNomineesCount: Int,
    quotaStats: List<LocalityQuotaStatsItem>,
    onAutoNominate: () -> Unit,
    onOpenManualAdd: () -> Unit,
    onClearNominees: () -> Unit
) {
    val targetQuota = selectedProject?.targetQuota ?: 100
    val progress = (selectedNomineesCount.toFloat() / targetQuota.toFloat()).coerceIn(0f, 1f)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // بطاقة ملخص الحصة الكلية والتقدم
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("المرشحون الحاليون / سقف الحصة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("المشروع: ${selectedProject?.projectName ?: "عام"}", fontSize = 11.sp, color = SlateTextMuted)
                        }
                        Text(
                            text = "$selectedNomineesCount / $targetQuota",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = if (selectedNomineesCount >= targetQuota) PalestineGreen else Color(0xFF2563EB)
                        )
                    }

                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = if (selectedNomineesCount >= targetQuota) PalestineGreen else Color(0xFF2563EB),
                        trackColor = SlateBorder
                    )

                    // أزرار التحكم والترشيح الآلي/اليدوي
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onAutoNominate,
                            enabled = !isReadOnlyMode && filteredFamiliesCount > 0,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                        ) {
                            Icon(Icons.Default.AutoMode, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ترشيح آلي عادل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onOpenManualAdd,
                            enabled = !isReadOnlyMode && selectedNomineesCount < targetQuota,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة يدوية", fontSize = 12.sp)
                        }

                        IconButton(
                            onClick = onClearNominees,
                            enabled = !isReadOnlyMode && selectedNomineesCount > 0
                        ) {
                            Icon(Icons.Default.DeleteSweep, contentDescription = "تفريغ", tint = PalestineRed)
                        }
                    }
                }
            }
        }

        // عنوان لوحة الحصص
        item {
            Text(
                text = "لوحة مراجعة الحصص النسبية بالمحليات (Locality Quota Review)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        // قائمة المحليات مع الحصة المحسوبة والمرشحين والعجز/الفائض
        items(quotaStats, key = { it.localityName }) { stat ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = stat.localityName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = "الأسر المؤهلة: ${stat.baseX} (${stat.formattedPercentage})",
                            fontSize = 11.sp,
                            color = SlateTextMuted
                        )
                    }

                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "الحصة: ${stat.targetQuota} • المرشحون: ${stat.nominatedCount}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )

                        // شارة العجز أو الفائض
                        val diff = stat.shortageExcess
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = when {
                                diff < 0 -> PalestineRed.copy(alpha = 0.12f)
                                diff == 0 -> PalestineGreen.copy(alpha = 0.12f)
                                else -> Color(0xFFF59E0B).copy(alpha = 0.12f)
                            }
                        ) {
                            Text(
                                text = when {
                                    diff < 0 -> "عجز: ${-diff}"
                                    diff == 0 -> "مكتمل ✓"
                                    else -> "زيادة: +$diff"
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    diff < 0 -> PalestineRed
                                    diff == 0 -> PalestineGreen
                                    else -> Color(0xFFD97706)
                                },
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * الخطوة 3: المراجعة النهائية والاعتماد (Step 3: Final Review & Commit)
 */
@Composable
fun Step3FinalReviewAndCommit(
    selectedProject: ProjectEntity?,
    selectedNominees: List<FamilyEntity>,
    isReadOnlyMode: Boolean,
    onRemoveNominee: (FamilyEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("كشف المرشحين النهائي الجاهز للترحيل", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("المشروع: ${selectedProject?.projectName} • إجمالي المرشحين: ${selectedNominees.size} أسرة", fontSize = 12.sp, color = PalestineGreen, fontWeight = FontWeight.Bold)
                    if (isReadOnlyMode) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = PalestineRed.copy(alpha = 0.12f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ هذا المشروع مغلق ومكتمل. لا يمكن ترحيل أو تعديل أسماء إضافية.",
                                color = PalestineRed,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }

        if (selectedNominees.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لم يتم اختيار أي مرشحين حتى الآن. يرجى العودة للخطوة السابقة والضغط على (ترشيح آلي عادل) أو الإضافة يدوياً.",
                        textAlign = TextAlign.Center,
                        color = SlateTextMuted,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(selectedNominees, key = { it.familyID }) { nominee ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = nominee.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "هوية: ${nominee.nationalID} • جوال: ${nominee.primary_phone} • أفراد: ${nominee.familyMembersCount}",
                                fontSize = 11.sp,
                                color = SlateTextMuted
                            )
                            Text(
                                text = "المنطقة الحالية: ${nominee.currentSubArea} • الإيواء: ${nominee.shelterStatus}",
                                fontSize = 11.sp,
                                color = PalestineGreen
                            )
                        }

                        if (!isReadOnlyMode) {
                            IconButton(onClick = { onRemoveNominee(nominee) }) {
                                Icon(Icons.Default.RemoveCircleOutline, contentDescription = "استبعاد", tint = PalestineRed)
                            }
                        }
                    }
                }
            }
        }
    }
}
