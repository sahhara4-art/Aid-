package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.LocalityQuota
import com.humanitarian.aidmanagement.engine.NominationCandidate
import com.humanitarian.aidmanagement.notifications.AidNotificationHelper
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NominationScreen(
    repository: AidRepository,
    nominationViewModel: NominationViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = NominationViewModel.Factory(repository)
    ),
    onNavigateBack: () -> Unit,
    onNavigateToManualSelection: (aidTypeId: Int, projectId: Long) -> Unit,
    onNavigateToResults: () -> Unit
) {
    val context = LocalContext.current
    val dynamicShelterList by nominationViewModel.shelterStatuses.collectAsState()
    val dynamicWorksList by nominationViewModel.worksApprovals.collectAsState()
    val dynamicDamageList by nominationViewModel.damageTypes.collectAsState()
    val dynamicLocalitiesList by nominationViewModel.localities.collectAsState()
    val pureLocalitiesList by nominationViewModel.pureLocalities.collectAsState()
    val customLocalityQuotas = remember { mutableStateMapOf<String, String>() }

    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val projects by repository.getActiveProjects().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val distributions by repository.getDistributions().collectAsState(initial = emptyList())
    val currentUser by repository.currentUserFlow.collectAsState(initial = repository.getCurrentUser())
    val isManager = currentUser == null || currentUser?.RoleID == 1 || currentUser?.UserName?.equals("admin", ignoreCase = true) == true

    val scope = rememberCoroutineScope()
    val todayStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }

    // اختيار تصنيفات متعددة
    val selectedAidTypeIds = remember { mutableStateListOf<Int>(1) } // الافتراضي: غذائي
    var exclusionMode by remember { mutableStateOf("DAYS") } // "DAYS" أو "DATE"
    var exclusionDaysText by remember { mutableStateOf("30") } // أيام الاستثناء
    var exclusionDateText by remember { mutableStateOf("2024-12-01") } // تاريخ الاستثناء

    // شروط ومعايير الترشيح المخصصة
    var requireChildren by remember { mutableStateOf(false) }
    var selectedChildAge by remember { mutableStateOf(5) }
    var selectedShelter by remember { mutableStateOf("الكل") }
    var selectedWorks by remember { mutableStateOf("الكل") }
    var selectedDamage by remember { mutableStateOf("الكل") }
    var selectedMinMembers by remember { mutableStateOf(1) }

    var selectedProjectId by remember { mutableStateOf(1L) }
    var selectedLocalityId by remember { mutableStateOf(0) } // 0 = كل المحليات
    var requiredCountText by remember { mutableStateOf("100") }

    var isProcessing by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var quotasDialogList by remember { mutableStateOf<List<LocalityQuota>?>(null) }

    // نوافذ المدير: طرح مشروع جديد وتعديل المشروع
    var showCreateProjectDialog by remember { mutableStateOf(false) }
    var showEditProjectDialog by remember { mutableStateOf(false) }

    // حقول نموذج طرح مشروع جديد
    var newProjectName by remember { mutableStateOf("مشروع السلات الغذائية الطارئة الميدانية") }
    var newProjectNumber by remember { mutableStateOf("PRJ-2026-0${projects.size + 1}") }
    var newAidTypeId by remember { mutableStateOf(1) }
    var newFundingOrg by remember { mutableStateOf("برنامج الأغذية العالمي WFP") }
    var newWarehouse by remember { mutableStateOf("المستودع الرئيسي - دير البلح") }
    var newAidValue by remember { mutableStateOf("250.0") }
    var newTargetCount by remember { mutableStateOf("250") }
    var newNominationDeadline by remember { mutableStateOf("2026-10-25") }
    var newDetailedNotes by remember { mutableStateOf("طرح مشروع رسمي من قبل المدير وإشعار فرق الترشيح الميدانية") }

    // تحديث المشروع المحدد عند توفر المشاريع
    LaunchedEffect(projects) {
        if (projects.isNotEmpty() && (selectedProjectId == 1L || projects.none { it.projectID == selectedProjectId })) {
            selectedProjectId = projects.first().projectID
            requiredCountText = projects.first().quantity.toString()
        }
    }

    val activeProject = projects.find { it.projectID == selectedProjectId } ?: projects.firstOrNull()

    // تفعيل محرك الترشيح الديناميكي المتقدم افتراضياً
    var showLegacyProjectManager by remember { mutableStateOf(false) }

    if (!showLegacyProjectManager) {
        DynamicNominationScreen(
            repository = repository,
            nominationViewModel = nominationViewModel,
            onNavigateBack = onNavigateBack,
            onNavigateToManualSelection = onNavigateToManualSelection,
            onOpenProjectManager = { showLegacyProjectManager = true }
        )
        return
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "طرح المشاريع وتوزيع الحصص الإغاثية",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                "طرح واعتماد المشاريع • حصص المحليات الرسمية",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = { showLegacyProjectManager = false }) {
                            Icon(Icons.Default.Bolt, contentDescription = "محرك الترشيح الديناميكي", tint = Color(0xFF1976D2))
                        }
                        if (isManager) {
                            IconButton(onClick = { showCreateProjectDialog = true }) {
                                Icon(Icons.Default.AddBusiness, contentDescription = "طرح مشروع جديد", tint = Color(0xFF10B981))
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // ==========================================
                // 1. بطاقة بيانات المشروع المطروح ومحددات المدير
                // ==========================================
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF10B981).copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Assignment, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                                }
                                Column {
                                    Text(
                                        text = "المشروع الإغاثي المطروح للترشيح",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "محددات المدير • الحصص والمواعيد الرسمية",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                            }

                            if (isManager) {
                                Button(
                                    onClick = { showCreateProjectDialog = true },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("طرح مشروع جديد 🚀", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                        // اختيار المشروع من القائمة
                        if (projects.isNotEmpty()) {
                            Text("اختر المشروع للترشيح والعمل:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(projects) { prj ->
                                    val isSelected = prj.projectID == selectedProjectId
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            selectedProjectId = prj.projectID
                                            requiredCountText = prj.quantity.toString()
                                            selectedAidTypeIds.clear()
                                            selectedAidTypeIds.add(prj.aidTypeID)
                                        },
                                        leadingIcon = {
                                            if (isSelected) Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                        },
                                        label = {
                                            Column {
                                                Text(prj.projectName, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
                                                Text("${prj.projectNumber} • ${prj.quantity} حصة", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                                            }
                                        },
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }
                            }
                        }

                        // عرض تفاصيل المشروع النشط
                        if (activeProject != null) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(text = "رقم المشروع: ${activeProject.projectNumber}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color(0xFF10B981).copy(alpha = 0.15f)
                                        ) {
                                            Text(
                                                text = "الحصة الإجمالية: ${activeProject.quantity} أسرة",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = Color(0xFF047857),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(text = "المانح: ${activeProject.fundingInstitution}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                                        Text(text = "المستودع: ${activeProject.warehouseName}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                                    }

                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(text = "قيمة المعونة: ${activeProject.aidValue} ₪", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFD97706))
                                        Text(text = "تاريخ البدء/الموعد: ${activeProject.projectDate}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                                    }

                                    if (!activeProject.detailedDescription.isNullOrBlank()) {
                                        Text(
                                            text = "المعايير المحددة: ${activeProject.detailedDescription}",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                        )
                                    }

                                    if (activeProject.isLocked) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFFFEE2E2),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(16.dp))
                                                Text(
                                                    text = "تنبيه: هذا المشروع مقفل (🔒) ومغلق أمام أي ترشيح جديد.",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF991B1B)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // أزرار سريعة للمدير للتحكم بالمشروع
                        if (isManager && activeProject != null) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { showEditProjectDialog = true },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("تعديل المشروع ✏️", fontSize = 11.sp)
                                }

                                Button(
                                    onClick = onNavigateToResults,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("الاعتماد والاستكمال النهائي 👑", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // 2. بطاقة تصنيفات المساعدات المفحوصة والمستثناة
                // ==========================================
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "تصنيفات المساعدات المفحوصة والمستثناة",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "تم تحديد (${selectedAidTypeIds.size} من ${aidTypes.size}) نوعاً",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(
                                    onClick = {
                                        selectedAidTypeIds.clear()
                                        selectedAidTypeIds.addAll(aidTypes.map { it.aidTypeID })
                                    }
                                ) {
                                    Text("تحديد الكل", style = MaterialTheme.typography.labelSmall)
                                }
                                TextButton(
                                    onClick = {
                                        selectedAidTypeIds.clear()
                                        if (aidTypes.isNotEmpty()) selectedAidTypeIds.add(aidTypes.first().aidTypeID)
                                    }
                                ) {
                                    Text("إعادة ضبط", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        // تصنيفات المساعدات عبر FlowRow
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            aidTypes.forEach { aid ->
                                val isSelected = selectedAidTypeIds.contains(aid.aidTypeID)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        if (isSelected) {
                                            if (selectedAidTypeIds.size > 1) {
                                                selectedAidTypeIds.remove(aid.aidTypeID)
                                            }
                                        } else {
                                            selectedAidTypeIds.add(aid.aidTypeID)
                                        }
                                    },
                                    leadingIcon = {
                                        if (isSelected) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        }
                                    },
                                    label = { Text(aid.aidTypeName, style = MaterialTheme.typography.bodySmall) },
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        // تحديد مدة وطريقة الاستثناء
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "طريقة الاستثناء والحد الزمني:",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                FilterChip(
                                    selected = exclusionMode == "DAYS",
                                    onClick = { exclusionMode = "DAYS" },
                                    label = { Text("بالأيام السابقة") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                FilterChip(
                                    selected = exclusionMode == "DATE",
                                    onClick = { exclusionMode = "DATE" },
                                    label = { Text("بتاريخ مخصص") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            if (exclusionMode == "DAYS") {
                                OutlinedTextField(
                                    value = exclusionDaysText,
                                    onValueChange = { exclusionDaysText = it },
                                    label = { Text("عدد أيام الاستثناء") },
                                    supportingText = { Text("استبعاد من استلم في آخر ${exclusionDaysText.toIntOrNull() ?: 30} يوماً") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true
                                )

                                Text(
                                    text = "فترات استثناء سريعة:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )

                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val periods = listOf(15, 30, 45, 60, 90, 180)
                                    items(periods) { days ->
                                        FilterChip(
                                            selected = exclusionDaysText == days.toString(),
                                            onClick = { exclusionDaysText = days.toString() },
                                            label = { Text("$days يوم", style = MaterialTheme.typography.labelSmall) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }
                            } else {
                                OutlinedTextField(
                                    value = exclusionDateText,
                                    onValueChange = { exclusionDateText = it },
                                    label = { Text("تاريخ الاستثناء (YYYY-MM-DD)") },
                                    supportingText = { Text("استبعاد أي أسرة استلمت في أو بعد $exclusionDateText", color = MaterialTheme.colorScheme.error) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true
                                )
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        // شروط ومعايير الأهلية المخصصة
                        Text(
                            text = "شروط ومعايير الأهلية المخصصة للمشروع:",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // 1. اعتماد التنمية
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF10B981).copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "اعتماد التنمية الاجتماعية: معتمد",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF065F46)
                                )
                                Text(
                                    text = "إلزامي ودائم 🔒",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF047857)
                                )
                            }
                        }

                        // 2. شرط الأطفال
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "اشتراط وجود أطفال بالأسرة:",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    FilterChip(
                                        selected = requireChildren,
                                        onClick = { requireChildren = !requireChildren },
                                        label = { Text(if (requireChildren) "مفعل" else "غير مشروط") },
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                }

                                if (requireChildren) {
                                    Text(
                                        "الحد الأقصى لعمر الطفل:",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                    LazyRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        items(listOf(2, 5, 10, 18)) { age ->
                                            FilterChip(
                                                selected = selectedChildAge == age,
                                                onClick = { selectedChildAge = age },
                                                label = { Text("حتى $age سنوات") },
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // 3. حالة الإيواء (ديناميكي من قاعدة البيانات)
                        Text("حالة الإيواء:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        val shelterOptions = if (dynamicShelterList.isNotEmpty()) dynamicShelterList else listOf("الكل")
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            shelterOptions.forEach { sh ->
                                FilterChip(
                                    selected = selectedShelter == sh,
                                    onClick = { selectedShelter = sh },
                                    label = { Text(sh.ifBlank { "غير محدد" }) },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }

                        // 4. اعتماد الأشغال (ديناميكي من قاعدة البيانات)
                        Text("اعتماد وزارة الأشغال:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        val worksOptions = if (dynamicWorksList.isNotEmpty()) dynamicWorksList else listOf("الكل")
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            worksOptions.forEach { w ->
                                FilterChip(
                                    selected = selectedWorks == w,
                                    onClick = { selectedWorks = w },
                                    label = { Text(w.ifBlank { "غير محدد" }) },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }

                        // 5. حالة الضرر (ديناميكي من قاعدة البيانات)
                        Text("حالة الضرر المسجل:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        val damageOptions = if (dynamicDamageList.isNotEmpty()) dynamicDamageList else listOf("الكل")
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            damageOptions.forEach { d ->
                                FilterChip(
                                    selected = selectedDamage == d,
                                    onClick = { selectedDamage = d },
                                    label = { Text(d.ifBlank { "غير محدد" }) },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }

                        // 6. الحد الأدنى لأفراد الأسرة
                        Text("الحد الأدنى لأفراد الأسرة:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(listOf(1, 4, 6, 8)) { m ->
                                FilterChip(
                                    selected = selectedMinMembers == m,
                                    onClick = { selectedMinMembers = m },
                                    label = { Text(if (m == 1) "الكل (1+)" else "$m+ أفراد") },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        // العدد المطلوب ترشيحه
                        OutlinedTextField(
                            value = requiredCountText,
                            onValueChange = { requiredCountText = it },
                            label = { Text("العدد المطلوب ترشيحه (حصص المشروع)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        // نطاق المحليات - قائمة منسدلة ديناميكية (DropdownMenu) مبنية من قاعدة البيانات
                        var localityDropdownExpanded by remember { mutableStateOf(false) }
                        val selectedLocalityName = remember(selectedLocalityId, localities) {
                            if (selectedLocalityId == 0) "جميع المحليات بنسب التوزيع"
                            else localities.find { it.LocalityID == selectedLocalityId }?.LocalityName ?: "محلية #$selectedLocalityId"
                        }

                        Text("نطاق التوزيع الجغرافي (قائمة المحليات):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedTextField(
                                value = selectedLocalityName,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("اختر المحلية أو النطاق الجغرافي *") },
                                trailingIcon = {
                                    IconButton(onClick = { localityDropdownExpanded = !localityDropdownExpanded }) {
                                        Icon(
                                            imageVector = if (localityDropdownExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { localityDropdownExpanded = true },
                                shape = RoundedCornerShape(12.dp)
                            )

                            DropdownMenu(
                                expanded = localityDropdownExpanded,
                                onDismissRequest = { localityDropdownExpanded = false },
                                modifier = Modifier.fillMaxWidth(0.9f)
                            ) {
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("جميع المحليات بنسب التوزيع", fontWeight = if (selectedLocalityId == 0) FontWeight.Bold else FontWeight.Normal)
                                            if (selectedLocalityId == 0) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    },
                                    onClick = {
                                        selectedLocalityId = 0
                                        localityDropdownExpanded = false
                                    }
                                )
                                if (localities.isEmpty()) {
                                    DropdownMenuItem(
                                        text = { Text("لا توجد بيانات محليات مسجلة", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                                        onClick = { localityDropdownExpanded = false },
                                        enabled = false
                                    )
                                } else {
                                    localities.forEach { loc ->
                                        DropdownMenuItem(
                                            text = {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(loc.LocalityName, fontWeight = if (selectedLocalityId == loc.LocalityID) FontWeight.Bold else FontWeight.Normal)
                                                    if (selectedLocalityId == loc.LocalityID) {
                                                        Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                                    }
                                                }
                                            },
                                            onClick = {
                                                selectedLocalityId = loc.LocalityID
                                                localityDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        // قسم التوزيع الجغرافي وحصص المحليات الديناميكي
                        Text(
                            text = "التوزيع الجغرافي وحصص المحليات:",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        if (pureLocalitiesList.isEmpty()) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        Icons.Default.LocationOff,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.outline
                                    )
                                    Text(
                                        text = "لا توجد محليات مسجلة في قاعدة البيانات حالياً. ستظهر الحصص تلقائياً عند استيراد الأسر.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val total = requiredCountText.toIntOrNull() ?: 100
                                val defaultShare = if (pureLocalitiesList.isNotEmpty()) total / pureLocalitiesList.size else 0
                                pureLocalitiesList.forEach { locName ->
                                    val currentQuota = customLocalityQuotas[locName] ?: defaultShare.toString()
                                    Card(
                                        shape = RoundedCornerShape(12.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 12.dp, vertical = 8.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.LocationOn,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.primary,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Text(
                                                    text = locName,
                                                    fontWeight = FontWeight.SemiBold,
                                                    style = MaterialTheme.typography.bodyMedium
                                                )
                                            }
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(
                                                    text = "الحصة:",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                OutlinedTextField(
                                                    value = currentQuota,
                                                    onValueChange = { customLocalityQuotas[locName] = it },
                                                    modifier = Modifier.width(90.dp),
                                                    shape = RoundedCornerShape(8.dp),
                                                    singleLine = true,
                                                    textStyle = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // بطاقة ملخص القواعد المطبقة
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "ملخص القواعد المطبقة على الترشيح:",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text("• استبعاد فوري لأي أسرة استلمت أحد التصنيفات المحددة خلال فترة الاستثناء.", style = MaterialTheme.typography.bodySmall)
                        Text("• اعتماد التنمية = معتمد، والأولوية للأسر الأكبر عدداً وذوي الأضرار البليغة.", style = MaterialTheme.typography.bodySmall)
                        Text("• يتم احتساب الحصص الجغرافية للمناطق بخوارزمية أكبر الكسور المتبقية الرسمية.", style = MaterialTheme.typography.bodySmall)
                    }
                }

                AnimatedVisibility(
                    visible = statusMessage != null,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusMessage ?: "",
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // ==========================================
                // 3. أزرار العمليات والتنفيذ (آلي + يدوي + حصص + اعتماد)
                // ==========================================
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // زر تنفيذ الترشيح الآلي الرئيسي
                    Button(
                        onClick = {
                            val total = requiredCountText.toIntOrNull() ?: 100
                            scope.launch {
                                isProcessing = true
                                statusMessage = "جاري تشغيل محرك الترشيح وفحص الاستثناءات لـ ${selectedAidTypeIds.size} تصنيفات..."
                                val criteria = com.humanitarian.aidmanagement.engine.NominationCriteria(
                                    developmentApprovalRequired = true,
                                    requireChildren = requireChildren,
                                    maxChildAge = if (requireChildren) selectedChildAge else null,
                                    shelterStatus = if (selectedShelter == "الكل") null else selectedShelter,
                                    worksApproval = if (selectedWorks == "الكل") null else selectedWorks,
                                    damageType = if (selectedDamage == "الكل") null else selectedDamage,
                                    minFamilyMembers = selectedMinMembers,
                                    exclusionMode = exclusionMode,
                                    exclusionDays = exclusionDaysText.toIntOrNull() ?: 30,
                                    exclusionDateCutoff = exclusionDateText,
                                    aidTypeIds = selectedAidTypeIds.toList()
                                )
                                val candidates = repository.runNominationWithCriteria(
                                    localityId = selectedLocalityId,
                                    criteria = criteria,
                                    projectId = selectedProjectId,
                                    requiredCount = total
                                )
                                isProcessing = false
                                statusMessage = "تم ترشيح ${candidates.size} أسرة مستحقة وفقاً للشروط المحددة وتم ترحيلهم لشاشة الاعتماد."
                                onNavigateToResults()
                            }
                        },
                        enabled = !isProcessing && (activeProject?.isLocked != true),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (activeProject?.isLocked == true) Color.Gray else Color(0xFF10B981)
                        )
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                        } else {
                            Icon(if (activeProject?.isLocked == true) Icons.Default.Lock else Icons.Default.AutoMode, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (activeProject?.isLocked == true) "المشروع مقفل - لا يمكن الترشيح 🔒" else "تنفيذ الترشيح الآلي الذكي ($requiredCountText حصة)",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // زر الترشيح والاستكمال اليدوي
                        Button(
                            onClick = {
                                val primaryAidId = selectedAidTypeIds.firstOrNull() ?: 1
                                onNavigateToManualSelection(primaryAidId, selectedProjectId)
                            },
                            enabled = !isProcessing && (activeProject?.isLocked != true),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                        ) {
                            Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ترشيح واستكمال يدوي ✋", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }

                        // زر عرض حصص المحليات بالنسب الرسمية
                        OutlinedButton(
                            onClick = {
                                val total = requiredCountText.toIntOrNull() ?: 100
                                scope.launch {
                                    val quotas = repository.calculateQuotas(total)
                                    quotasDialogList = quotas
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PieChart, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("حصص المحليات 📊", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    // زر عرض نتائج واعتماد الترشيح المكتمل
                    Button(
                        onClick = onNavigateToResults,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4338CA))
                    ) {
                        Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("عرض نتائج الترشيح والاعتماد النهائي 👑", fontWeight = FontWeight.Bold)
                    }

                    // زر مسح الاختيارات المؤقتة
                    TextButton(
                        onClick = {
                            scope.launch {
                                val primaryAidId = selectedAidTypeIds.firstOrNull() ?: 1
                                repository.clearManualSelections(primaryAidId, selectedProjectId)
                                statusMessage = "تم مسح الاختيارات المؤقتة بنجاح"
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("مسح الاختيارات المؤقتة", color = MaterialTheme.colorScheme.error)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }

        // ==========================================
        // نافذة المدير: طرح مشروع جديد وإشعار المستخدمين
        // ==========================================
        if (showCreateProjectDialog) {
            AlertDialog(
                onDismissRequest = { showCreateProjectDialog = false },
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.92f),
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF10B981).copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AddBusiness, contentDescription = null, tint = Color(0xFF10B981))
                            }
                            Column {
                                Text("طرح مشروع إغاثي جديد", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                Text("تحديد المعايير والعدد وإشعار الفرق الميدانية", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            }
                        }
                        IconButton(onClick = { showCreateProjectDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق")
                        }
                    }
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .wrapContentHeight()
                            .heightIn(max = 500.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = newProjectName,
                            onValueChange = { newProjectName = it },
                            label = { Text("اسم المشروع الإغاثي *") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newProjectNumber,
                                onValueChange = { newProjectNumber = it },
                                label = { Text("رمز المشروع") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = newTargetCount,
                                onValueChange = { newTargetCount = it },
                                label = { Text("العدد المطلوب (حصة) *") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        // تصنيف المعونة
                        Text("تصنيف المعونة الأساسي:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(aidTypes) { aid ->
                                FilterChip(
                                    selected = newAidTypeId == aid.aidTypeID,
                                    onClick = { newAidTypeId = aid.aidTypeID },
                                    label = { Text(aid.aidTypeName, fontSize = 11.sp) },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newFundingOrg,
                                onValueChange = { newFundingOrg = it },
                                label = { Text("الجهة المانحة") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = newAidValue,
                                onValueChange = { newAidValue = it },
                                label = { Text("القيمة (₪)") },
                                modifier = Modifier.weight(0.7f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = newWarehouse,
                                onValueChange = { newWarehouse = it },
                                label = { Text("نقطة التوزيع / المستودع") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = newNominationDeadline,
                                onValueChange = { newNominationDeadline = it },
                                label = { Text("الموعد المحدد للترشيح") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        OutlinedTextField(
                            value = newDetailedNotes,
                            onValueChange = { newDetailedNotes = it },
                            label = { Text("الشروط والمعايير الإلزامية للمشروع") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            minLines = 2
                        )

                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val targetQty = newTargetCount.toIntOrNull() ?: 250
                            val aidVal = newAidValue.toDoubleOrNull() ?: 250.0
                            val project = ProjectEntity(
                                projectNumber = newProjectNumber,
                                projectName = newProjectName,
                                aidTypeID = newAidTypeId,
                                detailedDescription = newDetailedNotes,
                                projectDate = todayStr,
                                actualNominationDate = "$todayStr 10:00",
                                fundingInstitution = newFundingOrg,
                                warehouseName = newWarehouse,
                                aidValue = aidVal,
                                quantity = targetQty,
                                stageUserName = currentUser?.fullName ?: "مدير النظام",
                                notes = "موعد الترشيح المحدد: $newNominationDeadline",
                                isActive = true
                            )

                            scope.launch {
                                val insertedId = repository.insertProject(project)
                                selectedProjectId = insertedId
                                requiredCountText = targetQty.toString()
                                selectedAidTypeIds.clear()
                                selectedAidTypeIds.add(newAidTypeId)
                                showCreateProjectDialog = false
                                statusMessage = "📢 تم طرح مشروع \"$newProjectName\" بنجاح وإشعار المستخدمين بالموعد المحدد $newNominationDeadline ضمن الحصص الرسمية!"

                                // إرسال إشعار نظامي رسمي للفرق والمستخدمين
                                val quotasSummary = "المشروع متاح للترشيح المعتمد لجميع المحليات"
                                val aidName = aidTypes.find { it.aidTypeID == newAidTypeId }?.aidTypeName ?: "معونة إغاثية"
                                AidNotificationHelper.notifyProjectLaunched(
                                    context = context,
                                    notificationId = (System.currentTimeMillis() % 100000).toInt(),
                                    projectNumber = newProjectNumber,
                                    projectName = newProjectName,
                                    aidTypeName = aidName,
                                    targetCount = targetQty,
                                    deadline = newNominationDeadline,
                                    quotasSummary = quotasSummary
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Campaign, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("طرح المشروع وإشعار الفرق 📢", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = { showCreateProjectDialog = false },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إلغاء")
                    }
                }
            )
        }

        // ==========================================
        // نافذة المدير: تعديل بيانات ومعايير المشروع الحالي
        // ==========================================
        if (showEditProjectDialog && activeProject != null) {
            EditProjectDialog(
                project = activeProject,
                onDismiss = { showEditProjectDialog = false },
                onConfirm = { updatedProject ->
                    scope.launch {
                        repository.insertProject(updatedProject)
                        requiredCountText = updatedProject.quantity.toString()
                        showEditProjectDialog = false
                        statusMessage = "تم تعديل بيانات ومعايير المشروع بنجاح."
                    }
                }
            )
        }

        // ==========================================
        // نافذة عرض حصص المحليات بنظام أكبر الكسور
        // ==========================================
        if (quotasDialogList != null) {
            val total = requiredCountText.toIntOrNull() ?: 100
            AlertDialog(
                onDismissRequest = { quotasDialogList = null },
                title = {
                    Text("توزيع الحصص على المحليات (المجموع: $total)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "تم حساب الحصص بخوارزمية تقريب الكسور لضمان تطابق المجموع بدقة وفق نسب السكان الحقيقية في قاعدة البيانات:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        quotasDialogList!!.forEach { q ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(q.localityName, style = MaterialTheme.typography.bodyMedium)
                                Text("${q.allocatedCount} أسرة", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { quotasDialogList = null },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("حسناً")
                    }
                }
            )
        }
    }
}

@Composable
private fun EditProjectDialog(
    project: ProjectEntity,
    onDismiss: () -> Unit,
    onConfirm: (ProjectEntity) -> Unit
) {
    var editName by remember(project) { mutableStateOf(project.projectName) }
    var editTarget by remember(project) { mutableStateOf(project.quantity.toString()) }
    var editFunding by remember(project) { mutableStateOf(project.fundingInstitution) }
    var editWarehouse by remember(project) { mutableStateOf(project.warehouseName) }
    var editValue by remember(project) { mutableStateOf(project.aidValue.toString()) }
    var editDesc by remember(project) { mutableStateOf(project.detailedDescription) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "تعديل بيانات ومعايير المشروع الحالي",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = editName,
                    onValueChange = { editName = it },
                    label = { Text("اسم المشروع") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = editTarget,
                        onValueChange = { editTarget = it },
                        label = { Text("العدد المطلوب (الحصة)") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = editValue,
                        onValueChange = { editValue = it },
                        label = { Text("القيمة (₪)") },
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = editFunding,
                    onValueChange = { editFunding = it },
                    label = { Text("الجهة المانحة") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = editWarehouse,
                    onValueChange = { editWarehouse = it },
                    label = { Text("نقطة التوزيع / المستودع") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = editDesc,
                    onValueChange = { editDesc = it },
                    label = { Text("معايير المشروع وشروط الترشيح") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = project.copy(
                        projectName = editName,
                        quantity = editTarget.toIntOrNull() ?: project.quantity,
                        fundingInstitution = editFunding,
                        warehouseName = editWarehouse,
                        aidValue = editValue.toDoubleOrNull() ?: project.aidValue,
                        detailedDescription = editDesc
                    )
                    onConfirm(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("حفظ التعديلات")
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("إلغاء")
            }
        }
    )
}
