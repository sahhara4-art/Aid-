package com.humanitarian.aidmanagement.util

import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import java.util.Locale

/**
 * المصدر المركزي الموحّد لتصنيفات وأنواع المساعدات في كامل التطبيق.
 * يتولى توحيد النصوص والمسافات، ومنع التكرار، وتوفير التصنيفات الافتراضية المعتمدة،
 * وحل اسم التصنيف الفعلي للسجلات والمشاريع بشكل متسق في جميع الشاشات والإحصائيات.
 */
object AidCategoryCatalog {

    val DEFAULT_AID_TYPES: List<AidTypeEntity> = listOf(
        AidTypeEntity(1, "غذائي", "طرود وسلات غذائية أساسية", 30, true),
        AidTypeEntity(2, "خضروات وفواكه", "سلل خضار وفواكه طازجة", 15, true),
        AidTypeEntity(3, "لحوم", "لحوم طازجة أو مجمدة وأضاحي", 30, true),
        AidTypeEntity(4, "مساعدات نقدية", "دعم مالي ومساعدات نقدية طارئة", 30, true),
        AidTypeEntity(5, "كسوة", "ملابس وكسوة للأسرة والأطفال", 90, true),
        AidTypeEntity(6, "مساعدات صحية", "أدوية ومستلزمات طبية وصحية", 15, true),
        AidTypeEntity(7, "فرشات وشوادر", "فرشات وبطانيات وشوادر وخيام", 180, true),
        AidTypeEntity(8, "أدوات مطبخ", "أدوات ومستلزمات طبخ ومطبخ", 180, true),
        AidTypeEntity(9, "بامبرز أطفال", "حفاضات ومستلزمات رعاية الأطفال", 15, true),
        AidTypeEntity(10, "فارس الشهم", "مساعدات ومشاريع عملية الفارس الشهم", 30, true),
        AidTypeEntity(11, "تنمية اجتماعية", "مشاريع ومساعدات وزارة التنمية الاجتماعية", 30, true)
    )

    val MAX_DEFAULT_ID: Int = DEFAULT_AID_TYPES.maxOf { it.aidTypeID }

    private val MULTI_WHITESPACE_REGEX = Regex("\\s+")
    private val INVISIBLE_CHARS_REGEX = Regex("[\\u200B-\\u200F\\uFEFF\\u00A0]")
    private val ARABIC_DIACRITICS_REGEX = Regex("[\\u064B-\\u065F\\u0670\\u0640]")

    private val PLACEHOLDER_KEYS = setOf("غير محدد", "غيرمحدد", "بدون تصنيف", "لا يوجد", "-")

    /**
     * تنظيف وتوحيد المسافات في اسم التصنيف مع الحفاظ على صياغته العربية الواضحة للعرض.
     */
    fun cleanName(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        return raw
            .replace(INVISIBLE_CHARS_REGEX, " ")
            .trim()
            .replace(MULTI_WHITESPACE_REGEX, " ")
    }

    /**
     * مفتاح قياسي موحّد للمقارنة ومنع التكرار المزعج (توحيد المسافات، الهمزات، التاء المربوطة، الألف المقصورة، التشكيل).
     */
    fun canonicalKey(raw: String?): String {
        val cleaned = cleanName(raw)
        if (cleaned.isBlank()) return ""
        return cleaned
            .replace(ARABIC_DIACRITICS_REGEX, "")
            .replace('أ', 'ا')
            .replace('إ', 'ا')
            .replace('آ', 'ا')
            .replace('ٱ', 'ا')
            .replace('ى', 'ي')
            .replace('ة', 'ه')
            .replace('ؤ', 'و')
            .replace('ئ', 'ي')
            .lowercase(Locale.ROOT)
    }

    fun isValidCategoryName(raw: String?): Boolean {
        val cleaned = cleanName(raw)
        if (cleaned.isBlank()) return false
        val key = canonicalKey(cleaned)
        return key.isNotBlank() && key !in PLACEHOLDER_KEYS
    }

    fun isSameCategory(first: String?, second: String?): Boolean {
        val k1 = canonicalKey(first)
        val k2 = canonicalKey(second)
        return k1.isNotBlank() && k1 == k2
    }

    /**
     * دمج وتنقية قائمة كيانات أنواع المساعدات مع التصنيفات الافتراضية ومنع التكرار حسب المفتاح القياسي.
     */
    fun mergeWithDefaultsAndDeduplicate(
        dbTypes: List<AidTypeEntity>,
        includeDefaultsIfMissing: Boolean = true
    ): List<AidTypeEntity> {
        val byCanonicalKey = LinkedHashMap<String, AidTypeEntity>()
        val sortedDb = dbTypes
            .filter { isValidCategoryName(it.aidTypeName) }
            .sortedWith(compareByDescending<AidTypeEntity> { it.isActive }.thenBy { it.aidTypeID })

        for (item in sortedDb) {
            val cleaned = cleanName(item.aidTypeName)
            val key = canonicalKey(cleaned)
            if (key.isNotBlank() && !byCanonicalKey.containsKey(key)) {
                byCanonicalKey[key] = item.copy(aidTypeName = cleaned)
            }
        }

        if (includeDefaultsIfMissing) {
            for (def in DEFAULT_AID_TYPES) {
                val key = canonicalKey(def.aidTypeName)
                if (key.isNotBlank() && !byCanonicalKey.containsKey(key)) {
                    byCanonicalKey[key] = def
                }
            }
        }

        return byCanonicalKey.values
            .sortedBy { it.aidTypeID }
    }

    /**
     * توحيد ومنع تكرار قائمة أسماء التصنيفات النصية مع الحفاظ على ترتيب الأولوية (الافتراضية والمضافة ثم البقية).
     */
    fun deduplicateCategoryNames(
        primaryNames: Iterable<String>,
        secondaryNames: Iterable<String> = emptyList(),
        includeDefaults: Boolean = true
    ): List<String> {
        val map = LinkedHashMap<String, String>()

        fun addIfNew(raw: String) {
            val cleaned = cleanName(raw)
            if (!isValidCategoryName(cleaned)) return
            val key = canonicalKey(cleaned)
            if (key.isNotBlank() && !map.containsKey(key)) {
                map[key] = cleaned
            }
        }

        if (includeDefaults) {
            DEFAULT_AID_TYPES.forEach { addIfNew(it.aidTypeName) }
        }
        primaryNames.forEach { addIfNew(it) }
        secondaryNames.forEach { addIfNew(it) }

        return map.values.toList()
    }

    /**
     * مطابقة كيان التصنيف من قائمة موجودة عبر الاسم (المفتاح القياسي).
     */
    fun findMatchingType(types: List<AidTypeEntity>, rawName: String?): AidTypeEntity? {
        val targetKey = canonicalKey(rawName)
        if (targetKey.isBlank()) return null
        return types.firstOrNull { canonicalKey(it.aidTypeName) == targetKey }
    }

    /**
     * إرجاع اسم التصنيف الحقيقي مع الرجوع الآمن لتصنيف المشروع أو التصنيفات الافتراضية.
     */
    fun resolveDisplayName(
        aidTypeId: Int,
        aidTypeMap: Map<Int, AidTypeEntity>,
        projectAidTypeId: Int? = null,
        fallbackLabel: String = "مساعدة إنسانية"
    ): String {
        val primaryName = aidTypeMap[aidTypeId]?.aidTypeName?.let { cleanName(it) }
        if (!primaryName.isNullOrBlank()) return primaryName

        if (projectAidTypeId != null && projectAidTypeId > 0) {
            val projectTypeName = aidTypeMap[projectAidTypeId]?.aidTypeName?.let { cleanName(it) }
            if (!projectTypeName.isNullOrBlank()) return projectTypeName
        }

        val effectiveId = aidTypeId.takeIf { it > 0 } ?: (projectAidTypeId?.takeIf { it > 0 } ?: 0)
        val defaultMatch = DEFAULT_AID_TYPES.firstOrNull { it.aidTypeID == effectiveId }?.aidTypeName
        if (!defaultMatch.isNullOrBlank()) return defaultMatch

        return if (effectiveId > 0) "تصنيف #$effectiveId" else fallbackLabel
    }
}
