package com.humanitarian.aidmanagement.civilregistry.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.CancellationSignal
import android.provider.OpenableColumns
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryChildRecord
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryChildrenSchema
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryDbStatus
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryImportProgress
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySchema
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchPage
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * مصدر البيانات الفعلي لقاعدة civil_registry.db (أرباب الأسر + جدول الأبناء ~1.87 مليون سجل) بوضع القراءة فقط
 *
 * ضمانات هندسية صارمة:
 * 1. فتح civil_registry.db حصراً بوضع SQLiteDatabase.OPEN_READONLY.
 * 2. مفصول 100% عن قاعدة Room الخاصة بالمشروع.
 * 3. يستفيد من الفهارس الموجودة مسبقاً (idx_citizen_id, idx_citizen_name, idx_wife_id,
 *    idx_children_parent_id, idx_children_child_id, idx_children_birth_date).
 * 4. يتعامل تلقائياً وبأمان مع القواعد القديمة التي لا تحتوي على children_registry دون أي تعطل.
 */
class SqliteCivilRegistryDataSource(
    private val appContext: Context
) : CivilRegistryDataSource {

    companion object {
        private const val COPY_BUFFER_BYTES = 256 * 1024
        private const val PROGRESS_EMIT_INTERVAL_BYTES = 1024L * 1024L
    }

    private val dbLock = Any()
    @Volatile
    private var readOnlyDb: SQLiteDatabase? = null
    @Volatile
    private var activeDbPath: String? = null

    override suspend fun ensureDatabaseReady(): CivilRegistryDbStatus = withContext(Dispatchers.IO) {
        try {
            val dbFile = resolveOrProvisionDatabaseFile()
                ?: return@withContext CivilRegistryDbStatus.Missing(
                    expectedPath = appContext.getDatabasePath(CivilRegistrySchema.DATABASE_FILE_NAME).absolutePath
                )

            val db = openReadOnlyInternal(dbFile)
            buildReadyStatus(db, dbFile.absolutePath)
        } catch (t: Throwable) {
            CivilRegistryDbStatus.Error(
                message = t.localizedMessage ?: "تعذر فتح قاعدة السجل المدني بوضع القراءة فقط."
            )
        }
    }

    /**
     * ربط ونسخ نسخة محلية كبيرة من civil_registry.db يختارها المستخدم من ذاكرة الجهاز (للقراءة فقط)
     * يتم التنفيذ بالكامل على Dispatchers.IO مع تقارير تقدم سلسة لشريط التقدم في الواجهة.
     */
    suspend fun importExternalDatabase(
        uri: Uri,
        onProgress: ((CivilRegistryImportProgress) -> Unit)? = null
    ): CivilRegistryDbStatus = withContext(Dispatchers.IO) {
        var tempFile: File? = null
        try {
            val targetFile = appContext.getDatabasePath(CivilRegistrySchema.DATABASE_FILE_NAME)
            targetFile.parentFile?.mkdirs()
            val stagingFile = File(targetFile.parentFile, "${CivilRegistrySchema.DATABASE_FILE_NAME}.tmp")
            tempFile = stagingFile

            val totalBytes = resolveUriSizeBytes(uri)
            onProgress?.invoke(
                CivilRegistryImportProgress(
                    copiedBytes = 0L,
                    totalBytes = totalBytes,
                    stageMessage = "جاري نسخ ملف قاعدة بيانات السجل المدني..."
                )
            )

            var copiedBytes = 0L
            var lastReportedBytes = 0L

            appContext.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(stagingFile).use { output ->
                    val buffer = ByteArray(COPY_BUFFER_BYTES)
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        output.write(buffer, 0, read)
                        copiedBytes += read
                        if (copiedBytes - lastReportedBytes >= PROGRESS_EMIT_INTERVAL_BYTES) {
                            lastReportedBytes = copiedBytes
                            onProgress?.invoke(
                                CivilRegistryImportProgress(
                                    copiedBytes = copiedBytes,
                                    totalBytes = totalBytes,
                                    stageMessage = "جاري استيراد قاعدة السجل المدني..."
                                )
                            )
                        }
                    }
                    output.flush()
                }
            } ?: return@withContext CivilRegistryDbStatus.Error("تعذر قراءة الملف المختار من الجهاز.")

            onProgress?.invoke(
                CivilRegistryImportProgress(
                    copiedBytes = copiedBytes,
                    totalBytes = if (totalBytes > 0L) totalBytes else copiedBytes,
                    stageMessage = "جاري التحقق من الجداول والفهارس..."
                )
            )

            val testDb = SQLiteDatabase.openDatabase(
                stagingFile.absolutePath,
                null,
                SQLiteDatabase.OPEN_READONLY or SQLiteDatabase.NO_LOCALIZED_COLLATORS
            )
            val tableExists = try {
                CivilRegistryQueryExecutor.hasTable(testDb, CivilRegistrySchema.TABLE_NAME)
            } finally {
                testDb.close()
            }

            if (!tableExists) {
                stagingFile.delete()
                return@withContext CivilRegistryDbStatus.Error(
                    "الملف المختار لا يحتوي على جدول السجل المدني المعتمد (${CivilRegistrySchema.TABLE_NAME})."
                )
            }

            synchronized(dbLock) {
                closeInternalLocked()
                if (targetFile.exists()) targetFile.delete()
                if (!stagingFile.renameTo(targetFile)) {
                    stagingFile.copyTo(targetFile, overwrite = true)
                    stagingFile.delete()
                }
            }

            val db = openReadOnlyInternal(targetFile)
            buildReadyStatus(db, targetFile.absolutePath)
        } catch (t: Throwable) {
            try {
                tempFile?.takeIf { it.exists() }?.delete()
            } catch (_: Throwable) {
            }
            CivilRegistryDbStatus.Error(
                message = t.localizedMessage ?: "حدث خطأ أثناء ربط ملف civil_registry.db."
            )
        }
    }

    override suspend fun search(
        query: CivilRegistrySearchQuery,
        offset: Int,
        pageSize: Int,
        cancellationSignal: CancellationSignal?
    ): CivilRegistrySearchPage = withContext(Dispatchers.IO) {
        val db = getOpenedReadOnlyDb()
            ?: return@withContext CivilRegistrySearchPage(emptyList(), hasMore = false, offset = offset.coerceAtLeast(0))

        CivilRegistryQueryExecutor.executeSearch(
            db = db,
            query = query,
            offset = offset,
            pageSize = pageSize,
            cancellationSignal = cancellationSignal
        )
    }

    override suspend fun getChildrenForParent(
        parentId: String,
        minBirthDateIso: String?,
        maxBirthDateIso: String?,
        cancellationSignal: CancellationSignal?
    ): List<CivilRegistryChildRecord> = withContext(Dispatchers.IO) {
        val db = getOpenedReadOnlyDb() ?: return@withContext emptyList()
        CivilRegistryQueryExecutor.queryChildrenByParentId(
            db = db,
            parentId = parentId,
            minBirthDateIso = minBirthDateIso,
            maxBirthDateIso = maxBirthDateIso,
            cancellationSignal = cancellationSignal,
            enforceCivilRegistryAccessGuard = true
        )
    }

    internal suspend fun getChildrenForOfficialSync(
        parentId: String,
        minBirthDateIso: String? = null,
        maxBirthDateIso: String? = null
    ): Pair<Boolean, List<CivilRegistryChildRecord>> = withContext(Dispatchers.IO) {
        val db = getOpenedReadOnlyDb() ?: return@withContext (false to emptyList())
        val hasTable = CivilRegistryQueryExecutor.hasTable(db, CivilRegistryChildrenSchema.TABLE_NAME)
        if (!hasTable) return@withContext (false to emptyList())
        val list = CivilRegistryQueryExecutor.queryChildrenByParentId(
            db = db,
            parentId = parentId,
            minBirthDateIso = minBirthDateIso,
            maxBirthDateIso = maxBirthDateIso,
            cancellationSignal = null,
            enforceCivilRegistryAccessGuard = false
        )
        true to list
    }

    internal suspend fun getChildrenForOfficialSyncChunk(
        parentIds: List<String>,
        minBirthDateIso: String? = null,
        maxBirthDateIso: String? = null
    ): List<CivilRegistryChildRecord> = withContext(Dispatchers.IO) {
        if (parentIds.isEmpty()) return@withContext emptyList()
        val db = getOpenedReadOnlyDb() ?: return@withContext emptyList()
        CivilRegistryQueryExecutor.queryChildrenByParentIdsChunk(
            db = db,
            parentIds = parentIds,
            minBirthDateIso = minBirthDateIso,
            maxBirthDateIso = maxBirthDateIso,
            cancellationSignal = null,
            enforceCivilRegistryAccessGuard = false
        )
    }

    override suspend fun hasChildrenRegistryTable(): Boolean = withContext(Dispatchers.IO) {
        val db = getOpenedReadOnlyDb() ?: return@withContext false
        CivilRegistryQueryExecutor.hasTable(db, CivilRegistryChildrenSchema.TABLE_NAME)
    }

    override fun close() {
        synchronized(dbLock) {
            closeInternalLocked()
        }
    }

    private fun buildReadyStatus(db: SQLiteDatabase, path: String): CivilRegistryDbStatus.Ready {
        val totalRows = CivilRegistryQueryExecutor.queryTotalCountFast(db)
        val hasChildren = CivilRegistryQueryExecutor.hasTable(db, CivilRegistryChildrenSchema.TABLE_NAME)
        val totalChildren = if (hasChildren) CivilRegistryQueryExecutor.queryChildrenCountFast(db) else 0L
        val hasAgeView = CivilRegistryQueryExecutor.hasView(db, CivilRegistryChildrenSchema.VIEW_NAME)
        val hasFts = CivilRegistryQueryExecutor.hasTable(db, CivilRegistryChildrenSchema.FTS_TABLE_NAME)
        return CivilRegistryDbStatus.Ready(
            totalRecords = totalRows,
            dbPath = path,
            hasChildrenRegistry = hasChildren,
            totalChildrenRecords = totalChildren,
            hasChildrenAgeView = hasAgeView,
            hasChildrenFts = hasFts
        )
    }

    private fun resolveUriSizeBytes(uri: Uri): Long {
        try {
            appContext.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (idx >= 0 && !cursor.isNull(idx)) {
                        val size = cursor.getLong(idx)
                        if (size > 0L) return size
                    }
                }
            }
        } catch (_: Throwable) {
        }
        return try {
            appContext.contentResolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                if (afd.length > 0L) afd.length else -1L
            } ?: -1L
        } catch (_: Throwable) {
            -1L
        }
    }

    private fun resolveOrProvisionDatabaseFile(): File? {
        val dbName = CivilRegistrySchema.DATABASE_FILE_NAME
        val candidates = listOfNotNull(
            appContext.getDatabasePath(dbName),
            File(appContext.filesDir, dbName),
            appContext.getExternalFilesDir(null)?.let { File(it, dbName) }
        )

        candidates.firstOrNull { it.exists() && it.length() > 0L }?.let { return it }

        val targetFile = appContext.getDatabasePath(dbName)
        val hasAsset = try {
            appContext.assets.list("")?.contains(dbName) == true
        } catch (_: Exception) {
            false
        }
        if (!hasAsset) return null

        targetFile.parentFile?.mkdirs()
        val tempFile = File(targetFile.parentFile, "$dbName.copying")
        appContext.assets.open(dbName).use { input ->
            FileOutputStream(tempFile).use { output ->
                val buffer = ByteArray(COPY_BUFFER_BYTES)
                while (true) {
                    val bytes = input.read(buffer)
                    if (bytes <= 0) break
                    output.write(buffer, 0, bytes)
                }
                output.flush()
            }
        }
        if (targetFile.exists()) targetFile.delete()
        if (!tempFile.renameTo(targetFile)) {
            tempFile.copyTo(targetFile, overwrite = true)
            tempFile.delete()
        }
        return targetFile.takeIf { it.exists() && it.length() > 0L }
    }

    private fun openReadOnlyInternal(file: File): SQLiteDatabase {
        synchronized(dbLock) {
            val current = readOnlyDb
            if (current != null && current.isOpen && activeDbPath == file.absolutePath) {
                return current
            }
            closeInternalLocked()
            val opened = SQLiteDatabase.openDatabase(
                file.absolutePath,
                null,
                SQLiteDatabase.OPEN_READONLY or SQLiteDatabase.NO_LOCALIZED_COLLATORS
            )
            try {
                opened.rawQuery("PRAGMA cache_size = -12000", null).close()
                opened.rawQuery("PRAGMA temp_store = MEMORY", null).close()
            } catch (_: Throwable) {
            }
            readOnlyDb = opened
            activeDbPath = file.absolutePath
            return opened
        }
    }

    private fun getOpenedReadOnlyDb(): SQLiteDatabase? {
        synchronized(dbLock) {
            val current = readOnlyDb
            if (current != null && current.isOpen) return current
        }
        val file = resolveOrProvisionDatabaseFile() ?: return null
        return openReadOnlyInternal(file)
    }

    private fun closeInternalLocked() {
        try {
            readOnlyDb?.close()
        } catch (_: Throwable) {
        } finally {
            readOnlyDb = null
            activeDbPath = null
        }
    }
}
