package com.humanitarian.aidmanagement.civilregistry.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.CancellationSignal
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistryDbStatus
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySchema
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchPage
import com.humanitarian.aidmanagement.civilregistry.model.CivilRegistrySearchQuery
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * مصدر البيانات الفعلي لقاعدة civil_registry.db (478,638 سجل) بوضع القراءة فقط
 *
 * ضمانات هندسية صارمة:
 * 1. فتح civil_registry.db حصراً بوضع SQLiteDatabase.OPEN_READONLY.
 * 2. مفصول 100% عن قاعدة Room الخاصة بالمشروع.
 * 3. يستفيد من الفهارس الموجودة مسبقاً (idx_citizen_id, idx_citizen_name, idx_wife_id).
 */
class SqliteCivilRegistryDataSource(
    private val appContext: Context
) : CivilRegistryDataSource {

    companion object {
        private const val COPY_BUFFER_BYTES = 64 * 1024
    }

    private val dbLock = Any()
    @Volatile
    private var readOnlyDb: SQLiteDatabase? = null
    @Volatile
    private var activeDbPath: String? = null

    override suspend fun ensureDatabaseReady(): CivilRegistryDbStatus = withContext(Dispatchers.IO) {
        try {
            val dbFile = resolveOrProvisionDatabaseFile()
                ?: return@withContext CivilRegistryDbStatus.Missing(
                    expectedPath = appContext.getDatabasePath(CivilRegistrySchema.DATABASE_FILE_NAME).absolutePath
                )

            val db = openReadOnlyInternal(dbFile)
            val totalRows = CivilRegistryQueryExecutor.queryTotalCountFast(db)
            CivilRegistryDbStatus.Ready(totalRecords = totalRows, dbPath = dbFile.absolutePath)
        } catch (t: Throwable) {
            CivilRegistryDbStatus.Error(
                message = t.localizedMessage ?: "تعذر فتح قاعدة السجل المدني بوضع القراءة فقط."
            )
        }
    }

    /**
     * ربط نسخة محلية من civil_registry.db يختارها المستخدم من ذاكرة الجهاز (للقراءة فقط)
     */
    suspend fun importExternalDatabase(uri: Uri): CivilRegistryDbStatus = withContext(Dispatchers.IO) {
        try {
            val targetFile = appContext.getDatabasePath(CivilRegistrySchema.DATABASE_FILE_NAME)
            targetFile.parentFile?.mkdirs()
            val tempFile = File(targetFile.parentFile, "${CivilRegistrySchema.DATABASE_FILE_NAME}.tmp")

            appContext.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    val buffer = ByteArray(COPY_BUFFER_BYTES)
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        output.write(buffer, 0, read)
                    }
                    output.flush()
                }
            } ?: return@withContext CivilRegistryDbStatus.Error("تعذر قراءة الملف المختار من الجهاز.")

            val testDb = SQLiteDatabase.openDatabase(
                tempFile.absolutePath,
                null,
                SQLiteDatabase.OPEN_READONLY or SQLiteDatabase.NO_LOCALIZED_COLLATORS
            )
            val tableExists = try {
                testDb.rawQuery(
                    "SELECT name FROM sqlite_master WHERE type='table' AND name = ?",
                    arrayOf(CivilRegistrySchema.TABLE_NAME)
                ).use { it.moveToFirst() }
            } finally {
                testDb.close()
            }

            if (!tableExists) {
                tempFile.delete()
                return@withContext CivilRegistryDbStatus.Error(
                    "الملف المختار لا يحتوي على جدول السجل المدني المعتمد (${CivilRegistrySchema.TABLE_NAME})."
                )
            }

            synchronized(dbLock) {
                closeInternalLocked()
                if (targetFile.exists()) targetFile.delete()
                if (!tempFile.renameTo(targetFile)) {
                    tempFile.copyTo(targetFile, overwrite = true)
                    tempFile.delete()
                }
            }

            val db = openReadOnlyInternal(targetFile)
            val totalRows = CivilRegistryQueryExecutor.queryTotalCountFast(db)
            CivilRegistryDbStatus.Ready(totalRecords = totalRows, dbPath = targetFile.absolutePath)
        } catch (t: Throwable) {
            CivilRegistryDbStatus.Error(
                message = t.localizedMessage ?: "حدث خطأ أثناء ربط ملف civil_registry.db."
            )
        }
    }

    override suspend fun search(
        query: CivilRegistrySearchQuery,
        offset: Int,
        pageSize: Int,
        cancellationSignal: CancellationSignal?
    ): CivilRegistrySearchPage = withContext(Dispatchers.IO) {
        val db = getOpenedReadOnlyDb()
            ?: return@withContext CivilRegistrySearchPage(emptyList(), hasMore = false, offset = offset.coerceAtLeast(0))

        CivilRegistryQueryExecutor.executeSearch(
            db = db,
            query = query,
            offset = offset,
            pageSize = pageSize,
            cancellationSignal = cancellationSignal
        )
    }

    override fun close() {
        synchronized(dbLock) {
            closeInternalLocked()
        }
    }

    private fun resolveOrProvisionDatabaseFile(): File? {
        val dbName = CivilRegistrySchema.DATABASE_FILE_NAME
        val candidates = listOfNotNull(
            appContext.getDatabasePath(dbName),
            File(appContext.filesDir, dbName),
            appContext.getExternalFilesDir(null)?.let { File(it, dbName) }
        )

        candidates.firstOrNull { it.exists() && it.length() > 0L }?.let { return it }

        val targetFile = appContext.getDatabasePath(dbName)
        val hasAsset = try {
            appContext.assets.list("")?.contains(dbName) == true
        } catch (_: Exception) {
            false
        }
        if (!hasAsset) return null

        targetFile.parentFile?.mkdirs()
        val tempFile = File(targetFile.parentFile, "$dbName.copying")
        appContext.assets.open(dbName).use { input ->
            FileOutputStream(tempFile).use { output ->
                val buffer = ByteArray(COPY_BUFFER_BYTES)
                while (true) {
                    val bytes = input.read(buffer)
                    if (bytes <= 0) break
                    output.write(buffer, 0, bytes)
                }
                output.flush()
            }
        }
        if (targetFile.exists()) targetFile.delete()
        if (!tempFile.renameTo(targetFile)) {
            tempFile.copyTo(targetFile, overwrite = true)
            tempFile.delete()
        }
        return targetFile.takeIf { it.exists() && it.length() > 0L }
    }

    private fun openReadOnlyInternal(file: File): SQLiteDatabase {
        synchronized(dbLock) {
            val current = readOnlyDb
            if (current != null && current.isOpen && activeDbPath == file.absolutePath) {
                return current
            }
            closeInternalLocked()
            val opened = SQLiteDatabase.openDatabase(
                file.absolutePath,
                null,
                SQLiteDatabase.OPEN_READONLY or SQLiteDatabase.NO_LOCALIZED_COLLATORS
            )
            try {
                opened.rawQuery("PRAGMA cache_size = -8000", null).close()
                opened.rawQuery("PRAGMA temp_store = MEMORY", null).close()
            } catch (_: Throwable) {
            }
            readOnlyDb = opened
            activeDbPath = file.absolutePath
            return opened
        }
    }

    private fun getOpenedReadOnlyDb(): SQLiteDatabase? {
        synchronized(dbLock) {
            val current = readOnlyDb
            if (current != null && current.isOpen) return current
        }
        val file = resolveOrProvisionDatabaseFile() ?: return null
        return openReadOnlyInternal(file)
    }

    private fun closeInternalLocked() {
        try {
            readOnlyDb?.close()
        } catch (_: Throwable) {
        } finally {
            readOnlyDb = null
            activeDbPath = null
        }
    }
}
