package com.humanitarian.aidmanagement.ui.screens.reports

import android.app.DatePickerDialog
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.dao.AidClassificationStat
import com.humanitarian.aidmanagement.data.local.dao.DamageTypeBreakdown
import com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord
import com.humanitarian.aidmanagement.data.local.dao.LocalityFamilyCount
import com.humanitarian.aidmanagement.data.local.dao.SubAreaFamilyCount
import com.humanitarian.aidmanagement.data.local.dao.WarDamageStats
import com.humanitarian.aidmanagement.data.local.dao.ProjectAggregatedSummary
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.*
import com.humanitarian.aidmanagement.util.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.ui.components.ExportColumnSelectorDialog
import com.humanitarian.aidmanagement.util.ExportColumnRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

sealed class PendingReportExport {
    data class Project(
        val projectId: Long,
        val isExcel: Boolean,
        val defaultFileName: String,
        val selectedColumns: List<String> = emptyList()
    ) : PendingReportExport()

    data class Locality(
        val localityName: String,
        val defaultFileName: String
    ) : PendingReportExport()

    data class Comprehensive(
        val fromDate: String,
        val toDate: String,
        val isExcel: Boolean,
        val defaultFileName: String,
        val selectedColumns: List<String> = emptyList()
    ) : PendingReportExport()
}

sealed class PendingExcelExport {
    data class Project(val projectId: Long, val defaultFileName: String) : PendingExcelExport()
    data class Locality(val localityName: String, val defaultFileName: String) : PendingExcelExport()
    data class Comprehensive(val fromDate: String, val toDate: String, val defaultFileName: String) : PendingExcelExport()
}

enum class ReportDashboardTab(val label: String) {
    PROJECT("المشاريع والمستفيدين"),
    LOCALITY("المحليات والشعب"),
    COMPREHENSIVE_PERIOD("التوزيع الشامل حسب الفترة")
}

enum class VisualChartTab(val label: String) {
    LOCALITY_DISTRIBUTION("توزيع المحليات"),
    AID_CATEGORIES("تصنيفات المساعدات"),
    FAMILY_CLASSIFICATIONS("تصنيفات الأسر"),
    PROJECT_COMPLETION("معدلات إنجاز المشاريع")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    repository: AidRepository,
    viewModel: ReportsViewModel = viewModel(factory = ReportsViewModel.Factory(repository)),
    onNavigateBack: () -> Unit,
    onNavigateToDynamicReportExport: () -> Unit = {}
) {
    val context = LocalContext.current
    val exporter = remember { ProfessionalReportExporter(context) }
    val scope = rememberCoroutineScope()

    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val canExportExcel = remember(currentUser) { AccessControlManager.canExportExcel() }
    val canExportPdf = remember(currentUser) { AccessControlManager.canExportPdf() }

    val geoStats by viewModel.geoDamageStats.collectAsStateWithLifecycle()
    val dynamicLocalities by viewModel.localities.collectAsStateWithLifecycle()
    val assignedSubArea by viewModel.assignedSubArea.collectAsStateWithLifecycle()
    val assignedDivisions by viewModel.assignedDivisions.collectAsStateWithLifecycle()
    val vmLocalityLocked by viewModel.isLocalityLocked.collectAsStateWithLifecycle()
    val vmBranchLocked by viewModel.isBranchLocked.collectAsStateWithLifecycle()
    val vmCanViewAllBranches by viewModel.canViewAllBranches.collectAsStateWithLifecycle()
    val vmLockedBranchName by viewModel.lockedBranchName.collectAsStateWithLifecycle()
    val isLocalityLocked = vmLocalityLocked || assignedSubArea != null
    val isBranchLocked = vmBranchLocked || assignedDivisions.size == 1
    val canViewAllBranches = vmCanViewAllBranches && assignedDivisions.isEmpty()
    val lockedBranchName = vmLockedBranchName ?: if (assignedDivisions.size == 1) assignedDivisions.first() else null

    // نطاق التاريخ
    val defaultCalendar = Calendar.getInstance()
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(defaultCalendar.time)
    val past30DaysCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -30) }
    val past30DaysStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(past30DaysCal.time)

    val fromDate by viewModel.fromDate.collectAsStateWithLifecycle()
    val toDate by viewModel.toDate.collectAsStateWithLifecycle()
    val selectedPreset by viewModel.selectedPreset.collectAsStateWithLifecycle()

    // حالات التبويب وحركة الظهور الانسيابية
    var selectedReportTab by remember { mutableStateOf(ReportDashboardTab.PROJECT) }
    var selectedChartTab by remember { mutableStateOf(VisualChartTab.LOCALITY_DISTRIBUTION) }
    var isDashboardVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isDashboardVisible = true
    }

    // بيانات من قاعدة البيانات مستلمة عبر تدفقات تفاعلية مستمرة لمنع التصفير
    val stats by viewModel.dashboardStats.collectAsStateWithLifecycle()
    val localityStats by viewModel.localityStats.collectAsStateWithLifecycle()
    val aidTypeStats by viewModel.aidTypeStats.collectAsStateWithLifecycle()
    val distinctAidCategories by viewModel.distinctAidCategories.collectAsStateWithLifecycle()
    val aidClassificationStats by viewModel.aidClassificationStats.collectAsStateWithLifecycle()
    val subAreaRatios by viewModel.subAreaRatios.collectAsStateWithLifecycle()
    val residentStats by viewModel.residentStats.collectAsStateWithLifecycle()
    val warDamageStats by viewModel.warDamageStats.collectAsStateWithLifecycle()
    val activeProjects by viewModel.activeProjects.collectAsStateWithLifecycle()
    val localitiesList by viewModel.localitiesList.collectAsStateWithLifecycle()
    val periodDeliveryCount by viewModel.periodDeliveryCount.collectAsStateWithLifecycle()

    // اختيارات التقارير المحددة
    var selectedProjectId by remember { mutableStateOf<Long?>(null) }
    var selectedLocalityId by remember { mutableStateOf<Int?>(null) }
    var isProjectPickerExpanded by remember { mutableStateOf(false) }
    var isLocalityPickerExpanded by remember { mutableStateOf(false) }

    val projectPreviewList by viewModel.projectPreviewList.collectAsStateWithLifecycle()
    val isLoadingProjectPreview by viewModel.isLoadingProjectPreview.collectAsStateWithLifecycle()
    val comprehensivePreviewList by viewModel.comprehensivePreviewList.collectAsStateWithLifecycle()
    val isLoadingComprehensivePreview by viewModel.isLoadingComprehensivePreview.collectAsStateWithLifecycle()
    val projectSummaries by viewModel.projectSummaries.collectAsStateWithLifecycle()

    LaunchedEffect(activeProjects) {
        if (selectedProjectId == null && activeProjects.isNotEmpty()) {
            val firstId = activeProjects.first().projectID
            selectedProjectId = firstId
            viewModel.loadProjectPreview(firstId)
        }
    }
    LaunchedEffect(localitiesList) {
        if (selectedLocalityId == null && localitiesList.isNotEmpty()) {
            selectedLocalityId = localitiesList.first().LocalityID
        }
    }

    // حالة التصدير عبر الـ ViewModel مع إدارة التخزين الآمن SAF
    val isExporting = viewModel.isExporting
    var pendingExport by remember { mutableStateOf<PendingReportExport?>(null) }
    var exportedFile by remember { mutableStateOf<File?>(null) }
    var exportedFileType by remember { mutableStateOf<String?>(null) } // "PDF" or "EXCEL"
    var exportStatusMessage by remember { mutableStateOf<String?>(null) }

    // حالة حوار اختيار وتخصيص الأعمدة
    var showColumnSelectorDialog by remember { mutableStateOf(false) }
    var columnSelectorFormat by remember { mutableStateOf("EXCEL") }
    var columnSelectorReportTitle by remember { mutableStateOf("") }

    // مشغل نظام التخزين الآمن (Storage Access Framework) لحفظ ملفات Excel عبر Cache-First
    val createExcelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri: Uri? ->
        if (uri != null) {
            if (!canExportExcel) {
                pendingExport = null
                return@rememberLauncherForActivityResult
            }
            val pending = pendingExport ?: return@rememberLauncherForActivityResult
            scope.launch {
                viewModel.isExporting = true
                try {
                    val result: Result<Unit> = withContext(Dispatchers.IO) {
                        when (pending) {
                            is PendingReportExport.Project -> {
                                val prj = activeProjects.firstOrNull { it.projectID == pending.projectId }
                                    ?: return@withContext Result.failure(Exception("بيانات المشروع المختار غير متوفرة"))

                                val aidTypes = repository.getActiveAidTypes().first().associateBy { it.aidTypeID }

                                val meta = listOf(
                                    "المشروع:" to prj.projectName,
                                    "رقم المشروع:" to prj.projectNumber,
                                    "الجهة الممولة:" to (prj.fundingInstitution ?: "غير محدد"),
                                    "المشرف المسؤول:" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات"),
                                    "نوع المساعدة:" to (aidTypes[prj.aidTypeID]?.aidTypeName ?: "مساعدات إغاثية"),
                                    "تاريخ التقرير:" to SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
                                )
                                exporter.exportDynamicFamiliesExcelChunkedToUri(
                                    uri = uri,
                                    title = "كشف مستفيدي المشروع الإنساني - ${prj.projectName}",
                                    metaRows = meta,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS },
                                    chunkSize = 5000
                                ) { limit, offset ->
                                    repository.getProjectBeneficiariesWithFamiliesChunk(pending.projectId, limit, offset)
                                }
                            }
                            is PendingReportExport.Locality -> {
                                val totalFam = repository.getTotalFamiliesCountForLocalityByName(pending.localityName)
                                val reportData = LocalityReportData(
                                    localityName = pending.localityName,
                                    subAreas = subAreaRatios,
                                    totalFamilies = totalFam,
                                    totalBeneficiaries = subAreaRatios.sumOf { it.eligibleFamiliesCount },
                                    totalDelivered = subAreaRatios.sumOf { it.deliveredBeneficiariesCount },
                                    dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                    supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                )
                                exporter.exportLocalitySubAreasExcelToUri(uri, reportData)
                            }
                            is PendingReportExport.Comprehensive -> {
                                val meta = listOf(
                                    "نطاق الفترة:" to "${pending.fromDate} إلى ${pending.toDate}",
                                    "إجمالي المساعدات:" to "$periodDeliveryCount طرد",
                                    "المشرف المسؤول:" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات"),
                                    "تاريخ التقرير:" to SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
                                )
                                exporter.exportDynamicFamiliesExcelChunkedToUri(
                                    uri = uri,
                                    title = "تقرير التوزيع الشامل والعمليات الميدانية",
                                    metaRows = meta,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS },
                                    chunkSize = 5000
                                ) { limit, offset ->
                                    repository.getBeneficiariesWithFamiliesInDateRangeChunk(pending.fromDate, pending.toDate, limit, offset)
                                }
                            }
                        }
                    }

                    result.onSuccess {
                        exportedFile = null
                        exportStatusMessage = "تم حفظ ملف Excel بنجاح بالأعمدة المخصصة عبر التخزين الآمن (SAF)."
                        Toast.makeText(context, "تم حفظ ملف الإكسل بنجاح في الموقع المختار!", Toast.LENGTH_LONG).show()
                    }.onFailure { err ->
                        exportStatusMessage = "خطأ أثناء حفظ ملف Excel: ${err.message}"
                        Toast.makeText(context, "فشل حفظ ملف الإكسل: ${err.message ?: "حدث خطأ"}", Toast.LENGTH_LONG).show()
                    }
                } catch (t: Throwable) {
                    exportStatusMessage = "خطأ أثناء تصدير Excel: ${t.message}"
                    Toast.makeText(context, "فشل تصدير ملف الإكسل: ${t.message ?: "حدث خطأ غير متوقع"}", Toast.LENGTH_LONG).show()
                } finally {
                    viewModel.isExporting = false
                    pendingExport = null
                }
            }
        } else {
            pendingExport = null
        }
    }

    // مشغل نظام التخزين الآمن (Storage Access Framework) لحفظ مستندات PDF عبر Cache-First
    val createPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        if (uri != null) {
            if (!canExportPdf) {
                pendingExport = null
                return@rememberLauncherForActivityResult
            }
            val pending = pendingExport ?: return@rememberLauncherForActivityResult
            scope.launch {
                viewModel.isExporting = true
                try {
                    val result: Result<Unit> = withContext(Dispatchers.IO) {
                        when (pending) {
                            is PendingReportExport.Project -> {
                                val prj = activeProjects.firstOrNull { it.projectID == pending.projectId }
                                    ?: return@withContext Result.failure(Exception("بيانات المشروع المختار غير متوفرة"))
                                val combined = repository.getProjectBeneficiariesWithFamilies(pending.projectId)
                                if (combined.isEmpty()) {
                                    return@withContext Result.failure(Exception("لا توجد سجلات مستفيدين لهذا المشروع حتى الآن"))
                                }
                                val aidTypes = repository.getActiveAidTypes().first().associateBy { it.aidTypeID }

                                val meta = listOf(
                                    "المشروع" to prj.projectName,
                                    "رقم المشروع" to prj.projectNumber,
                                    "الجهة الممولة" to (prj.fundingInstitution ?: "غير محدد"),
                                    "المشرف" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات"),
                                    "نوع المساعدة" to (aidTypes[prj.aidTypeID]?.aidTypeName ?: "مساعدات إغاثية")
                                )
                                exporter.exportDynamicFamiliesPdfToUri(
                                    uri = uri,
                                    title = "كشف مستفيدي المشروع الإنساني المعتمد",
                                    subtitle = "مشروع: ${prj.projectName} (${prj.projectNumber})",
                                    metaRows = meta,
                                    records = combined,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS }
                                )
                            }
                            is PendingReportExport.Comprehensive -> {
                                val combined = repository.getBeneficiariesWithFamiliesInDateRange(pending.fromDate, pending.toDate)
                                if (combined.isEmpty()) {
                                    return@withContext Result.failure(Exception("لا توجد سجلات توزيع في الفترة المحددة"))
                                }
                                val meta = listOf(
                                    "النطاق الزمني" to "${pending.fromDate} إلى ${pending.toDate}",
                                    "إجمالي المساعدات" to "${combined.size} طرد",
                                    "المشرف المسؤول" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات")
                                )
                                exporter.exportDynamicFamiliesPdfToUri(
                                    uri = uri,
                                    title = "تقرير التوزيع الشامل والعمليات الميدانية",
                                    subtitle = "تغطية العمليات من تاريخ ${pending.fromDate} إلى ${pending.toDate}",
                                    metaRows = meta,
                                    records = combined,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS }
                                )
                            }
                            is PendingReportExport.Locality -> {
                                Result.failure(Exception("تقرير المحلية متوفر عبر المعاينة والطباعة المباشرة"))
                            }
                        }
                    }

                    result.onSuccess {
                        exportedFile = null
                        exportStatusMessage = "تم حفظ مستند PDF بنجاح وفق الأعمدة المخصصة عبر التخزين الآمن (SAF)."
                        Toast.makeText(context, "تم حفظ مستند PDF بنجاح في الموقع المختار!", Toast.LENGTH_LONG).show()
                    }.onFailure { err ->
                        exportStatusMessage = "خطأ أثناء حفظ مستند PDF: ${err.message}"
                        Toast.makeText(context, "فشل حفظ مستند PDF: ${err.message ?: "حدث خطأ"}", Toast.LENGTH_LONG).show()
                    }
                } catch (t: Throwable) {
                    exportStatusMessage = "خطأ أثناء تصدير PDF: ${t.message}"
                    Toast.makeText(context, "فشل تصدير مستند PDF: ${t.message ?: "حدث خطأ غير متوقع"}", Toast.LENGTH_LONG).show()
                } finally {
                    viewModel.isExporting = false
                    pendingExport = null
                }
            }
        } else {
            pendingExport = null
        }
    }

    // دالة تحميل وتحديث البيانات
    fun loadData() {
        viewModel.refreshData()
    }

    LaunchedEffect(fromDate, toDate, currentUser) {
        viewModel.refreshData()
    }

    // دوال منتقي التاريخ
    fun openDatePicker(isFrom: Boolean) {
        val calendar = Calendar.getInstance()
        val currentStr = if (isFrom) fromDate else toDate
        val parts = currentStr.split("-")
        val y = parts.getOrNull(0)?.toIntOrNull() ?: calendar.get(Calendar.YEAR)
        val m = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val d = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(context, { _, year, month, dayOfMonth ->
            val formatted = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth)
            if (isFrom) {
                viewModel.setDateRange(formatted, toDate)
            } else {
                viewModel.setDateRange(fromDate, formatted)
            }
        }, y, m, d).show()
    }

    fun applyPreset(preset: String) {
        viewModel.applyPreset(preset)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "لوحة التقارير والتحليلات البيانية",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                "كشوفات A4 PDF رسمية وتصدير إكسل Excel (.xlsx)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            viewModel.resetFilters()
                            onNavigateBack()
                        }) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = onNavigateToDynamicReportExport) {
                            Icon(Icons.Default.Insights, contentDescription = "مركز التقارير الديناميكي")
                        }
                        IconButton(onClick = { loadData() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "تحديث البيانات")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            val calmGreenBackdrop = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF0D9488).copy(alpha = 0.06f),
                    MaterialTheme.colorScheme.background,
                    Color(0xFF0284C7).copy(alpha = 0.04f)
                )
            )
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(calmGreenBackdrop)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 84.dp)
            ) {
                // =========================================================================
                // 1. شريط فلترة الفترة الزمنية (Interactive Date Range Picker)
                // =========================================================================
                item {
                    AnimatedVisibility(
                        visible = isDashboardVisible,
                        enter = fadeIn(tween(360)) + slideInVertically(tween(360)) { it / 8 }
                    ) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            border = BorderStroke(1.dp, Color(0xFF0D9488).copy(alpha = 0.16f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .animateContentSize(animationSpec = tween(280))
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Text(
                                        text = "نطاق الفلترة الزمنية للتقارير والإحصائيات",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = "$periodDeliveryCount مساعدة منفذة",
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            // أزرار الفترات السريعة (Presets)
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val presets = listOf("آخر 7 أيام", "آخر 30 يوماً", "آخر 90 يوماً", "كافة الفترات")
                                items(presets) { p ->
                                    FilterChip(
                                        selected = selectedPreset == p,
                                        onClick = { applyPreset(p) },
                                        label = { Text(p, fontSize = 11.sp) }
                                    )
                                }
                            }

                            // مربعي التاريخ التفاعليين
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedCard(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { openDatePicker(true) },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("من تاريخ:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(fromDate, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }

                                OutlinedCard(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { openDatePicker(false) },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("إلى تاريخ:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(toDate, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                    }
                }

                // =========================================================================
                // 2. إشعار نتيجة التصدير الأخير مع أزرار الإجراءات
                // =========================================================================
                if (exportedFile != null) {
                    item {
                        val file = exportedFile!!
                        val isPdf = exportedFileType == "PDF"
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = if (isPdf) Color(0xFF10B981).copy(alpha = 0.12f) else Color(0xFF0284C7).copy(alpha = 0.12f)),
                            border = BorderStroke(1.5.dp, if (isPdf) Color(0xFF10B981).copy(alpha = 0.5f) else Color(0xFF0284C7).copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (isPdf) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFF0284C7).copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.TableChart,
                                            contentDescription = null,
                                            tint = if (isPdf) Color(0xFF047857) else Color(0xFF0284C7),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isPdf) "تم توليد مستند A4 PDF بنجاح!" else "تم إنشاء ملف Excel (.xlsx) بنجاح!",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = if (isPdf) Color(0xFF047857) else Color(0xFF0369A1)
                                        )
                                        Text(
                                            text = "${file.name} • ${file.length() / 1024} كيلوبايت",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val mime = if (isPdf) "application/pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                            exporter.openFile(file, mime)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("فتح الملف", fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = {
                                            val mime = if (isPdf) "application/pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                            exporter.shareFile(file, mime, file.name)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("مشاركة", fontSize = 11.sp)
                                    }

                                    if (isPdf) {
                                        Button(
                                            onClick = { exporter.printPdfReport(file) },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("طباعة A4", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (exportStatusMessage != null) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = exportStatusMessage ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }

                // =========================================================================
                // 3. لوحة الرسوم البيانية التفاعلية (Visual Analytics Dashboard)
                // =========================================================================
                item {
                    AnimatedVisibility(
                        visible = isDashboardVisible,
                        enter = fadeIn(tween(450, delayMillis = 90)) + slideInVertically(tween(450, delayMillis = 90)) { it / 6 }
                    ) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            border = BorderStroke(1.dp, Color(0xFF0D9488).copy(alpha = 0.18f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .animateContentSize(animationSpec = tween(320))
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = Color(0xFF0D9488).copy(alpha = 0.12f),
                                            modifier = Modifier.size(34.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Default.Analytics, contentDescription = null, tint = Color(0xFF0D9488), modifier = Modifier.size(20.dp))
                                            }
                                        }
                                        Column {
                                            Text(
                                                text = "المخططات والتحليلات البيانية الحية",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "بيانات تفاعلية محدثة من قاعدة البيانات",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = Color(0xFF10B981).copy(alpha = 0.12f),
                                        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.25f))
                                    ) {
                                        Text(
                                            text = "مباشر",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF047857),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                // أزرار التبديل السلس بين المخططات البيانية
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    items(VisualChartTab.values()) { tab ->
                                        val isSelected = selectedChartTab == tab
                                        Surface(
                                            onClick = { selectedChartTab = tab },
                                            shape = RoundedCornerShape(14.dp),
                                            color = if (isSelected) Color(0xFF0D9488) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                            contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            border = BorderStroke(
                                                1.dp,
                                                if (isSelected) Color(0xFF0D9488) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)
                                            ),
                                            shadowElevation = if (isSelected) 2.dp else 0.dp
                                        ) {
                                            Text(
                                                text = tab.label,
                                                fontSize = 11.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                            )
                                        }
                                    }
                                }

                                // عرض المخطط البياني المختار بحركة انتقالية ناعمة
                                AnimatedContent(
                                    targetState = selectedChartTab,
                                    transitionSpec = {
                                        (fadeIn(tween(260)) + slideInVertically(tween(260)) { it / 12 })
                                            .togetherWith(fadeOut(tween(180)))
                                    },
                                    label = "VisualChartTransition"
                                ) { activeTab ->
                                    when (activeTab) {
                                        VisualChartTab.LOCALITY_DISTRIBUTION -> {
                                            LocalityDistributionDonutChart(localityStats = localityStats)
                                        }
                                        VisualChartTab.AID_CATEGORIES -> {
                                            AidCategoriesDistributionChart(
                                                classificationStats = aidClassificationStats
                                            )
                                        }
                                        VisualChartTab.FAMILY_CLASSIFICATIONS -> {
                                            FamilyClassificationsChart(
                                                residentStats = residentStats,
                                                warDamageStats = warDamageStats
                                            )
                                        }
                                        VisualChartTab.PROJECT_COMPLETION -> {
                                            ProjectCompletionRatesCard(
                                                projects = activeProjects,
                                                projectSummaries = projectSummaries
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // =========================================================================
                // 3.5. بطاقة إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية
                // (Dynamic Geographic Scope & Area Damage Statistics)
                // =========================================================================
                item {
                    DynamicReportsGeoDamageCard(
                        localities = dynamicLocalities,
                        selectedLocality = geoStats.selectedLocality,
                        selectedSubArea = geoStats.selectedSubArea,
                        availableSubAreas = geoStats.availableSubAreas,
                        localityFamilyCount = geoStats.localityFamilyCount,
                        subAreaFamilyCount = geoStats.subAreaFamilyCount,
                        localityCounts = geoStats.localityCounts,
                        completelyDestroyedCount = geoStats.completelyDestroyedCount,
                        warDamageStats = geoStats.warDamageStats,
                        damageDistribution = geoStats.damageDistribution,
                        damageDetailsByRegion = geoStats.damageDetailsByRegion,
                        isLocalityLocked = isLocalityLocked,
                        isBranchLocked = isBranchLocked,
                        canViewAllBranches = canViewAllBranches,
                        lockedBranchName = lockedBranchName,
                        onLocalitySelected = { locName ->
                            viewModel.selectLocality(locName)
                        },
                        onSubAreaSelected = { sub ->
                            viewModel.selectSubArea(sub)
                        }
                    )
                }

                // =========================================================================
                // 4. مركز توليد وتصدير التقارير المعتمدة (Specific Report Types)
                // =========================================================================
                item {
                    AnimatedVisibility(
                        visible = isDashboardVisible,
                        enter = fadeIn(tween(520, delayMillis = 180)) + slideInVertically(tween(520, delayMillis = 180)) { it / 6 }
                    ) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .animateContentSize(animationSpec = tween(300))
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text(
                                    text = "مركز استخراج التقارير وتصدير المستندات",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                // ألسنة التبويب للتقارير الثلاثة
                                TabRow(
                                    selectedTabIndex = selectedReportTab.ordinal,
                                    containerColor = Color.Transparent,
                                    contentColor = MaterialTheme.colorScheme.primary
                                ) {
                                    ReportDashboardTab.values().forEach { tab ->
                                        Tab(
                                            selected = selectedReportTab == tab,
                                            onClick = { selectedReportTab = tab },
                                            text = { Text(tab.label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                                        )
                                    }
                                }

                                // محتوى التبويب المختار بحركة ناعمة
                                when (selectedReportTab) {
                                ReportDashboardTab.PROJECT -> {
                                    // أ) تقرير مشروع ومستفيدوه
                                    ProjectReportSection(
                                        projects = activeProjects,
                                        selectedProjectId = selectedProjectId,
                                        onSelectProject = { 
                                            selectedProjectId = it
                                            viewModel.selectProject(it)
                                        },
                                        isExpanded = isProjectPickerExpanded,
                                        onToggleExpand = { isProjectPickerExpanded = !isProjectPickerExpanded },
                                        previewList = projectPreviewList,
                                        isLoadingPreview = isLoadingProjectPreview,
                                        isExporting = isExporting,
                                        canExportPdf = canExportPdf,
                                        canExportExcel = canExportExcel,
                                        onExportPdf = {
                                            if (!canExportPdf) return@ProjectReportSection
                                            val prjId = selectedProjectId ?: return@ProjectReportSection
                                            val prj = activeProjects.firstOrNull { it.projectID == prjId }
                                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                            val safeNumber = prj?.projectNumber?.replace(Regex("[^a-zA-Z0-9_-]"), "_") ?: prjId.toString()
                                            val defaultFileName = "Project_${safeNumber}_$timeStamp.pdf"
                                            columnSelectorFormat = "PDF"
                                            columnSelectorReportTitle = "مشروع ${prj?.projectName ?: prjId.toString()}"
                                            pendingExport = PendingReportExport.Project(prjId, isExcel = false, defaultFileName = defaultFileName)
                                            showColumnSelectorDialog = true
                                        },
                                        onExportExcel = {
                                            if (!canExportExcel) return@ProjectReportSection
                                            val prjId = selectedProjectId ?: return@ProjectReportSection
                                            val prj = activeProjects.firstOrNull { it.projectID == prjId }
                                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                            val safeNumber = prj?.projectNumber?.replace(Regex("[^a-zA-Z0-9_-]"), "_") ?: prjId.toString()
                                            val defaultFileName = "Project_${safeNumber}_$timeStamp.xlsx"
                                            columnSelectorFormat = "EXCEL"
                                            columnSelectorReportTitle = "مشروع ${prj?.projectName ?: prjId.toString()}"
                                            pendingExport = PendingReportExport.Project(prjId, isExcel = true, defaultFileName = defaultFileName)
                                            showColumnSelectorDialog = true
                                        }
                                    )
                                }
                                ReportDashboardTab.LOCALITY -> {
                                    // ب) تقرير محلية وشعبها
                                    LocalityReportSection(
                                        localities = dynamicLocalities,
                                        selectedLocality = geoStats.selectedLocality,
                                        onSelectLocality = { viewModel.selectLocality(it) },
                                        isExpanded = isLocalityPickerExpanded,
                                        onToggleExpand = {
                                            if (!isLocalityLocked) {
                                                isLocalityPickerExpanded = !isLocalityPickerExpanded
                                            }
                                        },
                                        subAreas = subAreaRatios,
                                        isExporting = isExporting,
                                        isLocalityLocked = isLocalityLocked,
                                        canExportPdf = canExportPdf,
                                        canExportExcel = canExportExcel,
                                        onExportPdf = {
                                            if (!canExportPdf) return@LocalityReportSection
                                            val locName = geoStats.selectedLocality.ifBlank { dynamicLocalities.firstOrNull() ?: return@LocalityReportSection }
                                            scope.launch {
                                                viewModel.isExporting = true
                                                try {
                                                    val totalFam = withContext(Dispatchers.IO) {
                                                        repository.getTotalFamiliesCountForLocalityByName(locName)
                                                    }
                                                    val reportData = LocalityReportData(
                                                        localityName = locName,
                                                        subAreas = subAreaRatios,
                                                        totalFamilies = totalFam,
                                                        totalBeneficiaries = subAreaRatios.sumOf { it.eligibleFamiliesCount },
                                                        totalDelivered = subAreaRatios.sumOf { it.deliveredBeneficiariesCount },
                                                        dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                                        supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                                    )
                                                    val result = exporter.generateLocalitySubAreasPdf(reportData)
                                                    result.onSuccess { file ->
                                                        exportedFile = file
                                                        exportedFileType = "PDF"
                                                        exportStatusMessage = "تم توليد تقرير A4 PDF لتغطية المحلية وشعبها بنجاح."
                                                    }.onFailure { err ->
                                                        exportStatusMessage = "خطأ أثناء توليد PDF: ${err.message}"
                                                        Toast.makeText(context, "فشل تصدير التقرير: ${err.message ?: "الذاكرة غير كافية"}", Toast.LENGTH_LONG).show()
                                                    }
                                                } catch (e: Exception) {
                                                    exportStatusMessage = "خطأ أثناء توليد PDF: ${e.message}"
                                                    Toast.makeText(context, "فشل تصدير التقرير: ${e.message}", Toast.LENGTH_LONG).show()
                                                } finally {
                                                    viewModel.isExporting = false
                                                }
                                            }
                                        },
                                        onExportExcel = {
                                            if (!canExportExcel) return@LocalityReportSection
                                            val locName = geoStats.selectedLocality.ifBlank { dynamicLocalities.firstOrNull() ?: return@LocalityReportSection }
                                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                            val safeLoc = locName.trim().replace(Regex("[^a-zA-Z0-9_\u0600-\u06FF-]"), "_")
                                            val defaultFileName = "Locality_${safeLoc}_$timeStamp.xlsx"
                                            pendingExport = PendingReportExport.Locality(locName, defaultFileName)
                                            createExcelLauncher.launch(defaultFileName)
                                        }
                                    )
                                }
                                ReportDashboardTab.COMPREHENSIVE_PERIOD -> {
                                    // ج) تقرير التوزيع الشامل حسب الفترة
                                    ComprehensiveReportSection(
                                        fromDate = fromDate,
                                        toDate = toDate,
                                        periodDeliveryCount = periodDeliveryCount,
                                        localityStats = localityStats,
                                        aidTypeStats = aidTypeStats,
                                        distinctCategories = distinctAidCategories,
                                        previewList = comprehensivePreviewList,
                                        isLoadingPreview = isLoadingComprehensivePreview,
                                        isExporting = isExporting,
                                        canExportPdf = canExportPdf,
                                        canExportExcel = canExportExcel,
                                        onExportPdf = {
                                            if (!canExportPdf) return@ComprehensiveReportSection
                                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                            val defaultFileName = "Comprehensive_${fromDate}_to_${toDate}_$timeStamp.pdf"
                                            columnSelectorFormat = "PDF"
                                            columnSelectorReportTitle = "التوزيع الشامل ($fromDate إلى $toDate)"
                                            pendingExport = PendingReportExport.Comprehensive(fromDate, toDate, isExcel = false, defaultFileName = defaultFileName)
                                            showColumnSelectorDialog = true
                                        },
                                        onExportExcel = {
                                            if (!canExportExcel) return@ComprehensiveReportSection
                                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                            val defaultFileName = "Comprehensive_${fromDate}_to_${toDate}_$timeStamp.xlsx"
                                            columnSelectorFormat = "EXCEL"
                                            columnSelectorReportTitle = "التوزيع الشامل ($fromDate إلى $toDate)"
                                            pendingExport = PendingReportExport.Comprehensive(fromDate, toDate, isExcel = true, defaultFileName = defaultFileName)
                                            showColumnSelectorDialog = true
                                        }
                                    )
                                }
                            }
                        }
                    }
                    }
                }
            }
        }
    }

    // نافذة اختيار وتخصيص أعمدة التصدير (Dynamic Column Chooser Dialog)
    if (showColumnSelectorDialog) {
        val currentPending = pendingExport
        ExportColumnSelectorDialog(
            exportFormat = columnSelectorFormat,
            reportTitle = columnSelectorReportTitle,
            initialSelectedKeys = ExportColumnRegistry.DEFAULT_SELECTED_KEYS,
            onConfirm = { chosenKeys ->
                showColumnSelectorDialog = false
                when (currentPending) {
                    is PendingReportExport.Project -> {
                        pendingExport = currentPending.copy(selectedColumns = chosenKeys)
                        if (currentPending.isExcel) {
                            createExcelLauncher.launch(currentPending.defaultFileName)
                        } else {
                            createPdfLauncher.launch(currentPending.defaultFileName)
                        }
                    }
                    is PendingReportExport.Comprehensive -> {
                        pendingExport = currentPending.copy(selectedColumns = chosenKeys)
                        if (currentPending.isExcel) {
                            createExcelLauncher.launch(currentPending.defaultFileName)
                        } else {
                            createPdfLauncher.launch(currentPending.defaultFileName)
                        }
                    }
                    else -> {}
                }
            },
            onDismiss = {
                showColumnSelectorDialog = false
                pendingExport = null
            }
        )
    }
}

// =========================================================================
// المكونات الفرعية للشاشة
// =========================================================================

@Composable
private fun LocalityDistributionDonutChart(localityStats: List<LocalityDistributionStat>) {
    val activeStats = remember(localityStats) {
        localityStats.filter { it.deliveredAidCount > 0 || it.familiesCount > 0 }
    }
    var listVisible by remember { mutableStateOf(false) }
    LaunchedEffect(activeStats) { listVisible = true }

    if (activeStats.isEmpty()) {
        Box(modifier = Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد بيانات توزيع للمحليات", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        return
    }

    val palette = listOf(
        Color(0xFF0D9488), Color(0xFF0284C7), Color(0xFF10B981),
        Color(0xFFF59E0B), Color(0xFF8B5CF6), Color(0xFFEC4899),
        Color(0xFF06B6D4), Color(0xFFF97316)
    )

    val totalAid = activeStats.sumOf { it.deliveredAidCount }
    val sweepProgress by animateFloatAsState(
        targetValue = if (listVisible) 1f else 0f,
        animationSpec = tween(durationMillis = 650),
        label = "DonutSweep"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .animateContentSize(animationSpec = tween(280)),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // مخطط Canvas دائري Donut مع لمسة زجاجية ناعمة
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D9488).copy(alpha = 0.05f)),
            border = BorderStroke(1.dp, Color(0xFF0D9488).copy(alpha = 0.16f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(modifier = Modifier.size(134.dp), contentAlignment = Alignment.Center) {
                    Canvas(modifier = Modifier.size(118.dp)) {
                        var currentAngle = -90f
                        val strokeWidthPx = 24f

                        activeStats.forEachIndexed { i, stat ->
                            val rawSweep = if (totalAid > 0) (stat.deliveredAidCount.toFloat() / totalAid.toFloat()) * 360f else (360f / activeStats.size)
                            val sweepAngle = rawSweep * sweepProgress
                            val color = palette[i % palette.size]

                            drawArc(
                                color = color,
                                startAngle = currentAngle,
                                sweepAngle = sweepAngle,
                                useCenter = false,
                                style = Stroke(width = strokeWidthPx, cap = StrokeCap.Round)
                            )
                            currentAngle += rawSweep
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$totalAid", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
                        Text("طرد موزع", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                    Text(
                        text = "ملخص توزيع المحليات",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${activeStats.size} محليات نشطة • إجمالي ${activeStats.sumOf { it.familiesCount }} أسرة",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // بطاقات المحليات الفردية بحواف 16.dp وشارات ملونة وحركة دخول سلسة
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 320.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            activeStats.forEachIndexed { i, stat ->
                val color = palette[i % palette.size]
                val percent = if (totalAid > 0) (stat.deliveredAidCount * 100 / totalAid) else 0
                val delay = (i * 45).coerceAtMost(320)

                AnimatedVisibility(
                    visible = listVisible,
                    enter = fadeIn(tween(300, delayMillis = delay)) +
                        slideInVertically(tween(300, delayMillis = delay)) { it / 3 }
                ) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        border = BorderStroke(1.dp, color.copy(alpha = 0.22f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 11.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                )
                                Column {
                                    Text(
                                        text = stat.localityName,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${stat.familiesCount} أسرة مسجلة",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = color.copy(alpha = 0.13f),
                                border = BorderStroke(1.dp, color.copy(alpha = 0.28f))
                            ) {
                                Text(
                                    text = "${stat.deliveredAidCount} طرد ($percent%)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = color,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AidCategoriesDistributionChart(
    classificationStats: List<AidClassificationStat>
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .animateContentSize(animationSpec = tween(280)),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "تحليل تصنيفات المساعدات الفعلية من قاعدة البيانات:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0D9488)
            )
            if (classificationStats.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF0D9488).copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, Color(0xFF0D9488).copy(alpha = 0.25f))
                ) {
                    Text(
                        text = "${classificationStats.size} تصنيف نشط",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0D9488),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        if (classificationStats.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF0D9488).copy(alpha = 0.08f),
                                Color(0xFF0284C7).copy(alpha = 0.05f)
                            )
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.85f), RoundedCornerShape(24.dp))
                    .padding(vertical = 28.dp, horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Category,
                        contentDescription = null,
                        tint = Color(0xFF0D9488).copy(alpha = 0.65f),
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = "لا توجد سجلات تصنيفات مساعدات في قاعدة البيانات حتى الآن",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF0D9488).copy(alpha = 0.07f),
                                Color(0xFF0284C7).copy(alpha = 0.05f)
                            )
                        )
                    )
                    .padding(8.dp)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(
                        items = classificationStats,
                        key = { it.classificationName }
                    ) { stat ->
                        AidClassificationGlassCard(stat = stat)
                    }
                }
            }
        }
    }
}

@Composable
private fun AidClassificationGlassCard(stat: AidClassificationStat) {
    val denominator = (stat.candidatesCount + stat.beneficiariesCount).takeIf { it > 0 } ?: stat.total
    val targetProgress = if (denominator > 0) {
        (stat.beneficiariesCount.toFloat() / denominator.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    var isAnimated by remember(stat.classificationName) { mutableStateOf(false) }
    LaunchedEffect(stat.classificationName, targetProgress) {
        isAnimated = true
    }
    val animatedProgress by animateFloatAsState(
        targetValue = if (isAnimated) targetProgress else 0f,
        animationSpec = tween(durationMillis = 750, easing = FastOutSlowInEasing),
        label = "AidClassificationProgress_${stat.classificationName}"
    )

    val candidateOrange = Color(0xFFF59E0B)
    val beneficiaryGreen = Color(0xFF10B981)
    val tealAccent = Color(0xFF0D9488)
    val percentageText = String.format(Locale.US, "%.1f%%", targetProgress * 100f)
    val cardShape = RoundedCornerShape(24.dp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 4.dp,
                shape = cardShape,
                clip = false,
                ambientColor = tealAccent.copy(alpha = 0.14f),
                spotColor = Color(0x1A000000)
            )
            .clip(cardShape)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.82f),
                        Color(0xFFF0FDFA).copy(alpha = 0.68f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.95f),
                        Color.White.copy(alpha = 0.55f)
                    )
                ),
                shape = cardShape
            )
            .animateContentSize(animationSpec = tween(260))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. ترويسة البطاقة: أيقونة توضيحية + الاسم الحقيقي للتصنيف من قاعدة البيانات + الإجمالي
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        tealAccent.copy(alpha = 0.18f),
                                        Color(0xFF0284C7).copy(alpha = 0.14f)
                                    )
                                )
                            )
                            .border(1.dp, Color.White.copy(alpha = 0.8f), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolunteerActivism,
                            contentDescription = null,
                            tint = tealAccent,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stat.classificationName,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF0F172A),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "تصنيف فعلي مسجل",
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.72f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.9f))
                ) {
                    Text(
                        text = "الإجمالي: ${stat.total}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            // 2. قسم الأرقام البارزة: عدد المرشحين (برتقالي) و عدد المستفيدين (أخضر)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    color = candidateOrange.copy(alpha = 0.11f),
                    border = BorderStroke(1.dp, candidateOrange.copy(alpha = 0.28f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "عدد المرشحين:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFB45309)
                            )
                            Text(
                                text = "${stat.candidatesCount}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFD97706)
                            )
                        }
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    color = beneficiaryGreen.copy(alpha = 0.11f),
                    border = BorderStroke(1.dp, beneficiaryGreen.copy(alpha = 0.28f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF059669),
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "عدد المستفيدين:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF047857)
                            )
                            Text(
                                text = "${stat.beneficiariesCount}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF059669)
                            )
                        }
                    }
                }
            }

            // 3. الرسم البياني: شريط التقدم الذكي لنسبة المستفيدين من إجمالي المرشحين والمستفيدين
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "نسبة المستفيدين من إجمالي المرشحين والمستفيدين",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF475569),
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = percentageText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF059669)
                    )
                }

                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(9.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    color = beneficiaryGreen,
                    trackColor = candidateOrange.copy(alpha = 0.18f)
                )
            }
        }
    }
}

@Composable
private fun FamilyClassificationsChart(
    residentStats: List<KeyCountRecord>,
    warDamageStats: List<KeyCountRecord>
) {
    val activeResident = remember(residentStats) { residentStats.filter { it.count > 0 } }
    val activeDamage = remember(warDamageStats) { warDamageStats.filter { it.count > 0 } }
    var listVisible by remember { mutableStateOf(false) }
    LaunchedEffect(activeResident, activeDamage) { listVisible = true }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 380.dp)
            .verticalScroll(rememberScrollState())
            .animateContentSize(animationSpec = tween(280)),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "1. صفة الإقامة (مقيم / نازح):",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF0D9488)
        )
        val totalResident = activeResident.sumOf { it.count }.coerceAtLeast(1)
        if (activeResident.isNotEmpty()) {
            activeResident.forEachIndexed { idx, stat ->
                val pct = (stat.count * 100) / totalResident
                val animatedProgress by animateFloatAsState(
                    targetValue = if (listVisible) (pct / 100f).coerceIn(0f, 1f) else 0f,
                    animationSpec = tween(550),
                    label = "ResidentProg_$idx"
                )
                val delay = (idx * 45).coerceAtMost(280)
                val accent = Color(0xFF0D9488)

                AnimatedVisibility(
                    visible = listVisible,
                    enter = fadeIn(tween(280, delayMillis = delay)) +
                        slideInVertically(tween(280, delayMillis = delay)) { it / 3 }
                ) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.2f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stat.keyName,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = accent.copy(alpha = 0.13f),
                                    border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
                                ) {
                                    Text(
                                        text = "${stat.count} أسرة ($pct%)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = accent,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            LinearProgressIndicator(
                                progress = { animatedProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = accent,
                                trackColor = accent.copy(alpha = 0.12f)
                            )
                        }
                    }
                }
            }
        } else {
            Text("لا توجد بيانات لحالة الإقامة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "2. تصنيف أضرار الحرب:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFDC2626)
        )
        val totalDamage = activeDamage.sumOf { it.count }.coerceAtLeast(1)
        if (activeDamage.isNotEmpty()) {
            activeDamage.forEachIndexed { idx, stat ->
                val pct = (stat.count * 100) / totalDamage
                val animatedProgress by animateFloatAsState(
                    targetValue = if (listVisible) (pct / 100f).coerceIn(0f, 1f) else 0f,
                    animationSpec = tween(550),
                    label = "DamageProg_$idx"
                )
                val delay = (idx * 45).coerceAtMost(280)
                val accent = Color(0xFFEF4444)

                AnimatedVisibility(
                    visible = listVisible,
                    enter = fadeIn(tween(280, delayMillis = delay)) +
                        slideInVertically(tween(280, delayMillis = delay)) { it / 3 }
                ) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        border = BorderStroke(1.dp, accent.copy(alpha = 0.2f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .animateContentSize()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(7.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stat.keyName,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = accent.copy(alpha = 0.13f),
                                    border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
                                ) {
                                    Text(
                                        text = "${stat.count} ($pct%)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = accent,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            LinearProgressIndicator(
                                progress = { animatedProgress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = accent,
                                trackColor = accent.copy(alpha = 0.12f)
                            )
                        }
                    }
                }
            }
        } else {
            Text("لا توجد بيانات لأضرار الحرب", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ProjectCompletionRatesCard(
    projects: List<ProjectEntity>,
    projectSummaries: List<ProjectAggregatedSummary> = emptyList()
) {
    if (projects.isEmpty()) {
        Text("لا توجد مشاريع نشطة حالياً", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }

    val summaryMap = remember(projectSummaries) { projectSummaries.associateBy { it.projectNumber } }
    var listVisible by remember { mutableStateOf(false) }
    LaunchedEffect(projects) { listVisible = true }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 360.dp)
            .verticalScroll(rememberScrollState())
            .animateContentSize(animationSpec = tween(280)),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        projects.forEachIndexed { idx, prj ->
            val summary = summaryMap[prj.projectNumber]
            val totalCandidates = summary?.totalCandidates ?: 0
            val totalDelivered = summary?.totalReceived ?: 0
            val completionRate = if (totalCandidates > 0) {
                ((totalDelivered.toFloat() / totalCandidates.toFloat()) * 100f).coerceIn(0f, 100f)
            } else 0f
            val progressFraction = (completionRate / 100f).coerceIn(0f, 1f)
            val animatedProgress by animateFloatAsState(
                targetValue = if (listVisible) progressFraction else 0f,
                animationSpec = tween(550),
                label = "ProjProg_$idx"
            )
            val accent = if (completionRate >= 100f) Color(0xFF10B981) else Color(0xFF0284C7)
            val delay = (idx * 45).coerceAtMost(320)

            AnimatedVisibility(
                visible = listVisible,
                enter = fadeIn(tween(280, delayMillis = delay)) +
                    slideInVertically(tween(280, delayMillis = delay)) { it / 3 }
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.22f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize()
                ) {
                    Column(modifier = Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = prj.projectName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${prj.projectNumber} • الممول: ${prj.fundingInstitution}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = accent.copy(alpha = 0.13f),
                                border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
                            ) {
                                Text(
                                    text = "${completionRate.toInt()}%",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = accent,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "المستفيدون الفعليون: $totalDelivered من $totalCandidates مرشح",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = prj.projectDate,
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        LinearProgressIndicator(
                            progress = { animatedProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = accent,
                            trackColor = accent.copy(alpha = 0.12f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BeneficiaryPreviewTable(
    title: String,
    items: List<AidRecordWithBeneficiary>,
    isLoading: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                if (items.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = "${items.size} سجل",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            if (isLoading) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("جارِ تحميل ومعاينة البيانات...", fontSize = 11.sp)
                }
            } else if (items.isEmpty()) {
                Text(
                    text = "لا توجد سجلات مطابقة للعرض أو التصدير حالياً.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 200.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("الاسم", modifier = Modifier.weight(2.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("الهوية", modifier = Modifier.weight(2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("المشروع", modifier = Modifier.weight(2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("الحالة", modifier = Modifier.weight(1.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    items.forEachIndexed { idx, item ->
                        val name = item.family?.name?.ifBlank { null }
                            ?: item.record.notes?.ifBlank { null }
                            ?: "غير محدد"
                        val idNum = item.family?.nationalID?.ifBlank { null }
                            ?: item.record.familyID.toString()
                        val prjNum = item.record.projectID.toString()
                        val status = item.record.recipientStatus.ifBlank { "مرشح" }
                        val isDelivered = status.trim() in setOf("مستفيد", "تم التسليم", "مستلم")

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (idx % 2 == 0) Color.Transparent else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = name,
                                modifier = Modifier.weight(2.5f),
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = idNum,
                                modifier = Modifier.weight(2f),
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = prjNum,
                                modifier = Modifier.weight(2f),
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isDelivered) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFFF59E0B).copy(alpha = 0.15f),
                                modifier = Modifier.weight(1.5f)
                            ) {
                                Text(
                                    text = status,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDelivered) Color(0xFF047857) else Color(0xFFB45309),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProjectReportSection(
    projects: List<ProjectEntity>,
    selectedProjectId: Long?,
    onSelectProject: (Long) -> Unit,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    previewList: List<AidRecordWithBeneficiary>,
    isLoadingPreview: Boolean,
    isExporting: Boolean,
    canExportPdf: Boolean = true,
    canExportExcel: Boolean = true,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit
) {
    val currentProject = projects.firstOrNull { it.projectID == selectedProjectId }
    val canExport = !isExporting && selectedProjectId != null && previewList.isNotEmpty() && !isLoadingPreview

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "اختر المشروع لتوليد كشف المستفيدين الرسمي:",
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )

        // Dropdown Selector
        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedCard(
                modifier = Modifier.fillMaxWidth().clickable { onToggleExpand() },
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = currentProject?.projectName ?: "اختر المشروع...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        if (currentProject != null) {
                            Text(
                                text = "${currentProject.projectNumber} • ${currentProject.fundingInstitution}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                }
            }

            DropdownMenu(
                expanded = isExpanded,
                onDismissRequest = onToggleExpand,
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                if (projects.isEmpty()) {
                    DropdownMenuItem(
                        text = { Text("لا توجد بيانات مشاريع مسجلة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        onClick = onToggleExpand,
                        enabled = false
                    )
                } else {
                    projects.forEach { prj ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("${prj.projectNumber} - ${prj.fundingInstitution}", fontSize = 10.sp)
                                }
                            },
                            onClick = {
                                onSelectProject(prj.projectID)
                                onToggleExpand()
                            }
                        )
                    }
                }
            }
        }

        // جدول المعاينة المسبقة قبل التصدير
        if (selectedProjectId != null) {
            BeneficiaryPreviewTable(
                title = "معاينة كشف المستفيدين قبل التصدير",
                items = previewList,
                isLoading = isLoadingPreview
            )
        }

        // أزرار التصدير (تُخفى كلياً إذا لم يكن لدى المستخدم صلاحية التصدير)
        if (canExportPdf || canExportExcel) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (canExportPdf) {
                    Button(
                        onClick = onExportPdf,
                        enabled = canExport,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isExporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("جارِ المعالجة...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير كشف A4 PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (canExportExcel) {
                    Button(
                        onClick = onExportExcel,
                        enabled = canExport,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isExporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("جارِ التصدير...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير إكسل Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (selectedProjectId != null && previewList.isEmpty() && !isLoadingPreview) {
            Text(
                text = "⚠️ يتعذر التصدير لعدم وجود مستفيدين مسجلين في هذا المشروع.",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
private fun LocalityReportSection(
    localities: List<String>,
    selectedLocality: String,
    onSelectLocality: (String) -> Unit,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    subAreas: List<SubAreaBenefitRatioStat>,
    isExporting: Boolean,
    isLocalityLocked: Boolean = false,
    canExportPdf: Boolean = true,
    canExportExcel: Boolean = true,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit
) {
    val currentLoc = selectedLocality.ifBlank { localities.firstOrNull() ?: "" }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = if (isLocalityLocked) "النطاق الجغرافي المقيد لصلاحياتك (للقراءة والاستعلام):" else "اختر المحلية لاستخراج تقرير الشعب والنسب الدقيقة:",
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )

        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = !isLocalityLocked) { onToggleExpand() },
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.outlinedCardColors(
                    containerColor = if (isLocalityLocked) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = currentLoc.ifBlank { "اختر المحلية..." },
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Icon(
                        imageVector = if (isLocalityLocked) Icons.Default.Lock else Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = if (isLocalityLocked) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            DropdownMenu(
                expanded = isExpanded && !isLocalityLocked,
                onDismissRequest = onToggleExpand,
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                if (localities.isEmpty()) {
                    DropdownMenuItem(
                        text = { Text("لا توجد بيانات محليات مسجلة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        onClick = onToggleExpand,
                        enabled = false
                    )
                } else {
                    localities.forEach { locName ->
                        DropdownMenuItem(
                            text = { Text(locName, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            onClick = {
                                onSelectLocality(locName)
                                onToggleExpand()
                            }
                        )
                    }
                }
            }
        }

        // إحصائية سريعة
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("الشعب المشمولة: ${subAreas.size} شعبة", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                Text("المستحقين: ${subAreas.sumOf { it.eligibleFamiliesCount }}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        }

        // أزرار التصدير (تُخفى كلياً إذا لم يكن لدى المستخدم صلاحية التصدير)
        if (canExportPdf || canExportExcel) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (canExportPdf) {
                    Button(
                        onClick = onExportPdf,
                        enabled = !isExporting && currentLoc.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isExporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("جارِ المعالجة...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير تقرير A4 PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (canExportExcel) {
                    Button(
                        onClick = onExportExcel,
                        enabled = !isExporting && currentLoc.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isExporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("جارِ التصدير...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير إكسل Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ComprehensiveReportSection(
    fromDate: String,
    toDate: String,
    periodDeliveryCount: Int,
    localityStats: List<LocalityDistributionStat>,
    aidTypeStats: List<AidTypeDistributionStat>,
    distinctCategories: List<String> = emptyList(),
    previewList: List<AidRecordWithBeneficiary>,
    isLoadingPreview: Boolean,
    isExporting: Boolean,
    canExportPdf: Boolean = true,
    canExportExcel: Boolean = true,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit
) {
    var selectedCatFilter by remember { mutableStateOf("كافة التصنيفات") }
    val categoryTabs = remember(distinctCategories, aidTypeStats) {
        listOf("كافة التصنيفات") + (if (distinctCategories.isNotEmpty()) distinctCategories else aidTypeStats.map { it.aidTypeName }.distinct())
    }
    val canExport = !isExporting && previewList.isNotEmpty() && !isLoadingPreview

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تقرير العمليات الميدانية الشامل:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Text("الفترة المحددة: من $fromDate إلى $toDate", fontSize = 11.sp)
                Text("إجمالي المساعدات المنفذة في هذه الفترة: $periodDeliveryCount طرد موزع", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("يغطي ${localityStats.size} محلية و ${aidTypeStats.size} صنف إغاثي مع جداول المستلمين ومربعات التوقيع.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // تبويبات فلترة تصنيفات المساعدات الديناميكية
        if (categoryTabs.size > 2) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تصنيف المساعدة المشمول:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categoryTabs.forEach { cat ->
                        val isSel = selectedCatFilter == cat
                        Surface(
                            onClick = { selectedCatFilter = cat },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            contentColor = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface
                        ) {
                            Text(
                                text = cat,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // جدول المعاينة المسبقة لكشف التوزيع الشامل
        BeneficiaryPreviewTable(
            title = "معاينة كشف التوزيع الشامل قبل التصدير",
            items = previewList,
            isLoading = isLoadingPreview
        )

        if (canExportPdf || canExportExcel) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (canExportPdf) {
                    Button(
                        onClick = onExportPdf,
                        enabled = canExport,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isExporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("جارِ المعالجة...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير شامل A4 PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                if (canExportExcel) {
                    Button(
                        onClick = onExportExcel,
                        enabled = canExport,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isExporting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("جارِ التصدير...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تصدير إكسل Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (previewList.isEmpty() && !isLoadingPreview) {
            Text(
                text = "⚠️ لا توجد سجلات توزيع في الفترة المحددة، التصدير غير متاح.",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

/**
 * بطاقة إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية المفصلة والديناميكية
 * تتيح اختيار محلية وشعبة معينة لعرض التوزيع التجميعي المحدث لحظياً للأسر والمنازل المهدمة وأضرار الحرب
 */
@Composable
fun DynamicReportsGeoDamageCard(
    localities: List<String>,
    selectedLocality: String,
    selectedSubArea: String,
    availableSubAreas: List<String>,
    localityFamilyCount: Int,
    subAreaFamilyCount: Int,
    localityCounts: Map<String, Int>,
    completelyDestroyedCount: Int,
    warDamageStats: WarDamageStats?,
    damageDistribution: List<DamageTypeBreakdown>,
    damageDetailsByRegion: Map<String, Map<String, Int>> = emptyMap(),
    isLocalityLocked: Boolean = false,
    isBranchLocked: Boolean = false,
    canViewAllBranches: Boolean = true,
    lockedBranchName: String? = null,
    onLocalitySelected: (String) -> Unit,
    onSubAreaSelected: (String) -> Unit
) {
    var localityExpanded by remember { mutableStateOf(false) }
    var subAreaExpanded by remember { mutableStateOf(false) }

    val selectedLocalityName = selectedLocality.ifBlank { "اختر المحلية" }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = BorderStroke(1.dp, Color(0xFF0284C7).copy(alpha = 0.22f)),
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(animationSpec = tween(280))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ترويسة البطاقة بدون أي عناصر تسبب انضغاط النص أفقياً
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationCity,
                    contentDescription = null,
                    tint = Color(0xFF0284C7),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = "اختر المحلية والشعبة لعرض التوزيع التجميعي المحدث لحظياً للأسر وأضرار الحرب:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // صفي القوائم المنسدلة لاختيار المحلية والشعبة
            val displayBranch = lockedBranchName.takeIf { isBranchLocked && !it.isNullOrBlank() }
                ?: selectedSubArea
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // منسدل المحلية (يُقفل تلقائياً إذا كانت الصلاحية محصورة بمحلية واحدة)
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { if (!isLocalityLocked) localityExpanded = true },
                        enabled = !isLocalityLocked,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Icon(
                                    imageVector = if (isLocalityLocked) Icons.Default.Lock else Icons.Default.LocationCity,
                                    contentDescription = null,
                                    tint = if (isLocalityLocked) MaterialTheme.colorScheme.onSurfaceVariant else Color(0xFF16A34A),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = selectedLocalityName,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (!isLocalityLocked) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF16A34A))
                            }
                        }
                    }

                    DropdownMenu(
                        expanded = localityExpanded && !isLocalityLocked,
                        onDismissRequest = { localityExpanded = false }
                    ) {
                        localities.forEach { locName ->
                            val count = localityCounts[locName] ?: 0
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            locName,
                                            fontWeight = if (locName == selectedLocality) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("($count أسرة)", fontSize = 11.sp, color = Color(0xFF16A34A))
                                    }
                                },
                                onClick = {
                                    onLocalitySelected(locName)
                                    localityExpanded = false
                                }
                            )
                        }
                    }
                }

                // منسدل الشعبة / المنطقة الفرعية (يُقفل تلقائياً إذا كانت الصلاحية محصورة بشعبة واحدة)
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { if (!isBranchLocked) subAreaExpanded = true },
                        enabled = !isBranchLocked,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Icon(
                                    imageVector = if (isBranchLocked) Icons.Default.Lock else Icons.Default.AltRoute,
                                    contentDescription = null,
                                    tint = if (isBranchLocked) MaterialTheme.colorScheme.onSurfaceVariant else Color(0xFF0284C7),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = displayBranch.ifBlank { if (canViewAllBranches) "كافة الشعب" else "اختر الشعبة" },
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (!isBranchLocked) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF0284C7))
                            }
                        }
                    }

                    DropdownMenu(
                        expanded = subAreaExpanded && !isBranchLocked,
                        onDismissRequest = { subAreaExpanded = false }
                    ) {
                        if (canViewAllBranches) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        "كافة الشعب",
                                        fontWeight = if (selectedSubArea.isBlank()) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onSubAreaSelected("")
                                    subAreaExpanded = false
                                }
                            )
                        }

                        availableSubAreas.forEach { sub ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        sub,
                                        fontWeight = if (sub == selectedSubArea) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onSubAreaSelected(sub)
                                    subAreaExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // شبكة المؤشرات الإحصائية الأربعة الرئيسية
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReportGeoStatBadge(
                    title = "أسر المحلية",
                    value = "$localityFamilyCount",
                    subtitle = selectedLocalityName,
                    color = Color(0xFF16A34A),
                    icon = Icons.Default.Groups,
                    modifier = Modifier.weight(1f)
                )

                ReportGeoStatBadge(
                    title = "أسر الشعبة",
                    value = if (displayBranch.isNotBlank()) "$subAreaFamilyCount" else "الكل",
                    subtitle = displayBranch.ifBlank { "غير مقيد بشعبة" },
                    color = Color(0xFF0284C7),
                    icon = Icons.Default.LocationOn,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReportGeoStatBadge(
                    title = "منازل مهدمة كلياً",
                    value = "$completelyDestroyedCount",
                    subtitle = "أضرار كلية بالنطاق",
                    color = Color(0xFFDC2626),
                    icon = Icons.Default.HomeWork,
                    modifier = Modifier.weight(1f)
                )

                val totalAssessed = warDamageStats?.totalAssessed ?: 0
                ReportGeoStatBadge(
                    title = "إجمالي أضرار الحرب",
                    value = "$totalAssessed",
                    subtitle = "منازل مسجلة بالنطاق",
                    color = Color(0xFFD97706),
                    icon = Icons.Default.Warning,
                    modifier = Modifier.weight(1f)
                )
            }

            // تفصيل الحالات الهندسية والإنشائية
            warDamageStats?.let { ws ->
                if (ws.totalAssessed > 0) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "تفصيل الحالات الهندسية والإنشائية المسجلة:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MiniDamagePill(
                                    label = "جزئي بليغ",
                                    count = ws.severePartialDamageCount,
                                    color = Color(0xFFEA580C),
                                    modifier = Modifier.weight(1f)
                                )
                                MiniDamagePill(
                                    label = "جزئي طفيف",
                                    count = ws.minorPartialDamageCount,
                                    color = Color(0xFFCA8A04),
                                    modifier = Modifier.weight(1f)
                                )
                                MiniDamagePill(
                                    label = "سليم / لا ضرر",
                                    count = ws.noDamageCount,
                                    color = Color(0xFF16A34A),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // توزيع درجات الأضرار المسجلة ميدانياً مع بطاقات أنيقة وشارات ملونة
            if (damageDistribution.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.24f),
                    border = BorderStroke(1.dp, Color(0xFF16A34A).copy(alpha = 0.16f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(animationSpec = tween(280))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "توزيع درجات الأضرار المسجلة ميدانياً بالنطاق:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        val total = damageDistribution.sumOf { it.count }.coerceAtLeast(1)
                        damageDistribution.forEachIndexed { idx, item ->
                            val percent = (item.count.toDouble() / total.toDouble()) * 100
                            val accent = Color(0xFF16A34A)
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                                border = BorderStroke(1.dp, accent.copy(alpha = 0.18f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .animateContentSize()
                            ) {
                                Column(
                                    modifier = Modifier.padding(11.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = item.damageType,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Surface(
                                            shape = RoundedCornerShape(20.dp),
                                            color = accent.copy(alpha = 0.12f),
                                            border = BorderStroke(1.dp, accent.copy(alpha = 0.26f))
                                        ) {
                                            Text(
                                                text = "${item.count} منزل (${String.format(Locale.US, "%.1f%%", percent)})",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = accent,
                                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                    LinearProgressIndicator(
                                        progress = { (item.count.toFloat() / total.toFloat()).coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(5.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = accent,
                                        trackColor = accent.copy(alpha = 0.12f)
                                    )
                                    val regionMap = damageDetailsByRegion[item.damageType]
                                    if (!regionMap.isNullOrEmpty()) {
                                        val topRegions = regionMap.entries.sortedByDescending { it.value }.take(3)
                                        Text(
                                            text = topRegions.joinToString(" • ") { "${it.key}: ${it.value}" },
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportGeoStatBadge(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
                Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = color)
            }
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MiniDamagePill(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "$count", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

