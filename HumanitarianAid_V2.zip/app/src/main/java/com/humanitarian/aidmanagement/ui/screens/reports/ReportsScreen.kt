package com.humanitarian.aidmanagement.ui.screens.reports

import android.app.DatePickerDialog
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.dao.AidClassificationStat
import com.humanitarian.aidmanagement.data.local.dao.DamageTypeBreakdown
import com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord
import com.humanitarian.aidmanagement.data.local.dao.ProjectAggregatedSummary
import com.humanitarian.aidmanagement.data.local.dao.WarDamageStats
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.*
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.util.ExportColumnRegistry
import com.humanitarian.aidmanagement.util.LocalityReportData
import com.humanitarian.aidmanagement.util.ProfessionalReportExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

sealed class PendingReportExport {
    data class Project(
        val projectId: Long,
        val isExcel: Boolean,
        val defaultFileName: String,
        val selectedColumns: List<String> = emptyList()
    ) : PendingReportExport()

    data class Locality(
        val localityName: String,
        val defaultFileName: String
    ) : PendingReportExport()

    data class Comprehensive(
        val fromDate: String,
        val toDate: String,
        val isExcel: Boolean,
        val defaultFileName: String,
        val selectedColumns: List<String> = emptyList()
    ) : PendingReportExport()

    data class SmartFiltered(
        val category: String?,
        val regions: List<String>,
        val fromDate: String,
        val toDate: String,
        val isExcel: Boolean,
        val defaultFileName: String,
        val selectedColumns: List<String> = emptyList()
    ) : PendingReportExport()
}

sealed class PendingExcelExport {
    data class Project(val projectId: Long, val defaultFileName: String) : PendingExcelExport()
    data class Locality(val localityName: String, val defaultFileName: String) : PendingExcelExport()
    data class Comprehensive(val fromDate: String, val toDate: String, val defaultFileName: String) : PendingExcelExport()
}

enum class ReportDashboardTab(val label: String) {
    PROJECT("المشاريع والمستفيدين"),
    LOCALITY("المحليات والشعب"),
    COMPREHENSIVE_PERIOD("التوزيع الشامل حسب الفترة")
}

enum class VisualChartTab(val label: String) {
    LOCALITY_DISTRIBUTION("توزيع المحليات"),
    AID_CATEGORIES("تصنيفات المساعدات"),
    FAMILY_CLASSIFICATIONS("تصنيفات الأسر"),
    PROJECT_COMPLETION("معدلات إنجاز المشاريع")
}

private val GlassCardTint = Color.White.copy(alpha = 0.8f)
private val GlassBorderBrush = Brush.verticalGradient(
    colors = listOf(
        Color.White.copy(alpha = 0.96f),
        Color.White.copy(alpha = 0.52f)
    )
)
private val PrimaryTeal = Color(0xFF0D9488)
private val PrimarySky = Color(0xFF0284C7)
private val EmeraldAccent = Color(0xFF10B981)
private val IndigoAccent = Color(0xFF4F46E5)
private val SlateTitle = Color(0xFF0F172A)
private val SlateMuted = Color(0xFF475569)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    repository: AidRepository,
    viewModel: ReportsViewModel = viewModel(factory = ReportsViewModel.Factory(repository)),
    onNavigateBack: () -> Unit,
    onNavigateToDynamicReportExport: () -> Unit = {}
) {
    val context = LocalContext.current
    val exporter = remember { ProfessionalReportExporter(context) }
    val scope = rememberCoroutineScope()

    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val canExportExcel = remember(currentUser) { AccessControlManager.canExportExcel() }
    val canExportPdf = remember(currentUser) { AccessControlManager.canExportPdf() }

    val geoStats by viewModel.geoDamageStats.collectAsStateWithLifecycle()
    val dynamicLocalities by viewModel.localities.collectAsStateWithLifecycle()
    val assignedSubArea by viewModel.assignedSubArea.collectAsStateWithLifecycle()
    val assignedDivisions by viewModel.assignedDivisions.collectAsStateWithLifecycle()
    val vmLocalityLocked by viewModel.isLocalityLocked.collectAsStateWithLifecycle()
    val vmBranchLocked by viewModel.isBranchLocked.collectAsStateWithLifecycle()
    val vmCanViewAllBranches by viewModel.canViewAllBranches.collectAsStateWithLifecycle()
    val vmLockedBranchName by viewModel.lockedBranchName.collectAsStateWithLifecycle()
    val isLocalityLocked = vmLocalityLocked || assignedSubArea != null
    val isBranchLocked = vmBranchLocked || assignedDivisions.size == 1
    val canViewAllBranches = vmCanViewAllBranches && assignedDivisions.isEmpty()
    val lockedBranchName = vmLockedBranchName ?: if (assignedDivisions.size == 1) assignedDivisions.first() else null

    // نطاق التاريخ
    val fromDate by viewModel.fromDate.collectAsStateWithLifecycle()
    val toDate by viewModel.toDate.collectAsStateWithLifecycle()
    val selectedPreset by viewModel.selectedPreset.collectAsStateWithLifecycle()

    // حالات الظهور الانسيابية وتبويب الرسوم البيانية
    var selectedChartTab by remember { mutableStateOf(VisualChartTab.LOCALITY_DISTRIBUTION) }
    var isDashboardVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isDashboardVisible = true
    }

    // حالة نافذة التصدير الذكية المنبثقة
    var showSmartExportSheet by remember { mutableStateOf(false) }

    // تدفقات البيانات الحية من قاعدة البيانات
    val stats by viewModel.dashboardStats.collectAsStateWithLifecycle()
    val localityStats by viewModel.localityStats.collectAsStateWithLifecycle()
    val aidClassificationStats by viewModel.aidClassificationStats.collectAsStateWithLifecycle()
    val subAreaRatios by viewModel.subAreaRatios.collectAsStateWithLifecycle()
    val residentStats by viewModel.residentStats.collectAsStateWithLifecycle()
    val warDamageStats by viewModel.warDamageStats.collectAsStateWithLifecycle()
    val activeProjects by viewModel.activeProjects.collectAsStateWithLifecycle()
    val periodDeliveryCount by viewModel.periodDeliveryCount.collectAsStateWithLifecycle()
    val periodBeneficiaryFamiliesCount by viewModel.periodBeneficiaryFamiliesCount.collectAsStateWithLifecycle()
    val projectSummaries by viewModel.projectSummaries.collectAsStateWithLifecycle()

    // تدفقات الفلترة التفاعلية للتصدير الذكي
    val smartCategories by viewModel.smartCategoriesInRange.collectAsStateWithLifecycle()
    val selectedSmartCategory by viewModel.selectedSmartCategory.collectAsStateWithLifecycle()
    val smartRegions by viewModel.smartRegionsForCategory.collectAsStateWithLifecycle()
    val selectedSmartRegions by viewModel.selectedSmartRegions.collectAsStateWithLifecycle()
    val selectedSmartColumns by viewModel.selectedSmartColumns.collectAsStateWithLifecycle()

    // حالة التصدير عبر SAF
    val isExporting = viewModel.isExporting
    var pendingExport by remember { mutableStateOf<PendingReportExport?>(null) }
    var exportedFile by remember { mutableStateOf<File?>(null) }
    var exportedFileType by remember { mutableStateOf<String?>(null) }
    var exportStatusMessage by remember { mutableStateOf<String?>(null) }

    val createExcelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri: Uri? ->
        if (uri != null) {
            if (!canExportExcel) {
                pendingExport = null
                return@rememberLauncherForActivityResult
            }
            val pending = pendingExport ?: return@rememberLauncherForActivityResult
            scope.launch {
                viewModel.isExporting = true
                try {
                    val result: Result<Unit> = withContext(Dispatchers.IO) {
                        when (pending) {
                            is PendingReportExport.SmartFiltered -> {
                                val records = viewModel.fetchSmartExportRecords(
                                    category = pending.category,
                                    fromDate = pending.fromDate,
                                    toDate = pending.toDate,
                                    regions = pending.regions
                                )
                                if (records.isEmpty()) {
                                    return@withContext Result.failure(Exception("لا توجد سجلات مطابقة للفلاتر المختارة"))
                                }
                                val meta = listOf(
                                    "تصنيف المساعدة" to (pending.category ?: "كافة التصنيفات"),
                                    "النطاق الزمني" to "${pending.fromDate} إلى ${pending.toDate}",
                                    "المناطق المشمولة" to (if (pending.regions.isEmpty()) "كافة المناطق" else pending.regions.joinToString("، ")),
                                    "إجمالي السجلات" to "${records.size} سجل",
                                    "المشرف المسؤول" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات"),
                                    "تاريخ التصدير" to SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
                                )
                                exporter.exportDynamicFamiliesExcelToUri(
                                    uri = uri,
                                    title = "تقرير المساعدات المخصص - ${pending.category ?: "كافة التصنيفات"}",
                                    metaRows = meta,
                                    records = records,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS }
                                )
                            }
                            is PendingReportExport.Project -> {
                                val prj = activeProjects.firstOrNull { it.projectID == pending.projectId }
                                    ?: return@withContext Result.failure(Exception("بيانات المشروع المختار غير متوفرة"))
                                val aidTypes = repository.getActiveAidTypes().first().associateBy { it.aidTypeID }
                                val meta = listOf(
                                    "المشروع:" to prj.projectName,
                                    "رقم المشروع:" to prj.projectNumber,
                                    "الجهة الممولة:" to (prj.fundingInstitution ?: "غير محدد"),
                                    "المشرف المسؤول:" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات"),
                                    "نوع المساعدة:" to (aidTypes[prj.aidTypeID]?.aidTypeName ?: "مساعدات إغاثية"),
                                    "تاريخ التقرير:" to SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
                                )
                                exporter.exportDynamicFamiliesExcelChunkedToUri(
                                    uri = uri,
                                    title = "كشف مستفيدي المشروع الإنساني - ${prj.projectName}",
                                    metaRows = meta,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS },
                                    chunkSize = 5000
                                ) { limit, offset ->
                                    repository.getProjectBeneficiariesWithFamiliesChunk(pending.projectId, limit, offset)
                                }
                            }
                            is PendingReportExport.Locality -> {
                                val totalFam = repository.getTotalFamiliesCountForLocalityByName(pending.localityName)
                                val reportData = LocalityReportData(
                                    localityName = pending.localityName,
                                    subAreas = subAreaRatios,
                                    totalFamilies = totalFam,
                                    totalBeneficiaries = subAreaRatios.sumOf { it.eligibleFamiliesCount },
                                    totalDelivered = subAreaRatios.sumOf { it.deliveredBeneficiariesCount },
                                    dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                    supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                )
                                exporter.exportLocalitySubAreasExcelToUri(uri, reportData)
                            }
                            is PendingReportExport.Comprehensive -> {
                                val meta = listOf(
                                    "نطاق الفترة:" to "${pending.fromDate} إلى ${pending.toDate}",
                                    "إجمالي المساعدات:" to "$periodDeliveryCount طرد",
                                    "المشرف المسؤول:" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات"),
                                    "تاريخ التقرير:" to SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
                                )
                                exporter.exportDynamicFamiliesExcelChunkedToUri(
                                    uri = uri,
                                    title = "تقرير التوزيع الشامل والعمليات الميدانية",
                                    metaRows = meta,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS },
                                    chunkSize = 5000
                                ) { limit, offset ->
                                    repository.getBeneficiariesWithFamiliesInDateRangeChunk(pending.fromDate, pending.toDate, limit, offset)
                                }
                            }
                        }
                    }

                    result.onSuccess {
                        exportedFile = null
                        exportStatusMessage = "تم حفظ ملف Excel بنجاح بالبيانات والأعمدة المخصصة عبر التخزين الآمن (SAF)."
                        Toast.makeText(context, "تم حفظ ملف الإكسل بنجاح في الموقع المختار!", Toast.LENGTH_LONG).show()
                    }.onFailure { err ->
                        exportStatusMessage = "خطأ أثناء حفظ ملف Excel: ${err.message}"
                        Toast.makeText(context, "فشل حفظ ملف الإكسل: ${err.message ?: "حدث خطأ"}", Toast.LENGTH_LONG).show()
                    }
                } catch (t: Throwable) {
                    exportStatusMessage = "خطأ أثناء تصدير Excel: ${t.message}"
                    Toast.makeText(context, "فشل تصدير ملف الإكسل: ${t.message ?: "حدث خطأ غير متوقع"}", Toast.LENGTH_LONG).show()
                } finally {
                    viewModel.isExporting = false
                    pendingExport = null
                }
            }
        } else {
            pendingExport = null
        }
    }

    val createPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        if (uri != null) {
            if (!canExportPdf) {
                pendingExport = null
                return@rememberLauncherForActivityResult
            }
            val pending = pendingExport ?: return@rememberLauncherForActivityResult
            scope.launch {
                viewModel.isExporting = true
                try {
                    val result: Result<Unit> = withContext(Dispatchers.IO) {
                        when (pending) {
                            is PendingReportExport.SmartFiltered -> {
                                val records = viewModel.fetchSmartExportRecords(
                                    category = pending.category,
                                    fromDate = pending.fromDate,
                                    toDate = pending.toDate,
                                    regions = pending.regions
                                )
                                if (records.isEmpty()) {
                                    return@withContext Result.failure(Exception("لا توجد سجلات مطابقة للفلاتر المختارة"))
                                }
                                val categoryTitle = pending.category ?: "كافة التصنيفات"
                                val meta = listOf(
                                    "التصنيف" to categoryTitle,
                                    "الفترة" to "${pending.fromDate} إلى ${pending.toDate}",
                                    "المناطق" to (if (pending.regions.isEmpty()) "كافة المناطق" else pending.regions.joinToString("، ")),
                                    "السجلات" to "${records.size} مستفيد",
                                    "المشرف" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات")
                                )
                                exporter.exportDynamicFamiliesPdfToUri(
                                    uri = uri,
                                    title = "تقرير المساعدات المخصص - $categoryTitle",
                                    subtitle = "كشف المستفيدين للفترة من ${pending.fromDate} إلى ${pending.toDate}",
                                    metaRows = meta,
                                    records = records,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS }
                                )
                            }
                            is PendingReportExport.Project -> {
                                val prj = activeProjects.firstOrNull { it.projectID == pending.projectId }
                                    ?: return@withContext Result.failure(Exception("بيانات المشروع المختار غير متوفرة"))
                                val combined = repository.getProjectBeneficiariesWithFamilies(pending.projectId)
                                if (combined.isEmpty()) {
                                    return@withContext Result.failure(Exception("لا توجد سجلات مستفيدين لهذا المشروع حتى الآن"))
                                }
                                val aidTypes = repository.getActiveAidTypes().first().associateBy { it.aidTypeID }
                                val meta = listOf(
                                    "المشروع" to prj.projectName,
                                    "رقم المشروع" to prj.projectNumber,
                                    "الجهة الممولة" to (prj.fundingInstitution ?: "غير محدد"),
                                    "المشرف" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات"),
                                    "نوع المساعدة" to (aidTypes[prj.aidTypeID]?.aidTypeName ?: "مساعدات إغاثية")
                                )
                                exporter.exportDynamicFamiliesPdfToUri(
                                    uri = uri,
                                    title = "كشف مستفيدي المشروع الإنساني المعتمد",
                                    subtitle = "مشروع: ${prj.projectName} (${prj.projectNumber})",
                                    metaRows = meta,
                                    records = combined,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS }
                                )
                            }
                            is PendingReportExport.Comprehensive -> {
                                val combined = repository.getBeneficiariesWithFamiliesInDateRange(pending.fromDate, pending.toDate)
                                if (combined.isEmpty()) {
                                    return@withContext Result.failure(Exception("لا توجد سجلات توزيع في الفترة المحددة"))
                                }
                                val meta = listOf(
                                    "النطاق الزمني" to "${pending.fromDate} إلى ${pending.toDate}",
                                    "إجمالي المساعدات" to "${combined.size} طرد",
                                    "المشرف المسؤول" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات")
                                )
                                exporter.exportDynamicFamiliesPdfToUri(
                                    uri = uri,
                                    title = "تقرير التوزيع الشامل والعمليات الميدانية",
                                    subtitle = "تغطية العمليات من تاريخ ${pending.fromDate} إلى ${pending.toDate}",
                                    metaRows = meta,
                                    records = combined,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS }
                                )
                            }
                            is PendingReportExport.Locality -> {
                                Result.failure(Exception("تقرير المحلية متوفر عبر المعاينة والطباعة المباشرة"))
                            }
                        }
                    }

                    result.onSuccess {
                        exportedFile = null
                        exportStatusMessage = "تم حفظ مستند PDF بنجاح وفق الفلاتر والأعمدة المخصصة عبر التخزين الآمن (SAF)."
                        Toast.makeText(context, "تم حفظ مستند PDF بنجاح في الموقع المختار!", Toast.LENGTH_LONG).show()
                    }.onFailure { err ->
                        exportStatusMessage = "خطأ أثناء حفظ مستند PDF: ${err.message}"
                        Toast.makeText(context, "فشل حفظ مستند PDF: ${err.message ?: "حدث خطأ"}", Toast.LENGTH_LONG).show()
                    }
                } catch (t: Throwable) {
                    exportStatusMessage = "خطأ أثناء تصدير PDF: ${t.message}"
                    Toast.makeText(context, "فشل تصدير مستند PDF: ${t.message ?: "حدث خطأ غير متوقع"}", Toast.LENGTH_LONG).show()
                } finally {
                    viewModel.isExporting = false
                    pendingExport = null
                }
            }
        } else {
            pendingExport = null
        }
    }

    LaunchedEffect(fromDate, toDate, currentUser) {
        viewModel.refreshData()
    }

    fun openDatePicker(isFrom: Boolean) {
        val calendar = Calendar.getInstance()
        val currentStr = if (isFrom) fromDate else toDate
        val parts = currentStr.split("-")
        val y = parts.getOrNull(0)?.toIntOrNull() ?: calendar.get(Calendar.YEAR)
        val m = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val d = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(context, { _, year, month, dayOfMonth ->
            val formatted = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth)
            if (isFrom) {
                viewModel.setDateRange(formatted, toDate)
            } else {
                viewModel.setDateRange(fromDate, formatted)
            }
        }, y, m, d).show()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(modifier = Modifier.fillMaxSize()) {
            // خلفية متدرجة ناعمة وحيوية تدعم التأثير الزجاجي (Vibrant Glassmorphism Backdrop)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFFE6FFFA),
                                Color(0xFFE0F2FE),
                                Color(0xFFF1F5F9),
                                Color(0xFFECFEFF)
                            )
                        )
                    )
            )
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF14B8A6).copy(alpha = 0.20f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.86f, size.height * 0.12f),
                        radius = size.width * 0.65f
                    ),
                    center = Offset(size.width * 0.86f, size.height * 0.12f),
                    radius = size.width * 0.65f
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF38BDF8).copy(alpha = 0.22f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.12f, size.height * 0.42f),
                        radius = size.width * 0.7f
                    ),
                    center = Offset(size.width * 0.12f, size.height * 0.42f),
                    radius = size.width * 0.7f
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF6366F1).copy(alpha = 0.14f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.82f, size.height * 0.78f),
                        radius = size.width * 0.65f
                    ),
                    center = Offset(size.width * 0.82f, size.height * 0.78f),
                    radius = size.width * 0.65f
                )
            }

            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(
                                            Brush.linearGradient(
                                                colors = listOf(PrimaryTeal, PrimarySky)
                                            )
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Analytics,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        "لوحة التقارير والتحليلات الذكية",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 16.sp,
                                        color = SlateTitle
                                    )
                                    Text(
                                        "إحصائيات حية وتصدير ديناميكي مخصص",
                                        fontSize = 11.sp,
                                        color = SlateMuted
                                    )
                                }
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = {
                                viewModel.resetFilters()
                                onNavigateBack()
                            }) {
                                Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = SlateTitle)
                            }
                        },
                        actions = {
                            IconButton(onClick = onNavigateToDynamicReportExport) {
                                Icon(Icons.Default.Insights, contentDescription = "مركز التقارير الديناميكي", tint = PrimarySky)
                            }
                            IconButton(onClick = { viewModel.refreshData() }) {
                                Icon(Icons.Default.Refresh, contentDescription = "تحديث البيانات", tint = PrimaryTeal)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.White.copy(alpha = 0.72f),
                            titleContentColor = SlateTitle
                        )
                    )
                },
                bottomBar = {
                    if (canExportExcel || canExportPdf) {
                        Surface(
                            color = Color.White.copy(alpha = 0.86f),
                            shadowElevation = 10.dp,
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.95f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .navigationBarsPadding()
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                            ) {
                                Button(
                                    onClick = { showSmartExportSheet = true },
                                    shape = RoundedCornerShape(18.dp),
                                    contentPadding = PaddingValues(0.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(54.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(
                                                Brush.horizontalGradient(
                                                    colors = listOf(PrimaryTeal, PrimarySky, IndigoAccent)
                                                ),
                                                shape = RoundedCornerShape(18.dp)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.FileUpload,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(22.dp)
                                            )
                                            Text(
                                                text = "استخراج وتصدير التقارير 📤",
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            ) { paddingValues ->
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    // =========================================================================
                    // 1. بطاقة نطاق الفلترة الزمنية التفاعلية (Glassmorphism Date Filter)
                    // =========================================================================
                    item {
                        AnimatedVisibility(
                            visible = isDashboardVisible,
                            enter = fadeIn(tween(340)) + slideInVertically(tween(340)) { it / 8 }
                        ) {
                            GlassmorphicCard(accentColor = PrimaryTeal) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            GlassIconBadge(
                                                icon = Icons.Default.DateRange,
                                                tint = PrimaryTeal
                                            )
                                            Column {
                                                Text(
                                                    text = "الفترة الزمنية للتقارير",
                                                    fontWeight = FontWeight.ExtraBold,
                                                    fontSize = 14.sp,
                                                    color = SlateTitle
                                                )
                                                Text(
                                                    text = "تُحدّث الإحصائيات والفلاتر تلقائياً حسب التاريخ",
                                                    fontSize = 11.sp,
                                                    color = SlateMuted
                                                )
                                            }
                                        }
                                    }

                                    LazyRow(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        val presets = listOf("آخر 7 أيام", "آخر 30 يوماً", "آخر 90 يوماً", "كافة الفترات")
                                        items(presets) { preset ->
                                            val isSelected = selectedPreset == preset
                                            Surface(
                                                onClick = { viewModel.applyPreset(preset) },
                                                shape = RoundedCornerShape(14.dp),
                                                color = if (isSelected) PrimaryTeal else Color.White.copy(alpha = 0.7f),
                                                contentColor = if (isSelected) Color.White else SlateTitle,
                                                border = BorderStroke(
                                                    1.dp,
                                                    if (isSelected) PrimaryTeal else PrimaryTeal.copy(alpha = 0.22f)
                                                ),
                                                shadowElevation = if (isSelected) 3.dp else 0.dp
                                            ) {
                                                Text(
                                                    text = preset,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                                )
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        GlassDateBox(
                                            label = "من تاريخ",
                                            dateValue = fromDate,
                                            accent = PrimaryTeal,
                                            onClick = { openDatePicker(true) },
                                            modifier = Modifier.weight(1f)
                                        )
                                        GlassDateBox(
                                            label = "إلى تاريخ",
                                            dateValue = toDate,
                                            accent = PrimarySky,
                                            onClick = { openDatePicker(false) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // =========================================================================
                    // 2. بطاقات مؤشرات الأداء الرئيسية (Glassmorphism KPI Stat Cards)
                    // =========================================================================
                    item {
                        AnimatedVisibility(
                            visible = isDashboardVisible,
                            enter = fadeIn(tween(400, delayMillis = 60)) + slideInVertically(tween(400, delayMillis = 60)) { it / 8 }
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    GlassKpiCard(
                                        title = "إجمالي المساعدات المنفذة",
                                        value = "$periodDeliveryCount",
                                        subtitle = "خلال الفترة المحددة",
                                        icon = Icons.Default.VolunteerActivism,
                                        gradientColors = listOf(PrimaryTeal, EmeraldAccent),
                                        modifier = Modifier.weight(1f)
                                    )
                                    GlassKpiCard(
                                        title = "عدد الأسر المستفيدة",
                                        value = "$periodBeneficiaryFamiliesCount",
                                        subtitle = "أسرة مستلمة فريدة",
                                        icon = Icons.Default.Groups,
                                        gradientColors = listOf(PrimarySky, IndigoAccent),
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                // شريط مؤشرات عامة مساندة من قاعدة البيانات
                                GlassmorphicCard(accentColor = PrimarySky) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp, vertical = 12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        CompactGlassMetric(
                                            icon = Icons.Default.FamilyRestroom,
                                            label = "إجمالي الأسر",
                                            value = "${stats?.totalFamilies ?: 0}",
                                            tint = PrimaryTeal,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .width(1.dp)
                                                .height(28.dp)
                                                .background(SlateMuted.copy(alpha = 0.16f))
                                        )
                                        CompactGlassMetric(
                                            icon = Icons.Default.FolderSpecial,
                                            label = "المشاريع النشطة",
                                            value = "${activeProjects.size}",
                                            tint = PrimarySky,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .width(1.dp)
                                                .height(28.dp)
                                                .background(SlateMuted.copy(alpha = 0.16f))
                                        )
                                        CompactGlassMetric(
                                            icon = Icons.Default.Category,
                                            label = "التصنيفات",
                                            value = "${smartCategories.size}",
                                            tint = IndigoAccent,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // =========================================================================
                    // 3. إشعار نتيجة التصدير الأخير
                    // =========================================================================
                    if (exportedFile != null) {
                        item {
                            val file = exportedFile!!
                            val isPdf = exportedFileType == "PDF"
                            val accent = if (isPdf) EmeraldAccent else PrimarySky
                            GlassmorphicCard(accentColor = accent) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        GlassIconBadge(
                                            icon = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.TableChart,
                                            tint = accent
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (isPdf) "تم توليد مستند A4 PDF بنجاح!" else "تم إنشاء ملف Excel بنجاح!",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = SlateTitle
                                            )
                                            Text(
                                                text = "${file.name} • ${file.length() / 1024} كيلوبايت",
                                                fontSize = 11.sp,
                                                color = SlateMuted,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                val mime = if (isPdf) "application/pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                                exporter.openFile(file, mime)
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("فتح", fontSize = 11.sp)
                                        }
                                        Button(
                                            onClick = {
                                                val mime = if (isPdf) "application/pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                                exporter.shareFile(file, mime, file.name)
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = PrimarySky),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("مشاركة", fontSize = 11.sp)
                                        }
                                        if (isPdf) {
                                            Button(
                                                onClick = { exporter.printPdfReport(file) },
                                                shape = RoundedCornerShape(12.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldAccent),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("طباعة", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else if (exportStatusMessage != null) {
                        item {
                            GlassmorphicCard(accentColor = PrimaryTeal) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    GlassIconBadge(icon = Icons.Default.CheckCircle, tint = PrimaryTeal)
                                    Text(
                                        text = exportStatusMessage ?: "",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = SlateTitle,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(onClick = { exportStatusMessage = null }) {
                                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = SlateMuted, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }

                    // =========================================================================
                    // 4. لوحة المخططات والتحليلات البيانية الحية (Glassmorphic Charts)
                    // =========================================================================
                    item {
                        AnimatedVisibility(
                            visible = isDashboardVisible,
                            enter = fadeIn(tween(460, delayMillis = 120)) + slideInVertically(tween(460, delayMillis = 120)) { it / 8 }
                        ) {
                            GlassmorphicCard(accentColor = PrimaryTeal) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            GlassIconBadge(icon = Icons.Default.BarChart, tint = PrimaryTeal)
                                            Column {
                                                Text(
                                                    text = "المخططات والتحليلات البيانية الحية",
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = SlateTitle
                                                )
                                                Text(
                                                    text = "بيانات ديناميكية مرتبطة مباشرة بقاعدة البيانات",
                                                    fontSize = 11.sp,
                                                    color = SlateMuted
                                                )
                                            }
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = EmeraldAccent.copy(alpha = 0.14f),
                                            border = BorderStroke(1.dp, EmeraldAccent.copy(alpha = 0.30f))
                                        ) {
                                            Text(
                                                text = "مباشر",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF047857),
                                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                                            )
                                        }
                                    }

                                    LazyRow(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        items(VisualChartTab.values()) { tab ->
                                            val isSelected = selectedChartTab == tab
                                            Surface(
                                                onClick = { selectedChartTab = tab },
                                                shape = RoundedCornerShape(14.dp),
                                                color = if (isSelected) PrimaryTeal else Color.White.copy(alpha = 0.72f),
                                                contentColor = if (isSelected) Color.White else SlateTitle,
                                                border = BorderStroke(
                                                    1.dp,
                                                    if (isSelected) PrimaryTeal else Color.White.copy(alpha = 0.9f)
                                                ),
                                                shadowElevation = if (isSelected) 3.dp else 0.dp
                                            ) {
                                                Text(
                                                    text = tab.label,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                                )
                                            }
                                        }
                                    }

                                    AnimatedContent(
                                        targetState = selectedChartTab,
                                        transitionSpec = {
                                            (fadeIn(tween(260)) + slideInVertically(tween(260)) { it / 12 })
                                                .togetherWith(fadeOut(tween(180)))
                                        },
                                        label = "VisualChartTransition"
                                    ) { activeTab ->
                                        when (activeTab) {
                                            VisualChartTab.LOCALITY_DISTRIBUTION -> {
                                                LocalityDistributionDonutChart(localityStats = localityStats)
                                            }
                                            VisualChartTab.AID_CATEGORIES -> {
                                                AidCategoriesDistributionChart(classificationStats = aidClassificationStats)
                                            }
                                            VisualChartTab.FAMILY_CLASSIFICATIONS -> {
                                                FamilyClassificationsChart(
                                                    residentStats = residentStats,
                                                    warDamageStats = warDamageStats
                                                )
                                            }
                                            VisualChartTab.PROJECT_COMPLETION -> {
                                                ProjectCompletionRatesCard(
                                                    projects = activeProjects,
                                                    projectSummaries = projectSummaries
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // =========================================================================
                    // 5. بطاقة إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية
                    // =========================================================================
                    item {
                        DynamicReportsGeoDamageCard(
                            localities = dynamicLocalities,
                            selectedLocality = geoStats.selectedLocality,
                            selectedSubArea = geoStats.selectedSubArea,
                            availableSubAreas = geoStats.availableSubAreas,
                            localityFamilyCount = geoStats.localityFamilyCount,
                            subAreaFamilyCount = geoStats.subAreaFamilyCount,
                            localityCounts = geoStats.localityCounts,
                            completelyDestroyedCount = geoStats.completelyDestroyedCount,
                            warDamageStats = geoStats.warDamageStats,
                            damageDistribution = geoStats.damageDistribution,
                            damageDetailsByRegion = geoStats.damageDetailsByRegion,
                            isLocalityLocked = isLocalityLocked,
                            isBranchLocked = isBranchLocked,
                            canViewAllBranches = canViewAllBranches,
                            lockedBranchName = lockedBranchName,
                            onLocalitySelected = { viewModel.selectLocality(it) },
                            onSubAreaSelected = { viewModel.selectSubArea(it) }
                        )
                    }
                }
            }

            // =========================================================================
            // 6. نافذة التصدير الذكية المنبثقة (Smart Export ModalBottomSheet)
            // =========================================================================
            if (showSmartExportSheet) {
                SmartExportModalBottomSheet(
                    fromDate = fromDate,
                    toDate = toDate,
                    categories = smartCategories,
                    selectedCategory = selectedSmartCategory,
                    regions = smartRegions,
                    selectedRegions = selectedSmartRegions,
                    selectedColumnKeys = selectedSmartColumns,
                    isExporting = isExporting,
                    canExportExcel = canExportExcel,
                    canExportPdf = canExportPdf,
                    onSelectCategory = { viewModel.selectSmartCategory(it) },
                    onToggleRegion = { viewModel.toggleSmartRegion(it) },
                    onToggleSelectAllRegions = { viewModel.toggleSelectAllSmartRegions() },
                    onToggleColumn = { viewModel.toggleSmartColumn(it) },
                    onSelectDefaultColumns = { viewModel.selectDefaultSmartColumns() },
                    onSelectAllColumns = { viewModel.selectAllSmartColumns() },
                    onExportExcel = {
                        if (!canExportExcel) return@SmartExportModalBottomSheet
                        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                        val safeCat = (selectedSmartCategory ?: "All")
                            .trim()
                            .replace(Regex("[^a-zA-Z0-9_\u0600-\u06FF-]"), "_")
                        val defaultFileName = "Report_${safeCat}_${fromDate}_to_${toDate}_$timeStamp.xlsx"
                        pendingExport = PendingReportExport.SmartFiltered(
                            category = selectedSmartCategory,
                            regions = selectedSmartRegions.toList(),
                            fromDate = fromDate,
                            toDate = toDate,
                            isExcel = true,
                            defaultFileName = defaultFileName,
                            selectedColumns = selectedSmartColumns
                        )
                        showSmartExportSheet = false
                        createExcelLauncher.launch(defaultFileName)
                    },
                    onExportPdf = {
                        if (!canExportPdf) return@SmartExportModalBottomSheet
                        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                        val safeCat = (selectedSmartCategory ?: "All")
                            .trim()
                            .replace(Regex("[^a-zA-Z0-9_\u0600-\u06FF-]"), "_")
                        val defaultFileName = "Report_${safeCat}_${fromDate}_to_${toDate}_$timeStamp.pdf"
                        pendingExport = PendingReportExport.SmartFiltered(
                            category = selectedSmartCategory,
                            regions = selectedSmartRegions.toList(),
                            fromDate = fromDate,
                            toDate = toDate,
                            isExcel = false,
                            defaultFileName = defaultFileName,
                            selectedColumns = selectedSmartColumns
                        )
                        showSmartExportSheet = false
                        createPdfLauncher.launch(defaultFileName)
                    },
                    onDismiss = { showSmartExportSheet = false }
                )
            }
        }
    }
}

// =========================================================================
// مكونات Glassmorphism الأساسية للشاشة
// =========================================================================

@Composable
private fun GlassmorphicCard(
    accentColor: Color = PrimaryTeal,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = 5.dp,
                shape = shape,
                clip = false,
                ambientColor = accentColor.copy(alpha = 0.14f),
                spotColor = Color(0x1A0F172A)
            )
            .clip(shape)
            .background(GlassCardTint)
            .border(width = 1.dp, brush = GlassBorderBrush, shape = shape)
            .animateContentSize(animationSpec = tween(260))
    ) {
        Column(modifier = Modifier.fillMaxWidth(), content = content)
    }
}

@Composable
private fun GlassIconBadge(
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(38.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(tint.copy(alpha = 0.13f))
            .border(1.dp, Color.White.copy(alpha = 0.85f), RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun GlassDateBox(
    label: String,
    dateValue: String,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(16.dp)
    Surface(
        onClick = onClick,
        shape = shape,
        color = Color.White.copy(alpha = 0.72f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.CalendarToday,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(16.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(label, fontSize = 10.sp, color = SlateMuted)
                Text(
                    text = dateValue,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    color = SlateTitle,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun GlassKpiCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    gradientColors: List<Color>,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(24.dp)
    val mainAccent = gradientColors.firstOrNull() ?: PrimaryTeal
    Box(
        modifier = modifier
            .shadow(
                elevation = 6.dp,
                shape = shape,
                clip = false,
                ambientColor = mainAccent.copy(alpha = 0.18f),
                spotColor = Color(0x1A0F172A)
            )
            .clip(shape)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.85f),
                        mainAccent.copy(alpha = 0.10f)
                    )
                )
            )
            .border(1.dp, GlassBorderBrush, shape)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(gradientColors)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = mainAccent.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = subtitle,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = mainAccent,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = value,
                fontSize = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                color = SlateTitle
            )
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SlateMuted,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CompactGlassMetric(
    icon: ImageVector,
    label: String,
    value: String,
    tint: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Column(horizontalAlignment = Alignment.Start) {
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = SlateTitle)
            Text(label, fontSize = 10.sp, color = SlateMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// =========================================================================
// نافذة التصدير الذكية المنبثقة (Smart Export Interactive ModalBottomSheet)
// =========================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SmartExportModalBottomSheet(
    fromDate: String,
    toDate: String,
    categories: List<String>,
    selectedCategory: String?,
    regions: List<String>,
    selectedRegions: Set<String>,
    selectedColumnKeys: List<String>,
    isExporting: Boolean,
    canExportExcel: Boolean,
    canExportPdf: Boolean,
    onSelectCategory: (String?) -> Unit,
    onToggleRegion: (String) -> Unit,
    onToggleSelectAllRegions: () -> Unit,
    onToggleColumn: (String) -> Unit,
    onSelectDefaultColumns: () -> Unit,
    onSelectAllColumns: () -> Unit,
    onExportExcel: () -> Unit,
    onExportPdf: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scrollState = rememberScrollState()
    val allRegionsSelected = regions.isNotEmpty() && selectedRegions.size == regions.size
    val canProceedExport = !isExporting &&
        categories.isNotEmpty() &&
        selectedRegions.isNotEmpty() &&
        selectedColumnKeys.isNotEmpty()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor = Color(0xFFF4F9FC),
        dragHandle = { BottomSheetDefaults.DragHandle(color = PrimaryTeal.copy(alpha = 0.45f)) }
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ترويسة النافذة الذكية
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Brush.linearGradient(listOf(PrimaryTeal, PrimarySky))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FileUpload,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "استخراج وتصدير التقارير 📤",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = SlateTitle
                            )
                            Text(
                                text = "الفترة: من $fromDate إلى $toDate",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = PrimaryTeal
                            )
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = SlateMuted)
                    }
                }

                // المحتوى التفاعلي القابل للتمرير
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .heightIn(max = 480.dp)
                        .verticalScroll(scrollState),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // 1. اختيار تصنيف المساعدة (ديناميكي من قاعدة البيانات للفترة المختارة)
                    GlassmorphicCard(accentColor = PrimaryTeal) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    GlassIconBadge(icon = Icons.Default.Category, tint = PrimaryTeal)
                                    Column {
                                        Text(
                                            text = "1. اختيار تصنيف المساعدة",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = SlateTitle
                                        )
                                        Text(
                                            text = "التصنيفات المصروفة فعلياً خلال الفترة",
                                            fontSize = 10.sp,
                                            color = SlateMuted
                                        )
                                    }
                                }
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = PrimaryTeal.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "${categories.size} تصنيف",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryTeal,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            if (categories.isEmpty()) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color(0xFFFEF3C7).copy(alpha = 0.7f),
                                    border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.35f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "لا توجد مساعدات منفذة مسجلة ضمن الفترة الزمنية المحددة.",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF92400E),
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            } else {
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    item {
                                        val isAllSelected = selectedCategory == null
                                        FilterChip(
                                            selected = isAllSelected,
                                            onClick = { onSelectCategory(null) },
                                            label = {
                                                Text(
                                                    text = "كافة التصنيفات",
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isAllSelected) FontWeight.Bold else FontWeight.Medium
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = PrimaryTeal,
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                    items(categories) { category ->
                                        val isSel = selectedCategory == category
                                        FilterChip(
                                            selected = isSel,
                                            onClick = { onSelectCategory(category) },
                                            label = {
                                                Text(
                                                    text = category,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                                                )
                                            },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = PrimaryTeal,
                                                selectedLabelColor = Color.White
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 2. فلتر المناطق المستفيدة التفاعلي (Multi-Select Checkboxes + تحديد الكل)
                    GlassmorphicCard(accentColor = PrimarySky) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    GlassIconBadge(icon = Icons.Default.LocationOn, tint = PrimarySky)
                                    Column {
                                        Text(
                                            text = "2. فلتر المناطق المستفيدة",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = SlateTitle
                                        )
                                        Text(
                                            text = "تظهر ديناميكياً حسب التصنيف والفترة",
                                            fontSize = 10.sp,
                                            color = SlateMuted
                                        )
                                    }
                                }

                                if (regions.isNotEmpty()) {
                                    OutlinedButton(
                                        onClick = onToggleSelectAllRegions,
                                        shape = RoundedCornerShape(12.dp),
                                        border = BorderStroke(1.dp, PrimarySky.copy(alpha = 0.45f)),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (allRegionsSelected) Icons.Default.CheckBox else Icons.Default.SelectAll,
                                            contentDescription = null,
                                            tint = PrimarySky,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (allRegionsSelected) "إلغاء الكل" else "تحديد الكل",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PrimarySky
                                        )
                                    }
                                }
                            }

                            if (regions.isEmpty()) {
                                Text(
                                    text = "لا توجد مناطق مستفيدة مطابقة للتصنيف والفترة المختارة.",
                                    fontSize = 11.sp,
                                    color = SlateMuted,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            } else {
                                Text(
                                    text = "المناطق المحددة: ${selectedRegions.size} من ${regions.size}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimarySky
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    regions.chunked(2).forEach { rowRegions ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            rowRegions.forEach { region ->
                                                val checked = region in selectedRegions
                                                Surface(
                                                    onClick = { onToggleRegion(region) },
                                                    shape = RoundedCornerShape(12.dp),
                                                    color = if (checked) PrimarySky.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.7f),
                                                    border = BorderStroke(
                                                        1.dp,
                                                        if (checked) PrimarySky.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.9f)
                                                    ),
                                                    modifier = Modifier.weight(1f)
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Checkbox(
                                                            checked = checked,
                                                            onCheckedChange = { onToggleRegion(region) },
                                                            colors = CheckboxDefaults.colors(checkedColor = PrimarySky),
                                                            modifier = Modifier.size(20.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Text(
                                                            text = region,
                                                            fontSize = 11.sp,
                                                            fontWeight = if (checked) FontWeight.Bold else FontWeight.Medium,
                                                            color = SlateTitle,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                    }
                                                }
                                            }
                                            if (rowRegions.size == 1) {
                                                Spacer(modifier = Modifier.weight(1f))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // 3. حقول البيانات المطلوبة في التصدير (Dynamic Columns Checkboxes)
                    GlassmorphicCard(accentColor = IndigoAccent) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    GlassIconBadge(icon = Icons.Default.ViewColumn, tint = IndigoAccent)
                                    Column {
                                        Text(
                                            text = "3. حقول البيانات المطلوبة",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = SlateTitle
                                        )
                                        Text(
                                            text = "${selectedColumnKeys.size} عمود محدد للتصدير",
                                            fontSize = 10.sp,
                                            color = SlateMuted
                                        )
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    TextButton(
                                        onClick = onSelectDefaultColumns,
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Text("الافتراضية", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = PrimaryTeal)
                                    }
                                    TextButton(
                                        onClick = onSelectAllColumns,
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Text("الكل", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = IndigoAccent)
                                    }
                                }
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                ExportColumnRegistry.ALL_COLUMNS.chunked(2).forEach { pair ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        pair.forEach { colDef ->
                                            val isChecked = colDef.key in selectedColumnKeys
                                            Surface(
                                                onClick = { onToggleColumn(colDef.key) },
                                                shape = RoundedCornerShape(12.dp),
                                                color = if (isChecked) IndigoAccent.copy(alpha = 0.11f) else Color.White.copy(alpha = 0.7f),
                                                border = BorderStroke(
                                                    1.dp,
                                                    if (isChecked) IndigoAccent.copy(alpha = 0.40f) else Color.White.copy(alpha = 0.9f)
                                                ),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Checkbox(
                                                        checked = isChecked,
                                                        onCheckedChange = { onToggleColumn(colDef.key) },
                                                        colors = CheckboxDefaults.colors(checkedColor = IndigoAccent),
                                                        modifier = Modifier.size(20.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = colDef.label,
                                                        fontSize = 10.5.sp,
                                                        fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Medium,
                                                        color = SlateTitle,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }
                                        }
                                        if (pair.size == 1) {
                                            Spacer(modifier = Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // رسالة تنبيه عند نقص الاختيارات
                if (!canProceedExport && !isExporting) {
                    val hint = when {
                        categories.isEmpty() -> "لا توجد بيانات مساعدات منفذة في الفترة المحددة."
                        selectedRegions.isEmpty() -> "يرجى اختيار منطقة مستفيدة واحدة على الأقل."
                        selectedColumnKeys.isEmpty() -> "يرجى تحديد حقل بيانات واحد على الأقل للتصدير."
                        else -> ""
                    }
                    if (hint.isNotEmpty()) {
                        Text(
                            text = hint,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFB45309)
                        )
                    }
                }

                // 4. أزرار التنفيذ النهائية: تصدير Excel 📊 و تصدير PDF 📄
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (canExportExcel) {
                        Button(
                            onClick = onExportExcel,
                            enabled = canProceedExport,
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PrimarySky,
                                disabledContainerColor = PrimarySky.copy(alpha = 0.35f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            if (isExporting) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("جارِ التصدير...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تصدير Excel 📊", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }

                    if (canExportPdf) {
                        Button(
                            onClick = onExportPdf,
                            enabled = canProceedExport,
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PrimaryTeal,
                                disabledContainerColor = PrimaryTeal.copy(alpha = 0.35f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            if (isExporting) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.White)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("جارِ المعالجة...", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            } else {
                                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("تصدير PDF 📄", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// المخططات البيانية الحية وبطاقة النطاق الجغرافي (Dynamic DB Charts)
// =========================================================================

@Composable
private fun LocalityDistributionDonutChart(localityStats: List<LocalityDistributionStat>) {
    val activeStats = remember(localityStats) {
        localityStats.filter { it.deliveredAidCount > 0 || it.familiesCount > 0 }
    }
    var listVisible by remember { mutableStateOf(false) }
    LaunchedEffect(activeStats) { listVisible = true }

    if (activeStats.isEmpty()) {
        Box(modifier = Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد بيانات توزيع للمحليات", color = SlateMuted, fontSize = 12.sp)
        }
        return
    }

    val palette = listOf(
        PrimaryTeal, PrimarySky, EmeraldAccent,
        Color(0xFFF59E0B), Color(0xFF8B5CF6), Color(0xFFEC4899),
        Color(0xFF06B6D4), Color(0xFFF97316)
    )

    val totalAid = activeStats.sumOf { it.deliveredAidCount }
    val sweepProgress by animateFloatAsState(
        targetValue = if (listVisible) 1f else 0f,
        animationSpec = tween(durationMillis = 650),
        label = "DonutSweep"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .animateContentSize(animationSpec = tween(280)),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = PrimaryTeal.copy(alpha = 0.06f),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.85f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(modifier = Modifier.size(134.dp), contentAlignment = Alignment.Center) {
                    Canvas(modifier = Modifier.size(118.dp)) {
                        var currentAngle = -90f
                        val strokeWidthPx = 24f

                        activeStats.forEachIndexed { i, stat ->
                            val rawSweep = if (totalAid > 0) (stat.deliveredAidCount.toFloat() / totalAid.toFloat()) * 360f else (360f / activeStats.size)
                            val sweepAngle = rawSweep * sweepProgress
                            val color = palette[i % palette.size]

                            drawArc(
                                color = color,
                                startAngle = currentAngle,
                                sweepAngle = sweepAngle,
                                useCenter = false,
                                style = Stroke(width = strokeWidthPx, cap = StrokeCap.Round)
                            )
                            currentAngle += rawSweep
                        }
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$totalAid", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = PrimaryTeal)
                        Text("مساعدة", fontSize = 10.sp, color = SlateMuted)
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
                    Text(
                        text = "ملخص توزيع المحليات",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = SlateTitle
                    )
                    Text(
                        text = "${activeStats.size} محليات نشطة • إجمالي ${activeStats.sumOf { it.familiesCount }} أسرة",
                        fontSize = 11.sp,
                        color = SlateMuted
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 320.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            activeStats.forEachIndexed { i, stat ->
                val color = palette[i % palette.size]
                val percent = if (totalAid > 0) (stat.deliveredAidCount * 100 / totalAid) else 0
                val delay = (i * 45).coerceAtMost(320)

                AnimatedVisibility(
                    visible = listVisible,
                    enter = fadeIn(tween(300, delayMillis = delay)) +
                        slideInVertically(tween(300, delayMillis = delay)) { it / 3 }
                ) {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White.copy(alpha = 0.78f),
                        border = BorderStroke(1.dp, color.copy(alpha = 0.25f)),
                        shadowElevation = 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 11.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                )
                                Column {
                                    Text(
                                        text = stat.localityName,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SlateTitle,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${stat.familiesCount} أسرة مسجلة",
                                        fontSize = 10.sp,
                                        color = SlateMuted
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = color.copy(alpha = 0.13f),
                                border = BorderStroke(1.dp, color.copy(alpha = 0.28f))
                            ) {
                                Text(
                                    text = "${stat.deliveredAidCount} طرد ($percent%)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = color,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AidCategoriesDistributionChart(
    classificationStats: List<AidClassificationStat>
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .animateContentSize(animationSpec = tween(280)),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "تحليل تصنيفات المساعدات الفعلية من قاعدة البيانات:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = PrimaryTeal
            )
            if (classificationStats.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = PrimaryTeal.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, PrimaryTeal.copy(alpha = 0.25f))
                ) {
                    Text(
                        text = "${classificationStats.size} تصنيف نشط",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryTeal,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        if (classificationStats.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                PrimaryTeal.copy(alpha = 0.08f),
                                PrimarySky.copy(alpha = 0.05f)
                            )
                        )
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.85f), RoundedCornerShape(24.dp))
                    .padding(vertical = 28.dp, horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Category,
                        contentDescription = null,
                        tint = PrimaryTeal.copy(alpha = 0.65f),
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = "لا توجد سجلات تصنيفات مساعدات في قاعدة البيانات حتى الآن",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = SlateMuted,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            val totalAllCategories = remember(classificationStats) {
                classificationStats.sumOf { it.total }.coerceAtLeast(1)
            }
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                classificationStats.forEach { stat ->
                    key(stat.classificationName) {
                        AidClassificationGlassCard(
                            stat = stat,
                            totalAllCategories = totalAllCategories
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AidClassificationGlassCard(
    stat: AidClassificationStat,
    totalAllCategories: Int
) {
    val denominator = (stat.candidatesCount + stat.beneficiariesCount).takeIf { it > 0 } ?: stat.total
    val targetProgress = if (denominator > 0) {
        (stat.beneficiariesCount.toFloat() / denominator.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    val categorySharePct = if (totalAllCategories > 0) {
        (stat.total.toDouble() / totalAllCategories.toDouble()) * 100.0
    } else {
        0.0
    }
    var isAnimated by remember(stat.classificationName) { mutableStateOf(false) }
    LaunchedEffect(stat.classificationName, targetProgress) {
        isAnimated = true
    }
    val animatedProgress by animateFloatAsState(
        targetValue = if (isAnimated) targetProgress else 0f,
        animationSpec = tween(durationMillis = 750, easing = FastOutSlowInEasing),
        label = "AidClassificationProgress_${stat.classificationName}"
    )

    val candidateOrange = Color(0xFFF59E0B)
    val beneficiaryGreen = EmeraldAccent
    val percentageText = String.format(Locale.US, "%.1f%%", targetProgress * 100f)
    val sharePercentageText = String.format(Locale.US, "%.1f%%", categorySharePct)
    val cardShape = RoundedCornerShape(24.dp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 4.dp,
                shape = cardShape,
                clip = false,
                ambientColor = PrimaryTeal.copy(alpha = 0.14f),
                spotColor = Color(0x1A000000)
            )
            .clip(cardShape)
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.84f),
                        Color(0xFFF0FDFA).copy(alpha = 0.72f)
                    )
                )
            )
            .border(width = 1.dp, brush = GlassBorderBrush, shape = cardShape)
            .animateContentSize(animationSpec = tween(260))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    GlassIconBadge(icon = Icons.Default.VolunteerActivism, tint = PrimaryTeal)
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stat.classificationName,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = SlateTitle,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "حصة التصنيف: $sharePercentageText من الإجمالي",
                            fontSize = 10.sp,
                            color = SlateMuted
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color.White.copy(alpha = 0.76f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.9f))
                ) {
                    Text(
                        text = "الإجمالي: ${stat.total}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SlateTitle,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    color = candidateOrange.copy(alpha = 0.11f),
                    border = BorderStroke(1.dp, candidateOrange.copy(alpha = 0.28f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "عدد المرشحين:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFB45309)
                            )
                            Text(
                                text = "${stat.candidatesCount}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFD97706)
                            )
                        }
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    color = beneficiaryGreen.copy(alpha = 0.11f),
                    border = BorderStroke(1.dp, beneficiaryGreen.copy(alpha = 0.28f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF059669),
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "عدد المستفيدين:",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF047857)
                            )
                            Text(
                                text = "${stat.beneficiariesCount}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF059669)
                            )
                        }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "نسبة المستفيدين من إجمالي المرشحين والمستفيدين",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = SlateMuted,
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = percentageText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF059669)
                    )
                }

                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(9.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    color = beneficiaryGreen,
                    trackColor = candidateOrange.copy(alpha = 0.18f)
                )
            }
        }
    }
}

@Composable
private fun FamilyClassificationsChart(
    residentStats: List<KeyCountRecord>,
    warDamageStats: List<KeyCountRecord>
) {
    val activeResident = remember(residentStats) { residentStats.filter { it.count > 0 } }
    val activeDamage = remember(warDamageStats) { warDamageStats.filter { it.count > 0 } }
    var listVisible by remember { mutableStateOf(false) }
    LaunchedEffect(activeResident, activeDamage) { listVisible = true }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 380.dp)
            .verticalScroll(rememberScrollState())
            .animateContentSize(animationSpec = tween(280)),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "1. صفة الإقامة (مقيم / نازح):",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = PrimaryTeal
        )
        val totalResident = activeResident.sumOf { it.count }.coerceAtLeast(1)
        if (activeResident.isNotEmpty()) {
            activeResident.forEachIndexed { idx, stat ->
                val pct = (stat.count * 100) / totalResident
                val animatedProgress by animateFloatAsState(
                    targetValue = if (listVisible) (pct / 100f).coerceIn(0f, 1f) else 0f,
                    animationSpec = tween(550),
                    label = "ResidentProg_$idx"
                )
                val accent = PrimaryTeal
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White.copy(alpha = 0.78f),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.22f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stat.keyName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = SlateTitle
                            )
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = accent.copy(alpha = 0.13f),
                                border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
                            ) {
                                Text(
                                    text = "${stat.count} أسرة ($pct%)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = accent,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        LinearProgressIndicator(
                            progress = { animatedProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = accent,
                            trackColor = accent.copy(alpha = 0.12f)
                        )
                    }
                }
            }
        } else {
            Text("لا توجد بيانات لحالة الإقامة", fontSize = 11.sp, color = SlateMuted)
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "2. تصنيف أضرار الحرب:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFDC2626)
        )
        val totalDamage = activeDamage.sumOf { it.count }.coerceAtLeast(1)
        if (activeDamage.isNotEmpty()) {
            activeDamage.forEachIndexed { idx, stat ->
                val pct = (stat.count * 100) / totalDamage
                val animatedProgress by animateFloatAsState(
                    targetValue = if (listVisible) (pct / 100f).coerceIn(0f, 1f) else 0f,
                    animationSpec = tween(550),
                    label = "DamageProg_$idx"
                )
                val accent = Color(0xFFEF4444)
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White.copy(alpha = 0.78f),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.22f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stat.keyName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = SlateTitle
                            )
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = accent.copy(alpha = 0.13f),
                                border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
                            ) {
                                Text(
                                    text = "${stat.count} ($pct%)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = accent,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        LinearProgressIndicator(
                            progress = { animatedProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = accent,
                            trackColor = accent.copy(alpha = 0.12f)
                        )
                    }
                }
            }
        } else {
            Text("لا توجد بيانات لأضرار الحرب", fontSize = 11.sp, color = SlateMuted)
        }
    }
}

@Composable
private fun ProjectCompletionRatesCard(
    projects: List<ProjectEntity>,
    projectSummaries: List<ProjectAggregatedSummary> = emptyList()
) {
    if (projects.isEmpty()) {
        Text("لا توجد مشاريع نشطة حالياً", fontSize = 11.sp, color = SlateMuted)
        return
    }

    val summaryMap = remember(projectSummaries) { projectSummaries.associateBy { it.projectNumber } }
    var listVisible by remember { mutableStateOf(false) }
    LaunchedEffect(projects) { listVisible = true }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 360.dp)
            .verticalScroll(rememberScrollState())
            .animateContentSize(animationSpec = tween(280)),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        projects.forEachIndexed { idx, prj ->
            val summary = summaryMap[prj.projectNumber]
            val totalCandidates = summary?.totalCandidates ?: 0
            val totalDelivered = summary?.totalReceived ?: 0
            val completionRate = if (totalCandidates > 0) {
                ((totalDelivered.toFloat() / totalCandidates.toFloat()) * 100f).coerceIn(0f, 100f)
            } else 0f
            val progressFraction = (completionRate / 100f).coerceIn(0f, 1f)
            val animatedProgress by animateFloatAsState(
                targetValue = if (listVisible) progressFraction else 0f,
                animationSpec = tween(550),
                label = "ProjProg_$idx"
            )
            val accent = if (completionRate >= 100f) EmeraldAccent else PrimarySky

            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color.White.copy(alpha = 0.78f),
                border = BorderStroke(1.dp, accent.copy(alpha = 0.24f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = prj.projectName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = SlateTitle,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${prj.projectNumber} • الممول: ${prj.fundingInstitution}",
                                fontSize = 10.sp,
                                color = SlateMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = accent.copy(alpha = 0.13f),
                            border = BorderStroke(1.dp, accent.copy(alpha = 0.28f))
                        ) {
                            Text(
                                text = "${completionRate.toInt()}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = accent,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "المستفيدون الفعليون: $totalDelivered من $totalCandidates مرشح",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = SlateMuted
                        )
                        Text(
                            text = prj.projectDate,
                            fontSize = 10.sp,
                            color = SlateMuted
                        )
                    }

                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = accent,
                        trackColor = accent.copy(alpha = 0.12f)
                    )
                }
            }
        }
    }
}

/**
 * بطاقة إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية المفصلة والديناميكية (Glassmorphism)
 */
@Composable
fun DynamicReportsGeoDamageCard(
    localities: List<String>,
    selectedLocality: String,
    selectedSubArea: String,
    availableSubAreas: List<String>,
    localityFamilyCount: Int,
    subAreaFamilyCount: Int,
    localityCounts: Map<String, Int>,
    completelyDestroyedCount: Int,
    warDamageStats: WarDamageStats?,
    damageDistribution: List<DamageTypeBreakdown>,
    damageDetailsByRegion: Map<String, Map<String, Int>> = emptyMap(),
    isLocalityLocked: Boolean = false,
    isBranchLocked: Boolean = false,
    canViewAllBranches: Boolean = true,
    lockedBranchName: String? = null,
    onLocalitySelected: (String) -> Unit,
    onSubAreaSelected: (String) -> Unit
) {
    var localityExpanded by remember { mutableStateOf(false) }
    var subAreaExpanded by remember { mutableStateOf(false) }

    val selectedLocalityName = selectedLocality.ifBlank { "اختر المحلية" }

    GlassmorphicCard(accentColor = PrimarySky) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassIconBadge(icon = Icons.Default.LocationCity, tint = PrimarySky)
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "إحصائيات النطاق الجغرافي وأضرار المناطق",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = SlateTitle
                    )
                    Text(
                        text = "اختر المحلية والشعبة لعرض التوزيع التجميعي للأسر وأضرار الحرب:",
                        fontSize = 11.sp,
                        color = SlateMuted
                    )
                }
            }

            val displayBranch = lockedBranchName.takeIf { isBranchLocked && !it.isNullOrBlank() }
                ?: selectedSubArea
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { if (!isLocalityLocked) localityExpanded = true },
                        enabled = !isLocalityLocked,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White.copy(alpha = 0.72f)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Icon(
                                    imageVector = if (isLocalityLocked) Icons.Default.Lock else Icons.Default.LocationCity,
                                    contentDescription = null,
                                    tint = if (isLocalityLocked) SlateMuted else Color(0xFF16A34A),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = selectedLocalityName,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTitle,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (!isLocalityLocked) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF16A34A))
                            }
                        }
                    }

                    DropdownMenu(
                        expanded = localityExpanded && !isLocalityLocked,
                        onDismissRequest = { localityExpanded = false }
                    ) {
                        localities.forEach { locName ->
                            val count = localityCounts[locName] ?: 0
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            locName,
                                            fontWeight = if (locName == selectedLocality) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("($count أسرة)", fontSize = 11.sp, color = Color(0xFF16A34A))
                                    }
                                },
                                onClick = {
                                    onLocalitySelected(locName)
                                    localityExpanded = false
                                }
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { if (!isBranchLocked) subAreaExpanded = true },
                        enabled = !isBranchLocked,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White.copy(alpha = 0.72f)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Icon(
                                    imageVector = if (isBranchLocked) Icons.Default.Lock else Icons.Default.AltRoute,
                                    contentDescription = null,
                                    tint = if (isBranchLocked) SlateMuted else PrimarySky,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = displayBranch.ifBlank { if (canViewAllBranches) "كافة الشعب" else "اختر الشعبة" },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTitle,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (!isBranchLocked) {
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = PrimarySky)
                            }
                        }
                    }

                    DropdownMenu(
                        expanded = subAreaExpanded && !isBranchLocked,
                        onDismissRequest = { subAreaExpanded = false }
                    ) {
                        if (canViewAllBranches) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        "كافة الشعب",
                                        fontWeight = if (selectedSubArea.isBlank()) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onSubAreaSelected("")
                                    subAreaExpanded = false
                                }
                            )
                        }

                        availableSubAreas.forEach { sub ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        sub,
                                        fontWeight = if (sub == selectedSubArea) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onSubAreaSelected(sub)
                                    subAreaExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReportGeoStatBadge(
                    title = "أسر المحلية",
                    value = "$localityFamilyCount",
                    subtitle = selectedLocalityName,
                    color = Color(0xFF16A34A),
                    icon = Icons.Default.Groups,
                    modifier = Modifier.weight(1f)
                )

                ReportGeoStatBadge(
                    title = "أسر الشعبة",
                    value = if (displayBranch.isNotBlank()) "$subAreaFamilyCount" else "الكل",
                    subtitle = displayBranch.ifBlank { "غير مقيد بشعبة" },
                    color = PrimarySky,
                    icon = Icons.Default.LocationOn,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReportGeoStatBadge(
                    title = "منازل مهدمة كلياً",
                    value = "$completelyDestroyedCount",
                    subtitle = "أضرار كلية بالنطاق",
                    color = Color(0xFFDC2626),
                    icon = Icons.Default.HomeWork,
                    modifier = Modifier.weight(1f)
                )

                val totalAssessed = warDamageStats?.totalAssessed ?: 0
                ReportGeoStatBadge(
                    title = "إجمالي أضرار الحرب",
                    value = "$totalAssessed",
                    subtitle = "منازل مسجلة بالنطاق",
                    color = Color(0xFFD97706),
                    icon = Icons.Default.Warning,
                    modifier = Modifier.weight(1f)
                )
            }

            warDamageStats?.let { ws ->
                if (ws.totalAssessed > 0) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.68f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.85f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "تفصيل الحالات الهندسية والإنشائية المسجلة:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SlateTitle
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MiniDamagePill(
                                    label = "جزئي بليغ",
                                    count = ws.severePartialDamageCount,
                                    color = Color(0xFFEA580C),
                                    modifier = Modifier.weight(1f)
                                )
                                MiniDamagePill(
                                    label = "جزئي طفيف",
                                    count = ws.minorPartialDamageCount,
                                    color = Color(0xFFCA8A04),
                                    modifier = Modifier.weight(1f)
                                )
                                MiniDamagePill(
                                    label = "سليم / لا ضرر",
                                    count = ws.noDamageCount,
                                    color = Color(0xFF16A34A),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            if (damageDistribution.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White.copy(alpha = 0.62f),
                    border = BorderStroke(1.dp, Color(0xFF16A34A).copy(alpha = 0.18f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(animationSpec = tween(280))
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "توزيع درجات الأضرار المسجلة ميدانياً بالنطاق:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = SlateTitle
                        )
                        val total = damageDistribution.sumOf { it.count }.coerceAtLeast(1)
                        damageDistribution.forEach { item ->
                            val percent = (item.count.toDouble() / total.toDouble()) * 100
                            val accent = Color(0xFF16A34A)
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Color.White.copy(alpha = 0.85f),
                                border = BorderStroke(1.dp, accent.copy(alpha = 0.2f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(11.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = item.damageType,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = SlateTitle,
                                            modifier = Modifier.weight(1f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Surface(
                                            shape = RoundedCornerShape(20.dp),
                                            color = accent.copy(alpha = 0.12f),
                                            border = BorderStroke(1.dp, accent.copy(alpha = 0.26f))
                                        ) {
                                            Text(
                                                text = "${item.count} منزل (${String.format(Locale.US, "%.1f%%", percent)})",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = accent,
                                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                    LinearProgressIndicator(
                                        progress = { (item.count.toFloat() / total.toFloat()).coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(5.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = accent,
                                        trackColor = accent.copy(alpha = 0.12f)
                                    )
                                    val regionMap = damageDetailsByRegion[item.damageType]
                                    if (!regionMap.isNullOrEmpty()) {
                                        val topRegions = regionMap.entries.sortedByDescending { it.value }.take(3)
                                        Text(
                                            text = topRegions.joinToString(" • ") { "${it.key}: ${it.value}" },
                                            fontSize = 10.sp,
                                            color = SlateMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportGeoStatBadge(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = color.copy(alpha = 0.09f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
                Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = color)
            }
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = SlateMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MiniDamagePill(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.09f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.22f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "$count", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = label, fontSize = 9.sp, color = SlateMuted)
        }
    }
}
