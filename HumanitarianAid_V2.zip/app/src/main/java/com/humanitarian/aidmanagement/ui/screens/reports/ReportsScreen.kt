package com.humanitarian.aidmanagement.ui.screens.reports

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.DashboardStats
import com.humanitarian.aidmanagement.util.DistributionPdfReportData
import com.humanitarian.aidmanagement.util.PdfReportExporter
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val pdfExporter = remember { PdfReportExporter(context) }
    var stats by remember { mutableStateOf<DashboardStats?>(null) }
    var selectedReportType by remember { mutableStateOf("الكل") }
    var exportSuccessMessage by remember { mutableStateOf<String?>(null) }
    var generatedPdfFile by remember { mutableStateOf<File?>(null) }
    var isGeneratingPdf by remember { mutableStateOf(false) }
    var subAreaRatios by remember { mutableStateOf<List<com.humanitarian.aidmanagement.data.repository.SubAreaBenefitRatioStat>>(emptyList()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        stats = repository.getDashboardStats()
        subAreaRatios = repository.calculateSubAreaBenefitRatios()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "التقارير وتصدير المستندات (PDF)",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                "كشوفات توزيع رسمية وسجلات معتمدة للطباعة",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "توليد كشوفات التوزيع وتقارير PDF الرسمية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "استخراج مستندات PDF معتمدة تتضمن جداول المستلمين ومربعات التوقيع والبصمة، مع دعم الطباعة المباشرة والمشاركة الميدانية.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // شريط تصفية التقارير أفقياً لمنع التداخل
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val reportFilters = listOf("الكل", "كشوفات التوزيع", "الأسر", "المستفيدين", "توزيع المحليات")
                                items(reportFilters) { type ->
                                    FilterChip(
                                        selected = selectedReportType == type,
                                        onClick = { selectedReportType = type },
                                        label = { Text(type, style = MaterialTheme.typography.labelSmall) },
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // إشعار نجاح توليد الـ PDF مع أزرار المشاركة والطباعة
                if (generatedPdfFile != null) {
                    item {
                        val file = generatedPdfFile!!
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981).copy(alpha = 0.12f)),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF10B981).copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(Color(0xFF10B981).copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(24.dp))
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "تم إنشاء مستند الـ PDF بنجاح!",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = Color(0xFF047857)
                                        )
                                        Text(
                                            text = "${file.name} • ${file.length() / 1024} كيلوبايت",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Button(
                                        onClick = { pdfExporter.sharePdfReport(file) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(44.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("مشاركة", style = MaterialTheme.typography.bodySmall)
                                    }

                                    Button(
                                        onClick = { pdfExporter.printPdfReport(file) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(44.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                    ) {
                                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("طباعة فورية", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                } else if (exportSuccessMessage != null) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = exportSuccessMessage ?: "",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }

                // بطاقة نسب الاستفادة والترشيح الدقيقة للمناطق (المستفيدين / المستحقين: مقيم + معتمد)
                if (selectedReportType == "الكل" || selectedReportType == "توزيع المحليات") {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.Analytics, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(22.dp))
                                        Column {
                                            Text(
                                                "نسب الاستفادة الدقيقة للمناطق الفرعية",
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.titleSmall
                                            )
                                            Text(
                                                "معادلة الاستحقاق: (المستفيدين / الأسر المستحقة مقيم + معتمد)",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = Color(0xFF10B981).copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "فلترة Room DAO",
                                            color = Color(0xFF047857),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }

                                if (subAreaRatios.isEmpty()) {
                                    Text(
                                        "جاري احتساب النسب الدقيقة من قاعدة البيانات عبر Dispatchers.IO...",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        subAreaRatios.forEach { ratioItem ->
                                            SubAreaRatioRow(item = ratioItem)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 1. بطاقة تقرير كشف توزيع المساعدات الميداني (PDF)
                item {
                    PdfReportCard(
                        title = "كشف توزيع المساعدات الميداني (PDF)",
                        description = "كشف رسمي جاهز للطباعة والتوقيع يتضمن أرقام الهويات ومربعات البصمة لـ ${stats?.totalSelectedCandidates ?: 0} مرشح",
                        badge = "مستند رسمي PDF",
                        icon = Icons.Default.PictureAsPdf,
                        color = Color(0xFF0D9488),
                        isLoading = isGeneratingPdf,
                        onExportPdf = {
                            scope.launch {
                                isGeneratingPdf = true
                                try {
                                    val candidates = repository.runNomination(null, 1, 1L, 50)
                                    val reportData = DistributionPdfReportData(
                                        reportTitle = "كشف توزيع المساعدات الإنسانية الميداني",
                                        projectName = "مشروع الإغاثة العاجلة وتوزيع الطرود",
                                        aidTypeName = "غذائي",
                                        localityName = "جميع المحليات المعتمدة",
                                        date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                                        supervisorName = repository.getCurrentUser()?.FullName ?: "مشرف التوزيع الميداني",
                                        candidates = candidates
                                    )
                                    val file = pdfExporter.generateDistributionReportPdf(reportData)
                                    generatedPdfFile = file
                                    exportSuccessMessage = "تم توليد ملف PDF بنجاح."
                                } catch (e: Exception) {
                                    exportSuccessMessage = "خطأ أثناء توليد PDF: ${e.localizedMessage}"
                                } finally {
                                    isGeneratingPdf = false
                                }
                            }
                        }
                    )
                }

                // 2. تقرير الأسر الشامل
                item {
                    PdfReportCard(
                        title = "تقرير الأسر الشامل حسب المحلية والحالة",
                        description = "بيانات ${stats?.totalFamilies ?: 0} أسرة مسجلة في Room Database مع أرقام الهويات وحالة الإيواء",
                        badge = "سجل الأسر",
                        icon = Icons.Default.FamilyRestroom,
                        color = Color(0xFF0284C7),
                        isLoading = isGeneratingPdf,
                        onExportPdf = {
                            scope.launch {
                                isGeneratingPdf = true
                                try {
                                    val candidates = repository.runNomination(null, 1, 1L, 40)
                                    val reportData = DistributionPdfReportData(
                                        reportTitle = "تقرير حصر الأسر والمستفيدين الشامل",
                                        projectName = "حصر وتحديث بيانات الأسر الميدانية",
                                        aidTypeName = "بيانات عامة",
                                        localityName = "كافة المحليات",
                                        date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                                        supervisorName = repository.getCurrentUser()?.FullName ?: "إدارة المنظومة",
                                        candidates = candidates
                                    )
                                    val file = pdfExporter.generateDistributionReportPdf(reportData)
                                    generatedPdfFile = file
                                } finally {
                                    isGeneratingPdf = false
                                }
                            }
                        }
                    )
                }

                // 3. تقرير المستفيدين وسجلات الاستلام الفعلية
                item {
                    PdfReportCard(
                        title = "ملخص المستفيدين وسندات الصرف الميدانية",
                        description = "سجلات المساعدات المسلمة (${stats?.totalAidRecords ?: 0}) والمستودعات ومطابقة المستلمين",
                        badge = "سندات صرف",
                        icon = Icons.Default.FactCheck,
                        color = Color(0xFF8B5CF6),
                        isLoading = isGeneratingPdf,
                        onExportPdf = {
                            scope.launch {
                                isGeneratingPdf = true
                                try {
                                    val candidates = repository.runNomination(null, 1, 1L, 30)
                                    val reportData = DistributionPdfReportData(
                                        reportTitle = "سند صرف وتوزيع المساعدات المستلمة",
                                        projectName = "مشروع الكسوة والفرشات الشتوية",
                                        aidTypeName = "فرشات وشوادر",
                                        localityName = "المستودع الرئيسي",
                                        date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                                        supervisorName = "أمين المستودع المركزي",
                                        candidates = candidates
                                    )
                                    val file = pdfExporter.generateDistributionReportPdf(reportData)
                                    generatedPdfFile = file
                                } finally {
                                    isGeneratingPdf = false
                                }
                            }
                        }
                    )
                }

                // 4. تقرير نسب وتوزيع المحليات
                item {
                    PdfReportCard(
                        title = "تقرير نسب وتوزيع المحليات",
                        description = "مقارنة الحصص والنسب المئوية المستهدفة بخوارزمية أكبر الكسور مع الأعداد الموزعة",
                        badge = "توزيع جغرافي",
                        icon = Icons.Default.PieChart,
                        color = Color(0xFFF59E0B),
                        isLoading = isGeneratingPdf,
                        onExportPdf = {
                            scope.launch {
                                isGeneratingPdf = true
                                try {
                                    val candidates = repository.runNomination(null, 1, 1L, 25)
                                    val reportData = DistributionPdfReportData(
                                        reportTitle = "تقرير التوزيع الجغرافي لحصص المحليات",
                                        projectName = "توزيع المساعدات حسب نسب المحليات المعتمدة",
                                        aidTypeName = "غذائي",
                                        localityName = "الرمال، الشيخ رضوان، الشاطئ، مشروع عامر",
                                        date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
                                        supervisorName = "لجنة التوزيع المشتركة",
                                        candidates = candidates
                                    )
                                    val file = pdfExporter.generateDistributionReportPdf(reportData)
                                    generatedPdfFile = file
                                } finally {
                                    isGeneratingPdf = false
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun PdfReportCard(
    title: String,
    description: String,
    badge: String,
    icon: ImageVector,
    color: Color,
    isLoading: Boolean,
    onExportPdf: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f, fill = false),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = color.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = badge,
                                color = color,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onExportPdf,
                enabled = !isLoading,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = color),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                } else {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تصدير وطباعة تقرير PDF", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * مكون عرض نسبة الاستفادة الدقيقة لكل منطقة فرعية على حدة
 * مبني على المعادلة: (عدد المستفيدين في تلك المنطقة / إجمالي الأسر المستحقة في نفس المنطقة) * 100
 * حيث الاستحقاق الصارم: (الوضع = مقيم) و (حالة الاعتماد = معتمد)
 */
@Composable
fun SubAreaRatioRow(item: com.humanitarian.aidmanagement.data.repository.SubAreaBenefitRatioStat) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    item.ratioPercentage >= 75.0 -> Color(0xFF10B981)
                                    item.ratioPercentage >= 40.0 -> Color(0xFF3B82F6)
                                    item.ratioPercentage > 0.0 -> Color(0xFFF59E0B)
                                    else -> Color(0xFF94A3B8)
                                }
                            )
                    )
                    Text(
                        text = item.subAreaName,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when {
                        item.ratioPercentage >= 75.0 -> Color(0xFF10B981).copy(alpha = 0.15f)
                        item.ratioPercentage >= 40.0 -> Color(0xFF3B82F6).copy(alpha = 0.15f)
                        item.ratioPercentage > 0.0 -> Color(0xFFF59E0B).copy(alpha = 0.15f)
                        else -> MaterialTheme.colorScheme.surfaceVariant
                    }
                ) {
                    Text(
                        text = item.formattedRatio,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = when {
                            item.ratioPercentage >= 75.0 -> Color(0xFF047857)
                            item.ratioPercentage >= 40.0 -> Color(0xFF1D4ED8)
                            item.ratioPercentage > 0.0 -> Color(0xFFB45309)
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // مؤشر التقدم البصري للنسبة
            LinearProgressIndicator(
                progress = { (item.ratioPercentage / 100.0).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = when {
                    item.ratioPercentage >= 75.0 -> Color(0xFF10B981)
                    item.ratioPercentage >= 40.0 -> Color(0xFF3B82F6)
                    item.ratioPercentage > 0.0 -> Color(0xFFF59E0B)
                    else -> Color(0xFFCBD5E1)
                },
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            // تفصيل الأعداد الدقيقة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "المستفيدين: ${item.deliveredBeneficiariesCount} أسرة",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "المستحقين (مقيم+معتمد): ${item.eligibleFamiliesCount}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "الإجمالي: ${item.totalFamiliesCount}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
    }
}
