package com.humanitarian.aidmanagement.ui.screens.reports

import android.app.DatePickerDialog
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.dao.DamageTypeBreakdown
import com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord
import com.humanitarian.aidmanagement.data.local.dao.LocalityFamilyCount
import com.humanitarian.aidmanagement.data.local.dao.SubAreaFamilyCount
import com.humanitarian.aidmanagement.data.local.dao.WarDamageStats
import com.humanitarian.aidmanagement.data.local.dao.ProjectAggregatedSummary
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.*
import com.humanitarian.aidmanagement.util.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.ui.components.ExportColumnSelectorDialog
import com.humanitarian.aidmanagement.util.ExportColumnRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

sealed class PendingReportExport {
    data class Project(
        val projectId: Long,
        val isExcel: Boolean,
        val defaultFileName: String,
        val selectedColumns: List<String> = emptyList()
    ) : PendingReportExport()

    data class Locality(
        val localityName: String,
        val defaultFileName: String
    ) : PendingReportExport()

    data class Comprehensive(
        val fromDate: String,
        val toDate: String,
        val isExcel: Boolean,
        val defaultFileName: String,
        val selectedColumns: List<String> = emptyList()
    ) : PendingReportExport()
}

sealed class PendingExcelExport {
    data class Project(val projectId: Long, val defaultFileName: String) : PendingExcelExport()
    data class Locality(val localityName: String, val defaultFileName: String) : PendingExcelExport()
    data class Comprehensive(val fromDate: String, val toDate: String, val defaultFileName: String) : PendingExcelExport()
}

enum class ReportDashboardTab(val label: String) {
    PROJECT("المشاريع والمستفيدين"),
    LOCALITY("المحليات والشعب"),
    COMPREHENSIVE_PERIOD("التوزيع الشامل حسب الفترة")
}

enum class VisualChartTab(val label: String) {
    LOCALITY_DISTRIBUTION("توزيع المحليات"),
    AID_CATEGORIES("تصنيفات المساعدات"),
    FAMILY_CLASSIFICATIONS("تصنيفات الأسر"),
    PROJECT_COMPLETION("معدلات إنجاز المشاريع")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    repository: AidRepository,
    viewModel: ReportsViewModel = viewModel(factory = ReportsViewModel.Factory(repository)),
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val exporter = remember { ProfessionalReportExporter(context) }
    val scope = rememberCoroutineScope()

    val geoStats by viewModel.geoDamageStats.collectAsStateWithLifecycle()
    val dynamicLocalities by viewModel.localities.collectAsStateWithLifecycle()

    // نطاق التاريخ
    val defaultCalendar = Calendar.getInstance()
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(defaultCalendar.time)
    val past30DaysCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -30) }
    val past30DaysStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(past30DaysCal.time)

    val fromDate by viewModel.fromDate.collectAsStateWithLifecycle()
    val toDate by viewModel.toDate.collectAsStateWithLifecycle()
    val selectedPreset by viewModel.selectedPreset.collectAsStateWithLifecycle()

    // حالات التبويب
    var selectedReportTab by remember { mutableStateOf(ReportDashboardTab.PROJECT) }
    var selectedChartTab by remember { mutableStateOf(VisualChartTab.LOCALITY_DISTRIBUTION) }

    // بيانات من قاعدة البيانات مستلمة عبر تدفقات تفاعلية مستمرة لمنع التصفير
    val stats by viewModel.dashboardStats.collectAsStateWithLifecycle()
    val localityStats by viewModel.localityStats.collectAsStateWithLifecycle()
    val aidTypeStats by viewModel.aidTypeStats.collectAsStateWithLifecycle()
    val distinctAidCategories by viewModel.distinctAidCategories.collectAsStateWithLifecycle()
    val subAreaRatios by viewModel.subAreaRatios.collectAsStateWithLifecycle()
    val residentStats by viewModel.residentStats.collectAsStateWithLifecycle()
    val warDamageStats by viewModel.warDamageStats.collectAsStateWithLifecycle()
    val activeProjects by viewModel.activeProjects.collectAsStateWithLifecycle()
    val localitiesList by viewModel.localitiesList.collectAsStateWithLifecycle()
    val periodDeliveryCount by viewModel.periodDeliveryCount.collectAsStateWithLifecycle()

    // اختيارات التقارير المحددة
    var selectedProjectId by remember { mutableStateOf<Long?>(null) }
    var selectedLocalityId by remember { mutableStateOf<Int?>(null) }
    var isProjectPickerExpanded by remember { mutableStateOf(false) }
    var isLocalityPickerExpanded by remember { mutableStateOf(false) }

    val projectPreviewList by viewModel.projectPreviewList.collectAsStateWithLifecycle()
    val isLoadingProjectPreview by viewModel.isLoadingProjectPreview.collectAsStateWithLifecycle()
    val comprehensivePreviewList by viewModel.comprehensivePreviewList.collectAsStateWithLifecycle()
    val isLoadingComprehensivePreview by viewModel.isLoadingComprehensivePreview.collectAsStateWithLifecycle()
    val projectSummaries by viewModel.projectSummaries.collectAsStateWithLifecycle()

    LaunchedEffect(activeProjects) {
        if (selectedProjectId == null && activeProjects.isNotEmpty()) {
            val firstId = activeProjects.first().projectID
            selectedProjectId = firstId
            viewModel.loadProjectPreview(firstId)
        }
    }
    LaunchedEffect(localitiesList) {
        if (selectedLocalityId == null && localitiesList.isNotEmpty()) {
            selectedLocalityId = localitiesList.first().LocalityID
        }
    }

    // حالة التصدير عبر الـ ViewModel مع إدارة التخزين الآمن SAF
    val isExporting = viewModel.isExporting
    var pendingExport by remember { mutableStateOf<PendingReportExport?>(null) }
    var exportedFile by remember { mutableStateOf<File?>(null) }
    var exportedFileType by remember { mutableStateOf<String?>(null) } // "PDF" or "EXCEL"
    var exportStatusMessage by remember { mutableStateOf<String?>(null) }

    // حالة حوار اختيار وتخصيص الأعمدة
    var showColumnSelectorDialog by remember { mutableStateOf(false) }
    var columnSelectorFormat by remember { mutableStateOf("EXCEL") }
    var columnSelectorReportTitle by remember { mutableStateOf("") }

    // مشغل نظام التخزين الآمن (Storage Access Framework) لحفظ ملفات Excel عبر Cache-First
    val createExcelLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri: Uri? ->
        if (uri != null) {
            val pending = pendingExport ?: return@rememberLauncherForActivityResult
            scope.launch {
                viewModel.isExporting = true
                try {
                    val result: Result<Unit> = withContext(Dispatchers.IO) {
                        when (pending) {
                            is PendingReportExport.Project -> {
                                val prj = activeProjects.firstOrNull { it.projectID == pending.projectId }
                                    ?: return@withContext Result.failure(Exception("بيانات المشروع المختار غير متوفرة"))
                                
                                // استخدام القائمة المعروضة حالياً على الشاشة مسبقاً دون إعادة استعلام من القاعدة
                                val combined = projectPreviewList.ifEmpty {
                                    repository.getProjectBeneficiariesWithFamilies(pending.projectId)
                                }
                                if (combined.isEmpty()) {
                                    return@withContext Result.failure(Exception("لا توجد سجلات مستفيدين لهذا المشروع حتى الآن"))
                                }
                                val aidTypes = repository.getActiveAidTypes().first().associateBy { it.aidTypeID }

                                val meta = listOf(
                                    "المشروع:" to prj.projectName,
                                    "رقم المشروع:" to prj.projectNumber,
                                    "الجهة الممولة:" to (prj.fundingInstitution ?: "غير محدد"),
                                    "المشرف المسؤول:" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات"),
                                    "نوع المساعدة:" to (aidTypes[prj.aidTypeID]?.aidTypeName ?: "مساعدات إغاثية"),
                                    "تاريخ التقرير:" to SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
                                )
                                exporter.exportDynamicFamiliesExcelToUri(
                                    uri = uri,
                                    title = "كشف مستفيدي المشروع الإنساني - ${prj.projectName}",
                                    metaRows = meta,
                                    records = combined,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS }
                                )
                            }
                            is PendingReportExport.Locality -> {
                                val locFamilies = repository.getFamiliesByLocalitySync(pending.localityName)
                                val totalFam = locFamilies.size
                                val reportData = LocalityReportData(
                                    localityName = pending.localityName,
                                    subAreas = subAreaRatios,
                                    totalFamilies = totalFam,
                                    totalBeneficiaries = subAreaRatios.sumOf { it.eligibleFamiliesCount },
                                    totalDelivered = subAreaRatios.sumOf { it.deliveredBeneficiariesCount },
                                    dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                    supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                )
                                exporter.exportLocalitySubAreasExcelToUri(uri, reportData)
                            }
                            is PendingReportExport.Comprehensive -> {
                                // استخدام القائمة المعروضة حالياً على الشاشة مسبقاً
                                val combined = comprehensivePreviewList.ifEmpty {
                                    repository.getBeneficiariesWithFamiliesInDateRange(pending.fromDate, pending.toDate)
                                }
                                if (combined.isEmpty()) {
                                    return@withContext Result.failure(Exception("لا توجد سجلات توزيع في الفترة المحددة"))
                                }
                                val meta = listOf(
                                    "نطاق الفترة:" to "${pending.fromDate} إلى ${pending.toDate}",
                                    "إجمالي المساعدات:" to "${combined.size} طرد",
                                    "المشرف المسؤول:" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات"),
                                    "تاريخ التقرير:" to SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
                                )
                                exporter.exportDynamicFamiliesExcelToUri(
                                    uri = uri,
                                    title = "تقرير التوزيع الشامل والعمليات الميدانية",
                                    metaRows = meta,
                                    records = combined,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS }
                                )
                            }
                        }
                    }

                    result.onSuccess {
                        exportedFile = null
                        exportStatusMessage = "تم حفظ ملف Excel بنجاح بالأعمدة المخصصة عبر التخزين الآمن (SAF)."
                        Toast.makeText(context, "تم حفظ ملف الإكسل بنجاح في الموقع المختار!", Toast.LENGTH_LONG).show()
                    }.onFailure { err ->
                        exportStatusMessage = "خطأ أثناء حفظ ملف Excel: ${err.message}"
                        Toast.makeText(context, "فشل حفظ ملف الإكسل: ${err.message ?: "حدث خطأ"}", Toast.LENGTH_LONG).show()
                    }
                } catch (t: Throwable) {
                    exportStatusMessage = "خطأ أثناء تصدير Excel: ${t.message}"
                    Toast.makeText(context, "فشل تصدير ملف الإكسل: ${t.message ?: "حدث خطأ غير متوقع"}", Toast.LENGTH_LONG).show()
                } finally {
                    viewModel.isExporting = false
                    pendingExport = null
                }
            }
        } else {
            pendingExport = null
        }
    }

    // مشغل نظام التخزين الآمن (Storage Access Framework) لحفظ مستندات PDF عبر Cache-First
    val createPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri: Uri? ->
        if (uri != null) {
            val pending = pendingExport ?: return@rememberLauncherForActivityResult
            scope.launch {
                viewModel.isExporting = true
                try {
                    val result: Result<Unit> = withContext(Dispatchers.IO) {
                        when (pending) {
                            is PendingReportExport.Project -> {
                                val prj = activeProjects.firstOrNull { it.projectID == pending.projectId }
                                    ?: return@withContext Result.failure(Exception("بيانات المشروع المختار غير متوفرة"))
                                val combined = projectPreviewList.ifEmpty {
                                    repository.getProjectBeneficiariesWithFamilies(pending.projectId)
                                }
                                if (combined.isEmpty()) {
                                    return@withContext Result.failure(Exception("لا توجد سجلات مستفيدين لهذا المشروع حتى الآن"))
                                }
                                val aidTypes = repository.getActiveAidTypes().first().associateBy { it.aidTypeID }

                                val meta = listOf(
                                    "المشروع" to prj.projectName,
                                    "رقم المشروع" to prj.projectNumber,
                                    "الجهة الممولة" to (prj.fundingInstitution ?: "غير محدد"),
                                    "المشرف" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات"),
                                    "نوع المساعدة" to (aidTypes[prj.aidTypeID]?.aidTypeName ?: "مساعدات إغاثية")
                                )
                                exporter.exportDynamicFamiliesPdfToUri(
                                    uri = uri,
                                    title = "كشف مستفيدي المشروع الإنساني المعتمد",
                                    subtitle = "مشروع: ${prj.projectName} (${prj.projectNumber})",
                                    metaRows = meta,
                                    records = combined,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS }
                                )
                            }
                            is PendingReportExport.Comprehensive -> {
                                val combined = comprehensivePreviewList.ifEmpty {
                                    repository.getBeneficiariesWithFamiliesInDateRange(pending.fromDate, pending.toDate)
                                }
                                if (combined.isEmpty()) {
                                    return@withContext Result.failure(Exception("لا توجد سجلات توزيع في الفترة المحددة"))
                                }
                                val meta = listOf(
                                    "النطاق الزمني" to "${pending.fromDate} إلى ${pending.toDate}",
                                    "إجمالي المساعدات" to "${combined.size} طرد",
                                    "المشرف المسؤول" to (repository.getCurrentUser()?.fullName ?: "مدير العمليات")
                                )
                                exporter.exportDynamicFamiliesPdfToUri(
                                    uri = uri,
                                    title = "تقرير التوزيع الشامل والعمليات الميدانية",
                                    subtitle = "تغطية العمليات من تاريخ ${pending.fromDate} إلى ${pending.toDate}",
                                    metaRows = meta,
                                    records = combined,
                                    selectedColumnKeys = pending.selectedColumns.ifEmpty { ExportColumnRegistry.DEFAULT_SELECTED_KEYS }
                                )
                            }
                            is PendingReportExport.Locality -> {
                                Result.failure(Exception("تقرير المحلية متوفر عبر المعاينة والطباعة المباشرة"))
                            }
                        }
                    }

                    result.onSuccess {
                        exportedFile = null
                        exportStatusMessage = "تم حفظ مستند PDF بنجاح وفق الأعمدة المخصصة عبر التخزين الآمن (SAF)."
                        Toast.makeText(context, "تم حفظ مستند PDF بنجاح في الموقع المختار!", Toast.LENGTH_LONG).show()
                    }.onFailure { err ->
                        exportStatusMessage = "خطأ أثناء حفظ مستند PDF: ${err.message}"
                        Toast.makeText(context, "فشل حفظ مستند PDF: ${err.message ?: "حدث خطأ"}", Toast.LENGTH_LONG).show()
                    }
                } catch (t: Throwable) {
                    exportStatusMessage = "خطأ أثناء تصدير PDF: ${t.message}"
                    Toast.makeText(context, "فشل تصدير مستند PDF: ${t.message ?: "حدث خطأ غير متوقع"}", Toast.LENGTH_LONG).show()
                } finally {
                    viewModel.isExporting = false
                    pendingExport = null
                }
            }
        } else {
            pendingExport = null
        }
    }

    // دالة تحميل وتحديث البيانات
    fun loadData() {
        viewModel.refreshData()
    }

    LaunchedEffect(fromDate, toDate) {
        viewModel.refreshData()
    }

    // دوال منتقي التاريخ
    fun openDatePicker(isFrom: Boolean) {
        val calendar = Calendar.getInstance()
        val currentStr = if (isFrom) fromDate else toDate
        val parts = currentStr.split("-")
        val y = parts.getOrNull(0)?.toIntOrNull() ?: calendar.get(Calendar.YEAR)
        val m = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val d = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(context, { _, year, month, dayOfMonth ->
            val formatted = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth)
            if (isFrom) {
                viewModel.setDateRange(formatted, toDate)
            } else {
                viewModel.setDateRange(fromDate, formatted)
            }
        }, y, m, d).show()
    }

    fun applyPreset(preset: String) {
        viewModel.applyPreset(preset)
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "لوحة التقارير والتحليلات البيانية",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                "كشوفات A4 PDF رسمية وتصدير إكسل Excel (.xlsx)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            viewModel.resetFilters()
                            onNavigateBack()
                        }) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = { loadData() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "تحديث البيانات")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                // =========================================================================
                // 1. شريط فلترة الفترة الزمنية (Interactive Date Range Picker)
                // =========================================================================
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Text(
                                        text = "نطاق الفلترة الزمنية للتقارير والإحصائيات",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = "$periodDeliveryCount مساعدة منفذة",
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            // أزرار الفترات السريعة (Presets)
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val presets = listOf("آخر 7 أيام", "آخر 30 يوماً", "آخر 90 يوماً", "كافة الفترات")
                                items(presets) { p ->
                                    FilterChip(
                                        selected = selectedPreset == p,
                                        onClick = { applyPreset(p) },
                                        label = { Text(p, fontSize = 11.sp) }
                                    )
                                }
                            }

                            // مربعي التاريخ التفاعليين
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedCard(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { openDatePicker(true) },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("من تاريخ:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(fromDate, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }

                                OutlinedCard(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { openDatePicker(false) },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("إلى تاريخ:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(toDate, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }

                // =========================================================================
                // 2. إشعار نتيجة التصدير الأخير مع أزرار الإجراءات
                // =========================================================================
                if (exportedFile != null) {
                    item {
                        val file = exportedFile!!
                        val isPdf = exportedFileType == "PDF"
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = if (isPdf) Color(0xFF10B981).copy(alpha = 0.12f) else Color(0xFF0284C7).copy(alpha = 0.12f)),
                            border = BorderStroke(1.5.dp, if (isPdf) Color(0xFF10B981).copy(alpha = 0.5f) else Color(0xFF0284C7).copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (isPdf) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFF0284C7).copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.TableChart,
                                            contentDescription = null,
                                            tint = if (isPdf) Color(0xFF047857) else Color(0xFF0284C7),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isPdf) "تم توليد مستند A4 PDF بنجاح!" else "تم إنشاء ملف Excel (.xlsx) بنجاح!",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = if (isPdf) Color(0xFF047857) else Color(0xFF0369A1)
                                        )
                                        Text(
                                            text = "${file.name} • ${file.length() / 1024} كيلوبايت",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val mime = if (isPdf) "application/pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                            exporter.openFile(file, mime)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("فتح الملف", fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = {
                                            val mime = if (isPdf) "application/pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                            exporter.shareFile(file, mime, file.name)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("مشاركة", fontSize = 11.sp)
                                    }

                                    if (isPdf) {
                                        Button(
                                            onClick = { exporter.printPdfReport(file) },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("طباعة A4", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (exportStatusMessage != null) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = exportStatusMessage ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }

                // =========================================================================
                // 3. لوحة الرسوم البيانية التفاعلية (Visual Analytics Dashboard)
                // =========================================================================
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Analytics, contentDescription = null, tint = Color(0xFF0D9488), modifier = Modifier.size(22.dp))
                                    Text(
                                        text = "المخططات والتحليلات البيانية الحية",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // أزرار التبديل بين المخططات البيانية
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                VisualChartTab.values().forEach { tab ->
                                    FilterChip(
                                        selected = selectedChartTab == tab,
                                        onClick = { selectedChartTab = tab },
                                        label = { Text(tab.label, fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }

                            // عرض المخطط البياني المختار
                            when (selectedChartTab) {
                                VisualChartTab.LOCALITY_DISTRIBUTION -> {
                                    LocalityDistributionDonutChart(localityStats = localityStats)
                                }
                                VisualChartTab.AID_CATEGORIES -> {
                                    AidCategoriesDistributionChart(
                                        aidTypeStats = aidTypeStats,
                                        distinctCategories = distinctAidCategories
                                    )
                                }
                                VisualChartTab.FAMILY_CLASSIFICATIONS -> {
                                    FamilyClassificationsChart(
                                        residentStats = residentStats,
                                        warDamageStats = warDamageStats
                                    )
                                }
                                VisualChartTab.PROJECT_COMPLETION -> {
                                    ProjectCompletionRatesCard(
                                        projects = activeProjects,
                                        projectSummaries = projectSummaries
                                    )
                                }
                            }
                        }
                    }
                }

                // =========================================================================
                // 3.5. بطاقة إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية
                // (Dynamic Geographic Scope & Area Damage Statistics)
                // =========================================================================
                item {
                    DynamicReportsGeoDamageCard(
                        localities = dynamicLocalities,
                        selectedLocality = geoStats.selectedLocality,
                        selectedSubArea = geoStats.selectedSubArea,
                        availableSubAreas = geoStats.availableSubAreas,
                        localityFamilyCount = geoStats.localityFamilyCount,
                        subAreaFamilyCount = geoStats.subAreaFamilyCount,
                        localityCounts = geoStats.localityCounts,
                        completelyDestroyedCount = geoStats.completelyDestroyedCount,
                        warDamageStats = geoStats.warDamageStats,
                        damageDistribution = geoStats.damageDistribution,
                        damageDetailsByRegion = geoStats.damageDetailsByRegion,
                        onLocalitySelected = { locName ->
                            viewModel.selectLocality(locName)
                        },
                        onSubAreaSelected = { sub ->
                            viewModel.selectSubArea(sub)
                        }
                    )
                }

                // =========================================================================
                // 4. مركز توليد وتصدير التقارير المعتمدة (Specific Report Types)
                // =========================================================================
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Text(
                                text = "مركز استخراج التقارير وتصدير المستندات",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            // ألسنة التبويب للتقارير الثلاثة
                            TabRow(
                                selectedTabIndex = selectedReportTab.ordinal,
                                containerColor = Color.Transparent,
                                contentColor = MaterialTheme.colorScheme.primary
                            ) {
                                ReportDashboardTab.values().forEach { tab ->
                                    Tab(
                                        selected = selectedReportTab == tab,
                                        onClick = { selectedReportTab = tab },
                                        text = { Text(tab.label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                                    )
                                }
                            }

                            // محتوى التبويب المختار
                            when (selectedReportTab) {
                                ReportDashboardTab.PROJECT -> {
                                    // أ) تقرير مشروع ومستفيدوه
                                    ProjectReportSection(
                                        projects = activeProjects,
                                        selectedProjectId = selectedProjectId,
                                        onSelectProject = { 
                                            selectedProjectId = it
                                            viewModel.selectProject(it)
                                        },
                                        isExpanded = isProjectPickerExpanded,
                                        onToggleExpand = { isProjectPickerExpanded = !isProjectPickerExpanded },
                                        previewList = projectPreviewList,
                                        isLoadingPreview = isLoadingProjectPreview,
                                        isExporting = isExporting,
                                        onExportPdf = {
                                            val prjId = selectedProjectId ?: return@ProjectReportSection
                                            val prj = activeProjects.firstOrNull { it.projectID == prjId }
                                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                            val safeNumber = prj?.projectNumber?.replace(Regex("[^a-zA-Z0-9_-]"), "_") ?: prjId.toString()
                                            val defaultFileName = "Project_${safeNumber}_$timeStamp.pdf"
                                            columnSelectorFormat = "PDF"
                                            columnSelectorReportTitle = "مشروع ${prj?.projectName ?: prjId.toString()}"
                                            pendingExport = PendingReportExport.Project(prjId, isExcel = false, defaultFileName = defaultFileName)
                                            showColumnSelectorDialog = true
                                        },
                                        onExportExcel = {
                                            val prjId = selectedProjectId ?: return@ProjectReportSection
                                            val prj = activeProjects.firstOrNull { it.projectID == prjId }
                                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                            val safeNumber = prj?.projectNumber?.replace(Regex("[^a-zA-Z0-9_-]"), "_") ?: prjId.toString()
                                            val defaultFileName = "Project_${safeNumber}_$timeStamp.xlsx"
                                            columnSelectorFormat = "EXCEL"
                                            columnSelectorReportTitle = "مشروع ${prj?.projectName ?: prjId.toString()}"
                                            pendingExport = PendingReportExport.Project(prjId, isExcel = true, defaultFileName = defaultFileName)
                                            showColumnSelectorDialog = true
                                        }
                                    )
                                }
                                ReportDashboardTab.LOCALITY -> {
                                    // ب) تقرير محلية وشعبها
                                    LocalityReportSection(
                                        localities = dynamicLocalities,
                                        selectedLocality = geoStats.selectedLocality,
                                        onSelectLocality = { viewModel.selectLocality(it) },
                                        isExpanded = isLocalityPickerExpanded,
                                        onToggleExpand = { isLocalityPickerExpanded = !isLocalityPickerExpanded },
                                        subAreas = subAreaRatios,
                                        isExporting = isExporting,
                                        onExportPdf = {
                                            val locName = geoStats.selectedLocality.ifBlank { dynamicLocalities.firstOrNull() ?: return@LocalityReportSection }
                                            scope.launch {
                                                viewModel.isExporting = true
                                                try {
                                                    val locFamilies = withContext(Dispatchers.IO) {
                                                        repository.getFamiliesByLocalitySync(locName)
                                                    }
                                                    val totalFam = locFamilies.size
                                                    val reportData = LocalityReportData(
                                                        localityName = locName,
                                                        subAreas = subAreaRatios,
                                                        totalFamilies = totalFam,
                                                        totalBeneficiaries = subAreaRatios.sumOf { it.eligibleFamiliesCount },
                                                        totalDelivered = subAreaRatios.sumOf { it.deliveredBeneficiariesCount },
                                                        dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                                        supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                                    )
                                                    val result = exporter.generateLocalitySubAreasPdf(reportData)
                                                    result.onSuccess { file ->
                                                        exportedFile = file
                                                        exportedFileType = "PDF"
                                                        exportStatusMessage = "تم توليد تقرير A4 PDF لتغطية المحلية وشعبها بنجاح."
                                                    }.onFailure { err ->
                                                        exportStatusMessage = "خطأ أثناء توليد PDF: ${err.message}"
                                                        Toast.makeText(context, "فشل تصدير التقرير: ${err.message ?: "الذاكرة غير كافية"}", Toast.LENGTH_LONG).show()
                                                    }
                                                } catch (e: Exception) {
                                                    exportStatusMessage = "خطأ أثناء توليد PDF: ${e.message}"
                                                    Toast.makeText(context, "فشل تصدير التقرير: ${e.message}", Toast.LENGTH_LONG).show()
                                                } finally {
                                                    viewModel.isExporting = false
                                                }
                                            }
                                        },
                                        onExportExcel = {
                                            val locName = geoStats.selectedLocality.ifBlank { dynamicLocalities.firstOrNull() ?: return@LocalityReportSection }
                                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                            val safeLoc = locName.trim().replace(Regex("[^a-zA-Z0-9_\u0600-\u06FF-]"), "_")
                                            val defaultFileName = "Locality_${safeLoc}_$timeStamp.xlsx"
                                            pendingExport = PendingReportExport.Locality(locName, defaultFileName)
                                            createExcelLauncher.launch(defaultFileName)
                                        }
                                    )
                                }
                                ReportDashboardTab.COMPREHENSIVE_PERIOD -> {
                                    // ج) تقرير التوزيع الشامل حسب الفترة
                                    ComprehensiveReportSection(
                                        fromDate = fromDate,
                                        toDate = toDate,
                                        periodDeliveryCount = periodDeliveryCount,
                                        localityStats = localityStats,
                                        aidTypeStats = aidTypeStats,
                                        distinctCategories = distinctAidCategories,
                                        previewList = comprehensivePreviewList,
                                        isLoadingPreview = isLoadingComprehensivePreview,
                                        isExporting = isExporting,
                                        onExportPdf = {
                                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                            val defaultFileName = "Comprehensive_${fromDate}_to_${toDate}_$timeStamp.pdf"
                                            columnSelectorFormat = "PDF"
                                            columnSelectorReportTitle = "التوزيع الشامل ($fromDate إلى $toDate)"
                                            pendingExport = PendingReportExport.Comprehensive(fromDate, toDate, isExcel = false, defaultFileName = defaultFileName)
                                            showColumnSelectorDialog = true
                                        },
                                        onExportExcel = {
                                            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                            val defaultFileName = "Comprehensive_${fromDate}_to_${toDate}_$timeStamp.xlsx"
                                            columnSelectorFormat = "EXCEL"
                                            columnSelectorReportTitle = "التوزيع الشامل ($fromDate إلى $toDate)"
                                            pendingExport = PendingReportExport.Comprehensive(fromDate, toDate, isExcel = true, defaultFileName = defaultFileName)
                                            showColumnSelectorDialog = true
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // نافذة اختيار وتخصيص أعمدة التصدير (Dynamic Column Chooser Dialog)
    if (showColumnSelectorDialog) {
        val currentPending = pendingExport
        ExportColumnSelectorDialog(
            exportFormat = columnSelectorFormat,
            reportTitle = columnSelectorReportTitle,
            initialSelectedKeys = ExportColumnRegistry.DEFAULT_SELECTED_KEYS,
            onConfirm = { chosenKeys ->
                showColumnSelectorDialog = false
                when (currentPending) {
                    is PendingReportExport.Project -> {
                        pendingExport = currentPending.copy(selectedColumns = chosenKeys)
                        if (currentPending.isExcel) {
                            createExcelLauncher.launch(currentPending.defaultFileName)
                        } else {
                            createPdfLauncher.launch(currentPending.defaultFileName)
                        }
                    }
                    is PendingReportExport.Comprehensive -> {
                        pendingExport = currentPending.copy(selectedColumns = chosenKeys)
                        if (currentPending.isExcel) {
                            createExcelLauncher.launch(currentPending.defaultFileName)
                        } else {
                            createPdfLauncher.launch(currentPending.defaultFileName)
                        }
                    }
                    else -> {}
                }
            },
            onDismiss = {
                showColumnSelectorDialog = false
                pendingExport = null
            }
        )
    }
}

// =========================================================================
// المكونات الفرعية للشاشة
// =========================================================================

@Composable
private fun LocalityDistributionDonutChart(localityStats: List<LocalityDistributionStat>) {
    val activeStats = remember(localityStats) {
        localityStats.filter { it.deliveredAidCount > 0 || it.familiesCount > 0 }
    }

    if (activeStats.isEmpty()) {
        Box(modifier = Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد بيانات توزيع للمحليات", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        return
    }

    val palette = listOf(
        Color(0xFF0D9488), Color(0xFF0284C7), Color(0xFF10B981),
        Color(0xFFF59E0B), Color(0xFF8B5CF6), Color(0xFFEC4899),
        Color(0xFF06B6D4), Color(0xFFF97316)
    )

    val totalAid = activeStats.sumOf { it.deliveredAidCount }

    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // مخطط Canvas دائري Donut
        Box(modifier = Modifier.size(150.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(130.dp)) {
                var currentAngle = -90f
                val strokeWidthPx = 28f

                activeStats.forEachIndexed { i, stat ->
                    val sweepAngle = if (totalAid > 0) (stat.deliveredAidCount.toFloat() / totalAid.toFloat()) * 360f else (360f / activeStats.size)
                    val color = palette[i % palette.size]

                    drawArc(
                        color = color,
                        startAngle = currentAngle,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        style = Stroke(width = strokeWidthPx, cap = StrokeCap.Round)
                    )
                    currentAngle += sweepAngle
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$totalAid", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                Text("طرد موزع", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Spacer(modifier = Modifier.width(16.dp))

        // جدول النسب والمفتاح الدليلي لكافة المحليات المسجلة بدقة
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            activeStats.forEachIndexed { i, stat ->
                val color = palette[i % palette.size]
                val percent = if (totalAid > 0) (stat.deliveredAidCount * 100 / totalAid) else 0
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
                        Text(stat.localityName, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                    Text("$percent% (${stat.deliveredAidCount})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
                }
            }
        }
    }
}

@Composable
private fun AidCategoriesDistributionChart(
    aidTypeStats: List<AidTypeDistributionStat>,
    distinctCategories: List<String>
) {
    val activeAidStats = remember(aidTypeStats) {
        aidTypeStats.filter { it.deliveredCount > 0 }
    }
    val totalDelivered = activeAidStats.sumOf { it.deliveredCount }.coerceAtLeast(1)

    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("توزيع المساعدات المسلمة حسب التصنيفات المعتمدة ديناميكياً:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        if (activeAidStats.isNotEmpty()) {
            activeAidStats.forEach { stat ->
                val percent = (stat.deliveredCount.toDouble() / totalDelivered.toDouble()) * 100.0
                val color = Color(stat.colorHex)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stat.aidTypeName, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "${stat.deliveredCount} مساعدة (${String.format(Locale.US, "%.1f%%", percent)})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = color
                        )
                    }
                    LinearProgressIndicator(
                        progress = { (percent / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = color,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        } else if (distinctCategories.isNotEmpty()) {
            distinctCategories.forEach { cat ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    ) {
                        Text("تصنيف معتمد", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }
        } else {
            Text("لا توجد بيانات لتصنيفات المساعدات في هذه الفترة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun FamilyClassificationsChart(
    residentStats: List<KeyCountRecord>,
    warDamageStats: List<KeyCountRecord>
) {
    val activeResident = remember(residentStats) { residentStats.filter { it.count > 0 } }
    val activeDamage = remember(warDamageStats) { warDamageStats.filter { it.count > 0 } }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("1. صفة الإقامة (مقيم / نازح):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        val totalResident = activeResident.sumOf { it.count }.coerceAtLeast(1)
        if (activeResident.isNotEmpty()) {
            activeResident.forEach { stat ->
                val pct = (stat.count * 100) / totalResident
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(stat.keyName, fontSize = 11.sp)
                        Text("$pct% (${stat.count} أسرة)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = { pct / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF0D9488),
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        } else {
            Text("لا توجد بيانات لحالة الإقامة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text("2. تصنيف أضرار الحرب:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        val totalDamage = activeDamage.sumOf { it.count }.coerceAtLeast(1)
        if (activeDamage.isNotEmpty()) {
            activeDamage.forEach { stat ->
                val pct = (stat.count * 100) / totalDamage
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(stat.keyName, fontSize = 11.sp)
                        Text("$pct% (${stat.count})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = { pct / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFFEF4444),
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        } else {
            Text("لا توجد بيانات لأضرار الحرب", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ProjectCompletionRatesCard(
    projects: List<ProjectEntity>,
    projectSummaries: List<ProjectAggregatedSummary> = emptyList()
) {
    if (projects.isEmpty()) {
        Text("لا توجد مشاريع نشطة حالياً", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }

    val summaryMap = remember(projectSummaries) { projectSummaries.associateBy { it.projectNumber } }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        projects.forEach { prj ->
            val summary = summaryMap[prj.projectNumber]
            val totalCandidates = summary?.totalCandidates ?: 0
            val totalDelivered = summary?.totalReceived ?: 0
            val completionRate = if (totalCandidates > 0) {
                ((totalDelivered.toFloat() / totalCandidates.toFloat()) * 100f).coerceIn(0f, 100f)
            } else 0f
            val progressFraction = (completionRate / 100f).coerceIn(0f, 1f)

            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(prj.projectNumber, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Text("الممول: ${prj.fundingInstitution} • النطاق: ${prj.projectDate}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "المستفيدون الفعليون: $totalDelivered من $totalCandidates مرشح",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${completionRate.toInt()}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (completionRate >= 100f) Color(0xFF10B981) else Color(0xFF0284C7)
                        )
                    }

                    LinearProgressIndicator(
                        progress = { progressFraction },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = if (completionRate >= 100f) Color(0xFF10B981) else Color(0xFF0284C7),
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun BeneficiaryPreviewTable(
    title: String,
    items: List<AidRecordWithBeneficiary>,
    isLoading: Boolean,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                if (items.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = "${items.size} سجل",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            if (isLoading) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("جارِ تحميل ومعاينة البيانات...", fontSize = 11.sp)
                }
            } else if (items.isEmpty()) {
                Text(
                    text = "لا توجد سجلات مطابقة للعرض أو التصدير حالياً.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(vertical = 6.dp)
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 200.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("الاسم", modifier = Modifier.weight(2.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("الهوية", modifier = Modifier.weight(2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("المشروع", modifier = Modifier.weight(2f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("الحالة", modifier = Modifier.weight(1.5f), fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    items.forEachIndexed { idx, item ->
                        val name = item.family?.name?.ifBlank { null }
                            ?: item.record.notes?.ifBlank { null }
                            ?: "غير محدد"
                        val idNum = item.family?.nationalID?.ifBlank { null }
                            ?: item.record.familyID.toString()
                        val prjNum = item.record.projectID.toString()
                        val status = item.record.recipientStatus.ifBlank { "مرشح" }
                        val isDelivered = status == "مستفيد"

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (idx % 2 == 0) Color.Transparent else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = name,
                                modifier = Modifier.weight(2.5f),
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = idNum,
                                modifier = Modifier.weight(2f),
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = prjNum,
                                modifier = Modifier.weight(2f),
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isDelivered) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFFF59E0B).copy(alpha = 0.15f),
                                modifier = Modifier.weight(1.5f)
                            ) {
                                Text(
                                    text = status,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isDelivered) Color(0xFF047857) else Color(0xFFB45309),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProjectReportSection(
    projects: List<ProjectEntity>,
    selectedProjectId: Long?,
    onSelectProject: (Long) -> Unit,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    previewList: List<AidRecordWithBeneficiary>,
    isLoadingPreview: Boolean,
    isExporting: Boolean,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit
) {
    val currentProject = projects.firstOrNull { it.projectID == selectedProjectId }
    val canExport = !isExporting && selectedProjectId != null && previewList.isNotEmpty() && !isLoadingPreview

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "اختر المشروع لتوليد كشف المستفيدين الرسمي:",
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )

        // Dropdown Selector
        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedCard(
                modifier = Modifier.fillMaxWidth().clickable { onToggleExpand() },
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = currentProject?.projectName ?: "اختر المشروع...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        if (currentProject != null) {
                            Text(
                                text = "${currentProject.projectNumber} • ${currentProject.fundingInstitution}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                }
            }

            DropdownMenu(
                expanded = isExpanded,
                onDismissRequest = onToggleExpand,
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                if (projects.isEmpty()) {
                    DropdownMenuItem(
                        text = { Text("لا توجد بيانات مشاريع مسجلة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        onClick = onToggleExpand,
                        enabled = false
                    )
                } else {
                    projects.forEach { prj ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("${prj.projectNumber} - ${prj.fundingInstitution}", fontSize = 10.sp)
                                }
                            },
                            onClick = {
                                onSelectProject(prj.projectID)
                                onToggleExpand()
                            }
                        )
                    }
                }
            }
        }

        // جدول المعاينة المسبقة قبل التصدير
        if (selectedProjectId != null) {
            BeneficiaryPreviewTable(
                title = "معاينة كشف المستفيدين قبل التصدير",
                items = previewList,
                isLoading = isLoadingPreview
            )
        }

        // أزرار التصدير
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onExportPdf,
                enabled = canExport,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (isExporting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("جارِ المعالجة...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصدير كشف A4 PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Button(
                onClick = onExportExcel,
                enabled = canExport,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (isExporting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("جارِ التصدير...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصدير إكسل Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (selectedProjectId != null && previewList.isEmpty() && !isLoadingPreview) {
            Text(
                text = "⚠️ يتعذر التصدير لعدم وجود مستفيدين مسجلين في هذا المشروع.",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
private fun LocalityReportSection(
    localities: List<String>,
    selectedLocality: String,
    onSelectLocality: (String) -> Unit,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    subAreas: List<SubAreaBenefitRatioStat>,
    isExporting: Boolean,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit
) {
    val currentLoc = selectedLocality.ifBlank { localities.firstOrNull() ?: "" }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("اختر المحلية لاستخراج تقرير الشعب والنسب الدقيقة:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)

        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedCard(
                modifier = Modifier.fillMaxWidth().clickable { onToggleExpand() },
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = currentLoc.ifBlank { "اختر المحلية..." },
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                }
            }

            DropdownMenu(
                expanded = isExpanded,
                onDismissRequest = onToggleExpand,
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                if (localities.isEmpty()) {
                    DropdownMenuItem(
                        text = { Text("لا توجد بيانات محليات مسجلة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        onClick = onToggleExpand,
                        enabled = false
                    )
                } else {
                    localities.forEach { locName ->
                        DropdownMenuItem(
                            text = { Text(locName, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            onClick = {
                                onSelectLocality(locName)
                                onToggleExpand()
                            }
                        )
                    }
                }
            }
        }

        // إحصائية سريعة
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("الشعب المشمولة: ${subAreas.size} شعبة", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                Text("المستحقين: ${subAreas.sumOf { it.eligibleFamiliesCount }}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        }

        // أزرار التصدير
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onExportPdf,
                enabled = !isExporting && currentLoc.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (isExporting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("جارِ المعالجة...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصدير تقرير A4 PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Button(
                onClick = onExportExcel,
                enabled = !isExporting && currentLoc.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (isExporting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("جارِ التصدير...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصدير إكسل Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ComprehensiveReportSection(
    fromDate: String,
    toDate: String,
    periodDeliveryCount: Int,
    localityStats: List<LocalityDistributionStat>,
    aidTypeStats: List<AidTypeDistributionStat>,
    distinctCategories: List<String> = emptyList(),
    previewList: List<AidRecordWithBeneficiary>,
    isLoadingPreview: Boolean,
    isExporting: Boolean,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit
) {
    var selectedCatFilter by remember { mutableStateOf("كافة التصنيفات") }
    val categoryTabs = remember(distinctCategories, aidTypeStats) {
        listOf("كافة التصنيفات") + (if (distinctCategories.isNotEmpty()) distinctCategories else aidTypeStats.map { it.aidTypeName }.distinct())
    }
    val canExport = !isExporting && previewList.isNotEmpty() && !isLoadingPreview

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تقرير العمليات الميدانية الشامل:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Text("الفترة المحددة: من $fromDate إلى $toDate", fontSize = 11.sp)
                Text("إجمالي المساعدات المنفذة في هذه الفترة: $periodDeliveryCount طرد موزع", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("يغطي ${localityStats.size} محلية و ${aidTypeStats.size} صنف إغاثي مع جداول المستلمين ومربعات التوقيع.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // تبويبات فلترة تصنيفات المساعدات الديناميكية
        if (categoryTabs.size > 2) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تصنيف المساعدة المشمول:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categoryTabs.forEach { cat ->
                        val isSel = selectedCatFilter == cat
                        Surface(
                            onClick = { selectedCatFilter = cat },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            contentColor = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface
                        ) {
                            Text(
                                text = cat,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // جدول المعاينة المسبقة لكشف التوزيع الشامل
        BeneficiaryPreviewTable(
            title = "معاينة كشف التوزيع الشامل قبل التصدير",
            items = previewList,
            isLoading = isLoadingPreview
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onExportPdf,
                enabled = canExport,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (isExporting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("جارِ المعالجة...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصدير شامل A4 PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Button(
                onClick = onExportExcel,
                enabled = canExport,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (isExporting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("جارِ التصدير...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصدير إكسل Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (previewList.isEmpty() && !isLoadingPreview) {
            Text(
                text = "⚠️ لا توجد سجلات توزيع في الفترة المحددة، التصدير غير متاح.",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

/**
 * بطاقة إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية المفصلة والديناميكية
 * تتيح اختيار محلية وشعبة معينة لعرض التوزيع التجميعي المحدث لحظياً للأسر والمنازل المهدمة وأضرار الحرب
 */
@Composable
fun DynamicReportsGeoDamageCard(
    localities: List<String>,
    selectedLocality: String,
    selectedSubArea: String,
    availableSubAreas: List<String>,
    localityFamilyCount: Int,
    subAreaFamilyCount: Int,
    localityCounts: Map<String, Int>,
    completelyDestroyedCount: Int,
    warDamageStats: WarDamageStats?,
    damageDistribution: List<DamageTypeBreakdown>,
    damageDetailsByRegion: Map<String, Map<String, Int>> = emptyMap(),
    onLocalitySelected: (String) -> Unit,
    onSubAreaSelected: (String) -> Unit
) {
    var localityExpanded by remember { mutableStateOf(false) }
    var subAreaExpanded by remember { mutableStateOf(false) }

    val selectedLocalityName = selectedLocality.ifBlank { "اختر المحلية" }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, Color(0xFF0284C7).copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ترويسة البطاقة بدون أي عناصر تسبب انضغاط النص أفقياً
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationCity,
                    contentDescription = null,
                    tint = Color(0xFF0284C7),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = "اختر المحلية والشعبة لعرض التوزيع التجميعي المحدث لحظياً للأسر وأضرار الحرب:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // صفي القوائم المنسدلة لاختيار المحلية والشعبة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // منسدل المحلية
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { localityExpanded = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Icon(Icons.Default.LocationCity, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(16.dp))
                                Text(
                                    text = selectedLocalityName,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF16A34A))
                        }
                    }

                    DropdownMenu(
                        expanded = localityExpanded,
                        onDismissRequest = { localityExpanded = false }
                    ) {
                        localities.forEach { locName ->
                            val count = localityCounts[locName] ?: 0
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            locName,
                                            fontWeight = if (locName == selectedLocality) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("($count أسرة)", fontSize = 11.sp, color = Color(0xFF16A34A))
                                    }
                                },
                                onClick = {
                                    onLocalitySelected(locName)
                                    localityExpanded = false
                                }
                            )
                        }
                    }
                }

                // منسدل الشعبة / المنطقة الفرعية
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { subAreaExpanded = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Icon(Icons.Default.AltRoute, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(16.dp))
                                Text(
                                    text = selectedSubArea.ifBlank { "كافة الشعب" },
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF0284C7))
                        }
                    }

                    DropdownMenu(
                        expanded = subAreaExpanded,
                        onDismissRequest = { subAreaExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    "كافة الشعب",
                                    fontWeight = if (selectedSubArea.isBlank()) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            onClick = {
                                onSubAreaSelected("")
                                subAreaExpanded = false
                            }
                        )

                        availableSubAreas.forEach { sub ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        sub,
                                        fontWeight = if (sub == selectedSubArea) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onSubAreaSelected(sub)
                                    subAreaExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // شبكة المؤشرات الإحصائية الأربعة الرئيسية
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReportGeoStatBadge(
                    title = "أسر المحلية",
                    value = "$localityFamilyCount",
                    subtitle = selectedLocalityName,
                    color = Color(0xFF16A34A),
                    icon = Icons.Default.Groups,
                    modifier = Modifier.weight(1f)
                )

                ReportGeoStatBadge(
                    title = "أسر الشعبة",
                    value = if (selectedSubArea.isNotBlank()) "$subAreaFamilyCount" else "الكل",
                    subtitle = selectedSubArea.ifBlank { "غير مقيد بشعبة" },
                    color = Color(0xFF0284C7),
                    icon = Icons.Default.LocationOn,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReportGeoStatBadge(
                    title = "منازل مهدمة كلياً",
                    value = "$completelyDestroyedCount",
                    subtitle = "أضرار كلية بالنطاق",
                    color = Color(0xFFDC2626),
                    icon = Icons.Default.HomeWork,
                    modifier = Modifier.weight(1f)
                )

                val totalAssessed = warDamageStats?.totalAssessed ?: 0
                ReportGeoStatBadge(
                    title = "إجمالي أضرار الحرب",
                    value = "$totalAssessed",
                    subtitle = "منازل مسجلة بالنطاق",
                    color = Color(0xFFD97706),
                    icon = Icons.Default.Warning,
                    modifier = Modifier.weight(1f)
                )
            }

            // تفصيل الحالات الهندسية والإنشائية
            warDamageStats?.let { ws ->
                if (ws.totalAssessed > 0) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "تفصيل الحالات الهندسية والإنشائية المسجلة:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MiniDamagePill(
                                    label = "جزئي بليغ",
                                    count = ws.severePartialDamageCount,
                                    color = Color(0xFFEA580C),
                                    modifier = Modifier.weight(1f)
                                )
                                MiniDamagePill(
                                    label = "جزئي طفيف",
                                    count = ws.minorPartialDamageCount,
                                    color = Color(0xFFCA8A04),
                                    modifier = Modifier.weight(1f)
                                )
                                MiniDamagePill(
                                    label = "سليم / لا ضرر",
                                    count = ws.noDamageCount,
                                    color = Color(0xFF16A34A),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // توزيع درجات الأضرار المسجلة ميدانياً مع أشرطة بيانية تفاعلية
            if (damageDistribution.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "توزيع درجات الأضرار المسجلة ميدانياً بالنطاق:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        val total = damageDistribution.sumOf { it.count }.coerceAtLeast(1)
                        damageDistribution.forEach { item ->
                            val percent = (item.count.toDouble() / total.toDouble()) * 100
                            Column(modifier = Modifier.padding(vertical = 3.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.damageType,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${item.count} منزل (${String.format(Locale.US, "%.1f%%", percent)})",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF16A34A)
                                    )
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                LinearProgressIndicator(
                                    progress = (item.count.toFloat() / total.toFloat()).coerceIn(0f, 1f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = Color(0xFF16A34A),
                                    trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                )
                                val regionMap = damageDetailsByRegion[item.damageType]
                                if (!regionMap.isNullOrEmpty()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    val topRegions = regionMap.entries.sortedByDescending { it.value }.take(3)
                                    Text(
                                        text = topRegions.joinToString(" • ") { "${it.key}: ${it.value}" },
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportGeoStatBadge(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
                Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = color)
            }
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MiniDamagePill(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "$count", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

