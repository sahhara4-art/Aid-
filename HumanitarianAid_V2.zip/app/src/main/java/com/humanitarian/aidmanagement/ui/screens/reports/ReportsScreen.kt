package com.humanitarian.aidmanagement.ui.screens.reports

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.dao.DamageTypeBreakdown
import com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord
import com.humanitarian.aidmanagement.data.local.dao.LocalityFamilyCount
import com.humanitarian.aidmanagement.data.local.dao.SubAreaFamilyCount
import com.humanitarian.aidmanagement.data.local.dao.WarDamageStats
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.*
import com.humanitarian.aidmanagement.util.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

enum class ReportDashboardTab(val label: String) {
    PROJECT("المشاريع والمستفيدين"),
    LOCALITY("المحليات والشعب"),
    COMPREHENSIVE_PERIOD("التوزيع الشامل حسب الفترة")
}

enum class VisualChartTab(val label: String) {
    LOCALITY_DISTRIBUTION("توزيع المحليات"),
    AID_CATEGORIES("تصنيفات المساعدات"),
    FAMILY_CLASSIFICATIONS("تصنيفات الأسر"),
    PROJECT_COMPLETION("معدلات إنجاز المشاريع")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(
    repository: AidRepository,
    viewModel: ReportsViewModel = viewModel(factory = ReportsViewModel.Factory(repository)),
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val exporter = remember { ProfessionalReportExporter(context) }
    val scope = rememberCoroutineScope()

    val geoStats by viewModel.geoDamageStats.collectAsState()
    val dynamicLocalities by viewModel.localities.collectAsState()

    // نطاق التاريخ
    val defaultCalendar = Calendar.getInstance()
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(defaultCalendar.time)
    val past30DaysCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -30) }
    val past30DaysStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(past30DaysCal.time)

    var fromDate by remember { mutableStateOf(past30DaysStr) }
    var toDate by remember { mutableStateOf(todayStr) }
    var selectedPreset by remember { mutableStateOf("آخر 30 يوماً") }

    // حالات التبويب
    var selectedReportTab by remember { mutableStateOf(ReportDashboardTab.PROJECT) }
    var selectedChartTab by remember { mutableStateOf(VisualChartTab.LOCALITY_DISTRIBUTION) }

    // بيانات من قاعدة البيانات
    var stats by remember { mutableStateOf<DashboardStats?>(null) }
    var localityStats by remember { mutableStateOf<List<LocalityDistributionStat>>(emptyList()) }
    var aidTypeStats by remember { mutableStateOf<List<AidTypeDistributionStat>>(emptyList()) }
    var distinctAidCategories by remember { mutableStateOf<List<String>>(emptyList()) }
    var subAreaRatios by remember { mutableStateOf<List<SubAreaBenefitRatioStat>>(emptyList()) }
    var residentStats by remember { mutableStateOf<List<KeyCountRecord>>(emptyList()) }
    var warDamageStats by remember { mutableStateOf<List<KeyCountRecord>>(emptyList()) }
    var activeProjects by remember { mutableStateOf<List<ProjectEntity>>(emptyList()) }
    var localitiesList by remember { mutableStateOf<List<LocalityEntity>>(emptyList()) }
    var periodDeliveryCount by remember { mutableStateOf(0) }

    // اختيارات التقارير المحددة
    var selectedProjectId by remember { mutableStateOf<Long?>(null) }
    var selectedLocalityId by remember { mutableStateOf<Int?>(null) }
    var isProjectPickerExpanded by remember { mutableStateOf(false) }
    var isLocalityPickerExpanded by remember { mutableStateOf(false) }

    // حالة التصدير
    var isExporting by remember { mutableStateOf(false) }
    var exportedFile by remember { mutableStateOf<File?>(null) }
    var exportedFileType by remember { mutableStateOf<String?>(null) } // "PDF" or "EXCEL"
    var exportStatusMessage by remember { mutableStateOf<String?>(null) }

    // دالة تحميل وتحديث البيانات
    fun loadData() {
        scope.launch {
            withContext(Dispatchers.IO) {
                stats = repository.getDashboardStats()
                localityStats = repository.getLocalityDistributionStats()
                aidTypeStats = repository.getAidTypeDistributionStats(fromDate, toDate)
                distinctAidCategories = repository.getDistinctAidCategoriesSync()
                subAreaRatios = repository.calculateSubAreaBenefitRatios()
                residentStats = repository.getResidentStatusDistributionStats()
                warDamageStats = repository.getWarDamageDistributionStats()
                activeProjects = repository.getActiveProjects().first()
                localitiesList = repository.getAllowedLocalitiesSync()
                periodDeliveryCount = repository.getDeliveredCountInDateRange(fromDate, toDate)

                if (selectedProjectId == null && activeProjects.isNotEmpty()) {
                    selectedProjectId = activeProjects.first().projectID
                }
                if (selectedLocalityId == null && localitiesList.isNotEmpty()) {
                    selectedLocalityId = localitiesList.first().LocalityID
                }
            }
        }
    }

    LaunchedEffect(fromDate, toDate) {
        loadData()
    }

    // دوال منتقي التاريخ
    fun openDatePicker(isFrom: Boolean) {
        val calendar = Calendar.getInstance()
        val currentStr = if (isFrom) fromDate else toDate
        val parts = currentStr.split("-")
        val y = parts.getOrNull(0)?.toIntOrNull() ?: calendar.get(Calendar.YEAR)
        val m = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val d = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(context, { _, year, month, dayOfMonth ->
            val formatted = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth)
            if (isFrom) {
                fromDate = formatted
            } else {
                toDate = formatted
            }
            selectedPreset = "مخصص"
        }, y, m, d).show()
    }

    fun applyPreset(preset: String) {
        val cal = Calendar.getInstance()
        val end = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        val start = when (preset) {
            "آخر 7 أيام" -> {
                cal.add(Calendar.DAY_OF_YEAR, -7)
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            }
            "آخر 30 يوماً" -> {
                cal.add(Calendar.DAY_OF_YEAR, -30)
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            }
            "آخر 90 يوماً" -> {
                cal.add(Calendar.DAY_OF_YEAR, -90)
                SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
            }
            "كافة الفترات" -> "2024-01-01"
            else -> past30DaysStr
        }
        fromDate = start
        toDate = end
        selectedPreset = preset
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "لوحة التقارير والتحليلات البيانية",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                "كشوفات A4 PDF رسمية وتصدير إكسل Excel (.xlsx)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = { loadData() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "تحديث البيانات")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                // =========================================================================
                // 1. شريط فلترة الفترة الزمنية (Interactive Date Range Picker)
                // =========================================================================
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Text(
                                        text = "نطاق الفلترة الزمنية للتقارير والإحصائيات",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = "$periodDeliveryCount مساعدة منفذة",
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            // أزرار الفترات السريعة (Presets)
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                val presets = listOf("آخر 7 أيام", "آخر 30 يوماً", "آخر 90 يوماً", "كافة الفترات")
                                items(presets) { p ->
                                    FilterChip(
                                        selected = selectedPreset == p,
                                        onClick = { applyPreset(p) },
                                        label = { Text(p, fontSize = 11.sp) }
                                    )
                                }
                            }

                            // مربعي التاريخ التفاعليين
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedCard(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { openDatePicker(true) },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("من تاريخ:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(fromDate, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }

                                OutlinedCard(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { openDatePicker(false) },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text("إلى تاريخ:", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(toDate, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }

                // =========================================================================
                // 2. إشعار نتيجة التصدير الأخير مع أزرار الإجراءات
                // =========================================================================
                if (exportedFile != null) {
                    item {
                        val file = exportedFile!!
                        val isPdf = exportedFileType == "PDF"
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = if (isPdf) Color(0xFF10B981).copy(alpha = 0.12f) else Color(0xFF0284C7).copy(alpha = 0.12f)),
                            border = BorderStroke(1.5.dp, if (isPdf) Color(0xFF10B981).copy(alpha = 0.5f) else Color(0xFF0284C7).copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (isPdf) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFF0284C7).copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.TableChart,
                                            contentDescription = null,
                                            tint = if (isPdf) Color(0xFF047857) else Color(0xFF0284C7),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isPdf) "تم توليد مستند A4 PDF بنجاح!" else "تم إنشاء ملف Excel (.xlsx) بنجاح!",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = if (isPdf) Color(0xFF047857) else Color(0xFF0369A1)
                                        )
                                        Text(
                                            text = "${file.name} • ${file.length() / 1024} كيلوبايت",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val mime = if (isPdf) "application/pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                            exporter.openFile(file, mime)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("فتح الملف", fontSize = 11.sp)
                                    }

                                    Button(
                                        onClick = {
                                            val mime = if (isPdf) "application/pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                            exporter.shareFile(file, mime, file.name)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("مشاركة", fontSize = 11.sp)
                                    }

                                    if (isPdf) {
                                        Button(
                                            onClick = { exporter.printPdfReport(file) },
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("طباعة A4", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else if (exportStatusMessage != null) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = exportStatusMessage ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }
                }

                // =========================================================================
                // 3. لوحة الرسوم البيانية التفاعلية (Visual Analytics Dashboard)
                // =========================================================================
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Analytics, contentDescription = null, tint = Color(0xFF0D9488), modifier = Modifier.size(22.dp))
                                    Text(
                                        text = "المخططات والتحليلات البيانية الحية",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // أزرار التبديل بين المخططات البيانية
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                VisualChartTab.values().forEach { tab ->
                                    FilterChip(
                                        selected = selectedChartTab == tab,
                                        onClick = { selectedChartTab = tab },
                                        label = { Text(tab.label, fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }

                            // عرض المخطط البياني المختار
                            when (selectedChartTab) {
                                VisualChartTab.LOCALITY_DISTRIBUTION -> {
                                    LocalityDistributionDonutChart(localityStats = localityStats)
                                }
                                VisualChartTab.AID_CATEGORIES -> {
                                    AidCategoriesDistributionChart(
                                        aidTypeStats = aidTypeStats,
                                        distinctCategories = distinctAidCategories
                                    )
                                }
                                VisualChartTab.FAMILY_CLASSIFICATIONS -> {
                                    FamilyClassificationsChart(
                                        residentStats = residentStats,
                                        warDamageStats = warDamageStats
                                    )
                                }
                                VisualChartTab.PROJECT_COMPLETION -> {
                                    ProjectCompletionRatesCard(projects = activeProjects)
                                }
                            }
                        }
                    }
                }

                // =========================================================================
                // 3.5. بطاقة إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية
                // (Dynamic Geographic Scope & Area Damage Statistics)
                // =========================================================================
                item {
                    DynamicReportsGeoDamageCard(
                        localities = dynamicLocalities,
                        selectedLocality = geoStats.selectedLocality,
                        selectedSubArea = geoStats.selectedSubArea,
                        availableSubAreas = geoStats.availableSubAreas,
                        localityFamilyCount = geoStats.localityFamilyCount,
                        subAreaFamilyCount = geoStats.subAreaFamilyCount,
                        localityCounts = geoStats.localityCounts,
                        completelyDestroyedCount = geoStats.completelyDestroyedCount,
                        warDamageStats = geoStats.warDamageStats,
                        damageDistribution = geoStats.damageDistribution,
                        onLocalitySelected = { locName ->
                            viewModel.selectLocality(locName)
                        },
                        onSubAreaSelected = { sub ->
                            viewModel.selectSubArea(sub)
                        }
                    )
                }

                // =========================================================================
                // 4. مركز توليد وتصدير التقارير المعتمدة (Specific Report Types)
                // =========================================================================
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            Text(
                                text = "مركز استخراج التقارير وتصدير المستندات",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            // ألسنة التبويب للتقارير الثلاثة
                            TabRow(
                                selectedTabIndex = selectedReportTab.ordinal,
                                containerColor = Color.Transparent,
                                contentColor = MaterialTheme.colorScheme.primary
                            ) {
                                ReportDashboardTab.values().forEach { tab ->
                                    Tab(
                                        selected = selectedReportTab == tab,
                                        onClick = { selectedReportTab = tab },
                                        text = { Text(tab.label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
                                    )
                                }
                            }

                            // محتوى التبويب المختار
                            when (selectedReportTab) {
                                ReportDashboardTab.PROJECT -> {
                                    // أ) تقرير مشروع ومستفيدوه
                                    ProjectReportSection(
                                        projects = activeProjects,
                                        selectedProjectId = selectedProjectId,
                                        onSelectProject = { selectedProjectId = it },
                                        isExpanded = isProjectPickerExpanded,
                                        onToggleExpand = { isProjectPickerExpanded = !isProjectPickerExpanded },
                                        isExporting = isExporting,
                                        onExportPdf = {
                                            val prjId = selectedProjectId ?: return@ProjectReportSection
                                            scope.launch {
                                                isExporting = true
                                                try {
                                                    val prj = activeProjects.firstOrNull { it.projectID == prjId } ?: return@launch
                                                    val records = repository.getAidRecordsForProjectSync(prjId)
                                                    val families = repository.getFamilies().first().associateBy { it.familyID }
                                                    val aidTypes = repository.getActiveAidTypes().first().associateBy { it.aidTypeID }

                                                    val combined = records.map {
                                                        AidRecordWithBeneficiary(record = it, family = families[it.familyID])
                                                    }
                                                    val reportData = ProjectReportData(
                                                        project = prj,
                                                        aidTypeName = aidTypes[prj.aidTypeID]?.aidTypeName ?: "مساعدات إغاثية",
                                                        records = combined,
                                                        dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                                        supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                                    )
                                                    val result = exporter.generateProjectBeneficiariesPdf(reportData)
                                                    result.onSuccess { file ->
                                                        exportedFile = file
                                                        exportedFileType = "PDF"
                                                        exportStatusMessage = "تم توليد مستند PDF لمستفيدي المشروع بنجاح."
                                                    }.onFailure { err ->
                                                        exportStatusMessage = "خطأ أثناء توليد PDF: ${err.message}"
                                                        Toast.makeText(context, "فشل تصدير التقرير: ${err.message ?: "الذاكرة غير كافية"}", Toast.LENGTH_LONG).show()
                                                    }
                                                } catch (e: Exception) {
                                                    exportStatusMessage = "خطأ أثناء توليد PDF: ${e.message}"
                                                    Toast.makeText(context, "فشل تصدير التقرير: ${e.message}", Toast.LENGTH_LONG).show()
                                                } finally {
                                                    isExporting = false
                                                }
                                            }
                                        },
                                        onExportExcel = {
                                            val prjId = selectedProjectId ?: return@ProjectReportSection
                                            scope.launch {
                                                isExporting = true
                                                try {
                                                    val prj = activeProjects.firstOrNull { it.projectID == prjId } ?: return@launch
                                                    val records = repository.getAidRecordsForProjectSync(prjId)
                                                    val families = repository.getFamilies().first().associateBy { it.familyID }
                                                    val aidTypes = repository.getActiveAidTypes().first().associateBy { it.aidTypeID }

                                                    val combined = records.map {
                                                        AidRecordWithBeneficiary(record = it, family = families[it.familyID])
                                                    }
                                                    val reportData = ProjectReportData(
                                                        project = prj,
                                                        aidTypeName = aidTypes[prj.aidTypeID]?.aidTypeName ?: "مساعدات إغاثية",
                                                        records = combined,
                                                        dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                                        supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                                    )
                                                    val result = exporter.generateProjectBeneficiariesExcel(reportData)
                                                    result.onSuccess { file ->
                                                        exportedFile = file
                                                        exportedFileType = "EXCEL"
                                                        exportStatusMessage = "تم تصدير ملف Excel بنجاح."
                                                    }.onFailure { err ->
                                                        exportStatusMessage = "خطأ أثناء تصدير Excel: ${err.message}"
                                                        Toast.makeText(context, "فشل تصدير ملف الإكسل: ${err.message ?: "الذاكرة غير كافية"}", Toast.LENGTH_LONG).show()
                                                    }
                                                } catch (e: Exception) {
                                                    exportStatusMessage = "خطأ أثناء تصدير Excel: ${e.message}"
                                                    Toast.makeText(context, "فشل تصدير ملف الإكسل: ${e.message}", Toast.LENGTH_LONG).show()
                                                } finally {
                                                    isExporting = false
                                                }
                                            }
                                        }
                                    )
                                }
                                ReportDashboardTab.LOCALITY -> {
                                    // ب) تقرير محلية وشعبها
                                    LocalityReportSection(
                                        localities = dynamicLocalities,
                                        selectedLocality = geoStats.selectedLocality,
                                        onSelectLocality = { viewModel.selectLocality(it) },
                                        isExpanded = isLocalityPickerExpanded,
                                        onToggleExpand = { isLocalityPickerExpanded = !isLocalityPickerExpanded },
                                        subAreas = subAreaRatios,
                                        isExporting = isExporting,
                                        onExportPdf = {
                                            val locName = geoStats.selectedLocality.ifBlank { dynamicLocalities.firstOrNull() ?: return@LocalityReportSection }
                                            scope.launch {
                                                isExporting = true
                                                try {
                                                    val locFamilies = repository.getAllFamiliesSync().filter { it.currentSubRegion == locName }
                                                    val totalFam = locFamilies.size
                                                    val reportData = LocalityReportData(
                                                        localityName = locName,
                                                        subAreas = subAreaRatios,
                                                        totalFamilies = totalFam,
                                                        totalBeneficiaries = subAreaRatios.sumOf { it.eligibleFamiliesCount },
                                                        totalDelivered = subAreaRatios.sumOf { it.deliveredBeneficiariesCount },
                                                        dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                                        supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                                    )
                                                    val result = exporter.generateLocalitySubAreasPdf(reportData)
                                                    result.onSuccess { file ->
                                                        exportedFile = file
                                                        exportedFileType = "PDF"
                                                        exportStatusMessage = "تم توليد تقرير A4 PDF لتغطية المحلية وشعبها بنجاح."
                                                    }.onFailure { err ->
                                                        exportStatusMessage = "خطأ أثناء توليد PDF: ${err.message}"
                                                        Toast.makeText(context, "فشل تصدير التقرير: ${err.message ?: "الذاكرة غير كافية"}", Toast.LENGTH_LONG).show()
                                                    }
                                                } catch (e: Exception) {
                                                    exportStatusMessage = "خطأ أثناء توليد PDF: ${e.message}"
                                                    Toast.makeText(context, "فشل تصدير التقرير: ${e.message}", Toast.LENGTH_LONG).show()
                                                } finally {
                                                    isExporting = false
                                                }
                                            }
                                        },
                                        onExportExcel = {
                                            val locName = geoStats.selectedLocality.ifBlank { dynamicLocalities.firstOrNull() ?: return@LocalityReportSection }
                                            scope.launch {
                                                isExporting = true
                                                try {
                                                    val locFamilies = repository.getAllFamiliesSync().filter { it.currentSubRegion == locName }
                                                    val totalFam = locFamilies.size
                                                    val reportData = LocalityReportData(
                                                        localityName = locName,
                                                        subAreas = subAreaRatios,
                                                        totalFamilies = totalFam,
                                                        totalBeneficiaries = subAreaRatios.sumOf { it.eligibleFamiliesCount },
                                                        totalDelivered = subAreaRatios.sumOf { it.deliveredBeneficiariesCount },
                                                        dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                                        supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                                    )
                                                    val result = exporter.generateLocalitySubAreasExcel(reportData)
                                                    result.onSuccess { file ->
                                                        exportedFile = file
                                                        exportedFileType = "EXCEL"
                                                        exportStatusMessage = "تم تصدير ملف Excel للمحلية بنجاح."
                                                    }.onFailure { err ->
                                                        exportStatusMessage = "خطأ أثناء تصدير Excel: ${err.message}"
                                                        Toast.makeText(context, "فشل تصدير ملف الإكسل: ${err.message ?: "الذاكرة غير كافية"}", Toast.LENGTH_LONG).show()
                                                    }
                                                } catch (e: Exception) {
                                                    exportStatusMessage = "خطأ أثناء تصدير Excel: ${e.message}"
                                                    Toast.makeText(context, "فشل تصدير ملف الإكسل: ${e.message}", Toast.LENGTH_LONG).show()
                                                } finally {
                                                    isExporting = false
                                                }
                                            }
                                        }
                                    )
                                }
                                ReportDashboardTab.COMPREHENSIVE_PERIOD -> {
                                    // ج) تقرير التوزيع الشامل حسب الفترة
                                    ComprehensiveReportSection(
                                        fromDate = fromDate,
                                        toDate = toDate,
                                        periodDeliveryCount = periodDeliveryCount,
                                        localityStats = localityStats,
                                        aidTypeStats = aidTypeStats,
                                        distinctCategories = distinctAidCategories,
                                        isExporting = isExporting,
                                        onExportPdf = {
                                            scope.launch {
                                                isExporting = true
                                                try {
                                                    val allRecords = repository.getAllAidRecords().first()
                                                    val families = repository.getFamilies().first().associateBy { it.familyID }
                                                    val filtered = allRecords.filter {
                                                        val d = it.deliveryDate ?: it.aidDate
                                                        d in fromDate..toDate
                                                    }
                                                    val combined = filtered.map {
                                                        AidRecordWithBeneficiary(record = it, family = families[it.familyID])
                                                    }
                                                    val reportData = ComprehensivePeriodReportData(
                                                        fromDate = fromDate,
                                                        toDate = toDate,
                                                        totalDeliveries = periodDeliveryCount,
                                                        localityStats = localityStats,
                                                        aidTypeStats = aidTypeStats,
                                                        records = combined,
                                                        dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                                        supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                                    )
                                                    val result = exporter.generateComprehensivePeriodPdf(reportData)
                                                    result.onSuccess { file ->
                                                        exportedFile = file
                                                        exportedFileType = "PDF"
                                                        exportStatusMessage = "تم توليد تقرير A4 PDF الشامل بنجاح."
                                                    }.onFailure { err ->
                                                        exportStatusMessage = "خطأ أثناء توليد PDF: ${err.message}"
                                                        Toast.makeText(context, "فشل تصدير التقرير: ${err.message ?: "الذاكرة غير كافية"}", Toast.LENGTH_LONG).show()
                                                    }
                                                } catch (e: Exception) {
                                                    exportStatusMessage = "خطأ أثناء توليد PDF: ${e.message}"
                                                    Toast.makeText(context, "فشل تصدير التقرير: ${e.message}", Toast.LENGTH_LONG).show()
                                                } finally {
                                                    isExporting = false
                                                }
                                            }
                                        },
                                        onExportExcel = {
                                            scope.launch {
                                                isExporting = true
                                                try {
                                                    val allRecords = repository.getAllAidRecords().first()
                                                    val families = repository.getFamilies().first().associateBy { it.familyID }
                                                    val filtered = allRecords.filter {
                                                        val d = it.deliveryDate ?: it.aidDate
                                                        d in fromDate..toDate
                                                    }
                                                    val combined = filtered.map {
                                                        AidRecordWithBeneficiary(record = it, family = families[it.familyID])
                                                    }
                                                    val reportData = ComprehensivePeriodReportData(
                                                        fromDate = fromDate,
                                                        toDate = toDate,
                                                        totalDeliveries = periodDeliveryCount,
                                                        localityStats = localityStats,
                                                        aidTypeStats = aidTypeStats,
                                                        records = combined,
                                                        dateGenerated = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                                                        supervisorName = repository.getCurrentUser()?.fullName ?: "مدير العمليات"
                                                    )
                                                    val result = exporter.generateComprehensivePeriodExcel(reportData)
                                                    result.onSuccess { file ->
                                                        exportedFile = file
                                                        exportedFileType = "EXCEL"
                                                        exportStatusMessage = "تم تصدير ملف Excel الشامل للفترة بنجاح."
                                                    }.onFailure { err ->
                                                        exportStatusMessage = "خطأ أثناء تصدير Excel: ${err.message}"
                                                        Toast.makeText(context, "فشل تصدير ملف الإكسل: ${err.message ?: "الذاكرة غير كافية"}", Toast.LENGTH_LONG).show()
                                                    }
                                                } catch (e: Exception) {
                                                    exportStatusMessage = "خطأ أثناء تصدير Excel: ${e.message}"
                                                    Toast.makeText(context, "فشل تصدير ملف الإكسل: ${e.message}", Toast.LENGTH_LONG).show()
                                                } finally {
                                                    isExporting = false
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// =========================================================================
// المكونات الفرعية للشاشة
// =========================================================================

@Composable
private fun LocalityDistributionDonutChart(localityStats: List<LocalityDistributionStat>) {
    val activeStats = remember(localityStats) {
        localityStats.filter { it.deliveredAidCount > 0 || it.familiesCount > 0 }
    }

    if (activeStats.isEmpty()) {
        Box(modifier = Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
            Text("لا توجد بيانات توزيع للمحليات", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        return
    }

    val palette = listOf(
        Color(0xFF0D9488), Color(0xFF0284C7), Color(0xFF10B981),
        Color(0xFFF59E0B), Color(0xFF8B5CF6), Color(0xFFEC4899),
        Color(0xFF06B6D4), Color(0xFFF97316)
    )

    val totalAid = activeStats.sumOf { it.deliveredAidCount }

    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // مخطط Canvas دائري Donut
        Box(modifier = Modifier.size(150.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.size(130.dp)) {
                var currentAngle = -90f
                val strokeWidthPx = 28f

                activeStats.forEachIndexed { i, stat ->
                    val sweepAngle = if (totalAid > 0) (stat.deliveredAidCount.toFloat() / totalAid.toFloat()) * 360f else (360f / activeStats.size)
                    val color = palette[i % palette.size]

                    drawArc(
                        color = color,
                        startAngle = currentAngle,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        style = Stroke(width = strokeWidthPx, cap = StrokeCap.Round)
                    )
                    currentAngle += sweepAngle
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$totalAid", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                Text("طرد موزع", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Spacer(modifier = Modifier.width(16.dp))

        // جدول النسب والمفتاح الدليلي لكافة المحليات المسجلة بدقة
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            activeStats.forEachIndexed { i, stat ->
                val color = palette[i % palette.size]
                val percent = if (totalAid > 0) (stat.deliveredAidCount * 100 / totalAid) else 0
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
                        Text(stat.localityName, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                    }
                    Text("$percent% (${stat.deliveredAidCount})", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = color)
                }
            }
        }
    }
}

@Composable
private fun AidCategoriesDistributionChart(
    aidTypeStats: List<AidTypeDistributionStat>,
    distinctCategories: List<String>
) {
    val activeAidStats = remember(aidTypeStats) {
        aidTypeStats.filter { it.deliveredCount > 0 }
    }
    val totalDelivered = activeAidStats.sumOf { it.deliveredCount }.coerceAtLeast(1)

    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("توزيع المساعدات المسلمة حسب التصنيفات المعتمدة ديناميكياً:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        if (activeAidStats.isNotEmpty()) {
            activeAidStats.forEach { stat ->
                val percent = (stat.deliveredCount.toDouble() / totalDelivered.toDouble()) * 100.0
                val color = Color(stat.colorHex)
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(stat.aidTypeName, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "${stat.deliveredCount} مساعدة (${String.format(Locale.US, "%.1f%%", percent)})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = color
                        )
                    }
                    LinearProgressIndicator(
                        progress = { (percent / 100.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = color,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        } else if (distinctCategories.isNotEmpty()) {
            distinctCategories.forEach { cat ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                    ) {
                        Text("تصنيف معتمد", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }
        } else {
            Text("لا توجد بيانات لتصنيفات المساعدات في هذه الفترة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun FamilyClassificationsChart(
    residentStats: List<KeyCountRecord>,
    warDamageStats: List<KeyCountRecord>
) {
    val activeResident = remember(residentStats) { residentStats.filter { it.count > 0 } }
    val activeDamage = remember(warDamageStats) { warDamageStats.filter { it.count > 0 } }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("1. صفة الإقامة (مقيم / نازح):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        val totalResident = activeResident.sumOf { it.count }.coerceAtLeast(1)
        if (activeResident.isNotEmpty()) {
            activeResident.forEach { stat ->
                val pct = (stat.count * 100) / totalResident
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(stat.keyName, fontSize = 11.sp)
                        Text("$pct% (${stat.count} أسرة)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = { pct / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF0D9488),
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        } else {
            Text("لا توجد بيانات لحالة الإقامة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text("2. تصنيف أضرار الحرب:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        val totalDamage = activeDamage.sumOf { it.count }.coerceAtLeast(1)
        if (activeDamage.isNotEmpty()) {
            activeDamage.forEach { stat ->
                val pct = (stat.count * 100) / totalDamage
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(stat.keyName, fontSize = 11.sp)
                        Text("$pct% (${stat.count})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = { pct / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFFEF4444),
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }
        } else {
            Text("لا توجد بيانات لأضرار الحرب", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ProjectCompletionRatesCard(projects: List<ProjectEntity>) {
    if (projects.isEmpty()) {
        Text("لا توجد مشاريع نشطة حالياً", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        projects.forEach { prj ->
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(prj.projectNumber, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    Text("الممول: ${prj.fundingInstitution} • النطاق: ${prj.projectDate}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LinearProgressIndicator(
                        progress = { 0.75f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = Color(0xFF10B981)
                    )
                }
            }
        }
    }
}

@Composable
private fun ProjectReportSection(
    projects: List<ProjectEntity>,
    selectedProjectId: Long?,
    onSelectProject: (Long) -> Unit,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    isExporting: Boolean,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit
) {
    val currentProject = projects.firstOrNull { it.projectID == selectedProjectId }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "اختر المشروع لتوليد كشف المستفيدين الرسمي:",
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )

        // Dropdown Selector
        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedCard(
                modifier = Modifier.fillMaxWidth().clickable { onToggleExpand() },
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = currentProject?.projectName ?: "اختر المشروع...",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        if (currentProject != null) {
                            Text(
                                text = "${currentProject.projectNumber} • ${currentProject.fundingInstitution}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                }
            }

            DropdownMenu(
                expanded = isExpanded,
                onDismissRequest = onToggleExpand,
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                if (projects.isEmpty()) {
                    DropdownMenuItem(
                        text = { Text("لا توجد بيانات مشاريع مسجلة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        onClick = onToggleExpand,
                        enabled = false
                    )
                } else {
                    projects.forEach { prj ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(prj.projectName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("${prj.projectNumber} - ${prj.fundingInstitution}", fontSize = 10.sp)
                                }
                            },
                            onClick = {
                                onSelectProject(prj.projectID)
                                onToggleExpand()
                            }
                        )
                    }
                }
            }
        }

        // أزرار التصدير
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onExportPdf,
                enabled = !isExporting && selectedProjectId != null,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("تصدير كشف A4 PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onExportExcel,
                enabled = !isExporting && selectedProjectId != null,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("تصدير إكسل Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun LocalityReportSection(
    localities: List<String>,
    selectedLocality: String,
    onSelectLocality: (String) -> Unit,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    subAreas: List<SubAreaBenefitRatioStat>,
    isExporting: Boolean,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit
) {
    val currentLoc = selectedLocality.ifBlank { localities.firstOrNull() ?: "" }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("اختر المحلية لاستخراج تقرير الشعب والنسب الدقيقة:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)

        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedCard(
                modifier = Modifier.fillMaxWidth().clickable { onToggleExpand() },
                shape = RoundedCornerShape(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = currentLoc.ifBlank { "اختر المحلية..." },
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                }
            }

            DropdownMenu(
                expanded = isExpanded,
                onDismissRequest = onToggleExpand,
                modifier = Modifier.fillMaxWidth(0.9f)
            ) {
                if (localities.isEmpty()) {
                    DropdownMenuItem(
                        text = { Text("لا توجد بيانات محليات مسجلة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        onClick = onToggleExpand,
                        enabled = false
                    )
                } else {
                    localities.forEach { locName ->
                        DropdownMenuItem(
                            text = { Text(locName, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            onClick = {
                                onSelectLocality(locName)
                                onToggleExpand()
                            }
                        )
                    }
                }
            }
        }

        // إحصائية سريعة
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("الشعب المشمولة: ${subAreas.size} شعبة", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                Text("المستحقين: ${subAreas.sumOf { it.eligibleFamiliesCount }}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
        }

        // أزرار التصدير
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onExportPdf,
                enabled = !isExporting && currentLoc.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("تصدير تقرير A4 PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onExportExcel,
                enabled = !isExporting && currentLoc.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("تصدير إكسل Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ComprehensiveReportSection(
    fromDate: String,
    toDate: String,
    periodDeliveryCount: Int,
    localityStats: List<LocalityDistributionStat>,
    aidTypeStats: List<AidTypeDistributionStat>,
    distinctCategories: List<String> = emptyList(),
    isExporting: Boolean,
    onExportPdf: () -> Unit,
    onExportExcel: () -> Unit
) {
    var selectedCatFilter by remember { mutableStateOf("كافة التصنيفات") }
    val categoryTabs = remember(distinctCategories, aidTypeStats) {
        listOf("كافة التصنيفات") + (if (distinctCategories.isNotEmpty()) distinctCategories else aidTypeStats.map { it.aidTypeName }.distinct())
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تقرير العمليات الميدانية الشامل:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                Text("الفترة المحددة: من $fromDate إلى $toDate", fontSize = 11.sp)
                Text("إجمالي المساعدات المنفذة في هذه الفترة: $periodDeliveryCount طرد موزع", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("يغطي ${localityStats.size} محلية و ${aidTypeStats.size} صنف إغاثي مع جداول المستلمين ومربعات التوقيع.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // تبويبات فلترة تصنيفات المساعدات الديناميكية
        if (categoryTabs.size > 2) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("تصنيف المساعدة المشمول:", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categoryTabs.forEach { cat ->
                        val isSel = selectedCatFilter == cat
                        Surface(
                            onClick = { selectedCatFilter = cat },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            contentColor = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface
                        ) {
                            Text(
                                text = cat,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onExportPdf,
                enabled = !isExporting,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("تصدير شامل A4 PDF", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onExportExcel,
                enabled = !isExporting,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("تصدير إكسل Excel", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * بطاقة إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية المفصلة والديناميكية
 * تتيح اختيار محلية وشعبة معينة لعرض التوزيع التجميعي المحدث لحظياً للأسر والمنازل المهدمة وأضرار الحرب
 */
@Composable
fun DynamicReportsGeoDamageCard(
    localities: List<String>,
    selectedLocality: String,
    selectedSubArea: String,
    availableSubAreas: List<String>,
    localityFamilyCount: Int,
    subAreaFamilyCount: Int,
    localityCounts: Map<String, Int>,
    completelyDestroyedCount: Int,
    warDamageStats: WarDamageStats?,
    damageDistribution: List<DamageTypeBreakdown>,
    onLocalitySelected: (String) -> Unit,
    onSubAreaSelected: (String) -> Unit
) {
    var localityExpanded by remember { mutableStateOf(false) }
    var subAreaExpanded by remember { mutableStateOf(false) }

    val selectedLocalityName = selectedLocality.ifBlank { "اختر المحلية" }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, Color(0xFF0284C7).copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ترويسة البطاقة بدون أي عناصر تسبب انضغاط النص أفقياً
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LocationCity,
                    contentDescription = null,
                    tint = Color(0xFF0284C7),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إحصائيات النطاق الجغرافي وأضرار المناطق الميدانية",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = "اختر المحلية والشعبة لعرض التوزيع التجميعي المحدث لحظياً للأسر وأضرار الحرب:",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // صفي القوائم المنسدلة لاختيار المحلية والشعبة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // منسدل المحلية
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { localityExpanded = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Icon(Icons.Default.LocationCity, contentDescription = null, tint = Color(0xFF16A34A), modifier = Modifier.size(16.dp))
                                Text(
                                    text = selectedLocalityName,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF16A34A))
                        }
                    }

                    DropdownMenu(
                        expanded = localityExpanded,
                        onDismissRequest = { localityExpanded = false }
                    ) {
                        localities.forEach { locName ->
                            val count = localityCounts[locName] ?: 0
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            locName,
                                            fontWeight = if (locName == selectedLocality) FontWeight.Bold else FontWeight.Normal
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("($count أسرة)", fontSize = 11.sp, color = Color(0xFF16A34A))
                                    }
                                },
                                onClick = {
                                    onLocalitySelected(locName)
                                    localityExpanded = false
                                }
                            )
                        }
                    }
                }

                // منسدل الشعبة / المنطقة الفرعية
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { subAreaExpanded = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                Icon(Icons.Default.AltRoute, contentDescription = null, tint = Color(0xFF0284C7), modifier = Modifier.size(16.dp))
                                Text(
                                    text = selectedSubArea.ifBlank { "كافة الشعب" },
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color(0xFF0284C7))
                        }
                    }

                    DropdownMenu(
                        expanded = subAreaExpanded,
                        onDismissRequest = { subAreaExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    "كافة الشعب والمناطق الفرعية",
                                    fontWeight = if (selectedSubArea.isBlank()) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            onClick = {
                                onSubAreaSelected("")
                                subAreaExpanded = false
                            }
                        )

                        availableSubAreas.forEach { sub ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        sub,
                                        fontWeight = if (sub == selectedSubArea) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onSubAreaSelected(sub)
                                    subAreaExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // شبكة المؤشرات الإحصائية الأربعة الرئيسية
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReportGeoStatBadge(
                    title = "أسر المحلية",
                    value = "$localityFamilyCount",
                    subtitle = selectedLocalityName,
                    color = Color(0xFF16A34A),
                    icon = Icons.Default.Groups,
                    modifier = Modifier.weight(1f)
                )

                ReportGeoStatBadge(
                    title = "أسر الشعبة",
                    value = if (selectedSubArea.isNotBlank()) "$subAreaFamilyCount" else "الكل",
                    subtitle = selectedSubArea.ifBlank { "غير مقيد بشعبة" },
                    color = Color(0xFF0284C7),
                    icon = Icons.Default.LocationOn,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ReportGeoStatBadge(
                    title = "منازل مهدمة كلياً",
                    value = "$completelyDestroyedCount",
                    subtitle = "أضرار كلية بالنطاق",
                    color = Color(0xFFDC2626),
                    icon = Icons.Default.HomeWork,
                    modifier = Modifier.weight(1f)
                )

                val totalAssessed = warDamageStats?.totalAssessed ?: 0
                ReportGeoStatBadge(
                    title = "إجمالي أضرار الحرب",
                    value = "$totalAssessed",
                    subtitle = "منازل مسجلة بالنطاق",
                    color = Color(0xFFD97706),
                    icon = Icons.Default.Warning,
                    modifier = Modifier.weight(1f)
                )
            }

            // تفصيل الحالات الهندسية والإنشائية
            warDamageStats?.let { ws ->
                if (ws.totalAssessed > 0) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "تفصيل الحالات الهندسية والإنشائية المسجلة:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                MiniDamagePill(
                                    label = "جزئي بليغ",
                                    count = ws.severePartialDamageCount,
                                    color = Color(0xFFEA580C),
                                    modifier = Modifier.weight(1f)
                                )
                                MiniDamagePill(
                                    label = "جزئي طفيف",
                                    count = ws.minorPartialDamageCount,
                                    color = Color(0xFFCA8A04),
                                    modifier = Modifier.weight(1f)
                                )
                                MiniDamagePill(
                                    label = "سليم / لا ضرر",
                                    count = ws.noDamageCount,
                                    color = Color(0xFF16A34A),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            // توزيع درجات الأضرار المسجلة ميدانياً مع أشرطة بيانية تفاعلية
            if (damageDistribution.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "توزيع درجات الأضرار المسجلة ميدانياً بالنطاق:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        val total = damageDistribution.sumOf { it.count }.coerceAtLeast(1)
                        damageDistribution.forEach { item ->
                            val percent = (item.count.toDouble() / total.toDouble()) * 100
                            Column(modifier = Modifier.padding(vertical = 3.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = item.damageType,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${item.count} منزل (${String.format(Locale.US, "%.1f%%", percent)})",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF16A34A)
                                    )
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                LinearProgressIndicator(
                                    progress = (item.count.toFloat() / total.toFloat()).coerceIn(0f, 1f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(4.dp)
                                        .clip(RoundedCornerShape(2.dp)),
                                    color = Color(0xFF16A34A),
                                    trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportGeoStatBadge(
    title: String,
    value: String,
    subtitle: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
                Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = color)
            }
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MiniDamagePill(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = color.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "$count", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

