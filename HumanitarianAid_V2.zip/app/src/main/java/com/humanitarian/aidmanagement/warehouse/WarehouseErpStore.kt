package com.humanitarian.aidmanagement.warehouse

import android.content.Context
import com.humanitarian.aidmanagement.security.TamperProofAuditLog
import com.humanitarian.aidmanagement.util.PublicDownloadsExporter
import com.humanitarian.aidmanagement.util.SavedExportResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.ceil

// ============================================================================
// 1. النماذج البيانية والمحاسبية لنظام إدارة المخازن واللوجستيات (Warehouse ERP & 3PL)
// ============================================================================

object WarehouseConstants {
    const val ALL_WAREHOUSES = "ALL"

    const val ZONE_DRY = "جاف"
    const val ZONE_COLD = "مبرد"
    const val ZONE_CUSTODY = "أمانات"
    const val ZONE_QUARANTINE = "حجر صحي"

    val STORAGE_ZONES = listOf(ZONE_DRY, ZONE_COLD, ZONE_CUSTODY, ZONE_QUARANTINE)
    val STORAGE_TYPES = listOf("جاف", "مبرد", "ساحة مفتوحة")
    val WAREHOUSE_STATUSES = listOf("نشط", "ممتلئ", "مغلق")
    val WORKER_ROLES = listOf(
        "أمين مخزن",
        "عامل تحميل",
        "حارس أمن",
        "أمين عهدة فرعي",
        "مدخل بيانات"
    )
    val EXPENSE_CATEGORIES = listOf(
        "محروقات وسولار",
        "نقل وعتالة",
        "صيانة",
        "تغليف",
        "نثريات"
    )
}

enum class WorkerPayType(val arabicLabel: String) {
    MONTHLY("راتب شهري"),
    DAILY("أجر يومي");

    companion object {
        fun fromString(raw: String): WorkerPayType {
            return entries.firstOrNull { it.name.equals(raw.trim(), ignoreCase = true) } ?: MONTHLY
        }
    }
}

enum class StockMovementType(val arabicTitle: String, val voucherPrefix: String) {
    IN("سند استلام واردات (GRN)", "GRN"),
    OUT("سند إرسال صادرات (GDN)", "GDN"),
    TRANSFER("مناقلة بين مخزنين", "TRF"),
    KIT_ASSEMBLE("تجميع طرود (Kit)", "KIT-A"),
    KIT_UNBUNDLE("تفكيك طرود (Unbundle)", "KIT-U"),
    DELIVERY_DEDUCT("خصم تسليم ميداني", "DLV-OUT"),
    DELIVERY_RESTORE("إرجاع تراجع تسليم", "DLV-RET"),
    AUDIT_ADJUST("تسوية جرد أعمى", "AUD");

    companion object {
        fun fromString(raw: String): StockMovementType {
            return entries.firstOrNull { it.name.equals(raw.trim(), ignoreCase = true) } ?: IN
        }
    }
}

enum class ClientBillingModel(val arabicLabel: String) {
    PER_PIECE_DAY("بالقطعة / يوم"),
    PER_PALLET_WEEK("بالطبلية / أسبوع"),
    PER_MONTH("شهري");

    companion object {
        fun fromString(raw: String): ClientBillingModel {
            return entries.firstOrNull { it.name.equals(raw.trim(), ignoreCase = true) } ?: PER_PIECE_DAY
        }
    }
}

enum class ClientStorageTxType(val arabicLabel: String) {
    DEPOSIT("إيداع بضاعة"),
    WITHDRAWAL("سحب بضاعة"),
    PAYMENT("دفعة سداد مالي");

    companion object {
        fun fromString(raw: String): ClientStorageTxType {
            return entries.firstOrNull { it.name.equals(raw.trim(), ignoreCase = true) } ?: DEPOSIT
        }
    }
}

enum class ShipmentStatus(val arabicLabel: String) {
    IN_TRANSIT("في الطريق (بانتظار الاستلام)"),
    CONFIRMED("تم الاستلام بالكامل"),
    SHORTAGE_REPORTED("تم الاستلام مع محضر عجز");

    companion object {
        fun fromString(raw: String): ShipmentStatus {
            return entries.firstOrNull { it.name.equals(raw.trim(), ignoreCase = true) } ?: IN_TRANSIT
        }
    }
}

enum class PettyCashStatus(val arabicLabel: String) {
    OPEN("عهدة مفتوحة"),
    SETTLED("عهدة مسوّاة ومغلقة");

    companion object {
        fun fromString(raw: String): PettyCashStatus {
            return entries.firstOrNull { it.name.equals(raw.trim(), ignoreCase = true) } ?: OPEN
        }
    }
}

data class Warehouse(
    val id: String,
    val name: String,
    val location: String = "",
    val storageType: String = "جاف",
    val maxCapacity: Long = 10000L,
    val status: String = "نشط",
    val keeperName: String = "",
    val keeperId: String = "",
    val keeperPhone: String = "",
    val equipmentNotes: String = "",
    val createdAt: String = ""
)

data class WarehouseWorker(
    val id: String,
    val warehouseId: String,
    val name: String,
    val role: String = "أمين مخزن",
    val payType: WorkerPayType = WorkerPayType.MONTHLY,
    val rate: Double = 0.0,
    val isActive: Boolean = true
)

data class WarehouseItem(
    val id: String,
    val warehouseId: String,
    val name: String,
    val category: String = "",
    val majorUnitName: String = "كرتونة",
    val minorUnitName: String = "قطعة",
    val conversionFactor: Int = 1,
    val totalMinorQty: Long = 0L,
    val minThreshold: Long = 0L,
    val expiryDate: String = "",
    val linkedProjectId: String? = null
) {
    val safeConversionFactor: Int
        get() = conversionFactor.coerceAtLeast(1)

    val fullMajorUnits: Long
        get() = totalMinorQty / safeConversionFactor.toLong()

    val remainingMinorUnits: Long
        get() = totalMinorQty % safeConversionFactor.toLong()

    val isLowStock: Boolean
        get() = minThreshold > 0L && totalMinorQty <= minThreshold

    fun toMinorUnits(majorQty: Long, minorQty: Long): Long {
        return (majorQty * safeConversionFactor.toLong()) + minorQty
    }

    fun formatDualQuantity(): String {
        val factor = safeConversionFactor
        val majorLabel = majorUnitName.ifBlank { "وحدة كبرى" }
        val minorLabel = minorUnitName.ifBlank { "قطعة" }
        return if (factor <= 1) {
            "$totalMinorQty $minorLabel"
        } else {
            val fullMajor = fullMajorUnits
            val remMinor = remainingMinorUnits
            if (remMinor == 0L) {
                "$fullMajor $majorLabel ($totalMinorQty $minorLabel)"
            } else {
                "$fullMajor $majorLabel + $remMinor $minorLabel ($totalMinorQty $minorLabel)"
            }
        }
    }
}

data class KitComponentSpec(
    val componentItemId: String,
    val minorQtyPerKit: Long
)

data class StockMovement(
    val id: String,
    val voucherNo: String,
    val type: StockMovementType,
    val warehouseId: String,
    val targetWarehouseId: String? = null,
    val itemId: String,
    val itemName: String,
    val majorQty: Long = 0L,
    val minorQty: Long = 0L,
    val totalMinorDelta: Long,
    val supplierOrDonor: String = "",
    val waybillNo: String = "",
    val batchNo: String = "",
    val recipientOrProject: String = "",
    val linkedProjectId: String? = null,
    val driverName: String = "",
    val vehiclePlate: String = "",
    val date: String,
    val notes: String = "",
    val performedBy: String = ""
)

data class StorageClient(
    val id: String,
    val warehouseId: String,
    val clientName: String,
    val contactPerson: String = "",
    val phone: String = "",
    val billingModel: ClientBillingModel = ClientBillingModel.PER_PIECE_DAY,
    val unitRate: Double = 0.0,
    val handlingFee: Double = 0.0,
    val freeGraceDays: Int = 0
)

data class ClientStorageTx(
    val id: String,
    val clientId: String,
    val warehouseId: String,
    val type: ClientStorageTxType,
    val itemDescription: String = "",
    val quantityPieces: Long = 0L,
    val paymentAmount: Double = 0.0,
    val date: String,
    val notes: String = "",
    val performedBy: String = ""
)

data class ClientBillingSummary(
    val clientId: String,
    val totalDepositedPieces: Long,
    val totalWithdrawnPieces: Long,
    val remainingPieces: Long,
    val totalBillableStorageDays: Long,
    val totalBillablePieceDays: Long,
    val storageFeeTotal: Double,
    val handlingFeeTotal: Double,
    val totalCharges: Double,
    val totalPaid: Double,
    val netAmountDue: Double
)

data class WarehouseBudgetEntry(
    val id: String,
    val warehouseId: String,
    val allocatedAmount: Double,
    val fundingSource: String = "",
    val date: String,
    val notes: String = "",
    val performedBy: String = ""
)

data class WarehouseExpense(
    val id: String,
    val warehouseId: String,
    val category: String,
    val amount: Double,
    val invoiceNo: String = "",
    val date: String,
    val notes: String = "",
    val performedBy: String = "",
    val allocatedTarget: String = "GENERAL"
)

data class WarehousePayrollRecord(
    val id: String,
    val warehouseId: String,
    val periodLabel: String,
    val workerId: String,
    val workerName: String,
    val role: String,
    val payType: WorkerPayType = WorkerPayType.MONTHLY,
    val rate: Double = 0.0,
    val daysWorked: Int = 0,
    val amount: Double = 0.0,
    val isPaid: Boolean = false,
    val paidDate: String = "",
    val performedBy: String = ""
)

data class WarehouseFinancialSummary(
    val warehouseId: String,
    val approvedBudget: Double,
    val thirdPartyStorageRevenue: Double,
    val thirdPartyReceivables: Double,
    val totalExpenses: Double,
    val totalPayroll: Double,
    val pendingPayroll: Double,
    val netWarehouseBalance: Double,
    val totalHandledUnits: Long,
    val avgHandlingCostPerUnit: Double
)

data class BlindAuditVarianceResult(
    val itemId: String,
    val itemName: String,
    val systemMinorQty: Long,
    val countedMinorQty: Long,
    val varianceMinorQty: Long,
    val movement: StockMovement
)

data class BlindAuditItemInput(
    val itemId: String,
    val countedMajorQty: Long,
    val countedMinorQty: Long
)

data class BlindAuditBatchReport(
    val warehouseId: String,
    val warehouseName: String,
    val auditedAt: String,
    val performedBy: String,
    val reason: String,
    val results: List<BlindAuditVarianceResult>,
    val auditRecordId: String,
    val auditEntryHash: String
)

data class StockBatch(
    val id: String,
    val itemId: String,
    val warehouseId: String,
    val batchNo: String,
    val donorName: String = "",
    val expiryDate: String = "",
    val remainingMinorQty: Long = 0L,
    val zoneName: String = WarehouseConstants.ZONE_DRY,
    val createdAt: String = ""
) {
    val isQuarantined: Boolean
        get() = zoneName.trim() == WarehouseConstants.ZONE_QUARANTINE
}

data class InTransitShipment(
    val shipmentId: String,
    val fromWarehouseId: String,
    val toWarehouseId: String,
    val itemId: String,
    val itemName: String,
    val sentMinorQty: Long,
    val driverName: String = "",
    val vehiclePlate: String = "",
    val status: ShipmentStatus = ShipmentStatus.IN_TRANSIT,
    val receivedMinorQty: Long = 0L,
    val shortageQty: Long = 0L,
    val gatePassToken: String = "",
    val voucherNo: String = "",
    val batchNo: String = "",
    val expiryDate: String = "",
    val donorName: String = "",
    val category: String = "",
    val majorUnitName: String = "كرتونة",
    val minorUnitName: String = "قطعة",
    val conversionFactor: Int = 1,
    val sentAt: String = "",
    val confirmedAt: String = "",
    val notes: String = "",
    val performedBy: String = "",
    val shortageAuditHash: String = ""
)

data class ColdChainLog(
    val id: String,
    val warehouseId: String,
    val timestamp: String,
    val temperatureCelsius: Double,
    val generatorHours: Double,
    val recordedBy: String = "",
    val notes: String = ""
)

data class PettyCashAdvance(
    val id: String,
    val warehouseId: String,
    val keeperName: String,
    val amount: Double,
    val date: String,
    val status: PettyCashStatus = PettyCashStatus.OPEN,
    val spentAmount: Double = 0.0,
    val settledDate: String = "",
    val notes: String = "",
    val performedBy: String = ""
) {
    val remainingAmount: Double
        get() = kotlin.math.round((amount - spentAmount) * 100.0) / 100.0
}

data class WarehouseErpState(
    val warehouses: List<Warehouse> = emptyList(),
    val workers: List<WarehouseWorker> = emptyList(),
    val items: List<WarehouseItem> = emptyList(),
    val batches: List<StockBatch> = emptyList(),
    val movements: List<StockMovement> = emptyList(),
    val inTransitShipments: List<InTransitShipment> = emptyList(),
    val coldChainLogs: List<ColdChainLog> = emptyList(),
    val pettyCashAdvances: List<PettyCashAdvance> = emptyList(),
    val clients: List<StorageClient> = emptyList(),
    val clientTransactions: List<ClientStorageTx> = emptyList(),
    val budgetEntries: List<WarehouseBudgetEntry> = emptyList(),
    val expenses: List<WarehouseExpense> = emptyList(),
    val payrollRecords: List<WarehousePayrollRecord> = emptyList(),
    val isLoaded: Boolean = false
)

// ============================================================================
// 2. محرك البيانات والمحاسبة المخزنية المحلي (JSON + Reactive StateFlow)
// ============================================================================

object WarehouseErpStore {

    private const val STORE_FILE_NAME = "warehouse_erp_v1.json"
    private const val DATE_ONLY_PATTERN = "yyyy-MM-dd"
    private const val DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm"

    private val storeLock = Any()

    private val _stateFlow = MutableStateFlow(WarehouseErpState())
    val stateFlow: StateFlow<WarehouseErpState> = _stateFlow.asStateFlow()

    val currentState: WarehouseErpState
        get() = _stateFlow.value

    private fun getStoreFile(context: Context): File {
        return File(context.applicationContext.filesDir, STORE_FILE_NAME)
    }

    private fun nowDate(): String = SimpleDateFormat(DATE_ONLY_PATTERN, Locale.US).format(Date())

    private fun nowDateTime(): String = SimpleDateFormat(DATE_TIME_PATTERN, Locale.US).format(Date())

    private fun newId(prefix: String): String {
        val shortUid = UUID.randomUUID().toString().replace("-", "").take(8).uppercase(Locale.US)
        return "$prefix-${System.currentTimeMillis()}-$shortUid"
    }

    private fun newVoucherNo(type: StockMovementType): String {
        val stamp = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date())
        val rand = UUID.randomUUID().toString().replace("-", "").take(4).uppercase(Locale.US)
        return "${type.voucherPrefix}-$stamp-$rand"
    }

    /**
     * تحميل البيانات من ملف JSON المحلي مرة واحدة عند الحاجة وتحديث StateFlow.
     */
    fun ensureLoaded(context: Context): WarehouseErpState {
        val current = _stateFlow.value
        if (current.isLoaded) return current
        return reload(context)
    }

    fun reload(context: Context): WarehouseErpState {
        synchronized(storeLock) {
            val file = getStoreFile(context)
            val parsed = if (file.exists() && file.length() > 0L) {
                runCatching { parseStateFromJson(file.readText(Charsets.UTF_8)) }
                    .getOrElse { WarehouseErpState(isLoaded = true) }
            } else {
                WarehouseErpState(isLoaded = true)
            }
            _stateFlow.value = parsed.copy(isLoaded = true)
            return _stateFlow.value
        }
    }

    private fun commitStateLocked(context: Context, newState: WarehouseErpState) {
        val marked = newState.copy(isLoaded = true)
        val jsonStr = serializeStateToJson(marked).toString(2)
        val targetFile = getStoreFile(context)
        val tmpFile = File(targetFile.parentFile, "$STORE_FILE_NAME.tmp")
        tmpFile.writeText(jsonStr, Charsets.UTF_8)
        if (targetFile.exists()) {
            targetFile.delete()
        }
        if (!tmpFile.renameTo(targetFile)) {
            targetFile.writeText(jsonStr, Charsets.UTF_8)
            tmpFile.delete()
        }
        _stateFlow.value = marked
    }

    private suspend fun writeAuditSafe(
        context: Context,
        actionType: String,
        targetId: String,
        details: String,
        performedBy: String
    ) {
        runCatching {
            TamperProofAuditLog.logEvent(
                context = context,
                actionType = actionType,
                targetId = targetId,
                details = details,
                performedBy = performedBy.ifBlank { "أمين المخزن" }
            )
        }
    }

    // ------------------------------------------------------------------------
    // أ) إدارة المخازن (Warehouses) مع دعم العزل بمخزن محدد (assignedWarehouseId)
    // ------------------------------------------------------------------------

    fun getVisibleWarehouses(assignedWarehouseId: String): List<Warehouse> {
        val all = _stateFlow.value.warehouses
        val cleanAssigned = assignedWarehouseId.trim()
        if (cleanAssigned.isBlank() ||
            cleanAssigned.equals(WarehouseConstants.ALL_WAREHOUSES, ignoreCase = true) ||
            cleanAssigned == "الكل" ||
            cleanAssigned == "*"
        ) {
            return all
        }
        return all.filter { it.id == cleanAssigned }
    }

    suspend fun saveWarehouse(
        context: Context,
        warehouse: Warehouse,
        performedBy: String = ""
    ): Warehouse = withContext(Dispatchers.IO) {
        val saved = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val resolvedId = warehouse.id.trim().ifBlank { newId("WH") }
            val resolved = warehouse.copy(
                id = resolvedId,
                name = warehouse.name.trim(),
                location = warehouse.location.trim(),
                storageType = warehouse.storageType.trim().ifBlank { "جاف" },
                maxCapacity = warehouse.maxCapacity.coerceAtLeast(1L),
                status = warehouse.status.trim().ifBlank { "نشط" },
                keeperName = warehouse.keeperName.trim(),
                keeperId = warehouse.keeperId.trim(),
                keeperPhone = warehouse.keeperPhone.trim(),
                equipmentNotes = warehouse.equipmentNotes.trim(),
                createdAt = warehouse.createdAt.ifBlank { nowDate() }
            )
            val updatedList = state.warehouses.filterNot { it.id == resolvedId } + resolved
            commitStateLocked(context, state.copy(warehouses = updatedList))
            resolved
        }
        writeAuditSafe(
            context = context,
            actionType = "إدارة المخازن",
            targetId = saved.id,
            details = "حفظ/تحديث تعريف المخزن: ${saved.name} (${saved.storageType} - ${saved.status})",
            performedBy = performedBy
        )
        saved
    }

    suspend fun deleteWarehouse(
        context: Context,
        warehouseId: String,
        performedBy: String = ""
    ) = withContext(Dispatchers.IO) {
        val removedName = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val target = state.warehouses.firstOrNull { it.id == warehouseId }
            val next = state.copy(
                warehouses = state.warehouses.filterNot { it.id == warehouseId },
                workers = state.workers.filterNot { it.warehouseId == warehouseId },
                items = state.items.filterNot { it.warehouseId == warehouseId },
                batches = state.batches.filterNot { it.warehouseId == warehouseId },
                inTransitShipments = state.inTransitShipments.filterNot {
                    it.fromWarehouseId == warehouseId || it.toWarehouseId == warehouseId
                },
                coldChainLogs = state.coldChainLogs.filterNot { it.warehouseId == warehouseId },
                pettyCashAdvances = state.pettyCashAdvances.filterNot { it.warehouseId == warehouseId },
                clients = state.clients.filterNot { it.warehouseId == warehouseId },
                clientTransactions = state.clientTransactions.filterNot { it.warehouseId == warehouseId },
                budgetEntries = state.budgetEntries.filterNot { it.warehouseId == warehouseId },
                expenses = state.expenses.filterNot { it.warehouseId == warehouseId },
                payrollRecords = state.payrollRecords.filterNot { it.warehouseId == warehouseId }
            )
            commitStateLocked(context, next)
            target?.name ?: warehouseId
        }
        writeAuditSafe(
            context = context,
            actionType = "إدارة المخازن",
            targetId = warehouseId,
            details = "حذف المخزن وسجلاته المرتبطة: $removedName",
            performedBy = performedBy
        )
    }

    // ------------------------------------------------------------------------
    // ب) إدارة طاقم العاملين في المخزن (Warehouse Workers)
    // ------------------------------------------------------------------------

    suspend fun saveWorker(
        context: Context,
        worker: WarehouseWorker,
        performedBy: String = ""
    ): WarehouseWorker = withContext(Dispatchers.IO) {
        val saved = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val resolvedId = worker.id.trim().ifBlank { newId("WRK") }
            val resolved = worker.copy(
                id = resolvedId,
                name = worker.name.trim(),
                role = worker.role.trim().ifBlank { "عامل تحميل" },
                rate = worker.rate.coerceAtLeast(0.0)
            )
            val updated = state.workers.filterNot { it.id == resolvedId } + resolved
            commitStateLocked(context, state.copy(workers = updated))
            resolved
        }
        writeAuditSafe(
            context = context,
            actionType = "طاقم المخزن",
            targetId = saved.warehouseId,
            details = "حفظ/تحديث عامل مخزن: ${saved.name} (${saved.role} - ${saved.payType.arabicLabel}: ${saved.rate})",
            performedBy = performedBy
        )
        saved
    }

    suspend fun deleteWorker(
        context: Context,
        workerId: String,
        performedBy: String = ""
    ) = withContext(Dispatchers.IO) {
        synchronized(storeLock) {
            val state = ensureLoaded(context)
            commitStateLocked(context, state.copy(workers = state.workers.filterNot { it.id == workerId }))
        }
        writeAuditSafe(
            context = context,
            actionType = "طاقم المخزن",
            targetId = workerId,
            details = "حذف عامل من طاقم المخزن",
            performedBy = performedBy
        )
    }

    // ------------------------------------------------------------------------
    // ج) إدارة الأصناف بالوحدات المزدوجة (Dual-Unit Warehouse Items)
    // ------------------------------------------------------------------------

    suspend fun saveItem(
        context: Context,
        item: WarehouseItem,
        performedBy: String = ""
    ): WarehouseItem = withContext(Dispatchers.IO) {
        val saved = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val resolvedId = item.id.trim().ifBlank { newId("ITM") }
            val existing = state.items.firstOrNull { it.id == resolvedId }
            val resolved = item.copy(
                id = resolvedId,
                name = item.name.trim(),
                category = item.category.trim(),
                majorUnitName = item.majorUnitName.trim().ifBlank { "كرتونة" },
                minorUnitName = item.minorUnitName.trim().ifBlank { "قطعة" },
                conversionFactor = item.conversionFactor.coerceAtLeast(1),
                totalMinorQty = item.totalMinorQty.coerceAtLeast(0L),
                minThreshold = item.minThreshold.coerceAtLeast(0L),
                expiryDate = item.expiryDate.trim(),
                linkedProjectId = item.linkedProjectId?.trim()?.takeIf { it.isNotBlank() }
            )
            val updatedItems = state.items.filterNot { it.id == resolvedId } + resolved
            val existingItemBatches = state.batches.filter { it.itemId == resolvedId && !it.isQuarantined && it.remainingMinorQty > 0L }
            val updatedBatches = if (existing == null && resolved.totalMinorQty > 0L && existingItemBatches.isEmpty()) {
                state.batches + StockBatch(
                    id = newId("BCH"),
                    itemId = resolvedId,
                    warehouseId = resolved.warehouseId,
                    batchNo = "INIT-${resolvedId.takeLast(6)}",
                    donorName = "",
                    expiryDate = resolved.expiryDate,
                    remainingMinorQty = resolved.totalMinorQty,
                    zoneName = WarehouseConstants.ZONE_DRY,
                    createdAt = nowDateTime()
                )
            } else {
                state.batches
            }
            commitStateLocked(context, state.copy(items = updatedItems, batches = updatedBatches))
            resolved
        }
        writeAuditSafe(
            context = context,
            actionType = "أصناف المخزن",
            targetId = saved.id,
            details = "تعريف/تحديث صنف: ${saved.name} (${saved.formatDualQuantity()})",
            performedBy = performedBy
        )
        saved
    }

    suspend fun deleteItem(
        context: Context,
        itemId: String,
        performedBy: String = ""
    ) = withContext(Dispatchers.IO) {
        synchronized(storeLock) {
            val state = ensureLoaded(context)
            commitStateLocked(
                context,
                state.copy(
                    items = state.items.filterNot { it.id == itemId },
                    batches = state.batches.filterNot { it.itemId == itemId }
                )
            )
        }
        writeAuditSafe(
            context = context,
            actionType = "أصناف المخزن",
            targetId = itemId,
            details = "حذف صنف من دليل المخزن",
            performedBy = performedBy
        )
    }

    // ------------------------------------------------------------------------
    // د) محرك التشغيلات (FEFO)، حركات الوارد والصادر، النقل المؤمّن، الحجر الصحي وسلسلة التبريد
    // ------------------------------------------------------------------------

    private data class FefoDeductionResult(
        val updatedBatches: List<StockBatch>,
        val deductedMinorQty: Long,
        val consumedBatchNos: List<String>,
        val earliestConsumedExpiry: String,
        val primaryDonorName: String
    )

    private fun newCustomVoucherNo(prefix: String): String {
        val stamp = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date())
        val rand = UUID.randomUUID().toString().replace("-", "").take(4).uppercase(Locale.US)
        return "$prefix-$stamp-$rand"
    }

    private fun newGatePassToken(): String {
        val stamp = SimpleDateFormat("yyMMddHHmm", Locale.US).format(Date())
        val rand = UUID.randomUUID().toString().replace("-", "").take(6).uppercase(Locale.US)
        return "GP-$stamp-$rand"
    }

    private fun parseExpirySortableMillis(expiryDate: String): Long {
        val clean = expiryDate.trim().take(10)
        if (clean.isBlank()) return Long.MAX_VALUE
        return runCatching {
            SimpleDateFormat(DATE_ONLY_PATTERN, Locale.US).apply { isLenient = false }
                .parse(clean)?.time ?: Long.MAX_VALUE
        }.getOrElse { Long.MAX_VALUE }
    }

    private fun ensureLegacyBatchIfNeeded(batches: List<StockBatch>, item: WarehouseItem): List<StockBatch> {
        val healthySum = batches
            .filter { it.itemId == item.id && !it.isQuarantined && it.remainingMinorQty > 0L }
            .sumOf { it.remainingMinorQty }
        val missingLegacyQty = item.totalMinorQty - healthySum
        if (missingLegacyQty <= 0L) return batches
        return batches + StockBatch(
            id = newId("BCH"),
            itemId = item.id,
            warehouseId = item.warehouseId,
            batchNo = "INIT-${item.id.takeLast(6)}",
            donorName = "",
            expiryDate = item.expiryDate,
            remainingMinorQty = missingLegacyQty,
            zoneName = WarehouseConstants.ZONE_DRY,
            createdAt = nowDateTime()
        )
    }

    private fun recomputeHealthyTotal(batches: List<StockBatch>, itemId: String): Long {
        return batches
            .filter { it.itemId == itemId && !it.isQuarantined && it.remainingMinorQty > 0L }
            .sumOf { it.remainingMinorQty }
    }

    private fun earliestHealthyExpiry(batches: List<StockBatch>, itemId: String, fallback: String): String {
        return batches
            .filter { it.itemId == itemId && !it.isQuarantined && it.remainingMinorQty > 0L && it.expiryDate.isNotBlank() }
            .minByOrNull { parseExpirySortableMillis(it.expiryDate) }
            ?.expiryDate
            ?: fallback
    }

    private fun mergeOrAddBatchLocked(
        batches: List<StockBatch>,
        itemId: String,
        warehouseId: String,
        batchNo: String,
        donorName: String,
        expiryDate: String,
        addMinorQty: Long,
        zoneName: String
    ): List<StockBatch> {
        if (addMinorQty <= 0L) return batches
        val cleanBatchNo = batchNo.trim()
        val cleanDonor = donorName.trim()
        val cleanExpiry = expiryDate.trim()
        val cleanZone = zoneName.trim().ifBlank { WarehouseConstants.ZONE_DRY }

        val matchIdx = batches.indexOfFirst {
            it.itemId == itemId &&
                it.warehouseId == warehouseId &&
                it.batchNo.equals(cleanBatchNo, ignoreCase = true) &&
                it.expiryDate.trim() == cleanExpiry &&
                it.zoneName.trim() == cleanZone &&
                it.donorName.trim().equals(cleanDonor, ignoreCase = true)
        }
        return if (matchIdx >= 0) {
            batches.mapIndexed { idx, b ->
                if (idx == matchIdx) b.copy(remainingMinorQty = b.remainingMinorQty + addMinorQty) else b
            }
        } else {
            batches + StockBatch(
                id = newId("BCH"),
                itemId = itemId,
                warehouseId = warehouseId,
                batchNo = cleanBatchNo,
                donorName = cleanDonor,
                expiryDate = cleanExpiry,
                remainingMinorQty = addMinorQty,
                zoneName = cleanZone,
                createdAt = nowDateTime()
            )
        }
    }

    /**
     * خصم آلي بنظام FEFO (الأقرب انتهاءً أولاً) من التشغيلات السليمة غير المحجورة مع تتبع أرقام التشغيلات المستهلكة.
     */
    private fun deductFefoLocked(
        batches: List<StockBatch>,
        item: WarehouseItem,
        requestedMinorQty: Long,
        allowPartial: Boolean = false
    ): FefoDeductionResult {
        val prepared = ensureLegacyBatchIfNeeded(batches, item)
        val candidates = prepared
            .filter { it.itemId == item.id && !it.isQuarantined && it.remainingMinorQty > 0L }
            .sortedWith(
                compareBy<StockBatch>(
                    { parseExpirySortableMillis(it.expiryDate) },
                    { it.createdAt },
                    { it.id }
                )
            )

        val available = candidates.sumOf { it.remainingMinorQty }
        if (!allowPartial) {
            require(available >= requestedMinorQty) {
                "الرصيد المتاح (${item.formatDualQuantity()}) غير كافٍ للكمية المطلوبة ($requestedMinorQty ${item.minorUnitName})"
            }
        }

        var remainingToDeduct = requestedMinorQty.coerceAtLeast(0L)
        val deductionsByBatchId = HashMap<String, Long>()
        val consumedBatchNos = LinkedHashSet<String>()
        var earliestExpiry = ""
        var primaryDonor = ""

        for (batch in candidates) {
            if (remainingToDeduct <= 0L) break
            val take = minOf(remainingToDeduct, batch.remainingMinorQty)
            if (take > 0L) {
                deductionsByBatchId[batch.id] = take
                if (batch.batchNo.isNotBlank()) consumedBatchNos.add(batch.batchNo)
                if (earliestExpiry.isBlank() && batch.expiryDate.isNotBlank()) {
                    earliestExpiry = batch.expiryDate
                }
                if (primaryDonor.isBlank() && batch.donorName.isNotBlank()) {
                    primaryDonor = batch.donorName
                }
                remainingToDeduct -= take
            }
        }

        val deductedTotal = requestedMinorQty - remainingToDeduct
        val updatedBatches = prepared.mapNotNull { b ->
            val cut = deductionsByBatchId[b.id] ?: 0L
            if (cut <= 0L) {
                b
            } else {
                val left = (b.remainingMinorQty - cut).coerceAtLeast(0L)
                if (left > 0L) b.copy(remainingMinorQty = left) else null
            }
        }

        return FefoDeductionResult(
            updatedBatches = updatedBatches,
            deductedMinorQty = deductedTotal,
            consumedBatchNos = consumedBatchNos.toList(),
            earliestConsumedExpiry = earliestExpiry.ifBlank { item.expiryDate },
            primaryDonorName = primaryDonor
        )
    }

    /**
     * استعلامات مساعدة للتشغيلات السليمة والمحجورة وتتبع سحب التشغيلة (Batch Recall).
     */
    fun getActiveBatchesForItem(itemId: String, includeQuarantine: Boolean = true): List<StockBatch> {
        return _stateFlow.value.batches
            .filter { it.itemId == itemId && it.remainingMinorQty > 0L && (includeQuarantine || !it.isQuarantined) }
            .sortedWith(
                compareBy<StockBatch>(
                    { it.isQuarantined },
                    { parseExpirySortableMillis(it.expiryDate) },
                    { it.createdAt }
                )
            )
    }

    fun getQuarantinedBatches(warehouseId: String): List<StockBatch> {
        return _stateFlow.value.batches
            .filter { it.warehouseId == warehouseId && it.isQuarantined && it.remainingMinorQty > 0L }
            .sortedBy { parseExpirySortableMillis(it.expiryDate) }
    }

    fun findMovementsByBatchNo(batchNo: String): List<StockMovement> {
        val needle = batchNo.trim()
        if (needle.isBlank()) return emptyList()
        return _stateFlow.value.movements.filter { mov ->
            mov.batchNo.contains(needle, ignoreCase = true)
        }
    }

    /**
     * سند استلام واردات (GRN): ينشئ تشغيلة (StockBatch) بالتاريخ والمنطقة ويحسب رصيد الصنف تلقائياً من مجموع التشغيلات السليمة.
     */
    suspend fun recordStockIn(
        context: Context,
        warehouseId: String,
        itemId: String,
        majorQty: Long = 0L,
        minorQty: Long = 0L,
        supplierOrDonor: String = "",
        waybillNo: String = "",
        batchNo: String = "",
        linkedProjectId: String? = null,
        notes: String = "",
        performedBy: String = "",
        expiryDate: String = "",
        zoneName: String = WarehouseConstants.ZONE_DRY
    ): StockMovement = withContext(Dispatchers.IO) {
        val cleanLinkedProject = linkedProjectId?.trim()?.takeIf { it.isNotBlank() }
        val movement = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val item = state.items.firstOrNull { it.id == itemId && it.warehouseId == warehouseId }
                ?: throw IllegalArgumentException("الصنف غير موجود في المخزن المحدد")
            val deltaMinor = item.toMinorUnits(majorQty.coerceAtLeast(0L), minorQty.coerceAtLeast(0L))
            require(deltaMinor > 0L) { "يجب إدخال كمية واردة أكبر من صفر" }

            val effectiveBatchNo = batchNo.trim().ifBlank {
                val stamp = SimpleDateFormat("yyMMdd-HHmm", Locale.US).format(Date())
                val rnd = UUID.randomUUID().toString().replace("-", "").take(3).uppercase(Locale.US)
                "BCH-$stamp-$rnd"
            }
            val effectiveExpiry = expiryDate.trim().ifBlank { item.expiryDate }
            val effectiveZone = zoneName.trim().ifBlank { WarehouseConstants.ZONE_DRY }

            val preparedBatches = ensureLegacyBatchIfNeeded(state.batches, item)
            val nextBatches = mergeOrAddBatchLocked(
                batches = preparedBatches,
                itemId = item.id,
                warehouseId = warehouseId,
                batchNo = effectiveBatchNo,
                donorName = supplierOrDonor,
                expiryDate = effectiveExpiry,
                addMinorQty = deltaMinor,
                zoneName = effectiveZone
            )

            val recomputedTotal = recomputeHealthyTotal(nextBatches, item.id)
            val updatedItem = item.copy(
                totalMinorQty = recomputedTotal,
                expiryDate = earliestHealthyExpiry(nextBatches, item.id, effectiveExpiry),
                linkedProjectId = cleanLinkedProject ?: item.linkedProjectId
            )
            val mov = StockMovement(
                id = newId("MOV"),
                voucherNo = newVoucherNo(StockMovementType.IN),
                type = StockMovementType.IN,
                warehouseId = warehouseId,
                itemId = item.id,
                itemName = item.name,
                majorQty = majorQty.coerceAtLeast(0L),
                minorQty = minorQty.coerceAtLeast(0L),
                totalMinorDelta = if (effectiveZone == WarehouseConstants.ZONE_QUARANTINE) 0L else deltaMinor,
                supplierOrDonor = supplierOrDonor.trim(),
                waybillNo = waybillNo.trim(),
                batchNo = effectiveBatchNo,
                linkedProjectId = cleanLinkedProject ?: item.linkedProjectId,
                date = nowDateTime(),
                notes = buildString {
                    if (notes.isNotBlank()) append(notes.trim())
                    if (effectiveZone != WarehouseConstants.ZONE_DRY) {
                        if (isNotEmpty()) append(" | ")
                        append("المنطقة: $effectiveZone")
                    }
                    if (effectiveExpiry.isNotBlank()) {
                        if (isNotEmpty()) append(" | ")
                        append("الانتهاء: $effectiveExpiry")
                    }
                },
                performedBy = performedBy.trim()
            )
            commitStateLocked(
                context,
                state.copy(
                    items = state.items.map { if (it.id == item.id) updatedItem else it },
                    batches = nextBatches,
                    movements = listOf(mov) + state.movements
                )
            )
            mov
        }
        writeAuditSafe(
            context = context,
            actionType = "سند استلام واردات (GRN)",
            targetId = movement.voucherNo,
            details = "وارد ${movement.itemName}: +${movement.totalMinorDelta} وحدة صغرى | تشغيلة: ${movement.batchNo} | المورد: ${movement.supplierOrDonor}",
            performedBy = performedBy
        )
        movement
    }

    /**
     * سند إرسال صادرات (GDN): يخصم تلقائياً بنظام FEFO (الأقرب انتهاءً أولاً) ويوثق أرقام التشغيلات المستهلكة لـ Batch Recall.
     */
    suspend fun recordStockOut(
        context: Context,
        warehouseId: String,
        itemId: String,
        majorQty: Long = 0L,
        minorQty: Long = 0L,
        recipientOrProject: String = "",
        linkedProjectId: String? = null,
        driverName: String = "",
        vehiclePlate: String = "",
        notes: String = "",
        performedBy: String = ""
    ): StockMovement = withContext(Dispatchers.IO) {
        val movement = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val item = state.items.firstOrNull { it.id == itemId && it.warehouseId == warehouseId }
                ?: throw IllegalArgumentException("الصنف غير موجود في المخزن المحدد")
            val deductMinor = item.toMinorUnits(majorQty.coerceAtLeast(0L), minorQty.coerceAtLeast(0L))
            require(deductMinor > 0L) { "يجب إدخال كمية صادرة أكبر من صفر" }

            val fefo = deductFefoLocked(state.batches, item, deductMinor, allowPartial = false)
            val recomputedTotal = recomputeHealthyTotal(fefo.updatedBatches, item.id)
            val updatedItem = item.copy(
                totalMinorQty = recomputedTotal,
                expiryDate = earliestHealthyExpiry(fefo.updatedBatches, item.id, item.expiryDate)
            )
            val mov = StockMovement(
                id = newId("MOV"),
                voucherNo = newVoucherNo(StockMovementType.OUT),
                type = StockMovementType.OUT,
                warehouseId = warehouseId,
                itemId = item.id,
                itemName = item.name,
                majorQty = majorQty.coerceAtLeast(0L),
                minorQty = minorQty.coerceAtLeast(0L),
                totalMinorDelta = -fefo.deductedMinorQty,
                batchNo = fefo.consumedBatchNos.joinToString(", "),
                recipientOrProject = recipientOrProject.trim(),
                linkedProjectId = linkedProjectId?.trim()?.takeIf { it.isNotBlank() },
                driverName = driverName.trim(),
                vehiclePlate = vehiclePlate.trim(),
                date = nowDateTime(),
                notes = notes.trim(),
                performedBy = performedBy.trim()
            )
            commitStateLocked(
                context,
                state.copy(
                    items = state.items.map { if (it.id == item.id) updatedItem else it },
                    batches = fefo.updatedBatches,
                    movements = listOf(mov) + state.movements
                )
            )
            mov
        }
        writeAuditSafe(
            context = context,
            actionType = "سند إرسال صادرات (GDN)",
            targetId = movement.voucherNo,
            details = "صادر FEFO ${movement.itemName}: -${-movement.totalMinorDelta} وحدة صغرى | تشغيلات: ${movement.batchNo} | المستلم: ${movement.recipientOrProject}",
            performedBy = performedBy
        )
        movement
    }

    /**
     * مناقلة مؤمّنة بين مخزنين (In-Transit Handshake):
     * تخصم فوراً من المخزن المرسل عبر FEFO وتنشئ شحنة بحالة IN_TRANSIT مع تصريح خروج (gatePassToken)
     * دون إضافتها لرصيد المخزن المستقبل حتى يؤكد أمين المخزن المستقبل الاستلام الفعلي عبر confirmShipmentArrival.
     */
    suspend fun recordTransfer(
        context: Context,
        sourceWarehouseId: String,
        targetWarehouseId: String,
        sourceItemId: String,
        majorQty: Long = 0L,
        minorQty: Long = 0L,
        driverName: String = "",
        vehiclePlate: String = "",
        notes: String = "",
        performedBy: String = ""
    ): StockMovement = withContext(Dispatchers.IO) {
        val (movement, shipment) = synchronized(storeLock) {
            require(sourceWarehouseId != targetWarehouseId) { "لا يمكن تنفيذ مناقلة إلى نفس المخزن" }
            val state = ensureLoaded(context)
            val sourceWh = state.warehouses.firstOrNull { it.id == sourceWarehouseId }
                ?: throw IllegalArgumentException("المخزن المرسل غير موجود")
            val targetWh = state.warehouses.firstOrNull { it.id == targetWarehouseId }
                ?: throw IllegalArgumentException("المخزن المستقبل غير موجود")
            val sourceItem = state.items.firstOrNull { it.id == sourceItemId && it.warehouseId == sourceWarehouseId }
                ?: throw IllegalArgumentException("الصنف غير موجود في المخزن المرسل")

            val qtyMinor = sourceItem.toMinorUnits(majorQty.coerceAtLeast(0L), minorQty.coerceAtLeast(0L))
            require(qtyMinor > 0L) { "يجب تحديد كمية مناقلة أكبر من صفر" }

            val fefo = deductFefoLocked(state.batches, sourceItem, qtyMinor, allowPartial = false)
            val recomputedSourceTotal = recomputeHealthyTotal(fefo.updatedBatches, sourceItem.id)
            val updatedSourceItem = sourceItem.copy(
                totalMinorQty = recomputedSourceTotal,
                expiryDate = earliestHealthyExpiry(fefo.updatedBatches, sourceItem.id, sourceItem.expiryDate)
            )

            val now = nowDateTime()
            val voucher = newVoucherNo(StockMovementType.TRANSFER)
            val gatePassToken = newGatePassToken()
            val consumedBatchLabel = fefo.consumedBatchNos.joinToString(", ")

            val createdShipment = InTransitShipment(
                shipmentId = newId("SHP"),
                fromWarehouseId = sourceWarehouseId,
                toWarehouseId = targetWarehouseId,
                itemId = sourceItem.id,
                itemName = sourceItem.name,
                sentMinorQty = qtyMinor,
                driverName = driverName.trim(),
                vehiclePlate = vehiclePlate.trim(),
                status = ShipmentStatus.IN_TRANSIT,
                receivedMinorQty = 0L,
                shortageQty = 0L,
                gatePassToken = gatePassToken,
                voucherNo = voucher,
                batchNo = consumedBatchLabel,
                expiryDate = fefo.earliestConsumedExpiry,
                donorName = fefo.primaryDonorName,
                category = sourceItem.category,
                majorUnitName = sourceItem.majorUnitName,
                minorUnitName = sourceItem.minorUnitName,
                conversionFactor = sourceItem.safeConversionFactor,
                sentAt = now,
                confirmedAt = "",
                notes = notes.trim().ifBlank { "مناقلة من ${sourceWh.name} إلى ${targetWh.name}" },
                performedBy = performedBy.trim()
            )

            val mov = StockMovement(
                id = newId("MOV"),
                voucherNo = voucher,
                type = StockMovementType.TRANSFER,
                warehouseId = sourceWarehouseId,
                targetWarehouseId = targetWarehouseId,
                itemId = sourceItem.id,
                itemName = sourceItem.name,
                majorQty = majorQty.coerceAtLeast(0L),
                minorQty = minorQty.coerceAtLeast(0L),
                totalMinorDelta = -qtyMinor,
                waybillNo = gatePassToken,
                batchNo = consumedBatchLabel,
                recipientOrProject = targetWh.name,
                driverName = driverName.trim(),
                vehiclePlate = vehiclePlate.trim(),
                date = now,
                notes = buildString {
                    append(notes.trim().ifBlank { "مناقلة في الطريق من ${sourceWh.name} إلى ${targetWh.name}" })
                    append(" | تصريح خروج: $gatePassToken | شحنة: ${createdShipment.shipmentId}")
                },
                performedBy = performedBy.trim()
            )

            commitStateLocked(
                context,
                state.copy(
                    items = state.items.map { if (it.id == sourceItem.id) updatedSourceItem else it },
                    batches = fefo.updatedBatches,
                    movements = listOf(mov) + state.movements,
                    inTransitShipments = listOf(createdShipment) + state.inTransitShipments
                )
            )
            mov to createdShipment
        }
        writeAuditSafe(
            context = context,
            actionType = "مناقلة مخزنية (في الطريق)",
            targetId = movement.voucherNo,
            details = "شحنة ${shipment.shipmentId} | ${movement.itemName}: ${shipment.sentMinorQty} وحدة صغرى إلى ${movement.recipientOrProject} | تصريح: ${shipment.gatePassToken}",
            performedBy = performedBy
        )
        movement
    }

    /**
     * تأكيد وصول الشحنة في المخزن المستقبل (In-Transit Handshake):
     * يُضيف الكمية المستلمة فعلياً لرصيد المخزن المستقبل مع إنشاء تشغيلة،
     * وفي حال كانت الكمية المستلمة أقل من المرسلة يصدر «محضر عجز نقل» مختوم بـ SHA-256 في TamperProofAuditLog.
     */
    suspend fun confirmShipmentArrival(
        context: Context,
        shipmentId: String,
        actualReceivedMinorQty: Long,
        notes: String = "",
        performedBy: String = ""
    ): InTransitShipment = withContext(Dispatchers.IO) {
        val now = nowDateTime()
        val (updatedShipment, fromWhName, toWhName) = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val shipment = state.inTransitShipments.firstOrNull { it.shipmentId == shipmentId }
                ?: throw IllegalArgumentException("الشحنة المطلوبة غير موجودة")
            require(shipment.status == ShipmentStatus.IN_TRANSIT) {
                "تم تأكيد هذه الشحنة مسبقاً (${shipment.status.arabicLabel})"
            }
            require(actualReceivedMinorQty >= 0L) { "الكمية المستلمة لا يمكن أن تكون سالبة" }
            require(actualReceivedMinorQty <= shipment.sentMinorQty) {
                "الكمية المستلمة ($actualReceivedMinorQty) تتجاوز الكمية المرسلة (${shipment.sentMinorQty})"
            }

            val fromWh = state.warehouses.firstOrNull { it.id == shipment.fromWarehouseId }
            val toWh = state.warehouses.firstOrNull { it.id == shipment.toWarehouseId }
            val sourceName = fromWh?.name ?: shipment.fromWarehouseId
            val targetName = toWh?.name ?: shipment.toWarehouseId

            val shortage = (shipment.sentMinorQty - actualReceivedMinorQty).coerceAtLeast(0L)
            val finalStatus = if (shortage > 0L) ShipmentStatus.SHORTAGE_REPORTED else ShipmentStatus.CONFIRMED

            val existingTargetItem = state.items.firstOrNull {
                it.warehouseId == shipment.toWarehouseId &&
                    it.name.trim().equals(shipment.itemName.trim(), ignoreCase = true) &&
                    it.minorUnitName.trim().equals(shipment.minorUnitName.trim(), ignoreCase = true)
            }
            val targetItem = existingTargetItem ?: WarehouseItem(
                id = newId("ITM"),
                warehouseId = shipment.toWarehouseId,
                name = shipment.itemName,
                category = shipment.category,
                majorUnitName = shipment.majorUnitName,
                minorUnitName = shipment.minorUnitName,
                conversionFactor = shipment.conversionFactor.coerceAtLeast(1),
                totalMinorQty = 0L,
                minThreshold = 0L,
                expiryDate = shipment.expiryDate
            )

            val preparedBatches = if (existingTargetItem != null) {
                ensureLegacyBatchIfNeeded(state.batches, existingTargetItem)
            } else {
                state.batches
            }

            val arrivalBatchNo = shipment.batchNo.trim().ifBlank { "TRF-${shipment.shipmentId.takeLast(6)}" }
            val nextBatches = if (actualReceivedMinorQty > 0L) {
                mergeOrAddBatchLocked(
                    batches = preparedBatches,
                    itemId = targetItem.id,
                    warehouseId = shipment.toWarehouseId,
                    batchNo = arrivalBatchNo,
                    donorName = shipment.donorName.ifBlank { sourceName },
                    expiryDate = shipment.expiryDate,
                    addMinorQty = actualReceivedMinorQty,
                    zoneName = WarehouseConstants.ZONE_DRY
                )
            } else {
                preparedBatches
            }

            val recomputedTargetTotal = recomputeHealthyTotal(nextBatches, targetItem.id)
            val finalTargetItem = targetItem.copy(
                totalMinorQty = recomputedTargetTotal,
                expiryDate = earliestHealthyExpiry(nextBatches, targetItem.id, shipment.expiryDate)
            )
            val nextItems = if (existingTargetItem != null) {
                state.items.map { if (it.id == existingTargetItem.id) finalTargetItem else it }
            } else {
                state.items + finalTargetItem
            }

            val arrivalMov = StockMovement(
                id = newId("MOV"),
                voucherNo = if (actualReceivedMinorQty > 0L) {
                    newVoucherNo(StockMovementType.IN)
                } else {
                    newCustomVoucherNo("SHRT")
                },
                type = if (actualReceivedMinorQty > 0L) StockMovementType.IN else StockMovementType.AUDIT_ADJUST,
                warehouseId = shipment.toWarehouseId,
                targetWarehouseId = shipment.fromWarehouseId,
                itemId = finalTargetItem.id,
                itemName = finalTargetItem.name,
                majorQty = actualReceivedMinorQty / finalTargetItem.safeConversionFactor.toLong(),
                minorQty = actualReceivedMinorQty % finalTargetItem.safeConversionFactor.toLong(),
                totalMinorDelta = actualReceivedMinorQty,
                supplierOrDonor = sourceName,
                waybillNo = shipment.gatePassToken,
                batchNo = arrivalBatchNo,
                driverName = shipment.driverName,
                vehiclePlate = shipment.vehiclePlate,
                date = now,
                notes = buildString {
                    append("تأكيد استلام شحنة #${shipment.shipmentId} من $sourceName (المرسل=${shipment.sentMinorQty}، المستلم=$actualReceivedMinorQty")
                    if (shortage > 0L) append("، محضر عجز نقل=$shortage")
                    append(")")
                    if (notes.isNotBlank()) append(" | ${notes.trim()}")
                },
                performedBy = performedBy.trim()
            )

            val confirmedShipment = shipment.copy(
                status = finalStatus,
                receivedMinorQty = actualReceivedMinorQty,
                shortageQty = shortage,
                confirmedAt = now,
                notes = listOf(shipment.notes, notes.trim()).filter { it.isNotBlank() }.joinToString(" | ")
            )

            commitStateLocked(
                context,
                state.copy(
                    items = nextItems,
                    batches = nextBatches,
                    movements = listOf(arrivalMov) + state.movements,
                    inTransitShipments = state.inTransitShipments.map {
                        if (it.shipmentId == shipmentId) confirmedShipment else it
                    }
                )
            )
            Triple(confirmedShipment, sourceName, targetName)
        }

        if (updatedShipment.shortageQty > 0L) {
            val auditRecord = runCatching {
                TamperProofAuditLog.logEvent(
                    context = context,
                    actionType = "محضر عجز نقل",
                    targetId = updatedShipment.shipmentId,
                    details = buildString {
                        append("عجز نقل في الشحنة ${updatedShipment.shipmentId} (${updatedShipment.itemName}) ")
                        append("من $fromWhName إلى $toWhName | المرسل=${updatedShipment.sentMinorQty} | ")
                        append("المستلم=${updatedShipment.receivedMinorQty} | العجز=${updatedShipment.shortageQty} | ")
                        append("السائق: ${updatedShipment.driverName} (${updatedShipment.vehiclePlate}) | تصريح: ${updatedShipment.gatePassToken}")
                        if (notes.isNotBlank()) append(" | ملاحظة: ${notes.trim()}")
                    },
                    performedBy = performedBy.ifBlank { "أمين المخزن المستقبل" }
                )
            }.getOrNull()

            if (auditRecord != null && auditRecord.entryHash.isNotBlank()) {
                val withHash = synchronized(storeLock) {
                    val state = ensureLoaded(context)
                    val stamped = updatedShipment.copy(shortageAuditHash = auditRecord.entryHash)
                    commitStateLocked(
                        context,
                        state.copy(
                            inTransitShipments = state.inTransitShipments.map {
                                if (it.shipmentId == shipmentId) stamped else it
                            }
                        )
                    )
                    stamped
                }
                return@withContext withHash
            }
        } else {
            writeAuditSafe(
                context = context,
                actionType = "تأكيد استلام مناقلة",
                targetId = updatedShipment.shipmentId,
                details = "استلام كامل شحنة ${updatedShipment.itemName} (${updatedShipment.receivedMinorQty} وحدة صغرى) في $toWhName من $fromWhName",
                performedBy = performedBy
            )
        }
        updatedShipment
    }

    /**
     * تجميع مكونات في طرود جاهزة (KIT_ASSEMBLE) مع تحديث التشغيلات بنظام FEFO.
     */
    suspend fun assembleKit(
        context: Context,
        warehouseId: String,
        targetKitItemId: String,
        kitsCount: Long,
        components: List<KitComponentSpec>,
        notes: String = "",
        performedBy: String = ""
    ): StockMovement = withContext(Dispatchers.IO) {
        val movement = synchronized(storeLock) {
            require(kitsCount > 0L) { "يجب تحديد عدد طرود أكبر من صفر" }
            require(components.isNotEmpty()) { "يجب تحديد مكون واحد على الأقل للتجميع" }
            val state = ensureLoaded(context)
            val kitItem = state.items.firstOrNull { it.id == targetKitItemId && it.warehouseId == warehouseId }
                ?: throw IllegalArgumentException("صنف الطرد المستهدف غير موجود في المخزن")

            val requiredById = HashMap<String, Long>()
            for (spec in components) {
                require(spec.minorQtyPerKit > 0L) { "كمية المكون لكل طرد يجب أن تكون أكبر من صفر" }
                val comp = state.items.firstOrNull { it.id == spec.componentItemId && it.warehouseId == warehouseId }
                    ?: throw IllegalArgumentException("أحد المكونات غير موجود في المخزن")
                val totalNeeded = (requiredById[comp.id] ?: 0L) + (spec.minorQtyPerKit * kitsCount)
                require(comp.totalMinorQty >= totalNeeded) {
                    "رصيد المكون «${comp.name}» غير كافٍ (المتاح: ${comp.totalMinorQty}، المطلوب: $totalNeeded)"
                }
                requiredById[comp.id] = totalNeeded
            }

            var workingBatches = ensureLegacyBatchIfNeeded(state.batches, kitItem)
            val consumedBatchMap = HashMap<String, String>()
            requiredById.forEach { (compId, usedQty) ->
                val comp = state.items.first { it.id == compId }
                val fefo = deductFefoLocked(workingBatches, comp, usedQty, allowPartial = false)
                workingBatches = fefo.updatedBatches
                consumedBatchMap[compId] = fefo.consumedBatchNos.joinToString(", ")
            }

            val voucher = newVoucherNo(StockMovementType.KIT_ASSEMBLE)
            val kitBatchNo = "KIT-${voucher.takeLast(6)}"
            workingBatches = mergeOrAddBatchLocked(
                batches = workingBatches,
                itemId = kitItem.id,
                warehouseId = warehouseId,
                batchNo = kitBatchNo,
                donorName = "",
                expiryDate = kitItem.expiryDate,
                addMinorQty = kitsCount,
                zoneName = WarehouseConstants.ZONE_DRY
            )

            val updatedItems = state.items.map { item ->
                when {
                    item.id == kitItem.id -> item.copy(
                        totalMinorQty = recomputeHealthyTotal(workingBatches, item.id),
                        expiryDate = earliestHealthyExpiry(workingBatches, item.id, item.expiryDate)
                    )
                    requiredById.containsKey(item.id) -> item.copy(
                        totalMinorQty = recomputeHealthyTotal(workingBatches, item.id),
                        expiryDate = earliestHealthyExpiry(workingBatches, item.id, item.expiryDate)
                    )
                    else -> item
                }
            }

            val now = nowDateTime()
            val newMovements = ArrayList<StockMovement>()
            val mainMov = StockMovement(
                id = newId("MOV"),
                voucherNo = voucher,
                type = StockMovementType.KIT_ASSEMBLE,
                warehouseId = warehouseId,
                itemId = kitItem.id,
                itemName = kitItem.name,
                minorQty = kitsCount,
                totalMinorDelta = kitsCount,
                batchNo = kitBatchNo,
                date = now,
                notes = notes.trim().ifBlank { "تجميع $kitsCount طرد من ${components.size} مكونات" },
                performedBy = performedBy.trim()
            )
            newMovements.add(mainMov)
            requiredById.forEach { (compId, usedQty) ->
                val comp = state.items.first { it.id == compId }
                newMovements.add(
                    StockMovement(
                        id = newId("MOV"),
                        voucherNo = voucher,
                        type = StockMovementType.KIT_ASSEMBLE,
                        warehouseId = warehouseId,
                        itemId = comp.id,
                        itemName = comp.name,
                        minorQty = usedQty,
                        totalMinorDelta = -usedQty,
                        batchNo = consumedBatchMap[compId].orEmpty(),
                        date = now,
                        notes = "سحب مكون لتجميع $kitsCount × ${kitItem.name}",
                        performedBy = performedBy.trim()
                    )
                )
            }

            commitStateLocked(
                context,
                state.copy(
                    items = updatedItems,
                    batches = workingBatches,
                    movements = newMovements + state.movements
                )
            )
            mainMov
        }
        writeAuditSafe(
            context = context,
            actionType = "تجميع طرود (Kit)",
            targetId = movement.voucherNo,
            details = "تجميع +${movement.totalMinorDelta} من ${movement.itemName}",
            performedBy = performedBy
        )
        movement
    }

    /**
     * تفكيك طرود جاهزة وإرجاع مكوناتها إلى المخزون (KIT_UNBUNDLE) مع تحديث التشغيلات.
     */
    suspend fun unbundleKit(
        context: Context,
        warehouseId: String,
        sourceKitItemId: String,
        kitsCount: Long,
        components: List<KitComponentSpec>,
        notes: String = "",
        performedBy: String = ""
    ): StockMovement = withContext(Dispatchers.IO) {
        val movement = synchronized(storeLock) {
            require(kitsCount > 0L) { "يجب تحديد عدد طرود للتفكيك أكبر من صفر" }
            require(components.isNotEmpty()) { "يجب تحديد مكون واحد على الأقل للتفكيك" }
            val state = ensureLoaded(context)
            val kitItem = state.items.firstOrNull { it.id == sourceKitItemId && it.warehouseId == warehouseId }
                ?: throw IllegalArgumentException("صنف الطرد غير موجود في المخزن")
            require(kitItem.totalMinorQty >= kitsCount) {
                "رصيد الطرود المتاح (${kitItem.totalMinorQty}) غير كافٍ لتفكيك $kitsCount"
            }

            val restoreById = HashMap<String, Long>()
            for (spec in components) {
                require(spec.minorQtyPerKit > 0L) { "كمية المكون لكل طرد يجب أن تكون أكبر من صفر" }
                val comp = state.items.firstOrNull { it.id == spec.componentItemId && it.warehouseId == warehouseId }
                    ?: throw IllegalArgumentException("أحد المكونات غير موجود في المخزن")
                restoreById[comp.id] = (restoreById[comp.id] ?: 0L) + (spec.minorQtyPerKit * kitsCount)
            }

            val kitFefo = deductFefoLocked(state.batches, kitItem, kitsCount, allowPartial = false)
            var workingBatches = kitFefo.updatedBatches
            val voucher = newVoucherNo(StockMovementType.KIT_UNBUNDLE)
            val restoreBatchNo = "UNB-${voucher.takeLast(6)}"

            restoreById.forEach { (compId, restoredQty) ->
                val comp = state.items.first { it.id == compId }
                workingBatches = ensureLegacyBatchIfNeeded(workingBatches, comp)
                workingBatches = mergeOrAddBatchLocked(
                    batches = workingBatches,
                    itemId = comp.id,
                    warehouseId = warehouseId,
                    batchNo = restoreBatchNo,
                    donorName = "",
                    expiryDate = comp.expiryDate,
                    addMinorQty = restoredQty,
                    zoneName = WarehouseConstants.ZONE_DRY
                )
            }

            val updatedItems = state.items.map { item ->
                when {
                    item.id == kitItem.id -> item.copy(
                        totalMinorQty = recomputeHealthyTotal(workingBatches, item.id),
                        expiryDate = earliestHealthyExpiry(workingBatches, item.id, item.expiryDate)
                    )
                    restoreById.containsKey(item.id) -> item.copy(
                        totalMinorQty = recomputeHealthyTotal(workingBatches, item.id),
                        expiryDate = earliestHealthyExpiry(workingBatches, item.id, item.expiryDate)
                    )
                    else -> item
                }
            }

            val now = nowDateTime()
            val newMovements = ArrayList<StockMovement>()
            val mainMov = StockMovement(
                id = newId("MOV"),
                voucherNo = voucher,
                type = StockMovementType.KIT_UNBUNDLE,
                warehouseId = warehouseId,
                itemId = kitItem.id,
                itemName = kitItem.name,
                minorQty = kitsCount,
                totalMinorDelta = -kitsCount,
                batchNo = kitFefo.consumedBatchNos.joinToString(", "),
                date = now,
                notes = notes.trim().ifBlank { "تفكيك $kitsCount طرد وإرجاع المكونات" },
                performedBy = performedBy.trim()
            )
            newMovements.add(mainMov)
            restoreById.forEach { (compId, restoredQty) ->
                val comp = state.items.first { it.id == compId }
                newMovements.add(
                    StockMovement(
                        id = newId("MOV"),
                        voucherNo = voucher,
                        type = StockMovementType.KIT_UNBUNDLE,
                        warehouseId = warehouseId,
                        itemId = comp.id,
                        itemName = comp.name,
                        minorQty = restoredQty,
                        totalMinorDelta = restoredQty,
                        batchNo = restoreBatchNo,
                        date = now,
                        notes = "إرجاع مكون من تفكيك $kitsCount × ${kitItem.name}",
                        performedBy = performedBy.trim()
                    )
                )
            }

            commitStateLocked(
                context,
                state.copy(
                    items = updatedItems,
                    batches = workingBatches,
                    movements = newMovements + state.movements
                )
            )
            mainMov
        }
        writeAuditSafe(
            context = context,
            actionType = "تفكيك طرود (Unbundle)",
            targetId = movement.voucherNo,
            details = "تفكيك ${-movement.totalMinorDelta} من ${movement.itemName}",
            performedBy = performedBy
        )
        movement
    }

    /**
     * خصم آلي مرتبط بشاشة تسليم المساعدات (DELIVERY_DEDUCT) بنظام FEFO مع توثيق رقم التشغيلة المستهلكة لـ Batch Recall.
     */
    suspend fun recordDeliveryDeduction(
        context: Context,
        projectId: String,
        unitsCount: Long = 1L,
        beneficiaryRef: String = "",
        performedBy: String = ""
    ): StockMovement? = withContext(Dispatchers.IO) {
        val cleanProjId = projectId.trim()
        if (cleanProjId.isBlank() || unitsCount <= 0L) return@withContext null

        val movement = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val linkedItem = state.items.firstOrNull { it.linkedProjectId == cleanProjId }
                ?: return@synchronized null

            val fefo = deductFefoLocked(state.batches, linkedItem, unitsCount, allowPartial = true)
            val nextQty = recomputeHealthyTotal(fefo.updatedBatches, linkedItem.id)
            val mov = StockMovement(
                id = newId("MOV"),
                voucherNo = newVoucherNo(StockMovementType.DELIVERY_DEDUCT),
                type = StockMovementType.DELIVERY_DEDUCT,
                warehouseId = linkedItem.warehouseId,
                itemId = linkedItem.id,
                itemName = linkedItem.name,
                minorQty = unitsCount,
                totalMinorDelta = -fefo.deductedMinorQty,
                batchNo = fefo.consumedBatchNos.joinToString(", "),
                recipientOrProject = beneficiaryRef.trim(),
                linkedProjectId = cleanProjId,
                date = nowDateTime(),
                notes = "خصم آلي FEFO مرتبط بتسليم مساعدة للمشروع #$cleanProjId",
                performedBy = performedBy.trim()
            )
            commitStateLocked(
                context,
                state.copy(
                    items = state.items.map {
                        if (it.id == linkedItem.id) {
                            it.copy(
                                totalMinorQty = nextQty,
                                expiryDate = earliestHealthyExpiry(fefo.updatedBatches, linkedItem.id, it.expiryDate)
                            )
                        } else it
                    },
                    batches = fefo.updatedBatches,
                    movements = listOf(mov) + state.movements
                )
            )
            mov
        }
        if (movement != null) {
            writeAuditSafe(
                context = context,
                actionType = "خصم تسليم مخزني آلي",
                targetId = movement.voucherNo,
                details = "خصم FEFO ${-movement.totalMinorDelta} من ${movement.itemName} (تشغيلة: ${movement.batchNo} | المشروع #$cleanProjId)",
                performedBy = performedBy
            )
        }
        movement
    }

    /**
     * إرجاع آلي مرتبط بالتراجع عن التسليم في شاشة التسليم (DELIVERY_RESTORE) مع تحديث التشغيلات.
     */
    suspend fun recordDeliveryRestore(
        context: Context,
        projectId: String,
        unitsCount: Long = 1L,
        beneficiaryRef: String = "",
        performedBy: String = ""
    ): StockMovement? = withContext(Dispatchers.IO) {
        val cleanProjId = projectId.trim()
        if (cleanProjId.isBlank() || unitsCount <= 0L) return@withContext null

        val movement = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val linkedItem = state.items.firstOrNull { it.linkedProjectId == cleanProjId }
                ?: return@synchronized null

            val preparedBatches = ensureLegacyBatchIfNeeded(state.batches, linkedItem)
            val latestHealthyBatch = preparedBatches
                .filter { it.itemId == linkedItem.id && !it.isQuarantined && it.remainingMinorQty > 0L }
                .minByOrNull { parseExpirySortableMillis(it.expiryDate) }

            val restoreBatchNo = latestHealthyBatch?.batchNo ?: "RET-${linkedItem.id.takeLast(6)}"
            val nextBatches = mergeOrAddBatchLocked(
                batches = preparedBatches,
                itemId = linkedItem.id,
                warehouseId = linkedItem.warehouseId,
                batchNo = restoreBatchNo,
                donorName = latestHealthyBatch?.donorName.orEmpty(),
                expiryDate = latestHealthyBatch?.expiryDate ?: linkedItem.expiryDate,
                addMinorQty = unitsCount,
                zoneName = latestHealthyBatch?.zoneName ?: WarehouseConstants.ZONE_DRY
            )
            val nextQty = recomputeHealthyTotal(nextBatches, linkedItem.id)
            val mov = StockMovement(
                id = newId("MOV"),
                voucherNo = newVoucherNo(StockMovementType.DELIVERY_RESTORE),
                type = StockMovementType.DELIVERY_RESTORE,
                warehouseId = linkedItem.warehouseId,
                itemId = linkedItem.id,
                itemName = linkedItem.name,
                minorQty = unitsCount,
                totalMinorDelta = unitsCount,
                batchNo = restoreBatchNo,
                recipientOrProject = beneficiaryRef.trim(),
                linkedProjectId = cleanProjId,
                date = nowDateTime(),
                notes = "إرجاع آلي نتيجة التراجع عن تسليم مساعدة للمشروع #$cleanProjId",
                performedBy = performedBy.trim()
            )
            commitStateLocked(
                context,
                state.copy(
                    items = state.items.map { if (it.id == linkedItem.id) it.copy(totalMinorQty = nextQty) else it },
                    batches = nextBatches,
                    movements = listOf(mov) + state.movements
                )
            )
            mov
        }
        if (movement != null) {
            writeAuditSafe(
                context = context,
                actionType = "إرجاع تسليم مخزني آلي",
                targetId = movement.voucherNo,
                details = "إرجاع +${movement.totalMinorDelta} إلى ${movement.itemName} (المشروع #$cleanProjId)",
                performedBy = performedBy
            )
        }
        movement
    }

    /**
     * واجهة مختصرة للخصم الآلي من المخزن عند تأكيد التسليم في DeliveryScreen.kt
     */
    suspend fun deductForDelivery(
        context: Context,
        projectId: String,
        unitsCount: Long = 1L,
        beneficiaryRef: String = "",
        performedBy: String = ""
    ): StockMovement? = recordDeliveryDeduction(
        context = context,
        projectId = projectId,
        unitsCount = unitsCount,
        beneficiaryRef = beneficiaryRef,
        performedBy = performedBy
    )

    /**
     * واجهة مختصرة للإرجاع الآلي إلى المخزن عند التراجع عن التسليم في DeliveryScreen.kt
     */
    suspend fun restoreFromDelivery(
        context: Context,
        projectId: String,
        unitsCount: Long = 1L,
        beneficiaryRef: String = "",
        performedBy: String = ""
    ): StockMovement? = recordDeliveryRestore(
        context = context,
        projectId = projectId,
        unitsCount = unitsCount,
        beneficiaryRef = beneficiaryRef,
        performedBy = performedBy
    )

    private fun syncBatchesToAuditVarianceLocked(
        batches: List<StockBatch>,
        item: WarehouseItem,
        variance: Long
    ): List<StockBatch> {
        var working = ensureLegacyBatchIfNeeded(batches, item)
        if (variance < 0L) {
            working = deductFefoLocked(working, item, -variance, allowPartial = true).updatedBatches
        } else if (variance > 0L) {
            working = mergeOrAddBatchLocked(
                batches = working,
                itemId = item.id,
                warehouseId = item.warehouseId,
                batchNo = "AUD-${SimpleDateFormat("yyMMdd", Locale.US).format(Date())}",
                donorName = "تسوية جرد",
                expiryDate = item.expiryDate,
                addMinorQty = variance,
                zoneName = WarehouseConstants.ZONE_DRY
            )
        }
        return working
    }

    /**
     * تسوية الجرد الأعمى (AUDIT_ADJUST): مقارنة العد الفعلي بالرصيد الدفتري وتطبيق التسوية على التشغيلات.
     */
    suspend fun applyBlindAuditAdjustment(
        context: Context,
        warehouseId: String,
        itemId: String,
        countedMajorQty: Long,
        countedMinorQty: Long,
        reason: String,
        performedBy: String = ""
    ): BlindAuditVarianceResult = withContext(Dispatchers.IO) {
        val result = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val item = state.items.firstOrNull { it.id == itemId && it.warehouseId == warehouseId }
                ?: throw IllegalArgumentException("الصنف غير موجود في المخزن")
            val systemQty = item.totalMinorQty
            val countedTotal = item.toMinorUnits(countedMajorQty.coerceAtLeast(0L), countedMinorQty.coerceAtLeast(0L))
            val variance = countedTotal - systemQty
            val nextBatches = syncBatchesToAuditVarianceLocked(state.batches, item, variance)

            val mov = StockMovement(
                id = newId("MOV"),
                voucherNo = newVoucherNo(StockMovementType.AUDIT_ADJUST),
                type = StockMovementType.AUDIT_ADJUST,
                warehouseId = warehouseId,
                itemId = item.id,
                itemName = item.name,
                majorQty = countedMajorQty.coerceAtLeast(0L),
                minorQty = countedMinorQty.coerceAtLeast(0L),
                totalMinorDelta = variance,
                date = nowDateTime(),
                notes = buildString {
                    append("جرد أعمى: الدفتري=$systemQty، الفعلي=$countedTotal، الفارق=${if (variance >= 0) "+$variance" else "$variance"}")
                    if (reason.isNotBlank()) append(" | السبب: ${reason.trim()}")
                },
                performedBy = performedBy.trim()
            )
            commitStateLocked(
                context,
                state.copy(
                    items = state.items.map { if (it.id == item.id) it.copy(totalMinorQty = countedTotal) else it },
                    batches = nextBatches,
                    movements = listOf(mov) + state.movements
                )
            )
            BlindAuditVarianceResult(
                itemId = item.id,
                itemName = item.name,
                systemMinorQty = systemQty,
                countedMinorQty = countedTotal,
                varianceMinorQty = variance,
                movement = mov
            )
        }
        writeAuditSafe(
            context = context,
            actionType = "تسوية جرد أعمى",
            targetId = result.movement.voucherNo,
            details = "${result.itemName}: دفتري=${result.systemMinorQty}، فعلي=${result.countedMinorQty}، فارق=${result.varianceMinorQty}",
            performedBy = performedBy
        )
        result
    }

    /**
     * اعتماد محضر الجرد الأعمى الجماعي للمخزن بالكامل مع تسوية كافة الأصناف والتشغيلات وتوثيق المحضر
     * في TamperProofAuditLog وإرجاع بصمة SHA-256 المعتمدة.
     */
    suspend fun applyBatchBlindAudit(
        context: Context,
        warehouseId: String,
        entries: List<BlindAuditItemInput>,
        reason: String,
        performedBy: String = ""
    ): BlindAuditBatchReport = withContext(Dispatchers.IO) {
        require(entries.isNotEmpty()) { "لا توجد أصناف مدخلة للجرد" }
        val nowStamp = nowDateTime()
        val (warehouseName, results) = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val wh = state.warehouses.firstOrNull { it.id == warehouseId }
            val whName = wh?.name ?: warehouseId

            val itemMap = state.items.filter { it.warehouseId == warehouseId }.associateBy { it.id }
            val varianceResults = ArrayList<BlindAuditVarianceResult>()
            val newQtyByItemId = HashMap<String, Long>()
            val createdMovements = ArrayList<StockMovement>()
            var workingBatches = state.batches

            for (entry in entries) {
                val item = itemMap[entry.itemId] ?: continue
                val systemQty = item.totalMinorQty
                val countedTotal = item.toMinorUnits(
                    entry.countedMajorQty.coerceAtLeast(0L),
                    entry.countedMinorQty.coerceAtLeast(0L)
                )
                val variance = countedTotal - systemQty
                workingBatches = syncBatchesToAuditVarianceLocked(workingBatches, item, variance)
                val mov = StockMovement(
                    id = newId("MOV"),
                    voucherNo = newVoucherNo(StockMovementType.AUDIT_ADJUST),
                    type = StockMovementType.AUDIT_ADJUST,
                    warehouseId = warehouseId,
                    itemId = item.id,
                    itemName = item.name,
                    majorQty = entry.countedMajorQty.coerceAtLeast(0L),
                    minorQty = entry.countedMinorQty.coerceAtLeast(0L),
                    totalMinorDelta = variance,
                    date = nowStamp,
                    notes = buildString {
                        append("جرد أعمى: الدفتري=$systemQty، الفعلي=$countedTotal، الفارق=${if (variance >= 0) "+$variance" else "$variance"}")
                        if (reason.isNotBlank()) append(" | السبب: ${reason.trim()}")
                    },
                    performedBy = performedBy.trim()
                )
                newQtyByItemId[item.id] = countedTotal
                createdMovements.add(mov)
                varianceResults.add(
                    BlindAuditVarianceResult(
                        itemId = item.id,
                        itemName = item.name,
                        systemMinorQty = systemQty,
                        countedMinorQty = countedTotal,
                        varianceMinorQty = variance,
                        movement = mov
                    )
                )
            }

            require(varianceResults.isNotEmpty()) { "لم يتم العثور على أصناف مطابقة داخل المخزن" }

            val updatedItems = state.items.map { item ->
                val adjusted = newQtyByItemId[item.id]
                if (adjusted != null) item.copy(totalMinorQty = adjusted) else item
            }

            commitStateLocked(
                context,
                state.copy(
                    items = updatedItems,
                    batches = workingBatches,
                    movements = createdMovements + state.movements
                )
            )
            whName to varianceResults
        }

        val deficitCount = results.count { it.varianceMinorQty < 0L }
        val surplusCount = results.count { it.varianceMinorQty > 0L }
        val matchedCount = results.count { it.varianceMinorQty == 0L }
        val detailsSummary = buildString {
            append("محضر جرد أعمى للمخزن: $warehouseName | أصناف=${results.size} (مطابق=$matchedCount، عجز=$deficitCount، زيادة=$surplusCount)")
            if (reason.isNotBlank()) append(" | الملاحظة: ${reason.trim()}")
        }

        val auditRecord = runCatching {
            TamperProofAuditLog.logEvent(
                context = context,
                actionType = "تسوية جرد أعمى",
                targetId = warehouseId,
                details = detailsSummary,
                performedBy = performedBy.ifBlank { "لجنة الجرد" }
            )
        }.getOrNull()

        BlindAuditBatchReport(
            warehouseId = warehouseId,
            warehouseName = warehouseName,
            auditedAt = nowStamp,
            performedBy = performedBy.ifBlank { "لجنة الجرد" },
            reason = reason.trim(),
            results = results,
            auditRecordId = auditRecord?.id ?: "",
            auditEntryHash = auditRecord?.entryHash ?: ""
        )
    }

    /**
     * نقل كمية تالفة أو مشكوك بصلاحيتها إلى «الحجر الصحي» (استبعاد من الرصيد الصالح) أو إتلافها رسمياً (محضر إتلاف).
     */
    suspend fun moveToQuarantineOrDispose(
        context: Context,
        itemId: String,
        batchNo: String,
        minorQty: Long,
        reason: String,
        isDisposed: Boolean,
        performedBy: String = ""
    ): StockMovement = withContext(Dispatchers.IO) {
        require(minorQty > 0L) { "يجب تحديد كمية أكبر من صفر" }
        require(reason.isNotBlank()) { "يجب كتابة سبب النقل للحجر الصحي أو الإتلاف" }

        val movement = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val item = state.items.firstOrNull { it.id == itemId }
                ?: throw IllegalArgumentException("الصنف غير موجود")

            val prepared = ensureLegacyBatchIfNeeded(state.batches, item)
            val cleanBatchNo = batchNo.trim()

            // في حالة الإتلاف ندعم الإتلاف من تشغيلة سليمة أو من تشغيلة موجودة مسبقاً في الحجر الصحي
            var workingBatches = prepared
            var effectiveBatchLabel = cleanBatchNo
            var effectiveExpiry = item.expiryDate
            var effectiveDonor = ""
            var deductedFromUsable = true

            if (cleanBatchNo.isNotBlank()) {
                val healthyMatch = prepared.firstOrNull {
                    it.itemId == item.id && !it.isQuarantined &&
                        it.batchNo.equals(cleanBatchNo, ignoreCase = true) && it.remainingMinorQty > 0L
                }
                val quarantineMatch = if (healthyMatch == null && isDisposed) {
                    prepared.firstOrNull {
                        it.itemId == item.id && it.isQuarantined &&
                            it.batchNo.equals(cleanBatchNo, ignoreCase = true) && it.remainingMinorQty > 0L
                    }
                } else null

                val targetBatch = healthyMatch ?: quarantineMatch
                    ?: throw IllegalArgumentException("التشغيلة ($cleanBatchNo) غير موجودة أو رصيدها غير كافٍ")

                require(targetBatch.remainingMinorQty >= minorQty) {
                    "رصيد التشغيلة ${targetBatch.batchNo} (${targetBatch.remainingMinorQty}) غير كافٍ للكمية المطلوبة ($minorQty)"
                }
                deductedFromUsable = !targetBatch.isQuarantined
                effectiveBatchLabel = targetBatch.batchNo
                effectiveExpiry = targetBatch.expiryDate
                effectiveDonor = targetBatch.donorName

                workingBatches = prepared.mapNotNull { b ->
                    if (b.id != targetBatch.id) {
                        b
                    } else {
                        val rem = (b.remainingMinorQty - minorQty).coerceAtLeast(0L)
                        if (rem > 0L) b.copy(remainingMinorQty = rem) else null
                    }
                }
            } else {
                val fefo = deductFefoLocked(prepared, item, minorQty, allowPartial = false)
                workingBatches = fefo.updatedBatches
                effectiveBatchLabel = fefo.consumedBatchNos.joinToString(", ").ifBlank { "FEFO" }
                effectiveExpiry = fefo.earliestConsumedExpiry
                effectiveDonor = fefo.primaryDonorName
            }

            if (!isDisposed) {
                workingBatches = mergeOrAddBatchLocked(
                    batches = workingBatches,
                    itemId = item.id,
                    warehouseId = item.warehouseId,
                    batchNo = effectiveBatchLabel,
                    donorName = effectiveDonor,
                    expiryDate = effectiveExpiry,
                    addMinorQty = minorQty,
                    zoneName = WarehouseConstants.ZONE_QUARANTINE
                )
            }

            val recomputedUsableTotal = recomputeHealthyTotal(workingBatches, item.id)
            val updatedItem = item.copy(
                totalMinorQty = recomputedUsableTotal,
                expiryDate = earliestHealthyExpiry(workingBatches, item.id, item.expiryDate)
            )

            val voucher = newCustomVoucherNo(if (isDisposed) "DSP" else "QRN")
            val mov = StockMovement(
                id = newId("MOV"),
                voucherNo = voucher,
                type = StockMovementType.AUDIT_ADJUST,
                warehouseId = item.warehouseId,
                itemId = item.id,
                itemName = item.name,
                minorQty = minorQty,
                totalMinorDelta = if (deductedFromUsable) -minorQty else 0L,
                batchNo = effectiveBatchLabel,
                date = nowDateTime(),
                notes = if (isDisposed) {
                    "محضر إتلاف تالف ($minorQty ${item.minorUnitName}${if (!deductedFromUsable) " من الحجر الصحي" else ""}) | السبب: ${reason.trim()}"
                } else {
                    "نقل إلى الحجر الصحي ($minorQty ${item.minorUnitName} - مستبعد من الرصيد الصالح) | السبب: ${reason.trim()}"
                },
                performedBy = performedBy.trim()
            )

            commitStateLocked(
                context,
                state.copy(
                    items = state.items.map { if (it.id == item.id) updatedItem else it },
                    batches = workingBatches,
                    movements = listOf(mov) + state.movements
                )
            )
            mov
        }

        writeAuditSafe(
            context = context,
            actionType = if (isDisposed) "محضر إتلاف تالف" else "نقل إلى الحجر الصحي",
            targetId = movement.voucherNo,
            details = "${movement.itemName} | تشغيلة: ${movement.batchNo} | كمية: $minorQty | السبب: ${reason.trim()}",
            performedBy = performedBy
        )
        movement
    }

    /**
     * تسجيل قراءة سلسلة التبريد والمولدات (ColdChainLog) للمخازن المبردة.
     */
    suspend fun addColdChainLog(
        context: Context,
        warehouseId: String,
        temperatureCelsius: Double,
        generatorHours: Double,
        recordedBy: String = "",
        notes: String = ""
    ): ColdChainLog = withContext(Dispatchers.IO) {
        require(generatorHours >= 0.0) { "ساعات تشغيل المولد يجب أن تكون صفراً أو أكبر" }
        val log = synchronized(storeLock) {
            val state = ensureLoaded(context)
            require(state.warehouses.any { it.id == warehouseId }) { "المخزن المحدد غير موجود" }
            val created = ColdChainLog(
                id = newId("CLD"),
                warehouseId = warehouseId,
                timestamp = nowDateTime(),
                temperatureCelsius = roundMoney(temperatureCelsius),
                generatorHours = roundMoney(generatorHours),
                recordedBy = recordedBy.trim(),
                notes = notes.trim()
            )
            commitStateLocked(context, state.copy(coldChainLogs = listOf(created) + state.coldChainLogs))
            created
        }
        writeAuditSafe(
            context = context,
            actionType = "سجل سلسلة التبريد",
            targetId = log.warehouseId,
            details = "حرارة: ${log.temperatureCelsius}°C | ساعات المولد: ${log.generatorHours}h | ${log.notes}",
            performedBy = recordedBy
        )
        log
    }

    // ------------------------------------------------------------------------
    // هـ) نظام التخزين للغير والعملاء (3PL Storage Clients & Billing Engine)
    // ------------------------------------------------------------------------

    suspend fun saveClient(
        context: Context,
        client: StorageClient,
        performedBy: String = ""
    ): StorageClient = withContext(Dispatchers.IO) {
        val saved = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val resolvedId = client.id.trim().ifBlank { newId("CLI") }
            val resolved = client.copy(
                id = resolvedId,
                clientName = client.clientName.trim(),
                contactPerson = client.contactPerson.trim(),
                phone = client.phone.trim(),
                unitRate = client.unitRate.coerceAtLeast(0.0),
                handlingFee = client.handlingFee.coerceAtLeast(0.0),
                freeGraceDays = client.freeGraceDays.coerceAtLeast(0)
            )
            val updated = state.clients.filterNot { it.id == resolvedId } + resolved
            commitStateLocked(context, state.copy(clients = updated))
            resolved
        }
        writeAuditSafe(
            context = context,
            actionType = "عملاء التخزين للغير (3PL)",
            targetId = saved.id,
            details = "حفظ/تحديث عميل تخزين: ${saved.clientName} (${saved.billingModel.arabicLabel} - ${saved.unitRate})",
            performedBy = performedBy
        )
        saved
    }

    suspend fun deleteClient(
        context: Context,
        clientId: String,
        performedBy: String = ""
    ) = withContext(Dispatchers.IO) {
        synchronized(storeLock) {
            val state = ensureLoaded(context)
            commitStateLocked(
                context,
                state.copy(
                    clients = state.clients.filterNot { it.id == clientId },
                    clientTransactions = state.clientTransactions.filterNot { it.clientId == clientId }
                )
            )
        }
        writeAuditSafe(
            context = context,
            actionType = "عملاء التخزين للغير (3PL)",
            targetId = clientId,
            details = "حذف عميل تخزين للغير وحركاته",
            performedBy = performedBy
        )
    }

    suspend fun recordClientTransaction(
        context: Context,
        clientId: String,
        type: ClientStorageTxType,
        quantityPieces: Long = 0L,
        paymentAmount: Double = 0.0,
        itemDescription: String = "",
        date: String = "",
        notes: String = "",
        performedBy: String = ""
    ): ClientStorageTx = withContext(Dispatchers.IO) {
        val tx = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val client = state.clients.firstOrNull { it.id == clientId }
                ?: throw IllegalArgumentException("عميل التخزين غير موجود")

            when (type) {
                ClientStorageTxType.DEPOSIT -> require(quantityPieces > 0L) { "يجب إدخال كمية إيداع أكبر من صفر" }
                ClientStorageTxType.WITHDRAWAL -> {
                    require(quantityPieces > 0L) { "يجب إدخال كمية سحب أكبر من صفر" }
                    val summary = calculateClientBillingInternal(state, client, nowDate())
                    require(summary.remainingPieces >= quantityPieces) {
                        "رصيد العميل المتبقي (${summary.remainingPieces} قطعة) غير كافٍ لسحب $quantityPieces قطعة"
                    }
                }
                ClientStorageTxType.PAYMENT -> require(paymentAmount > 0.0) { "يجب إدخال مبلغ سداد أكبر من صفر" }
            }

            val created = ClientStorageTx(
                id = newId("CTX"),
                clientId = client.id,
                warehouseId = client.warehouseId,
                type = type,
                itemDescription = itemDescription.trim(),
                quantityPieces = if (type == ClientStorageTxType.PAYMENT) 0L else quantityPieces,
                paymentAmount = if (type == ClientStorageTxType.PAYMENT) paymentAmount else 0.0,
                date = date.trim().ifBlank { nowDate() },
                notes = notes.trim(),
                performedBy = performedBy.trim()
            )
            commitStateLocked(context, state.copy(clientTransactions = listOf(created) + state.clientTransactions))
            created
        }
        writeAuditSafe(
            context = context,
            actionType = "حركة تخزين للغير (3PL)",
            targetId = tx.id,
            details = "${tx.type.arabicLabel} | كمية=${tx.quantityPieces} | سداد=${tx.paymentAmount}",
            performedBy = performedBy
        )
        tx
    }

    /**
     * الدالة المحاسبية لعملاء التخزين للغير (3PL):
     * تحسب تلقائياً عبر FIFO: الرصيد المتبقي بالقطعة، إجمالي أيام التخزين المستحقة بعد السماح،
     * إجمالي أجرة التخزين والمناولة، المدفوع، وصافي المبلغ المستحق على العميل.
     */
    fun calculateClientBilling(
        clientId: String,
        asOfDate: String = nowDate()
    ): ClientBillingSummary {
        val state = _stateFlow.value
        val client = state.clients.firstOrNull { it.id == clientId }
            ?: return ClientBillingSummary(
                clientId = clientId,
                totalDepositedPieces = 0L,
                totalWithdrawnPieces = 0L,
                remainingPieces = 0L,
                totalBillableStorageDays = 0L,
                totalBillablePieceDays = 0L,
                storageFeeTotal = 0.0,
                handlingFeeTotal = 0.0,
                totalCharges = 0.0,
                totalPaid = 0.0,
                netAmountDue = 0.0
            )
        return calculateClientBillingInternal(state, client, asOfDate)
    }

    private data class FifoStorageLot(
        var remainingQty: Long,
        val depositMillis: Long
    )

    private fun calculateClientBillingInternal(
        state: WarehouseErpState,
        client: StorageClient,
        asOfDate: String
    ): ClientBillingSummary {
        val clientTxs = state.clientTransactions
            .filter { it.clientId == client.id }
            .sortedBy { parseDateMillis(it.date) }

        val asOfMillis = parseDateMillis(asOfDate)
        val graceDays = client.freeGraceDays.coerceAtLeast(0).toLong()

        var totalDeposited = 0L
        var totalWithdrawn = 0L
        var totalPaid = 0.0
        var depositMovementsCount = 0
        var firstDepositMillis: Long? = null
        var lastActivityMillis: Long? = null

        val fifoLots = ArrayDeque<FifoStorageLot>()
        var totalBillablePieceDays = 0L
        var maxBillableDaysSingleLot = 0L

        for (tx in clientTxs) {
            val txMillis = parseDateMillis(tx.date)
            when (tx.type) {
                ClientStorageTxType.DEPOSIT -> {
                    if (tx.quantityPieces > 0L) {
                        totalDeposited += tx.quantityPieces
                        depositMovementsCount++
                        if (firstDepositMillis == null) firstDepositMillis = txMillis
                        lastActivityMillis = txMillis
                        fifoLots.addLast(FifoStorageLot(tx.quantityPieces, txMillis))
                    }
                }
                ClientStorageTxType.WITHDRAWAL -> {
                    var toDeduct = tx.quantityPieces.coerceAtLeast(0L)
                    totalWithdrawn += toDeduct
                    lastActivityMillis = txMillis
                    while (toDeduct > 0L && fifoLots.isNotEmpty()) {
                        val lot = fifoLots.first()
                        val consumed = minOf(toDeduct, lot.remainingQty)
                        val daysHeld = daysBetweenMillis(lot.depositMillis, txMillis)
                        val billableDays = (daysHeld - graceDays).coerceAtLeast(0L)
                        totalBillablePieceDays += consumed * billableDays
                        if (billableDays > maxBillableDaysSingleLot) {
                            maxBillableDaysSingleLot = billableDays
                        }
                        lot.remainingQty -= consumed
                        toDeduct -= consumed
                        if (lot.remainingQty <= 0L) {
                            fifoLots.removeFirst()
                        }
                    }
                }
                ClientStorageTxType.PAYMENT -> {
                    totalPaid += tx.paymentAmount.coerceAtLeast(0.0)
                }
            }
        }

        // احتساب الأيام المتراكمة للدفعات التي لا تزال داخل المخزن حتى تاريخ اليوم (asOfDate)
        for (openLot in fifoLots) {
            if (openLot.remainingQty > 0L) {
                val daysHeld = daysBetweenMillis(openLot.depositMillis, asOfMillis)
                val billableDays = (daysHeld - graceDays).coerceAtLeast(0L)
                totalBillablePieceDays += openLot.remainingQty * billableDays
                if (billableDays > maxBillableDaysSingleLot) {
                    maxBillableDaysSingleLot = billableDays
                }
            }
        }

        val remainingPieces = (totalDeposited - totalWithdrawn).coerceAtLeast(0L)

        // إجمالي أيام التخزين المستحقة (المدة الفعلية النشطة بعد خصم أيام السماح المجانية)
        val spanEndMillis = if (remainingPieces > 0L) asOfMillis else (lastActivityMillis ?: asOfMillis)
        val spanBillableDays = if (firstDepositMillis != null) {
            (daysBetweenMillis(firstDepositMillis, spanEndMillis) - graceDays).coerceAtLeast(0L)
        } else {
            0L
        }
        val effectiveBillableDays = maxOf(spanBillableDays, maxBillableDaysSingleLot)

        val storageFeeTotal = when (client.billingModel) {
            ClientBillingModel.PER_PIECE_DAY -> {
                totalBillablePieceDays.toDouble() * client.unitRate
            }
            ClientBillingModel.PER_PALLET_WEEK -> {
                (totalBillablePieceDays.toDouble() / 7.0) * client.unitRate
            }
            ClientBillingModel.PER_MONTH -> {
                if (effectiveBillableDays <= 0L || totalDeposited <= 0L) {
                    0.0
                } else {
                    val monthsBilled = ceil(effectiveBillableDays.toDouble() / 30.0).coerceAtLeast(1.0)
                    monthsBilled * client.unitRate
                }
            }
        }

        val handlingFeeTotal = depositMovementsCount.toDouble() * client.handlingFee
        val totalCharges = roundMoney(storageFeeTotal + handlingFeeTotal)
        val roundedPaid = roundMoney(totalPaid)
        val netDue = roundMoney(totalCharges - roundedPaid)

        return ClientBillingSummary(
            clientId = client.id,
            totalDepositedPieces = totalDeposited,
            totalWithdrawnPieces = totalWithdrawn,
            remainingPieces = remainingPieces,
            totalBillableStorageDays = effectiveBillableDays,
            totalBillablePieceDays = totalBillablePieceDays,
            storageFeeTotal = roundMoney(storageFeeTotal),
            handlingFeeTotal = roundMoney(handlingFeeTotal),
            totalCharges = totalCharges,
            totalPaid = roundedPaid,
            netAmountDue = netDue
        )
    }

    // ------------------------------------------------------------------------
    // و) النظام المالي للمخزن: الموازنة، المصروفات التشغيلية، والرواتب
    // ------------------------------------------------------------------------

    suspend fun addBudgetEntry(
        context: Context,
        warehouseId: String,
        allocatedAmount: Double,
        fundingSource: String = "",
        date: String = "",
        notes: String = "",
        performedBy: String = ""
    ): WarehouseBudgetEntry = withContext(Dispatchers.IO) {
        require(allocatedAmount > 0.0) { "مبلغ الموازنة يجب أن يكون أكبر من صفر" }
        val entry = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val created = WarehouseBudgetEntry(
                id = newId("BDG"),
                warehouseId = warehouseId,
                allocatedAmount = roundMoney(allocatedAmount),
                fundingSource = fundingSource.trim(),
                date = date.trim().ifBlank { nowDate() },
                notes = notes.trim(),
                performedBy = performedBy.trim()
            )
            commitStateLocked(context, state.copy(budgetEntries = listOf(created) + state.budgetEntries))
            created
        }
        writeAuditSafe(
            context = context,
            actionType = "موازنة المخزن",
            targetId = entry.warehouseId,
            details = "اعتماد موازنة للمخزن بقيمة ${entry.allocatedAmount} (${entry.fundingSource})",
            performedBy = performedBy
        )
        entry
    }

    suspend fun addExpense(
        context: Context,
        warehouseId: String,
        category: String,
        amount: Double,
        invoiceNo: String = "",
        date: String = "",
        notes: String = "",
        performedBy: String = "",
        allocatedTarget: String = "GENERAL"
    ): WarehouseExpense = withContext(Dispatchers.IO) {
        require(amount > 0.0) { "قيمة المصروف يجب أن تكون أكبر من صفر" }
        val resolvedTarget = allocatedTarget.trim().ifBlank { "GENERAL" }
        val expense = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val created = WarehouseExpense(
                id = newId("EXP"),
                warehouseId = warehouseId,
                category = category.trim().ifBlank { "نثريات" },
                amount = roundMoney(amount),
                invoiceNo = invoiceNo.trim(),
                date = date.trim().ifBlank { nowDate() },
                notes = notes.trim(),
                performedBy = performedBy.trim(),
                allocatedTarget = resolvedTarget
            )
            commitStateLocked(context, state.copy(expenses = listOf(created) + state.expenses))
            created
        }
        writeAuditSafe(
            context = context,
            actionType = "مصروف تشغيلي للمخزن",
            targetId = expense.warehouseId,
            details = "${expense.category}: ${expense.amount} | تحميل: ${expense.allocatedTarget} | فاتورة: ${expense.invoiceNo}",
            performedBy = performedBy
        )
        expense
    }

    fun getExpensesByAllocatedTarget(warehouseId: String, allocatedTarget: String): List<WarehouseExpense> {
        val target = allocatedTarget.trim().ifBlank { "GENERAL" }
        return _stateFlow.value.expenses.filter {
            it.warehouseId == warehouseId && it.allocatedTarget.equals(target, ignoreCase = true)
        }
    }

    fun getTotalExpensesByTarget(warehouseId: String): Map<String, Double> {
        return _stateFlow.value.expenses
            .filter { it.warehouseId == warehouseId }
            .groupBy { it.allocatedTarget.ifBlank { "GENERAL" } }
            .mapValues { (_, list) -> roundMoney(list.sumOf { it.amount }) }
    }

    // ------------------------------------------------------------------------
    // ز) العُهد النقدية لأمين المخزن (PettyCashAdvance)
    // ------------------------------------------------------------------------

    fun getOpenPettyCashAdvance(warehouseId: String): PettyCashAdvance? {
        return _stateFlow.value.pettyCashAdvances.firstOrNull {
            it.warehouseId == warehouseId && it.status == PettyCashStatus.OPEN
        }
    }

    /**
     * فتح عهدة نقدية جديدة لأمين المخزن — يمنع صرفاً قاطعاً فتح عهدة جديدة قبل تسوية العهدة المفتوحة لنفس المخزن.
     */
    suspend fun openPettyCashAdvance(
        context: Context,
        warehouseId: String,
        keeperName: String,
        amount: Double,
        date: String = "",
        notes: String = "",
        performedBy: String = ""
    ): PettyCashAdvance = withContext(Dispatchers.IO) {
        require(amount > 0.0) { "مبلغ العهدة يجب أن يكون أكبر من صفر" }
        val advance = synchronized(storeLock) {
            val state = ensureLoaded(context)
            require(state.warehouses.any { it.id == warehouseId }) { "المخزن المحدد غير موجود" }
            val existingOpen = state.pettyCashAdvances.firstOrNull {
                it.warehouseId == warehouseId && it.status == PettyCashStatus.OPEN
            }
            require(existingOpen == null) {
                "لا يمكن فتح عهدة نقدية جديدة قبل تسوية العهدة المفتوحة حالياً (${existingOpen?.id}) لهذا المخزن"
            }
            val created = PettyCashAdvance(
                id = newId("PCA"),
                warehouseId = warehouseId,
                keeperName = keeperName.trim().ifBlank { "أمين المخزن" },
                amount = roundMoney(amount),
                date = date.trim().ifBlank { nowDate() },
                status = PettyCashStatus.OPEN,
                spentAmount = 0.0,
                settledDate = "",
                notes = notes.trim(),
                performedBy = performedBy.trim()
            )
            commitStateLocked(context, state.copy(pettyCashAdvances = listOf(created) + state.pettyCashAdvances))
            created
        }
        writeAuditSafe(
            context = context,
            actionType = "فتح عهدة نقدية",
            targetId = advance.id,
            details = "عهدة للمخزن ${advance.warehouseId} باسم ${advance.keeperName} بمبلغ ${advance.amount}",
            performedBy = performedBy
        )
        advance
    }

    /**
     * تسجيل فاتورة صرف على العهدة النقدية المفتوحة وإضافتها تلقائياً لسجل المصروفات التشغيلية.
     */
    suspend fun recordPettyCashSpend(
        context: Context,
        advanceId: String,
        amount: Double,
        category: String = "نثريات",
        invoiceNo: String = "",
        allocatedTarget: String = "GENERAL",
        notes: String = "",
        performedBy: String = ""
    ): PettyCashAdvance = withContext(Dispatchers.IO) {
        require(amount > 0.0) { "مبلغ الصرف من العهدة يجب أن يكون أكبر من صفر" }
        val updatedAdvance = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val advance = state.pettyCashAdvances.firstOrNull { it.id == advanceId }
                ?: throw IllegalArgumentException("العهدة النقدية غير موجودة")
            require(advance.status == PettyCashStatus.OPEN) { "العهدة النقدية مسوّاة ومغلقة بالفعل" }
            val newSpent = roundMoney(advance.spentAmount + amount)
            require(newSpent <= roundMoney(advance.amount) + 0.001) {
                "المبلغ المطلوب يتجاوز الرصيد المتبقي في العهدة (${advance.remainingAmount})"
            }
            val updated = advance.copy(spentAmount = newSpent)
            val linkedExpense = WarehouseExpense(
                id = newId("EXP"),
                warehouseId = advance.warehouseId,
                category = category.trim().ifBlank { "نثريات" },
                amount = roundMoney(amount),
                invoiceNo = invoiceNo.trim(),
                date = nowDate(),
                notes = buildString {
                    append("صرف من العهدة #${advance.id}")
                    if (notes.isNotBlank()) append(" | ${notes.trim()}")
                },
                performedBy = performedBy.trim().ifBlank { advance.keeperName },
                allocatedTarget = allocatedTarget.trim().ifBlank { "GENERAL" }
            )
            commitStateLocked(
                context,
                state.copy(
                    pettyCashAdvances = state.pettyCashAdvances.map { if (it.id == advanceId) updated else it },
                    expenses = listOf(linkedExpense) + state.expenses
                )
            )
            updated
        }
        writeAuditSafe(
            context = context,
            actionType = "صرف من العهدة النقدية",
            targetId = updatedAdvance.id,
            details = "صرف $amount ($category) من العهدة | إجمالي المنصرف: ${updatedAdvance.spentAmount} / ${updatedAdvance.amount}",
            performedBy = performedBy
        )
        updatedAdvance
    }

    /**
     * تسوية وإغلاق العهدة النقدية المفتوحة لإتاحة فتح عهدة جديدة لاحقاً.
     */
    suspend fun settlePettyCashAdvance(
        context: Context,
        advanceId: String,
        settlementNotes: String = "",
        performedBy: String = ""
    ): PettyCashAdvance = withContext(Dispatchers.IO) {
        val settled = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val advance = state.pettyCashAdvances.firstOrNull { it.id == advanceId }
                ?: throw IllegalArgumentException("العهدة النقدية غير موجودة")
            require(advance.status == PettyCashStatus.OPEN) { "العهدة النقدية مسوّاة ومغلقة مسبقاً" }
            val next = advance.copy(
                status = PettyCashStatus.SETTLED,
                settledDate = nowDate(),
                notes = listOf(advance.notes, settlementNotes.trim()).filter { it.isNotBlank() }.joinToString(" | ")
            )
            commitStateLocked(
                context,
                state.copy(
                    pettyCashAdvances = state.pettyCashAdvances.map { if (it.id == advanceId) next else it }
                )
            )
            next
        }
        writeAuditSafe(
            context = context,
            actionType = "تسوية عهدة نقدية",
            targetId = settled.id,
            details = "إغلاق عهدة ${settled.keeperName} | المبلغ: ${settled.amount} | المنصرف: ${settled.spentAmount} | المرتجع: ${settled.remainingAmount}",
            performedBy = performedBy
        )
        settled
    }

    suspend fun deleteExpense(
        context: Context,
        expenseId: String,
        performedBy: String = ""
    ) = withContext(Dispatchers.IO) {
        synchronized(storeLock) {
            val state = ensureLoaded(context)
            commitStateLocked(context, state.copy(expenses = state.expenses.filterNot { it.id == expenseId }))
        }
        writeAuditSafe(
            context = context,
            actionType = "مصروف تشغيلي للمخزن",
            targetId = expenseId,
            details = "حذف سجل مصروف تشغيلي",
            performedBy = performedBy
        )
    }

    /**
     * توليد مسير رواتب وأجور تلقائياً لجميع العاملين النشطين في المخزن لفترة محددة (مثلاً: "2026-11").
     */
    suspend fun generatePayrollForPeriod(
        context: Context,
        warehouseId: String,
        periodLabel: String,
        defaultDailyWorkedDays: Int = 26,
        performedBy: String = ""
    ): List<WarehousePayrollRecord> = withContext(Dispatchers.IO) {
        val cleanPeriod = periodLabel.trim().ifBlank {
            SimpleDateFormat("yyyy-MM", Locale.US).format(Date())
        }
        val createdRecords = synchronized(storeLock) {
            val state = ensureLoaded(context)
            val activeWorkers = state.workers.filter { it.warehouseId == warehouseId && it.isActive }
            val existingWorkerIds = state.payrollRecords
                .filter { it.warehouseId == warehouseId && it.periodLabel.equals(cleanPeriod, ignoreCase = true) }
                .map { it.workerId }
                .toSet()

            val newlyGenerated = activeWorkers
                .filter { it.id !in existingWorkerIds }
                .map { worker ->
                    val days = if (worker.payType == WorkerPayType.DAILY) defaultDailyWorkedDays.coerceAtLeast(1) else 30
                    val computedAmount = if (worker.payType == WorkerPayType.DAILY) {
                        roundMoney(worker.rate * days.toDouble())
                    } else {
                        roundMoney(worker.rate)
                    }
                    WarehousePayrollRecord(
                        id = newId("PAY"),
                        warehouseId = warehouseId,
                        periodLabel = cleanPeriod,
                        workerId = worker.id,
                        workerName = worker.name,
                        role = worker.role,
                        payType = worker.payType,
                        rate = worker.rate,
                        daysWorked = days,
                        amount = computedAmount,
                        isPaid = false,
                        paidDate = "",
                        performedBy = performedBy.trim()
                    )
                }

            if (newlyGenerated.isNotEmpty()) {
                commitStateLocked(context, state.copy(payrollRecords = newlyGenerated + state.payrollRecords))
            }
            newlyGenerated
        }
        if (createdRecords.isNotEmpty()) {
            writeAuditSafe(
                context = context,
                actionType = "مسير رواتب المخزن",
                targetId = warehouseId,
                details = "توليد مسير رواتب الفترة $cleanPeriod لعدد ${createdRecords.size} عامل",
                performedBy = performedBy
            )
        }
        createdRecords
    }

    suspend fun updatePayrollDaysWorked(
        context: Context,
        payrollId: String,
        daysWorked: Int
    ) = withContext(Dispatchers.IO) {
        synchronized(storeLock) {
            val state = ensureLoaded(context)
            val updated = state.payrollRecords.map { rec ->
                if (rec.id == payrollId && !rec.isPaid) {
                    val safeDays = daysWorked.coerceAtLeast(0)
                    val newAmount = if (rec.payType == WorkerPayType.DAILY) {
                        roundMoney(rec.rate * safeDays.toDouble())
                    } else {
                        rec.amount
                    }
                    rec.copy(daysWorked = safeDays, amount = newAmount)
                } else {
                    rec
                }
            }
            commitStateLocked(context, state.copy(payrollRecords = updated))
        }
    }

    /**
     * اعتماد وصرف سجل راتب محدد (يُخصم تلقائياً من صافي رصيد موازنة المخزن).
     */
    suspend fun approveAndPayPayroll(
        context: Context,
        payrollId: String,
        performedBy: String = ""
    ) = withContext(Dispatchers.IO) {
        val paidRecord = synchronized(storeLock) {
            val state = ensureLoaded(context)
            var matched: WarehousePayrollRecord? = null
            val updated = state.payrollRecords.map { rec ->
                if (rec.id == payrollId && !rec.isPaid) {
                    val paid = rec.copy(
                        isPaid = true,
                        paidDate = nowDate(),
                        performedBy = performedBy.trim().ifBlank { rec.performedBy }
                    )
                    matched = paid
                    paid
                } else {
                    rec
                }
            }
            if (matched != null) {
                commitStateLocked(context, state.copy(payrollRecords = updated))
            }
            matched
        }
        if (paidRecord != null) {
            writeAuditSafe(
                context = context,
                actionType = "صرف راتب مخزن",
                targetId = paidRecord.warehouseId,
                details = "اعتماد وصرف راتب ${paidRecord.workerName} (${paidRecord.periodLabel}): ${paidRecord.amount}",
                performedBy = performedBy
            )
        }
    }

    suspend fun approveAllPendingPayrollForPeriod(
        context: Context,
        warehouseId: String,
        periodLabel: String,
        performedBy: String = ""
    ): Int = withContext(Dispatchers.IO) {
        val count = synchronized(storeLock) {
            val state = ensureLoaded(context)
            var approvedCount = 0
            val today = nowDate()
            val updated = state.payrollRecords.map { rec ->
                if (rec.warehouseId == warehouseId &&
                    rec.periodLabel.equals(periodLabel.trim(), ignoreCase = true) &&
                    !rec.isPaid
                ) {
                    approvedCount++
                    rec.copy(
                        isPaid = true,
                        paidDate = today,
                        performedBy = performedBy.trim().ifBlank { rec.performedBy }
                    )
                } else {
                    rec
                }
            }
            if (approvedCount > 0) {
                commitStateLocked(context, state.copy(payrollRecords = updated))
            }
            approvedCount
        }
        if (count > 0) {
            writeAuditSafe(
                context = context,
                actionType = "اعتماد مسير رواتب",
                targetId = warehouseId,
                details = "اعتماد وصرف مسير الفترة $periodLabel لعدد $count عامل",
                performedBy = performedBy
            )
        }
        count
    }

    /**
     * الملخص المالي والمحاسبي الشامل للمخزن:
     * الموازنة المعتمدة + إيرادات التخزين للغير - إجمالي المصروفات - إجمالي الرواتب = صافي رصيد المخزن،
     * بالإضافة إلى متوسط تكلفة مناولة الوحدة الواحدة.
     */
    fun getWarehouseFinancialSummary(warehouseId: String): WarehouseFinancialSummary {
        val state = _stateFlow.value
        val approvedBudget = state.budgetEntries
            .filter { it.warehouseId == warehouseId }
            .sumOf { it.allocatedAmount }

        val warehouseClients = state.clients.filter { it.warehouseId == warehouseId }
        var storageRevenueCollected = 0.0
        var storageReceivables = 0.0
        val today = nowDate()
        for (cli in warehouseClients) {
            val billing = calculateClientBillingInternal(state, cli, today)
            storageRevenueCollected += billing.totalPaid
            if (billing.netAmountDue > 0.0) {
                storageReceivables += billing.netAmountDue
            }
        }

        val totalExpenses = state.expenses
            .filter { it.warehouseId == warehouseId }
            .sumOf { it.amount }

        val whPayrolls = state.payrollRecords.filter { it.warehouseId == warehouseId }
        val totalPaidPayroll = whPayrolls.filter { it.isPaid }.sumOf { it.amount }
        val pendingPayroll = whPayrolls.filter { !it.isPaid }.sumOf { it.amount }

        val netBalance = roundMoney(approvedBudget + storageRevenueCollected - totalExpenses - totalPaidPayroll)

        // إجمالي الوحدات المناولة (وارد + صادر + مناقلة + تسليم + إيداع/سحب عملاء 3PL)
        val internalHandled = state.movements
            .filter {
                (it.warehouseId == warehouseId || it.targetWarehouseId == warehouseId) &&
                    it.type != StockMovementType.AUDIT_ADJUST
            }
            .sumOf { kotlin.math.abs(it.totalMinorDelta) }

        val thirdPartyHandled = state.clientTransactions
            .filter {
                it.warehouseId == warehouseId &&
                    (it.type == ClientStorageTxType.DEPOSIT || it.type == ClientStorageTxType.WITHDRAWAL)
            }
            .sumOf { it.quantityPieces.coerceAtLeast(0L) }

        val totalHandledUnits = internalHandled + thirdPartyHandled
        val totalOperationalCost = totalExpenses + totalPaidPayroll
        val avgHandlingCost = if (totalHandledUnits > 0L) {
            roundMoney(totalOperationalCost / totalHandledUnits.toDouble())
        } else {
            0.0
        }

        return WarehouseFinancialSummary(
            warehouseId = warehouseId,
            approvedBudget = roundMoney(approvedBudget),
            thirdPartyStorageRevenue = roundMoney(storageRevenueCollected),
            thirdPartyReceivables = roundMoney(storageReceivables),
            totalExpenses = roundMoney(totalExpenses),
            totalPayroll = roundMoney(totalPaidPayroll),
            pendingPayroll = roundMoney(pendingPayroll),
            netWarehouseBalance = netBalance,
            totalHandledUnits = totalHandledUnits,
            avgHandlingCostPerUnit = avgHandlingCost
        )
    }

    // ------------------------------------------------------------------------
    // ح) التنبؤ بنفاد المخزون (Burn-Rate) وتصدير بطاقة الصنف CSV
    // ------------------------------------------------------------------------

    /**
     * التنبؤ بعدد الأيام المتبقية حتى نفاد الصنف بناءً على متوسط السحب والصرف الفعلي خلال آخر 14 يوماً.
     * يُرجع null في حال عدم وجود استهلاك خلال آخر 14 يوماً أو عدم وجود الصنف.
     */
    fun predictDaysUntilStockout(itemId: String): Int? {
        val state = _stateFlow.value
        val item = state.items.firstOrNull { it.id == itemId } ?: return null
        val cutoffMillis = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(14L)
        val totalOut14Days = state.movements
            .filter { mov ->
                mov.itemId == itemId &&
                    mov.totalMinorDelta < 0L &&
                    (mov.type == StockMovementType.OUT ||
                        mov.type == StockMovementType.DELIVERY_DEDUCT ||
                        mov.type == StockMovementType.TRANSFER ||
                        mov.type == StockMovementType.KIT_ASSEMBLE) &&
                    parseDateTimeMillis(mov.date) >= cutoffMillis
            }
            .sumOf { -it.totalMinorDelta }

        if (totalOut14Days <= 0L) return null
        val dailyAvg = totalOut14Days.toDouble() / 14.0
        if (dailyAvg <= 0.0) return null
        return (item.totalMinorQty.toDouble() / dailyAvg).toInt().coerceAtLeast(0)
    }

    /**
     * تصدير بطاقة الصنف الكاملة (Stock Card) بصيغة CSV UTF-8 وحفظها مباشرة في Downloads/HumanitarianAid.
     */
    suspend fun exportStockCardCsv(
        context: Context,
        warehouseId: String,
        itemId: String
    ): SavedExportResult = withContext(Dispatchers.IO) {
        val state = ensureLoaded(context)
        val warehouse = state.warehouses.firstOrNull { it.id == warehouseId }
            ?: throw IllegalArgumentException("المخزن غير موجود")
        val item = state.items.firstOrNull { it.id == itemId && it.warehouseId == warehouseId }
            ?: throw IllegalArgumentException("الصنف غير موجود في المخزن المحدد")

        val itemBatches = state.batches
            .filter { it.itemId == item.id && it.remainingMinorQty > 0L }
            .sortedWith(compareBy<StockBatch>({ it.isQuarantined }, { parseExpirySortableMillis(it.expiryDate) }))
        val quarantinedQty = itemBatches.filter { it.isQuarantined }.sumOf { it.remainingMinorQty }
        val predictedDays = predictDaysUntilStockout(item.id)

        val itemMovements = state.movements
            .filter { it.itemId == item.id && it.warehouseId == warehouseId }
            .sortedBy { parseDateTimeMillis(it.date) }

        fun csvCell(raw: String): String {
            val escaped = raw.replace("\"", "\"\"")
            return "\"$escaped\""
        }

        val sb = StringBuilder()
        sb.appendLine("بطاقة الصنف المخزنية (Stock Card)")
        sb.appendLine(listOf("المخزن", warehouse.name, "الموقع", warehouse.location).joinToString(",") { csvCell(it) })
        sb.appendLine(listOf("الصنف", item.name, "التصنيف", item.category).joinToString(",") { csvCell(it) })
        sb.appendLine(
            listOf(
                "الوحدة المزدوجة",
                "1 ${item.majorUnitName} = ${item.safeConversionFactor} ${item.minorUnitName}",
                "الرصيد الصالح الحالي",
                item.formatDualQuantity()
            ).joinToString(",") { csvCell(it) }
        )
        sb.appendLine(
            listOf(
                "الرصيد المحجور (حجر صحي)",
                "$quarantinedQty ${item.minorUnitName}",
                "توقع النفاد (متوسط 14 يوم)",
                if (predictedDays != null) "$predictedDays يوم" else "غير متوفر (لا يوجد استهلاك حديث)"
            ).joinToString(",") { csvCell(it) }
        )
        sb.appendLine(listOf("تاريخ التصدير", nowDateTime()).joinToString(",") { csvCell(it) })
        sb.appendLine()

        sb.appendLine("التشغيلات النشطة والمحجورة (Batches - FEFO)")
        sb.appendLine(
            listOf("رقم التشغيلة", "الجهة المانحة", "تاريخ الانتهاء", "المنطقة", "الرصيد المتبقي (${item.minorUnitName})")
                .joinToString(",") { csvCell(it) }
        )
        if (itemBatches.isEmpty()) {
            sb.appendLine(listOf("-", "-", item.expiryDate.ifBlank { "-" }, WarehouseConstants.ZONE_DRY, item.totalMinorQty.toString()).joinToString(",") { csvCell(it) })
        } else {
            itemBatches.forEach { b ->
                sb.appendLine(
                    listOf(
                        b.batchNo,
                        b.donorName.ifBlank { "-" },
                        b.expiryDate.ifBlank { "-" },
                        b.zoneName,
                        b.remainingMinorQty.toString()
                    ).joinToString(",") { csvCell(it) }
                )
            }
        }
        sb.appendLine()

        sb.appendLine("سجل حركات بطاقة الصنف (Stock Card Movements)")
        sb.appendLine(
            listOf(
                "التاريخ",
                "رقم السند",
                "نوع الحركة",
                "رقم التشغيلة",
                "التغير (${item.minorUnitName})",
                "الرصيد التراكمي",
                "الجهة / المورد / المستلم",
                "البوليصة / تصريح الخروج",
                "المنفذ",
                "ملاحظات"
            ).joinToString(",") { csvCell(it) }
        )

        var runningBalance = 0L
        for (mov in itemMovements) {
            runningBalance = (runningBalance + mov.totalMinorDelta).coerceAtLeast(0L)
            val party = mov.supplierOrDonor.ifBlank { mov.recipientOrProject }.ifBlank { "-" }
            sb.appendLine(
                listOf(
                    mov.date,
                    mov.voucherNo,
                    mov.type.arabicTitle,
                    mov.batchNo.ifBlank { "-" },
                    if (mov.totalMinorDelta > 0L) "+${mov.totalMinorDelta}" else mov.totalMinorDelta.toString(),
                    runningBalance.toString(),
                    party,
                    mov.waybillNo.ifBlank { "-" },
                    mov.performedBy.ifBlank { "-" },
                    mov.notes
                ).joinToString(",") { csvCell(it) }
            )
        }

        val safeItemName = item.name.replace(Regex("[^\\p{L}\\p{N}_-]+"), "_").trim('_').take(32).ifBlank { item.id }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
        val fileName = "StockCard_${safeItemName}_$stamp.csv"
        val saved = PublicDownloadsExporter.saveCsvToPublicDownloads(
            context = context,
            fileName = fileName,
            csvContent = sb.toString()
        )
        writeAuditSafe(
            context = context,
            actionType = "تصدير بطاقة صنف (CSV)",
            targetId = item.id,
            details = "تصدير بطاقة الصنف ${item.name} إلى ${saved.fileName}",
            performedBy = "أمين المخزن"
        )
        saved
    }

    // ------------------------------------------------------------------------
    // أدوات التاريخ، التقريب، والتسلسل بصيغة JSON
    // ------------------------------------------------------------------------

    private fun parseDateMillis(raw: String): Long {
        val clean = raw.trim().take(10)
        if (clean.isBlank()) return System.currentTimeMillis()
        return runCatching {
            SimpleDateFormat(DATE_ONLY_PATTERN, Locale.US).parse(clean)?.time ?: System.currentTimeMillis()
        }.getOrElse { System.currentTimeMillis() }
    }

    private fun parseDateTimeMillis(raw: String): Long {
        val clean = raw.trim()
        if (clean.isBlank()) return 0L
        return runCatching {
            if (clean.length >= 16) {
                SimpleDateFormat(DATE_TIME_PATTERN, Locale.US).parse(clean.take(16))?.time
            } else {
                SimpleDateFormat(DATE_ONLY_PATTERN, Locale.US).parse(clean.take(10))?.time
            } ?: 0L
        }.getOrElse { parseDateMillis(clean) }
    }

    private fun daysBetweenMillis(startMillis: Long, endMillis: Long): Long {
        val diff = endMillis - startMillis
        if (diff <= 0L) return 0L
        return TimeUnit.MILLISECONDS.toDays(diff)
    }

    private fun roundMoney(value: Double): Double {
        return kotlin.math.round(value * 100.0) / 100.0
    }

    private fun serializeStateToJson(state: WarehouseErpState): JSONObject {
        return JSONObject().apply {
            put("version", 2)
            put("warehouses", JSONArray().apply {
                state.warehouses.forEach { w ->
                    put(JSONObject().apply {
                        put("id", w.id)
                        put("name", w.name)
                        put("location", w.location)
                        put("storageType", w.storageType)
                        put("maxCapacity", w.maxCapacity)
                        put("status", w.status)
                        put("keeperName", w.keeperName)
                        put("keeperId", w.keeperId)
                        put("keeperPhone", w.keeperPhone)
                        put("equipmentNotes", w.equipmentNotes)
                        put("createdAt", w.createdAt)
                    })
                }
            })
            put("workers", JSONArray().apply {
                state.workers.forEach { w ->
                    put(JSONObject().apply {
                        put("id", w.id)
                        put("warehouseId", w.warehouseId)
                        put("name", w.name)
                        put("role", w.role)
                        put("payType", w.payType.name)
                        put("rate", w.rate)
                        put("isActive", w.isActive)
                    })
                }
            })
            put("items", JSONArray().apply {
                state.items.forEach { it ->
                    put(JSONObject().apply {
                        put("id", it.id)
                        put("warehouseId", it.warehouseId)
                        put("name", it.name)
                        put("category", it.category)
                        put("majorUnitName", it.majorUnitName)
                        put("minorUnitName", it.minorUnitName)
                        put("conversionFactor", it.conversionFactor)
                        put("totalMinorQty", it.totalMinorQty)
                        put("minThreshold", it.minThreshold)
                        put("expiryDate", it.expiryDate)
                        put("linkedProjectId", it.linkedProjectId ?: "")
                    })
                }
            })
            put("batches", JSONArray().apply {
                state.batches.forEach { b ->
                    put(JSONObject().apply {
                        put("id", b.id)
                        put("itemId", b.itemId)
                        put("warehouseId", b.warehouseId)
                        put("batchNo", b.batchNo)
                        put("donorName", b.donorName)
                        put("expiryDate", b.expiryDate)
                        put("remainingMinorQty", b.remainingMinorQty)
                        put("zoneName", b.zoneName)
                        put("createdAt", b.createdAt)
                    })
                }
            })
            put("movements", JSONArray().apply {
                state.movements.forEach { m ->
                    put(JSONObject().apply {
                        put("id", m.id)
                        put("voucherNo", m.voucherNo)
                        put("type", m.type.name)
                        put("warehouseId", m.warehouseId)
                        put("targetWarehouseId", m.targetWarehouseId ?: "")
                        put("itemId", m.itemId)
                        put("itemName", m.itemName)
                        put("majorQty", m.majorQty)
                        put("minorQty", m.minorQty)
                        put("totalMinorDelta", m.totalMinorDelta)
                        put("supplierOrDonor", m.supplierOrDonor)
                        put("waybillNo", m.waybillNo)
                        put("batchNo", m.batchNo)
                        put("recipientOrProject", m.recipientOrProject)
                        put("linkedProjectId", m.linkedProjectId ?: "")
                        put("driverName", m.driverName)
                        put("vehiclePlate", m.vehiclePlate)
                        put("date", m.date)
                        put("notes", m.notes)
                        put("performedBy", m.performedBy)
                    })
                }
            })
            put("inTransitShipments", JSONArray().apply {
                state.inTransitShipments.forEach { s ->
                    put(JSONObject().apply {
                        put("shipmentId", s.shipmentId)
                        put("fromWarehouseId", s.fromWarehouseId)
                        put("toWarehouseId", s.toWarehouseId)
                        put("itemId", s.itemId)
                        put("itemName", s.itemName)
                        put("sentMinorQty", s.sentMinorQty)
                        put("driverName", s.driverName)
                        put("vehiclePlate", s.vehiclePlate)
                        put("status", s.status.name)
                        put("receivedMinorQty", s.receivedMinorQty)
                        put("shortageQty", s.shortageQty)
                        put("gatePassToken", s.gatePassToken)
                        put("voucherNo", s.voucherNo)
                        put("batchNo", s.batchNo)
                        put("expiryDate", s.expiryDate)
                        put("donorName", s.donorName)
                        put("category", s.category)
                        put("majorUnitName", s.majorUnitName)
                        put("minorUnitName", s.minorUnitName)
                        put("conversionFactor", s.conversionFactor)
                        put("sentAt", s.sentAt)
                        put("confirmedAt", s.confirmedAt)
                        put("notes", s.notes)
                        put("performedBy", s.performedBy)
                        put("shortageAuditHash", s.shortageAuditHash)
                    })
                }
            })
            put("coldChainLogs", JSONArray().apply {
                state.coldChainLogs.forEach { c ->
                    put(JSONObject().apply {
                        put("id", c.id)
                        put("warehouseId", c.warehouseId)
                        put("timestamp", c.timestamp)
                        put("temperatureCelsius", c.temperatureCelsius)
                        put("generatorHours", c.generatorHours)
                        put("recordedBy", c.recordedBy)
                        put("notes", c.notes)
                    })
                }
            })
            put("pettyCashAdvances", JSONArray().apply {
                state.pettyCashAdvances.forEach { a ->
                    put(JSONObject().apply {
                        put("id", a.id)
                        put("warehouseId", a.warehouseId)
                        put("keeperName", a.keeperName)
                        put("amount", a.amount)
                        put("date", a.date)
                        put("status", a.status.name)
                        put("spentAmount", a.spentAmount)
                        put("settledDate", a.settledDate)
                        put("notes", a.notes)
                        put("performedBy", a.performedBy)
                    })
                }
            })
            put("clients", JSONArray().apply {
                state.clients.forEach { c ->
                    put(JSONObject().apply {
                        put("id", c.id)
                        put("warehouseId", c.warehouseId)
                        put("clientName", c.clientName)
                        put("contactPerson", c.contactPerson)
                        put("phone", c.phone)
                        put("billingModel", c.billingModel.name)
                        put("unitRate", c.unitRate)
                        put("handlingFee", c.handlingFee)
                        put("freeGraceDays", c.freeGraceDays)
                    })
                }
            })
            put("clientTransactions", JSONArray().apply {
                state.clientTransactions.forEach { tx ->
                    put(JSONObject().apply {
                        put("id", tx.id)
                        put("clientId", tx.clientId)
                        put("warehouseId", tx.warehouseId)
                        put("type", tx.type.name)
                        put("itemDescription", tx.itemDescription)
                        put("quantityPieces", tx.quantityPieces)
                        put("paymentAmount", tx.paymentAmount)
                        put("date", tx.date)
                        put("notes", tx.notes)
                        put("performedBy", tx.performedBy)
                    })
                }
            })
            put("budgetEntries", JSONArray().apply {
                state.budgetEntries.forEach { b ->
                    put(JSONObject().apply {
                        put("id", b.id)
                        put("warehouseId", b.warehouseId)
                        put("allocatedAmount", b.allocatedAmount)
                        put("fundingSource", b.fundingSource)
                        put("date", b.date)
                        put("notes", b.notes)
                        put("performedBy", b.performedBy)
                    })
                }
            })
            put("expenses", JSONArray().apply {
                state.expenses.forEach { e ->
                    put(JSONObject().apply {
                        put("id", e.id)
                        put("warehouseId", e.warehouseId)
                        put("category", e.category)
                        put("amount", e.amount)
                        put("invoiceNo", e.invoiceNo)
                        put("date", e.date)
                        put("notes", e.notes)
                        put("performedBy", e.performedBy)
                        put("allocatedTarget", e.allocatedTarget)
                    })
                }
            })
            put("payrollRecords", JSONArray().apply {
                state.payrollRecords.forEach { p ->
                    put(JSONObject().apply {
                        put("id", p.id)
                        put("warehouseId", p.warehouseId)
                        put("periodLabel", p.periodLabel)
                        put("workerId", p.workerId)
                        put("workerName", p.workerName)
                        put("role", p.role)
                        put("payType", p.payType.name)
                        put("rate", p.rate)
                        put("daysWorked", p.daysWorked)
                        put("amount", p.amount)
                        put("isPaid", p.isPaid)
                        put("paidDate", p.paidDate)
                        put("performedBy", p.performedBy)
                    })
                }
            })
        }
    }

    private fun parseStateFromJson(rawJson: String): WarehouseErpState {
        val root = JSONObject(rawJson)

        val warehouses = buildList {
            val arr = root.optJSONArray("warehouses") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    Warehouse(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        location = o.optString("location"),
                        storageType = o.optString("storageType", "جاف"),
                        maxCapacity = o.optLong("maxCapacity", 10000L),
                        status = o.optString("status", "نشط"),
                        keeperName = o.optString("keeperName"),
                        keeperId = o.optString("keeperId"),
                        keeperPhone = o.optString("keeperPhone"),
                        equipmentNotes = o.optString("equipmentNotes"),
                        createdAt = o.optString("createdAt")
                    )
                )
            }
        }

        val workers = buildList {
            val arr = root.optJSONArray("workers") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    WarehouseWorker(
                        id = o.optString("id"),
                        warehouseId = o.optString("warehouseId"),
                        name = o.optString("name"),
                        role = o.optString("role", "عامل تحميل"),
                        payType = WorkerPayType.fromString(o.optString("payType", "MONTHLY")),
                        rate = o.optDouble("rate", 0.0),
                        isActive = o.optBoolean("isActive", true)
                    )
                )
            }
        }

        val items = buildList {
            val arr = root.optJSONArray("items") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    WarehouseItem(
                        id = o.optString("id"),
                        warehouseId = o.optString("warehouseId"),
                        name = o.optString("name"),
                        category = o.optString("category"),
                        majorUnitName = o.optString("majorUnitName", "كرتونة"),
                        minorUnitName = o.optString("minorUnitName", "قطعة"),
                        conversionFactor = o.optInt("conversionFactor", 1).coerceAtLeast(1),
                        totalMinorQty = o.optLong("totalMinorQty", 0L),
                        minThreshold = o.optLong("minThreshold", 0L),
                        expiryDate = o.optString("expiryDate"),
                        linkedProjectId = o.optString("linkedProjectId").takeIf { it.isNotBlank() }
                    )
                )
            }
        }

        val batches = buildList {
            val arr = root.optJSONArray("batches") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    StockBatch(
                        id = o.optString("id"),
                        itemId = o.optString("itemId"),
                        warehouseId = o.optString("warehouseId"),
                        batchNo = o.optString("batchNo"),
                        donorName = o.optString("donorName"),
                        expiryDate = o.optString("expiryDate"),
                        remainingMinorQty = o.optLong("remainingMinorQty", 0L),
                        zoneName = o.optString("zoneName", WarehouseConstants.ZONE_DRY),
                        createdAt = o.optString("createdAt")
                    )
                )
            }
        }

        val movements = buildList {
            val arr = root.optJSONArray("movements") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    StockMovement(
                        id = o.optString("id"),
                        voucherNo = o.optString("voucherNo"),
                        type = StockMovementType.fromString(o.optString("type", "IN")),
                        warehouseId = o.optString("warehouseId"),
                        targetWarehouseId = o.optString("targetWarehouseId").takeIf { it.isNotBlank() },
                        itemId = o.optString("itemId"),
                        itemName = o.optString("itemName"),
                        majorQty = o.optLong("majorQty", 0L),
                        minorQty = o.optLong("minorQty", 0L),
                        totalMinorDelta = o.optLong("totalMinorDelta", 0L),
                        supplierOrDonor = o.optString("supplierOrDonor"),
                        waybillNo = o.optString("waybillNo"),
                        batchNo = o.optString("batchNo"),
                        recipientOrProject = o.optString("recipientOrProject"),
                        linkedProjectId = o.optString("linkedProjectId").takeIf { it.isNotBlank() },
                        driverName = o.optString("driverName"),
                        vehiclePlate = o.optString("vehiclePlate"),
                        date = o.optString("date"),
                        notes = o.optString("notes"),
                        performedBy = o.optString("performedBy")
                    )
                )
            }
        }

        val inTransitShipments = buildList {
            val arr = root.optJSONArray("inTransitShipments") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    InTransitShipment(
                        shipmentId = o.optString("shipmentId"),
                        fromWarehouseId = o.optString("fromWarehouseId"),
                        toWarehouseId = o.optString("toWarehouseId"),
                        itemId = o.optString("itemId"),
                        itemName = o.optString("itemName"),
                        sentMinorQty = o.optLong("sentMinorQty", 0L),
                        driverName = o.optString("driverName"),
                        vehiclePlate = o.optString("vehiclePlate"),
                        status = ShipmentStatus.fromString(o.optString("status", "IN_TRANSIT")),
                        receivedMinorQty = o.optLong("receivedMinorQty", 0L),
                        shortageQty = o.optLong("shortageQty", 0L),
                        gatePassToken = o.optString("gatePassToken"),
                        voucherNo = o.optString("voucherNo"),
                        batchNo = o.optString("batchNo"),
                        expiryDate = o.optString("expiryDate"),
                        donorName = o.optString("donorName"),
                        category = o.optString("category"),
                        majorUnitName = o.optString("majorUnitName", "كرتونة"),
                        minorUnitName = o.optString("minorUnitName", "قطعة"),
                        conversionFactor = o.optInt("conversionFactor", 1).coerceAtLeast(1),
                        sentAt = o.optString("sentAt"),
                        confirmedAt = o.optString("confirmedAt"),
                        notes = o.optString("notes"),
                        performedBy = o.optString("performedBy"),
                        shortageAuditHash = o.optString("shortageAuditHash")
                    )
                )
            }
        }

        val coldChainLogs = buildList {
            val arr = root.optJSONArray("coldChainLogs") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    ColdChainLog(
                        id = o.optString("id"),
                        warehouseId = o.optString("warehouseId"),
                        timestamp = o.optString("timestamp"),
                        temperatureCelsius = o.optDouble("temperatureCelsius", 0.0),
                        generatorHours = o.optDouble("generatorHours", 0.0),
                        recordedBy = o.optString("recordedBy"),
                        notes = o.optString("notes")
                    )
                )
            }
        }

        val pettyCashAdvances = buildList {
            val arr = root.optJSONArray("pettyCashAdvances") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    PettyCashAdvance(
                        id = o.optString("id"),
                        warehouseId = o.optString("warehouseId"),
                        keeperName = o.optString("keeperName"),
                        amount = o.optDouble("amount", 0.0),
                        date = o.optString("date"),
                        status = PettyCashStatus.fromString(o.optString("status", "OPEN")),
                        spentAmount = o.optDouble("spentAmount", 0.0),
                        settledDate = o.optString("settledDate"),
                        notes = o.optString("notes"),
                        performedBy = o.optString("performedBy")
                    )
                )
            }
        }

        val clients = buildList {
            val arr = root.optJSONArray("clients") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    StorageClient(
                        id = o.optString("id"),
                        warehouseId = o.optString("warehouseId"),
                        clientName = o.optString("clientName"),
                        contactPerson = o.optString("contactPerson"),
                        phone = o.optString("phone"),
                        billingModel = ClientBillingModel.fromString(o.optString("billingModel", "PER_PIECE_DAY")),
                        unitRate = o.optDouble("unitRate", 0.0),
                        handlingFee = o.optDouble("handlingFee", 0.0),
                        freeGraceDays = o.optInt("freeGraceDays", 0)
                    )
                )
            }
        }

        val clientTransactions = buildList {
            val arr = root.optJSONArray("clientTransactions") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    ClientStorageTx(
                        id = o.optString("id"),
                        clientId = o.optString("clientId"),
                        warehouseId = o.optString("warehouseId"),
                        type = ClientStorageTxType.fromString(o.optString("type", "DEPOSIT")),
                        itemDescription = o.optString("itemDescription"),
                        quantityPieces = o.optLong("quantityPieces", 0L),
                        paymentAmount = o.optDouble("paymentAmount", 0.0),
                        date = o.optString("date"),
                        notes = o.optString("notes"),
                        performedBy = o.optString("performedBy")
                    )
                )
            }
        }

        val budgetEntries = buildList {
            val arr = root.optJSONArray("budgetEntries") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    WarehouseBudgetEntry(
                        id = o.optString("id"),
                        warehouseId = o.optString("warehouseId"),
                        allocatedAmount = o.optDouble("allocatedAmount", 0.0),
                        fundingSource = o.optString("fundingSource"),
                        date = o.optString("date"),
                        notes = o.optString("notes"),
                        performedBy = o.optString("performedBy")
                    )
                )
            }
        }

        val expenses = buildList {
            val arr = root.optJSONArray("expenses") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    WarehouseExpense(
                        id = o.optString("id"),
                        warehouseId = o.optString("warehouseId"),
                        category = o.optString("category", "نثريات"),
                        amount = o.optDouble("amount", 0.0),
                        invoiceNo = o.optString("invoiceNo"),
                        date = o.optString("date"),
                        notes = o.optString("notes"),
                        performedBy = o.optString("performedBy"),
                        allocatedTarget = o.optString("allocatedTarget", "GENERAL").ifBlank { "GENERAL" }
                    )
                )
            }
        }

        val payrollRecords = buildList {
            val arr = root.optJSONArray("payrollRecords") ?: return@buildList
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                add(
                    WarehousePayrollRecord(
                        id = o.optString("id"),
                        warehouseId = o.optString("warehouseId"),
                        periodLabel = o.optString("periodLabel"),
                        workerId = o.optString("workerId"),
                        workerName = o.optString("workerName"),
                        role = o.optString("role"),
                        payType = WorkerPayType.fromString(o.optString("payType", "MONTHLY")),
                        rate = o.optDouble("rate", 0.0),
                        daysWorked = o.optInt("daysWorked", 0),
                        amount = o.optDouble("amount", 0.0),
                        isPaid = o.optBoolean("isPaid", false),
                        paidDate = o.optString("paidDate"),
                        performedBy = o.optString("performedBy")
                    )
                )
            }
        }

        return WarehouseErpState(
            warehouses = warehouses,
            workers = workers,
            items = items,
            batches = batches,
            movements = movements,
            inTransitShipments = inTransitShipments,
            coldChainLogs = coldChainLogs,
            pettyCashAdvances = pettyCashAdvances,
            clients = clients,
            clientTransactions = clientTransactions,
            budgetEntries = budgetEntries,
            expenses = expenses,
            payrollRecords = payrollRecords,
            isLoaded = true
        )
    }
}
