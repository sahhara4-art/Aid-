package com.humanitarian.aidmanagement.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.dao.AidTypeStatistic
import com.humanitarian.aidmanagement.data.local.dao.DynamicLocality
import com.humanitarian.aidmanagement.data.local.dao.DynamicLocalityStat
import com.humanitarian.aidmanagement.data.local.entities.Family
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

/**
 * DashboardViewModel - الهيكلية الديناميكية للمحليات
 * 1. القائمة المنسدلة تستمد خياراتها آلياً من استعلام DISTINCT السابق عبر قاعدة البيانات.
 * 2. الرسوم البيانية وشاشات الإحصائيات تُبنى آلياً بناءً على قائمة الـ (Grouping) الراجعة من قاعدة البيانات.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModel(
    private val database: AidDatabase
) : ViewModel() {

    // فلترة التواريخ: من تاريخ / إلى تاريخ
    private val _startDate = MutableStateFlow<Long?>(null)
    val startDate: StateFlow<Long?> = _startDate.asStateFlow()

    private val _endDate = MutableStateFlow<Long?>(null)
    val endDate: StateFlow<Long?> = _endDate.asStateFlow()

    // نطاق المستخدم وصلاحياته
    private val _isSuperAdmin = MutableStateFlow(true)
    private val _allowedLocalityIds = MutableStateFlow<List<Int>>(emptyList())

    fun setUserScope(isSuperAdmin: Boolean, allowedLocalityIds: List<Int>) {
        _isSuperAdmin.value = isSuperAdmin
        _allowedLocalityIds.value = allowedLocalityIds
    }

    fun setDateRange(start: Long?, end: Long?) {
        _startDate.value = start
        _endDate.value = end
    }

    fun clearDateRange() {
        _startDate.value = null
        _endDate.value = null
    }

    private val queryFilterParams = combine(
        _isSuperAdmin,
        _allowedLocalityIds,
        _startDate,
        _endDate
    ) { isSuper, locs, start, end ->
        FilterParams(isSuper, locs, start, end)
    }

    // =========================================================================
    // 1. القائمة المنسدلة (Dropdown Menu) تستمد خياراتها من استعلام DISTINCT
    // SELECT DISTINCT localityID, localityName FROM families WHERE localityName IS NOT NULL
    // =========================================================================
    val dynamicLocalitiesDropdown: StateFlow<List<DynamicLocality>> = database.familyDao()
        .getDistinctDynamicLocalities()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // =========================================================================
    // 2. شاشة الإحصائيات والرسوم البيانية (Charts) تُبنى آلياً من استعلام Grouping
    // SELECT localityName, COUNT(*) as totalCount FROM families WHERE developmentApproval = 'معتمد' AND residentStatus = 'مقيم' GROUP BY localityName
    // =========================================================================
    val dynamicLocalityCharts: StateFlow<List<DynamicLocalityStat>> = queryFilterParams
        .flatMapLatest { params ->
            database.familyDao().getDynamicLocalityStatisticsFiltered(
                isSuperAdmin = params.isSuperAdmin,
                allowedLocalityIds = params.allowedLocalityIds,
                startDate = params.startDate,
                endDate = params.endDate
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // =========================================================================
    // 3. إجمالي الأسر المستوفية للشرطين: معتمد ومقيم
    // =========================================================================
    val approvedResidentFamiliesCount: StateFlow<Int> = queryFilterParams
        .flatMapLatest { params ->
            database.familyDao().countApprovedResidentFamilies(
                isSuperAdmin = params.isSuperAdmin,
                allowedLocalityIds = params.allowedLocalityIds,
                startDate = params.startDate,
                endDate = params.endDate
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    // =========================================================================
    // 4. إجمالي المستفيدين (الأفراد) للأسر المعتمدة والمقيمة
    // =========================================================================
    val approvedResidentBeneficiariesCount: StateFlow<Int> = queryFilterParams
        .flatMapLatest { params ->
            database.familyDao().countApprovedResidentBeneficiaries(
                isSuperAdmin = params.isSuperAdmin,
                allowedLocalityIds = params.allowedLocalityIds,
                startDate = params.startDate,
                endDate = params.endDate
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    // =========================================================================
    // 5. إجمالي المساعدات المسلمة
    // =========================================================================
    val totalAidsCount: StateFlow<Int> = queryFilterParams
        .flatMapLatest { params ->
            database.aidRecordDao().countTotalAids(
                isSuperAdmin = params.isSuperAdmin,
                allowedLocalityIds = params.allowedLocalityIds,
                startDate = params.startDate,
                endDate = params.endDate
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    // =========================================================================
    // 6. إضافة أسرة جديدة مع ربطها بالمحلية الديناميكية
    // =========================================================================
    fun addNewFamily(
        name: String,
        nationalId: String,
        locality: DynamicLocality,
        membersCount: Int,
        residentStatus: String,
        devApproval: String
    ) {
        viewModelScope.launch {
            val family = Family(
                name = name.trim(),
                nationalID = nationalId.trim(),
                birthDate = System.currentTimeMillis() - 35L * 365 * 24 * 3600 * 1000,
                gender = "ذكر",
                maritalStatus = "متزوج",
                familyMembersCount = membersCount,
                residentStatus = residentStatus,
                developmentApproval = devApproval,
                localityID = locality.localityID,
                localityName = locality.localityName, // اعتماد الاسم والمعرف ديناميكياً
                createdDate = System.currentTimeMillis(),
                modifiedDate = System.currentTimeMillis()
            )
            database.familyDao().insertFamily(family)
        }
    }

    private data class FilterParams(
        val isSuperAdmin: Boolean,
        val allowedLocalityIds: List<Int>,
        val startDate: Long?,
        val endDate: Long?
    )
}
