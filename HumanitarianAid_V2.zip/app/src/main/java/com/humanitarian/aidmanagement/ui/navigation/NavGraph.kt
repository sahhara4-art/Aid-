package com.humanitarian.aidmanagement.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Login : Screen("login", "تسجيل الدخول")
    object Dashboard : Screen("dashboard", "المؤشرات العامة والتقارير")
    object Families : Screen("families", "بيانات الأسر")
    object Children : Screen("children", "سجل الأطفال")
    object Nomination : Screen("nomination", "ترشيح المساعدات")
    object DynamicNomination : Screen("dynamic_nomination", "محرك الترشيح الديناميكي")
    object ManualSelection : Screen("manual_selection", "الترشيح اليدوي")
    object NominationResults : Screen("nomination_results", "نتائج الترشيح")
    object Migration : Screen("migration", "ترحيل المساعدات")
    object Transfer : Screen("transfer", "ترحيل المساعدات")
    object Delivery : Screen("delivery", "تسليم وصرف المساعدات")
    object AccountsPermissions : Screen("accounts_permissions", "الحسابات والصلاحيات")
    object Projects : Screen("projects", "المشاريع الإنسانية")
    object Reports : Screen("reports", "التقارير والإحصائيات")
    object GeographicDistribution : Screen("geographic_distribution", "التوزيع الجغرافي للمستفيدين")
    object ExcelImportExport : Screen("excel_import_export", "استيراد ملفات إكسل")
    object DynamicReportExport : Screen("dynamic_report_export", "مركز التقارير والمعاينة الديناميكي")
    object ExecutiveReports : Screen("executive_reports", "التقرير الإداري التنفيذي")
    object Settings : Screen("settings", "إعدادات المنظومة")
    object BackupRestore : Screen("backup_restore", "النسخ الاحتياطي واستعادة البيانات")
    object FamilyDetails : Screen("family_details/{familyId}", "الملف الشامل للأسرة") {
        fun createRoute(familyId: Long): String = "family_details/$familyId"
    }
    object ProjectDetails : Screen("project_details/{projectId}", "تفاصيل المشروع المنفذ") {
        fun createRoute(projectId: Long): String = "project_details/$projectId"
    }
    object ExportProject : Screen("export_project_screen/{projectId}", "التصدير المخصص المتقدم") {
        fun createRoute(projectId: Long): String = "export_project_screen/$projectId"
    }
    object AddFamily : Screen("add_family_screen", "إضافة أسرة جديدة")
    object AddChild : Screen("add_child/{familyId}/{familyNationalId}", "إضافة فرد أو ابن") {
        fun createRoute(familyId: Long, familyNationalId: String): String = 
            "add_child/$familyId/${java.net.URLEncoder.encode(familyNationalId, "UTF-8")}"
    }
}
