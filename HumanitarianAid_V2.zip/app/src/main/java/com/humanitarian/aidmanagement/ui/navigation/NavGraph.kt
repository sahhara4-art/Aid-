package com.humanitarian.aidmanagement.ui.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Dashboard : Screen("dashboard")
    object Families : Screen("families")
    object FamilyDetails : Screen("family_details/{familyId}") {
        fun createRoute(familyId: Int) = "family_details/$familyId"
    }
    object AidRecords : Screen("aid_records")
    object Nomination : Screen("nomination")
    object Reports : Screen("reports")
    object Settings : Screen("settings")
    object ExcelImport : Screen("excel_import")
    object Geographic : Screen("geographic")
    object Projects : Screen("projects")
    object Delivery : Screen("delivery")
}
