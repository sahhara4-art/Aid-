package com.humanitarian.aidmanagement.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object BootRouter : Screen("boot_route", "تهيئة النظام والتحقق من الترخيص")
    object LicenseActivation : Screen("license_activation", "تفعيل الترخيص")
    object Login : Screen("login", "تسجيل الدخول")
    object Dashboard : Screen("dashboard", "المؤشرات العامة والتقارير")
    object Families : Screen("families", "بيانات الأسر")
    object Children : Screen("children", "سجل الأطفال")
    object Nomination : Screen("nomination", "ترشيح المساعدات")
    // مسار توافقي قديم يُعاد توجيهه تلقائياً إلى المسار الموحّد Screen.Nomination (المربوط بالشكاوى وترشيح الإكسل)
    object DynamicNomination : Screen("dynamic_nomination", "ترشيح المساعدات")
    object ManualSelection : Screen("manual_selection", "الترشيح اليدوي")
    object NominationResults : Screen("nomination_results", "نتائج الترشيح")
    object Migration : Screen("migration", "ترحيل المساعدات")
    object Transfer : Screen("transfer", "ترحيل المساعدات")
    object Delivery : Screen("delivery", "تسليم وصرف المساعدات")
    object AccountsPermissions : Screen("accounts_permissions", "الحسابات والصلاحيات")
    object UsersManagement : Screen("users_management_route", "إدارة المستخدمين والصلاحيات")
    object Projects : Screen("projects", "المشاريع الإنسانية")
    object WarehouseErp : Screen("warehouse_erp", "إدارة المخازن والمحاسبة اللوجستية")
    object WarehouseDynamicReports : Screen("warehouse_dynamic_reports", "تقارير المخازن التفصيلية")
    object Reports : Screen("reports", "التقارير والإحصائيات")
    object GeographicDistribution : Screen("geographic_distribution", "التوزيع الجغرافي للمستفيدين")
    object ExcelMatching : Screen("excel_matching", "مطابقة وتدقيق الإكسل")
    object HouseholdIntegrityAuditor : Screen("household_integrity_auditor", "كاشف التداخل والازدواجية")
    object AuditLog : Screen("audit_log_screen", "سجل الرقابة والتدقيق")
    object ExcelImportExport : Screen("excel_import_export", "استيراد ملفات إكسل")
    object DynamicReportExport : Screen("dynamic_report_export", "مركز التقارير والمعاينة الديناميكي")
    object ExecutiveReports : Screen("executive_reports", "التقرير الإداري التنفيذي")
    object Settings : Screen("settings", "إعدادات المنظومة")
    object BackupRestore : Screen("backup_restore", "النسخ الاحتياطي واستعادة البيانات")
    object FamilyDetails : Screen("family_details/{familyId}", "الملف الشامل للأسرة") {
        fun createRoute(familyId: Long): String = "family_details/$familyId"
    }
    object ProjectDetails : Screen("project_details/{projectId}", "تفاصيل المشروع المنفذ") {
        fun createRoute(projectId: Long): String = "project_details/$projectId"
    }
    object ExportProject : Screen("export_project_screen/{projectId}", "التصدير المخصص المتقدم") {
        fun createRoute(projectId: Long): String = "export_project_screen/$projectId"
    }
    object AddFamily : Screen("add_family", "إضافة أسرة جديدة")
    object CivilRegistryLookup : Screen("civil_registry_lookup", "البحث في السجل المدني")
    object AddChild : Screen("add_child/{familyId}/{familyNationalId}", "إضافة فرد أو ابن") {
        fun createRoute(familyId: Long, familyNationalId: String): String = 
            "add_child/$familyId/${java.net.URLEncoder.encode(familyNationalId, "UTF-8")}"
    }
}

/**
 * جدار حماية مسارات التنقل (NavGraph Firewall)
 * يطبق الصلاحيات بدقة متناهية لكل شاشة في القائمة الجانبية؛
 * تجاوز الصلاحيات محصور فقط بالحساب الرئيسي (username == "admin").
 */
fun canAccessNavRoute(
    route: String?,
    permissions: List<String>,
    isSuperAdmin: Boolean
): Boolean {
    if (route == null ||
        route == Screen.BootRouter.route ||
        route == Screen.LicenseActivation.route ||
        route == Screen.Login.route
    ) return true
    if (isSuperAdmin || com.humanitarian.aidmanagement.security.AccessControlManager.isSuperAdmin()) return true

    val acm = com.humanitarian.aidmanagement.security.AccessControlManager
    val normalizedFallback = permissions
        .map { acm.normalizeScreenKey(it) }
        .filter { it.isNotBlank() }
        .toSet()

    fun hasScreen(screenKey: String): Boolean {
        return if (acm.isLoggedIn()) {
            acm.canAccessScreen(screenKey)
        } else {
            normalizedFallback.contains(acm.normalizeScreenKey(screenKey))
        }
    }

    return when {
        route == Screen.Dashboard.route ->
            hasScreen(acm.SCREEN_DASHBOARD)

        route == Screen.Families.route ||
            route.startsWith("family_details") ||
            route == Screen.Children.route ->
            hasScreen(acm.SCREEN_FAMILIES)

        route == Screen.AddFamily.route ->
            if (acm.isLoggedIn()) {
                acm.canAddNewFamily()
            } else {
                normalizedFallback.contains(acm.SCREEN_ADD_FAMILY) &&
                    permissions.any { it.equals(acm.ACTION_ADD, ignoreCase = true) }
            }

        route.startsWith("add_child") ->
            hasScreen(acm.SCREEN_FAMILIES) &&
                if (acm.isLoggedIn()) acm.hasActionPermission(acm.ACTION_ADD) else permissions.contains(acm.ACTION_ADD)

        route == Screen.CivilRegistryLookup.route ->
            hasScreen(acm.SCREEN_CIVIL_REGISTRY)

        route == Screen.Nomination.route ||
            route == Screen.DynamicNomination.route ||
            route.startsWith("manual_selection") ||
            route == Screen.NominationResults.route ||
            route == Screen.Migration.route ||
            route == Screen.Transfer.route ->
            hasScreen(acm.SCREEN_NOMINATION)

        route == Screen.Delivery.route ->
            hasScreen(acm.SCREEN_DELIVERY)

        route == Screen.Projects.route || route.startsWith("project_details") ->
            hasScreen(acm.SCREEN_PROJECTS)

        route == Screen.WarehouseErp.route ->
            hasScreen(acm.SCREEN_WAREHOUSE_ERP)

        route == Screen.WarehouseDynamicReports.route ->
            hasScreen(acm.SCREEN_WAREHOUSE_REPORTS)

        route == Screen.GeographicDistribution.route ->
            hasScreen(acm.SCREEN_GEOGRAPHIC)

        route == Screen.Reports.route ->
            hasScreen(acm.SCREEN_REPORTS)

        route == Screen.ExecutiveReports.route ->
            hasScreen(acm.SCREEN_EXECUTIVE_REPORTS)

        route == Screen.DynamicReportExport.route || route.startsWith("export_project_screen") ->
            hasScreen(acm.SCREEN_DYNAMIC_REPORTS)

        route == Screen.HouseholdIntegrityAuditor.route ->
            hasScreen(acm.SCREEN_INTEGRITY_AUDITOR)

        route == Screen.ExcelMatching.route ->
            hasScreen(acm.SCREEN_EXCEL_MATCHING)

        route == Screen.ExcelImportExport.route ->
            hasScreen(acm.SCREEN_EXCEL)

        route == Screen.AuditLog.route ->
            hasScreen(acm.SCREEN_AUDIT_LOG)

        route == Screen.BackupRestore.route || route == Screen.Settings.route ->
            hasScreen(acm.SCREEN_BACKUP)

        route == Screen.AccountsPermissions.route || route == Screen.UsersManagement.route ->
            hasScreen(acm.SCREEN_USERS)

        else -> false
    }
}

