package com.humanitarian.aidmanagement.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object BootRouter : Screen("boot_route", "تهيئة النظام والتحقق من الترخيص")
    object LicenseActivation : Screen("license_activation", "تفعيل الترخيص")
    object Login : Screen("login", "تسجيل الدخول")
    object Dashboard : Screen("dashboard", "المؤشرات العامة والتقارير")
    object Families : Screen("families", "بيانات الأسر")
    object Children : Screen("children", "سجل الأطفال")
    object Nomination : Screen("nomination", "ترشيح المساعدات")
    object DynamicNomination : Screen("dynamic_nomination", "محرك الترشيح الديناميكي")
    object ManualSelection : Screen("manual_selection", "الترشيح اليدوي")
    object NominationResults : Screen("nomination_results", "نتائج الترشيح")
    object Migration : Screen("migration", "ترحيل المساعدات")
    object Transfer : Screen("transfer", "ترحيل المساعدات")
    object Delivery : Screen("delivery", "تسليم وصرف المساعدات")
    object AccountsPermissions : Screen("accounts_permissions", "الحسابات والصلاحيات")
    object UsersManagement : Screen("users_management_route", "إدارة المستخدمين والصلاحيات")
    object Projects : Screen("projects", "المشاريع الإنسانية")
    object Reports : Screen("reports", "التقارير والإحصائيات")
    object GeographicDistribution : Screen("geographic_distribution", "التوزيع الجغرافي للمستفيدين")
    object ExcelMatching : Screen("excel_matching", "مطابقة وتدقيق الإكسل")
    object ExcelImportExport : Screen("excel_import_export", "استيراد ملفات إكسل")
    object DynamicReportExport : Screen("dynamic_report_export", "مركز التقارير والمعاينة الديناميكي")
    object ExecutiveReports : Screen("executive_reports", "التقرير الإداري التنفيذي")
    object Settings : Screen("settings", "إعدادات المنظومة")
    object BackupRestore : Screen("backup_restore", "النسخ الاحتياطي واستعادة البيانات")
    object FamilyDetails : Screen("family_details/{familyId}", "الملف الشامل للأسرة") {
        fun createRoute(familyId: Long): String = "family_details/$familyId"
    }
    object ProjectDetails : Screen("project_details/{projectId}", "تفاصيل المشروع المنفذ") {
        fun createRoute(projectId: Long): String = "project_details/$projectId"
    }
    object ExportProject : Screen("export_project_screen/{projectId}", "التصدير المخصص المتقدم") {
        fun createRoute(projectId: Long): String = "export_project_screen/$projectId"
    }
    object AddFamily : Screen("add_family_screen", "إضافة أسرة جديدة")
    object AddChild : Screen("add_child/{familyId}/{familyNationalId}", "إضافة فرد أو ابن") {
        fun createRoute(familyId: Long, familyNationalId: String): String = 
            "add_child/$familyId/${java.net.URLEncoder.encode(familyNationalId, "UTF-8")}"
    }
}

/**
 * جدار حماية مسارات التنقل (NavGraph Firewall)
 * يحدد بدقة ما إذا كان المستخدم الحالي يمتلك الصلاحية اللازمة لفتح المسار المطلوب
 */
fun canAccessNavRoute(
    route: String?,
    permissions: List<String>,
    isSuperAdmin: Boolean
): Boolean {
    if (route == null || route == Screen.BootRouter.route || route == Screen.LicenseActivation.route || route == Screen.Login.route || route == Screen.Dashboard.route) return true
    if (isSuperAdmin) return true

    return when {
        route == Screen.AccountsPermissions.route || route == Screen.UsersManagement.route ->
            permissions.contains("CAN_MANAGE_USERS") || permissions.contains("users")

        route == Screen.ExcelMatching.route ->
            permissions.contains("CAN_MATCH_EXCEL") ||
                permissions.contains("excel_matching") ||
                permissions.contains("CAN_IMPORT_EXCEL") ||
                permissions.contains("CAN_VERIFY_IDS")

        route == Screen.ExcelImportExport.route ->
            permissions.contains("CAN_IMPORT_EXCEL") || permissions.contains("IMPORT") || permissions.contains("excel_import_export")

        route == Screen.DynamicReportExport.route ->
            permissions.contains("CAN_EXPORT_REPORTS") ||
                permissions.contains("CAN_EXPORT") ||
                permissions.contains("CAN_EXPORT_EXCEL") ||
                permissions.contains("CAN_EXPORT_PDF") ||
                permissions.contains("EXPORT") ||
                permissions.contains("CAN_ACCESS_BI_DASHBOARD")

        route.startsWith("export_project_screen") ->
            permissions.contains("CAN_EXPORT_REPORTS") ||
                permissions.contains("CAN_EXPORT") ||
                permissions.contains("CAN_EXPORT_EXCEL") ||
                permissions.contains("CAN_EXPORT_PDF") ||
                permissions.contains("EXPORT")

        route == Screen.Reports.route ->
            permissions.contains("CAN_ACCESS_BI_DASHBOARD") ||
                permissions.contains("CAN_VIEW_REPORTS") ||
                permissions.contains("reports")

        route == Screen.ExecutiveReports.route ->
            permissions.contains("CAN_ACCESS_BI_DASHBOARD") ||
                permissions.contains("CAN_VIEW_REPORTS") ||
                permissions.contains("CAN_EXPORT_REPORTS") ||
                permissions.contains("CAN_EXPORT_EXCEL") ||
                permissions.contains("CAN_EXPORT_PDF") ||
                permissions.contains("reports")

        route == Screen.GeographicDistribution.route ->
            permissions.contains("CAN_ACCESS_BI_DASHBOARD") ||
                permissions.contains("CAN_VIEW_REPORTS") ||
                permissions.contains("CAN_VIEW_GEOGRAPHIC")

        route == Screen.BackupRestore.route || route == Screen.Settings.route ->
            permissions.contains("CAN_BACKUP_CLOUD") ||
                permissions.contains("CAN_BACKUP_LOCAL") ||
                permissions.contains("BACKUP_CLOUD") ||
                permissions.contains("BACKUP_LOCAL") ||
                permissions.contains("CAN_MANAGE_USERS") ||
                permissions.contains("backup")

        route == Screen.Nomination.route ||
            route == Screen.DynamicNomination.route ||
            route.startsWith("manual_selection") ||
            route == Screen.NominationResults.route ||
            route == Screen.Migration.route ||
            route == Screen.Transfer.route ->
            permissions.contains("CAN_RUN_FILTRATION") ||
                permissions.contains("CAN_NOMINATE") ||
                permissions.contains("nomination")

        route == Screen.Delivery.route ->
            permissions.contains("CAN_DELIVER_AID") ||
                permissions.contains("CAN_DELIVER") ||
                permissions.contains("delivery")

        route == Screen.Families.route ||
            route == Screen.AddFamily.route ||
            route.startsWith("family_details") ||
            route.startsWith("add_child") ||
            route == Screen.Children.route ->
            permissions.contains("CAN_MANAGE_FAMILIES") ||
                permissions.contains("families")

        route == Screen.Projects.route || route.startsWith("project_details") ->
            permissions.contains("CAN_MANAGE_PROJECTS") ||
                permissions.contains("CAN_RUN_FILTRATION") ||
                permissions.contains("CAN_NOMINATE") ||
                permissions.contains("projects")

        else -> false
    }
}
