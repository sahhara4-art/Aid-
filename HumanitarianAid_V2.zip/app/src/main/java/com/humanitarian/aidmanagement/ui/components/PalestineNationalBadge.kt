package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PalestineNationalBadge(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .background(Color(0xFF0F172A), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(Modifier.size(8.dp).background(Color(0xFFE11D48), RoundedCornerShape(4.dp)))
        Box(Modifier.size(8.dp).background(Color(0xFF16A34A), RoundedCornerShape(4.dp)))
        Box(Modifier.size(8.dp).background(Color.White, RoundedCornerShape(4.dp)))
        Box(Modifier.size(8.dp).background(Color.Black, RoundedCornerShape(4.dp)))
        Spacer(Modifier.width(2.dp))
        Text("فلسطين", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
