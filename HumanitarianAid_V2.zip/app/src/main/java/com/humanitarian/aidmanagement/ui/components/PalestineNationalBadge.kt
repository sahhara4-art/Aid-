package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.ui.theme.*

/**
 * بصمة فلسطين الوطنية - مكون شريطي أنيق يعبر عن الهوية الوطنية الفلسطينية
 * يتضمن ألوان العلم الفلسطيني الأربعة (الأسود، الأبيض، الأخضر، المثلث الأحمر)
 */
@Composable
fun PalestineNationalBanner(
    modifier: Modifier = Modifier,
    subtitle: String = "الهيئة الوطنية لإدارة وتوزيع المساعدات الإنسانية • قطاع غزة"
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = PalestineWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, SlateBorder, RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // شريط ألوان العلم الفلسطيني الأربعة العلوي
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
            ) {
                Box(modifier = Modifier.weight(1f).fillMaxHeight().background(PalestineBlack))
                Box(modifier = Modifier.weight(1f).fillMaxHeight().background(PalestineWhite))
                Box(modifier = Modifier.weight(1f).fillMaxHeight().background(PalestineGreen))
                Box(modifier = Modifier.weight(0.4f).fillMaxHeight().background(PalestineRed))
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // شارة علم فلسطين مع الشعار
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = PalestineGreenContainer,
                        border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.3f)),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(text = "🇵🇸", fontSize = 20.sp)
                        }
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "دولة فلسطين",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = PalestineGreenDark
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = PalestineRed.copy(alpha = 0.12f)
                            ) {
                                Text(
                                    text = "صمود وأمل",
                                    color = PalestineRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = SlateTextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                // ختم الهوية
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = SlateSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
                ) {
                    Text(
                        text = "فلسطين في القلب",
                        color = PalestineGreen,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
