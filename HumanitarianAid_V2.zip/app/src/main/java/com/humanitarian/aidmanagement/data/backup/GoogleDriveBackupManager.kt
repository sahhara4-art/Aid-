package com.humanitarian.aidmanagement.data.backup

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Process
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.Scopes
import com.google.android.gms.common.api.Scope
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.google.api.services.drive.model.FileList
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * عنصر يمثل نسخة احتياطية سحابية محفوظة على Google Drive
 */
data class CloudBackupItem(
    val fileId: String,
    val fileName: String,
    val sizeBytes: Long,
    val createdTimeFormatted: String,
    val timestamp: Long,
    val description: String = ""
)

data class CloudBackupResult(
    val success: Boolean,
    val message: String,
    val fileId: String? = null,
    val fileName: String? = null,
    val sizeBytes: Long = 0L
)

data class CloudRestoreResult(
    val success: Boolean,
    val message: String,
    val requiresRestart: Boolean = false
)

/**
 * مدير النسخ الاحتياطي السحابي الفعلي المتكامل مع Google Drive REST API v3
 * يقوم بالآتي:
 * 1. تهيئة Google Sign-In باستخدام Scope ملفات Drive (DRIVE_FILE).
 * 2. حفظ ملفات قاعدة بيانات Room الثلاثة (.db, -wal, -shm) داخل ملف أرشيف مضغوط (.zip).
 * 3. إنشاء مجلد سحابي "HumanitarianAid_Backups" ورفع النسخة مع تفاصيل البيانات.
 * 4. استرجاع النسخ السحابية وتنزيلها واستبدال القاعدة المحلية وإعادة تشغيل التطبيق.
 */
class GoogleDriveBackupManager(
    private val context: Context,
    private val database: AidDatabase
) {
    companion object {
        const val BACKUP_FOLDER_NAME = "HumanitarianAid_Backups"
        const val MIME_TYPE_FOLDER = "application/vnd.google-apps.folder"
        const val MIME_TYPE_ZIP = "application/zip"

        /**
         * معرّف عميل الويب (Web Client ID - Client type 3) المعتمد من Firebase Console
         * لتمكين مصادقة Google Sign-In وتوليد ID Token وصلاحيات Google Drive API
         */
        const val WEB_CLIENT_ID = "915149520150-g3h23roq89at901od3ui4tohuo1a9f9a.apps.googleusercontent.com"
    }

    private val jsonFactory = GsonFactory.getDefaultInstance()
    private val httpTransport = NetHttpTransport()
    private val restoreScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * إعدادات عميل تسجيل الدخول بحساب Google مع صلاحية Drive File وطلب معرف الـ ID Token
     */
    fun getGoogleSignInClient(webClientId: String = WEB_CLIENT_ID): GoogleSignInClient {
        val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(Scopes.DRIVE_FILE))

        // استخدام Web Client ID المعتمد لطلب معرف الهوية
        if (webClientId.isNotBlank()) {
            builder.requestIdToken(webClientId)
        }

        return GoogleSignIn.getClient(context, builder.build())
    }

    /**
     * الحصول على آخر حساب تم تسجيل الدخول به ولديه الصلاحيات
     */
    fun getSignedInAccount(): GoogleSignInAccount? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return if (account != null && GoogleSignIn.hasPermissions(account, Scope(Scopes.DRIVE_FILE))) {
            account
        } else {
            null
        }
    }

    /**
     * تهيئة وإنشاء عميل GoogleDriveManager للحساب المعتمد
     */
    fun createDriveManager(account: GoogleSignInAccount): GoogleDriveManager {
        return GoogleDriveManager(context, account)
    }

    suspend fun backupDatabase(outputStream: java.io.OutputStream) { BackupRestoreEngine.performBackup(context, outputStream) }
    suspend fun restoreDatabase(inputStream: java.io.InputStream) { BackupRestoreEngine.performRestore(context, inputStream) }

    /**
     * بناء عميل خدمة Google Drive API v3 المرتبط بحساب المستخدم المعتمد
     */
    private fun getDriveService(account: GoogleSignInAccount): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(
            context,
            Collections.singleton(DriveScopes.DRIVE_FILE)
        ).apply {
            selectedAccount = account.account
        }

        val requestInitializer = com.google.api.client.http.HttpRequestInitializer { request ->
            credential.initialize(request)
            request.connectTimeout = 3 * 60 * 1000
            request.readTimeout = 3 * 60 * 1000
        }

        val driveService = com.google.api.services.drive.Drive.Builder(
            com.google.api.client.extensions.android.http.AndroidHttp.newCompatibleTransport(),
            com.google.api.client.json.jackson2.JacksonFactory.getDefaultInstance(),
            requestInitializer
        ).setApplicationName("Humanitarian Aid App").build()

        return driveService
    }

    /**
     * البحث عن المجلد السحابي المخصص للنسخ أو إنشاؤه إذا لم يكن موجوداً
     */
    private suspend fun getOrCreateBackupFolderId(driveService: Drive): String = withContext(Dispatchers.IO) {
        val query = "mimeType = '$MIME_TYPE_FOLDER' and name = '$BACKUP_FOLDER_NAME' and trashed = false"
        val result: FileList = driveService.files().list()
            .setQ(query)
            .setSpaces("drive")
            .setFields("files(id, name)")
            .execute()

        val existingFolder = result.files?.firstOrNull()
        if (existingFolder != null) {
            return@withContext existingFolder.id
        }

        // إنشاء المجلد إذا لم يكن موجوداً
        val folderMetadata = DriveFile().apply {
            name = BACKUP_FOLDER_NAME
            mimeType = MIME_TYPE_FOLDER
            description = "مجلد النسخ الاحتياطية المشفرة لنظام إدارة المساعدات الإنسانية"
        }

        val createdFolder = driveService.files().create(folderMetadata)
            .setFields("id")
            .execute()

        createdFolder.id
    }

    /**
     * رفع نسخة احتياطية متكاملة لقاعدة بيانات Room إلى Google Drive
     */
    suspend fun backupToGoogleDrive(account: GoogleSignInAccount): CloudBackupResult = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val folderId = getOrCreateBackupFolderId(driveService)

            val timestamp = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(timestamp))
            val backupFileName = "aid_backup_$dateStr.zip"
            val tempZipFile = File(context.cacheDir, backupFileName)

            FileOutputStream(tempZipFile).use { fos ->
                backupDatabase(fos)
            }

            // رفع الملف إلى Google Drive
            val driveMetadata = DriveFile().apply {
                name = backupFileName
                parents = listOf(folderId)
                description = "نسخة احتياطية كاملة لقاعدة بيانات Room بتاريخ $dateStr"
            }

            val mediaContent = FileContent(MIME_TYPE_ZIP, tempZipFile)
            val resultFile = driveService.files().create(driveMetadata, mediaContent)
                .setFields("id, name, size")
                .execute()

            val remoteId = resultFile?.id
            val remoteName = resultFile?.name ?: backupFileName
            val remoteSize = resultFile?.getSize() ?: tempZipFile.length()

            tempZipFile.delete()

            CloudBackupResult(
                success = true,
                message = "تم رفع النسخة الاحتياطية السحابية بنجاح إلى مجلد $BACKUP_FOLDER_NAME على Google Drive",
                fileId = remoteId,
                fileName = remoteName,
                sizeBytes = remoteSize
            )
        } catch (e: Exception) {
            CloudBackupResult(
                success = false,
                message = "فشل النسخ الاحتياطي السحابي: ${e.localizedMessage ?: e.message}"
            )
        }
    }

    /**
     * استعراض قائمة النسخ السحابية المحفوظة في مجلد HumanitarianAid_Backups
     */
    suspend fun listGoogleDriveBackups(account: GoogleSignInAccount): List<CloudBackupItem> = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val folderId = getOrCreateBackupFolderId(driveService)

            val query = "'$folderId' in parents and mimeType = '$MIME_TYPE_ZIP' and trashed = false"
            val fileList = driveService.files().list()
                .setQ(query)
                .setSpaces("drive")
                .setFields("files(id, name, size, createdTime, description)")
                .setOrderBy("createdTime desc")
                .execute()

            fileList.files?.map { file ->
                val createdTimeMillis = file.createdTime?.value ?: 0L
                val dateFormatted = if (createdTimeMillis > 0) {
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(createdTimeMillis))
                } else "غير محدد"

                CloudBackupItem(
                    fileId = file.id,
                    fileName = file.name ?: "نسخة احتياطية بدون اسم",
                    sizeBytes = file.getSize() ?: 0L,
                    createdTimeFormatted = dateFormatted,
                    timestamp = createdTimeMillis,
                    description = file.description ?: ""
                )
            } ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * التحقق مما إذا كان الملف يبدأ بترويسة أرشيف ZIP صالحة
     */
    private fun isZipArchive(file: File): Boolean {
        if (!file.exists() || file.length() < 4) return false
        return try {
            FileInputStream(file).use { fis ->
                val b = ByteArray(4)
                val read = fis.read(b)
                read == 4 && b[0] == 0x50.toByte() && b[1] == 0x4b.toByte() && (b[2] == 0x03.toByte() || b[2] == 0x05.toByte() || b[2] == 0x07.toByte())
            }
        } catch (_: Exception) { false }
    }

    /**
     * التحقق مما إذا كان الملف يحتوي على ترويسة SQLite الصريحة ("SQLite format 3")
     */
    private fun isSqliteHeader(file: File): Boolean {
        if (!file.exists() || file.length() < 16) return false
        return try {
            FileInputStream(file).use { fis ->
                val header = ByteArray(16)
                val read = fis.read(header)
                read >= 16 && String(header, 0, 15, Charsets.US_ASCII) == "SQLite format 3"
            }
        } catch (_: Exception) { false }
    }

    /**
     * فك ضغط ملف النسخة الاحتياطية واستخراج ملف قاعدة البيانات الأساسي (.db) كملف واحد فقط
     */
    private fun extractDatabaseFromArchive(zipFile: File, destinationDir: File): File? {
        if (!destinationDir.exists()) destinationDir.mkdirs()

        FileInputStream(zipFile).use { fis ->
            ZipInputStream(fis).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val entryPath = entry.name
                    val entryName = entryPath.substringAfterLast('/')
                    val isMacOrHidden = entryPath.contains("__MACOSX") || entryName.startsWith(".")

                    if (!entry.isDirectory && !isMacOrHidden) {
                        val destFile = File(destinationDir, entryName)
                        FileOutputStream(destFile).use { fos ->
                            zis.copyTo(fos)
                            fos.flush()
                            fos.fd.sync()
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }

        val allFiles = destinationDir.listFiles() ?: emptyArray()

        // البحث عن ملف قاعدة البيانات بالترويسة
        var dbFile = allFiles.firstOrNull { file ->
            !file.name.endsWith(".json") && isSqliteHeader(file)
        }

        // أو بالاسم والامتداد
        if (dbFile == null) {
            dbFile = allFiles.firstOrNull { file ->
                val lower = file.name.lowercase()
                !lower.endsWith(".json") &&
                (lower.contains("aid_database") ||
                 lower.contains("humanitarian_aid_database") ||
                 lower == AidDatabase.DATABASE_NAME.lowercase() ||
                 lower.endsWith(".db") ||
                 lower.endsWith(".sqlite"))
            }
        }

        return dbFile
    }

    /**
     * استرداد نسخة احتياطية من Google Drive تتبع التسلسل الصارم الخماسي داخل Dispatchers.IO:
     * 1. تحميل الملف: تحميل ملف .zip من Google Drive إلى مجلد مؤقت (Cache Directory).
     * 2. فك الضغط (Unzip): فك ضغط الملف المؤقت والتحقق من وجود ملف قاعدة البيانات.
     * 3. الإغلاق: استدعاء database.close() وإغلاق اتصالات Room.
     * 4. النقل الآمن: نسخ الملف المستخرج إلى مسار قاعدة البيانات الموحد context.getDatabasePath(AidDatabase.DATABASE_NAME).
     * 5. إعادة التشغيل: إعادة تشغيل التطبيق (Restart Process) ليقوم Room بقراءة الملفات المفكوكة حديثاً.
     */
    // الاستعادة مفعلة مباشرة عبر BackupRestoreEngine أعلاه

    suspend fun restoreFromGoogleDrive(account: GoogleSignInAccount, fileId: String): CloudRestoreResult = restoreScope.async {
        try {
            DatabaseBackupManager.updateRestoreState(RestoreState.DOWNLOADING)
            val driveService = getDriveService(account)
            val inputStream = driveService.files().get(fileId).executeMediaAsInputStream()

            DatabaseBackupManager.updateRestoreState(RestoreState.COPYING_FILES)
            inputStream.use { stream ->
                restoreDatabase(stream)
            }

            CloudRestoreResult(
                success = true,
                message = "تمت استعادة قاعدة البيانات بنجاح!"
            )
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveRestore", "Restore failed: ${e.message}", e)
            val userFriendlyMessage = when {
                e is java.net.SocketTimeoutException || e.message?.contains("timed out", ignoreCase = true) == true ->
                    "انتهت مهلة الاتصال أثناء تحميل النسخة الاحتياطية من Google Drive. يرجى التحقق من اتصال الإنترنت وإعادة المحاولة."
                e.message?.contains("Software caused connection abort", ignoreCase = true) == true ||
                e.message?.contains("Connection reset", ignoreCase = true) == true ||
                e is java.net.SocketException ->
                    "انقطع الاتصال بخوادم Google أثناء التحميل. يرجى المحاولة مرة أخرى."
                else ->
                    "فشلت استعادة النسخة السحابية: ${e.localizedMessage ?: e.message}"
            }
            DatabaseBackupManager.updateRestoreState(RestoreState.ERROR(userFriendlyMessage, "استعادة من Google Drive"))
            CloudRestoreResult(
                success = false,
                message = userFriendlyMessage
            )
        }
    }.await()


    /**
     * إعادة تشغيل التطبيق بشكل آمن لضمان فتح قاعدة بيانات Room بعد الاستبدال
     */
    fun restartApplication() {
        DatabaseBackupManager.restartApplication(context)
    }

    private fun addFileToZip(zos: ZipOutputStream, file: File, entryName: String) {
        val entry = ZipEntry(entryName)
        zos.putNextEntry(entry)
        FileInputStream(file).use { fis ->
            fis.copyTo(zos)
        }
        zos.flush()
        zos.closeEntry()
    }
}
