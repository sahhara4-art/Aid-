package com.humanitarian.aidmanagement.data.backup

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Process
import android.util.Log
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.googleapis.extensions.android.gms.auth.UserRecoverableAuthIOException
import com.google.api.client.googleapis.json.GoogleJsonResponseException
import com.google.api.client.googleapis.media.MediaHttpUploader
import com.google.api.client.googleapis.media.MediaHttpUploaderProgressListener
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.google.api.services.drive.model.FileList
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * عنصر يمثل نسخة احتياطية سحابية محفوظة على Google Drive
 */
data class CloudBackupItem(
    val fileId: String,
    val fileName: String,
    val sizeBytes: Long,
    val createdTimeFormatted: String,
    val timestamp: Long,
    val description: String = ""
)

data class CloudBackupResult(
    val success: Boolean,
    val message: String,
    val fileId: String? = null,
    val fileName: String? = null,
    val sizeBytes: Long = 0L,
    val recoverableIntent: Intent? = null
)

data class CloudRestoreResult(
    val success: Boolean,
    val message: String,
    val requiresRestart: Boolean = false
)

/**
 * مدير النسخ الاحتياطي السحابي الفعلي المتكامل مع Google Drive REST API v3
 * يقوم بالآتي:
 * 1. تهيئة Google Sign-In باستخدام Scope ملفات Drive (DRIVE_FILE).
 * 2. حفظ ملفات قاعدة بيانات Room الثلاثة (.db, -wal, -shm) داخل ملف أرشيف مضغوط (.zip).
 * 3. إنشاء مجلد سحابي "HumanitarianAid_Backups" ورفع النسخة مع تفاصيل البيانات.
 * 4. استرجاع النسخ السحابية وتنزيلها واستبدال القاعدة المحلية وإعادة تشغيل التطبيق.
 */
class GoogleDriveBackupManager(
    private val context: Context,
    private val database: AidDatabase
) {
    companion object {
        const val BACKUP_FOLDER_NAME = "HumanitarianAid_Backups"
        const val MIME_TYPE_FOLDER = "application/vnd.google-apps.folder"
        const val MIME_TYPE_ZIP = "application/zip"

        /**
         * معرّف عميل الويب (Web Client ID - Client type 3) المعتمد من Firebase Console
         * لتمكين مصادقة Google Sign-In وتوليد ID Token وصلاحيات Google Drive API
         */
        const val WEB_CLIENT_ID = "915149520150-g3h23roq89at901od3ui4tohuo1a9f9a.apps.googleusercontent.com"
    }

    private val jsonFactory = GsonFactory.getDefaultInstance()
    private val httpTransport = NetHttpTransport()
    private val restoreScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _uploadProgress = MutableStateFlow(0f)
    val uploadProgress: StateFlow<Float> = _uploadProgress.asStateFlow()

    /**
     * إعدادات عميل تسجيل الدخول بحساب Google مع صلاحية Drive File وطلب معرف الـ ID Token
     */
    fun getGoogleSignInClient(webClientId: String = WEB_CLIENT_ID): GoogleSignInClient {
        val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DriveScopes.DRIVE_FILE))

        // استخدام Web Client ID المعتمد لطلب معرف الهوية
        if (webClientId.isNotBlank()) {
            builder.requestIdToken(webClientId)
        }

        return GoogleSignIn.getClient(context, builder.build())
    }

    /**
     * الحصول على آخر حساب تم تسجيل الدخول به ولديه الصلاحيات
     */
    fun getSignedInAccount(): GoogleSignInAccount? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return if (account != null && GoogleSignIn.hasPermissions(account, Scope(DriveScopes.DRIVE_FILE))) {
            account
        } else {
            null
        }
    }

    /**
     * تهيئة وإنشاء عميل GoogleDriveManager للحساب المعتمد
     */
    fun createDriveManager(account: GoogleSignInAccount): GoogleDriveManager {
        return GoogleDriveManager(context, account)
    }

    suspend fun backupDatabase(outputStream: java.io.OutputStream) { BackupRestoreEngine.performBackup(context, outputStream) }
    suspend fun restoreDatabase(inputStream: java.io.InputStream) { BackupRestoreEngine.performRestore(context, inputStream) }

    /**
     * بناء عميل خدمة Google Drive API v3 المرتبط بحساب المستخدم المعتمد
     */
    private fun getDriveService(account: GoogleSignInAccount): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(
            context,
            Collections.singleton(DriveScopes.DRIVE_FILE)
        ).apply {
            selectedAccount = account.account
        }

        val requestInitializer = com.google.api.client.http.HttpRequestInitializer { request ->
            credential.initialize(request)
            // زيادة المهلة إلى 5 دقائق (300,000 ملي ثانية) لاستيعاب الملفات الكبيرة
            request.connectTimeout = 5 * 60 * 1000
            request.readTimeout = 5 * 60 * 1000
        }

        val driveService = com.google.api.services.drive.Drive.Builder(
            com.google.api.client.extensions.android.http.AndroidHttp.newCompatibleTransport(),
            com.google.api.client.json.jackson2.JacksonFactory.getDefaultInstance(),
            requestInitializer
        ).setApplicationName("Humanitarian Aid App").build()

        return driveService
    }

    /**
     * البحث عن المجلد السحابي المخصص للنسخ أو إنشاؤه إذا لم يكن موجوداً
     */
    private suspend fun getOrCreateBackupFolderId(driveService: Drive): String = withContext(Dispatchers.IO) {
        val query = "mimeType = '$MIME_TYPE_FOLDER' and name = '$BACKUP_FOLDER_NAME' and trashed = false"
        val result: FileList = driveService.files().list()
            .setQ(query)
            .setSpaces("drive")
            .setFields("files(id, name)")
            .execute()

        val existingFolder = result.files?.firstOrNull()
        if (existingFolder != null) {
            return@withContext existingFolder.id
        }

        // إنشاء المجلد إذا لم يكن موجوداً
        val folderMetadata = DriveFile().apply {
            name = BACKUP_FOLDER_NAME
            mimeType = MIME_TYPE_FOLDER
            description = "مجلد النسخ الاحتياطية المشفرة لنظام إدارة المساعدات الإنسانية"
        }

        val createdFolder = driveService.files().create(folderMetadata)
            .setFields("id")
            .execute()

        createdFolder.id
    }

    private fun extractReadableErrorMessage(t: Throwable): String {
        return when (t) {
            is UserRecoverableAuthIOException ->
                "مطلوب تفويض الوصول إلى Google Drive للمتابعة (${t.localizedMessage ?: t.message ?: "UserRecoverableAuthIOException"})"
            is GoogleJsonResponseException -> {
                val apiMsg = t.details?.message
                val code = t.statusCode
                "خطأ خادم Google Drive ($code): ${apiMsg ?: t.localizedMessage ?: t.message}"
            }
            else -> {
                val primary = t.localizedMessage ?: t.message ?: t.javaClass.simpleName
                val causeMsg = t.cause?.localizedMessage ?: t.cause?.message
                if (!causeMsg.isNullOrBlank() && causeMsg != primary) {
                    "$primary ($causeMsg)"
                } else {
                    primary
                }
            }
        }
    }

    /**
     * رفع نسخة احتياطية متكاملة لقاعدة بيانات Room إلى Google Drive
     * باستخدام FileContent والرفع المجزأ (Resumable Upload) بحجم 256KB لمنع OOM وضمان تقدم فعلي من 0% إلى 100%
     */
    suspend fun backupToGoogleDrive(
        account: GoogleSignInAccount,
        onProgress: (Float) -> Unit = {}
    ): CloudBackupResult = withContext(Dispatchers.IO) {
        val timestamp = System.currentTimeMillis()
        val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(timestamp))
        val backupFileName = "aid_backup_$dateStr.zip"
        val file = File(context.cacheDir, backupFileName)

        try {
            _uploadProgress.value = 0f
            onProgress(0f)

            val driveService = getDriveService(account)
            val folderId = getOrCreateBackupFolderId(driveService)

            FileOutputStream(file).use { fos ->
                backupDatabase(fos)
                fos.flush()
            }

            val fileLength = file.length()
            if (!file.exists() || fileLength <= 0L) {
                throw IllegalStateException("تعذر إنشاء ملف النسخة الاحتياطية المضغوط (الملف فارغ أو غير موجود)")
            }

            // رفع الملف إلى Google Drive عبر FileContent المباشر مع تفعيل الرفع المجزأ (Resumable Upload)
            val driveMetadata = DriveFile().apply {
                name = backupFileName
                parents = listOf(folderId)
                description = "نسخة احتياطية كاملة لقاعدة بيانات Room بتاريخ $dateStr"
            }

            val mediaContent = FileContent("application/zip", file)

            val request = driveService.files().create(driveMetadata, mediaContent)
                .setFields("id, name, size")

            request.mediaHttpUploader.isDirectUploadEnabled = false
            request.mediaHttpUploader.setChunkSize(MediaHttpUploader.MINIMUM_CHUNK_SIZE)
            request.mediaHttpUploader.setProgressListener(MediaHttpUploaderProgressListener { uploader ->
                val progress = when (uploader.uploadState) {
                    MediaHttpUploader.UploadState.INITIATION_STARTED -> 0.02f
                    MediaHttpUploader.UploadState.INITIATION_COMPLETE -> 0.05f
                    MediaHttpUploader.UploadState.MEDIA_IN_PROGRESS -> {
                        val p = try { uploader.progress } catch (_: Exception) { 0.0 }
                        if (p.isNaN()) 0.05f else p.toFloat().coerceIn(0.05f, 0.99f)
                    }
                    MediaHttpUploader.UploadState.MEDIA_COMPLETE -> 1f
                    else -> 0f
                }
                _uploadProgress.value = progress
                onProgress(progress)
            })

            val resultFile = request.execute()

            _uploadProgress.value = 1f
            onProgress(1f)

            val remoteId = resultFile?.id
            val remoteName = resultFile?.name ?: backupFileName
            val remoteSize = resultFile?.getSize() ?: fileLength

            CloudBackupResult(
                success = true,
                message = "تم رفع النسخة الاحتياطية السحابية بنجاح إلى مجلد $BACKUP_FOLDER_NAME على Google Drive",
                fileId = remoteId,
                fileName = remoteName,
                sizeBytes = remoteSize
            )
        } catch (t: Throwable) {
            Log.e("GoogleDriveBackup", "Upload failed before/during execution: ${t.message}", t)
            _uploadProgress.value = 0f
            onProgress(0f)
            val recoverable = (t as? UserRecoverableAuthIOException)?.intent
            val realMessage = extractReadableErrorMessage(t)
            CloudBackupResult(
                success = false,
                message = "فشل الرفع إلى Google Drive: $realMessage",
                recoverableIntent = recoverable
            )
        } finally {
            try {
                if (file.exists()) file.delete()
            } catch (_: Exception) {}
        }
    }

    /**
     * حذف نسخة احتياطية نهائياً من Google Drive
     */
    suspend fun deleteCloudBackup(
        account: GoogleSignInAccount,
        fileId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            driveService.files().delete(fileId).execute()
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e("GoogleDriveBackup", "Delete backup $fileId failed: ${t.message}", t)
            Result.failure(Exception(extractReadableErrorMessage(t), t))
        }
    }

    /**
     * استعراض قائمة النسخ السحابية المحفوظة في مجلد HumanitarianAid_Backups
     */
    suspend fun listGoogleDriveBackups(account: GoogleSignInAccount): List<CloudBackupItem> = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val folderId = getOrCreateBackupFolderId(driveService)

            val query = "'$folderId' in parents and mimeType = '$MIME_TYPE_ZIP' and trashed = false"
            val fileList = driveService.files().list()
                .setQ(query)
                .setSpaces("drive")
                .setFields("files(id, name, size, createdTime, description)")
                .setOrderBy("createdTime desc")
                .execute()

            fileList.files?.map { file ->
                val createdTimeMillis = file.createdTime?.value ?: 0L
                val dateFormatted = if (createdTimeMillis > 0) {
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(createdTimeMillis))
                } else "غير محدد"

                CloudBackupItem(
                    fileId = file.id,
                    fileName = file.name ?: "نسخة احتياطية بدون اسم",
                    sizeBytes = file.getSize() ?: 0L,
                    createdTimeFormatted = dateFormatted,
                    timestamp = createdTimeMillis,
                    description = file.description ?: ""
                )
            } ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * التحقق مما إذا كان الملف يبدأ بترويسة أرشيف ZIP صالحة
     */
    private fun isZipArchive(file: File): Boolean {
        if (!file.exists() || file.length() < 4) return false
        return try {
            FileInputStream(file).use { fis ->
                val b = ByteArray(4)
                val read = fis.read(b)
                read == 4 && b[0] == 0x50.toByte() && b[1] == 0x4b.toByte() && (b[2] == 0x03.toByte() || b[2] == 0x05.toByte() || b[2] == 0x07.toByte())
            }
        } catch (_: Exception) { false }
    }

    /**
     * فك ضغط ملف النسخة الاحتياطية واستخراج ملف قاعدة البيانات الأساسي (.db) كملف واحد فقط
     * مع تجاوز فحص ترويسة SQLite لأن قاعدة البيانات مشفرة عبر SQLCipher
     */
    private fun extractDatabaseFromArchive(zipFile: File, destinationDir: File): File? {
        if (!destinationDir.exists()) destinationDir.mkdirs()

        FileInputStream(zipFile).use { fis ->
            ZipInputStream(fis).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val entryPath = entry.name
                    val entryName = entryPath.substringAfterLast('/')
                    val isMacOrHidden = entryPath.contains("__MACOSX") || entryName.startsWith(".")

                    if (!entry.isDirectory && !isMacOrHidden && entryName.isNotBlank()) {
                        val destFile = File(destinationDir, entryName)
                        FileOutputStream(destFile).use { fos ->
                            zis.copyTo(fos)
                            fos.flush()
                            fos.fd.sync()
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }

        val allFiles = destinationDir.listFiles() ?: emptyArray()

        // الاعتماد على الامتداد والاسم فقط (تجاهل ترويسة SQLite لأن الملف مشفر بـ SQLCipher)
        val dbFile = allFiles.firstOrNull { file ->
            val lower = file.name.lowercase()
            !lower.endsWith(".json") &&
            !lower.endsWith("-wal") &&
            !lower.endsWith("-shm") &&
            !lower.endsWith("-journal") &&
            !lower.endsWith(".bin") &&
            (lower == AidDatabase.DATABASE_NAME.lowercase() ||
             lower.contains("aid_database") ||
             lower.endsWith(".db") ||
             lower.endsWith(".sqlite"))
        }

        return dbFile
    }

    /**
     * استرداد نسخة احتياطية مشفرة من Google Drive عبر الاستعادة المرحلية الآمنة قبل الإقلاع (Staged Pre-Boot Restore):
     * 1. تحميل الملف من Google Drive إلى مجلد مؤقت آمن داخل cacheDir.
     * 2. فك الضغط واستخراج ملف قاعدة البيانات المشفر (ومفتاح التشفير إن وجد) بالاسم والامتداد دون فحص الترويسة.
     * 3. حفظ الملف المستخرج في cacheDir وتخزين مساره في SharedPreferences تحت المفتاح cloud_pending_restore_path.
     * 4. إرجاع requiresRestart = true ليقوم المستخدم بإعادة تشغيل التطبيق فيلتقطه AidApplication قبل تهيئة Room/SQLCipher.
     */
    suspend fun restoreFromGoogleDrive(account: GoogleSignInAccount, fileId: String): CloudRestoreResult = restoreScope.async {
        val tempWorkDir = File(context.cacheDir, "cloud_restore_tmp_${System.currentTimeMillis()}")
        try {
            if (!tempWorkDir.exists()) tempWorkDir.mkdirs()

            DatabaseBackupManager.updateRestoreState(RestoreState.DOWNLOADING)
            val driveService = getDriveService(account)
            val downloadedFile = File(tempWorkDir, "cloud_backup_download.tmp")

            driveService.files().get(fileId).executeMediaAsInputStream().use { inputStream ->
                FileOutputStream(downloadedFile).use { fos ->
                    inputStream.copyTo(fos)
                    fos.flush()
                    fos.fd.sync()
                }
            }

            if (!downloadedFile.exists() || downloadedFile.length() < 100L) {
                throw IllegalStateException("ملف النسخة الاحتياطية السحابي فارغ أو غير مكتمل.")
            }

            DatabaseBackupManager.updateRestoreState(RestoreState.UNZIPPING)
            val extractDir = File(tempWorkDir, "extracted").apply { mkdirs() }
            val extractedDbFile: File?
            val extractedKeyFile: File?

            if (isZipArchive(downloadedFile)) {
                extractedDbFile = extractDatabaseFromArchive(downloadedFile, extractDir)
                val candidateKey = File(extractDir, "db_key.bin")
                extractedKeyFile = if (candidateKey.exists() && candidateKey.length() > 0L) candidateKey else null
            } else {
                extractedDbFile = downloadedFile
                extractedKeyFile = null
            }

            if (extractedDbFile == null || !extractedDbFile.exists() || extractedDbFile.length() < 100L) {
                throw IllegalStateException("تعذر العثور على ملف قاعدة البيانات المشفر داخل النسخة السحابية.")
            }

            DatabaseBackupManager.updateRestoreState(RestoreState.COPYING_FILES)
            val stagedDbFile = File(context.cacheDir, "pending_cloud_restore.db")
            if (stagedDbFile.exists()) stagedDbFile.delete()
            DatabaseBackupManager.copyFileWithSync(extractedDbFile, stagedDbFile)

            val stagedKeyFile: File? = if (extractedKeyFile != null) {
                val targetKey = File(context.cacheDir, "pending_cloud_restore_key.bin")
                if (targetKey.exists()) targetKey.delete()
                DatabaseBackupManager.copyFileWithSync(extractedKeyFile, targetKey)
                targetKey
            } else {
                null
            }

            val prefs = context.getSharedPreferences(DatabaseBackupManager.RESTORE_PREFS_NAME, Context.MODE_PRIVATE)
            val editor = prefs.edit()
                .putString(DatabaseBackupManager.KEY_CLOUD_PENDING_RESTORE_PATH, stagedDbFile.absolutePath)

            if (stagedKeyFile != null && stagedKeyFile.exists()) {
                editor.putString(DatabaseBackupManager.KEY_CLOUD_PENDING_KEY_PATH, stagedKeyFile.absolutePath)
            } else {
                editor.remove(DatabaseBackupManager.KEY_CLOUD_PENDING_KEY_PATH)
            }

            if (!editor.commit()) {
                throw IllegalStateException("تعذر حفظ مسار الاستعادة المؤقت في التفضيلات.")
            }

            DatabaseBackupManager.resetRestoreState()

            CloudRestoreResult(
                success = true,
                message = "تم تنزيل وتجهيز النسخة الاحتياطية السحابية بنجاح. يرجى إعادة تشغيل التطبيق الآن لإتمام الاستبدال.",
                requiresRestart = true
            )
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveRestore", "Restore failed: ${e.message}", e)
            val userFriendlyMessage = when {
                e is java.net.SocketTimeoutException || e.message?.contains("timed out", ignoreCase = true) == true ->
                    "انتهت مهلة الاتصال أثناء تحميل النسخة الاحتياطية من Google Drive. يرجى التحقق من اتصال الإنترنت وإعادة المحاولة."
                e.message?.contains("Software caused connection abort", ignoreCase = true) == true ||
                e.message?.contains("Connection reset", ignoreCase = true) == true ||
                e is java.net.SocketException ->
                    "انقطع الاتصال بخوادم Google أثناء التحميل. يرجى المحاولة مرة أخرى."
                else ->
                    "فشلت استعادة النسخة السحابية: ${e.localizedMessage ?: e.message}"
            }
            DatabaseBackupManager.updateRestoreState(RestoreState.ERROR(userFriendlyMessage, "استعادة من Google Drive"))
            CloudRestoreResult(
                success = false,
                message = userFriendlyMessage,
                requiresRestart = false
            )
        } finally {
            try {
                if (tempWorkDir.exists()) tempWorkDir.deleteRecursively()
            } catch (_: Exception) {}
        }
    }.await()


    /**
     * إعادة تشغيل التطبيق بشكل آمن لضمان فتح قاعدة بيانات Room بعد الاستبدال
     */
    fun restartApplication() {
        DatabaseBackupManager.restartApplication(context)
    }

    private fun addFileToZip(zos: ZipOutputStream, file: File, entryName: String) {
        val entry = ZipEntry(entryName)
        zos.putNextEntry(entry)
        FileInputStream(file).use { fis ->
            fis.copyTo(zos)
        }
        zos.flush()
        zos.closeEntry()
    }
}
