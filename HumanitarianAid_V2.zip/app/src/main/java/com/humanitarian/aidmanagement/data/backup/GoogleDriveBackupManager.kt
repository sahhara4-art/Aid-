package com.humanitarian.aidmanagement.data.backup

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Process
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.google.api.services.drive.model.FileList
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * عنصر يمثل نسخة احتياطية سحابية محفوظة على Google Drive
 */
data class CloudBackupItem(
    val fileId: String,
    val fileName: String,
    val sizeBytes: Long,
    val createdTimeFormatted: String,
    val timestamp: Long,
    val description: String = ""
)

data class CloudBackupResult(
    val success: Boolean,
    val message: String,
    val fileId: String? = null,
    val fileName: String? = null,
    val sizeBytes: Long = 0L
)

data class CloudRestoreResult(
    val success: Boolean,
    val message: String,
    val requiresRestart: Boolean = false
)

/**
 * مدير النسخ الاحتياطي السحابي الفعلي المتكامل مع Google Drive REST API v3
 * يقوم بالآتي:
 * 1. تهيئة Google Sign-In باستخدام Scope ملفات Drive (DRIVE_FILE).
 * 2. حفظ ملفات قاعدة بيانات Room الثلاثة (.db, -wal, -shm) داخل ملف أرشيف مضغوط (.zip).
 * 3. إنشاء مجلد سحابي "HumanitarianAid_Backups" ورفع النسخة مع تفاصيل البيانات.
 * 4. استرجاع النسخ السحابية وتنزيلها واستبدال القاعدة المحلية وإعادة تشغيل التطبيق.
 */
class GoogleDriveBackupManager(
    private val context: Context,
    private val database: AidDatabase
) {
    companion object {
        const val BACKUP_FOLDER_NAME = "HumanitarianAid_Backups"
        const val MIME_TYPE_FOLDER = "application/vnd.google-apps.folder"
        const val MIME_TYPE_ZIP = "application/zip"
    }

    private val jsonFactory = GsonFactory.getDefaultInstance()
    private val httpTransport = NetHttpTransport()

    /**
     * إعدادات عميل تسجيل الدخول بحساب Google مع صلاحية Drive File
     */
    fun getGoogleSignInClient(): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(DriveScopes.DRIVE_FILE))
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    /**
     * الحصول على آخر حساب تم تسجيل الدخول به ولديه الصلاحيات
     */
    fun getSignedInAccount(): GoogleSignInAccount? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return if (account != null && GoogleSignIn.hasPermissions(account, Scope(DriveScopes.DRIVE_FILE))) {
            account
        } else {
            null
        }
    }

    /**
     * بناء عميل خدمة Google Drive API v3 المرتبط بحساب المستخدم المعتمد
     */
    private fun getDriveService(account: GoogleSignInAccount): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(
            context,
            Collections.singleton(DriveScopes.DRIVE_FILE)
        ).apply {
            selectedAccount = account.account
        }

        return Drive.Builder(httpTransport, jsonFactory, credential)
            .setApplicationName("Humanitarian Aid Management")
            .build()
    }

    /**
     * البحث عن المجلد السحابي المخصص للنسخ أو إنشاؤه إذا لم يكن موجوداً
     */
    private suspend fun getOrCreateBackupFolderId(driveService: Drive): String = withContext(Dispatchers.IO) {
        val query = "mimeType = '$MIME_TYPE_FOLDER' and name = '$BACKUP_FOLDER_NAME' and trashed = false"
        val result: FileList = driveService.files().list()
            .setQ(query)
            .setSpaces("drive")
            .setFields("files(id, name)")
            .execute()

        val existingFolder = result.files?.firstOrNull()
        if (existingFolder != null) {
            return@withContext existingFolder.id
        }

        // إنشاء المجلد إذا لم يكن موجوداً
        val folderMetadata = DriveFile().apply {
            name = BACKUP_FOLDER_NAME
            mimeType = MIME_TYPE_FOLDER
            description = "مجلد النسخ الاحتياطية المشفرة لنظام إدارة المساعدات الإنسانية"
        }

        val createdFolder = driveService.files().create(folderMetadata)
            .setFields("id")
            .execute()

        createdFolder.id
    }

    /**
     * رفع نسخة احتياطية متكاملة لقاعدة بيانات Room إلى Google Drive
     */
    suspend fun backupToGoogleDrive(account: GoogleSignInAccount): CloudBackupResult = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val folderId = getOrCreateBackupFolderId(driveService)

            // 1. إجبار قاعدة البيانات على دمج كافة التعديلات المعلقة من الذاكرة (WAL) إلى الملف الرئيسي
            try {
                database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
            } catch (e: Exception) {
                android.util.Log.w("GoogleDriveBackup", "wal_checkpoint FULL: ${e.message}")
            }

            // 2. استدعاء database.close() فوراً لفك حجز الملف وتدمير مرجع Singleton
            try {
                database.close()
            } catch (e: Exception) {
                android.util.Log.w("GoogleDriveBackup", "database.close(): ${e.message}")
            }
            AidDatabase.resetInstance()

            val dbPath = context.getDatabasePath(AidDatabase.DATABASE_NAME)

            if (!dbPath.exists()) {
                return@withContext CloudBackupResult(
                    success = false,
                    message = "لم يتم العثور على ملف قاعدة البيانات المحلي (${dbPath.name})"
                )
            }

            // إنشاء ملف الأرشيف المؤقت مع الميتاداتا
            val timestamp = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(timestamp))
            val backupFileName = "aid_backup_$dateStr.zip"
            val tempZipFile = File(context.cacheDir, backupFileName)

            val metaObj = JSONObject().apply {
                put("timestamp", timestamp)
                put("date", dateStr)
                put("databaseName", AidDatabase.DATABASE_NAME)
                put("dbSizeBytes", dbPath.length())
            }

            // 3. نسخ ملف قاعدة البيانات (.db) فقط مدمجاً بالكامل دون أي ملفات WAL معلقة
            ZipOutputStream(FileOutputStream(tempZipFile)).use { zos ->
                // إضافة الميتاداتا
                zos.putNextEntry(ZipEntry("metadata.json"))
                zos.write(metaObj.toString(2).toByteArray(Charsets.UTF_8))
                zos.flush()
                zos.closeEntry()

                // إضافة ملف .db فقط مدمجاً بالكامل
                zos.putNextEntry(ZipEntry(dbPath.name))
                FileInputStream(dbPath).use { input ->
                    input.copyTo(zos)
                }
                zos.flush()
                zos.closeEntry()
            }

            // رفع الملف إلى Google Drive
            val driveMetadata = DriveFile().apply {
                name = backupFileName
                parents = listOf(folderId)
                description = "نسخة احتياطية كاملة لقاعدة بيانات Room بتاريخ $dateStr"
            }

            val mediaContent = FileContent(MIME_TYPE_ZIP, tempZipFile)
            val uploadedFile = driveService.files().create(driveMetadata, mediaContent)
                .setFields("id, name, size")
                .execute()

            // حذف الملف المؤقت بعد الرفع
            tempZipFile.delete()

            CloudBackupResult(
                success = true,
                message = "تم رفع النسخة الاحتياطية السحابية بنجاح إلى مجلد $BACKUP_FOLDER_NAME على Google Drive",
                fileId = uploadedFile.id,
                fileName = uploadedFile.name,
                sizeBytes = uploadedFile.getSize() ?: tempZipFile.length()
            )
        } catch (e: Exception) {
            CloudBackupResult(
                success = false,
                message = "فشل النسخ الاحتياطي السحابي: ${e.localizedMessage ?: e.message}"
            )
        }
    }

    /**
     * استعراض قائمة النسخ السحابية المحفوظة في مجلد HumanitarianAid_Backups
     */
    suspend fun listGoogleDriveBackups(account: GoogleSignInAccount): List<CloudBackupItem> = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val folderId = getOrCreateBackupFolderId(driveService)

            val query = "'$folderId' in parents and mimeType = '$MIME_TYPE_ZIP' and trashed = false"
            val fileList = driveService.files().list()
                .setQ(query)
                .setSpaces("drive")
                .setFields("files(id, name, size, createdTime, description)")
                .setOrderBy("createdTime desc")
                .execute()

            fileList.files?.map { file ->
                val createdTimeMillis = file.createdTime?.value ?: 0L
                val dateFormatted = if (createdTimeMillis > 0) {
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(createdTimeMillis))
                } else "غير محدد"

                CloudBackupItem(
                    fileId = file.id,
                    fileName = file.name ?: "نسخة احتياطية بدون اسم",
                    sizeBytes = file.getSize() ?: 0L,
                    createdTimeFormatted = dateFormatted,
                    timestamp = createdTimeMillis,
                    description = file.description ?: ""
                )
            } ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * استرداد نسخة احتياطية من Google Drive واستبدال قاعدة البيانات المحلية وفق الخطوات الأربع الصارمة:
     * 1. إغلاق قاعدة البيانات أولاً: database.close()
     * 2. حذف ملفات الكاش القديمة: wal & shm
     * 3. استبدال الملف بأمان: نسخ ملف النسخة الاحتياطية إلى مسار قاعدة البيانات الأصلية
     * 4. إعادة تشغيل التطبيق برمجياً: Programmatic Restart via Intent + exitProcess(0)
     */
    suspend fun restoreFromGoogleDrive(account: GoogleSignInAccount, fileId: String): CloudRestoreResult = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val downloadZipFile = File(context.cacheDir, "restore_temp.zip")

            FileOutputStream(downloadZipFile).use { outputStream ->
                driveService.files().get(fileId).executeMediaAndDownloadTo(outputStream)
            }

            val dbPath = context.getDatabasePath(AidDatabase.DATABASE_NAME)
            val walPath = File(dbPath.path + "-wal")
            val shmPath = File(dbPath.path + "-shm")
            val journalPath = File(dbPath.path + "-journal")

            // فك الضغط في مجلد مؤقت
            val extractDir = File(context.cacheDir, "restored_extracted")
            if (extractDir.exists()) extractDir.deleteRecursively()
            extractDir.mkdirs()

            ZipInputStream(FileInputStream(downloadZipFile)).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val outFile = File(extractDir, entry.name)
                    FileOutputStream(outFile).use { fos ->
                        zis.copyTo(fos)
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            val extractedDb = File(extractDir, AidDatabase.DATABASE_NAME).takeIf { it.exists() }
                ?: extractDir.listFiles()?.firstOrNull { it.extension in listOf("db", "sqlite") }

            if (extractedDb == null || !extractedDb.exists()) {
                downloadZipFile.delete()
                extractDir.deleteRecursively()
                return@withContext CloudRestoreResult(
                    success = false,
                    message = "ملف النسخة الاحتياطية السحابية غير صالح: لا يحتوي على ${AidDatabase.DATABASE_NAME}"
                )
            }

            val dbName = AidDatabase.DATABASE_NAME

            // الخطوة الأولى (الإغلاق): استدعِ database.close() وتأكد من تدمير أي مرجع (Singleton instance)
            try {
                database.close()
            } catch (e: Exception) {
                android.util.Log.w("GoogleDriveBackup", "database.close(): ${e.message}")
            }
            AidDatabase.resetInstance()

            // الخطوة الثانية (التنظيف العميق): حذف ملفات الذاكرة المؤقتة (WAL & SHM) من مسار قواعد البيانات في الجهاز
            val dbFile = context.getDatabasePath(dbName)
            try { dbFile.delete() } catch (_: Exception) {}
            try { File(dbFile.path + "-wal").delete() } catch (_: Exception) {}
            try { File(dbFile.path + "-shm").delete() } catch (_: Exception) {}
            try { File(dbFile.path + "-journal").delete() } catch (_: Exception) {}

            // الخطوة الثالثة (الاستبدال الآمن): نسخ ملف النسخة الاحتياطية المستعاد ليحل محل dbFile مع flush() و fd.sync()
            dbFile.parentFile?.mkdirs()

            FileInputStream(extractedDb).use { input ->
                FileOutputStream(dbFile).use { output ->
                    input.copyTo(output)
                    output.flush()
                    try {
                        output.fd.sync()
                    } catch (e: Exception) {
                        android.util.Log.w("GoogleDriveBackup", "fd.sync(): ${e.message}")
                    }
                }
            }

            // تنظيف الملفات المؤقتة
            downloadZipFile.delete()
            extractDir.deleteRecursively()

            // الخطوة الرابعة: إعادة التشغيل الإجباري النظيف (Cold Restart)
            DatabaseBackupManager.restartApplication(context)

            CloudRestoreResult(
                success = true,
                message = "تمت استعادة قاعدة البيانات السحابية بنجاح وجاري إعادة تشغيل التطبيق.",
                requiresRestart = true
            )
        } catch (e: Exception) {
            CloudRestoreResult(
                success = false,
                message = "فشلت استعادة النسخة السحابية: ${e.localizedMessage ?: e.message}"
            )
        }
    }

    /**
     * إعادة تشغيل التطبيق بشكل آمن لضمان فتح قاعدة بيانات Room بعد الاستبدال
     */
    fun restartApplication() {
        DatabaseBackupManager.restartApplication(context)
    }

    private fun addFileToZip(zos: ZipOutputStream, file: File, entryName: String) {
        val entry = ZipEntry(entryName)
        zos.putNextEntry(entry)
        FileInputStream(file).use { fis ->
            fis.copyTo(zos)
        }
        zos.flush()
        zos.closeEntry()
    }
}
