package com.humanitarian.aidmanagement.data.backup

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Process
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.Scopes
import com.google.android.gms.common.api.Scope
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.google.api.services.drive.model.FileList
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * عنصر يمثل نسخة احتياطية سحابية محفوظة على Google Drive
 */
data class CloudBackupItem(
    val fileId: String,
    val fileName: String,
    val sizeBytes: Long,
    val createdTimeFormatted: String,
    val timestamp: Long,
    val description: String = ""
)

data class CloudBackupResult(
    val success: Boolean,
    val message: String,
    val fileId: String? = null,
    val fileName: String? = null,
    val sizeBytes: Long = 0L
)

data class CloudRestoreResult(
    val success: Boolean,
    val message: String,
    val requiresRestart: Boolean = false
)

/**
 * مدير النسخ الاحتياطي السحابي الفعلي المتكامل مع Google Drive REST API v3
 * يقوم بالآتي:
 * 1. تهيئة Google Sign-In باستخدام Scope ملفات Drive (DRIVE_FILE).
 * 2. حفظ ملفات قاعدة بيانات Room الثلاثة (.db, -wal, -shm) داخل ملف أرشيف مضغوط (.zip).
 * 3. إنشاء مجلد سحابي "HumanitarianAid_Backups" ورفع النسخة مع تفاصيل البيانات.
 * 4. استرجاع النسخ السحابية وتنزيلها واستبدال القاعدة المحلية وإعادة تشغيل التطبيق.
 */
class GoogleDriveBackupManager(
    private val context: Context,
    private val database: AidDatabase
) {
    companion object {
        const val BACKUP_FOLDER_NAME = "HumanitarianAid_Backups"
        const val MIME_TYPE_FOLDER = "application/vnd.google-apps.folder"
        const val MIME_TYPE_ZIP = "application/zip"

        /**
         * معرّف عميل الويب (Web Client ID - Client type 3) المعتمد من Firebase Console
         * لتمكين مصادقة Google Sign-In وتوليد ID Token وصلاحيات Google Drive API
         */
        const val WEB_CLIENT_ID = "915149520150-g3h23roq89at901od3ui4tohuo1a9f9a.apps.googleusercontent.com"
    }

    private val jsonFactory = GsonFactory.getDefaultInstance()
    private val httpTransport = NetHttpTransport()

    /**
     * إعدادات عميل تسجيل الدخول بحساب Google مع صلاحية Drive File وطلب معرف الـ ID Token
     */
    fun getGoogleSignInClient(webClientId: String = WEB_CLIENT_ID): GoogleSignInClient {
        val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(Scopes.DRIVE_FILE))

        // استخدام Web Client ID المعتمد لطلب معرف الهوية
        if (webClientId.isNotBlank()) {
            builder.requestIdToken(webClientId)
        }

        return GoogleSignIn.getClient(context, builder.build())
    }

    /**
     * الحصول على آخر حساب تم تسجيل الدخول به ولديه الصلاحيات
     */
    fun getSignedInAccount(): GoogleSignInAccount? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return if (account != null && GoogleSignIn.hasPermissions(account, Scope(Scopes.DRIVE_FILE))) {
            account
        } else {
            null
        }
    }

    /**
     * تهيئة وإنشاء عميل GoogleDriveManager للحساب المعتمد
     */
    fun createDriveManager(account: GoogleSignInAccount): GoogleDriveManager {
        return GoogleDriveManager(context, account)
    }

    /**
     * بناء عميل خدمة Google Drive API v3 المرتبط بحساب المستخدم المعتمد
     */
    private fun getDriveService(account: GoogleSignInAccount): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(
            context,
            Collections.singleton(DriveScopes.DRIVE_FILE)
        ).apply {
            selectedAccount = account.account
        }

        return Drive.Builder(httpTransport, jsonFactory, credential)
            .setApplicationName("Humanitarian Aid Management")
            .build()
    }

    /**
     * البحث عن المجلد السحابي المخصص للنسخ أو إنشاؤه إذا لم يكن موجوداً
     */
    private suspend fun getOrCreateBackupFolderId(driveService: Drive): String = withContext(Dispatchers.IO) {
        val query = "mimeType = '$MIME_TYPE_FOLDER' and name = '$BACKUP_FOLDER_NAME' and trashed = false"
        val result: FileList = driveService.files().list()
            .setQ(query)
            .setSpaces("drive")
            .setFields("files(id, name)")
            .execute()

        val existingFolder = result.files?.firstOrNull()
        if (existingFolder != null) {
            return@withContext existingFolder.id
        }

        // إنشاء المجلد إذا لم يكن موجوداً
        val folderMetadata = DriveFile().apply {
            name = BACKUP_FOLDER_NAME
            mimeType = MIME_TYPE_FOLDER
            description = "مجلد النسخ الاحتياطية المشفرة لنظام إدارة المساعدات الإنسانية"
        }

        val createdFolder = driveService.files().create(folderMetadata)
            .setFields("id")
            .execute()

        createdFolder.id
    }

    /**
     * رفع نسخة احتياطية متكاملة لقاعدة بيانات Room إلى Google Drive
     */
    suspend fun backupToGoogleDrive(account: GoogleSignInAccount): CloudBackupResult = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val folderId = getOrCreateBackupFolderId(driveService)

            // 1. إجبار قاعدة البيانات على دمج كافة التعديلات المعلقة من الذاكرة (WAL) إلى الملف الرئيسي وحذف ملفات WAL
            try {
                database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(TRUNCATE)").close()
            } catch (e: Exception) {
                android.util.Log.w("GoogleDriveBackup", "wal_checkpoint TRUNCATE: ${e.message}")
            }

            // 2. استدعاء database.close() فوراً لفك حجز الملف وتدمير مرجع Singleton
            try {
                database.close()
            } catch (e: Exception) {
                android.util.Log.w("GoogleDriveBackup", "database.close(): ${e.message}")
            }
            AidDatabase.resetInstance()

            // 3. انتظار 500ms لضمان كتابة WAL بالكامل إلى القرص
            delay(500)

            val dbPath = context.getDatabasePath(AidDatabase.DATABASE_NAME)
            val parentDir = dbPath.parentFile ?: File(context.filesDir.parentFile, "databases")

            if (!dbPath.exists()) {
                try { AidDatabase.reestablishConnection(context) } catch (_: Exception) {}
                return@withContext CloudBackupResult(
                    success = false,
                    message = "لم يتم العثور على ملف قاعدة البيانات المحلي (${dbPath.name})"
                )
            }

            val walFile = File(parentDir, "${AidDatabase.DATABASE_NAME}-wal")
            val shmFile = File(parentDir, "${AidDatabase.DATABASE_NAME}-shm")

            // إنشاء ملف الأرشيف المؤقت مع الميتاداتا
            val timestamp = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(timestamp))
            val backupFileName = "aid_backup_$dateStr.zip"
            val tempZipFile = File(context.cacheDir, backupFileName)

            val metaObj = JSONObject().apply {
                put("timestamp", timestamp)
                put("date", dateStr)
                put("databaseName", AidDatabase.DATABASE_NAME)
                put("dbSizeBytes", dbPath.length())
            }

            // 4. ضغط ملف قاعدة البيانات المدمج بالكامل (.db) مع ملف البيانات الوصفية فقط
            ZipOutputStream(FileOutputStream(tempZipFile)).use { zos ->
                // إضافة الميتاداتا
                zos.putNextEntry(ZipEntry("metadata.json"))
                zos.write(metaObj.toString(2).toByteArray(Charsets.UTF_8))
                zos.flush()
                zos.closeEntry()

                // إضافة ملف .db
                zos.putNextEntry(ZipEntry(dbPath.name))
                FileInputStream(dbPath).use { input ->
                    input.copyTo(zos)
                }
                zos.flush()
                zos.closeEntry()
            }

            // 5. إعادة بناء الاتصال المحلي حتى لا تفشل عمليات الواجهة
            try {
                AidDatabase.reestablishConnection(context)
            } catch (e: Exception) {
                android.util.Log.w("GoogleDriveBackup", "reestablishConnection: ${e.message}")
            }

            // رفع الملف إلى Google Drive
            val driveMetadata = DriveFile().apply {
                name = backupFileName
                parents = listOf(folderId)
                description = "نسخة احتياطية كاملة لقاعدة بيانات Room بتاريخ $dateStr"
            }

            val mediaContent = FileContent(MIME_TYPE_ZIP, tempZipFile)
            val uploadedFile = driveService.files().create(driveMetadata, mediaContent)
                .setFields("id, name, size")
                .execute()

            // حذف الملف المؤقت بعد الرفع
            tempZipFile.delete()

            CloudBackupResult(
                success = true,
                message = "تم رفع النسخة الاحتياطية السحابية بنجاح إلى مجلد $BACKUP_FOLDER_NAME على Google Drive",
                fileId = uploadedFile.id,
                fileName = uploadedFile.name,
                sizeBytes = uploadedFile.getSize() ?: tempZipFile.length()
            )
        } catch (e: Exception) {
            CloudBackupResult(
                success = false,
                message = "فشل النسخ الاحتياطي السحابي: ${e.localizedMessage ?: e.message}"
            )
        }
    }

    /**
     * استعراض قائمة النسخ السحابية المحفوظة في مجلد HumanitarianAid_Backups
     */
    suspend fun listGoogleDriveBackups(account: GoogleSignInAccount): List<CloudBackupItem> = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val folderId = getOrCreateBackupFolderId(driveService)

            val query = "'$folderId' in parents and mimeType = '$MIME_TYPE_ZIP' and trashed = false"
            val fileList = driveService.files().list()
                .setQ(query)
                .setSpaces("drive")
                .setFields("files(id, name, size, createdTime, description)")
                .setOrderBy("createdTime desc")
                .execute()

            fileList.files?.map { file ->
                val createdTimeMillis = file.createdTime?.value ?: 0L
                val dateFormatted = if (createdTimeMillis > 0) {
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(createdTimeMillis))
                } else "غير محدد"

                CloudBackupItem(
                    fileId = file.id,
                    fileName = file.name ?: "نسخة احتياطية بدون اسم",
                    sizeBytes = file.getSize() ?: 0L,
                    createdTimeFormatted = dateFormatted,
                    timestamp = createdTimeMillis,
                    description = file.description ?: ""
                )
            } ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * استرداد نسخة احتياطية من Google Drive بنمط العزل المؤجل (Staged Pre-Boot Restore):
     * 1. تنزيل ملف ZIP إلى ملف مؤقت
     * 2. نقله إلى مجلد الحجر المؤقت cacheDir/restore_stage دون لمس قاعدة البيانات الحية
     * 3. التحقق من وجود ملف .db وتعيين PENDING_DB_RESTORE = true
     * 4. إشعار المستخدم وإعادة تشغيل التطبيق بارداً ليقوم المعترض بالاستبدال قبل فتح Room
     */
    suspend fun restoreFromGoogleDrive(account: GoogleSignInAccount, fileId: String): CloudRestoreResult = withContext(Dispatchers.IO) {
        val downloadZipFile = File(context.cacheDir, "restore_drive_${System.currentTimeMillis()}.zip")
        try {
            val driveService = getDriveService(account)

            // تنزيل ملف ZIP من Google Drive
            FileOutputStream(downloadZipFile).use { outputStream ->
                driveService.files().get(fileId).executeMediaAndDownloadTo(outputStream)
                outputStream.flush()
            }

            if (!downloadZipFile.exists() || downloadZipFile.length() == 0L) {
                return@withContext CloudRestoreResult(
                    success = false,
                    message = "فشل تنزيل ملف النسخة الاحتياطية من Google Drive أو أن الملف فارغ"
                )
            }

            // إغلاق قاعدة البيانات الحالية لفك أي أقفال نشطة قبل بدء الاستعادة
            try { database.close() } catch (e: Exception) { android.util.Log.w("GoogleDriveBackup", "database.close(): ${e.message}") }
            AidDatabase.resetInstance()

            // تجهيز الاستعادة في مجلد الحجر الصحي
            val backupManager = DatabaseBackupManager(context, database)
            val stageResult = backupManager.stageRestoreFromFile(downloadZipFile)

            if (!stageResult.success) {
                return@withContext CloudRestoreResult(
                    success = false,
                    message = stageResult.message
                )
            }

            // إشعار المستخدم بالتوست وبدء إعادة التشغيل البارد النظيف
            backupManager.triggerColdRestart()

            CloudRestoreResult(
                success = true,
                message = "تم تجهيز النسخة، سيتم إعادة تشغيل التطبيق لتطبيقها",
                requiresRestart = true
            )
        } catch (e: Exception) {
            CloudRestoreResult(
                success = false,
                message = "فشلت استعادة النسخة السحابية: ${e.localizedMessage ?: e.message}"
            )
        } finally {
            try { downloadZipFile.delete() } catch (_: Exception) {}
        }
    }

    /**
     * إعادة تشغيل التطبيق بشكل آمن لضمان فتح قاعدة بيانات Room بعد الاستبدال
     */
    fun restartApplication() {
        DatabaseBackupManager.restartApplication(context)
    }

    private fun addFileToZip(zos: ZipOutputStream, file: File, entryName: String) {
        val entry = ZipEntry(entryName)
        zos.putNextEntry(entry)
        FileInputStream(file).use { fis ->
            fis.copyTo(zos)
        }
        zos.flush()
        zos.closeEntry()
    }
}
