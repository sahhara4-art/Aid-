package com.humanitarian.aidmanagement.data.backup

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Process
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.Scopes
import com.google.android.gms.common.api.Scope
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.http.FileContent
import com.google.api.client.http.javanet.NetHttpTransport
import com.google.api.client.json.gson.GsonFactory
import com.google.api.services.drive.Drive
import com.google.api.services.drive.DriveScopes
import com.google.api.services.drive.model.File as DriveFile
import com.google.api.services.drive.model.FileList
import com.humanitarian.aidmanagement.data.local.AidDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * عنصر يمثل نسخة احتياطية سحابية محفوظة على Google Drive
 */
data class CloudBackupItem(
    val fileId: String,
    val fileName: String,
    val sizeBytes: Long,
    val createdTimeFormatted: String,
    val timestamp: Long,
    val description: String = ""
)

data class CloudBackupResult(
    val success: Boolean,
    val message: String,
    val fileId: String? = null,
    val fileName: String? = null,
    val sizeBytes: Long = 0L
)

data class CloudRestoreResult(
    val success: Boolean,
    val message: String,
    val requiresRestart: Boolean = false
)

/**
 * مدير النسخ الاحتياطي السحابي الفعلي المتكامل مع Google Drive REST API v3
 * يقوم بالآتي:
 * 1. تهيئة Google Sign-In باستخدام Scope ملفات Drive (DRIVE_FILE).
 * 2. حفظ ملفات قاعدة بيانات Room الثلاثة (.db, -wal, -shm) داخل ملف أرشيف مضغوط (.zip).
 * 3. إنشاء مجلد سحابي "HumanitarianAid_Backups" ورفع النسخة مع تفاصيل البيانات.
 * 4. استرجاع النسخ السحابية وتنزيلها واستبدال القاعدة المحلية وإعادة تشغيل التطبيق.
 */
class GoogleDriveBackupManager(
    private val context: Context,
    private val database: AidDatabase
) {
    companion object {
        const val BACKUP_FOLDER_NAME = "HumanitarianAid_Backups"
        const val MIME_TYPE_FOLDER = "application/vnd.google-apps.folder"
        const val MIME_TYPE_ZIP = "application/zip"

        /**
         * معرّف عميل الويب (Web Client ID - Client type 3) المعتمد من Firebase Console
         * لتمكين مصادقة Google Sign-In وتوليد ID Token وصلاحيات Google Drive API
         */
        const val WEB_CLIENT_ID = "915149520150-g3h23roq89at901od3ui4tohuo1a9f9a.apps.googleusercontent.com"
    }

    private val jsonFactory = GsonFactory.getDefaultInstance()
    private val httpTransport = NetHttpTransport()
    private val restoreScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /**
     * إعدادات عميل تسجيل الدخول بحساب Google مع صلاحية Drive File وطلب معرف الـ ID Token
     */
    fun getGoogleSignInClient(webClientId: String = WEB_CLIENT_ID): GoogleSignInClient {
        val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(Scopes.DRIVE_FILE))

        // استخدام Web Client ID المعتمد لطلب معرف الهوية
        if (webClientId.isNotBlank()) {
            builder.requestIdToken(webClientId)
        }

        return GoogleSignIn.getClient(context, builder.build())
    }

    /**
     * الحصول على آخر حساب تم تسجيل الدخول به ولديه الصلاحيات
     */
    fun getSignedInAccount(): GoogleSignInAccount? {
        val account = GoogleSignIn.getLastSignedInAccount(context)
        return if (account != null && GoogleSignIn.hasPermissions(account, Scope(Scopes.DRIVE_FILE))) {
            account
        } else {
            null
        }
    }

    /**
     * تهيئة وإنشاء عميل GoogleDriveManager للحساب المعتمد
     */
    fun createDriveManager(account: GoogleSignInAccount): GoogleDriveManager {
        return GoogleDriveManager(context, account)
    }

    /**
     * بناء عميل خدمة Google Drive API v3 المرتبط بحساب المستخدم المعتمد
     */
    private fun getDriveService(account: GoogleSignInAccount): Drive {
        val credential = GoogleAccountCredential.usingOAuth2(
            context,
            Collections.singleton(DriveScopes.DRIVE_FILE)
        ).apply {
            selectedAccount = account.account
        }

        // تمديد مهلة الاتصال والقراءة إلى 60 ثانية (60,000 مللي ثانية) لتجنب انقطاع تحميل الملفات الكبيرة
        val requestInitializer = com.google.api.client.http.HttpRequestInitializer { request ->
            credential.initialize(request)
            request.connectTimeout = 60000 // 60s مهلة الاتصال
            request.readTimeout = 60000    // 60s مهلة قراءة البيانات المتدفقة
        }

        return Drive.Builder(httpTransport, jsonFactory, requestInitializer)
            .setApplicationName("Humanitarian Aid Management")
            .build()
    }

    /**
     * البحث عن المجلد السحابي المخصص للنسخ أو إنشاؤه إذا لم يكن موجوداً
     */
    private suspend fun getOrCreateBackupFolderId(driveService: Drive): String = withContext(Dispatchers.IO) {
        val query = "mimeType = '$MIME_TYPE_FOLDER' and name = '$BACKUP_FOLDER_NAME' and trashed = false"
        val result: FileList = driveService.files().list()
            .setQ(query)
            .setSpaces("drive")
            .setFields("files(id, name)")
            .execute()

        val existingFolder = result.files?.firstOrNull()
        if (existingFolder != null) {
            return@withContext existingFolder.id
        }

        // إنشاء المجلد إذا لم يكن موجوداً
        val folderMetadata = DriveFile().apply {
            name = BACKUP_FOLDER_NAME
            mimeType = MIME_TYPE_FOLDER
            description = "مجلد النسخ الاحتياطية المشفرة لنظام إدارة المساعدات الإنسانية"
        }

        val createdFolder = driveService.files().create(folderMetadata)
            .setFields("id")
            .execute()

        createdFolder.id
    }

    /**
     * رفع نسخة احتياطية متكاملة لقاعدة بيانات Room إلى Google Drive
     */
    suspend fun backupToGoogleDrive(account: GoogleSignInAccount): CloudBackupResult = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val folderId = getOrCreateBackupFolderId(driveService)

            // 1. استدعاء database.close() لفك حجز الملف وتدمير مرجع Singleton
            try {
                database.close()
            } catch (e: Exception) {
                android.util.Log.w("GoogleDriveBackup", "database.close(): ${e.message}")
            }
            AidDatabase.resetInstance()

            val dbPath = context.getDatabasePath("aid_database")

            if (!dbPath.exists()) {
                try { AidDatabase.reestablishConnection(context) } catch (_: Exception) {}
                return@withContext CloudBackupResult(
                    success = false,
                    message = "لم يتم العثور على ملف قاعدة البيانات المحلي (${dbPath.name})"
                )
            }

            // إنشاء ملف الأرشيف المؤقت مع الميتاداتا
            val timestamp = System.currentTimeMillis()
            val dateStr = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date(timestamp))
            val backupFileName = "aid_backup_$dateStr.zip"
            val tempZipFile = File(context.cacheDir, backupFileName)

            val metaObj = JSONObject().apply {
                put("timestamp", timestamp)
                put("date", dateStr)
                put("databaseName", "aid_database")
                put("dbSizeBytes", dbPath.length())
            }

            // 2. ضغط ملف قاعدة البيانات الرئيسي الوحيد (.db) مع ملف البيانات الوصفية (بدون أي ملفات WAL أو SHM)
            ZipOutputStream(FileOutputStream(tempZipFile)).use { zos ->
                // إضافة الميتاداتا
                zos.putNextEntry(ZipEntry("metadata.json"))
                zos.write(metaObj.toString(2).toByteArray(Charsets.UTF_8))
                zos.flush()
                zos.closeEntry()

                // إضافة ملف .db
                zos.putNextEntry(ZipEntry("aid_database"))
                FileInputStream(dbPath).use { input ->
                    input.copyTo(zos)
                }
                zos.flush()
                zos.closeEntry()
            }

            // 3. إعادة بناء الاتصال المحلي حتى لا تفشل عمليات الواجهة
            try {
                AidDatabase.reestablishConnection(context)
            } catch (e: Exception) {
                android.util.Log.w("GoogleDriveBackup", "reestablishConnection: ${e.message}")
            }

            // رفع الملف إلى Google Drive
            val driveMetadata = DriveFile().apply {
                name = backupFileName
                parents = listOf(folderId)
                description = "نسخة احتياطية كاملة لقاعدة بيانات Room بتاريخ $dateStr"
            }

            val mediaContent = FileContent(MIME_TYPE_ZIP, tempZipFile)
            val uploadedFile = driveService.files().create(driveMetadata, mediaContent)
                .setFields("id, name, size")
                .execute()

            // حذف الملف المؤقت بعد الرفع
            tempZipFile.delete()

            CloudBackupResult(
                success = true,
                message = "تم رفع النسخة الاحتياطية السحابية بنجاح إلى مجلد $BACKUP_FOLDER_NAME على Google Drive",
                fileId = uploadedFile.id,
                fileName = uploadedFile.name,
                sizeBytes = uploadedFile.getSize() ?: tempZipFile.length()
            )
        } catch (e: Exception) {
            CloudBackupResult(
                success = false,
                message = "فشل النسخ الاحتياطي السحابي: ${e.localizedMessage ?: e.message}"
            )
        }
    }

    /**
     * استعراض قائمة النسخ السحابية المحفوظة في مجلد HumanitarianAid_Backups
     */
    suspend fun listGoogleDriveBackups(account: GoogleSignInAccount): List<CloudBackupItem> = withContext(Dispatchers.IO) {
        try {
            val driveService = getDriveService(account)
            val folderId = getOrCreateBackupFolderId(driveService)

            val query = "'$folderId' in parents and mimeType = '$MIME_TYPE_ZIP' and trashed = false"
            val fileList = driveService.files().list()
                .setQ(query)
                .setSpaces("drive")
                .setFields("files(id, name, size, createdTime, description)")
                .setOrderBy("createdTime desc")
                .execute()

            fileList.files?.map { file ->
                val createdTimeMillis = file.createdTime?.value ?: 0L
                val dateFormatted = if (createdTimeMillis > 0) {
                    SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(createdTimeMillis))
                } else "غير محدد"

                CloudBackupItem(
                    fileId = file.id,
                    fileName = file.name ?: "نسخة احتياطية بدون اسم",
                    sizeBytes = file.getSize() ?: 0L,
                    createdTimeFormatted = dateFormatted,
                    timestamp = createdTimeMillis,
                    description = file.description ?: ""
                )
            } ?: emptyList()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * التحقق مما إذا كان الملف يبدأ بترويسة أرشيف ZIP صالحة
     */
    private fun isZipArchive(file: File): Boolean {
        if (!file.exists() || file.length() < 4) return false
        return try {
            FileInputStream(file).use { fis ->
                val b = ByteArray(4)
                val read = fis.read(b)
                read == 4 && b[0] == 0x50.toByte() && b[1] == 0x4b.toByte() && (b[2] == 0x03.toByte() || b[2] == 0x05.toByte() || b[2] == 0x07.toByte())
            }
        } catch (_: Exception) { false }
    }

    /**
     * التحقق مما إذا كان الملف يحتوي على ترويسة SQLite الصريحة ("SQLite format 3")
     */
    private fun isSqliteHeader(file: File): Boolean {
        if (!file.exists() || file.length() < 16) return false
        return try {
            FileInputStream(file).use { fis ->
                val header = ByteArray(16)
                val read = fis.read(header)
                read >= 16 && String(header, 0, 15, Charsets.US_ASCII) == "SQLite format 3"
            }
        } catch (_: Exception) { false }
    }

    /**
     * فك ضغط ملف النسخة الاحتياطية واستخراج ملف قاعدة البيانات الأساسي (.db) كملف واحد فقط
     */
    private fun extractDatabaseFromArchive(zipFile: File, destinationDir: File): File? {
        if (!destinationDir.exists()) destinationDir.mkdirs()

        FileInputStream(zipFile).use { fis ->
            ZipInputStream(fis).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val entryPath = entry.name
                    val entryName = entryPath.substringAfterLast('/')
                    val isMacOrHidden = entryPath.contains("__MACOSX") || entryName.startsWith(".")

                    if (!entry.isDirectory && !isMacOrHidden) {
                        val destFile = File(destinationDir, entryName)
                        FileOutputStream(destFile).use { fos ->
                            zis.copyTo(fos)
                            fos.flush()
                            fos.fd.sync()
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }

        val allFiles = destinationDir.listFiles() ?: emptyArray()

        // البحث عن ملف قاعدة البيانات بالترويسة
        var dbFile = allFiles.firstOrNull { file ->
            !file.name.endsWith(".json") && isSqliteHeader(file)
        }

        // أو بالاسم والامتداد
        if (dbFile == null) {
            dbFile = allFiles.firstOrNull { file ->
                val lower = file.name.lowercase()
                !lower.endsWith(".json") &&
                (lower == "aid_database" ||
                 lower == "aid_database.db" ||
                 lower == AidDatabase.DATABASE_NAME.lowercase() ||
                 lower.endsWith(".db") ||
                 lower.endsWith(".sqlite"))
            }
        }

        return dbFile
    }

    /**
     * استرداد نسخة احتياطية من Google Drive تتبع التسلسل الصارم الخماسي داخل Dispatchers.IO:
     * 1. تحميل الملف: تحميل ملف .zip من Google Drive إلى مجلد مؤقت (Cache Directory).
     * 2. فك الضغط (Unzip): فك ضغط الملف المؤقت والتحقق من وجود الملفات الثلاثة (.db, .db-wal, .db-shm).
     * 3. الإغلاق: استدعاء database.close() وإغلاق اتصالات Room.
     * 4. النقل الآمن: نسخ الملفات الثلاثة المستخرجة إلى مسار قاعدة البيانات context.getDatabasePath("aid_database").path و DATABASE_NAME.
     * 5. إعادة التشغيل: إعادة تشغيل التطبيق (Restart Process) ليقوم Room بقراءة الملفات المفكوكة حديثاً.
     */
    suspend fun restoreFromGoogleDrive(account: GoogleSignInAccount, fileId: String): CloudRestoreResult = restoreScope.async {
        // 1. إنشاء المجلد الإجباري قبل أي كتابة
        val primaryDb = context.getDatabasePath("aid_database")
        primaryDb.parentFile?.mkdirs()
        val roomDb = context.getDatabasePath(AidDatabase.DATABASE_NAME)
        roomDb.parentFile?.mkdirs()
        val extDb = context.getDatabasePath("aid_database.db")
        extDb.parentFile?.mkdirs()

        val rollbackDir = File(context.cacheDir, "cloud_db_rollback_${System.currentTimeMillis()}").apply { mkdirs() }
        val rollbackDb = File(rollbackDir, "rollback_temp.db")
        var hasRollback = false

        val downloadZipFile = File(context.cacheDir, "restore_drive_${System.currentTimeMillis()}.zip")
        val unzipDir = File(context.cacheDir, "unzip_drive_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            // حفظ نسخة احتياطية للتراجع إذا كانت قاعدة البيانات الحالية موجودة
            if (primaryDb.exists() && primaryDb.length() > 0L) {
                try {
                    DatabaseBackupManager.copyFileWithSync(primaryDb, rollbackDb)
                    hasRollback = true
                } catch (e: Exception) {
                    android.util.Log.w("GoogleDriveRestore", "Rollback snapshot skipped: ${e.message}")
                }
            } else if (roomDb.exists() && roomDb.length() > 0L) {
                try {
                    DatabaseBackupManager.copyFileWithSync(roomDb, rollbackDb)
                    hasRollback = true
                } catch (e: Exception) {
                    android.util.Log.w("GoogleDriveRestore", "Rollback snapshot skipped: ${e.message}")
                }
            }

            val driveService = getDriveService(account)

            DatabaseBackupManager.updateRestoreState(RestoreState.DOWNLOADING)
            // تنزيل الملف المتدفق المباشر
            driveService.files().get(fileId).executeMediaAsInputStream().use { inputStream ->
                FileOutputStream(downloadZipFile).use { outputStream ->
                    inputStream.copyTo(outputStream)
                    outputStream.flush()
                    outputStream.fd.sync()
                }
            }

            if (!downloadZipFile.exists() || downloadZipFile.length() == 0L) {
                DatabaseBackupManager.updateRestoreState(RestoreState.ERROR("ملف النسخة الاحتياطية فارغ أو تعذر تحميله", "تحميل الملف"))
                return@async CloudRestoreResult(
                    success = false,
                    message = "فشل تنزيل ملف النسخة الاحتياطية من Google Drive أو أن الملف فارغ."
                )
            }

            DatabaseBackupManager.updateRestoreState(RestoreState.UNZIPPING)
            // استخراج ملف قاعدة البيانات الوحيد (TRUNCATE mode - ملف واحد فقط بدون wal أو shm)
            var extractedMainDb: File? = null
            if (isZipArchive(downloadZipFile)) {
                extractedMainDb = extractDatabaseFromArchive(downloadZipFile, unzipDir)
            } else if (isSqliteHeader(downloadZipFile)) {
                extractedMainDb = downloadZipFile
            }

            if (extractedMainDb == null || !extractedMainDb.exists() || extractedMainDb.length() == 0L) {
                DatabaseBackupManager.updateRestoreState(RestoreState.ERROR("لم يتم العثور على قاعدة بيانات SQLite صالحة داخل الملف", "فك الضغط"))
                return@async CloudRestoreResult(
                    success = false,
                    message = "فشل فك ضغط النسخة الاحتياطية: لم يتم العثور على قاعدة بيانات SQLite صالحة داخل الملف."
                )
            }

            // إغلاق قاعدة البيانات
            try {
                if (database.isOpen) {
                    database.close()
                }
            } catch (e: Exception) {
                android.util.Log.w("GoogleDriveRestore", "database.close() warning: ${e.message}")
            }
            AidDatabase.resetInstance()
            delay(350)

            DatabaseBackupManager.updateRestoreState(RestoreState.COPYING_FILES)
            // كتابة الملف المسترجع مباشرة مكان قاعدة البيانات الوحيدة
            DatabaseBackupManager.copyFileWithSync(extractedMainDb, primaryDb)
            if (roomDb.absolutePath != primaryDb.absolutePath) {
                DatabaseBackupManager.copyFileWithSync(primaryDb, roomDb)
            }
            if (extDb.absolutePath != primaryDb.absolutePath) {
                try { DatabaseBackupManager.copyFileWithSync(primaryDb, extDb) } catch (_: Exception) {}
            }

            DatabaseBackupManager.updateRestoreState(RestoreState.VERIFYING_INTEGRITY)
            if (!primaryDb.exists() || primaryDb.length() == 0L) {
                throw IllegalStateException("ملف قاعدة البيانات المسترجع غير موجود أو فارغ")
            }

            DatabaseBackupManager.updateRestoreState(RestoreState.SUCCESS)
            // القتل الإجباري للعملية بعد إظهار التنبيه
            withContext(Dispatchers.Main) {
                android.widget.Toast.makeText(
                    context,
                    "تمت استعادة قاعدة البيانات بنجاح! سيتم إغلاق التطبيق لتطبيق التغييرات، يرجى إعادة فتحه.",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
            delay(1500)
            kotlin.system.exitProcess(0)

            @Suppress("UNREACHABLE_CODE")
            CloudRestoreResult(
                success = true,
                message = "تمت استعادة قاعدة البيانات بنجاح!",
                requiresRestart = false
            )
        } catch (e: Exception) {
            android.util.Log.e("GoogleDriveRestore", "Restore failed: ${e.message}", e)

            if (hasRollback && rollbackDb.exists()) {
                try {
                    AidDatabase.resetInstance()
                    DatabaseBackupManager.copyFileWithSync(rollbackDb, primaryDb)
                    DatabaseBackupManager.copyFileWithSync(rollbackDb, roomDb)
                    AidDatabase.reestablishConnection(context)
                } catch (rollbackErr: Exception) {
                    android.util.Log.e("GoogleDriveRestore", "Rollback error: ${rollbackErr.message}")
                }
            }

            val userFriendlyMessage = when {
                e is java.net.SocketTimeoutException || e.message?.contains("timed out", ignoreCase = true) == true ->
                    "انتهت مهلة الاتصال أثناء تحميل النسخة الاحتياطية من Google Drive. يرجى التحقق من اتصال الإنترنت وإعادة المحاولة."
                e.message?.contains("Software caused connection abort", ignoreCase = true) == true ||
                e.message?.contains("Connection reset", ignoreCase = true) == true ||
                e is java.net.SocketException ->
                    "انقطع الاتصال بخوادم Google أثناء التحميل. يرجى المحاولة مرة أخرى."
                else ->
                    "فشلت استعادة النسخة السحابية: ${e.localizedMessage ?: e.message}"
            }
            DatabaseBackupManager.updateRestoreState(RestoreState.ERROR(userFriendlyMessage, "استعادة من Google Drive"))
            CloudRestoreResult(
                success = false,
                message = userFriendlyMessage
            )
        } finally {
            try { downloadZipFile.delete() } catch (_: Exception) {}
            try { unzipDir.deleteRecursively() } catch (_: Exception) {}
            try { rollbackDir.deleteRecursively() } catch (_: Exception) {}
        }
    }.await()


    /**
     * إعادة تشغيل التطبيق بشكل آمن لضمان فتح قاعدة بيانات Room بعد الاستبدال
     */
    fun restartApplication() {
        DatabaseBackupManager.restartApplication(context)
    }

    private fun addFileToZip(zos: ZipOutputStream, file: File, entryName: String) {
        val entry = ZipEntry(entryName)
        zos.putNextEntry(entry)
        FileInputStream(file).use { fis ->
            fis.copyTo(zos)
        }
        zos.flush()
        zos.closeEntry()
    }
}
