package com.humanitarian.aidmanagement.ui.screens.projects

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.humanitarian.aidmanagement.data.repository.AidRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreen(
    repository: AidRepository,
    onOpenDrawer: () -> Unit,
    onProjectClick: (Int) -> Unit
) {
    val projects by repository.getProjects().collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("المشاريع الإنسانية (${projects.size})", fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(projects) { p ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(p.projectName, fontWeight = FontWeight.Bold)
                        Text("الجهة الممولة: ${p.fundingOrganization}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
