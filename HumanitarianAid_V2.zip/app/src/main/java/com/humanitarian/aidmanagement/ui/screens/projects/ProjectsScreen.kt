package com.humanitarian.aidmanagement.ui.screens.projects

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.draw.scale
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.donor
import com.humanitarian.aidmanagement.data.local.entities.isOpen
import com.humanitarian.aidmanagement.data.local.entities.targetQuota
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.ProjectWithStats
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * MODULE 1: PROJECT MANAGEMENT BOUNDARY (Admin Only)
 * شاشة إدارة المشاريع الإنسانية المنفذة (ProjectsScreen / ProjectManagementScreen)
 * منفصلة تماماً عن شاشة محرك الترشيح العملياتي.
 */
@Composable
fun ProjectManagementScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToProjectDetails: (Long) -> Unit
) {
    ProjectsScreen(
        repository = repository,
        onNavigateBack = onNavigateBack,
        onNavigateToProjectDetails = onNavigateToProjectDetails
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToProjectDetails: (Long) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val currentUser by repository.currentUserFlow.collectAsStateWithLifecycle(initialValue = repository.getCurrentUser())
    val isManager = currentUser == null || currentUser?.RoleID == 1 || currentUser?.UserName?.equals("admin", ignoreCase = true) == true

    var searchQuery by remember { mutableStateOf("") }
    var projectsList by remember { mutableStateOf<List<ProjectWithStats>>(emptyList()) }
    var aidTypesList by remember { mutableStateOf<List<AidTypeEntity>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    // حوارات الإدارة (طرح، تعديل، حذف)
    var showCreateDialog by remember { mutableStateOf(false) }
    var projectToEdit by remember { mutableStateOf<ProjectEntity?>(null) }
    var projectToDelete by remember { mutableStateOf<ProjectEntity?>(null) }

    fun refreshProjects() {
        coroutineScope.launch {
            isLoading = true
            val (projectsData, aidTypesData) = withContext(Dispatchers.IO) {
                repository.getProjectsWithStats() to repository.getActiveAidTypesSync()
            }
            projectsList = projectsData
            aidTypesList = aidTypesData
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        refreshProjects()
    }

    val filteredProjects = remember(projectsList, searchQuery) {
        if (searchQuery.isBlank()) {
            projectsList
        } else {
            val q = searchQuery.trim().lowercase()
            projectsList.filter {
                it.project.projectName.lowercase().contains(q) ||
                it.project.projectNumber.lowercase().contains(q) ||
                it.aidTypeName.lowercase().contains(q) ||
                it.project.fundingInstitution.lowercase().contains(q)
            }
        }
    }

    val totalTarget = remember(projectsList) { projectsList.sumOf { it.project.quantity } }
    val totalCandidates = remember(projectsList) { projectsList.sumOf { it.candidatesCount } }
    val totalDelivered = remember(projectsList) { projectsList.sumOf { it.deliveredCount } }
    val openProjectsCount = remember(projectsList) { projectsList.count { it.project.isOpen } }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "إدارة المشاريع الإنسانية (Admin)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${projectsList.size} مشاريع مسجلة • $openProjectsCount مفتوح للترشيح",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = { refreshProjects() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = PalestineGreen)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            floatingActionButton = {
                if (isManager) {
                    ExtendedFloatingActionButton(
                        onClick = { showCreateDialog = true },
                        icon = { Icon(Icons.Default.Add, contentDescription = null) },
                        text = { Text("طرح مشروع جديد", fontWeight = FontWeight.Bold) },
                        containerColor = PalestineGreen,
                        contentColor = Color.White
                    )
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // شريط إحصائيات علوي سريع
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ProjectQuickMetric(
                            title = "المستهدف الكلي",
                            value = "$totalTarget",
                            icon = Icons.Default.TrackChanges,
                            color = PalestineGreen
                        )
                        Divider(modifier = Modifier.height(30.dp).width(1.dp), color = SlateBorder)
                        ProjectQuickMetric(
                            title = "المرشحون",
                            value = "$totalCandidates",
                            icon = Icons.Default.HowToReg,
                            color = Color(0xFF3B82F6)
                        )
                        Divider(modifier = Modifier.height(30.dp).width(1.dp), color = SlateBorder)
                        ProjectQuickMetric(
                            title = "المستلمون الفعليون",
                            value = "$totalDelivered",
                            icon = Icons.Default.CheckCircle,
                            color = Color(0xFF10B981)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // حقل البحث
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث بالرقم، الاسم، المانح أو نوع المساعدة...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = PalestineGreen) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = PalestineGreen)
                    }
                } else if (filteredProjects.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                Icons.Default.FolderOpen,
                                contentDescription = null,
                                modifier = Modifier.size(54.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                            )
                            Text(
                                text = "لا توجد مشاريع مطابقة للبحث",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 80.dp)
                    ) {
                        items(items = filteredProjects, key = { it.project.projectID }) { projectStat: ProjectWithStats ->
                            AdminProjectCard(
                                item = projectStat,
                                isManager = isManager,
                                onClick = { onNavigateToProjectDetails(projectStat.project.projectID) },
                                onToggleStatus = { newIsOpen ->
                                    coroutineScope.launch {
                                        withContext(Dispatchers.IO) {
                                            repository.setProjectLocked(projectStat.project.projectID, !newIsOpen)
                                        }
                                        refreshProjects()
                                    }
                                },
                                onEdit = { projectToEdit = projectStat.project },
                                onDelete = { projectToDelete = projectStat.project }
                            )
                        }
                    }
                }
            }
        }

        // نافذة طرح مشروع جديد (Admin Only)
        if (showCreateDialog) {
            CreateProjectAdminDialog(
                aidTypes = aidTypesList,
                onDismiss = { showCreateDialog = false },
                onConfirm = { newProject ->
                    showCreateDialog = false
                    coroutineScope.launch {
                        withContext(Dispatchers.IO) {
                            repository.insertProject(newProject)
                        }
                        refreshProjects()
                    }
                }
            )
        }

        // نافذة تعديل بيانات المشروع (Admin Only: Quota, Donor, Dates, Name)
        if (projectToEdit != null) {
            EditProjectAdminDialog(
                project = projectToEdit!!,
                aidTypes = aidTypesList,
                onDismiss = { projectToEdit = null },
                onConfirm = { updatedProject ->
                    projectToEdit = null
                    coroutineScope.launch {
                        withContext(Dispatchers.IO) {
                            repository.updateProject(updatedProject)
                        }
                        refreshProjects()
                    }
                }
            )
        }

        // نافذة تأكيد الحذف
        if (projectToDelete != null) {
            com.humanitarian.aidmanagement.ui.components.TypeToConfirmDeleteDialog(
                title = "حذف المشروع وسجلاته نهائياً",
                itemTypeLabel = "المشروع",
                expectedName = projectToDelete!!.projectName,
                onConfirm = {
                    val prj = projectToDelete!!
                    projectToDelete = null
                    coroutineScope.launch {
                        withContext(Dispatchers.IO) {
                            repository.deleteProject(prj.projectID)
                        }
                        refreshProjects()
                    }
                },
                onDismiss = { projectToDelete = null }
            )
        }
    }
}

/**
 * بطاقة المشروع لإدارة المدير (تحتوي على مفتاح تبديل الحالة isOpen وزر التعديل والحذف)
 */
@Composable
fun AdminProjectCard(
    item: ProjectWithStats,
    isManager: Boolean,
    onClick: () -> Unit,
    onToggleStatus: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val project = item.project
    // نسبة الإنجاز: (المستلمين / إجمالي المرشحين * 100)
    val percentDelivered = if (item.candidatesCount > 0) {
        ((item.deliveredCount.toDouble() / item.candidatesCount.toDouble()) * 100).toInt().coerceIn(0, 100)
    } else if (project.quantity > 0) {
        ((item.deliveredCount.toDouble() / project.quantity.toDouble()) * 100).toInt().coerceIn(0, 100)
    } else 0

    val isOpen = project.isOpen

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isOpen) PalestineGreen.copy(alpha = 0.4f) else SlateBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // ترويسة البطاقة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = project.projectName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "رقم: ${project.projectNumber} • المانح: ${project.fundingInstitution}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // شارة حالة المشروع (مفتوح للترشيح أم مغلق)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isOpen) PalestineGreen.copy(alpha = 0.15f) else Color(0xFFEF4444).copy(alpha = 0.15f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isOpen) PalestineGreen else Color(0xFFEF4444))
                        )
                        Text(
                            text = if (isOpen) "مفتوح للترشيح" else "مغلق ومكتمل",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isOpen) PalestineGreen else Color(0xFFEF4444)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // شريط الحصص والإنجاز
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SlateSurfaceVariant)
                    .padding(vertical = 10.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                MetricColumn(title = "الحصة المستهدفة", value = "${project.quantity}", color = MaterialTheme.colorScheme.onSurface)
                Divider(modifier = Modifier.height(24.dp).width(1.dp), color = SlateBorder)
                MetricColumn(title = "عدد المرشحين", value = "${item.candidatesCount}", color = Color(0xFF2563EB))
                Divider(modifier = Modifier.height(24.dp).width(1.dp), color = SlateBorder)
                MetricColumn(title = "المستلمون الفعليون", value = "${item.deliveredCount}", color = Color(0xFF059669))
            }

            Spacer(modifier = Modifier.height(10.dp))

            // شريط التقدم ونسبة الإنجاز
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "نسبة الإنجاز والتسليم: $percentDelivered%",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "المخزن: ${project.warehouseName}",
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateTextMuted
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { percentDelivered / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = if (percentDelivered >= 80) PalestineGreen else if (percentDelivered >= 40) Color(0xFFF59E0B) else PalestineRed,
                trackColor = SlateBorder
            )

            Spacer(modifier = Modifier.height(12.dp))

            // أزرار التحكم الخاصة بالمدير
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // تاريخ المشروع
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(13.dp), tint = SlateTextMuted)
                    Text(text = project.projectDate, style = MaterialTheme.typography.labelSmall, color = SlateTextMuted)
                }

                if (isManager) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // تبديل حالة الفتح والإغلاق
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isOpen) "مفتوح" else "مقفل",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isOpen) PalestineGreen else Color.Gray
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Switch(
                                checked = isOpen,
                                onCheckedChange = { onToggleStatus(it) },
                                modifier = Modifier.scale(0.8f),
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = PalestineGreen
                                )
                            )
                        }

                        // زر التعديل
                        IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = Color(0xFF2563EB), modifier = Modifier.size(18.dp))
                        }

                        // زر الحذف
                        IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "حذف", tint = PalestineRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }
    }
}

/**
 * نافذة طرح مشروع جديد (Admin Dialog)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateProjectAdminDialog(
    aidTypes: List<AidTypeEntity>,
    onDismiss: () -> Unit,
    onConfirm: (ProjectEntity) -> Unit
) {
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    var projectName by remember { mutableStateOf("") }
    var projectNumber by remember { mutableStateOf("PRJ-${System.currentTimeMillis() % 100000}") }
    var selectedAidTypeId by remember { mutableIntStateOf(aidTypes.firstOrNull()?.aidTypeID ?: 1) }
    var quantityText by remember { mutableStateOf("100") }
    var fundingInstitution by remember { mutableStateOf("برنامج الأغذية العالمي WFP") }
    var warehouseName by remember { mutableStateOf("المستودع الرئيسي") }
    var aidValueText by remember { mutableStateOf("150.0") }
    var projectDate by remember { mutableStateOf(today) }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.AddBusiness, contentDescription = null, tint = PalestineGreen)
                Text("طرح مشروع إنساني جديد", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    label = { Text("اسم المشروع *") },
                    placeholder = { Text("مثال: مشروع السلات الغذائية الطارئة") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = projectNumber,
                        onValueChange = { projectNumber = it },
                        label = { Text("رقم المشروع *") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("الحصة المستهدفة *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }

                // اختيار نوع المعونة
                Text("نوع المساعدة:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(items = aidTypes, key = { it.aidTypeID }) { type: AidTypeEntity ->
                        FilterChip(
                            selected = selectedAidTypeId == type.aidTypeID,
                            onClick = { selectedAidTypeId = type.aidTypeID },
                            label = { Text(type.aidTypeName) }
                        )
                    }
                }

                OutlinedTextField(
                    value = fundingInstitution,
                    onValueChange = { fundingInstitution = it },
                    label = { Text("الجهة المانحة / الممولة *") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = warehouseName,
                        onValueChange = { warehouseName = it },
                        label = { Text("المستودع المنفذ") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = projectDate,
                        onValueChange = { projectDate = it },
                        label = { Text("تاريخ المشروع") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات المشروع") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (projectName.isNotBlank()) {
                        val qty = quantityText.toIntOrNull() ?: 100
                        val valDouble = aidValueText.toDoubleOrNull() ?: 0.0
                        onConfirm(
                            ProjectEntity(
                                projectNumber = projectNumber,
                                projectName = projectName,
                                aidTypeID = selectedAidTypeId,
                                detailedDescription = notes,
                                projectDate = projectDate,
                                fundingInstitution = fundingInstitution,
                                warehouseName = warehouseName,
                                aidValue = valDouble,
                                quantity = qty,
                                notes = notes.ifBlank { null },
                                isActive = true,
                                isLocked = false
                            )
                        )
                    }
                },
                enabled = projectName.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("إنشاء المشروع", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

/**
 * نافذة تعديل بيانات المشروع (Admin Dialog: Edit Quota, Donor, Dates)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProjectAdminDialog(
    project: ProjectEntity,
    aidTypes: List<AidTypeEntity>,
    onDismiss: () -> Unit,
    onConfirm: (ProjectEntity) -> Unit
) {
    var projectName by remember { mutableStateOf(project.projectName) }
    var quantityText by remember { mutableStateOf(project.quantity.toString()) }
    var fundingInstitution by remember { mutableStateOf(project.fundingInstitution) }
    var warehouseName by remember { mutableStateOf(project.warehouseName) }
    var projectDate by remember { mutableStateOf(project.projectDate) }
    var notes by remember { mutableStateOf(project.notes ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Edit, contentDescription = null, tint = PalestineGreen)
                Text("تعديل بيانات المشروع وحصته", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    label = { Text("اسم المشروع") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("الحصة المستهدفة (Target Quota)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = projectDate,
                        onValueChange = { projectDate = it },
                        label = { Text("تاريخ المشروع") },
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = fundingInstitution,
                    onValueChange = { fundingInstitution = it },
                    label = { Text("الجهة المانحة (Donor)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = warehouseName,
                    onValueChange = { warehouseName = it },
                    label = { Text("المستودع المنفذ") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("الملاحظات") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val qty = quantityText.toIntOrNull() ?: project.quantity
                    onConfirm(
                        project.copy(
                            projectName = projectName,
                            quantity = qty,
                            fundingInstitution = fundingInstitution,
                            warehouseName = warehouseName,
                            projectDate = projectDate,
                            notes = notes.ifBlank { null }
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
            ) {
                Text("حفظ التعديلات", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun MetricColumn(title: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(text = value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = color)
        Text(text = title, style = MaterialTheme.typography.labelSmall, color = SlateTextMuted, fontSize = 11.sp)
    }
}

@Composable
private fun ProjectQuickMetric(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        }
        Column {
            Text(text = value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(text = title, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
