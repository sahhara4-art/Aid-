package com.humanitarian.aidmanagement.ui.screens.warehouse

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.security.TamperProofAuditLog
import com.humanitarian.aidmanagement.ui.theme.*
import com.humanitarian.aidmanagement.util.DynamicReportPdfSection
import com.humanitarian.aidmanagement.util.PublicDownloadsExporter
import com.humanitarian.aidmanagement.util.SavedExportResult
import com.humanitarian.aidmanagement.util.WarehouseVoucherPdfGenerator
import com.humanitarian.aidmanagement.warehouse.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs

private enum class DynamicReportTab(val title: String, val emoji: String) {
    OVERVIEW("الملخص الشامل", "📊"),
    STOCK_BATCHES("الأرصدة والتشغيلات", "📦"),
    MOVEMENTS_TRANSFERS("الوارد والصادر والمناقلات", "🚚"),
    CLIENTS_3PL("التخزين للغير (3PL)", "🤝"),
    FINANCE_PAYROLL("الموازنة والرواتب", "💰"),
    STAFF_CUSTODY("الطاقم والعُهد", "👥"),
    BLIND_AUDIT("الجرد الأعمى", "🕵️")
}

private enum class DateRangePreset(val label: String) {
    ALL_TIME("كافة الفترات"),
    LAST_7_DAYS("آخر 7 أيام"),
    LAST_30_DAYS("آخر 30 يوماً"),
    THIS_MONTH("الشهر الحالي"),
    CUSTOM("فترة مخصصة")
}

private enum class MovementSubFilter(val label: String) {
    ALL("الكل"),
    GRN_IN("واردات GRN"),
    GDN_OUT("صادرات GDN"),
    TRANSFERS("مناقلات"),
    FIELD_DELIVERY("صرف ميداني"),
    KITTING("تجميع وتفكيك")
}

private data class SavedDynamicExportDialogData(
    val title: String,
    val isPdf: Boolean,
    val result: SavedExportResult
)

/**
 * شاشة «تقارير المخازن التفصيلية الديناميكية» للمخازن منفردة أو مجتمعة،
 * مربوطة بالكامل بصلاحيات الوصول (SCREEN_WAREHOUSE_REPORTS)، العزل المخزني (assignedWarehouseId)،
 * صلاحية الموازنة (CAN_WAREHOUSE_FINANCE)، وصلاحية التصدير (CAN_WAREHOUSE_EXPORT_REPORTS).
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun WarehouseDynamicReportsScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val warehouseState by WarehouseErpStore.stateFlow.collectAsStateWithLifecycle()
    val currentUser by AccessControlManager.currentUser.collectAsStateWithLifecycle()
    val assignedWarehouseId by AccessControlManager.assignedWarehouseIdFlow.collectAsStateWithLifecycle()
    val activePermissions by AccessControlManager.permissionsFlow.collectAsStateWithLifecycle()
    val projects by repository.getActiveProjects().collectAsStateWithLifecycle(initialValue = emptyList())

    LaunchedEffect(Unit) {
        AccessControlManager.initWarehouseAssignments(context)
        withContext(Dispatchers.IO) {
            WarehouseErpStore.ensureLoaded(context)
        }
    }

    val isSuperAdmin = remember(currentUser) {
        currentUser?.UserName?.trim() == "admin" || AccessControlManager.isSuperAdmin()
    }
    val canViewReports = remember(currentUser, activePermissions, isSuperAdmin) {
        isSuperAdmin || AccessControlManager.canAccessScreen(AccessControlManager.SCREEN_WAREHOUSE_REPORTS)
    }
    val canViewFinance = remember(currentUser, activePermissions, isSuperAdmin) {
        isSuperAdmin || AccessControlManager.canManageWarehouseFinance()
    }
    val canExportReports = remember(currentUser, activePermissions, isSuperAdmin) {
        isSuperAdmin || AccessControlManager.canExportWarehouseReports()
    }
    val isRestrictedToSingleWarehouse = remember(currentUser, assignedWarehouseId, isSuperAdmin) {
        !isSuperAdmin && AccessControlManager.isRestrictedToSingleWarehouse(currentUser)
    }

    val actorName = remember(currentUser) {
        currentUser?.fullName?.takeIf { it.isNotBlank() }
            ?: currentUser?.UserName?.takeIf { it.isNotBlank() }
            ?: "مستخدم النظام"
    }

    // حارس الصلاحيات الصارم عند الفتح
    if (!canViewReports) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(
                containerColor = SlateBackground,
                topBar = {
                    TopAppBar(
                        navigationIcon = {
                            TextButton(onClick = onNavigateBack) {
                                Text("← رجوع", color = PalestineGreen, fontWeight = FontWeight.Bold)
                            }
                        },
                        title = {
                            Text("تقارير المخازن التفصيلية", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = PalestineWhite)
                    )
                }
            ) { padding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                        border = BorderStroke(1.5.dp, Color(0xFFFCA5A5)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text("⛔", fontSize = 42.sp)
                            Text(
                                text = "⛔ لا تملك صلاحية الاطلاع على تقارير المخازن التفصيلية",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = PalestineRed,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "يرجى مراجعة مدير النظام لتفعيل شاشة «تقارير المخازن التفصيلية» في صلاحيات حسابك.",
                                fontSize = 12.sp,
                                color = Color(0xFF991B1B),
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = onNavigateBack,
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineRed),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("العودة", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
        return
    }

    // المخازن المرئية للمستخدم حسب العزل المخزني
    val allowedWarehouses = remember(warehouseState.warehouses, assignedWarehouseId, isSuperAdmin) {
        if (isSuperAdmin) warehouseState.warehouses
        else WarehouseErpStore.getVisibleWarehouses(assignedWarehouseId)
    }

    // النطاق المخزني المختار ("ALL" = كافة المخازن الموحدة أو معرف مخزن محدد)
    var selectedWarehouseScope by remember(isRestrictedToSingleWarehouse, assignedWarehouseId) {
        mutableStateOf(
            if (isRestrictedToSingleWarehouse) assignedWarehouseId else WarehouseConstants.ALL_WAREHOUSES
        )
    }
    LaunchedEffect(allowedWarehouses, isRestrictedToSingleWarehouse, assignedWarehouseId) {
        if (isRestrictedToSingleWarehouse) {
            selectedWarehouseScope = allowedWarehouses.firstOrNull()?.id ?: assignedWarehouseId
        } else if (selectedWarehouseScope != WarehouseConstants.ALL_WAREHOUSES &&
            allowedWarehouses.none { it.id == selectedWarehouseScope }
        ) {
            selectedWarehouseScope = WarehouseConstants.ALL_WAREHOUSES
        }
    }

    // فلاتر الفترة الزمنية والبحث والتبويبات
    var selectedPreset by remember { mutableStateOf(DateRangePreset.ALL_TIME) }
    var customStartDate by remember { mutableStateOf(reportFormatDateOnly(System.currentTimeMillis() - 30L * 86_400_000L)) }
    var customEndDate by remember { mutableStateOf(reportFormatDateOnly(System.currentTimeMillis())) }
    var showDatePickerForStart by remember { mutableStateOf<Boolean?>(null) } // true=من، false=إلى
    var searchQuery by remember { mutableStateOf("") }
    var movementSubFilter by remember { mutableStateOf(MovementSubFilter.ALL) }
    var exportFullReportMode by remember { mutableStateOf(false) } // false=التبويب الحالي، true=التقرير الشامل
    var isExporting by remember { mutableStateOf(false) }
    var savedExportDialog by remember { mutableStateOf<SavedDynamicExportDialogData?>(null) }

    val visibleTabs = remember(canViewFinance) {
        DynamicReportTab.entries.filter { tab ->
            tab != DynamicReportTab.FINANCE_PAYROLL || canViewFinance
        }
    }
    var selectedTab by remember { mutableStateOf(DynamicReportTab.OVERVIEW) }
    LaunchedEffect(visibleTabs) {
        if (selectedTab !in visibleTabs) {
            selectedTab = DynamicReportTab.OVERVIEW
        }
    }

    // خرائط الأسماء المساعدة
    val warehouseNameById = remember(warehouseState.warehouses) {
        warehouseState.warehouses.associate { it.id to it.name }
    }
    val projectNameById = remember(projects) {
        projects.associate { it.projectID.toString() to it.projectName }
    }
    val clientNameById = remember(warehouseState.clients) {
        warehouseState.clients.associate { it.id to it.clientName }
    }

    // المخازن الداخلة في نطاق التقرير الحالي
    val scopedWarehouses = remember(allowedWarehouses, selectedWarehouseScope) {
        if (selectedWarehouseScope == WarehouseConstants.ALL_WAREHOUSES) {
            allowedWarehouses
        } else {
            allowedWarehouses.filter { it.id == selectedWarehouseScope }
        }
    }
    val scopedWarehouseIds = remember(scopedWarehouses) {
        scopedWarehouses.map { it.id }.toSet()
    }
    val warehouseScopeLabel = remember(selectedWarehouseScope, scopedWarehouses, isRestrictedToSingleWarehouse) {
        if (selectedWarehouseScope == WarehouseConstants.ALL_WAREHOUSES && !isRestrictedToSingleWarehouse) {
            "كافة المخازن (تقرير موحّد — ${scopedWarehouses.size} مخزن)"
        } else {
            scopedWarehouses.firstOrNull()?.name ?: selectedWarehouseScope
        }
    }

    // حدود الفترة الزمنية بالمللي ثانية
    val dateRangeBounds = remember(selectedPreset, customStartDate, customEndDate) {
        computeDateRangeMillis(selectedPreset, customStartDate, customEndDate)
    }
    val dateRangeLabel = remember(selectedPreset, customStartDate, customEndDate) {
        when (selectedPreset) {
            DateRangePreset.ALL_TIME -> "كافة الفترات"
            DateRangePreset.LAST_7_DAYS -> "آخر 7 أيام"
            DateRangePreset.LAST_30_DAYS -> "آخر 30 يوماً"
            DateRangePreset.THIS_MONTH -> "الشهر الحالي"
            DateRangePreset.CUSTOM -> "من $customStartDate إلى $customEndDate"
        }
    }

    val cleanQuery = searchQuery.trim().lowercase(Locale.ROOT)
    fun matchesSearch(vararg fields: String?): Boolean {
        if (cleanQuery.isEmpty()) return true
        return fields.any { it != null && it.lowercase(Locale.ROOT).contains(cleanQuery) }
    }

    fun isInDateRange(rawDate: String): Boolean {
        val (startMs, endMs) = dateRangeBounds
        if (startMs == null && endMs == null) return true
        val ms = parseAnyReportDateMillis(rawDate) ?: return false
        if (startMs != null && ms < startMs) return false
        if (endMs != null && ms > endMs) return false
        return true
    }

    // ========================================================================
    // البيانات المفلترة ديناميكياً حسب النطاق المخزني + الفترة الزمنية + البحث
    // ========================================================================
    val scopedItems = remember(warehouseState.items, scopedWarehouseIds, cleanQuery, warehouseNameById) {
        warehouseState.items.filter { item ->
            item.warehouseId in scopedWarehouseIds &&
                matchesSearch(item.name, item.category, item.expiryDate, warehouseNameById[item.warehouseId])
        }
    }
    val scopedBatches = remember(warehouseState.batches, scopedWarehouseIds) {
        warehouseState.batches.filter { it.warehouseId in scopedWarehouseIds && it.remainingMinorQty > 0L }
    }
    val scopedMovementsAllTypes = remember(warehouseState.movements, scopedWarehouseIds, dateRangeBounds, cleanQuery, warehouseNameById) {
        warehouseState.movements.filter { mov ->
            (mov.warehouseId in scopedWarehouseIds || (mov.targetWarehouseId != null && mov.targetWarehouseId in scopedWarehouseIds)) &&
                isInDateRange(mov.date) &&
                matchesSearch(
                    mov.voucherNo, mov.itemName, mov.batchNo, mov.supplierOrDonor,
                    mov.recipientOrProject, mov.driverName, mov.vehiclePlate, mov.notes,
                    mov.performedBy, warehouseNameById[mov.warehouseId],
                    mov.targetWarehouseId?.let { warehouseNameById[it] }
                )
        }
    }
    val filteredMovementsBySubType = remember(scopedMovementsAllTypes, movementSubFilter) {
        when (movementSubFilter) {
            MovementSubFilter.ALL -> scopedMovementsAllTypes
            MovementSubFilter.GRN_IN -> scopedMovementsAllTypes.filter { it.type == StockMovementType.IN }
            MovementSubFilter.GDN_OUT -> scopedMovementsAllTypes.filter { it.type == StockMovementType.OUT }
            MovementSubFilter.TRANSFERS -> scopedMovementsAllTypes.filter { it.type == StockMovementType.TRANSFER }
            MovementSubFilter.FIELD_DELIVERY -> scopedMovementsAllTypes.filter {
                it.type == StockMovementType.DELIVERY_DEDUCT || it.type == StockMovementType.DELIVERY_RESTORE
            }
            MovementSubFilter.KITTING -> scopedMovementsAllTypes.filter {
                it.type == StockMovementType.KIT_ASSEMBLE || it.type == StockMovementType.KIT_UNBUNDLE
            }
        }
    }
    val scopedShipments = remember(warehouseState.inTransitShipments, scopedWarehouseIds, dateRangeBounds, cleanQuery, warehouseNameById) {
        warehouseState.inTransitShipments.filter { sh ->
            (sh.fromWarehouseId in scopedWarehouseIds || sh.toWarehouseId in scopedWarehouseIds) &&
                isInDateRange(sh.sentAt.ifBlank { sh.confirmedAt }) &&
                matchesSearch(
                    sh.shipmentId, sh.voucherNo, sh.itemName, sh.driverName, sh.vehiclePlate,
                    sh.batchNo, sh.notes, warehouseNameById[sh.fromWarehouseId], warehouseNameById[sh.toWarehouseId]
                )
        }
    }
    val scopedClients = remember(warehouseState.clients, scopedWarehouseIds, cleanQuery, warehouseNameById) {
        warehouseState.clients.filter { cli ->
            cli.warehouseId in scopedWarehouseIds &&
                matchesSearch(cli.clientName, cli.contactPerson, cli.phone, cli.billingModel.arabicLabel, warehouseNameById[cli.warehouseId])
        }
    }
    val scopedClientTxs = remember(warehouseState.clientTransactions, scopedWarehouseIds, dateRangeBounds) {
        warehouseState.clientTransactions.filter { tx ->
            tx.warehouseId in scopedWarehouseIds && isInDateRange(tx.date)
        }
    }
    val scopedWorkers = remember(warehouseState.workers, scopedWarehouseIds, cleanQuery, warehouseNameById) {
        warehouseState.workers.filter { w ->
            w.warehouseId in scopedWarehouseIds &&
                matchesSearch(w.name, w.role, w.payType.arabicLabel, warehouseNameById[w.warehouseId])
        }
    }
    val scopedBudgets = remember(warehouseState.budgetEntries, scopedWarehouseIds, dateRangeBounds, cleanQuery, warehouseNameById) {
        warehouseState.budgetEntries.filter { b ->
            b.warehouseId in scopedWarehouseIds &&
                isInDateRange(b.date) &&
                matchesSearch(b.fundingSource, b.notes, b.performedBy, warehouseNameById[b.warehouseId])
        }
    }
    val scopedExpenses = remember(warehouseState.expenses, scopedWarehouseIds, dateRangeBounds, cleanQuery, warehouseNameById) {
        warehouseState.expenses.filter { e ->
            e.warehouseId in scopedWarehouseIds &&
                isInDateRange(e.date) &&
                matchesSearch(e.category, e.invoiceNo, e.notes, e.allocatedTarget, e.performedBy, warehouseNameById[e.warehouseId])
        }
    }
    val scopedPettyCash = remember(warehouseState.pettyCashAdvances, scopedWarehouseIds, dateRangeBounds, cleanQuery, warehouseNameById) {
        warehouseState.pettyCashAdvances.filter { p ->
            p.warehouseId in scopedWarehouseIds &&
                isInDateRange(p.date) &&
                matchesSearch(p.id, p.keeperName, p.notes, p.status.arabicLabel, warehouseNameById[p.warehouseId])
        }
    }
    val scopedPayrolls = remember(warehouseState.payrollRecords, scopedWarehouseIds, dateRangeBounds, cleanQuery, warehouseNameById) {
        warehouseState.payrollRecords.filter { pr ->
            pr.warehouseId in scopedWarehouseIds &&
                isInDateRange(pr.paidDate.ifBlank { "${pr.periodLabel}-01" }) &&
                matchesSearch(pr.workerName, pr.role, pr.periodLabel, warehouseNameById[pr.warehouseId])
        }
    }
    val scopedBlindAudits = remember(scopedMovementsAllTypes) {
        scopedMovementsAllTypes.filter { it.type == StockMovementType.AUDIT_ADJUST }
    }

    // مؤشرات الملخص الشامل
    val totalMaxCapacity = remember(scopedWarehouses) { scopedWarehouses.sumOf { it.maxCapacity.coerceAtLeast(0L) } }
    val totalOwnMinorUnits = remember(scopedItems) { scopedItems.sumOf { it.totalMinorQty } }
    val totalOwnMajorUnits = remember(scopedItems) { scopedItems.sumOf { it.fullMajorUnits } }
    val totalQuarantinedUnits = remember(scopedBatches) { scopedBatches.filter { it.isQuarantined }.sumOf { it.remainingMinorQty } }
    val clientBillingMap = remember(scopedClients, warehouseState.clientTransactions) {
        scopedClients.associate { it.id to WarehouseErpStore.calculateClientBilling(it.id) }
    }
    val total3plRemainingPieces = remember(clientBillingMap) {
        clientBillingMap.values.sumOf { it.remainingPieces }
    }
    val total3plReceivables = remember(clientBillingMap) {
        clientBillingMap.values.sumOf { it.netAmountDue.coerceAtLeast(0.0) }
    }
    val total3plCollected = remember(clientBillingMap) {
        clientBillingMap.values.sumOf { it.totalPaid }
    }
    val totalOccupancyPercent = remember(totalMaxCapacity, totalOwnMinorUnits, total3plRemainingPieces) {
        if (totalMaxCapacity <= 0L) 0
        else (((totalOwnMinorUnits + total3plRemainingPieces) * 100L) / totalMaxCapacity).toInt().coerceIn(0, 100)
    }
    val totalInboundUnits = remember(scopedMovementsAllTypes) {
        scopedMovementsAllTypes
            .filter { it.type == StockMovementType.IN || it.type == StockMovementType.DELIVERY_RESTORE }
            .sumOf { abs(it.totalMinorDelta) }
    }
    val totalOutboundUnits = remember(scopedMovementsAllTypes) {
        scopedMovementsAllTypes
            .filter { it.type == StockMovementType.OUT || it.type == StockMovementType.DELIVERY_DEDUCT }
            .sumOf { abs(it.totalMinorDelta) }
    }
    val totalTransfersUnits = remember(scopedMovementsAllTypes) {
        scopedMovementsAllTypes
            .filter { it.type == StockMovementType.TRANSFER }
            .sumOf { abs(it.totalMinorDelta) }
    }

    // المؤشرات المالية المجمّعة (تُعرض وتُصدّر فقط لمن يملك canViewFinance)
    val totalApprovedBudget = remember(scopedBudgets) { scopedBudgets.sumOf { it.allocatedAmount } }
    val totalExpensesSum = remember(scopedExpenses) { scopedExpenses.sumOf { it.amount } }
    val totalPaidPayroll = remember(scopedPayrolls) { scopedPayrolls.filter { it.isPaid }.sumOf { it.amount } }
    val totalPendingPayroll = remember(scopedPayrolls) { scopedPayrolls.filter { !it.isPaid }.sumOf { it.amount } }
    val netFinancialBalance = remember(totalApprovedBudget, total3plCollected, totalExpensesSum, totalPaidPayroll) {
        totalApprovedBudget + total3plCollected - totalExpensesSum - totalPaidPayroll
    }
    val totalHandledUnitsPeriod = remember(scopedMovementsAllTypes, scopedClientTxs) {
        val internal = scopedMovementsAllTypes
            .filter { it.type != StockMovementType.AUDIT_ADJUST }
            .sumOf { abs(it.totalMinorDelta) }
        val thirdParty = scopedClientTxs
            .filter { it.type == ClientStorageTxType.DEPOSIT || it.type == ClientStorageTxType.WITHDRAWAL }
            .sumOf { it.quantityPieces.coerceAtLeast(0L) }
        internal + thirdParty
    }
    val avgHandlingCostPerUnit = remember(totalExpensesSum, totalPaidPayroll, totalHandledUnitsPeriod) {
        if (totalHandledUnitsPeriod <= 0L) 0.0
        else (totalExpensesSum + totalPaidPayroll) / totalHandledUnitsPeriod.toDouble()
    }

    fun resolveTargetLabel(rawTarget: String): String {
        val clean = rawTarget.trim()
        return when {
            clean.isBlank() || clean.equals("GENERAL", ignoreCase = true) -> "مصروف عام للمخزن"
            clean.startsWith("PROJECT:", ignoreCase = true) -> {
                val pId = clean.substringAfter(":")
                "مشروع: ${projectNameById[pId] ?: "#$pId"}"
            }
            clean.startsWith("CLIENT:", ignoreCase = true) -> {
                val cId = clean.substringAfter(":")
                "عميل 3PL: ${clientNameById[cId] ?: cId}"
            }
            else -> clean
        }
    }

    // ========================================================================
    // دوال بناء أقسام التقرير الموحدة للتصدير (CSV و PDF) مع تطبيق قفل البيانات المالية
    // ========================================================================
    fun buildSectionForTab(tab: DynamicReportTab): List<DynamicReportPdfSection> {
        return when (tab) {
            DynamicReportTab.OVERVIEW -> {
                val whRows = scopedWarehouses.map { wh ->
                    val whItems = scopedItems.filter { it.warehouseId == wh.id }
                    val whOwnQty = whItems.sumOf { it.totalMinorQty }
                    val wh3plQty = scopedClients.filter { it.warehouseId == wh.id }
                        .sumOf { clientBillingMap[it.id]?.remainingPieces ?: 0L }
                    val occ = if (wh.maxCapacity > 0L) (((whOwnQty + wh3plQty) * 100L) / wh.maxCapacity).toInt().coerceIn(0, 100) else 0
                    val whStaff = scopedWorkers.count { it.warehouseId == wh.id && it.isActive }
                    listOf(
                        wh.name,
                        "${wh.storageType} (${wh.status})",
                        wh.keeperName.ifBlank { "-" },
                        "$whOwnQty + $wh3plQty (3PL)",
                        "$occ%",
                        "$whStaff"
                    )
                }
                listOf(
                    DynamicReportPdfSection(
                        title = "أولاً: ملخص المخازن ونسب الإشغال",
                        headers = listOf("المخزن", "النوع / الحالة", "أمين المخزن", "الأرصدة (ذاتي + 3PL)", "الإشغال", "الطاقم"),
                        weights = listOf(0.22f, 0.16f, 0.18f, 0.24f, 0.10f, 0.10f),
                        rows = whRows
                    )
                )
            }

            DynamicReportTab.STOCK_BATCHES -> {
                val rows = scopedItems.map { item ->
                    val itemBatches = scopedBatches.filter { it.itemId == item.id && !it.isQuarantined }
                    val qQty = scopedBatches.filter { it.itemId == item.id && it.isQuarantined }.sumOf { it.remainingMinorQty }
                    val burnDays = WarehouseErpStore.predictDaysUntilStockout(item.id)
                    val batchSummary = if (itemBatches.isEmpty()) {
                        item.expiryDate.ifBlank { "-" }
                    } else {
                        itemBatches.take(3).joinToString(" | ") { b ->
                            "${b.batchNo} (${b.expiryDate.ifBlank { "-" }}: ${b.remainingMinorQty})"
                        }
                    }
                    listOf(
                        "${item.name}\n(${warehouseNameById[item.warehouseId] ?: item.warehouseId})",
                        item.formatDualQuantity(),
                        batchSummary,
                        if (burnDays != null) "$burnDays يوم" else "مستقر",
                        if (qQty > 0L) "$qQty" else "0"
                    )
                }
                listOf(
                    DynamicReportPdfSection(
                        title = "ثانياً: تقرير الأرصدة والتشغيلات (FEFO) ومعدل النفاد",
                        headers = listOf("الصنف / المخزن", "الرصيد (جملة / فردي)", "التشغيلات النشطة (FEFO)", "توقع النفاد", "حجر صحي"),
                        weights = listOf(0.24f, 0.22f, 0.30f, 0.13f, 0.11f),
                        rows = rows
                    )
                )
            }

            DynamicReportTab.MOVEMENTS_TRANSFERS -> {
                val movRows = filteredMovementsBySubType.take(120).map { mov ->
                    val sign = if (mov.totalMinorDelta >= 0L) "+" else "-"
                    val whText = buildString {
                        append(warehouseNameById[mov.warehouseId] ?: mov.warehouseId)
                        if (!mov.targetWarehouseId.isNullOrBlank()) {
                            append(" ⬅ ")
                            append(warehouseNameById[mov.targetWarehouseId] ?: mov.targetWarehouseId)
                        }
                    }
                    listOf(
                        "${mov.voucherNo}\n${mov.date}",
                        mov.type.arabicTitle,
                        "${mov.itemName}\n$whText",
                        "$sign${abs(mov.totalMinorDelta)}",
                        mov.recipientOrProject.ifBlank { mov.supplierOrDonor.ifBlank { mov.performedBy.ifBlank { "-" } } }
                    )
                }
                val shRows = scopedShipments.map { sh ->
                    listOf(
                        "${sh.voucherNo.ifBlank { sh.shipmentId }}\n${sh.sentAt}",
                        "${warehouseNameById[sh.fromWarehouseId] ?: sh.fromWarehouseId} ⬅ ${warehouseNameById[sh.toWarehouseId] ?: sh.toWarehouseId}",
                        sh.itemName,
                        "مرسل: ${sh.sentMinorQty} | مستلم: ${sh.receivedMinorQty} | عجز: ${sh.shortageQty}",
                        sh.status.arabicLabel
                    )
                }
                listOf(
                    DynamicReportPdfSection(
                        title = "ثالثاً: سجل الوارد والصادر والمناقلات (${movementSubFilter.label})",
                        headers = listOf("رقم السند والتاريخ", "النوع", "الصنف / المخزن", "الكمية", "الجهة / المنفذ"),
                        weights = listOf(0.20f, 0.18f, 0.28f, 0.12f, 0.22f),
                        rows = movRows
                    ),
                    DynamicReportPdfSection(
                        title = "الشحنات قيد النقل (In-Transit) ومحاضر العجز",
                        headers = listOf("رقم الشحنة", "المسار", "الصنف", "الكميات والعجز", "الحالة"),
                        weights = listOf(0.18f, 0.24f, 0.18f, 0.24f, 0.16f),
                        rows = shRows,
                        emptyText = "لا توجد شحنات قيد النقل أو محاضر عجز ضمن الفترة المحددة"
                    )
                )
            }

            DynamicReportTab.CLIENTS_3PL -> {
                val rows = scopedClients.map { cli ->
                    val b = clientBillingMap[cli.id] ?: WarehouseErpStore.calculateClientBilling(cli.id)
                    listOf(
                        "${cli.clientName}\n(${warehouseNameById[cli.warehouseId] ?: cli.warehouseId})",
                        "مودع: ${b.totalDepositedPieces}\nمسحوب: ${b.totalWithdrawnPieces}",
                        "${b.remainingPieces} قطعة\n(${b.totalBillableStorageDays} يوم)",
                        reportFmtMoney(b.totalCharges),
                        reportFmtMoney(b.totalPaid),
                        reportFmtMoney(b.netAmountDue)
                    )
                }
                listOf(
                    DynamicReportPdfSection(
                        title = "رابعاً: كشف عملاء التخزين للغير (3PL) والأرصدة المالية",
                        headers = listOf("العميل / المخزن", "المودع والمسحوب", "المتبقي / الأيام", "المستحق", "المدفوع", "الصافي"),
                        weights = listOf(0.24f, 0.18f, 0.19f, 0.13f, 0.13f, 0.13f),
                        rows = rows
                    )
                )
            }

            DynamicReportTab.FINANCE_PAYROLL -> {
                if (!canViewFinance) return emptyList()
                val expRows = scopedExpenses.map { exp ->
                    listOf(
                        "${exp.date}\n${warehouseNameById[exp.warehouseId] ?: exp.warehouseId}",
                        exp.category,
                        resolveTargetLabel(exp.allocatedTarget),
                        exp.invoiceNo.ifBlank { "-" },
                        reportFmtMoney(exp.amount)
                    )
                }
                val pettyRows = scopedPettyCash.map { pc ->
                    listOf(
                        "${pc.keeperName}\n(${warehouseNameById[pc.warehouseId] ?: pc.warehouseId})",
                        pc.date,
                        reportFmtMoney(pc.amount),
                        reportFmtMoney(pc.spentAmount),
                        reportFmtMoney(pc.remainingAmount),
                        pc.status.arabicLabel
                    )
                }
                val payRows = scopedPayrolls.map { pr ->
                    listOf(
                        "${pr.workerName}\n(${pr.role})",
                        pr.periodLabel,
                        pr.payType.arabicLabel,
                        reportFmtMoney(pr.amount),
                        if (pr.isPaid) "مصروف (${pr.paidDate})" else "معلّق"
                    )
                }
                listOf(
                    DynamicReportPdfSection(
                        title = "خامساً: سجل المصروفات التشغيلية وتوزيع التكلفة",
                        headers = listOf("التاريخ / المخزن", "التصنيف", "جهة التحميل", "رقم الفاتورة", "المبلغ"),
                        weights = listOf(0.22f, 0.18f, 0.28f, 0.16f, 0.16f),
                        rows = expRows
                    ),
                    DynamicReportPdfSection(
                        title = "العُهد النقدية لأمناء المخازن (Petty Cash)",
                        headers = listOf("أمين العهدة / المخزن", "التاريخ", "العهدة", "المنصرف", "المتبقي", "الحالة"),
                        weights = listOf(0.24f, 0.14f, 0.15f, 0.15f, 0.15f, 0.17f),
                        rows = pettyRows
                    ),
                    DynamicReportPdfSection(
                        title = "كشف الرواتب والأجور التشغيلية",
                        headers = listOf("العامل / الوظيفة", "الفترة", "نوع الأجر", "المبلغ", "الحالة"),
                        weights = listOf(0.28f, 0.16f, 0.18f, 0.18f, 0.20f),
                        rows = payRows
                    )
                )
            }

            DynamicReportTab.STAFF_CUSTODY -> {
                val keeperRows = scopedWarehouses.map { wh ->
                    listOf(
                        wh.name,
                        wh.keeperName.ifBlank { "-" },
                        wh.keeperPhone.ifBlank { "-" },
                        wh.location.ifBlank { "-" },
                        wh.equipmentNotes.ifBlank { "لا توجد عُهد مسجلة" }
                    )
                }
                val workerRows = scopedWorkers.map { w ->
                    listOf(
                        w.name,
                        warehouseNameById[w.warehouseId] ?: w.warehouseId,
                        w.role,
                        w.payType.arabicLabel,
                        if (canViewFinance) reportFmtMoney(w.rate) else "محمي",
                        if (w.isActive) "نشط" else "متوقف"
                    )
                }
                listOf(
                    DynamicReportPdfSection(
                        title = "سادساً: أمناء المخازن وعُهد التجهيزات",
                        headers = listOf("المخزن", "أمين المخزن", "الجوال", "الموقع", "عُهد التجهيزات"),
                        weights = listOf(0.20f, 0.20f, 0.16f, 0.16f, 0.28f),
                        rows = keeperRows
                    ),
                    DynamicReportPdfSection(
                        title = "كشف طاقم العاملين بالمخازن",
                        headers = listOf("الاسم", "المخزن", "الوظيفة", "نوع الأجر", "الأجر", "الحالة"),
                        weights = listOf(0.22f, 0.20f, 0.18f, 0.16f, 0.12f, 0.12f),
                        rows = workerRows
                    )
                )
            }

            DynamicReportTab.BLIND_AUDIT -> {
                val rows = scopedBlindAudits.map { mov ->
                    val parsed = parseBlindAuditNotes(mov.notes, mov.totalMinorDelta)
                    listOf(
                        "${mov.voucherNo}\n${mov.date}",
                        "${mov.itemName}\n(${warehouseNameById[mov.warehouseId] ?: mov.warehouseId})",
                        parsed.systemBookLabel,
                        parsed.physicalCountLabel,
                        if (mov.totalMinorDelta > 0L) "+${mov.totalMinorDelta}" else "${mov.totalMinorDelta}",
                        mov.performedBy.ifBlank { "-" }
                    )
                }
                listOf(
                    DynamicReportPdfSection(
                        title = "سابعاً: سجل الجرد الأعمى والفروقات المسجّلة",
                        headers = listOf("السند والتاريخ", "الصنف / المخزن", "الدفتري", "الفعلي", "الفارق", "المنفذ"),
                        weights = listOf(0.20f, 0.26f, 0.12f, 0.12f, 0.12f, 0.18f),
                        rows = rows
                    )
                )
            }
        }
    }

    fun buildTargetTabsForExport(): List<DynamicReportTab> {
        return if (exportFullReportMode) {
            visibleTabs
        } else {
            listOf(selectedTab).filter { it != DynamicReportTab.FINANCE_PAYROLL || canViewFinance }
        }
    }

    fun buildKpiSummaryForPdf(): List<Triple<String, String, Int>> {
        val cDark = android.graphics.Color.parseColor("#064E3B")
        val cBlue = android.graphics.Color.parseColor("#0369A1")
        val cAmber = android.graphics.Color.parseColor("#B45309")
        val cRed = android.graphics.Color.parseColor("#B91C1C")
        val list = mutableListOf(
            Triple("عدد المخازن", "${scopedWarehouses.size}", cDark),
            Triple("نسبة الإشغال", "$totalOccupancyPercent%", if (totalOccupancyPercent >= 90) cRed else cDark),
            Triple("الرصيد الصالح", "$totalOwnMinorUnits وحدة", cDark),
            Triple("وارد / صادر", "+$totalInboundUnits / -$totalOutboundUnits", cBlue),
            Triple("أرصدة 3PL", "$total3plRemainingPieces قطعة", cAmber),
            Triple("ذمم العملاء", reportFmtMoney(total3plReceivables), if (total3plReceivables > 0) cRed else cDark)
        )
        if (canViewFinance) {
            list.add(Triple("صافي الرصيد المالي", reportFmtMoney(netFinancialBalance), if (netFinancialBalance >= 0) cDark else cRed))
            list.add(Triple("تكلفة مناولة الوحدة", reportFmtMoney(avgHandlingCostPerUnit), cBlue))
        }
        return list
    }

    fun triggerCsvExport() {
        if (!canExportReports || isExporting) return
        scope.launch {
            isExporting = true
            runCatching {
                val targetTabs = buildTargetTabsForExport()
                val sections = targetTabs.flatMap { buildSectionForTab(it) }
                val reportTitle = if (exportFullReportMode) {
                    "التقرير الشامل لتقارير المخازن الديناميكية"
                } else {
                    "تقرير المخازن — ${selectedTab.title}"
                }

                val csvContent = buildString {
                    appendLine(csvRow(reportTitle))
                    appendLine(csvRow("النطاق المخزني", warehouseScopeLabel, "الفترة الزمنية", dateRangeLabel))
                    appendLine(csvRow("مُصدر التقرير", actorName, "تاريخ الإصدار", reportNowDateTime()))
                    appendLine(csvRow("عدد المخازن", "${scopedWarehouses.size}", "نسبة الإشغال", "$totalOccupancyPercent%"))
                    appendLine(csvRow("إجمالي الوحدات الصالحة", "$totalOwnMinorUnits", "إجمالي الوارد / الصادر", "+$totalInboundUnits / -$totalOutboundUnits"))
                    if (canViewFinance) {
                        appendLine(
                            csvRow(
                                "الموازنة المعتمدة", reportFmtMoney(totalApprovedBudget),
                                "إجمالي المصروفات", reportFmtMoney(totalExpensesSum),
                                "الرواتب المدفوعة", reportFmtMoney(totalPaidPayroll),
                                "صافي الرصيد المالي", reportFmtMoney(netFinancialBalance)
                            )
                        )
                    }
                    appendLine()
                    sections.forEach { sec ->
                        appendLine(csvRow(sec.title))
                        appendLine(sec.headers.joinToString(",") { csvCell(it) })
                        if (sec.rows.isEmpty()) {
                            appendLine(csvRow(sec.emptyText))
                        } else {
                            sec.rows.forEach { r ->
                                appendLine(r.joinToString(",") { csvCell(it.replace("\n", " | ")) })
                            }
                        }
                        appendLine()
                    }
                }

                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val suffix = if (exportFullReportMode) "Full" else selectedTab.name
                val saved = withContext(Dispatchers.IO) {
                    PublicDownloadsExporter.saveCsvToPublicDownloads(
                        context = context,
                        fileName = "Warehouse_Report_${suffix}_$stamp.csv",
                        csvContent = csvContent
                    )
                }

                TamperProofAuditLog.logEvent(
                    context = context,
                    actionType = "تصدير تقرير مخازن",
                    targetId = selectedWarehouseScope,
                    details = "تصدير Excel (CSV): $reportTitle | النطاق: $warehouseScopeLabel | الفترة: $dateRangeLabel | الملف: ${saved.fileName}",
                    performedBy = actorName
                )
                saved to reportTitle
            }.onSuccess { (saved, title) ->
                savedExportDialog = SavedDynamicExportDialogData(
                    title = title,
                    isPdf = false,
                    result = saved
                )
            }.onFailure { err ->
                Toast.makeText(context, "تعذر تصدير ملف Excel: ${err.message}", Toast.LENGTH_LONG).show()
            }
            isExporting = false
        }
    }

    fun triggerPdfExport() {
        if (!canExportReports || isExporting) return
        scope.launch {
            isExporting = true
            runCatching {
                val targetTabs = buildTargetTabsForExport()
                val sections = targetTabs.flatMap { buildSectionForTab(it) }
                val reportTitle = if (exportFullReportMode) {
                    "التقرير الشامل لتقارير المخازن التفصيلية"
                } else {
                    "تقرير المخازن — ${selectedTab.title}"
                }
                val saved = WarehouseVoucherPdfGenerator.generateDynamicWarehouseReportPdf(
                    context = context,
                    reportTitle = reportTitle,
                    warehouseScopeLabel = warehouseScopeLabel,
                    dateRangeLabel = dateRangeLabel,
                    issuerName = actorName,
                    kpiSummary = buildKpiSummaryForPdf(),
                    sections = sections,
                    fileNamePrefix = if (exportFullReportMode) "Warehouse_Full_Report" else "Warehouse_${selectedTab.name}"
                )
                TamperProofAuditLog.logEvent(
                    context = context,
                    actionType = "تصدير تقرير مخازن",
                    targetId = selectedWarehouseScope,
                    details = "تصدير PDF معتمد: $reportTitle | النطاق: $warehouseScopeLabel | الفترة: $dateRangeLabel | الملف: ${saved.fileName}",
                    performedBy = actorName
                )
                saved to reportTitle
            }.onSuccess { (saved, title) ->
                savedExportDialog = SavedDynamicExportDialogData(
                    title = title,
                    isPdf = true,
                    result = saved
                )
            }.onFailure { err ->
                Toast.makeText(context, "تعذر توليد تقرير PDF: ${err.message}", Toast.LENGTH_LONG).show()
            }
            isExporting = false
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = SlateBackground,
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        TextButton(onClick = onNavigateBack) {
                            Text("←", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = PalestineGreen)
                        }
                    },
                    title = {
                        Column {
                            Text(
                                text = "📊 تقارير المخازن التفصيلية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SlateTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "$warehouseScopeLabel • $dateRangeLabel",
                                style = MaterialTheme.typography.labelSmall,
                                color = PalestineGreenDark,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    actions = {
                        TextButton(onClick = onOpenDrawer) {
                            Text("☰", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = PalestineGreen)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PalestineWhite)
                )
            },
            bottomBar = {
                Surface(
                    color = PalestineWhite,
                    shadowElevation = 8.dp,
                    border = BorderStroke(1.dp, SlateBorder)
                ) {
                    if (!canExportReports) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .navigationBarsPadding()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFFEF2F2),
                                border = BorderStroke(1.dp, Color(0xFFFCA5A5))
                            ) {
                                Text(
                                    text = "🔒 التصدير غير مفعّل لحسابك",
                                    color = PalestineRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                                )
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .navigationBarsPadding()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "نطاق التصدير:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextSecondary
                                )
                                FilterChip(
                                    selected = !exportFullReportMode,
                                    onClick = { exportFullReportMode = false },
                                    label = { Text("التبويب الحالي", fontSize = 10.5.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFECFDF5),
                                        selectedLabelColor = Color(0xFF065F46)
                                    )
                                )
                                FilterChip(
                                    selected = exportFullReportMode,
                                    onClick = { exportFullReportMode = true },
                                    label = { Text("التقرير الشامل الكامل", fontSize = 10.5.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFFECFDF5),
                                        selectedLabelColor = Color(0xFF065F46)
                                    )
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { triggerCsvExport() },
                                    enabled = !isExporting,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF047857))
                                ) {
                                    Text(
                                        text = if (isExporting) "جاري التصدير..." else "📊 تصدير Excel (CSV)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        maxLines = 1
                                    )
                                }
                                Button(
                                    onClick = { triggerPdfExport() },
                                    enabled = !isExporting,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E))
                                ) {
                                    Text(
                                        text = if (isExporting) "جاري التوليد..." else "📄 تصدير PDF معتمد",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // ============================================================
                // شريط الفلترة الديناميكي العلوي (النطاق المخزني + الفترة + البحث)
                // ============================================================
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFF064E3B), Color(0xFF047857))
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isRestrictedToSingleWarehouse) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color.White.copy(alpha = 0.16f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "🔒 نطاق مقيّد بمخزنك المعتمد: ${scopedWarehouses.firstOrNull()?.name ?: assignedWarehouseId}",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                            )
                        }
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            item(key = "wh_all") {
                                val isAll = selectedWarehouseScope == WarehouseConstants.ALL_WAREHOUSES
                                Surface(
                                    onClick = { selectedWarehouseScope = WarehouseConstants.ALL_WAREHOUSES },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isAll) Color.White else Color.White.copy(alpha = 0.16f),
                                    border = BorderStroke(1.dp, if (isAll) Color.White else Color.White.copy(alpha = 0.35f))
                                ) {
                                    Text(
                                        text = "🌐 كافة المخازن (تقرير موحّد)",
                                        color = if (isAll) Color(0xFF064E3B) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                            items(allowedWarehouses, key = { it.id }) { wh ->
                                val isSelected = selectedWarehouseScope == wh.id
                                Surface(
                                    onClick = { selectedWarehouseScope = wh.id },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) Color.White else Color.White.copy(alpha = 0.16f),
                                    border = BorderStroke(1.dp, if (isSelected) Color.White else Color.White.copy(alpha = 0.35f))
                                ) {
                                    Text(
                                        text = "🏭 ${wh.name}",
                                        color = if (isSelected) Color(0xFF064E3B) else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }

                    // أزرار الفترة الزمنية السريعة + اختيار تاريخ مخصص
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(DateRangePreset.entries, key = { it.name }) { preset ->
                            val isSelected = selectedPreset == preset
                            Surface(
                                onClick = { selectedPreset = preset },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) Color(0xFFD1FAE5) else Color.White.copy(alpha = 0.14f),
                                border = BorderStroke(1.dp, if (isSelected) Color(0xFF6EE7B7) else Color.White.copy(alpha = 0.25f))
                            ) {
                                Text(
                                    text = "📅 ${preset.label}",
                                    color = if (isSelected) Color(0xFF064E3B) else Color.White,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }

                    if (selectedPreset == DateRangePreset.CUSTOM) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                onClick = { showDatePickerForStart = true },
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "من: $customStartDate",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF064E3B),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                            Surface(
                                onClick = { showDatePickerForStart = false },
                                shape = RoundedCornerShape(8.dp),
                                color = Color.White,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "إلى: $customEndDate",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF064E3B),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    // حقل البحث الفوري
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        singleLine = true,
                        placeholder = {
                            Text(
                                text = "🔎 بحث فوري بالاسم، رقم السند، التشغيلة، العميل، أو العامل...",
                                fontSize = 11.5.sp,
                                color = Color(0xFF64748B)
                            )
                        },
                        trailingIcon = if (searchQuery.isNotBlank()) {
                            {
                                TextButton(onClick = { searchQuery = "" }) {
                                    Text("✕", fontWeight = FontWeight.Bold, color = PalestineRed)
                                }
                            }
                        } else null,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = Color(0xFF6EE7B7),
                            unfocusedBorderColor = Color.White.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 46.dp)
                    )
                }

                // ============================================================
                // شريط التبويبات التحليلية السبعة (مع إخفاء الموازنة لغير المخولين)
                // ============================================================
                val selectedIdx = visibleTabs.indexOf(selectedTab).coerceAtLeast(0)
                ScrollableTabRow(
                    selectedTabIndex = selectedIdx,
                    containerColor = PalestineWhite,
                    contentColor = PalestineGreen,
                    edgePadding = 8.dp
                ) {
                    visibleTabs.forEach { tab ->
                        Tab(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            text = {
                                Text(
                                    text = "${tab.emoji} ${tab.title}",
                                    fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 12.sp,
                                    maxLines = 1
                                )
                            }
                        )
                    }
                }

                // ============================================================
                // محتوى التبويب التحليلي النشط
                // ============================================================
                Box(modifier = Modifier.weight(1f)) {
                    when (selectedTab) {
                        DynamicReportTab.OVERVIEW -> {
                            OverviewReportTab(
                                warehouses = scopedWarehouses,
                                items = scopedItems,
                                clients = scopedClients,
                                clientBillingMap = clientBillingMap,
                                workers = scopedWorkers,
                                occupancyPercent = totalOccupancyPercent,
                                totalOwnMajorUnits = totalOwnMajorUnits,
                                totalOwnMinorUnits = totalOwnMinorUnits,
                                totalQuarantinedUnits = totalQuarantinedUnits,
                                totalInboundUnits = totalInboundUnits,
                                totalOutboundUnits = totalOutboundUnits,
                                totalTransfersUnits = totalTransfersUnits,
                                inTransitCount = scopedShipments.count { it.status == ShipmentStatus.IN_TRANSIT },
                                shortageCount = scopedShipments.count { it.status == ShipmentStatus.SHORTAGE_REPORTED },
                                total3plRemainingPieces = total3plRemainingPieces,
                                total3plReceivables = total3plReceivables,
                                canViewFinance = canViewFinance,
                                approvedBudget = totalApprovedBudget,
                                thirdPartyCollected = total3plCollected,
                                totalExpenses = totalExpensesSum,
                                totalPaidPayroll = totalPaidPayroll,
                                netFinancialBalance = netFinancialBalance
                            )
                        }

                        DynamicReportTab.STOCK_BATCHES -> {
                            StockAndBatchesReportTab(
                                items = scopedItems,
                                batches = scopedBatches,
                                warehouseNameById = warehouseNameById
                            )
                        }

                        DynamicReportTab.MOVEMENTS_TRANSFERS -> {
                            MovementsAndTransfersReportTab(
                                selectedSubFilter = movementSubFilter,
                                onSelectSubFilter = { movementSubFilter = it },
                                movements = filteredMovementsBySubType,
                                shipments = scopedShipments,
                                warehouseNameById = warehouseNameById
                            )
                        }

                        DynamicReportTab.CLIENTS_3PL -> {
                            Clients3plReportTab(
                                clients = scopedClients,
                                clientBillingMap = clientBillingMap,
                                periodTxs = scopedClientTxs,
                                warehouseNameById = warehouseNameById
                            )
                        }

                        DynamicReportTab.FINANCE_PAYROLL -> {
                            if (canViewFinance) {
                                FinanceAndPayrollReportTab(
                                    budgets = scopedBudgets,
                                    expenses = scopedExpenses,
                                    pettyCashAdvances = scopedPettyCash,
                                    payrolls = scopedPayrolls,
                                    approvedBudget = totalApprovedBudget,
                                    thirdPartyCollected = total3plCollected,
                                    totalExpenses = totalExpensesSum,
                                    totalPaidPayroll = totalPaidPayroll,
                                    totalPendingPayroll = totalPendingPayroll,
                                    netBalance = netFinancialBalance,
                                    totalHandledUnits = totalHandledUnitsPeriod,
                                    avgHandlingCostPerUnit = avgHandlingCostPerUnit,
                                    warehouseNameById = warehouseNameById,
                                    resolveTargetLabel = ::resolveTargetLabel
                                )
                            }
                        }

                        DynamicReportTab.STAFF_CUSTODY -> {
                            StaffAndCustodyReportTab(
                                warehouses = scopedWarehouses,
                                workers = scopedWorkers,
                                canViewFinance = canViewFinance,
                                warehouseNameById = warehouseNameById
                            )
                        }

                        DynamicReportTab.BLIND_AUDIT -> {
                            BlindAuditReportTab(
                                audits = scopedBlindAudits,
                                warehouseNameById = warehouseNameById
                            )
                        }
                    }
                }
            }
        }

        // منتقي التاريخ المخصص (من / إلى)
        showDatePickerForStart?.let { isStart ->
            val initialMillis = parseAnyReportDateMillis(if (isStart) customStartDate else customEndDate)
                ?: System.currentTimeMillis()
            val pickerState = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
            DatePickerDialog(
                onDismissRequest = { showDatePickerForStart = null },
                confirmButton = {
                    TextButton(
                        onClick = {
                            pickerState.selectedDateMillis?.let { chosenMs ->
                                val formatted = reportFormatDateOnlyUtc(chosenMs)
                                if (isStart) customStartDate = formatted else customEndDate = formatted
                            }
                            showDatePickerForStart = null
                        }
                    ) {
                        Text("تأكيد", fontWeight = FontWeight.Bold, color = PalestineGreen)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDatePickerForStart = null }) {
                        Text("إلغاء")
                    }
                }
            ) {
                DatePicker(state = pickerState)
            }
        }

        // نافذة تأكيد حفظ التقرير في التنزيلات (Downloads/HumanitarianAid) مع زر فتح ومشاركة
        savedExportDialog?.let { dlg ->
            AlertDialog(
                onDismissRequest = { savedExportDialog = null },
                title = {
                    Text(
                        text = if (dlg.isPdf) "✅ تم حفظ التقرير المعتمد (PDF)" else "✅ تم حفظ تقرير Excel (CSV)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF065F46)
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = dlg.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = SlateTextPrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFECFDF5),
                            border = BorderStroke(1.dp, Color(0xFFA7F3D0)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = "مسار الحفظ بالجوال:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF047857)
                                )
                                Text(
                                    text = dlg.result.humanReadablePath,
                                    fontSize = 11.5.sp,
                                    color = SlateTextPrimary
                                )
                            }
                        }
                        Text(
                            text = "تم توثيق عملية التصدير تلقائياً في سجل الرقابة والتدقيق (SHA-256).",
                            fontSize = 11.sp,
                            color = SlateTextSecondary
                        )
                    }
                },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(
                            onClick = {
                                val ok = if (dlg.isPdf) {
                                    PublicDownloadsExporter.shareSavedPdf(context, dlg.result, dlg.title)
                                } else {
                                    PublicDownloadsExporter.shareSavedCsv(context, dlg.result, dlg.title)
                                }
                                if (!ok) {
                                    Toast.makeText(context, "تعذر فتح قائمة المشاركة", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("📤 مشاركة", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = {
                                val ok = if (dlg.isPdf) {
                                    PublicDownloadsExporter.openSavedPdf(context, dlg.result)
                                } else {
                                    PublicDownloadsExporter.openSavedCsv(context, dlg.result)
                                }
                                if (!ok) {
                                    Toast.makeText(context, "لا يوجد تطبيق مثبت لفتح هذا الملف، يمكنك إيجاده في مجلد التنزيلات.", Toast.LENGTH_LONG).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("📂 فتح الملف", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { savedExportDialog = null }) {
                        Text("إغلاق")
                    }
                }
            )
        }
    }
}

// ============================================================================
// التبويب 1: الملخص الشامل
// ============================================================================
@Composable
private fun OverviewReportTab(
    warehouses: List<Warehouse>,
    items: List<WarehouseItem>,
    clients: List<StorageClient>,
    clientBillingMap: Map<String, ClientBillingSummary>,
    workers: List<WarehouseWorker>,
    occupancyPercent: Int,
    totalOwnMajorUnits: Long,
    totalOwnMinorUnits: Long,
    totalQuarantinedUnits: Long,
    totalInboundUnits: Long,
    totalOutboundUnits: Long,
    totalTransfersUnits: Long,
    inTransitCount: Int,
    shortageCount: Int,
    total3plRemainingPieces: Long,
    total3plReceivables: Double,
    canViewFinance: Boolean,
    approvedBudget: Double,
    thirdPartyCollected: Double,
    totalExpenses: Double,
    totalPaidPayroll: Double,
    netFinancialBalance: Double
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "kpi_row_1") {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportGlassKpiCard(
                    title = "المخازن المشمولة",
                    value = "${warehouses.size}",
                    subtitle = "نشط: ${warehouses.count { it.status == "نشط" }}",
                    accentColor = Color(0xFF059669),
                    modifier = Modifier.weight(1f)
                )
                ReportGlassKpiCard(
                    title = "نسبة الإشغال",
                    value = "$occupancyPercent%",
                    subtitle = "ذاتي + أمانات 3PL",
                    accentColor = if (occupancyPercent >= 90) PalestineRed else Color(0xFF0D9488),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item(key = "kpi_row_2") {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportGlassKpiCard(
                    title = "إجمالي الوحدات (فردي)",
                    value = "$totalOwnMinorUnits",
                    subtitle = "جملة: $totalOwnMajorUnits • أصناف: ${items.size}",
                    accentColor = Color(0xFF047857),
                    modifier = Modifier.weight(1f)
                )
                ReportGlassKpiCard(
                    title = "الحجر الصحي",
                    value = "$totalQuarantinedUnits",
                    subtitle = "تحت الحد الأدنى: ${items.count { it.isLowStock }}",
                    accentColor = if (totalQuarantinedUnits > 0L) Color(0xFFD97706) else Color(0xFF64748B),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item(key = "kpi_row_3") {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportGlassKpiCard(
                    title = "الوارد خلال الفترة",
                    value = "+$totalInboundUnits",
                    subtitle = "مناقلات: $totalTransfersUnits",
                    accentColor = Color(0xFF0284C7),
                    modifier = Modifier.weight(1f)
                )
                ReportGlassKpiCard(
                    title = "الصادر خلال الفترة",
                    value = "-$totalOutboundUnits",
                    subtitle = "قيد النقل: $inTransitCount | عجز: $shortageCount",
                    accentColor = Color(0xFFDC2626),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item(key = "kpi_row_4") {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportGlassKpiCard(
                    title = "أرصدة العملاء (3PL)",
                    value = "$total3plRemainingPieces قطعة",
                    subtitle = "عدد العملاء: ${clients.size}",
                    accentColor = Color(0xFF7C3AED),
                    modifier = Modifier.weight(1f)
                )
                ReportGlassKpiCard(
                    title = "ذمم العملاء المستحقة",
                    value = reportFmtMoney(total3plReceivables),
                    subtitle = "المحصّل: ${reportFmtMoney(thirdPartyCollected)}",
                    accentColor = if (total3plReceivables > 0.0) PalestineRed else Color(0xFF059669),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        if (canViewFinance) {
            item(key = "finance_summary_overview") {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                    border = BorderStroke(1.2.dp, Color(0xFF6EE7B7)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "💰 الخلاصة المالية المجمّعة (للمخوّلين)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp,
                            color = Color(0xFF065F46)
                        )
                        HorizontalDivider(color = Color(0xFFA7F3D0))
                        ReportKeyValueRow("الموازنة المعتمدة:", reportFmtMoney(approvedBudget), Color(0xFF065F46))
                        ReportKeyValueRow("إيرادات التخزين للغير المحصّلة:", reportFmtMoney(thirdPartyCollected), Color(0xFF0284C7))
                        ReportKeyValueRow("إجمالي المصروفات التشغيلية:", reportFmtMoney(totalExpenses), Color(0xFFB45309))
                        ReportKeyValueRow("الرواتب المدفوعة:", reportFmtMoney(totalPaidPayroll), Color(0xFF7C3AED))
                        HorizontalDivider(color = Color(0xFFA7F3D0))
                        ReportKeyValueRow(
                            "صافي الرصيد المالي للمخازن:",
                            reportFmtMoney(netFinancialBalance),
                            if (netFinancialBalance >= 0.0) Color(0xFF047857) else PalestineRed
                        )
                    }
                }
            }
        }

        item(key = "warehouses_breakdown_header") {
            Text(
                text = "🏭 تفصيل المخازن ضمن النطاق (${warehouses.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = SlateTextPrimary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (warehouses.isEmpty()) {
            item(key = "empty_wh") {
                ReportEmptyBanner("لا توجد مخازن مطابقة لنطاق العرض الحالي.")
            }
        } else {
            items(warehouses, key = { it.id }) { wh ->
                val whItems = items.filter { it.warehouseId == wh.id }
                val whOwn = whItems.sumOf { it.totalMinorQty }
                val wh3pl = clients.filter { it.warehouseId == wh.id }
                    .sumOf { clientBillingMap[it.id]?.remainingPieces ?: 0L }
                val whOcc = if (wh.maxCapacity > 0L) (((whOwn + wh3pl) * 100L) / wh.maxCapacity).toInt().coerceIn(0, 100) else 0
                val whWorkers = workers.count { it.warehouseId == wh.id && it.isActive }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🏭 ${wh.name}", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = SlateTextPrimary)
                            ReportStatusBadge(
                                text = "${wh.storageType} • ${wh.status}",
                                bg = Color(0xFFECFDF5),
                                fg = Color(0xFF065F46)
                            )
                        }
                        Text(
                            text = "أمين المخزن: ${wh.keeperName.ifBlank { "غير محدد" }} • الموقع: ${wh.location.ifBlank { "-" }} • الطاقم النشط: $whWorkers",
                            fontSize = 11.5.sp,
                            color = SlateTextSecondary
                        )
                        Text(
                            text = "رصيد ذاتي: $whOwn وحدة (${whItems.size} صنف) • أمانات 3PL: $wh3pl قطعة • الإشغال: $whOcc%",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = PalestineGreenDark
                        )
                        LinearProgressIndicator(
                            progress = { whOcc / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (whOcc >= 90) PalestineRed else PalestineGreen,
                            trackColor = Color(0xFFE2E8F0)
                        )
                    }
                }
            }
        }
    }
}

// ============================================================================
// التبويب 2: الأرصدة والتشغيلات (FEFO + Burn-Rate + الحجر الصحي)
// ============================================================================
@Composable
private fun StockAndBatchesReportTab(
    items: List<WarehouseItem>,
    batches: List<StockBatch>,
    warehouseNameById: Map<String, String>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (items.isEmpty()) {
            item { ReportEmptyBanner("لا توجد أصناف مخزنية مطابقة لفلتر البحث والنطاق الحالي.") }
        } else {
            items(items, key = { it.id }) { item ->
                val itemBatches = batches
                    .filter { it.itemId == item.id && !it.isQuarantined }
                    .sortedBy { it.expiryDate.ifBlank { "9999-12-31" } }
                val quarantinedQty = batches
                    .filter { it.itemId == item.id && it.isQuarantined }
                    .sumOf { it.remainingMinorQty }
                val burnDays = remember(item.id, item.totalMinorQty) {
                    WarehouseErpStore.predictDaysUntilStockout(item.id)
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(
                        1.dp,
                        if (item.isLowStock) Color(0xFFFCA5A5) else SlateBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "📦 ${item.name}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = SlateTextPrimary
                                )
                                Text(
                                    text = "${warehouseNameById[item.warehouseId] ?: item.warehouseId} • ${item.category.ifBlank { "عام" }}",
                                    fontSize = 11.sp,
                                    color = SlateTextSecondary
                                )
                            }
                            ReportStatusBadge(
                                text = item.formatDualQuantity(),
                                bg = if (item.isLowStock) Color(0xFFFEF2F2) else Color(0xFFECFDF5),
                                fg = if (item.isLowStock) PalestineRed else Color(0xFF065F46)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val burnColor = when {
                                burnDays == null -> Color(0xFF065F46)
                                burnDays < 7 -> Color(0xFFB45309)
                                else -> Color(0xFF0369A1)
                            }
                            val burnBg = when {
                                burnDays == null -> Color(0xFFECFDF5)
                                burnDays < 7 -> Color(0xFFFFFBEB)
                                else -> Color(0xFFF0F9FF)
                            }
                            ReportStatusBadge(
                                text = if (burnDays != null) "⏳ يكفي لـ $burnDays أيام (Burn-Rate)" else "✅ مخزون مستقر",
                                bg = burnBg,
                                fg = burnColor
                            )
                            if (quarantinedQty > 0L) {
                                ReportStatusBadge(
                                    text = "⚠️ حجر صحي: $quarantinedQty ${item.minorUnitName}",
                                    bg = Color(0xFFFEF2F2),
                                    fg = PalestineRed
                                )
                            }
                        }

                        if (itemBatches.isNotEmpty()) {
                            HorizontalDivider(color = Color(0xFFE2E8F0))
                            Text(
                                text = "التشغيلات النشطة (مرتبة حسب الأقرب انتهاءً — FEFO):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = SlateTextSecondary
                            )
                            itemBatches.forEach { b ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFF8FAFC),
                                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 8.dp, vertical = 5.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "🏷️ ${b.batchNo} • ${b.zoneName} • المانح: ${b.donorName.ifBlank { "-" }}",
                                            fontSize = 11.sp,
                                            color = SlateTextPrimary,
                                            modifier = Modifier.weight(1f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "📅 ${b.expiryDate.ifBlank { "-" }} | ${b.remainingMinorQty} ${item.minorUnitName}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PalestineGreenDark
                                        )
                                    }
                                }
                            }
                        } else if (item.expiryDate.isNotBlank()) {
                            Text(
                                text = "📅 أقرب تاريخ انتهاء: ${item.expiryDate}",
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// التبويب 3: الوارد والصادر والمناقلات + In-Transit + محاضر العجز
// ============================================================================
@Composable
private fun MovementsAndTransfersReportTab(
    selectedSubFilter: MovementSubFilter,
    onSelectSubFilter: (MovementSubFilter) -> Unit,
    movements: List<StockMovement>,
    shipments: List<InTransitShipment>,
    warehouseNameById: Map<String, String>
) {
    val inTransitList = remember(shipments) { shipments.filter { it.status == ShipmentStatus.IN_TRANSIT } }
    val shortageList = remember(shipments) { shipments.filter { it.status == ShipmentStatus.SHORTAGE_REPORTED } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "sub_filter_chips") {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(MovementSubFilter.entries, key = { it.name }) { sub ->
                    FilterChip(
                        selected = selectedSubFilter == sub,
                        onClick = { onSelectSubFilter(sub) },
                        label = { Text(sub.label, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PalestineGreen,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        if (inTransitList.isNotEmpty() || shortageList.isNotEmpty()) {
            item(key = "shipments_section") {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB)),
                    border = BorderStroke(1.dp, Color(0xFFFCD34D)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "🚚 الشحنات قيد النقل (${inTransitList.size}) ومحاضر العجز (${shortageList.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color(0xFF92400E)
                        )
                        (inTransitList + shortageList).forEach { sh ->
                            val isShortage = sh.status == ShipmentStatus.SHORTAGE_REPORTED
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isShortage) Color(0xFFFEF2F2) else Color.White,
                                border = BorderStroke(1.dp, if (isShortage) Color(0xFFFCA5A5) else Color(0xFFFDE68A)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    Text(
                                        text = "${if (isShortage) "🚨 محضر عجز" else "🚚 قيد النقل"} • ${sh.itemName} (${sh.voucherNo.ifBlank { sh.shipmentId }})",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (isShortage) PalestineRed else Color(0xFF92400E)
                                    )
                                    Text(
                                        text = "${warehouseNameById[sh.fromWarehouseId] ?: sh.fromWarehouseId} ⬅ ${warehouseNameById[sh.toWarehouseId] ?: sh.toWarehouseId} • السائق: ${sh.driverName.ifBlank { "-" }}",
                                        fontSize = 11.sp,
                                        color = SlateTextSecondary
                                    )
                                    Text(
                                        text = "المرسل: ${sh.sentMinorQty} | المستلم: ${sh.receivedMinorQty} | العجز: ${sh.shortageQty} • ${sh.sentAt}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isShortage) PalestineRed else SlateTextPrimary
                                    )
                                    if (sh.shortageAuditHash.isNotBlank()) {
                                        Text(
                                            text = "SHA-256: ${sh.shortageAuditHash.take(20)}...",
                                            fontSize = 10.sp,
                                            color = SlateTextMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (movements.isEmpty()) {
            item { ReportEmptyBanner("لا توجد حركات مخزنية مسجلة ضمن الفلتر والفترة المختارة.") }
        } else {
            items(movements, key = { it.id }) { mov ->
                val isPositive = mov.totalMinorDelta >= 0L
                val sign = if (isPositive) "+" else "-"
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = mov.type.arabicTitle,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = SlateTextPrimary
                            )
                            ReportStatusBadge(
                                text = "$sign${abs(mov.totalMinorDelta)} وحدة",
                                bg = if (isPositive) Color(0xFFECFDF5) else Color(0xFFFEF2F2),
                                fg = if (isPositive) Color(0xFF065F46) else PalestineRed
                            )
                        }
                        Text(
                            text = "الصنف: ${mov.itemName} • رقم السند: ${mov.voucherNo}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = PalestineGreenDark
                        )
                        Text(
                            text = buildString {
                                append("المخزن: ${warehouseNameById[mov.warehouseId] ?: mov.warehouseId}")
                                if (!mov.targetWarehouseId.isNullOrBlank()) {
                                    append(" ⬅ ${warehouseNameById[mov.targetWarehouseId] ?: mov.targetWarehouseId}")
                                }
                                append(" • التاريخ: ${mov.date}")
                            },
                            fontSize = 11.sp,
                            color = SlateTextSecondary
                        )
                        if (mov.batchNo.isNotBlank() || mov.supplierOrDonor.isNotBlank() || mov.recipientOrProject.isNotBlank()) {
                            Text(
                                text = listOfNotNull(
                                    mov.batchNo.takeIf { it.isNotBlank() }?.let { "تشغيلة: $it" },
                                    mov.supplierOrDonor.takeIf { it.isNotBlank() }?.let { "مورد/مانح: $it" },
                                    mov.recipientOrProject.takeIf { it.isNotBlank() }?.let { "مستلم/مشروع: $it" }
                                ).joinToString(" • "),
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }
                        if (mov.notes.isNotBlank()) {
                            Text(
                                text = "ملاحظة: ${mov.notes}",
                                fontSize = 11.sp,
                                color = SlateTextMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// التبويب 4: التخزين للغير (3PL)
// ============================================================================
@Composable
private fun Clients3plReportTab(
    clients: List<StorageClient>,
    clientBillingMap: Map<String, ClientBillingSummary>,
    periodTxs: List<ClientStorageTx>,
    warehouseNameById: Map<String, String>
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (clients.isEmpty()) {
            item { ReportEmptyBanner("لا يوجد عملاء تخزين للغير (3PL) ضمن النطاق الحالي.") }
        } else {
            items(clients, key = { it.id }) { cli ->
                val b = clientBillingMap[cli.id] ?: WarehouseErpStore.calculateClientBilling(cli.id)
                val txCountInPeriod = periodTxs.count { it.clientId == cli.id }
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, if (b.netAmountDue > 0.0) Color(0xFFFCA5A5) else SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("🤝 ${cli.clientName}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SlateTextPrimary)
                                Text(
                                    text = "${warehouseNameById[cli.warehouseId] ?: cli.warehouseId} • ${cli.billingModel.arabicLabel} (${reportFmtMoney(cli.unitRate)})",
                                    fontSize = 11.sp,
                                    color = SlateTextSecondary
                                )
                            }
                            ReportStatusBadge(
                                text = "المتبقي: ${b.remainingPieces} قطعة",
                                bg = Color(0xFFF5F3FF),
                                fg = Color(0xFF6D28D9)
                            )
                        }
                        HorizontalDivider(color = Color(0xFFE2E8F0))
                        ReportKeyValueRow("إجمالي المودع / المسحوب:", "${b.totalDepositedPieces} مودع  |  ${b.totalWithdrawnPieces} مسحوب", SlateTextPrimary)
                        ReportKeyValueRow("أيام التخزين المستحقة:", "${b.totalBillableStorageDays} يوم (فترة سماح: ${cli.freeGraceDays} يوم)", SlateTextSecondary)
                        ReportKeyValueRow("إجمالي الأجرة المستحقة (تخزين + مناولة):", reportFmtMoney(b.totalCharges), Color(0xFF0369A1))
                        ReportKeyValueRow("إجمالي المدفوع:", reportFmtMoney(b.totalPaid), Color(0xFF059669))
                        ReportKeyValueRow(
                            "المتبقي في ذمة العميل:",
                            reportFmtMoney(b.netAmountDue),
                            if (b.netAmountDue > 0.0) PalestineRed else Color(0xFF059669)
                        )
                        Text(
                            text = "حركات العميل خلال الفترة المحددة: $txCountInPeriod • التواصل: ${cli.contactPerson.ifBlank { "-" }} (${cli.phone.ifBlank { "-" }})",
                            fontSize = 10.5.sp,
                            color = SlateTextMuted
                        )
                    }
                }
            }
        }
    }
}

// ============================================================================
// التبويب 5: الموازنة والرواتب (للمخوّلين مالياً فقط)
// ============================================================================
@Composable
private fun FinanceAndPayrollReportTab(
    budgets: List<WarehouseBudgetEntry>,
    expenses: List<WarehouseExpense>,
    pettyCashAdvances: List<PettyCashAdvance>,
    payrolls: List<WarehousePayrollRecord>,
    approvedBudget: Double,
    thirdPartyCollected: Double,
    totalExpenses: Double,
    totalPaidPayroll: Double,
    totalPendingPayroll: Double,
    netBalance: Double,
    totalHandledUnits: Long,
    avgHandlingCostPerUnit: Double,
    warehouseNameById: Map<String, String>,
    resolveTargetLabel: (String) -> String
) {
    val expensesByCategory = remember(expenses) {
        expenses.groupBy { it.category.ifBlank { "نثريات" } }
            .mapValues { (_, list) -> list.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }
    }
    val expensesByTarget = remember(expenses) {
        expenses.groupBy { it.allocatedTarget.ifBlank { "GENERAL" } }
            .mapValues { (_, list) -> list.sumOf { it.amount } }
            .entries.sortedByDescending { it.value }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "fin_kpi_card") {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                border = BorderStroke(1.2.dp, Color(0xFF6EE7B7)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("💰 الملخص المالي وتكلفة المناولة", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF065F46))
                    HorizontalDivider(color = Color(0xFFA7F3D0))
                    ReportKeyValueRow("الموازنة المعتمدة (${budgets.size} بند):", reportFmtMoney(approvedBudget), Color(0xFF065F46))
                    ReportKeyValueRow("إيرادات 3PL المحصّلة:", reportFmtMoney(thirdPartyCollected), Color(0xFF0284C7))
                    ReportKeyValueRow("المصروفات التشغيلية (${expenses.size}):", reportFmtMoney(totalExpenses), Color(0xFFB45309))
                    ReportKeyValueRow("الرواتب المدفوعة / المعلقة:", "${reportFmtMoney(totalPaidPayroll)} / ${reportFmtMoney(totalPendingPayroll)}", Color(0xFF7C3AED))
                    ReportKeyValueRow("صافي الرصيد المالي:", reportFmtMoney(netBalance), if (netBalance >= 0.0) Color(0xFF047857) else PalestineRed)
                    ReportKeyValueRow("تكلفة مناولة الوحدة ($totalHandledUnits وحدة):", reportFmtMoney(avgHandlingCostPerUnit), Color(0xFF0F766E))
                }
            }
        }

        if (expensesByCategory.isNotEmpty()) {
            item(key = "exp_by_cat") {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("📂 المصروفات حسب التصنيف", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateTextPrimary)
                        HorizontalDivider(color = Color(0xFFE2E8F0))
                        expensesByCategory.forEach { (cat, sum) ->
                            ReportKeyValueRow(cat, reportFmtMoney(sum), Color(0xFFB45309))
                        }
                    }
                }
            }
        }

        if (expensesByTarget.isNotEmpty()) {
            item(key = "exp_by_target") {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("🎯 المصروفات حسب جهة التحميل", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateTextPrimary)
                        HorizontalDivider(color = Color(0xFFE2E8F0))
                        expensesByTarget.forEach { (target, sum) ->
                            ReportKeyValueRow(resolveTargetLabel(target), reportFmtMoney(sum), Color(0xFF0369A1))
                        }
                    }
                }
            }
        }

        item(key = "petty_cash_header") {
            Text(
                text = "💵 العُهد النقدية لأمناء المخازن (${pettyCashAdvances.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 13.5.sp,
                color = SlateTextPrimary
            )
        }
        if (pettyCashAdvances.isEmpty()) {
            item(key = "no_petty") { ReportEmptyBanner("لا توجد عُهد نقدية مسجلة خلال الفترة المحددة.") }
        } else {
            items(pettyCashAdvances, key = { it.id }) { pc ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, if (pc.status == PettyCashStatus.OPEN) Color(0xFFFCD34D) else SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("💵 ${pc.keeperName} • ${warehouseNameById[pc.warehouseId] ?: pc.warehouseId}", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            ReportStatusBadge(
                                text = pc.status.arabicLabel,
                                bg = if (pc.status == PettyCashStatus.OPEN) Color(0xFFFFFBEB) else Color(0xFFECFDF5),
                                fg = if (pc.status == PettyCashStatus.OPEN) Color(0xFFB45309) else Color(0xFF065F46)
                            )
                        }
                        Text(
                            text = "العهدة: ${reportFmtMoney(pc.amount)} | المنصرف: ${reportFmtMoney(pc.spentAmount)} | المتبقي: ${reportFmtMoney(pc.remainingAmount)} • ${pc.date}",
                            fontSize = 11.5.sp,
                            color = SlateTextSecondary
                        )
                    }
                }
            }
        }

        item(key = "payrolls_header") {
            Text(
                text = "🧾 سجل الرواتب والأجور (${payrolls.size})",
                fontWeight = FontWeight.Bold,
                fontSize = 13.5.sp,
                color = SlateTextPrimary
            )
        }
        if (payrolls.isEmpty()) {
            item(key = "no_pay") { ReportEmptyBanner("لا توجد سجلات رواتب ضمن الفترة المحددة.") }
        } else {
            items(payrolls, key = { it.id }) { pr ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${pr.workerName} (${pr.role})", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                            Text(
                                text = "${warehouseNameById[pr.warehouseId] ?: pr.warehouseId} • الفترة: ${pr.periodLabel} • ${pr.payType.arabicLabel}",
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(reportFmtMoney(pr.amount), fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = PalestineGreenDark)
                            Text(
                                text = if (pr.isPaid) "✅ مصروف (${pr.paidDate})" else "⏳ معلّق",
                                fontSize = 10.5.sp,
                                color = if (pr.isPaid) Color(0xFF059669) else Color(0xFFB45309)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// التبويب 6: الطاقم والعُهد
// ============================================================================
@Composable
private fun StaffAndCustodyReportTab(
    warehouses: List<Warehouse>,
    workers: List<WarehouseWorker>,
    canViewFinance: Boolean,
    warehouseNameById: Map<String, String>
) {
    val roleCounts = remember(workers) {
        workers.groupBy { it.role.ifBlank { "عامل" } }
            .mapValues { it.value.size }
            .entries.sortedByDescending { it.value }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "staff_summary") {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                border = BorderStroke(1.dp, Color(0xFFA7F3D0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(
                        text = "👥 ملخص القوى البشرية (${workers.size} عامل • نشط: ${workers.count { it.isActive }})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        color = Color(0xFF065F46)
                    )
                    if (roleCounts.isNotEmpty()) {
                        Text(
                            text = roleCounts.joinToString("  •  ") { "${it.key}: ${it.value}" },
                            fontSize = 11.5.sp,
                            color = SlateTextPrimary
                        )
                    }
                }
            }
        }

        item(key = "keepers_header") {
            Text("🔑 أمناء المخازن وعُهد التجهيزات (${warehouses.size})", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = SlateTextPrimary)
        }
        items(warehouses, key = { "keeper_${it.id}" }) { wh ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                border = BorderStroke(1.dp, SlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("🏭 ${wh.name} (${wh.location.ifBlank { "-" }})", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateTextPrimary)
                    Text(
                        text = "أمين المخزن: ${wh.keeperName.ifBlank { "غير محدد" }} • الهوية: ${wh.keeperId.ifBlank { "-" }} • الجوال: ${wh.keeperPhone.ifBlank { "-" }}",
                        fontSize = 11.5.sp,
                        color = SlateTextSecondary
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "🧰 عُهد التجهيزات والمعدات: ${wh.equipmentNotes.ifBlank { "لا توجد عُهد تجهيزات مسجلة" }}",
                            fontSize = 11.5.sp,
                            color = SlateTextPrimary,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }

        item(key = "workers_header") {
            Text("👷 كشف العاملين (${workers.size})", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = SlateTextPrimary)
        }
        if (workers.isEmpty()) {
            item { ReportEmptyBanner("لا يوجد عاملون مسجلون ضمن نطاق الفلترة الحالي.") }
        } else {
            items(workers, key = { it.id }) { w ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("👤 ${w.name}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SlateTextPrimary)
                            Text(
                                text = "${w.role} • ${warehouseNameById[w.warehouseId] ?: w.warehouseId} • ${w.payType.arabicLabel}",
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            if (canViewFinance) {
                                Text(reportFmtMoney(w.rate), fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PalestineGreenDark)
                            }
                            ReportStatusBadge(
                                text = if (w.isActive) "نشط" else "متوقف",
                                bg = if (w.isActive) Color(0xFFECFDF5) else Color(0xFFFEF2F2),
                                fg = if (w.isActive) Color(0xFF065F46) else PalestineRed
                            )
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// التبويب 7: الجرد الأعمى والفروقات
// ============================================================================
@Composable
private fun BlindAuditReportTab(
    audits: List<StockMovement>,
    warehouseNameById: Map<String, String>
) {
    val matchedCount = remember(audits) { audits.count { it.totalMinorDelta == 0L } }
    val deficitCount = remember(audits) { audits.count { it.totalMinorDelta < 0L } }
    val surplusCount = remember(audits) { audits.count { it.totalMinorDelta > 0L } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "audit_summary_bar") {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportGlassKpiCard("مطابق", "$matchedCount", "فارق = 0", Color(0xFF059669), Modifier.weight(1f))
                ReportGlassKpiCard("عجز جرد", "$deficitCount", "نقص فعلي", PalestineRed, Modifier.weight(1f))
                ReportGlassKpiCard("زيادة جرد", "$surplusCount", "فائض فعلي", Color(0xFF0284C7), Modifier.weight(1f))
            }
        }

        if (audits.isEmpty()) {
            item { ReportEmptyBanner("لا توجد جلسات جرد أعمى أو تسويات مسجلة خلال الفترة المحددة.") }
        } else {
            items(audits, key = { it.id }) { mov ->
                val parsed = parseBlindAuditNotes(mov.notes, mov.totalMinorDelta)
                val badgeBg = when {
                    mov.totalMinorDelta == 0L -> Color(0xFFECFDF5)
                    mov.totalMinorDelta < 0L -> Color(0xFFFEF2F2)
                    else -> Color(0xFFF0F9FF)
                }
                val badgeFg = when {
                    mov.totalMinorDelta == 0L -> Color(0xFF065F46)
                    mov.totalMinorDelta < 0L -> PalestineRed
                    else -> Color(0xFF0369A1)
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                    border = BorderStroke(1.dp, if (mov.totalMinorDelta < 0L) Color(0xFFFCA5A5) else SlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🕵️ ${mov.itemName}", fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = SlateTextPrimary)
                            ReportStatusBadge(
                                text = "الفارق: ${if (mov.totalMinorDelta > 0L) "+${mov.totalMinorDelta}" else "${mov.totalMinorDelta}"}",
                                bg = badgeBg,
                                fg = badgeFg
                            )
                        }
                        Text(
                            text = "${warehouseNameById[mov.warehouseId] ?: mov.warehouseId} • السند: ${mov.voucherNo} • ${mov.date}",
                            fontSize = 11.sp,
                            color = SlateTextSecondary
                        )
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("الدفتري: ${parsed.systemBookLabel}", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = SlateTextPrimary)
                            Text("الفعلي: ${parsed.physicalCountLabel}", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold, color = PalestineGreenDark)
                        }
                        if (mov.notes.isNotBlank()) {
                            Text(text = mov.notes, fontSize = 11.sp, color = SlateTextMuted)
                        }
                        Text(
                            text = "منفذ الجرد: ${mov.performedBy.ifBlank { "لجنة الجرد" }}",
                            fontSize = 10.5.sp,
                            color = SlateTextSecondary
                        )
                    }
                }
            }
        }
    }
}

// ============================================================================
// مكونات بصرية مساعدة ودوال التاريخ/التنسيق
// ============================================================================
@Composable
private fun ReportGlassKpiCard(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = PalestineWhite),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.28f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(11.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Text(text = title, fontSize = 11.sp, color = SlateTextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = accentColor, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(text = subtitle, fontSize = 10.sp, color = SlateTextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ReportStatusBadge(text: String, bg: Color, fg: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bg,
        border = BorderStroke(0.8.dp, fg.copy(alpha = 0.30f))
    ) {
        Text(
            text = text,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun ReportKeyValueRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 11.5.sp, color = SlateTextSecondary, modifier = Modifier.weight(1f))
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = valueColor)
    }
}

@Composable
private fun ReportEmptyBanner(message: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF8FAFC),
        border = BorderStroke(1.dp, SlateBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = message,
            fontSize = 12.sp,
            color = SlateTextSecondary,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(16.dp)
        )
    }
}

private data class ParsedBlindAuditRow(
    val systemBookLabel: String,
    val physicalCountLabel: String
)

private fun parseBlindAuditNotes(notes: String, delta: Long): ParsedBlindAuditRow {
    val bookRegex = Regex("الدفتري=([0-9]+)")
    val actualRegex = Regex("الفعلي=([0-9]+)")
    val book = bookRegex.find(notes)?.groupValues?.getOrNull(1)
    val actual = actualRegex.find(notes)?.groupValues?.getOrNull(1)
    return ParsedBlindAuditRow(
        systemBookLabel = book ?: "-",
        physicalCountLabel = actual ?: if (delta == 0L) "مطابق" else "-"
    )
}

private fun reportFmtMoney(amount: Double): String = String.format(Locale.US, "%.2f", amount)

private fun reportNowDateTime(): String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())

private fun reportFormatDateOnly(millis: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(millis))

private fun reportFormatDateOnlyUtc(millis: Long): String {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    sdf.timeZone = TimeZone.getTimeZone("UTC")
    return sdf.format(Date(millis))
}

private fun computeDateRangeMillis(
    preset: DateRangePreset,
    customStart: String,
    customEnd: String
): Pair<Long?, Long?> {
    val now = System.currentTimeMillis()
    return when (preset) {
        DateRangePreset.ALL_TIME -> null to null
        DateRangePreset.LAST_7_DAYS -> (now - 7L * 86_400_000L) to (now + 86_400_000L)
        DateRangePreset.LAST_30_DAYS -> (now - 30L * 86_400_000L) to (now + 86_400_000L)
        DateRangePreset.THIS_MONTH -> {
            val cal = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            cal.timeInMillis to (now + 86_400_000L)
        }
        DateRangePreset.CUSTOM -> {
            val startMs = parseAnyReportDateMillis(customStart)
            val endMs = parseAnyReportDateMillis(customEnd)?.let { it + 86_399_999L }
            startMs to endMs
        }
    }
}

private fun parseAnyReportDateMillis(raw: String): Long? {
    val clean = raw.trim()
    if (clean.isEmpty()) return null
    val patterns = listOf("yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM-dd", "yyyy-MM")
    for (p in patterns) {
        val parsed = runCatching {
            SimpleDateFormat(p, Locale.US).apply { isLenient = false }.parse(clean)?.time
        }.getOrNull()
        if (parsed != null) return parsed
    }
    return null
}

private fun csvCell(raw: String): String = "\"${raw.replace("\"", "\"\"")}\""

private fun csvRow(vararg cells: String): String = cells.joinToString(",") { csvCell(it) }
