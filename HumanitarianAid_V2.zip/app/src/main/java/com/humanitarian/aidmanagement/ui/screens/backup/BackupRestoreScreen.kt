package com.humanitarian.aidmanagement.ui.screens.backup

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.common.api.ApiException
import com.humanitarian.aidmanagement.AidApplication
import com.humanitarian.aidmanagement.data.backup.*
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.PalestineGreen
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    database: AidDatabase,
    repository: AidRepository? = null,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val effectiveRepo = repository
        ?: (context.applicationContext as? AidApplication)?.repository
        ?: AidApplication.instance.repository
    val localBackupManager = remember { DatabaseBackupManager(context, database) }
    val cloudBackupManager = remember { GoogleDriveBackupManager(context, database) }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: سحابي Google Drive, 1: محلي (الهاتف)

    // حالة Google Drive
    var googleAccount by remember { mutableStateOf<GoogleSignInAccount?>(null) }
    var isCloudProcessing by remember { mutableStateOf(false) }
    var cloudStatusMessage by remember { mutableStateOf<String?>(null) }
    var cloudBackupsList by remember { mutableStateOf<List<CloudBackupItem>>(emptyList()) }
    var selectedCloudBackupToRestore by remember { mutableStateOf<CloudBackupItem?>(null) }
    var showRestartDialog by remember { mutableStateOf(false) }

    // حالة النسخ المحلي
    var isLocalProcessing by remember { mutableStateOf(false) }
    var localOperationResult by remember { mutableStateOf<BackupResult?>(null) }

    // تسجيل الدخول لحساب Google
    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)
                googleAccount = account
                cloudStatusMessage = "تم تسجيل الدخول بنجاح بحساب: ${account?.email}"
                // تحديث قائمة النسخ السحابية
                account?.let { acc ->
                    scope.launch {
                        isCloudProcessing = true
                        cloudBackupsList = cloudBackupManager.listGoogleDriveBackups(acc)
                        isCloudProcessing = false
                    }
                }
            } catch (e: Exception) {
                cloudStatusMessage = "فشل تسجيل الدخول بحساب Google: ${e.message}"
            }
        } else {
            cloudStatusMessage = "تم إلغاء تسجيل الدخول بحساب Google"
        }
    }

    // مشغل حفظ النسخة الاحتياطية عبر منتقي ملفات النظام (SAF CreateDocument)
    val exportZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                isLocalProcessing = true
                val res = localBackupManager.exportEncryptedDatabaseToSafUri(uri)
                localOperationResult = res
                isLocalProcessing = false
            }
        }
    }

    // مشغل اختيار ملفات النسخ الاحتياطي (SAF OpenDocument) للاستعادة المباشرة والآمنة
    val zipFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                // 1. Open safe input stream from SAF Uri
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream == null) return@rememberLauncherForActivityResult // Handle error gracefully

                val zipInputStream = java.util.zip.ZipInputStream(inputStream)
                var entry = zipInputStream.nextEntry

                while (entry != null) {
                    // 2. ONLY extract the database file, ignore metadata.json
                    if (entry.name.endsWith(".db")) {
                        val dbName = "humanitarian_aid_database.db" // MUST match your actual DB name
                        val dbFile = context.getDatabasePath(dbName)
                        
                        // 3. Obliterate old database entirely to prevent SQLITE_CORRUPT
                        database.close() // Ensure your Room database instance is closed here
                        context.deleteDatabase(dbName)
                        
                        // 4. Write new database synchronously
                        val outputStream = java.io.FileOutputStream(dbFile)
                        zipInputStream.copyTo(outputStream)
                        outputStream.flush()
                        outputStream.fd.sync() // CRITICAL: Force write to disk
                        outputStream.close()
                        break // Exit loop once DB is extracted
                    }
                    zipInputStream.closeEntry()
                    entry = zipInputStream.nextEntry
                }
                zipInputStream.close()

                // 5. Hard Restart App to reload Room DB safely
                android.widget.Toast.makeText(context, "تم استعادة النسخة بنجاح، سيتم إعادة التشغيل", android.widget.Toast.LENGTH_LONG).show()
                Thread.sleep(1000) // Brief delay for Toast
                val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                intent?.addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK)
                context.startActivity(intent)
                kotlin.system.exitProcess(0)

            } catch (e: Exception) {
                e.printStackTrace()
                android.widget.Toast.makeText(context, "فشلت عملية استعادة النسخة: ${e.localizedMessage ?: e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(Unit) {
        googleAccount = cloudBackupManager.getSignedInAccount()

        googleAccount?.let { acc ->
            isCloudProcessing = true
            cloudBackupsList = cloudBackupManager.listGoogleDriveBackups(acc)
            isCloudProcessing = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("النسخ الاحتياطي واستعادة البيانات", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("محرك النسخ السحابي Google Drive والنسخ المحلي", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
        ) {
            // شريط التبويب
            PrimaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = PalestineGreen
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("السحابة (Google Drive)", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.SdCard, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("الذاكرة المحلية (الهاتف)", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("تزامن لحظي (Firebase)", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                )
            }

            if (selectedTab == 0) {

                // ==================== تبويب Google Drive السحابي ====================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // بطاقة حالة حساب Google
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .background(Color(0xFF4285F4).copy(alpha = 0.15f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Cloud, contentDescription = null, tint = Color(0xFF4285F4))
                                        }
                                        Column {
                                            Text(
                                                text = if (googleAccount != null) "مرتبط بـ Google Drive" else "غير متصل بحساب Google",
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.titleMedium
                                            )
                                            Text(
                                                text = googleAccount?.email ?: "سجل الدخول لحفظ واسترجاع ملفات قاعدة البيانات سحابياً",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }

                                if (googleAccount == null) {
                                    Button(
                                        onClick = {
                                            val client = cloudBackupManager.getGoogleSignInClient()
                                            googleSignInLauncher.launch(client.signInIntent)
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4285F4)),
                                        modifier = Modifier.fillMaxWidth().height(46.dp)
                                    ) {
                                        Icon(Icons.Default.Login, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("تسجيل الدخول بحساب Google", fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                val acc = googleAccount ?: return@Button
                                                scope.launch {
                                                    isCloudProcessing = true
                                                    val res = cloudBackupManager.backupToGoogleDrive(acc)
                                                    cloudStatusMessage = res.message
                                                    if (res.success) {
                                                        cloudBackupsList = cloudBackupManager.listGoogleDriveBackups(acc)
                                                    }
                                                    isCloudProcessing = false
                                                }
                                            },
                                            enabled = !isCloudProcessing,
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                            modifier = Modifier.weight(1f).height(44.dp)
                                        ) {
                                            if (isCloudProcessing) {
                                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                            } else {
                                                Icon(Icons.Default.CloudUpload, contentDescription = null)
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("رفع نسخة سحابية الآن", fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                val client = cloudBackupManager.getGoogleSignInClient()
                                                client.signOut().addOnCompleteListener {
                                                    googleAccount = null
                                                    cloudBackupsList = emptyList()
                                                    cloudStatusMessage = "تم تسجيل الخروج من Google Drive"
                                                }
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier.height(44.dp)
                                        ) {
                                            Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("خروج")
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // رسالة الحالة السحابية
                    cloudStatusMessage?.let { msg ->
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text(text = msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }

                    // قائمة النسخ السحابية على Google Drive
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "النسخ السحابية المحفوظة (${cloudBackupsList.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (googleAccount != null) {
                                IconButton(
                                    onClick = {
                                        val acc = googleAccount ?: return@IconButton
                                        scope.launch {
                                            isCloudProcessing = true
                                            cloudBackupsList = cloudBackupManager.listGoogleDriveBackups(acc)
                                            isCloudProcessing = false
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }

                    if (googleAccount == null) {
                        item {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
                                    Text("سجل الدخول بحساب Google لاستعراض النسخ السحابية", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    } else if (cloudBackupsList.isEmpty() && !isCloudProcessing) {
                        item {
                            Text(
                                text = "لا توجد نسخ سحابية محفوظة حتى الآن في مجلد ${GoogleDriveBackupManager.BACKUP_FOLDER_NAME}.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        items(cloudBackupsList) { item ->
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .background(PalestineGreen.copy(alpha = 0.1f), RoundedCornerShape(10.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.FolderZip, contentDescription = null, tint = PalestineGreen)
                                        }
                                        Column {
                                            Text(text = item.fileName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            Text(
                                                text = "الحجم: ${item.sizeBytes / 1024} KB • التاريخ: ${item.createdTimeFormatted}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = { selectedCloudBackupToRestore = item },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("استعادة", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (selectedTab == 1) {
                // ==================== تبويب الذاكرة المحلية (الهاتف) ====================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // تصدير واسترجاع قاعدة البيانات المشفرة (SQLCipher ZIP)
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .background(PalestineGreen.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Security, contentDescription = null, tint = PalestineGreen)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("أرشيف قاعدة البيانات المشفرة (SQLCipher ZIP)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("تصدير أو استعادة ملفات القاعدة الثلاثة (.db, -wal, -shm) مشفرة بالكامل لنقلها بأمان بين المناديب دون إنترنت", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val defaultName = "AidManagement_Backup_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.zip"
                                            exportZipLauncher.launch(defaultName)
                                        },
                                        enabled = !isLocalProcessing,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f).height(46.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                                    ) {
                                        if (isLocalProcessing) {
                                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                                        } else {
                                            Icon(Icons.Default.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("تصدير القاعدة المشفرة (ZIP)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            zipFilePickerLauncher.launch(arrayOf("*/*"))
                                        },
                                        enabled = !isLocalProcessing,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f).height(46.dp)
                                    ) {
                                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("استعادة من ملف (ZIP)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // تصدير JSON
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(Color(0xFF0284C7).copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.DataObject, contentDescription = null, tint = Color(0xFF0284C7))
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("تصدير كملف JSON مهيكل", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("ملف متكامل يحتوي على الأسر والأطفال والمساعدات والمشاريع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                Button(
                                    onClick = {
                                        scope.launch {
                                            isLocalProcessing = true
                                            localOperationResult = localBackupManager.exportToJson()
                                            isLocalProcessing = false
                                        }
                                    },
                                    enabled = !isLocalProcessing,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().height(44.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                                ) {
                                    if (isLocalProcessing) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                    } else {
                                        Icon(Icons.Default.FileDownload, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("تصدير نسخة JSON الآن")
                                    }
                                }
                            }
                        }
                    }

                    // تصدير SQL Dump
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(Color(0xFF10B981).copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Storage, contentDescription = null, tint = Color(0xFF10B981))
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("تصدير كملف SQL Dump", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("أوامر SQL قياسية قابلة للتشغيل المباشر على قواعد SQLite", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                Button(
                                    onClick = {
                                        scope.launch {
                                            isLocalProcessing = true
                                            localOperationResult = localBackupManager.exportToSql()
                                            isLocalProcessing = false
                                        }
                                    },
                                    enabled = !isLocalProcessing,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().height(44.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                ) {
                                    if (isLocalProcessing) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                    } else {
                                        Icon(Icons.Default.Code, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("تصدير أوامر SQL Dump")
                                    }
                                }
                            }
                        }
                    }

                    // عرض نتيجة العملية المحلية
                    localOperationResult?.let { res ->
                        item {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (res.success) Color(0xFF10B981).copy(alpha = 0.15f)
                                    else MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(
                                            imageVector = if (res.success) Icons.Default.CheckCircle else Icons.Default.Error,
                                            contentDescription = null,
                                            tint = if (res.success) Color(0xFF10B981) else MaterialTheme.colorScheme.error
                                        )
                                        Text(text = res.message, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    }
                                    if (res.filePath != null) {
                                        Text(text = "المسار: ${res.filePath}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }


                }
            } else {
                // ==================== تبويب التزامن اللحظي (Firebase Delta Sync) ====================
                com.humanitarian.aidmanagement.ui.screens.sync.FirebaseDeltaSyncScreen(
                    repository = effectiveRepo,
                    onNavigateBack = onNavigateBack
                )
            }
        }
    }


    // نافذة تأكيد استعادة النسخة السحابية من Google Drive
    selectedCloudBackupToRestore?.let { cloudItem ->
        AlertDialog(
            onDismissRequest = { selectedCloudBackupToRestore = null },
            icon = { Icon(Icons.Default.CloudDownload, contentDescription = null, tint = PalestineGreen) },
            title = { Text("استعادة من Google Drive", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "هل أنت متأكد من استعادة النسخة الاحتياطية (${cloudItem.fileName})؟\n\n" +
                    "⚠️ تحذير: سيتم استبدال قاعدة البيانات المحلية بالكامل بالنسخة المسترجعة من السحابة، وسيتم إعادة تشغيل التطبيق لتهيئة الجداول."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val acc = googleAccount ?: return@Button
                        val fileId = cloudItem.fileId
                        selectedCloudBackupToRestore = null
                        scope.launch {
                            isCloudProcessing = true
                            val result = cloudBackupManager.restoreFromGoogleDrive(acc, fileId)
                            isCloudProcessing = false
                            cloudStatusMessage = result.message
                            if (result.success && result.requiresRestart) {
                                showRestartDialog = true
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                ) {
                    Text("نعم، استعادة واستبدال")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedCloudBackupToRestore = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // نافذة إشعار إعادة التشغيل
    if (showRestartDialog) {
        AlertDialog(
            onDismissRequest = { },
            icon = { Icon(Icons.Default.RestartAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("اكتملت الاستعادة بنجاح", fontWeight = FontWeight.Bold) },
            text = {
                Text("تم استبدال قاعدة البيانات المحلية بنجاح. يجب الآن إعادة تشغيل التطبيق لتطبيق التغييرات وفتح الجداول.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRestartDialog = false
                        cloudBackupManager.restartApplication()
                    }
                ) {
                    Text("إعادة تشغيل التطبيق الآن")
                }
            }
        )
    }


}
