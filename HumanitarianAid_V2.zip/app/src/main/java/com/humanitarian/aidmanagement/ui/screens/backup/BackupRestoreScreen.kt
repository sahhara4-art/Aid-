package com.humanitarian.aidmanagement.ui.screens.backup

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.humanitarian.aidmanagement.AidApplication
import com.humanitarian.aidmanagement.data.backup.*
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.PalestineGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    database: AidDatabase,
    repository: AidRepository? = null,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val effectiveRepo = repository
        ?: (context.applicationContext as? AidApplication)?.repository
        ?: AidApplication.instance.repository
    val backupViewModel: BackupViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = BackupViewModel.Factory(context.applicationContext, database, effectiveRepo)
    )
    val localBackupManager = remember { DatabaseBackupManager(context, database) }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: سحابي Google Drive, 1: محلي (الهاتف)

    // حالة Google Drive من BackupViewModel
    val googleAccount by backupViewModel.googleAccount.collectAsStateWithLifecycle()
    val isCloudProcessing by backupViewModel.isCloudProcessing.collectAsStateWithLifecycle()
    val isUploading by backupViewModel.isUploading.collectAsStateWithLifecycle()
    val uploadProgress by backupViewModel.uploadProgress.collectAsStateWithLifecycle()
    val cloudStatusMessage by backupViewModel.cloudStatusMessage.collectAsStateWithLifecycle()
    val cloudBackupsList by backupViewModel.cloudBackupsList.collectAsStateWithLifecycle()
    val animatedUploadProgress by animateFloatAsState(
        targetValue = uploadProgress.coerceIn(0f, 1f),
        label = "cloud_upload_progress"
    )
    val uploadPercentage = (animatedUploadProgress * 100).toInt().coerceIn(0, 100)

    var selectedCloudBackupToRestore by remember { mutableStateOf<CloudBackupItem?>(null) }
    var showRestartDialog by remember { mutableStateOf(false) }
    val restoreProgressState by DatabaseBackupManager.restoreState.collectAsStateWithLifecycle()

    // حالة النسخ المحلي
    var isLocalProcessing by remember { mutableStateOf(false) }
    var localOperationResult by remember { mutableStateOf<BackupResult?>(null) }

    // تسجيل الدخول لحساب Google مع تشخيص مفصل ومعالجة حالات الإلغاء ورموز الخطأ
    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        backupViewModel.handleSignInResult(
            data = result.data,
            onSuccess = { account ->
                Toast.makeText(context, "تم تسجيل الدخول بنجاح: ${account.email}", Toast.LENGTH_SHORT).show()
            },
            onError = { _, message ->
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            }
        )
    }

    // مشغل حفظ النسخة الاحتياطية الموحدة (SAF CreateDocument)
    val exportDbLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val outputStream = context.contentResolver.openOutputStream(uri)
                        ?: throw Exception("تعذر فتح مسار حفظ النسخة")
                    outputStream.use { out ->
                        localBackupManager.backupDatabase(out)
                    }
                    try { AidDatabase.reestablishConnection(context) } catch (_: Exception) {}

                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "تم أخذ النسخة الاحتياطية بنجاح!", Toast.LENGTH_SHORT).show()
                    }
                } catch (t: Throwable) {
                    t.printStackTrace()
                    try { AidDatabase.reestablishConnection(context) } catch (_: Exception) {}
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "فشل النسخ الاحتياطي: ${t.message ?: "خطأ غير متوقع"}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    // مشغل اختيار ملف النسخة الاحتياطية الأصلية (SAF OpenDocument) للاستعادة المباشرة الآمنة
    val dbFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            isLocalProcessing = true
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    localBackupManager.restoreFromUri(uri)
                }
                isLocalProcessing = false
                localOperationResult = result
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                    if (result.success) {
                        showRestartDialog = true
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("النسخ الاحتياطي واستعادة البيانات", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("محرك النسخ السحابي Google Drive والنسخ المحلي", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
        ) {
            // شريط التبويب
            PrimaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = PalestineGreen
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("السحابة (Google Drive)", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.SdCard, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("الذاكرة المحلية (الهاتف)", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("تزامن لحظي (Firebase)", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                )
            }

            if (selectedTab == 0) {

                // ==================== تبويب Google Drive السحابي ====================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // بطاقة حالة حساب Google
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .background(
                                                    if (googleAccount != null) Color(0xFF10B981).copy(alpha = 0.15f)
                                                    else Color(0xFF4285F4).copy(alpha = 0.15f),
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (googleAccount != null) Icons.Default.CloudDone else Icons.Default.Cloud,
                                                contentDescription = null,
                                                tint = if (googleAccount != null) Color(0xFF10B981) else Color(0xFF4285F4)
                                            )
                                        }
                                        Column {
                                            Text(
                                                text = if (googleAccount != null) "متصل بخوادم Google" else "غير متصل بحساب Google",
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.titleMedium,
                                                color = if (googleAccount != null) Color(0xFF047857) else MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = googleAccount?.email ?: "سجل الدخول لحفظ واسترجاع ملفات قاعدة البيانات سحابياً",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    if (googleAccount != null) {
                                        IconButton(
                                            onClick = {
                                                backupViewModel.signOut()
                                            }
                                        ) {
                                            Icon(Icons.Default.Logout, contentDescription = "تسجيل الخروج", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }

                                if (googleAccount == null) {
                                    Button(
                                        onClick = {
                                            val client = backupViewModel.getGoogleSignInClient()
                                            // تنظيف أي جلسة سابقة عالقة أولاً لضمان ظهور نافذة اختيار الحساب وعدم الإلغاء الفوري
                                            client.signOut().addOnCompleteListener {
                                                googleSignInLauncher.launch(client.signInIntent)
                                            }
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4285F4)),
                                        modifier = Modifier.fillMaxWidth().height(48.dp)
                                    ) {
                                        Icon(Icons.Default.Login, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("تسجيل الدخول بحساب Google", fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                backupViewModel.uploadCloudBackup { success, message ->
                                                    Toast.makeText(
                                                        context,
                                                        message,
                                                        if (success) Toast.LENGTH_SHORT else Toast.LENGTH_LONG
                                                    ).show()
                                                }
                                            },
                                            enabled = !isCloudProcessing,
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                            modifier = Modifier.weight(1f).height(46.dp)
                                        ) {
                                            if (isCloudProcessing) {
                                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                            } else {
                                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("رفع نسخة سحابية", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            }
                                        }

                                        Button(
                                            onClick = {
                                                if (cloudBackupsList.isNotEmpty()) {
                                                    selectedCloudBackupToRestore = cloudBackupsList.first()
                                                } else {
                                                    backupViewModel.setCloudStatusMessage("جاري البحث عن أحدث نسخة سحابية...")
                                                    backupViewModel.refreshCloudBackups { list ->
                                                        if (list.isNotEmpty()) {
                                                            selectedCloudBackupToRestore = list.first()
                                                        } else {
                                                            backupViewModel.setCloudStatusMessage("لم يتم العثور على أي نسخ سحابية محفوظة في Google Drive.")
                                                            Toast.makeText(context, "لا توجد نسخ سحابية للاستعادة", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                }
                                            },
                                            enabled = !isCloudProcessing,
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                            modifier = Modifier.weight(1f).height(46.dp)
                                        ) {
                                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("استعادة نسخة سحابية", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                    }

                                    AnimatedVisibility(visible = isUploading) {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(top = 4.dp)
                                                .background(
                                                    PalestineGreen.copy(alpha = 0.08f),
                                                    RoundedCornerShape(12.dp)
                                                )
                                                .padding(12.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.CloudUpload,
                                                        contentDescription = null,
                                                        tint = PalestineGreen,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Text(
                                                        text = if (uploadPercentage == 0) "جاري تجهيز وبدء الرفع..." else "جاري الرفع... $uploadPercentage%",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                }
                                                Text(
                                                    text = "$uploadPercentage%",
                                                    style = MaterialTheme.typography.labelLarge,
                                                    fontWeight = FontWeight.Bold,
                                                    color = PalestineGreen
                                                )
                                            }
                                            LinearProgressIndicator(
                                                progress = { animatedUploadProgress },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(8.dp)
                                                    .clip(RoundedCornerShape(4.dp)),
                                                color = PalestineGreen,
                                                trackColor = MaterialTheme.colorScheme.surfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // رسالة الحالة السحابية
                    cloudStatusMessage?.let { msg ->
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text(text = msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }

                    // قائمة النسخ السحابية على Google Drive
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "النسخ السحابية المحفوظة (${cloudBackupsList.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (googleAccount != null) {
                                IconButton(
                                    onClick = {
                                        backupViewModel.refreshCloudBackups()
                                    }
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }

                    if (googleAccount == null) {
                        item {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
                                    Text("سجل الدخول بحساب Google لاستعراض النسخ السحابية", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    } else if (cloudBackupsList.isEmpty() && !isCloudProcessing) {
                        item {
                            Text(
                                text = "لا توجد نسخ سحابية محفوظة حتى الآن في مجلد ${GoogleDriveBackupManager.BACKUP_FOLDER_NAME}.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        items(cloudBackupsList) { item ->
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .background(PalestineGreen.copy(alpha = 0.1f), RoundedCornerShape(10.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.FolderZip, contentDescription = null, tint = PalestineGreen)
                                        }
                                        Column {
                                            Text(text = item.fileName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            Text(
                                                text = "الحجم: ${item.sizeBytes / 1024} KB • التاريخ: ${item.createdTimeFormatted}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = { selectedCloudBackupToRestore = item },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("استعادة", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }

                    // أداة تشخيص بصمة التوقيع (SHA-1 / SHA-256) لحل مشاكل Google Sign-In و Firebase
                    item {
                        Sha1DiagnosticCard(context = context)
                    }
                }
            } else if (selectedTab == 1) {
                // ==================== تبويب الذاكرة المحلية (الهاتف) ====================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // تصدير واسترجاع قاعدة البيانات المشفرة (SQLCipher ZIP)
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .background(PalestineGreen.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Security, contentDescription = null, tint = PalestineGreen)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("قاعدة البيانات الأصلية المباشرة (Native SQLite .db)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("تصدير أو استعادة ملف قاعدة البيانات المباشر (.db) بنظام Native Backup و WAL Checkpoint مع التطهير التام لسجلات WAL لضمان التماسك وتفادي التعليق", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val defaultName = "AidManagement_Backup_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.db"
                                            exportDbLauncher.launch(defaultName)
                                        },
                                        enabled = !isLocalProcessing,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f).height(46.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                                    ) {
                                        if (isLocalProcessing) {
                                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                                        } else {
                                            Icon(Icons.Default.Storage, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("تصدير قاعدة البيانات (.db)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            dbFilePickerLauncher.launch(arrayOf("*/*"))
                                        },
                                        enabled = !isLocalProcessing,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f).height(46.dp)
                                    ) {
                                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("استعادة من ملف (.db)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // تصدير JSON
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(Color(0xFF0284C7).copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.DataObject, contentDescription = null, tint = Color(0xFF0284C7))
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("تصدير كملف JSON مهيكل", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("ملف متكامل يحتوي على الأسر والأطفال والمساعدات والمشاريع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                Button(
                                    onClick = {
                                        scope.launch {
                                            isLocalProcessing = true
                                            localOperationResult = withContext(Dispatchers.IO) {
                                                localBackupManager.exportToJson()
                                            }
                                            isLocalProcessing = false
                                        }
                                    },
                                    enabled = !isLocalProcessing,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().height(44.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                                ) {
                                    if (isLocalProcessing) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                    } else {
                                        Icon(Icons.Default.FileDownload, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("تصدير نسخة JSON الآن")
                                    }
                                }
                            }
                        }
                    }

                    // تصدير SQL Dump
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(Color(0xFF10B981).copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Storage, contentDescription = null, tint = Color(0xFF10B981))
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("تصدير كملف SQL Dump", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("أوامر SQL قياسية قابلة للتشغيل المباشر على قواعد SQLite", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                Button(
                                    onClick = {
                                        scope.launch {
                                            isLocalProcessing = true
                                            localOperationResult = withContext(Dispatchers.IO) {
                                                localBackupManager.exportToSql()
                                            }
                                            isLocalProcessing = false
                                        }
                                    },
                                    enabled = !isLocalProcessing,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().height(44.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                ) {
                                    if (isLocalProcessing) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                    } else {
                                        Icon(Icons.Default.Code, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("تصدير أوامر SQL Dump")
                                    }
                                }
                            }
                        }
                    }

                    // عرض نتيجة العملية المحلية
                    localOperationResult?.let { res ->
                        item {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (res.success) Color(0xFF10B981).copy(alpha = 0.15f)
                                    else MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(
                                            imageVector = if (res.success) Icons.Default.CheckCircle else Icons.Default.Error,
                                            contentDescription = null,
                                            tint = if (res.success) Color(0xFF10B981) else MaterialTheme.colorScheme.error
                                        )
                                        Text(text = res.message, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    }
                                    if (res.filePath != null) {
                                        Text(text = "المسار: ${res.filePath}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }

                    // أداة تشخيص بصمة التوقيع (SHA-1 / SHA-256) لحل مشاكل Google Sign-In و Firebase
                    item {
                        Sha1DiagnosticCard(context = context)
                    }
                }
            } else {
                // ==================== تبويب التزامن اللحظي (Firebase Delta Sync) ====================
                com.humanitarian.aidmanagement.ui.screens.sync.FirebaseDeltaSyncScreen(
                    repository = effectiveRepo,
                    onNavigateBack = onNavigateBack
                )
            }
        }
    }


    // نافذة تأكيد استعادة النسخة السحابية من Google Drive
    selectedCloudBackupToRestore?.let { cloudItem ->
        AlertDialog(
            onDismissRequest = { selectedCloudBackupToRestore = null },
            icon = { Icon(Icons.Default.CloudDownload, contentDescription = null, tint = PalestineGreen) },
            title = { Text("استعادة من Google Drive", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "هل أنت متأكد من استعادة النسخة الاحتياطية (${cloudItem.fileName})؟\n\n" +
                    "⚠️ تحذير: سيتم استبدال قاعدة البيانات المحلية بالكامل بالنسخة المسترجعة من السحابة، وسيتم إعادة تشغيل التطبيق لتهيئة الجداول."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val fileId = cloudItem.fileId
                        selectedCloudBackupToRestore = null
                        backupViewModel.restoreFromCloud(fileId) { success, message, requiresRestart ->
                            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                            if (success && requiresRestart) {
                                showRestartDialog = true
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                ) {
                    Text("نعم، استعادة واستبدال")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedCloudBackupToRestore = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // نافذة إشعار إغلاق التطبيق بعد الاستعادة
    if (showRestartDialog) {
        AlertDialog(
            onDismissRequest = { },
            icon = { Icon(Icons.Default.RestartAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("اكتملت الاستعادة بنجاح", fontWeight = FontWeight.Bold) },
            text = {
                Text("تم استبدال قاعدة البيانات بنجاح. سيتم إغلاق التطبيق الآن لتطبيق التغييرات وتهيئة الجداول، يرجى إعادة فتحه يدوياً.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRestartDialog = false
                        backupViewModel.cloudBackupManager.restartApplication()
                    }
                ) {
                    Text("إغلاق التطبيق الآن")
                }
            }
        )
    }

    // متتبع الخطوات اللحظي لعملية الاستعادة (Live Restore Progress Tracker)
    if (restoreProgressState !is RestoreState.IDLE) {
        RestoreProgressTrackerDialog(
            state = restoreProgressState,
            onDismiss = {
                DatabaseBackupManager.resetRestoreState()
            }
        )
    }
}

@Composable
fun RestoreProgressTrackerDialog(
    state: RestoreState,
    onDismiss: () -> Unit
) {
    val isError = state is RestoreState.ERROR
    val isSuccess = state is RestoreState.SUCCESS

    AlertDialog(
        onDismissRequest = {
            if (isError) onDismiss()
        },
        icon = {
            when {
                isError -> Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(36.dp))
                isSuccess -> Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(36.dp))
                else -> Icon(Icons.Default.CloudSync, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(36.dp))
            }
        },
        title = {
            Text(
                text = state.displayTitle,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = state.displayDetail,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )

                if (!isError && !isSuccess) {
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = PalestineGreen,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }

                // عرض مؤشر الخطوات الأربع
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val steps = listOf(
                        1 to "تحميل حزمة النسخة الاحتياطية",
                        2 to "فك الضغط واستخراج ملف SQLite",
                        3 to "كتابة واستبدال ملف قاعدة البيانات",
                        4 to "التحقق الصارم من صحة الجداول"
                    )

                    steps.forEach { (index, title) ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val isCompleted = state.stepIndex > index || isSuccess
                            val isCurrent = state.stepIndex == index && !isError

                            when {
                                isCompleted -> Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                                isCurrent -> CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = PalestineGreen)
                                else -> Icon(Icons.Default.RadioButtonUnchecked, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(16.dp))
                            }

                            Text(
                                text = title,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                color = if (isCurrent) PalestineGreen else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (isError) {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("إغلاق والعودة")
                }
            }
        },
        dismissButton = null
    )
}

/**
 * استخراج بصمة توقيع التطبيق الحالية برمجياً (SHA-1 أو SHA-256)
 * تدعم بيئات التشغيل الحديثة (Android 9+) والقديمة، وتتعرف ديناميكياً على مفتاح التوقيع
 * المستخدم في GitHub Actions أو محلياً لتمكين تسجيل الدخول بحساب Google عبر Firebase.
 */
fun getAppCertificateFingerprint(context: Context, algorithm: String = "SHA1"): String {
    try {
        val packageName = context.packageName
        val pm = context.packageManager
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val signingInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo
            if (signingInfo != null) {
                if (signingInfo.hasMultipleSigners()) {
                    signingInfo.apkContentsSigners
                } else {
                    signingInfo.signingCertificateHistory
                }
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures
            }
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures
        }

        if (signatures != null && signatures.isNotEmpty()) {
            val md = MessageDigest.getInstance(algorithm)
            md.update(signatures[0].toByteArray())
            val digest = md.digest()
            val hexString = StringBuilder()
            for (b in digest) {
                hexString.append(String.format("%02x", b).uppercase(Locale.US)).append(":")
            }
            return hexString.toString().dropLast(1)
        }
    } catch (e: Exception) {
        return "Error: ${e.message}"
    }
    return "$algorithm Not Found"
}

fun getAppSha1(context: Context): String = getAppCertificateFingerprint(context, "SHA1")

fun getAppSha256(context: Context): String = getAppCertificateFingerprint(context, "SHA-256")

/**
 * بطاقة تشخيصية لعرض ونسخ بصمات SHA-1 و SHA-256 لحل مشاكل مصادقة Firebase
 */
@Composable
fun Sha1DiagnosticCard(
    context: Context,
    modifier: Modifier = Modifier
) {
    val sha1 = remember(context) { getAppSha1(context) }
    val sha256 = remember(context) { getAppSha256(context) }
    val packageName = context.packageName

    fun copyText(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard?.setPrimaryClip(clip)
        Toast.makeText(context, "✓ تم نسخ $label إلى الحافظة", Toast.LENGTH_SHORT).show()
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFFD97706).copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.VpnKey, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(18.dp))
                    }
                    Column {
                        Text(
                            text = "أداة تشخيص بصمة التوقيع (SHA-1 Extractor)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "مخصصة لربط Google Sign-In مع Firebase عبر GitHub Actions",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFD97706).copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "Debug Tool",
                        color = Color(0xFFD97706),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            val registeredSha1Clean = "16be196eed79642d3ea74ca292708c5347da9665"
            val currentSha1Clean = sha1.replace(":", "").lowercase(Locale.US)
            val isSha1Matched = currentSha1Clean.contains(registeredSha1Clean)

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSha1Matched) Color(0xFFD1FAE5).copy(alpha = 0.6f) else Color(0xFFFEF3C7).copy(alpha = 0.6f),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSha1Matched) Color(0xFF10B981) else Color(0xFFFDE68A))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (isSha1Matched) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isSha1Matched) Color(0xFF047857) else Color(0xFFB45309),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = if (isSha1Matched) {
                            "✅ بصمة التطبيق الحالية مطابقة تماماً للبصمة المعتمدة في google-services.json ومصادقة Firebase."
                        } else {
                            "💡 تنبيه: بصمة هذا الـ APK الحالي تختلف عن المسجلة. انسخ بصمة SHA-1 أدناه وأضفها إلى: Firebase Console > Project Settings > Your Android App > Add Fingerprint لتفادي إلغاء الدخول أو خطأ Code 10."
                        },
                        fontSize = 11.sp,
                        color = if (isSha1Matched) Color(0xFF065F46) else Color(0xFF92400E)
                    )
                }
            }

            // اسم الحزمة (Package Name)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("اسم الحزمة (Package Name):", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(packageName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { copyText("اسم الحزمة", packageName) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", modifier = Modifier.size(16.dp))
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // بصمة SHA-1
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("بصمة SHA-1 الرسمية الحالية:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    TextButton(
                        onClick = { copyText("بصمة SHA-1", sha1) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("نسخ SHA-1", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = sha1,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // بصمة SHA-256
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("بصمة SHA-256 (اختياري للعملاء المتقدمين):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    TextButton(
                        onClick = { copyText("بصمة SHA-256", sha256) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("نسخ SHA-256", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = sha256,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}
