package com.humanitarian.aidmanagement.ui.screens.backup

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInStatusCodes
import com.google.android.gms.common.api.ApiException
import com.humanitarian.aidmanagement.AidApplication
import com.humanitarian.aidmanagement.data.backup.*
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.PalestineGreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRestoreScreen(
    database: AidDatabase,
    repository: AidRepository? = null,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val effectiveRepo = repository
        ?: (context.applicationContext as? AidApplication)?.repository
        ?: AidApplication.instance.repository
    val localBackupManager = remember { DatabaseBackupManager(context, database) }
    val cloudBackupManager = remember { GoogleDriveBackupManager(context, database) }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: سحابي Google Drive, 1: محلي (الهاتف)

    // حالة Google Drive
    var googleAccount by remember { mutableStateOf(cloudBackupManager.getSignedInAccount()) }
    var isCloudProcessing by remember { mutableStateOf(false) }
    var cloudStatusMessage by remember { 
        mutableStateOf<String?>(
            if (googleAccount != null) "متصل بخوادم Google: ${googleAccount?.email}"
            else "سجل الدخول لحفظ واسترجاع ملفات قاعدة البيانات سحابياً"
        )
    }
    var cloudBackupsList by remember { mutableStateOf<List<CloudBackupItem>>(emptyList()) }
    var selectedCloudBackupToRestore by remember { mutableStateOf<CloudBackupItem?>(null) }
    var showRestartDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        googleAccount?.let { acc ->
            isCloudProcessing = true
            cloudBackupsList = cloudBackupManager.listGoogleDriveBackups(acc)
            isCloudProcessing = false
        }
    }

    // حالة النسخ المحلي
    var isLocalProcessing by remember { mutableStateOf(false) }
    var localOperationResult by remember { mutableStateOf<BackupResult?>(null) }

    // تسجيل الدخول لحساب Google مع تشخيص مفصل ومعالجة حالات الإلغاء ورموز الخطأ
    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        val task = if (data != null) GoogleSignIn.getSignedInAccountFromIntent(data) else null

        if (task != null) {
            try {
                val account = task.getResult(ApiException::class.java)
                if (account != null) {
                    googleAccount = account
                    cloudStatusMessage = "متصل بخوادم Google: ${account.email ?: account.displayName ?: "مستخدم معتمد"}"
                    Toast.makeText(context, "تم تسجيل الدخول بنجاح: ${account.email}", Toast.LENGTH_SHORT).show()
                    scope.launch {
                        isCloudProcessing = true
                        cloudBackupsList = cloudBackupManager.listGoogleDriveBackups(account)
                        isCloudProcessing = false
                    }
                } else {
                    cloudStatusMessage = "فشل تسجيل الدخول: الحساب فارغ"
                }
            } catch (e: ApiException) {
                val statusCode = e.statusCode
                val statusString = GoogleSignInStatusCodes.getStatusCodeString(statusCode)
                val diagnosis = when (statusCode) {
                    GoogleSignInStatusCodes.DEVELOPER_ERROR -> "خطأ في التكوين (Code 10: DEVELOPER_ERROR). يرجى التأكد من إضافة بصمة SHA-1 الخاصة بهذا الـ APK في Firebase Console."
                    GoogleSignInStatusCodes.SIGN_IN_CANCELLED -> "تم إلغاء اختيار الحساب من قِبل المستخدم (Code 12501)."
                    GoogleSignInStatusCodes.SIGN_IN_FAILED -> "فشل تسجيل الدخول (Code 12500). تأكد من تفعيل Google Drive API في Google Cloud Console."
                    GoogleSignInStatusCodes.NETWORK_ERROR -> "خطأ في الشبكة (Code 7). تحقق من الاتصال بالإنترنت."
                    else -> "كود الخطأ: $statusCode ($statusString)"
                }
                cloudStatusMessage = "فشل الاتصال: $diagnosis"
                Toast.makeText(context, "Error: $statusCode ($statusString)", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                val errorMsg = "خطأ غير متوقع: ${e.localizedMessage ?: e.message}"
                cloudStatusMessage = errorMsg
                Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
            }
        } else {
            cloudStatusMessage = "تم إلغاء عملية تسجيل الدخول بحساب Google (لم يتم استلام استجابة)"
            Toast.makeText(context, "تم إلغاء عملية اختيار الحساب", Toast.LENGTH_SHORT).show()
        }
    }

    // مشغل حفظ النسخة الاحتياطية الأصلية (SAF CreateDocument) بصيغة ملف .db مباشر
    val exportDbLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        if (uri != null) {
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                try {
                    // 1. Close database to flush state and release any file locks
                    try { database.close() } catch (e: Exception) {}
                    com.humanitarian.aidmanagement.data.local.AidDatabase.resetInstance()
                    kotlinx.coroutines.delay(300)

                    // 2. Locate the main physical database file
                    val dbName = com.humanitarian.aidmanagement.data.local.AidDatabase.DATABASE_NAME
                    val dbFile = context.getDatabasePath(dbName)

                    // 3. Simple raw 1:1 stream copy directly to the SAF URI
                    val outputStream = context.contentResolver.openOutputStream(uri) ?: return@launch
                    dbFile.inputStream().use { input ->
                        outputStream.use { output ->
                            input.copyTo(output)
                            output.flush()
                        }
                    }

                    try { com.humanitarian.aidmanagement.data.local.AidDatabase.reestablishConnection(context) } catch (_: Exception) {}

                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        android.widget.Toast.makeText(context, "تم أخذ النسخة الاحتياطية بنجاح!", android.widget.Toast.LENGTH_SHORT).show()
                    }
                } catch (t: Throwable) {
                    t.printStackTrace()
                    try { com.humanitarian.aidmanagement.data.local.AidDatabase.reestablishConnection(context) } catch (_: Exception) {}
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        android.widget.Toast.makeText(context, "فشل النسخ الاحتياطي: ${t.message ?: "خطأ غير متوقع"}", android.widget.Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    // مشغل اختيار ملف النسخة الاحتياطية الأصلية (SAF OpenDocument) للاستعادة المباشرة الآمنة
    val dbFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            isLocalProcessing = true
            scope.launch {
                val result = withContext(Dispatchers.IO) {
                    localBackupManager.restoreFromUri(uri)
                }
                isLocalProcessing = false
                localOperationResult = result
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                    if (result.success) {
                        showRestartDialog = true
                    }
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        googleAccount = cloudBackupManager.getSignedInAccount()

        googleAccount?.let { acc ->
            isCloudProcessing = true
            cloudBackupsList = cloudBackupManager.listGoogleDriveBackups(acc)
            isCloudProcessing = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("النسخ الاحتياطي واستعادة البيانات", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text("محرك النسخ السحابي Google Drive والنسخ المحلي", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
        ) {
            // شريط التبويب
            PrimaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = PalestineGreen
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("السحابة (Google Drive)", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.SdCard, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("الذاكرة المحلية (الهاتف)", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("تزامن لحظي (Firebase)", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                )
            }

            if (selectedTab == 0) {

                // ==================== تبويب Google Drive السحابي ====================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // بطاقة حالة حساب Google
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Box(
                                            modifier = Modifier
                                                .size(46.dp)
                                                .background(
                                                    if (googleAccount != null) Color(0xFF10B981).copy(alpha = 0.15f)
                                                    else Color(0xFF4285F4).copy(alpha = 0.15f),
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = if (googleAccount != null) Icons.Default.CloudDone else Icons.Default.Cloud,
                                                contentDescription = null,
                                                tint = if (googleAccount != null) Color(0xFF10B981) else Color(0xFF4285F4)
                                            )
                                        }
                                        Column {
                                            Text(
                                                text = if (googleAccount != null) "متصل بخوادم Google" else "غير متصل بحساب Google",
                                                fontWeight = FontWeight.Bold,
                                                style = MaterialTheme.typography.titleMedium,
                                                color = if (googleAccount != null) Color(0xFF047857) else MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = googleAccount?.email ?: "سجل الدخول لحفظ واسترجاع ملفات قاعدة البيانات سحابياً",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    if (googleAccount != null) {
                                        IconButton(
                                            onClick = {
                                                val client = cloudBackupManager.getGoogleSignInClient()
                                                client.signOut().addOnCompleteListener {
                                                    googleAccount = null
                                                    cloudBackupsList = emptyList()
                                                    cloudStatusMessage = "تم تسجيل الخروج من Google Drive"
                                                }
                                            }
                                        ) {
                                            Icon(Icons.Default.Logout, contentDescription = "تسجيل الخروج", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }

                                if (googleAccount == null) {
                                    Button(
                                        onClick = {
                                            val client = cloudBackupManager.getGoogleSignInClient()
                                            // تنظيف أي جلسة سابقة عالقة أولاً لضمان ظهور نافذة اختيار الحساب وعدم الإلغاء الفوري
                                            client.signOut().addOnCompleteListener {
                                                googleSignInLauncher.launch(client.signInIntent)
                                            }
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4285F4)),
                                        modifier = Modifier.fillMaxWidth().height(48.dp)
                                    ) {
                                        Icon(Icons.Default.Login, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("تسجيل الدخول بحساب Google", fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = {
                                                val acc = googleAccount ?: return@Button
                                                scope.launch {
                                                    isCloudProcessing = true
                                                    cloudStatusMessage = "جاري رفع النسخة السحابية إلى Google Drive..."
                                                    val res = cloudBackupManager.backupToGoogleDrive(acc)
                                                    cloudStatusMessage = res.message
                                                    if (res.success) {
                                                        cloudBackupsList = cloudBackupManager.listGoogleDriveBackups(acc)
                                                    }
                                                    isCloudProcessing = false
                                                }
                                            },
                                            enabled = !isCloudProcessing,
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                            modifier = Modifier.weight(1f).height(46.dp)
                                        ) {
                                            if (isCloudProcessing) {
                                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                                            } else {
                                                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("رفع نسخة سحابية", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            }
                                        }

                                        Button(
                                            onClick = {
                                                val acc = googleAccount ?: return@Button
                                                if (cloudBackupsList.isNotEmpty()) {
                                                    selectedCloudBackupToRestore = cloudBackupsList.first()
                                                } else {
                                                    scope.launch {
                                                        isCloudProcessing = true
                                                        cloudStatusMessage = "جاري البحث عن أحدث نسخة سحابية..."
                                                        val list = cloudBackupManager.listGoogleDriveBackups(acc)
                                                        cloudBackupsList = list
                                                        isCloudProcessing = false
                                                        if (list.isNotEmpty()) {
                                                            selectedCloudBackupToRestore = list.first()
                                                        } else {
                                                            cloudStatusMessage = "لم يتم العثور على أي نسخ سحابية محفوظة في Google Drive."
                                                            Toast.makeText(context, "لا توجد نسخ سحابية للاستعادة", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                }
                                            },
                                            enabled = !isCloudProcessing,
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                            modifier = Modifier.weight(1f).height(46.dp)
                                        ) {
                                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("استعادة نسخة سحابية", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // رسالة الحالة السحابية
                    cloudStatusMessage?.let { msg ->
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Text(text = msg, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }

                    // قائمة النسخ السحابية على Google Drive
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "النسخ السحابية المحفوظة (${cloudBackupsList.size})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (googleAccount != null) {
                                IconButton(
                                    onClick = {
                                        val acc = googleAccount ?: return@IconButton
                                        scope.launch {
                                            isCloudProcessing = true
                                            cloudBackupsList = cloudBackupManager.listGoogleDriveBackups(acc)
                                            isCloudProcessing = false
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }

                    if (googleAccount == null) {
                        item {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
                                    Text("سجل الدخول بحساب Google لاستعراض النسخ السحابية", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    } else if (cloudBackupsList.isEmpty() && !isCloudProcessing) {
                        item {
                            Text(
                                text = "لا توجد نسخ سحابية محفوظة حتى الآن في مجلد ${GoogleDriveBackupManager.BACKUP_FOLDER_NAME}.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        items(cloudBackupsList) { item ->
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .background(PalestineGreen.copy(alpha = 0.1f), RoundedCornerShape(10.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.FolderZip, contentDescription = null, tint = PalestineGreen)
                                        }
                                        Column {
                                            Text(text = item.fileName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                            Text(
                                                text = "الحجم: ${item.sizeBytes / 1024} KB • التاريخ: ${item.createdTimeFormatted}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = { selectedCloudBackupToRestore = item },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("استعادة", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }

                    // أداة تشخيص بصمة التوقيع (SHA-1 / SHA-256) لحل مشاكل Google Sign-In و Firebase
                    item {
                        Sha1DiagnosticCard(context = context)
                    }
                }
            } else if (selectedTab == 1) {
                // ==================== تبويب الذاكرة المحلية (الهاتف) ====================
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // تصدير واسترجاع قاعدة البيانات المشفرة (SQLCipher ZIP)
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .background(PalestineGreen.copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Security, contentDescription = null, tint = PalestineGreen)
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("قاعدة البيانات الأصلية المباشرة (Native SQLite .db)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("تصدير أو استعادة ملف قاعدة البيانات المباشر (.db) بنظام Native Backup و WAL Checkpoint مع التطهير التام لسجلات WAL لضمان التماسك وتفادي التعليق", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            val defaultName = "AidManagement_Backup_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.db"
                                            exportDbLauncher.launch(defaultName)
                                        },
                                        enabled = !isLocalProcessing,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f).height(46.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                                    ) {
                                        if (isLocalProcessing) {
                                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                                        } else {
                                            Icon(Icons.Default.Storage, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("تصدير قاعدة البيانات (.db)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            dbFilePickerLauncher.launch(arrayOf("*/*"))
                                        },
                                        enabled = !isLocalProcessing,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f).height(46.dp)
                                    ) {
                                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("استعادة من ملف (.db)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // تصدير JSON
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(Color(0xFF0284C7).copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.DataObject, contentDescription = null, tint = Color(0xFF0284C7))
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("تصدير كملف JSON مهيكل", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("ملف متكامل يحتوي على الأسر والأطفال والمساعدات والمشاريع", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                Button(
                                    onClick = {
                                        scope.launch {
                                            isLocalProcessing = true
                                            localOperationResult = withContext(Dispatchers.IO) {
                                                localBackupManager.exportToJson()
                                            }
                                            isLocalProcessing = false
                                        }
                                    },
                                    enabled = !isLocalProcessing,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().height(44.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                                ) {
                                    if (isLocalProcessing) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                    } else {
                                        Icon(Icons.Default.FileDownload, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("تصدير نسخة JSON الآن")
                                    }
                                }
                            }
                        }
                    }

                    // تصدير SQL Dump
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .background(Color(0xFF10B981).copy(alpha = 0.15f), RoundedCornerShape(12.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Storage, contentDescription = null, tint = Color(0xFF10B981))
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("تصدير كملف SQL Dump", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                                        Text("أوامر SQL قياسية قابلة للتشغيل المباشر على قواعد SQLite", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }

                                Button(
                                    onClick = {
                                        scope.launch {
                                            isLocalProcessing = true
                                            localOperationResult = withContext(Dispatchers.IO) {
                                                localBackupManager.exportToSql()
                                            }
                                            isLocalProcessing = false
                                        }
                                    },
                                    enabled = !isLocalProcessing,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth().height(44.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                ) {
                                    if (isLocalProcessing) {
                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                    } else {
                                        Icon(Icons.Default.Code, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("تصدير أوامر SQL Dump")
                                    }
                                }
                            }
                        }
                    }

                    // عرض نتيجة العملية المحلية
                    localOperationResult?.let { res ->
                        item {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (res.success) Color(0xFF10B981).copy(alpha = 0.15f)
                                    else MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(
                                            imageVector = if (res.success) Icons.Default.CheckCircle else Icons.Default.Error,
                                            contentDescription = null,
                                            tint = if (res.success) Color(0xFF10B981) else MaterialTheme.colorScheme.error
                                        )
                                        Text(text = res.message, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                                    }
                                    if (res.filePath != null) {
                                        Text(text = "المسار: ${res.filePath}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }

                    // أداة تشخيص بصمة التوقيع (SHA-1 / SHA-256) لحل مشاكل Google Sign-In و Firebase
                    item {
                        Sha1DiagnosticCard(context = context)
                    }
                }
            } else {
                // ==================== تبويب التزامن اللحظي (Firebase Delta Sync) ====================
                com.humanitarian.aidmanagement.ui.screens.sync.FirebaseDeltaSyncScreen(
                    repository = effectiveRepo,
                    onNavigateBack = onNavigateBack
                )
            }
        }
    }


    // نافذة تأكيد استعادة النسخة السحابية من Google Drive
    selectedCloudBackupToRestore?.let { cloudItem ->
        AlertDialog(
            onDismissRequest = { selectedCloudBackupToRestore = null },
            icon = { Icon(Icons.Default.CloudDownload, contentDescription = null, tint = PalestineGreen) },
            title = { Text("استعادة من Google Drive", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "هل أنت متأكد من استعادة النسخة الاحتياطية (${cloudItem.fileName})؟\n\n" +
                    "⚠️ تحذير: سيتم استبدال قاعدة البيانات المحلية بالكامل بالنسخة المسترجعة من السحابة، وسيتم إعادة تشغيل التطبيق لتهيئة الجداول."
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val acc = googleAccount ?: return@Button
                        val fileId = cloudItem.fileId
                        selectedCloudBackupToRestore = null
                        scope.launch {
                            isCloudProcessing = true
                            val result = cloudBackupManager.restoreFromGoogleDrive(acc, fileId)
                            isCloudProcessing = false
                            cloudStatusMessage = result.message
                            Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                            if (result.success && result.requiresRestart) {
                                showRestartDialog = true
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                ) {
                    Text("نعم، استعادة واستبدال")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedCloudBackupToRestore = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // نافذة إشعار إعادة التشغيل
    if (showRestartDialog) {
        AlertDialog(
            onDismissRequest = { },
            icon = { Icon(Icons.Default.RestartAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("اكتملت الاستعادة بنجاح", fontWeight = FontWeight.Bold) },
            text = {
                Text("تم استبدال قاعدة البيانات المحلية بنجاح. يجب الآن إعادة تشغيل التطبيق لتطبيق التغييرات وفتح الجداول.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRestartDialog = false
                        cloudBackupManager.restartApplication()
                    }
                ) {
                    Text("إعادة تشغيل التطبيق الآن")
                }
            }
        )
    }

}

/**
 * استخراج بصمة توقيع التطبيق الحالية برمجياً (SHA-1 أو SHA-256)
 * تدعم بيئات التشغيل الحديثة (Android 9+) والقديمة، وتتعرف ديناميكياً على مفتاح التوقيع
 * المستخدم في GitHub Actions أو محلياً لتمكين تسجيل الدخول بحساب Google عبر Firebase.
 */
fun getAppCertificateFingerprint(context: Context, algorithm: String = "SHA1"): String {
    try {
        val packageName = context.packageName
        val pm = context.packageManager
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val signingInfo = pm.getPackageInfo(packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo
            if (signingInfo != null) {
                if (signingInfo.hasMultipleSigners()) {
                    signingInfo.apkContentsSigners
                } else {
                    signingInfo.signingCertificateHistory
                }
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures
            }
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(packageName, PackageManager.GET_SIGNATURES).signatures
        }

        if (signatures != null && signatures.isNotEmpty()) {
            val md = MessageDigest.getInstance(algorithm)
            md.update(signatures[0].toByteArray())
            val digest = md.digest()
            val hexString = StringBuilder()
            for (b in digest) {
                hexString.append(String.format("%02x", b).uppercase(Locale.US)).append(":")
            }
            return hexString.toString().dropLast(1)
        }
    } catch (e: Exception) {
        return "Error: ${e.message}"
    }
    return "$algorithm Not Found"
}

fun getAppSha1(context: Context): String = getAppCertificateFingerprint(context, "SHA1")

fun getAppSha256(context: Context): String = getAppCertificateFingerprint(context, "SHA-256")

/**
 * بطاقة تشخيصية لعرض ونسخ بصمات SHA-1 و SHA-256 لحل مشاكل مصادقة Firebase
 */
@Composable
fun Sha1DiagnosticCard(
    context: Context,
    modifier: Modifier = Modifier
) {
    val sha1 = remember(context) { getAppSha1(context) }
    val sha256 = remember(context) { getAppSha256(context) }
    val packageName = context.packageName

    fun copyText(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard?.setPrimaryClip(clip)
        Toast.makeText(context, "✓ تم نسخ $label إلى الحافظة", Toast.LENGTH_SHORT).show()
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD97706).copy(alpha = 0.4f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color(0xFFD97706).copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.VpnKey, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(18.dp))
                    }
                    Column {
                        Text(
                            text = "أداة تشخيص بصمة التوقيع (SHA-1 Extractor)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "مخصصة لربط Google Sign-In مع Firebase عبر GitHub Actions",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFD97706).copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "Debug Tool",
                        color = Color(0xFFD97706),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            val registeredSha1Clean = "16be196eed79642d3ea74ca292708c5347da9665"
            val currentSha1Clean = sha1.replace(":", "").lowercase(Locale.US)
            val isSha1Matched = currentSha1Clean.contains(registeredSha1Clean)

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSha1Matched) Color(0xFFD1FAE5).copy(alpha = 0.6f) else Color(0xFFFEF3C7).copy(alpha = 0.6f),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSha1Matched) Color(0xFF10B981) else Color(0xFFFDE68A))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (isSha1Matched) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isSha1Matched) Color(0xFF047857) else Color(0xFFB45309),
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = if (isSha1Matched) {
                            "✅ بصمة التطبيق الحالية مطابقة تماماً للبصمة المعتمدة في google-services.json ومصادقة Firebase."
                        } else {
                            "💡 تنبيه: بصمة هذا الـ APK الحالي تختلف عن المسجلة. انسخ بصمة SHA-1 أدناه وأضفها إلى: Firebase Console > Project Settings > Your Android App > Add Fingerprint لتفادي إلغاء الدخول أو خطأ Code 10."
                        },
                        fontSize = 11.sp,
                        color = if (isSha1Matched) Color(0xFF065F46) else Color(0xFF92400E)
                    )
                }
            }

            // اسم الحزمة (Package Name)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("اسم الحزمة (Package Name):", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(packageName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = { copyText("اسم الحزمة", packageName) }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", modifier = Modifier.size(16.dp))
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

            // بصمة SHA-1
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("بصمة SHA-1 الرسمية الحالية:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    TextButton(
                        onClick = { copyText("بصمة SHA-1", sha1) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("نسخ SHA-1", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = sha1,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // بصمة SHA-256
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("بصمة SHA-256 (اختياري للعملاء المتقدمين):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                    TextButton(
                        onClick = { copyText("بصمة SHA-256", sha256) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("نسخ SHA-256", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = sha256,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        color = Color(0xFF0F172A),
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}
