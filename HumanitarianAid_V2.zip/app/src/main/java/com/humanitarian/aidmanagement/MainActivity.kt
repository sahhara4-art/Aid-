package com.humanitarian.aidmanagement

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.humanitarian.aidmanagement.ui.navigation.Screen
import com.humanitarian.aidmanagement.ui.screens.children.ChildrenScreen
import com.humanitarian.aidmanagement.ui.screens.dashboard.DashboardScreen
import com.humanitarian.aidmanagement.ui.screens.delivery.DeliveryScreen
import com.humanitarian.aidmanagement.ui.screens.excel.ExcelImportExportScreen
import com.humanitarian.aidmanagement.ui.screens.families.FamiliesScreen
import com.humanitarian.aidmanagement.ui.screens.login.LoginScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.ManualSelectionScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.NominationResultsScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.NominationScreen
import com.humanitarian.aidmanagement.ui.screens.reports.ReportsScreen
import com.humanitarian.aidmanagement.ui.screens.users.AccountsPermissionsScreen
import com.humanitarian.aidmanagement.ui.screens.backup.BackupRestoreScreen
import com.humanitarian.aidmanagement.ui.screens.geo.GeographicDistributionScreen
import com.humanitarian.aidmanagement.ui.theme.*

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as AidApplication
        val repository = app.repository
        val database = app.database

        setContent {
            HumanitarianAidTheme(darkTheme = false) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val navController = rememberNavController()
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route

                    val isLogin = currentRoute == Screen.Login.route
                    val currentUser by repository.currentUserFlow.collectAsState(initial = repository.getCurrentUser())
                    val isManager = currentUser == null || currentUser?.RoleID == 1 || currentUser?.UserName?.equals("admin", ignoreCase = true) == true

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = SlateBackground,
                        topBar = {
                            if (!isLogin && currentRoute != null) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    // شريط العلم الفلسطيني العلوي الناعم
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(3.5.dp)
                                    ) {
                                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(PalestineBlack))
                                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(PalestineWhite))
                                        Box(modifier = Modifier.weight(1f).fillMaxHeight().background(PalestineGreen))
                                        Box(modifier = Modifier.weight(0.35f).fillMaxHeight().background(PalestineRed))
                                    }

                                    TopAppBar(
                                        title = {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(text = "🇵🇸", fontSize = 22.sp)
                                                Column {
                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Text(
                                                            text = "إدارة المساعدات الإنسانية",
                                                            style = MaterialTheme.typography.titleMedium,
                                                            fontWeight = FontWeight.Bold,
                                                            color = SlateTextPrimary,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                        Surface(
                                                            shape = RoundedCornerShape(4.dp),
                                                            color = PalestineGreenContainer
                                                        ) {
                                                            Text(
                                                                text = "فلسطين",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                fontWeight = FontWeight.Bold,
                                                                color = PalestineGreenDark,
                                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                            )
                                                        }
                                                    }
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                    ) {
                                                        Text(
                                                            text = currentUser?.FullName ?: "مدير النظام",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = SlateTextSecondary,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                        Text(text = "•", color = SlateTextMuted)
                                                        Text(
                                                            text = repository.getAllowedGroupForCurrentUser(),
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = PalestineGreen,
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                    }
                                                }
                                            }
                                        },
                                        actions = {
                                            // زر شاشة التوزيع الجغرافي للمستفيدين (الخريطة والمناطق الفرعية)
                                            IconButton(onClick = { navController.navigate(Screen.GeographicDistribution.route) }) {
                                                Icon(
                                                    Icons.Default.Map,
                                                    contentDescription = "التوزيع الجغرافي للمستفيدين",
                                                    tint = PalestineGreen
                                                )
                                            }

                                            // زر شاشة الإكسل (استيراد وتصدير فترات محددة)
                                            if (isManager || repository.canAccessScreen("excel_import_export")) {
                                                IconButton(onClick = { navController.navigate(Screen.ExcelImportExport.route) }) {
                                                    Icon(
                                                        Icons.Default.Description,
                                                        contentDescription = "استيراد وتصدير إكسل",
                                                        tint = PalestineGreen
                                                    )
                                                }
                                            }

                                            // زر الحسابات والصلاحيات التفصيلية لمدير النظام
                                            if (isManager) {
                                                IconButton(onClick = { navController.navigate(Screen.AccountsPermissions.route) }) {
                                                    Icon(
                                                        Icons.Default.AdminPanelSettings,
                                                        contentDescription = "الصلاحيات والمستخدمين",
                                                        tint = PalestineRed
                                                    )
                                                }
                                            }

                                            // زر النسخ والتزامن
                                            IconButton(onClick = { navController.navigate(Screen.BackupRestore.route) }) {
                                                Icon(
                                                    Icons.Default.CloudSync,
                                                    contentDescription = "النسخ والتزامن",
                                                    tint = SkyBlue
                                                )
                                            }

                                            // زر تسجيل الخروج
                                            IconButton(onClick = {
                                                repository.logout()
                                                navController.navigate(Screen.Login.route) {
                                                    popUpTo(0) { inclusive = true }
                                                }
                                            }) {
                                                Icon(
                                                    Icons.Default.ExitToApp,
                                                    contentDescription = "تسجيل الخروج",
                                                    tint = SlateTextSecondary
                                                )
                                            }
                                        },
                                        colors = TopAppBarDefaults.topAppBarColors(
                                            containerColor = PalestineWhite,
                                            titleContentColor = SlateTextPrimary
                                        )
                                    )
                                }
                            }
                        },
                        bottomBar = {
                            if (!isLogin && currentRoute != null && !currentRoute.startsWith("manual_selection") && currentRoute != Screen.AccountsPermissions.route && currentRoute != Screen.BackupRestore.route && currentRoute != Screen.ExcelImportExport.route) {
                                NavigationBar(
                                    containerColor = PalestineWhite,
                                    tonalElevation = 3.dp
                                ) {
                                    // 1. الرئيسية
                                    if (isManager || repository.canAccessScreen("dashboard")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Dashboard.route,
                                            onClick = {
                                                navController.navigate(Screen.Dashboard.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.Dashboard, contentDescription = "الرئيسية") },
                                            label = { Text("الرئيسية", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 2. سجل الأسر
                                    if (isManager || repository.canAccessScreen("families")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Families.route,
                                            onClick = {
                                                navController.navigate(Screen.Families.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.FamilyRestroom, contentDescription = "الأسر") },
                                            label = { Text("الأسر", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 3. الترشيح
                                    if (isManager || repository.canAccessScreen("nomination")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Nomination.route,
                                            onClick = {
                                                navController.navigate(Screen.Nomination.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.HowToReg, contentDescription = "الترشيح") },
                                            label = { Text("الترشيح", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 4. التسليم والصرف
                                    if (isManager || repository.canAccessScreen("delivery")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Delivery.route,
                                            onClick = {
                                                navController.navigate(Screen.Delivery.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.CheckCircle, contentDescription = "التسليم") },
                                            label = { Text("التسليم", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 5. التقارير
                                    if (isManager || repository.canAccessScreen("reports")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Reports.route,
                                            onClick = {
                                                navController.navigate(Screen.Reports.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.BarChart, contentDescription = "التقارير") },
                                            label = { Text("التقارير", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = Screen.Login.route,
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable(Screen.Login.route) {
                                LoginScreen(
                                    database = database,
                                    repository = repository,
                                    onLoginSuccess = {
                                        navController.navigate(Screen.Dashboard.route) {
                                            popUpTo(Screen.Login.route) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(Screen.Dashboard.route) {
                                DashboardScreen(
                                    repository = repository,
                                    onNavigateToFamilies = { navController.navigate(Screen.Families.route) },
                                    onNavigateToNomination = { navController.navigate(Screen.Nomination.route) },
                                    onNavigateToReports = { navController.navigate(Screen.Reports.route) },
                                    onNavigateToDelivery = { navController.navigate(Screen.Delivery.route) },
                                    onNavigateToAccounts = { navController.navigate(Screen.AccountsPermissions.route) },
                                    onNavigateToBackup = { navController.navigate(Screen.BackupRestore.route) },
                                    onNavigateToGeographic = { navController.navigate(Screen.GeographicDistribution.route) },
                                    onLogout = {
                                        navController.navigate(Screen.Login.route) {
                                            popUpTo(0) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(Screen.Families.route) {
                                FamiliesScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.Children.route) {
                                ChildrenScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.Delivery.route) {
                                DeliveryScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.AccountsPermissions.route) {
                                AccountsPermissionsScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.ExcelImportExport.route) {
                                ExcelImportExportScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.GeographicDistribution.route) {
                                GeographicDistributionScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.Nomination.route) {
                                NominationScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateToManualSelection = { aidId, prjId ->
                                        navController.navigate("manual_selection/$aidId/$prjId")
                                    },
                                    onNavigateToResults = {
                                        navController.navigate(Screen.NominationResults.route)
                                    }
                                )
                            }

                            composable("manual_selection/{aidTypeId}/{projectId}") { backStackEntry ->
                                val aidTypeId = backStackEntry.arguments?.getString("aidTypeId")?.toIntOrNull() ?: 1
                                val projectId = backStackEntry.arguments?.getString("projectId")?.toLongOrNull() ?: 1L
                                ManualSelectionScreen(
                                    repository = repository,
                                    aidTypeId = aidTypeId,
                                    projectId = projectId,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.NominationResults.route) {
                                NominationResultsScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateHome = {
                                        navController.navigate(Screen.Dashboard.route) {
                                            popUpTo(Screen.Dashboard.route) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(Screen.Reports.route) {
                                ReportsScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.BackupRestore.route) {
                                BackupRestoreScreen(
                                    database = database,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
