package com.humanitarian.aidmanagement

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.humanitarian.aidmanagement.data.local.entities.User
import com.humanitarian.aidmanagement.ui.screens.*
import com.humanitarian.aidmanagement.ui.theme.HumanitarianAidTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as AidApplication

        setContent {
            HumanitarianAidTheme {
                // Force RTL throughout the entire application
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val navController = rememberNavController()
                    var currentUser by remember { mutableStateOf<User?>(null) }
                    var isSuperAdmin by remember { mutableStateOf(false) }
                    var allowedLocalityIds by remember { mutableStateOf(emptyList<Int>()) }

                    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
                    val scope = rememberCoroutineScope()

                    if (currentUser == null) {
                        LoginScreen(
                            repository = app.repository,
                            onLoginSuccess = { user ->
                                scope.launch {
                                    val (superAdmin, locs) = app.repository.getUserScope(user)
                                    isSuperAdmin = superAdmin
                                    allowedLocalityIds = locs
                                    currentUser = user
                                }
                            }
                        )
                    } else {
                        ModalNavigationDrawer(
                            drawerState = drawerState,
                            drawerContent = {
                                ModalDrawerSheet {
                                    Spacer(Modifier.height(16.dp))
                                    Text(
                                        "نظام إدارة المساعدات الإنسانية",
                                        style = MaterialTheme.typography.titleLarge,
                                        modifier = Modifier.padding(16.dp),
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        "المستخدم: ${currentUser?.fullName} (${if (isSuperAdmin) "مدير عام - كل المحليات" else "نطاق محدد"})",
                                        style = MaterialTheme.typography.bodyMedium,
                                        modifier = Modifier.padding(horizontal = 16.dp)
                                    )
                                    HorizontalDivider(Modifier.padding(vertical = 12.dp))

                                    NavigationDrawerItem(
                                        icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                                        label = { Text("الرئيسية") },
                                        selected = false,
                                        onClick = {
                                            scope.launch { drawerState.close() }
                                            navController.navigate("dashboard")
                                        }
                                    )
                                    NavigationDrawerItem(
                                        icon = { Icon(Icons.Default.People, contentDescription = null) },
                                        label = { Text("بيانات الأسر") },
                                        selected = false,
                                        onClick = {
                                            scope.launch { drawerState.close() }
                                            navController.navigate("families")
                                        }
                                    )
                                    NavigationDrawerItem(
                                        icon = { Icon(Icons.Default.VolunteerActivism, contentDescription = null) },
                                        label = { Text("المساعدات") },
                                        selected = false,
                                        onClick = {
                                            scope.launch { drawerState.close() }
                                            navController.navigate("aid_records")
                                        }
                                    )
                                    NavigationDrawerItem(
                                        icon = { Icon(Icons.Default.HowToReg, contentDescription = null) },
                                        label = { Text("الترشيح") },
                                        selected = false,
                                        onClick = {
                                            scope.launch { drawerState.close() }
                                            navController.navigate("nomination")
                                        }
                                    )
                                    NavigationDrawerItem(
                                        icon = { Icon(Icons.Default.Assessment, contentDescription = null) },
                                        label = { Text("التقارير") },
                                        selected = false,
                                        onClick = {
                                            scope.launch { drawerState.close() }
                                            navController.navigate("reports")
                                        }
                                    )
                                    if (currentUser?.roleId == 1 || currentUser?.roleId == 2) {
                                        NavigationDrawerItem(
                                            icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                                            label = { Text("الإعدادات والمستخدمين") },
                                            selected = false,
                                            onClick = {
                                                scope.launch { drawerState.close() }
                                                navController.navigate("settings")
                                            }
                                        )
                                    }
                                    Spacer(Modifier.weight(1f))
                                    NavigationDrawerItem(
                                        icon = { Icon(Icons.Default.Logout, contentDescription = null) },
                                        label = { Text("تسجيل الخروج") },
                                        selected = false,
                                        onClick = {
                                            scope.launch { drawerState.close() }
                                            currentUser = null
                                        }
                                    )
                                    Spacer(Modifier.height(16.dp))
                                }
                            }
                        ) {
                            NavHost(navController = navController, startDestination = "dashboard") {
                                composable("dashboard") {
                                    DashboardScreen(
                                        repository = app.repository,
                                        database = app.database,
                                        isSuperAdmin = isSuperAdmin,
                                        allowedLocalityIds = allowedLocalityIds,
                                        onOpenDrawer = { scope.launch { drawerState.open() } }
                                    )
                                }
                                composable("families") {
                                    FamiliesScreen(
                                        repository = app.repository,
                                        isSuperAdmin = isSuperAdmin,
                                        allowedLocalityIds = allowedLocalityIds,
                                        onOpenDrawer = { scope.launch { drawerState.open() } },
                                        onFamilySelected = { familyId ->
                                            navController.navigate("family_details/$familyId")
                                        }
                                    )
                                }
                                composable("family_details/{familyId}") { backStackEntry ->
                                    val familyId = backStackEntry.arguments?.getString("familyId")?.toIntOrNull() ?: 0
                                    FamilyDetailsScreen(
                                        familyId = familyId,
                                        repository = app.repository,
                                        isSuperAdmin = isSuperAdmin,
                                        allowedLocalityIds = allowedLocalityIds,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                                composable("aid_records") {
                                    AidRecordsScreen(
                                        repository = app.repository,
                                        isSuperAdmin = isSuperAdmin,
                                        allowedLocalityIds = allowedLocalityIds,
                                        onOpenDrawer = { scope.launch { drawerState.open() } }
                                    )
                                }
                                composable("nomination") {
                                    NominationScreen(
                                        database = app.database,
                                        repository = app.repository,
                                        engine = app.nominationEngine,
                                        currentUser = currentUser!!,
                                        isSuperAdmin = isSuperAdmin,
                                        allowedLocalityIds = allowedLocalityIds,
                                        onOpenDrawer = { scope.launch { drawerState.open() } }
                                    )
                                }
                                composable("reports") {
                                    ReportsScreen(
                                        repository = app.repository,
                                        database = app.database,
                                        isSuperAdmin = isSuperAdmin,
                                        allowedLocalityIds = allowedLocalityIds,
                                        onOpenDrawer = { scope.launch { drawerState.open() } }
                                    )
                                }
                                composable("settings") {
                                    SettingsScreen(
                                        database = app.database,
                                        currentUser = currentUser!!,
                                        onOpenDrawer = { scope.launch { drawerState.open() } }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
