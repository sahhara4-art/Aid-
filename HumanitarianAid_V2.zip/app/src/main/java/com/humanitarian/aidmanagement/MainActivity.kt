package com.humanitarian.aidmanagement

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.fragment.app.FragmentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.humanitarian.aidmanagement.ui.navigation.Screen
import com.humanitarian.aidmanagement.ui.screens.children.ChildrenScreen
import com.humanitarian.aidmanagement.ui.screens.dashboard.DashboardScreen
import com.humanitarian.aidmanagement.ui.screens.delivery.DeliveryScreen
import com.humanitarian.aidmanagement.ui.screens.excel.ExcelImportExportScreen
import com.humanitarian.aidmanagement.ui.screens.families.FamiliesScreen
import com.humanitarian.aidmanagement.ui.screens.families.FamilyDetailsScreen
import com.humanitarian.aidmanagement.ui.screens.login.LoginScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.ManualSelectionScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.NominationResultsScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.NominationScreen
import com.humanitarian.aidmanagement.ui.screens.reports.ReportsScreen
import com.humanitarian.aidmanagement.ui.screens.users.AccountsPermissionsScreen
import com.humanitarian.aidmanagement.ui.screens.backup.BackupRestoreScreen
import com.humanitarian.aidmanagement.ui.screens.geo.GeographicDistributionScreen
import com.humanitarian.aidmanagement.ui.screens.projects.ProjectDetailsScreen
import com.humanitarian.aidmanagement.ui.screens.projects.ProjectsScreen
import com.humanitarian.aidmanagement.ui.screens.reports.ExecutiveReportsScreen
import com.humanitarian.aidmanagement.ui.components.sync.DynamicSyncStatusIndicator
import com.humanitarian.aidmanagement.ui.theme.*

class MainActivity : FragmentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // التحقق الإضافي الصارم من المعترض قبل أي استدعاء لـ database أو repository أو setContent
        try {
            com.humanitarian.aidmanagement.data.backup.DatabaseBackupManager.performPendingRestoreIfRequired(this)
        } catch (e: Throwable) {
            android.util.Log.e("MainActivity", "Pre-Boot restore check warning: ${e.message}", e)
        }

        val app = (application as? AidApplication) ?: AidApplication.instance
        val repository = app.repository
        val database = app.database

        setContent {
            HumanitarianAidTheme(darkTheme = false) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val navController = rememberNavController()
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route

                    val isLogin = currentRoute == Screen.Login.route
                    val currentUser by repository.currentUserFlow.collectAsState(initial = repository.getCurrentUser())
                    val isManager = currentUser == null || currentUser?.RoleID == 1 || currentUser?.UserName?.equals("admin", ignoreCase = true) == true
                    val syncState by repository.getSyncState().collectAsState()
                    val userAssignedRegion = remember(currentUser) {
                        val region = currentUser?.AllowedNominationSubAreas?.trim() ?: "All"
                        if (region == "*" || region.isBlank()) "All" else region
                    }

                    val nominationViewModel: com.humanitarian.aidmanagement.ui.screens.nomination.NominationViewModel =
                        androidx.lifecycle.viewmodel.compose.viewModel(
                            factory = com.humanitarian.aidmanagement.ui.screens.nomination.NominationViewModel.Factory(repository, userAssignedRegion)
                        )

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = SlateBackground,
                        topBar = {
                            if (!isLogin && currentRoute == Screen.Dashboard.route) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    TopAppBar(
                                        title = {
                                            Column {
                                                Text(
                                                    text = "إدارة المساعدات الإنسانية",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = SlateTextPrimary,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Text(
                                                        text = currentUser?.fullName ?: "مدير النظام",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = SlateTextSecondary,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(text = "•", color = SlateTextMuted)
                                                    Text(
                                                        text = repository.getAllowedGroupForCurrentUser(),
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = PalestineGreen,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                }
                                            }
                                        },
                                        actions = {
                                            // مؤشر حالة التزامن الديناميكي اللحظي مع سيرفرات جوجل Firestore
                                            DynamicSyncStatusIndicator(
                                                syncState = syncState,
                                                onClick = { navController.navigate(Screen.BackupRestore.route) }
                                            )

                                            Spacer(modifier = Modifier.width(4.dp))

                                            // زر شاشة التوزيع الجغرافي للمستفيدين (الخريطة والمناطق الفرعية)
                                            IconButton(onClick = { navController.navigate(Screen.GeographicDistribution.route) }) {
                                                Icon(
                                                    Icons.Default.Map,
                                                    contentDescription = "التوزيع الجغرافي للمستفيدين",
                                                    tint = PalestineGreen
                                                )
                                            }

                                            // زر شاشة المشاريع الإنسانية المنفذة
                                            IconButton(onClick = { navController.navigate(Screen.Projects.route) }) {
                                                Icon(
                                                    Icons.Default.FolderShared,
                                                    contentDescription = "المشاريع المنفذة",
                                                    tint = PalestineGreen
                                                )
                                            }

                                            // زر التقرير الإداري التنفيذي واستيراد وتصدير إكسل
                                            if (isManager || repository.canAccessScreen("excel_import_export") || repository.canAccessScreen("executive_reports")) {
                                                IconButton(onClick = { navController.navigate(Screen.ExecutiveReports.route) }) {
                                                    Icon(
                                                        Icons.Default.Assessment,
                                                        contentDescription = "التقرير الإداري التنفيذي",
                                                        tint = PalestineGreen
                                                    )
                                                }
                                            }

                                            // زر الحسابات والصلاحيات التفصيلية لمدير النظام
                                            if (isManager) {
                                                IconButton(onClick = { navController.navigate(Screen.AccountsPermissions.route) }) {
                                                    Icon(
                                                        Icons.Default.AdminPanelSettings,
                                                        contentDescription = "الصلاحيات والمستخدمين",
                                                        tint = PalestineRed
                                                    )
                                                }
                                            }

                                            // زر استيراد وتصدير إكسل
                                            IconButton(onClick = { navController.navigate(Screen.ExcelImportExport.route) }) {
                                                Icon(
                                                    Icons.Default.UploadFile,
                                                    contentDescription = "استيراد وتصدير إكسل",
                                                    tint = PalestineGreen
                                                )
                                            }

                                            // زر النسخ والتزامن
                                            IconButton(onClick = { navController.navigate(Screen.BackupRestore.route) }) {
                                                Icon(
                                                    Icons.Default.CloudSync,
                                                    contentDescription = "النسخ والتزامن",
                                                    tint = SkyBlue
                                                )
                                            }

                                            // زر تسجيل الخروج
                                            IconButton(onClick = {
                                                repository.logout()
                                                navController.navigate(Screen.Login.route) {
                                                    popUpTo(0) { inclusive = true }
                                                }
                                            }) {
                                                Icon(
                                                    Icons.Default.ExitToApp,
                                                    contentDescription = "تسجيل الخروج",
                                                    tint = SlateTextSecondary
                                                )
                                            }
                                        },
                                        colors = TopAppBarDefaults.topAppBarColors(
                                            containerColor = PalestineWhite,
                                            titleContentColor = SlateTextPrimary
                                        )
                                    )
                                }
                            }
                        },
                        bottomBar = {
                            if (!isLogin && currentRoute != null && !currentRoute.startsWith("manual_selection") && currentRoute != Screen.AccountsPermissions.route && currentRoute != Screen.BackupRestore.route && currentRoute != Screen.ExcelImportExport.route && currentRoute != Screen.ExecutiveReports.route) {
                                NavigationBar(
                                    containerColor = PalestineWhite,
                                    tonalElevation = 3.dp
                                ) {
                                    // 1. الرئيسية
                                    if (isManager || repository.canAccessScreen("dashboard")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Dashboard.route,
                                            onClick = {
                                                navController.navigate(Screen.Dashboard.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.Dashboard, contentDescription = "الرئيسية") },
                                            label = { Text("الرئيسية", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 2. سجل الأسر
                                    if (isManager || repository.canAccessScreen("families")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Families.route,
                                            onClick = {
                                                navController.navigate(Screen.Families.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.FamilyRestroom, contentDescription = "الأسر") },
                                            label = { Text("الأسر", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 3. الترشيح
                                    if (isManager || repository.canAccessScreen("nomination")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Nomination.route,
                                            onClick = {
                                                navController.navigate(Screen.Nomination.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.HowToReg, contentDescription = "الترشيح") },
                                            label = { Text("الترشيح", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 4. التسليم والصرف
                                    if (isManager || repository.canAccessScreen("delivery")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Delivery.route,
                                            onClick = {
                                                navController.navigate(Screen.Delivery.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.CheckCircle, contentDescription = "التسليم") },
                                            label = { Text("التسليم", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 5. التقارير
                                    if (isManager || repository.canAccessScreen("reports")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Reports.route,
                                            onClick = {
                                                navController.navigate(Screen.Reports.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.BarChart, contentDescription = "التقارير") },
                                            label = { Text("التقارير", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = Screen.Login.route,
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable(Screen.Login.route) {
                                LoginScreen(
                                    database = database,
                                    repository = repository,
                                    onLoginSuccess = {
                                        navController.navigate(Screen.Dashboard.route) {
                                            popUpTo(Screen.Login.route) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(Screen.Dashboard.route) {
                                DashboardScreen(
                                    repository = repository,
                                    onNavigateToFamilies = { navController.navigate(Screen.Families.route) },
                                    onNavigateToNomination = { navController.navigate(Screen.Nomination.route) },
                                    onNavigateToReports = { navController.navigate(Screen.Reports.route) },
                                    onNavigateToDelivery = { navController.navigate(Screen.Delivery.route) },
                                    onNavigateToAccounts = { navController.navigate(Screen.AccountsPermissions.route) },
                                    onNavigateToBackup = { navController.navigate(Screen.BackupRestore.route) },
                                    onNavigateToGeographic = { navController.navigate(Screen.GeographicDistribution.route) },
                                    onNavigateToProjects = { navController.navigate(Screen.Projects.route) },
                                    onNavigateToExcelImport = { navController.navigate(Screen.ExcelImportExport.route) },
                                    onLogout = {
                                        navController.navigate(Screen.Login.route) {
                                            popUpTo(0) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(Screen.Families.route) {
                                FamiliesScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateToFamilyDetails = { familyId ->
                                        navController.navigate(Screen.FamilyDetails.createRoute(familyId))
                                    },
                                    onNavigateToAddFamily = {
                                        navController.navigate(Screen.AddFamily.route)
                                    }
                                )
                            }

                            composable(Screen.AddFamily.route) {
                                com.humanitarian.aidmanagement.ui.screens.families.AddFamilyScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(
                                route = Screen.FamilyDetails.route,
                                arguments = listOf(
                                    androidx.navigation.navArgument("familyId") {
                                        type = androidx.navigation.NavType.LongType
                                        defaultValue = 0L
                                    }
                                )
                            ) { backStackEntry ->
                                val familyId = backStackEntry.arguments?.getLong("familyId") ?: 0L
                                FamilyDetailsScreen(
                                    familyId = familyId,
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateToAddChild = { fId, fNatId ->
                                        navController.navigate(Screen.AddChild.createRoute(fId, fNatId))
                                    }
                                )
                            }

                            composable(
                                route = Screen.AddChild.route,
                                arguments = listOf(
                                    androidx.navigation.navArgument("familyId") {
                                        type = androidx.navigation.NavType.LongType
                                        defaultValue = 0L
                                    },
                                    androidx.navigation.navArgument("familyNationalId") {
                                        type = androidx.navigation.NavType.StringType
                                        defaultValue = ""
                                    }
                                )
                            ) { backStackEntry ->
                                val familyId = backStackEntry.arguments?.getLong("familyId") ?: 0L
                                val familyNationalId = backStackEntry.arguments?.getString("familyNationalId")?.let {
                                    java.net.URLDecoder.decode(it, "UTF-8")
                                } ?: ""
                                com.humanitarian.aidmanagement.ui.screens.children.AddChildScreen(
                                    familyId = familyId,
                                    familyNationalId = familyNationalId,
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.Children.route) {
                                ChildrenScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.Delivery.route) {
                                DeliveryScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.AccountsPermissions.route) {
                                AccountsPermissionsScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.ExecutiveReports.route) {
                                ExecutiveReportsScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.ExcelImportExport.route) {
                                ExcelImportExportScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.GeographicDistribution.route) {
                                GeographicDistributionScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.Nomination.route) {
                                NominationScreen(
                                    repository = repository,
                                    nominationViewModel = nominationViewModel,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateToManualSelection = { aidId, prjId ->
                                        navController.navigate("manual_selection/$aidId/$prjId")
                                    },
                                    onNavigateToResults = {
                                        navController.navigate(Screen.NominationResults.route)
                                    }
                                )
                            }

                            composable(Screen.DynamicNomination.route) {
                                com.humanitarian.aidmanagement.ui.screens.nomination.DynamicNominationScreen(
                                    repository = repository,
                                    nominationViewModel = nominationViewModel,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateToManualSelection = { aidId, prjId ->
                                        navController.navigate("manual_selection/$aidId/$prjId")
                                    }
                                )
                            }

                            composable("manual_selection/{aidTypeId}/{projectId}") { backStackEntry ->
                                val aidTypeId = backStackEntry.arguments?.getString("aidTypeId")?.toIntOrNull() ?: 1
                                val projectId = backStackEntry.arguments?.getString("projectId")?.toLongOrNull() ?: 1L
                                ManualSelectionScreen(
                                    repository = repository,
                                    nominationViewModel = nominationViewModel,
                                    aidTypeId = aidTypeId,
                                    projectId = projectId,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.NominationResults.route) {
                                NominationResultsScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateHome = {
                                        navController.navigate(Screen.Dashboard.route) {
                                            popUpTo(Screen.Dashboard.route) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(Screen.Migration.route) {
                                com.humanitarian.aidmanagement.ui.screens.nomination.MigrationScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateHome = {
                                        navController.navigate(Screen.Dashboard.route) {
                                            popUpTo(Screen.Dashboard.route) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(Screen.Transfer.route) {
                                com.humanitarian.aidmanagement.ui.screens.nomination.MigrationScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateHome = {
                                        navController.navigate(Screen.Dashboard.route) {
                                            popUpTo(Screen.Dashboard.route) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(Screen.Projects.route) {
                                ProjectsScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateToProjectDetails = { projectId ->
                                        navController.navigate(Screen.ProjectDetails.createRoute(projectId))
                                    }
                                )
                            }

                            composable(
                                route = Screen.ProjectDetails.route,
                                arguments = listOf(
                                    androidx.navigation.navArgument("projectId") {
                                        type = androidx.navigation.NavType.LongType
                                        defaultValue = 0L
                                    }
                                )
                            ) { backStackEntry ->
                                val projectId = backStackEntry.arguments?.getLong("projectId") ?: 0L
                                ProjectDetailsScreen(
                                    projectId = projectId,
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() },
                                    onNavigateToDelivery = { navController.navigate(Screen.Delivery.route) }
                                )
                            }

                            composable(Screen.Reports.route) {
                                ReportsScreen(
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }

                            composable(Screen.BackupRestore.route) {
                                BackupRestoreScreen(
                                    database = database,
                                    repository = repository,
                                    onNavigateBack = { navController.popBackStack() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
