package com.humanitarian.aidmanagement

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.fragment.app.FragmentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.security.LicenseManager
import com.humanitarian.aidmanagement.security.LicenseStatus
import com.humanitarian.aidmanagement.ui.navigation.Screen
import com.humanitarian.aidmanagement.ui.navigation.canAccessNavRoute
import com.humanitarian.aidmanagement.ui.screens.children.ChildrenScreen
import com.humanitarian.aidmanagement.ui.screens.dashboard.DashboardScreen
import com.humanitarian.aidmanagement.ui.screens.delivery.DeliveryScreen
import com.humanitarian.aidmanagement.ui.screens.excel.DynamicReportExportScreen
import com.humanitarian.aidmanagement.ui.screens.excel.ImportScreen
import com.humanitarian.aidmanagement.ui.screens.families.FamiliesScreen
import com.humanitarian.aidmanagement.ui.screens.families.FamilyDetailsScreen
import com.humanitarian.aidmanagement.ui.screens.license.LicenseActivationScreen
import com.humanitarian.aidmanagement.ui.screens.login.LoginScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.ManualSelectionScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.NominationResultsScreen
import com.humanitarian.aidmanagement.ui.screens.nomination.NominationScreen
import com.humanitarian.aidmanagement.ui.screens.reports.ReportsScreen
import com.humanitarian.aidmanagement.ui.screens.users.AccountsPermissionsScreen
import com.humanitarian.aidmanagement.ui.screens.backup.BackupRestoreScreen
import com.humanitarian.aidmanagement.ui.screens.geo.GeographicDistributionScreen
import com.humanitarian.aidmanagement.ui.screens.projects.ExportProjectScreen
import com.humanitarian.aidmanagement.ui.screens.projects.ProjectDetailsScreen
import com.humanitarian.aidmanagement.ui.screens.projects.ProjectsScreen
import com.humanitarian.aidmanagement.ui.screens.reports.ExecutiveReportsScreen
import com.humanitarian.aidmanagement.ui.components.GlassNavigationDrawerSheet
import com.humanitarian.aidmanagement.ui.components.sync.DynamicSyncStatusIndicator
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch

class MainActivity : FragmentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val app = (application as? AidApplication) ?: AidApplication.instance

            setContent {
                HumanitarianAidTheme(darkTheme = false) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        MainAppScaffold(app = app)
                    }
                }
            }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            LicenseManager.refreshStatus(applicationContext)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(app: AidApplication) {
    val context = LocalContext.current
    val appContext = remember(app, context) { app.applicationContext ?: context.applicationContext ?: context }
    val repository = app.repository
    val database = app.database
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val startRoute = remember {
        try {
            if (LicenseManager.isLicenseValid(appContext)) {
                Screen.Login.route
            } else {
                Screen.LicenseActivation.route
            }
        } catch (_: Throwable) {
            Screen.LicenseActivation.route
        }
    }
    val licenseStatus by LicenseManager.licenseStatusFlow.collectAsStateWithLifecycle()
    val isLicensed = licenseStatus is LicenseStatus.Valid

    LaunchedEffect(isLicensed, currentRoute) {
        if (!isLicensed && currentRoute != null && currentRoute != Screen.LicenseActivation.route) {
            try {
                if (navController.currentDestination != null) {
                    navController.navigate(Screen.LicenseActivation.route) {
                        popUpTo(0) { inclusive = true }
                        launchSingleTop = true
                    }
                }
            } catch (_: Throwable) {
            }
        }
    }

                    val isLogin = currentRoute == null || currentRoute == Screen.Login.route || currentRoute == Screen.LicenseActivation.route
                    val currentUser by repository.currentUserFlow.collectAsStateWithLifecycle(initialValue = repository.getCurrentUser())
                    val isManager = currentUser != null && repository.isSuperAdmin()
                    val acmPermissions by AccessControlManager.permissionsFlow.collectAsStateWithLifecycle()
                    val permissions: List<String> = remember(acmPermissions, currentUser, isManager) {
                        when {
                            currentUser == null -> emptyList()
                            isManager -> (AccessControlManager.ALL_ACTIONS.map { it.first } + AccessControlManager.ALL_SCREENS.map { it.first }).distinct()
                            else -> acmPermissions
                        }
                    }
                    val syncState by repository.getSyncState().collectAsStateWithLifecycle()
                    val userAssignedRegion = remember(currentUser) {
                        val region = currentUser?.AllowedNominationSubAreas?.trim() ?: "All"
                        if (region == "*" || region.isBlank()) "All" else region
                    }
                    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
                    val scope = rememberCoroutineScope()
                    val isDrawerActive = isLicensed && !isLogin && currentUser != null

                    LaunchedEffect(isDrawerActive) {
                        if (!isDrawerActive && drawerState.isOpen) {
                            drawerState.close()
                        }
                    }

                    ModalNavigationDrawer(
                        drawerState = drawerState,
                        gesturesEnabled = isDrawerActive,
                        scrimColor = Color(0xFF0F172A).copy(alpha = 0.56f),
                        drawerContent = {
                            if (isDrawerActive) {
                                GlassNavigationDrawerSheet(
                                    currentRoute = currentRoute,
                                    userFullName = currentUser?.fullName ?: "مدير النظام",
                                    userRoleLabel = if (isManager) "مهندس النظام" else "مستخدم مصرح",
                                    allowedGeographicScope = repository.getAllowedGroupForCurrentUser(),
                                    isManager = isManager,
                                    permissions = permissions,
                                    onNavigate = { targetRoute ->
                                        scope.launch { drawerState.close() }
                                        if (targetRoute == Screen.Dashboard.route) {
                                            navController.navigate(Screen.Dashboard.route) {
                                                popUpTo(Screen.Dashboard.route) { inclusive = false }
                                                launchSingleTop = true
                                            }
                                        } else if (currentRoute != targetRoute) {
                                            navController.navigate(targetRoute) {
                                                launchSingleTop = true
                                            }
                                        }
                                    },
                                    onLogout = {
                                        scope.launch { drawerState.close() }
                                        repository.logout()
                                        navController.navigate(Screen.Login.route) {
                                            popUpTo(0) { inclusive = true }
                                        }
                                    }
                                )
                            }
                        }
                    ) {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        containerColor = SlateBackground,
                        topBar = {
                            if (isLicensed && !isLogin && currentRoute == Screen.Dashboard.route) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    TopAppBar(
                                        navigationIcon = {
                                            IconButton(onClick = { scope.launch { drawerState.open() } }) {
                                                Icon(
                                                    imageVector = Icons.Default.Menu,
                                                    contentDescription = "القائمة الجانبية",
                                                    tint = PalestineGreen
                                                )
                                            }
                                        },
                                        title = {
                                            Column {
                                                Text(
                                                    text = "إدارة المساعدات الإنسانية",
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = SlateTextPrimary,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    Text(
                                                        text = currentUser?.fullName ?: "مدير النظام",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = SlateTextSecondary,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(text = "•", color = SlateTextMuted)
                                                    Text(
                                                        text = repository.getAllowedGroupForCurrentUser(),
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = PalestineGreen,
                                                        fontWeight = FontWeight.SemiBold
                                                    )
                                                }
                                            }
                                        },
                                        actions = {
                                            val canAccessBackup = isManager || permissions.contains("CAN_BACKUP_CLOUD") || permissions.contains("CAN_BACKUP_LOCAL")
                                            val canAccessUsers = isManager || permissions.contains("CAN_MANAGE_USERS")
                                            val canAccessGeographic = isManager || permissions.contains("CAN_ACCESS_BI_DASHBOARD") || permissions.contains("CAN_VIEW_GEOGRAPHIC")
                                            val canAccessProjects = isManager || permissions.contains("CAN_MANAGE_PROJECTS") || permissions.contains("CAN_RUN_FILTRATION")
                                            val canAccessExecutiveReports = isManager || permissions.contains("CAN_ACCESS_BI_DASHBOARD") || permissions.contains("CAN_EXPORT_REPORTS")
                                            val canAccessDynamicReports = isManager || permissions.contains("CAN_EXPORT_REPORTS") || permissions.contains("CAN_ACCESS_BI_DASHBOARD")
                                            val canAccessExcel = isManager || permissions.contains("CAN_IMPORT_EXCEL")

                                            // مؤشر حالة التزامن الديناميكي اللحظي مع سيرفرات جوجل Firestore
                                            if (canAccessBackup) {
                                                DynamicSyncStatusIndicator(
                                                    syncState = syncState,
                                                    onClick = {
                                                        navController.navigate(Screen.BackupRestore.route)
                                                    }
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                            }

                                            // زر شاشة التوزيع الجغرافي للمستفيدين (الخريطة والمناطق الفرعية)
                                            if (canAccessGeographic) {
                                                IconButton(onClick = { navController.navigate(Screen.GeographicDistribution.route) }) {
                                                    Icon(
                                                        Icons.Default.Map,
                                                        contentDescription = "التوزيع الجغرافي للمستفيدين",
                                                        tint = PalestineGreen
                                                    )
                                                }
                                            }

                                            // زر شاشة المشاريع الإنسانية المنفذة
                                            if (canAccessProjects) {
                                                IconButton(onClick = { navController.navigate(Screen.Projects.route) }) {
                                                    Icon(
                                                        Icons.Default.FolderShared,
                                                        contentDescription = "المشاريع المنفذة",
                                                        tint = PalestineGreen
                                                    )
                                                }
                                            }

                                            // زر التقرير الإداري التنفيذي
                                            if (canAccessExecutiveReports) {
                                                IconButton(onClick = { navController.navigate(Screen.ExecutiveReports.route) }) {
                                                    Icon(
                                                        Icons.Default.Assessment,
                                                        contentDescription = "التقرير الإداري التنفيذي",
                                                        tint = PalestineGreen
                                                    )
                                                }
                                            }

                                            // زر الحسابات والصلاحيات التفصيلية (CAN_MANAGE_USERS)
                                            if (canAccessUsers) {
                                                IconButton(onClick = { navController.navigate(Screen.AccountsPermissions.route) }) {
                                                    Icon(
                                                        Icons.Default.AdminPanelSettings,
                                                        contentDescription = "الصلاحيات والمستخدمين",
                                                        tint = PalestineRed
                                                    )
                                                }
                                            }

                                            // زر مركز التقارير والمعاينة الديناميكي (CAN_EXPORT_REPORTS / CAN_ACCESS_BI_DASHBOARD)
                                            if (canAccessDynamicReports) {
                                                IconButton(onClick = { navController.navigate(Screen.DynamicReportExport.route) }) {
                                                    Icon(
                                                        Icons.Default.Insights,
                                                        contentDescription = "مركز التقارير الديناميكي",
                                                        tint = PalestineGreen
                                                    )
                                                }
                                            }

                                            // زر استيراد ملفات إكسل (CAN_IMPORT_EXCEL)
                                            if (canAccessExcel) {
                                                IconButton(onClick = { navController.navigate(Screen.ExcelImportExport.route) }) {
                                                    Icon(
                                                        Icons.Default.UploadFile,
                                                        contentDescription = "استيراد ملفات إكسل",
                                                        tint = PalestineGreen
                                                    )
                                                }
                                            }

                                            // زر النسخ الاحتياطي والتزامن (CAN_BACKUP_CLOUD / CAN_BACKUP_LOCAL)
                                            if (canAccessBackup) {
                                                IconButton(onClick = { navController.navigate(Screen.BackupRestore.route) }) {
                                                    Icon(
                                                        Icons.Default.CloudSync,
                                                        contentDescription = "النسخ والتزامن",
                                                        tint = SkyBlue
                                                    )
                                                }
                                            }

                                            // زر تسجيل الخروج
                                            IconButton(onClick = {
                                                repository.logout()
                                                navController.navigate(Screen.Login.route) {
                                                    popUpTo(0) { inclusive = true }
                                                }
                                            }) {
                                                Icon(
                                                    Icons.Default.ExitToApp,
                                                    contentDescription = "تسجيل الخروج",
                                                    tint = SlateTextSecondary
                                                )
                                            }
                                        },
                                        colors = TopAppBarDefaults.topAppBarColors(
                                            containerColor = PalestineWhite,
                                            titleContentColor = SlateTextPrimary
                                        )
                                    )
                                }
                            }
                        },
                        bottomBar = {
                            if (isLicensed && !isLogin && currentRoute != null && !currentRoute.startsWith("manual_selection") && !currentRoute.startsWith("export_project_screen") && currentRoute != Screen.AccountsPermissions.route && currentRoute != Screen.UsersManagement.route && currentRoute != Screen.BackupRestore.route && currentRoute != Screen.ExcelImportExport.route && currentRoute != Screen.DynamicReportExport.route && currentRoute != Screen.ExecutiveReports.route) {
                                NavigationBar(
                                    containerColor = PalestineWhite,
                                    tonalElevation = 3.dp
                                ) {
                                    // 1. الرئيسية
                                    if (currentUser != null) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Dashboard.route,
                                            onClick = {
                                                navController.navigate(Screen.Dashboard.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.Dashboard, contentDescription = "الرئيسية") },
                                            label = { Text("الرئيسية", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 2. سجل الأسر (CAN_MANAGE_FAMILIES)
                                    if (isManager || permissions.contains("CAN_MANAGE_FAMILIES")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Families.route,
                                            onClick = {
                                                navController.navigate(Screen.Families.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.FamilyRestroom, contentDescription = "الأسر") },
                                            label = { Text("الأسر", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 3. الترشيح (CAN_RUN_FILTRATION)
                                    if (isManager || permissions.contains("CAN_RUN_FILTRATION")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Nomination.route,
                                            onClick = {
                                                navController.navigate(Screen.Nomination.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.HowToReg, contentDescription = "الترشيح") },
                                            label = { Text("الترشيح", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 4. التسليم والصرف (CAN_DELIVER_AID)
                                    if (isManager || permissions.contains("CAN_DELIVER_AID")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Delivery.route,
                                            onClick = {
                                                navController.navigate(Screen.Delivery.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.CheckCircle, contentDescription = "التسليم") },
                                            label = { Text("التسليم", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }

                                    // 5. التقارير (CAN_ACCESS_BI_DASHBOARD)
                                    if (isManager || permissions.contains("CAN_ACCESS_BI_DASHBOARD")) {
                                        NavigationBarItem(
                                            selected = currentRoute == Screen.Reports.route,
                                            onClick = {
                                                navController.navigate(Screen.Reports.route) {
                                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                                    launchSingleTop = true
                                                    restoreState = true
                                                }
                                            },
                                            icon = { Icon(Icons.Default.BarChart, contentDescription = "التقارير") },
                                            label = { Text("التقارير", style = MaterialTheme.typography.labelSmall) },
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = PalestineGreen,
                                                selectedTextColor = PalestineGreen,
                                                indicatorColor = PalestineGreenContainer
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = startRoute,
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable(Screen.LicenseActivation.route) {
                                LicenseActivationScreen(
                                    licenseStatus = licenseStatus,
                                    onLicenseActivated = {
                                        navController.navigate(Screen.Login.route) {
                                            popUpTo(Screen.LicenseActivation.route) { inclusive = true }
                                        }
                                    }
                                )
                            }

                            composable(Screen.Login.route) {
                                if (isLicensed) {
                                    LoginScreen(
                                        database = database,
                                        repository = repository,
                                        onLoginSuccess = {
                                            try {
                                                navController.navigate(Screen.Dashboard.route) {
                                                    popUpTo(Screen.Login.route) { inclusive = true }
                                                }
                                            } catch (e: Exception) {
                                                e.printStackTrace()
                                            }
                                        }
                                    )
                                }
                            }

                            composable(Screen.Dashboard.route) {
                                if (isLicensed) {
                                    DashboardScreen(
                                        repository = repository,
                                        onNavigateToFamilies = { navController.navigate(Screen.Families.route) },
                                        onNavigateToNomination = { navController.navigate(Screen.Nomination.route) },
                                        onNavigateToReports = { navController.navigate(Screen.Reports.route) },
                                        onNavigateToDelivery = { navController.navigate(Screen.Delivery.route) },
                                        onNavigateToAccounts = { navController.navigate(Screen.AccountsPermissions.route) },
                                        onNavigateToBackup = { navController.navigate(Screen.BackupRestore.route) },
                                        onNavigateToGeographic = { navController.navigate(Screen.GeographicDistribution.route) },
                                        onNavigateToProjects = { navController.navigate(Screen.Projects.route) },
                                        onNavigateToExcelImport = { navController.navigate(Screen.ExcelImportExport.route) },
                                        onNavigateToDynamicReportExport = { navController.navigate(Screen.DynamicReportExport.route) },
                                        onLogout = {
                                            navController.navigate(Screen.Login.route) {
                                                popUpTo(0) { inclusive = true }
                                            }
                                        }
                                    )
                                }
                            }

                            composable(Screen.Families.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = isLicensed && currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.Families.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    FamiliesScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() },
                                        onNavigateToFamilyDetails = { familyId ->
                                            navController.navigate(Screen.FamilyDetails.createRoute(familyId))
                                        },
                                        onNavigateToAddFamily = {
                                            navController.navigate(Screen.AddFamily.route)
                                        }
                                    )
                                }
                            }

                            composable(Screen.AddFamily.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.AddFamily.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    com.humanitarian.aidmanagement.ui.screens.families.AddFamilyScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(
                                route = Screen.FamilyDetails.route,
                                arguments = listOf(
                                    androidx.navigation.navArgument("familyId") {
                                        type = androidx.navigation.NavType.LongType
                                        defaultValue = 0L
                                    }
                                )
                            ) { backStackEntry ->
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.FamilyDetails.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    val familyId = backStackEntry.arguments?.getLong("familyId") ?: 0L
                                    FamilyDetailsScreen(
                                        familyId = familyId,
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() },
                                        onNavigateToAddChild = { fId, fNatId ->
                                            navController.navigate(Screen.AddChild.createRoute(fId, fNatId))
                                        }
                                    )
                                }
                            }

                            composable(
                                route = Screen.AddChild.route,
                                arguments = listOf(
                                    androidx.navigation.navArgument("familyId") {
                                        type = androidx.navigation.NavType.LongType
                                        defaultValue = 0L
                                    },
                                    androidx.navigation.navArgument("familyNationalId") {
                                        type = androidx.navigation.NavType.StringType
                                        defaultValue = ""
                                    }
                                )
                            ) { backStackEntry ->
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.AddChild.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    val familyId = backStackEntry.arguments?.getLong("familyId") ?: 0L
                                    val familyNationalId = backStackEntry.arguments?.getString("familyNationalId")?.let {
                                        java.net.URLDecoder.decode(it, "UTF-8")
                                    } ?: ""
                                    com.humanitarian.aidmanagement.ui.screens.children.AddChildScreen(
                                        familyId = familyId,
                                        familyNationalId = familyNationalId,
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.Children.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.Children.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    ChildrenScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.Delivery.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.Delivery.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    DeliveryScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.AccountsPermissions.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.AccountsPermissions.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    AccountsPermissionsScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.UsersManagement.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.UsersManagement.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    AccountsPermissionsScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.ExecutiveReports.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.ExecutiveReports.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    ExecutiveReportsScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.ExcelImportExport.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.ExcelImportExport.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    ImportScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.DynamicReportExport.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.DynamicReportExport.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    DynamicReportExportScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.GeographicDistribution.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.GeographicDistribution.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    GeographicDistributionScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.Nomination.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.Nomination.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    val nominationViewModel: com.humanitarian.aidmanagement.ui.screens.nomination.NominationViewModel =
                                        androidx.lifecycle.viewmodel.compose.viewModel(
                                            factory = com.humanitarian.aidmanagement.ui.screens.nomination.NominationViewModel.Factory(repository, userAssignedRegion)
                                        )
                                    NominationScreen(
                                        repository = repository,
                                        nominationViewModel = nominationViewModel,
                                        onNavigateBack = { navController.popBackStack() },
                                        onNavigateToManualSelection = { aidId, prjId ->
                                            navController.navigate("manual_selection/$aidId/$prjId")
                                        },
                                        onNavigateToResults = {
                                            navController.navigate(Screen.NominationResults.route)
                                        }
                                    )
                                }
                            }

                            composable(Screen.DynamicNomination.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.DynamicNomination.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    val nominationViewModel: com.humanitarian.aidmanagement.ui.screens.nomination.NominationViewModel =
                                        androidx.lifecycle.viewmodel.compose.viewModel(
                                            factory = com.humanitarian.aidmanagement.ui.screens.nomination.NominationViewModel.Factory(repository, userAssignedRegion)
                                        )
                                    com.humanitarian.aidmanagement.ui.screens.nomination.DynamicNominationScreen(
                                        repository = repository,
                                        nominationViewModel = nominationViewModel,
                                        onNavigateBack = { navController.popBackStack() },
                                        onNavigateToManualSelection = { aidId, prjId ->
                                            navController.navigate("manual_selection/$aidId/$prjId")
                                        }
                                    )
                                }
                            }

                            composable("manual_selection/{aidTypeId}/{projectId}") { backStackEntry ->
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute("manual_selection", permissions, isManager),
                                    navController = navController
                                ) {
                                    val nominationViewModel: com.humanitarian.aidmanagement.ui.screens.nomination.NominationViewModel =
                                        androidx.lifecycle.viewmodel.compose.viewModel(
                                            factory = com.humanitarian.aidmanagement.ui.screens.nomination.NominationViewModel.Factory(repository, userAssignedRegion)
                                        )
                                    val aidTypeId = backStackEntry.arguments?.getString("aidTypeId")?.toIntOrNull() ?: 1
                                    val projectId = backStackEntry.arguments?.getString("projectId")?.toLongOrNull() ?: 1L
                                    ManualSelectionScreen(
                                        repository = repository,
                                        nominationViewModel = nominationViewModel,
                                        aidTypeId = aidTypeId,
                                        projectId = projectId,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.NominationResults.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.NominationResults.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    NominationResultsScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() },
                                        onNavigateHome = {
                                            navController.navigate(Screen.Dashboard.route) {
                                                popUpTo(Screen.Dashboard.route) { inclusive = true }
                                            }
                                        }
                                    )
                                }
                            }

                            composable(Screen.Migration.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.Migration.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    com.humanitarian.aidmanagement.ui.screens.nomination.MigrationScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() },
                                        onNavigateHome = {
                                            navController.navigate(Screen.Dashboard.route) {
                                                popUpTo(Screen.Dashboard.route) { inclusive = true }
                                            }
                                        }
                                    )
                                }
                            }

                            composable(Screen.Transfer.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.Transfer.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    com.humanitarian.aidmanagement.ui.screens.nomination.MigrationScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() },
                                        onNavigateHome = {
                                            navController.navigate(Screen.Dashboard.route) {
                                                popUpTo(Screen.Dashboard.route) { inclusive = true }
                                            }
                                        }
                                    )
                                }
                            }

                            composable(Screen.Projects.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.Projects.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    ProjectsScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() },
                                        onNavigateToProjectDetails = { projectId ->
                                            navController.navigate(Screen.ProjectDetails.createRoute(projectId))
                                        }
                                    )
                                }
                            }

                            composable(
                                route = Screen.ProjectDetails.route,
                                arguments = listOf(
                                    androidx.navigation.navArgument("projectId") {
                                        type = androidx.navigation.NavType.LongType
                                        defaultValue = 0L
                                    }
                                )
                            ) { backStackEntry ->
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.ProjectDetails.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    val projectId = backStackEntry.arguments?.getLong("projectId") ?: 0L
                                    ProjectDetailsScreen(
                                        projectId = projectId,
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() },
                                        onNavigateToDelivery = { navController.navigate(Screen.Delivery.route) },
                                        onNavigateToExport = { navController.navigate("export_project_screen/$projectId") }
                                    )
                                }
                            }

                            composable(
                                route = Screen.ExportProject.route,
                                arguments = listOf(
                                    androidx.navigation.navArgument("projectId") {
                                        type = androidx.navigation.NavType.LongType
                                        defaultValue = 0L
                                    }
                                )
                            ) { backStackEntry ->
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.ExportProject.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    val projectId = backStackEntry.arguments?.getLong("projectId") ?: 0L
                                    ExportProjectScreen(
                                        projectId = projectId,
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }

                            composable(Screen.Reports.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.Reports.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    ReportsScreen(
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() },
                                        onNavigateToDynamicReportExport = { navController.navigate(Screen.DynamicReportExport.route) }
                                    )
                                }
                            }

                            composable(Screen.BackupRestore.route) {
                                AuthorizedRouteGuard(
                                    isAuthenticated = currentUser != null,
                                    hasPermission = canAccessNavRoute(Screen.BackupRestore.route, permissions, isManager),
                                    navController = navController
                                ) {
                                    BackupRestoreScreen(
                                        database = database,
                                        repository = repository,
                                        onNavigateBack = { navController.popBackStack() }
                                    )
                                }
                            }
                        }
                    }
                    }
}

@Composable
private fun AuthorizedRouteGuard(
    isAuthenticated: Boolean,
    hasPermission: Boolean,
    navController: androidx.navigation.NavHostController,
    content: @Composable () -> Unit
) {
    val licenseStatus by LicenseManager.licenseStatusFlow.collectAsStateWithLifecycle()
    val isLicensed = licenseStatus is LicenseStatus.Valid
    if (isLicensed && isAuthenticated && hasPermission) {
        content()
    } else {
        val targetRoute = when {
            !isLicensed -> Screen.LicenseActivation.route
            isAuthenticated -> Screen.Dashboard.route
            else -> Screen.Login.route
        }
        LaunchedEffect(isLicensed, isAuthenticated, hasPermission, targetRoute) {
            try {
                if (navController.currentDestination != null) {
                    navController.navigate(targetRoute) {
                        if (!isLicensed || !isAuthenticated) {
                            popUpTo(0) { inclusive = true }
                        } else {
                            popUpTo(navController.graph.findStartDestination().id) { inclusive = false }
                        }
                        launchSingleTop = true
                    }
                }
            } catch (_: Throwable) {
            }
        }
    }
}
