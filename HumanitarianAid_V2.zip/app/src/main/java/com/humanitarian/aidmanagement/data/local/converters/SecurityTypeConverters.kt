package com.humanitarian.aidmanagement.data.local.converters

import androidx.room.TypeConverter
import org.json.JSONArray

/**
 * محولات أنواع أمنية لقاعدة بيانات Room لتخزين واسترجاع قوائم الصلاحيات والنطاقات الجغرافية بصيغة JSON آمنة
 */
class SecurityTypeConverters {

    @TypeConverter
    fun fromStringList(list: List<String>?): String {
        if (list.isNullOrEmpty()) return "[]"
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        return arr.toString()
    }

    @TypeConverter
    fun toStringList(data: String?): List<String> {
        if (data.isNullOrBlank() || data == "[]") return emptyList()
        return try {
            val arr = JSONArray(data)
            val list = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                list.add(arr.getString(i))
            }
            list
        } catch (_: Exception) {
            data.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        }
    }
}
