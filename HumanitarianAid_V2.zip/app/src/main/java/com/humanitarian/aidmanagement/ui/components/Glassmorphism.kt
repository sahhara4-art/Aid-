package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.ui.theme.*

/**
 * دالة Modifier.glassEffect لإضفاء تأثير الزجاج العاكس (Glassmorphism)
 * تعتمد على تدرج لوني نصف شفاف، حدود رفيعة عاكسة (0.5dp Stroke)، وظل ناعم
 * متوافقة 100% مع كافة إصدارات أندرويد دون الحاجة لتأثيرات RenderEffect المعقدة
 */
fun Modifier.glassEffect(
    shape: Shape = RoundedCornerShape(16.dp),
    surfaceColor: Color = GlassSurfaceLight,
    borderColor: Color = GlassBorderLight,
    borderWidth: Dp = 0.5.dp,
    elevation: Dp = 3.dp,
    ambientColor: Color = Color(0x0D000000),
    spotColor: Color = Color(0x1A000000)
): Modifier = this
    .shadow(
        elevation = elevation,
        shape = shape,
        clip = false,
        ambientColor = ambientColor,
        spotColor = spotColor
    )
    .clip(shape)
    .background(
        brush = Brush.verticalGradient(
            colors = listOf(
                surfaceColor,
                surfaceColor.copy(alpha = (surfaceColor.alpha * 0.88f).coerceIn(0f, 1f))
            )
        )
    )
    .border(
        width = borderWidth,
        brush = Brush.verticalGradient(
            colors = listOf(
                borderColor,
                borderColor.copy(alpha = 0.25f)
            )
        ),
        shape = shape
    )

/**
 * مكوّن GlassCard: بديل متطور وعصري لـ Card التقليدي
 * يحافظ على نفس المعاملات ولا يكسر أي كود قائم
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(16.dp),
    elevation: Dp = 3.dp,
    surfaceColor: Color = GlassSurfaceLight,
    borderColor: Color = GlassBorderLight,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val clickableModifier = if (onClick != null) {
        Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = rememberRipple(),
            onClick = onClick
        )
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .glassEffect(
                shape = shape,
                surfaceColor = surfaceColor,
                borderColor = borderColor,
                elevation = elevation
            )
            .then(clickableModifier)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            content = content
        )
    }
}

/**
 * مكوّن GlassButton: زر بتأثير زجاجي أنيق مع دعم الأيقونات المعبرة والتدرجات
 */
@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(12.dp),
    containerColor: Color = PalestineGreen,
    contentColor: Color = Color.White,
    icon: ImageVector? = null,
    contentPadding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
    content: @Composable RowScope.() -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = containerColor.copy(alpha = 0.35f),
            disabledContentColor = contentColor.copy(alpha = 0.5f)
        ),
        contentPadding = contentPadding,
        modifier = modifier
            .shadow(
                elevation = if (enabled) 3.dp else 0.dp,
                shape = shape,
                ambientColor = containerColor.copy(alpha = 0.2f),
                spotColor = containerColor.copy(alpha = 0.35f)
            )
            .border(
                width = 0.5.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (enabled) 0.6f else 0.2f),
                        Color.White.copy(alpha = 0.1f)
                    )
                ),
                shape = shape
            )
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        content()
    }
}

/**
 * شارة حالة زجاجية مع أيقونة دلالية معبرة
 * تدعم كافة حالات المنظومة: مرشح، مرحل، معتمد، مستلم، تم التراجع، وغيرها
 */
@Composable
fun GlassStatusBadge(
    status: String,
    modifier: Modifier = Modifier,
    customIcon: ImageVector? = null
) {
    val cleanStatus = status.trim()

    val (bgColor, textColor, borderColor, icon) = when {
        cleanStatus.contains("مستلم") || cleanStatus.contains("تم التسليم") || cleanStatus.contains("مستفيد") -> {
            Quad(StatusDeliveredBg, StatusDelivered, StatusDeliveredBorder, Icons.Default.CheckCircle)
        }
        cleanStatus.contains("مرحل") || cleanStatus.contains("معتمد للترحيل") || cleanStatus.contains("معتمد") -> {
            Quad(StatusMigratedBg, StatusMigrated, StatusMigratedBorder, Icons.Default.Verified)
        }
        cleanStatus.contains("مرشح") || cleanStatus.contains("ترشيح") -> {
            Quad(StatusNominatedBg, StatusNominated, StatusNominatedBorder, Icons.Default.HourglassTop)
        }
        cleanStatus.contains("تراجع") || cleanStatus.contains("موقوف") -> {
            Quad(StatusWarningBg, StatusWarning, StatusWarningBorder, Icons.Default.Undo)
        }
        cleanStatus.contains("مستبعد") || cleanStatus.contains("غير مستحق") || cleanStatus.contains("رفض") -> {
            Quad(StatusErrorBg, StatusError, StatusErrorBorder, Icons.Default.Cancel)
        }
        else -> {
            Quad(StatusInfoBg, StatusInfo, StatusInfoBorder, Icons.Default.Info)
        }
    }

    val displayIcon = customIcon ?: icon

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        border = BorderStroke(0.5.dp, borderColor),
        modifier = modifier
            .shadow(
                elevation = 1.dp,
                shape = RoundedCornerShape(8.dp),
                ambientColor = borderColor.copy(alpha = 0.2f),
                spotColor = borderColor.copy(alpha = 0.3f)
            )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = displayIcon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = cleanStatus,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = textColor,
                fontSize = 11.sp
            )
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
