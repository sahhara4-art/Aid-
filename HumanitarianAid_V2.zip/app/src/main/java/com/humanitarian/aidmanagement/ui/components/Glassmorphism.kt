package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.ui.theme.*

/**
 * دالة Modifier.glassEffect لإضفاء تأثير الزجاج العاكس (Glassmorphism)
 * تعتمد على تدرج لوني نصف شفاف، حدود رفيعة عاكسة (0.5dp Stroke)، وظل ناعم
 * متوافقة 100% مع كافة إصدارات أندرويد دون الحاجة لتأثيرات RenderEffect المعقدة
 */
fun Modifier.glassEffect(
    shape: Shape = RoundedCornerShape(20.dp),
    surfaceColor: Color = Color.White.copy(alpha = 0.88f),
    borderColor: Color = Color(0xFFD6E8DF),
    borderWidth: Dp = 1.dp,
    elevation: Dp = 0.dp,
    ambientColor: Color = Color.Transparent,
    spotColor: Color = Color.Transparent
): Modifier = this
    .clip(shape)
    .background(surfaceColor)
    .border(
        width = borderWidth,
        color = borderColor,
        shape = shape
    )

/**
 * مكوّن GlassCard: بطاقة زجاجية نقية خالية من أي ظلال رمادية (Zero Shadow Artifact)
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    elevation: Dp = 0.dp,
    surfaceColor: Color = Color.White.copy(alpha = 0.88f),
    borderColor: Color = Color(0xFFD6E8DF),
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val clickableModifier = if (onClick != null) {
        Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = rememberRipple(),
            onClick = onClick
        )
    } else {
        Modifier
    }

    Surface(
        modifier = modifier.then(clickableModifier),
        shape = shape,
        color = surfaceColor,
        border = BorderStroke(1.dp, borderColor),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            content = content
        )
    }
}

/**
 * مكوّن GlassButton: زر بتأثير زجاجي أنيق مع دعم الأيقونات المعبرة والتدرجات
 */
@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    shape: Shape = RoundedCornerShape(12.dp),
    containerColor: Color = PalestineGreen,
    contentColor: Color = Color.White,
    icon: ImageVector? = null,
    contentPadding: PaddingValues = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
    content: @Composable RowScope.() -> Unit
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = shape,
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 0.dp,
            pressedElevation = 0.dp,
            disabledElevation = 0.dp
        ),
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor,
            disabledContainerColor = containerColor.copy(alpha = 0.35f),
            disabledContentColor = contentColor.copy(alpha = 0.5f)
        ),
        contentPadding = contentPadding,
        modifier = modifier
            .border(
                width = 0.5.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = if (enabled) 0.5f else 0.2f),
                        Color.White.copy(alpha = 0.1f)
                    )
                ),
                shape = shape
            )
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        content()
    }
}

/**
 * شارة حالة زجاجية مع أيقونة دلالية معبرة
 * تدعم كافة حالات المنظومة: مرشح، مرحل، معتمد، مستلم، تم التراجع، وغيرها
 */
@Composable
fun GlassStatusBadge(
    status: String,
    modifier: Modifier = Modifier,
    customIcon: ImageVector? = null
) {
    val cleanStatus = status.trim()

    val (bgColor, textColor, borderColor, icon) = when {
        cleanStatus.contains("مستلم") || cleanStatus.contains("تم التسليم") || cleanStatus.contains("مستفيد") -> {
            Quad(StatusDeliveredBg, StatusDelivered, StatusDeliveredBorder, Icons.Default.CheckCircle)
        }
        cleanStatus.contains("مرحل") || cleanStatus.contains("معتمد للترحيل") || cleanStatus.contains("معتمد") -> {
            Quad(StatusMigratedBg, StatusMigrated, StatusMigratedBorder, Icons.Default.Verified)
        }
        cleanStatus.contains("مرشح") || cleanStatus.contains("ترشيح") -> {
            Quad(StatusNominatedBg, StatusNominated, StatusNominatedBorder, Icons.Default.HourglassTop)
        }
        cleanStatus.contains("تراجع") || cleanStatus.contains("موقوف") -> {
            Quad(StatusWarningBg, StatusWarning, StatusWarningBorder, Icons.Default.Undo)
        }
        cleanStatus.contains("مستبعد") || cleanStatus.contains("غير مستحق") || cleanStatus.contains("رفض") -> {
            Quad(StatusErrorBg, StatusError, StatusErrorBorder, Icons.Default.Cancel)
        }
        else -> {
            Quad(StatusInfoBg, StatusInfo, StatusInfoBorder, Icons.Default.Info)
        }
    }

    val displayIcon = customIcon ?: icon

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        border = BorderStroke(0.5.dp, borderColor),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = displayIcon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(13.dp)
            )
            Text(
                text = cleanStatus,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = textColor,
                fontSize = 11.sp
            )
        }
    }
}

private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
