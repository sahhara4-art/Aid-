package com.humanitarian.aidmanagement.util

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.*
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.InputStream
import java.io.OutputStream
import com.humanitarian.aidmanagement.data.repository.AidRepository

object ExcelParserHelper {
    /**
     * العناوين القياسية الخاصة ببيانات الأسر FamilyEntity (36 حقلاً بالإضافة لـ "المحلية المعتمدة")
     */
    val FAMILY_TEMPLATE_HEADERS = listOf(
        "رقم الهوية الوطنية",
        "اسم المستفيد الرباعي",
        "الجنس",
        "تاريخ الميلاد",
        "العمر",
        "الحالة الاجتماعية",
        "حالة الوفاة",
        "تاريخ الوفاة",
        "رقم الجوال للتواصل",
        "رقم جوال بديل 1",
        "رقم جوال بديل 2",
        "اسم الزوج/الزوجة",
        "رقم هوية الزوج/الزوجة",
        "عدد أفراد الأسرة",
        "حالة الضرر",
        "وصف أضرار المنزل",
        "حالة الإصابة",
        "تاريخ الإصابة",
        "مصدر الدخل الأول",
        "مصدر الدخل الثاني",
        "رقم كرت المؤن / الوكالة",
        "المنطقة الرئيسية الأصلية",
        "المنطقة الفرعية الأصلية",
        "الشعبة الأصلية",
        "المسجد الأصلي",
        "المنطقة الرئيسية الحالية",
        "المنطقة الفرعية الحالية",
        "الشعبة الحالية",
        "المسجد الحالي",
        "حالة الاعتماد",
        "اعتماد المناطق والمحليات",
        "صفة الإقامة (مقيم / نازح)",
        "اعتماد وزارة الأشغال",
        "حالة الإيواء",
        "اسم المخيم أو مركز الإيواء",
        "ملاحظات ميدانية",
        "المحلية المعتمدة"
    )

    /**
     * العناوين القياسية الخاصة ببيانات الأبناء والتابعين ChildEntity
     */
    val CHILDREN_TEMPLATE_HEADERS = listOf(
        "رقم هوية الطفل",
        "اسم الطفل الرباعي",
        "تاريخ الميلاد",
        "الجنس",
        "رقم هوية رب الأسرة",
        "رقم المحلية",
        "حالة الإيواء"
    )

    /**
     * العناوين القياسية الخاصة بسجلات المساعدات AidRecordEntity
     */
    val AID_RECORDS_TEMPLATE_HEADERS = listOf(
        "رقم هوية الأسرة",
        "تصنيف المساعدة",
        "نوع المساعدة",
        "رقم المشروع",
        "اسم المشروع",
        "تاريخ المساعدة",
        "تاريخ الترشيح",
        "حالة الاستلام",
        "تاريخ التسليم الفعلي",
        "اسم المستلم الفعلي",
        "المستودع",
        "قيمة المساعدة",
        "ملاحظات"
    )

    /**
     * استخراج ترويسة ملف الإكسل (Headers) بسرعة البرق من أول صف غير فارغ فقط
     * دون قراءة أي صفوف تالية، وإغلاق المصنف فوراً لتفادي استهلاك الذاكرة (OOM)
     */
    fun readHeadersOnly(inputStream: InputStream): List<String> {
        val headers = mutableListOf<String>()
        var workbook: Workbook? = null
        try {
            workbook = WorkbookFactory.create(inputStream)
            val sheet = workbook.getSheetAt(0) ?: return emptyList()
            val formatter = DataFormatter()

            val maxScan = sheet.lastRowNum.coerceAtMost(20)
            for (i in 0..maxScan) {
                val row = sheet.getRow(i) ?: continue
                val rowHeaders = mutableListOf<String>()
                var hasAnyContent = false
                for (cell in row) {
                    val value = formatter.formatCellValue(cell).trim()
                    if (value.isNotBlank()) {
                        hasAnyContent = true
                    }
                    rowHeaders.add(value)
                }
                if (hasAnyContent) {
                    headers.addAll(rowHeaders)
                    break
                }
            }
        } catch (e: Exception) {
            Log.e("ExcelParserHelper", "Error reading headers only: ${e.message}", e)
        } finally {
            try {
                workbook?.close()
            } catch (closeEx: Exception) {
                Log.e("ExcelParserHelper", "Failed to close workbook: ${closeEx.message}", closeEx)
            }
        }
        return headers
    }

    /**
     * قراءة عينة محدودة (Sample Data) بسرعة البرق لشاشة مطابقة الحقول (3 إلى 5 صفوف كحد أقصى)
     * مع الترويسة، دون تحميل الملف الضخم كاملاً في الذاكرة
     */
    fun readSampleRows(inputStream: InputStream, maxRows: Int = 5): Pair<List<String>, List<Map<String, String>>> {
        val headers = mutableListOf<String>()
        val sampleRows = mutableListOf<Map<String, String>>()
        var workbook: Workbook? = null
        try {
            workbook = WorkbookFactory.create(inputStream)
            val sheet = workbook.getSheetAt(0) ?: return Pair(emptyList(), emptyList())
            val formatter = DataFormatter()

            var headerRowIndex = -1
            val maxScan = sheet.lastRowNum.coerceAtMost(20)
            for (i in 0..maxScan) {
                val row = sheet.getRow(i) ?: continue
                val rowHeaders = mutableListOf<String>()
                var hasAnyContent = false
                for (cell in row) {
                    val value = formatter.formatCellValue(cell).trim()
                    if (value.isNotBlank()) {
                        hasAnyContent = true
                    }
                    rowHeaders.add(value)
                }
                if (hasAnyContent) {
                    headers.addAll(rowHeaders)
                    headerRowIndex = i
                    break
                }
            }

            if (headerRowIndex != -1 && headers.isNotEmpty()) {
                var count = 0
                val startRow = headerRowIndex + 1
                val endRow = sheet.lastRowNum
                for (i in startRow..endRow) {
                    if (count >= maxRows) break
                    try {
                        val row = sheet.getRow(i) ?: continue
                        val rowData = mutableMapOf<String, String>()
                        var hasData = false
                        for (j in headers.indices) {
                            val cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
                            val value = formatter.formatCellValue(cell).trim()
                            if (value.isNotBlank()) hasData = true
                            rowData[headers[j]] = value
                        }
                        if (hasData) {
                            sampleRows.add(rowData)
                            count++
                        }
                    } catch (rowEx: Exception) {
                        Log.w("ExcelParserHelper", "Skipping sample row $i: ${rowEx.message}")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("ExcelParserHelper", "Error reading sample rows: ${e.message}", e)
        } finally {
            try {
                workbook?.close()
            } catch (closeEx: Exception) {
                Log.e("ExcelParserHelper", "Failed to close workbook: ${closeEx.message}", closeEx)
            }
        }
        return Pair(headers, sampleRows)
    }

    /**
     * قراءة وتفكيك أي ملف إكسل وتحويله إلى قائمة صفوف كخرائط مفتاح-قيمة
     * مع تطبيق حماية شاملة من الانهيار (try-catch داخلي لكل صف) وقراءة الخلايا عبر DataFormatter
     */
    fun parseExcelFile(
        inputStream: InputStream,
        maxRows: Int? = null,
        onProgress: ((current: Int, total: Int) -> Unit)? = null,
        aidTypeColumnIndex: Int? = null
    ): List<Map<String, String>> {
        val parsedData = mutableListOf<Map<String, String>>()
        var workbook: Workbook? = null
        try {
            workbook = WorkbookFactory.create(inputStream)
            val sheet = workbook.getSheetAt(0) ?: return emptyList()
            val formatter = DataFormatter()

            var headerRowIndex = -1
            val headers = mutableListOf<String>()
            val maxScan = sheet.lastRowNum.coerceAtMost(20)
            for (i in 0..maxScan) {
                val row = sheet.getRow(i) ?: continue
                val rowHeaders = mutableListOf<String>()
                var hasAnyContent = false
                for (cell in row) {
                    val value = formatter.formatCellValue(cell).trim()
                    if (value.isNotBlank()) hasAnyContent = true
                    rowHeaders.add(value)
                }
                if (hasAnyContent) {
                    headers.addAll(rowHeaders)
                    headerRowIndex = i
                    break
                }
            }

            if (headerRowIndex == -1 || headers.isEmpty()) {
                return emptyList()
            }

            val totalRows = (sheet.lastRowNum - headerRowIndex).coerceAtLeast(1)
            var count = 0

            for (i in (headerRowIndex + 1)..sheet.lastRowNum) {
                if (maxRows != null && count >= maxRows) break
                try {
                    val row = sheet.getRow(i) ?: continue
                    val rowData = mutableMapOf<String, String>()
                    var hasAnyData = false
                    for (j in headers.indices) {
                        val cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
                        val value = formatter.formatCellValue(cell).trim()
                        if (value.isNotBlank()) hasAnyData = true
                        rowData[headers[j]] = value
                    }

                    // استخراج قيمة "نوع المساعدة" بأمان إذا كان aidTypeColumnIndex ليس null لتجنب انهيار التطبيق (Crash)
                    if (aidTypeColumnIndex != null) {
                        val aidTypeValue = try {
                            val cell = row.getCell(aidTypeColumnIndex, Row.MissingCellPolicy.RETURN_BLANK_AS_NULL)
                            if (cell != null) {
                                formatter.formatCellValue(cell).trim().ifBlank { "غير محدد" }
                            } else {
                                "غير محدد"
                            }
                        } catch (cellEx: Exception) {
                            "غير محدد"
                        }
                        rowData["aidType"] = aidTypeValue
                        rowData["aidTypeName"] = aidTypeValue
                    }

                    if (hasAnyData) {
                        parsedData.add(rowData)
                        count++
                    }
                } catch (rowEx: Exception) {
                    Log.w("ExcelParserHelper", "Skipping corrupted row at line $i: ${rowEx.message}")
                }

                if (count % 1000 == 0 && onProgress != null) {
                    onProgress(count, totalRows)
                }
            }
        } catch (e: Exception) {
            Log.e("ExcelParserHelper", "Fatal error in parseExcelFile: ${e.message}", e)
        } finally {
            try {
                workbook?.close()
            } catch (closeEx: Exception) {
                Log.e("ExcelParserHelper", "Failed to close workbook: ${closeEx.message}", closeEx)
            }
        }
        return parsedData
    }

    suspend fun parseExcelFileAsync(
        inputStream: InputStream,
        maxRows: Int? = null,
        onProgress: ((current: Int, total: Int) -> Unit)? = null,
        aidTypeColumnIndex: Int? = null
    ): List<Map<String, String>> = withContext(Dispatchers.IO) {
        parseExcelFile(inputStream, maxRows, onProgress, aidTypeColumnIndex)
    }

    suspend fun readHeadersOnlyAsync(inputStream: InputStream): List<String> = withContext(Dispatchers.IO) {
        readHeadersOnly(inputStream)
    }

    suspend fun readSampleRowsAsync(inputStream: InputStream, maxRows: Int = 5): Pair<List<String>, List<Map<String, String>>> = withContext(Dispatchers.IO) {
        readSampleRows(inputStream, maxRows)
    }

    /**
     * استيراد وتفكيك ملف إكسل الخاص بالأبناء
     */
    fun parseChildrenExcelFile(inputStream: InputStream): List<Map<String, String>> {
        return parseExcelFile(inputStream)
    }

    /**
     * استيراد وتفكيك ملف إكسل الخاص بسجلات المساعدات مع دعم المعامل الجديد aidTypeColumnIndex
     */
    fun parseAidRecordsExcelFile(
        inputStream: InputStream,
        aidTypeColumnIndex: Int? = null,
        maxRows: Int? = null,
        onProgress: ((current: Int, total: Int) -> Unit)? = null
    ): List<Map<String, String>> {
        return parseExcelFile(
            inputStream = inputStream,
            maxRows = maxRows,
            onProgress = onProgress,
            aidTypeColumnIndex = aidTypeColumnIndex
        )
    }

    /**
     * دالة استيراد وتخزين سجلات المساعدات في قاعدة البيانات (تم الإبقاء عليها بالكامل للتوافق)
     */
    suspend fun importAidRecordsFromExcel(
        inputStream: InputStream,
        repository: AidRepository,
        aidTypeColumnIndex: Int? = null,
        nationalIdColumnIndex: Int? = null,
        onProgress: ((progress: Float, current: Int, total: Int) -> Unit)? = null
    ): AidRepository.BatchImportResult = withContext(Dispatchers.IO) {
        importAidRecordsFromExcelV2(
            inputStream = inputStream,
            repository = repository,
            aidTypeColumnIndex = aidTypeColumnIndex,
            nationalIdColumnIndex = nationalIdColumnIndex,
            defaultAssistanceType = "عينية",
            onProgress = onProgress
        )
    }

    /**
     * V2: الدالة الجديدة الموسعة لاستيراد سجلات المساعدات مع دعم المشاريع الديناميكية ونوع المساعدة
     */
    suspend fun importAidRecordsFromExcelV2(
        inputStream: InputStream,
        repository: AidRepository,
        aidTypeColumnIndex: Int? = null,
        nationalIdColumnIndex: Int? = null,
        projectNumberColumnIndex: Int? = null,
        projectNameColumnIndex: Int? = null,
        assistanceTypeColumnIndex: Int? = null,
        defaultAssistanceType: String? = "عينية",
        onProgress: ((progress: Float, current: Int, total: Int) -> Unit)? = null
    ): AidRepository.BatchImportResult = withContext(Dispatchers.IO) {
        val rows = parseExcelFile(inputStream, aidTypeColumnIndex = aidTypeColumnIndex)
        val importItems = rows.mapNotNull { r ->
            val keys = r.keys.toList()
            val rawAidCategory = if (aidTypeColumnIndex != null && aidTypeColumnIndex in keys.indices) {
                (r[keys[aidTypeColumnIndex]] ?: "").trim().ifBlank { "غير محدد" }
            } else {
                (r["aidTypeName"] ?: r["aidType"] ?: r["تصنيف المساعدة"] ?: "").trim().ifBlank { "غير محدد" }
            }

            val rawNatId = if (nationalIdColumnIndex != null && nationalIdColumnIndex in keys.indices) {
                normalizeNationalId(r[keys[nationalIdColumnIndex]])
            } else {
                normalizeNationalId(r["familyNationalID"] ?: r["nationalID"] ?: r["هوية"] ?: r["رقم الهوية"])
            }

            val rawProjectNumber = if (projectNumberColumnIndex != null && projectNumberColumnIndex in keys.indices) {
                r[keys[projectNumberColumnIndex]]?.trim() ?: ""
            } else {
                (r["projectNumber"] ?: r["رقم المشروع"] ?: r["كود المشروع"] ?: "").trim()
            }

            val rawProjectName = if (projectNameColumnIndex != null && projectNameColumnIndex in keys.indices) {
                r[keys[projectNameColumnIndex]]?.trim() ?: ""
            } else {
                (r["projectName"] ?: r["اسم المشروع"] ?: "مشروع الإغاثة الإنسانية").trim().ifBlank { "مشروع الإغاثة الإنسانية" }
            }

            val rawAssistanceType = if (assistanceTypeColumnIndex != null && assistanceTypeColumnIndex in keys.indices) {
                r[keys[assistanceTypeColumnIndex]]?.trim()?.ifBlank { null }
            } else {
                (r["assistanceType"] ?: r["نوع المساعدة"] ?: "").trim().ifBlank { null }
            } ?: defaultAssistanceType ?: "عينية"

            if (rawNatId.isNotBlank()) {
                AidRepository.AidRecordImportItem(
                    familyNationalID = rawNatId,
                    aidTypeName = rawAidCategory,
                    assistanceType = rawAssistanceType,
                    projectNumber = rawProjectNumber.ifBlank { null },
                    // projectID = 1L // تم إيقاف التعيين الثابت تلبية للتعليمات الصارمة، وسيتم توليده واستخراجه ديناميكياً
                    projectName = rawProjectName,
                    aidDate = (r["aidDate"] ?: r["date"] ?: "2026-10-14").ifBlank { "2026-10-14" },
                    recipientStatus = (r["recipientStatus"] ?: r["status"] ?: "مستلم").ifBlank { "مستلم" }
                )
            } else null
        }
        repository.importAidRecordsImportItemsBatchV2(
            items = importItems,
            defaultAssistanceType = defaultAssistanceType
        ) { pct: Float, cur: Int, tot: Int ->
            onProgress?.invoke(pct, cur, tot)
        }
    }

    /**
     * توليد قالب إكسل رسمي (.xlsx) للأسر
     */
    fun generateFamilyTemplate(outputStream: OutputStream) {
        generateWorkbookWithHeaders("قالب_استيراد_الأسر", FAMILY_TEMPLATE_HEADERS, IndexedColors.SEA_GREEN.index, outputStream)
    }

    /**
     * توليد قالب إكسل رسمي (.xlsx) للأبناء
     */
    fun generateChildrenTemplate(outputStream: OutputStream) {
        generateWorkbookWithHeaders("قالب_استيراد_الأبناء", CHILDREN_TEMPLATE_HEADERS, IndexedColors.ROYAL_BLUE.index, outputStream)
    }

    /**
     * توليد قالب إكسل رسمي (.xlsx) لسجلات المساعدات
     */
    fun generateAidRecordsTemplate(outputStream: OutputStream) {
        generateWorkbookWithHeaders("قالب_سجلات_المساعدات", AID_RECORDS_TEMPLATE_HEADERS, IndexedColors.DARK_TEAL.index, outputStream)
    }

    private fun generateWorkbookWithHeaders(
        sheetTitle: String,
        headers: List<String>,
        headerColorIndex: Short,
        outputStream: OutputStream
    ) {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet(sheetTitle)
        sheet.isRightToLeft = true

        val headerRow = sheet.createRow(0)

        val headerFont = workbook.createFont().apply {
            bold = true
            color = IndexedColors.WHITE.index
            fontHeightInPoints = 11.toShort()
        }

        val headerStyle = workbook.createCellStyle().apply {
            setFont(headerFont)
            fillForegroundColor = headerColorIndex
            fillPattern = FillPatternType.SOLID_FOREGROUND
            alignment = HorizontalAlignment.CENTER
            verticalAlignment = VerticalAlignment.CENTER
        }

        for (i in headers.indices) {
            val cell = headerRow.createCell(i)
            cell.setCellValue(headers[i])
            cell.cellStyle = headerStyle
            sheet.setColumnWidth(i, 22 * 256)
        }

        workbook.write(outputStream)
        workbook.close()
    }

    /**
     * توحيد صيغة أرقام الهوية (حل مشكلة الأرقام بالعربي والإنجليزي):
     * تحويل الأرقام المشرقية (٠,١,٢,٣,٤,٥,٦,٧,٨,٩) إلى أرقام إنجليزية (0,1,2,3,4,5,6,7,8,9)
     * وإزالة الفراغات والرموز الزائدة لمنع تكرار السجلات
     */
    fun normalizeNationalId(id: String?): String {
        if (id.isNullOrBlank()) return ""
        val easternDigits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
        val englishDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
        var res = id.trim().replace(".0", "").replace(" ", "")
        for (i in 0..9) {
            res = res.replace(easternDigits[i], englishDigits[i])
        }
        return res.filter { it in '0'..'9' }.trim()
    }

    /**
     * تحويل عام للأرقام المشرقية إلى إنجليزية مع إزالة الفراغات الزائدة
     */
    fun convertEasternToArabicDigits(text: String?): String {
        if (text.isNullOrBlank()) return ""
        val easternDigits = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
        val englishDigits = charArrayOf('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
        var res = text.trim()
        for (i in 0..9) {
            res = res.replace(easternDigits[i], englishDigits[i])
        }
        return res
    }

    /**
     * تنظيف وتوحيد النصوص العربية لإزالة التشكيل والتطويل وتوحيد الهمزات والتاء المربوطة
     */
    fun normalizeArabic(text: String): String {
        return text.trim()
            .replace("[\u064B-\u065F\u0670]".toRegex(), "") // إزالة التشكيل والفتحات والضمات
            .replace("\u0640".toRegex(), "") // إزالة التطويل (الكشيدة)
            .replace("أ", "ا")
            .replace("إ", "ا")
            .replace("آ", "ا")
            .replace("ٱ", "ا")
            .replace("ة", "ه")
            .replace("ى", "ي")
            .replace("  +", " ")
            .lowercase()
    }

    /**
     * خوارزمية مطابقة المحليات الصارمة (Strict Locality Resolution):
     * 1. فحص إذا كان الحقل رقماً (ID) مطابقاً.
     * 2. إذا كان نصاً، إجراء مطابقة صارمة (when/Map) لربط الأسماء بأرقامها الحقيقية.
     * 3. إزالة أي قيمة افتراضية صامتة (Zero Silent Fallback).
     * 4. إذا كانت المحلية مجهولة تماماً، يتم تسجيلها كخطأ لرفضها أو تخطيها.
     */
    fun resolveLocalityStrict(
        rawInput: String?,
        knownLocalities: List<Pair<Int, String>> = listOf(
            1 to "الرمال الشمالي",
            2 to "الشيخ رضوان",
            3 to "الشاطئ الشمالي والنصر",
            4 to "الشاطئ الجنوبي",
            5 to "مشروع عامر"
        )
    ): LocalityResolutionResult {
        val raw = rawInput?.trim() ?: ""
        if (raw.isBlank()) {
            return LocalityResolutionResult(
                localityId = null,
                localityName = null,
                isExactMatch = false,
                isError = true,
                errorMessage = "حقل المحلية فارغ"
            )
        }

        // 1. فحص إذا كان الحقل رقماً (ID صريح)
        val cleanNumeric = raw.replace(".0", "").replace(" ", "").trim()
        val numericId = cleanNumeric.toIntOrNull()
        if (numericId != null && numericId > 0) {
            val matchedKnown = knownLocalities.firstOrNull { it.first == numericId }
            return if (matchedKnown != null) {
                LocalityResolutionResult(
                    localityId = matchedKnown.first,
                    localityName = matchedKnown.second,
                    isExactMatch = true,
                    isError = false
                )
            } else {
                LocalityResolutionResult(
                    localityId = numericId,
                    localityName = "محلية رقم $numericId",
                    isExactMatch = true,
                    isError = false
                )
            }
        }

        // 2. إذا كان نصاً، تنفيذ المطابقة الصارمة عبر when لربط كافة الأسماء الشائعة بأرقامها الحقيقية
        val norm = normalizeArabic(raw)
            .replace("محليه", "")
            .replace("محلية", "")
            .replace("حي", "")
            .replace("منطقه", "")
            .replace("منطقة", "")
            .replace("بلديه", "")
            .replace("بلدية", "")
            .trim()

        val mappedId: Int? = when {
            // 1: الرمال الشمالي
            norm == "الرمال الشمالي" || norm == "الرمال الشماليه" ||
            norm == "رمال شمالي" || norm == "الرمال شمالي" ||
            norm == "شمال الرمال" || norm == "شمالي" ||
            norm.contains("شمال الرمال") || (norm.contains("الرمال") && norm.contains("شمال")) -> 1

            // 2: الشيخ رضوان
            norm == "الشيخ رضوان" || norm == "شيخ رضوان" ||
            norm.contains("الشيخ رضوان") || norm.contains("شيخ رضوان") ||
            norm.contains("الامن العام") -> 2

            // 3: الشاطئ الشمالي والنصر
            norm == "الشاطئ الشمالي والنصر" || norm == "الشاطي الشمالي والنصر" ||
            norm == "الشاطئ الشمالي" || norm == "الشاطي الشمالي" ||
            norm == "النصر" || norm == "النصر والشاطئ" ||
            norm.contains("شاطئ شمالي") || norm.contains("شاطي شمالي") ||
            (norm.contains("نصر") && norm.contains("شاط")) ||
            norm == "النصر والعودة" -> 3

            // 4: الشاطئ الجنوبي
            norm == "الشاطئ الجنوبي" || norm == "الشاطي الجنوبي" ||
            norm == "مخيم الشاطئ" || norm == "مخيم الشاطي" ||
            norm == "الشاطئ" || norm == "الشاطي" ||
            norm.contains("شاطئ جنوبي") || norm.contains("شاطي جنوبي") ||
            norm.contains("مخيم الشاط") -> 4

            // 5: مشروع عامر
            norm == "مشروع عامر" || norm == "عامر" ||
            norm.contains("مشروع عامر") || norm.contains("بيت لاهيا عامر") ||
            norm.contains("عباد الرحمن") -> 5

            else -> null
        }

        if (mappedId != null) {
            val matchedName = knownLocalities.firstOrNull { it.first == mappedId }?.second ?: "محلية $mappedId"
            return LocalityResolutionResult(
                localityId = mappedId,
                localityName = matchedName,
                isExactMatch = true,
                isError = false
            )
        }

        // 3. فحص بقية المحليات المسجلة ديناميكياً في النظام
        for (loc in knownLocalities) {
            val locNorm = normalizeArabic(loc.second)
            if (norm == locNorm || (norm.length >= 4 && (norm.contains(locNorm) || locNorm.contains(norm)))) {
                return LocalityResolutionResult(
                    localityId = loc.first,
                    localityName = loc.second,
                    isExactMatch = false,
                    isError = false
                )
            }
        }

        // 4. لا يوجد مطابقة: حظر أي Fallback صامت (رفض التوجيه العشوائي للمحلية 1)
        return LocalityResolutionResult(
            localityId = null,
            localityName = null,
            isExactMatch = false,
            isError = true,
            errorMessage = "المحلية غير معروفة: '$raw'"
        )
    }
}

/**
 * نتيجة فحص ومطابقة رقم واسم المحلية
 */
data class LocalityResolutionResult(
    val localityId: Int?,
    val localityName: String?,
    val isExactMatch: Boolean,
    val isError: Boolean,
    val errorMessage: String? = null
)

