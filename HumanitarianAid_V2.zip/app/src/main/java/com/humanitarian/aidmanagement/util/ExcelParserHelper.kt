package com.humanitarian.aidmanagement.util

import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.ss.usermodel.WorkbookFactory
import java.io.InputStream

object ExcelParserHelper {
    fun parseExcelFile(inputStream: InputStream): List<Map<String, String>> {
        val parsedData = mutableListOf<Map<String, String>>()
        try {
            val workbook = WorkbookFactory.create(inputStream)
            val sheet = workbook.getSheetAt(0)
            val headerRow = sheet.getRow(0) ?: return emptyList()
            val headers = mutableListOf<String>()
            val formatter = DataFormatter()
            
            for (cell in headerRow) {
                headers.add(formatter.formatCellValue(cell).trim())
            }

            for (i in 1..sheet.lastRowNum) {
                val row = sheet.getRow(i) ?: continue
                val rowData = mutableMapOf<String, String>()
                for (j in 0 until headers.size) {
                    val cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
                    rowData[headers[j]] = formatter.formatCellValue(cell).trim()
                }
                parsedData.add(rowData)
            }
            workbook.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return parsedData
    }
}
