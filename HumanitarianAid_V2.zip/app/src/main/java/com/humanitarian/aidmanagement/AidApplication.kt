package com.humanitarian.aidmanagement

import android.app.Application
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.NominationEngine
import com.humanitarian.aidmanagement.notifications.AidNotificationChannels
import com.humanitarian.aidmanagement.notifications.NotificationScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class AidApplication : Application() {
    private val applicationScope = CoroutineScope(SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        // تهيئة قنوات الإشعارات المحلية (Local Notifications Channels)
        AidNotificationChannels.createChannels(this)
        // جدولة الفحص الدوري للمواعيد وانتهاء الاستثناء عبر WorkManager
        NotificationScheduler.schedulePeriodicCheck(this)
        // تهيئة محرك التزامن التلقائي والعمل دون اتصال (Offline-First Sync Engine)
        com.humanitarian.aidmanagement.sync.SyncManager.initialize(this, database)
    }

    val database by lazy { AidDatabase.getDatabase(this, applicationScope) }

    val nominationEngine by lazy {
        NominationEngine(
            familyDao = database.familyDao(),
            childDao = database.childDao(),
            aidRecordDao = database.aidRecordDao(),
            nominationDao = database.nominationDao(),
            localityDao = database.localityDao(),
            systemSettingDao = database.systemSettingDao()
        )
    }

    val repository by lazy {
        AidRepository(
            database = database,
            nominationEngine = nominationEngine
        )
    }
}
