package com.humanitarian.aidmanagement

import android.app.Application
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.NominationEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class AidApplication : Application() {
    val applicationScope = CoroutineScope(SupervisorJob())

    val database by lazy { AidDatabase.getDatabase(this, applicationScope) }
    val repository by lazy { AidRepository(database) }
    val nominationEngine by lazy { NominationEngine(database) }

    override fun onCreate() {
        super.onCreate()
    }
}
