package com.humanitarian.aidmanagement

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import android.os.Build
import android.os.Process
import android.util.Log
import com.humanitarian.aidmanagement.crash.GlobalCrashHandler
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.NominationEngine
import com.humanitarian.aidmanagement.notifications.AidNotificationChannels
import com.humanitarian.aidmanagement.notifications.NotificationScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

open class AidApplication : Application() {
    companion object {
        @Volatile
        private var _instance: AidApplication? = null

        var instance: AidApplication
            get() = _instance ?: synchronized(this) {
                _instance ?: AidApplication().also { _instance = it }
            }
            protected set(value) {
                _instance = value
            }

        fun getInstanceSafely(): AidApplication? = _instance
    }

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private fun isCrashReportProcess(): Boolean {
        return try {
            val processName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                Application.getProcessName()
            } else {
                val pid = Process.myPid()
                val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                am?.runningAppProcesses?.firstOrNull { it.pid == pid }?.processName
            }
            processName?.endsWith(":crash_report") == true
        } catch (_: Throwable) {
            false
        }
    }

    override fun onCreate() {
        super.onCreate()

        // في حال تشغيل عملية الصندوق الأسود المعزولة (:crash_report)، نمتنع عن تهيئة قواعد البيانات والخدمات
        if (isCrashReportProcess()) {
            return
        }

        // تفعيل الصندوق الأسود لالتقاط أي انهيار كأول سطر تنفيذي في التطبيق
        Thread.setDefaultUncaughtExceptionHandler(GlobalCrashHandler(applicationContext))

        try {
            instance = this
            _instance = this

            // 0. المعترض الحرج للإقلاع النظيف (Staged Pre-Boot Restore Interceptor):
            // استعادة ملفات قاعدة البيانات المعزولة إن وُجد علم PENDING_DB_RESTORE
            // يتم هذا الفحص حتماً وبشكل تزامني قبل أي تحميل لـ SQLCipher أو Room أو أي خدمة أخرى
            try {
                com.humanitarian.aidmanagement.data.backup.DatabaseBackupManager.performPendingRestoreIfRequired(this)
            } catch (e: Throwable) {
                Log.e("AidApplication", "Pre-Boot restore check failed: ${e.message}", e)
            }

            // 1. تحميل مكتبة تشفير SQLCipher قبل أي محاولة للوصول لقاعدة البيانات لتجنب UnsatisfiedLinkError
            try {
                System.loadLibrary("sqlcipher")
                Log.i("AidApplication", "SQLCipher native library loaded successfully.")
            } catch (e: Throwable) {
                Log.w("AidApplication", "SQLCipher System.loadLibrary warning: ${e.message}")
            }

            // 2. تهيئة قنوات الإشعارات المحلية بأمان
            try {
                AidNotificationChannels.createChannels(this)
            } catch (e: Throwable) {
                Log.e("AidApplication", "Failed to create notification channels: ${e.message}", e)
            }

            // 3. جدولة الفحص الدوري للمواعيد وانتهاء الاستثناء عبر WorkManager في الخلفية
            applicationScope.launch(Dispatchers.IO) {
                try {
                    NotificationScheduler.schedulePeriodicCheck(this@AidApplication)
                } catch (e: Throwable) {
                    Log.e("AidApplication", "Failed to schedule periodic check: ${e.message}", e)
                }
            }

            // 4. التهيئة الصريحة لـ Firebase وضبط التخزين المؤقت المحلي لـ Cloud Firestore بسقف 40MB لمنع OOM
            try {
                if (com.google.firebase.FirebaseApp.getApps(this).isEmpty()) {
                    com.google.firebase.FirebaseApp.initializeApp(this)
                }
                val cacheSettings = com.google.firebase.firestore.PersistentCacheSettings.newBuilder()
                    .setSizeBytes(40L * 1024L * 1024L)
                    .build()
                val settings = com.google.firebase.firestore.FirebaseFirestoreSettings.Builder()
                    .setLocalCacheSettings(cacheSettings)
                    .build()
                com.google.firebase.firestore.FirebaseFirestore.getInstance().firestoreSettings = settings
            } catch (e: Throwable) {
                Log.w("AidApplication", "Firebase/Firestore init note: ${e.message}")
            }

            // 5. تشغيل محرك التزامن السحابي وتأمين جلسة مصادقة Firebase المجهولة فوراً في الخلفية
            startSyncManagerSafely()
        } catch (e: Exception) {
            e.printStackTrace()
            // منع الانهيار التام واستقرار التطبيق فارغاً بانتظار إدخال المستخدم
        }
    }

    /**
     * بدء محرك التزامن التلقائي بأمان مع ضمان مصادقة Firebase المجهولة على Dispatchers.IO
     */
    fun startSyncManagerSafely() {
        applicationScope.launch(Dispatchers.IO) {
            try {
                val fsManager = com.humanitarian.aidmanagement.sync.FirestoreSyncManager.getInstance(this@AidApplication)
                fsManager.initialize()
                fsManager.ensureAuthenticated()
                com.humanitarian.aidmanagement.sync.SyncManager.initialize(this@AidApplication, database)
            } catch (e: Throwable) {
                Log.e("AidApplication", "Failed to initialize SyncManager: ${e.message}", e)
            }
        }
    }

    val database: AidDatabase by lazy { AidDatabase.getDatabase(this, applicationScope) }

    val nominationEngine: NominationEngine by lazy {
        NominationEngine(
            familyDao = database.familyDao(),
            childDao = database.childDao(),
            aidRecordDao = database.aidRecordDao(),
            nominationDao = database.nominationDao(),
            localityDao = database.localityDao(),
            systemSettingDao = database.systemSettingDao()
        )
    }

    val repository: AidRepository by lazy {
        AidRepository(
            context = this,
            database = database,
            nominationEngine = nominationEngine
        )
    }
}

/**
 * كلاس توافقي بديل لضمان عدم حدوث ClassNotFoundException إذا تمت الإشارة إلى AidManagementApp في أي ملف خارجي أو Manifest
 */
class AidManagementApp : AidApplication()

