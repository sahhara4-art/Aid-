package com.humanitarian.aidmanagement

import android.app.Application
import android.util.Log
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.NominationEngine
import com.humanitarian.aidmanagement.notifications.AidNotificationChannels
import com.humanitarian.aidmanagement.notifications.NotificationScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

open class AidApplication : Application() {
    companion object {
        @Volatile
        private var _instance: AidApplication? = null

        var instance: AidApplication
            get() = _instance ?: synchronized(this) {
                _instance ?: AidApplication().also { _instance = it }
            }
            protected set(value) {
                _instance = value
            }

        fun getInstanceSafely(): AidApplication? = _instance
    }

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        try {
            instance = this
            _instance = this

            // 0. المعترض الحرج للإقلاع النظيف (Staged Pre-Boot Restore Interceptor):
            // استعادة ملفات قاعدة البيانات المعزولة إن وُجد علم PENDING_DB_RESTORE
            // يتم هذا الفحص حتماً وبشكل تزامني قبل أي تحميل لـ SQLCipher أو Room أو أي خدمة أخرى
            try {
                com.humanitarian.aidmanagement.data.backup.DatabaseBackupManager.performPendingRestoreIfRequired(this)
            } catch (e: Throwable) {
                Log.e("AidApplication", "Pre-Boot restore check failed: ${e.message}", e)
            }

            // 1. تحميل مكتبة تشفير SQLCipher قبل أي محاولة للوصول لقاعدة البيانات لتجنب UnsatisfiedLinkError
            try {
                System.loadLibrary("sqlcipher")
                Log.i("AidApplication", "SQLCipher native library loaded successfully.")
            } catch (e: Throwable) {
                Log.w("AidApplication", "SQLCipher System.loadLibrary warning: ${e.message}")
            }

            // 2. تهيئة قنوات الإشعارات المحلية بأمان
            try {
                AidNotificationChannels.createChannels(this)
            } catch (e: Throwable) {
                Log.e("AidApplication", "Failed to create notification channels: ${e.message}", e)
            }

            // 3. جدولة الفحص الدوري للمواعيد وانتهاء الاستثناء عبر WorkManager في الخلفية
            applicationScope.launch(Dispatchers.IO) {
                try {
                    NotificationScheduler.schedulePeriodicCheck(this@AidApplication)
                } catch (e: Throwable) {
                    Log.e("AidApplication", "Failed to schedule periodic check: ${e.message}", e)
                }
            }

            // 4. ضبط إعدادات التخزين المؤقت المحلي لـ Firebase Firestore للعمل دون اتصال
            try {
                val settings = com.google.firebase.firestore.FirebaseFirestoreSettings.Builder()
                    .setLocalCacheSettings(com.google.firebase.firestore.PersistentCacheSettings.newBuilder().build())
                    .build()
                com.google.firebase.firestore.FirebaseFirestore.getInstance().firestoreSettings = settings
            } catch (e: Throwable) {
                Log.w("AidApplication", "Firestore offline settings init note: ${e.message}")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            // منع الانهيار التام واستقرار التطبيق فارغاً بانتظار إدخال المستخدم
        }
    }

    /**
     * بدء محرك التزامن التلقائي بأمان بعد نجاح فحص الإقلاع الآمن (Safe Boot)
     */
    fun startSyncManagerSafely() {
        applicationScope.launch(Dispatchers.IO) {
            try {
                com.humanitarian.aidmanagement.sync.SyncManager.initialize(this@AidApplication, database)
            } catch (e: Throwable) {
                Log.e("AidApplication", "Failed to initialize SyncManager: ${e.message}", e)
            }
        }
    }

    val database: AidDatabase by lazy { AidDatabase.getDatabase(this, applicationScope) }

    val nominationEngine: NominationEngine by lazy {
        NominationEngine(
            familyDao = database.familyDao(),
            childDao = database.childDao(),
            aidRecordDao = database.aidRecordDao(),
            nominationDao = database.nominationDao(),
            localityDao = database.localityDao(),
            systemSettingDao = database.systemSettingDao()
        )
    }

    val repository: AidRepository by lazy {
        AidRepository(
            context = this,
            database = database,
            nominationEngine = nominationEngine
        )
    }
}

/**
 * كلاس توافقي بديل لضمان عدم حدوث ClassNotFoundException إذا تمت الإشارة إلى AidManagementApp في أي ملف خارجي أو Manifest
 */
class AidManagementApp : AidApplication()

