package com.humanitarian.aidmanagement.ui.components

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.security.AccessControlManager
import com.humanitarian.aidmanagement.util.AidCategoryCatalog
import com.humanitarian.aidmanagement.util.BulkA4PdfExportResult
import com.humanitarian.aidmanagement.util.BulkA4VouchersConfig
import com.humanitarian.aidmanagement.util.BulkA4VouchersPdfGenerator
import com.humanitarian.aidmanagement.util.BulkVoucherBeneficiaryItem
import com.humanitarian.aidmanagement.util.BulkVoucherDensity
import com.humanitarian.aidmanagement.util.PublicDownloadsExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val VoucherEmeraldDark = Color(0xFF065F46)
private val VoucherEmerald = Color(0xFF059669)
private val VoucherEmeraldSoft = Color(0xFFECFDF5)
private val VoucherEmeraldBorder = Color(0xFF6EE7B7)
private val VoucherIndigo = Color(0xFF4338CA)
private val VoucherSlateDark = Color(0xFF0F172A)
private val VoucherSlateMuted = Color(0xFF64748B)
private val VoucherNeutralBorder = Color(0xFFCBD5E1)

private val DELIVERED_STATUS_TOKENS = setOf("مستفيد", "تم التسليم", "مستلم")

/**
 * غلاف جاهز لشاشة المشاريع: يحمّل مستفيدي المشروع (مع تطبيق العزل الجغرافي للمستخدم الحالي)
 * ثم يعرض نافذة إعداد بطاقات التوزيع الجماعية على ورق A4.
 */
@Composable
fun ProjectBulkA4VouchersDialog(
    repository: AidRepository,
    project: ProjectEntity,
    aidTypeName: String,
    onDismiss: () -> Unit
) {
    var isLoadingBeneficiaries by remember(project.projectID) { mutableStateOf(true) }
    var beneficiaries by remember(project.projectID) { mutableStateOf<List<BulkVoucherBeneficiaryItem>>(emptyList()) }
    var resolvedAidType by remember(project.projectID) { mutableStateOf(aidTypeName) }
    var loadError by remember(project.projectID) { mutableStateOf<String?>(null) }

    LaunchedEffect(project.projectID) {
        isLoadingBeneficiaries = true
        loadError = null
        runCatching {
            withContext(Dispatchers.IO) {
                val aidRecords = repository.getAidRecordsForProject(project.projectID).first()
                val familiesList = repository.getFamiliesForProject(project.projectID)
                val familyMap = familiesList.associateBy { it.familyID }
                val localitiesList = repository.getLocalities().first()
                val localitiesMap = localitiesList.associate { it.LocalityID to it.LocalityName }
                val extraLocIds = repository.getCurrentUserLocalityIds()

                val resolvedCategory = if (aidTypeName.isNotBlank()) {
                    aidTypeName
                } else {
                    val aidTypes = repository.getActiveAidTypes().first().associateBy { it.aidTypeID }
                    AidCategoryCatalog.resolveDisplayName(
                        aidTypeId = project.aidTypeID,
                        aidTypeMap = aidTypes,
                        projectAidTypeId = project.aidTypeID,
                        fallbackLabel = "مساعدة إنسانية"
                    )
                }

                val allowedRecords = aidRecords.filter { rec ->
                    val fam = familyMap[rec.familyID]
                    fam != null && AccessControlManager.isFamilyAllowed(
                        family = fam,
                        localitiesMap = localitiesMap,
                        extraAllowedLocalityIds = extraLocIds
                    )
                }

                val items = allowedRecords.mapIndexed { idx, rec ->
                    val fam = familyMap[rec.familyID]
                    val isDelivered = rec.recipientStatus.trim() in DELIVERED_STATUS_TOKENS
                    BulkVoucherBeneficiaryItem(
                        serialNumber = idx + 1,
                        familyId = rec.familyID,
                        nationalId = fam?.nationalID?.trim().orEmpty(),
                        beneficiaryName = fam?.name?.trim().orEmpty().ifBlank { "مستفيد #${rec.familyID}" },
                        familySize = fam?.familyMembersCount ?: 0,
                        isDelivered = isDelivered
                    )
                }
                resolvedCategory to items
            }
        }.onSuccess { (cat, items) ->
            resolvedAidType = cat
            beneficiaries = items
        }.onFailure { err ->
            loadError = err.message ?: "تعذر تحميل قائمة المستفيدين"
        }
        isLoadingBeneficiaries = false
    }

    if (isLoadingBeneficiaries) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = onDismiss,
                containerColor = Color.White,
                shape = RoundedCornerShape(18.dp),
                title = {
                    Text(
                        text = "🪪 تجهيز بطاقات التوزيع (A4)",
                        color = VoucherEmeraldDark,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                },
                text = {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(
                            color = VoucherEmerald,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(26.dp)
                        )
                        Text(
                            text = "جاري تحميل مستفيدي مشروع «${project.projectName}»...",
                            color = VoucherSlateDark,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = onDismiss) {
                        Text("إلغاء", color = VoucherSlateMuted, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    } else if (loadError != null) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AlertDialog(
                onDismissRequest = onDismiss,
                containerColor = Color.White,
                shape = RoundedCornerShape(18.dp),
                title = {
                    Text(
                        text = "تعذر تحميل بيانات المشروع",
                        color = Color(0xFFDC2626),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(text = loadError ?: "خطأ غير متوقع", fontSize = 13.sp, color = VoucherSlateDark)
                },
                confirmButton = {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = VoucherEmerald)
                    ) {
                        Text("إغلاق", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    } else {
        BulkA4VouchersDialog(
            projectId = project.projectID,
            projectName = project.projectName,
            projectNumber = project.projectNumber,
            aidTypeName = resolvedAidType.ifBlank { "مساعدة إنسانية" },
            defaultLocation = project.warehouseName.trim(),
            beneficiaries = beneficiaries,
            onDismiss = onDismiss
        )
    }
}

/**
 * نافذة إعداد بطاقات التوزيع الجماعية على ورق A4 (24 أو 21 بطاقة في الصفحة)
 * بتصميم زجاجي أخضر مع تصدير مباشر إلى Downloads/HumanitarianAid وطباعة مباشرة عبر PrintManager.
 */
@Composable
fun BulkA4VouchersDialog(
    projectId: Long,
    projectName: String,
    projectNumber: String = "",
    aidTypeName: String,
    defaultLocation: String = "",
    beneficiaries: List<BulkVoucherBeneficiaryItem>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val todayFormatted = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }
    val tomorrowFormatted = remember {
        val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }

    var onlyPending by remember { mutableStateOf(true) }
    var selectedDensity by remember { mutableStateOf(BulkVoucherDensity.CARDS_24) }
    var pickupDate by remember { mutableStateOf(todayFormatted) }
    var pickupTime by remember { mutableStateOf("09:00 صباحاً - 02:00 ظهراً") }
    var pickupLocation by remember {
        mutableStateOf(defaultLocation.trim().ifBlank { "" })
    }

    var isProcessing by remember { mutableStateOf(false) }
    var processingLabel by remember { mutableStateOf("") }
    var savedPdfResult by remember { mutableStateOf<BulkA4PdfExportResult?>(null) }

    val pendingList = remember(beneficiaries) {
        beneficiaries.filter { !it.isDelivered }
    }
    val selectedBeneficiaries = remember(beneficiaries, pendingList, onlyPending) {
        val base = if (onlyPending) pendingList else beneficiaries
        base.mapIndexed { idx, item -> item.copy(serialNumber = idx + 1) }
    }
    val targetCardsCount = selectedBeneficiaries.size
    val expectedPagesCount = remember(targetCardsCount, selectedDensity) {
        BulkA4VouchersPdfGenerator.calculatePageCount(targetCardsCount, selectedDensity)
    }

    fun buildConfig(): BulkA4VouchersConfig {
        return BulkA4VouchersConfig(
            projectId = projectId,
            projectName = projectName,
            projectNumber = projectNumber,
            aidTypeName = aidTypeName,
            pickupDate = pickupDate.trim().ifBlank { todayFormatted },
            pickupTime = pickupTime.trim().ifBlank { "09:00 صباحاً - 02:00 ظهراً" },
            pickupLocation = pickupLocation.trim().ifBlank { defaultLocation.ifBlank { "نقطة التوزيع المعتمدة" } },
            density = selectedDensity
        )
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = {
                if (!isProcessing) onDismiss()
            },
            containerColor = Color(0xFFF7FCF9),
            shape = RoundedCornerShape(20.dp),
            title = {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(VoucherEmeraldDark, VoucherEmerald)
                            )
                        )
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "🪪 طباعة بطاقات التوزيع الجماعية (A4)",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = if (projectNumber.isNotBlank()) {
                                "$aidTypeName • $projectName (#$projectNumber)"
                            } else {
                                "$aidTypeName • $projectName"
                            },
                            color = Color(0xFFD1FAE5),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // شريط معاينة فوري لعدد البطاقات وعدد صفحات A4 المتوقعة
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (targetCardsCount > 0) VoucherEmeraldSoft else Color(0xFFFEF3C7),
                        border = BorderStroke(
                            1.dp,
                            if (targetCardsCount > 0) VoucherEmeraldBorder else Color(0xFFFCD34D)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Text(
                                text = if (targetCardsCount > 0) {
                                    "$targetCardsCount بطاقة ➔ $expectedPagesCount صفحة A4"
                                } else {
                                    "لا توجد بطاقات ضمن النطاق المختار حالياً"
                                },
                                color = if (targetCardsCount > 0) VoucherEmeraldDark else Color(0xFF92400E),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "إجمالي المرشحين: ${beneficiaries.size} • بانتظار الاستلام: ${pendingList.size}",
                                color = VoucherSlateMuted,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // 1) نطاق المستفيدين
                    Text(
                        text = "نطاق المستفيدين:",
                        color = VoucherSlateDark,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VoucherOptionCard(
                            title = "بانتظار الاستلام فقط",
                            subtitle = "${pendingList.size} مستفيد",
                            selected = onlyPending,
                            onClick = { onlyPending = true },
                            modifier = Modifier.weight(1f)
                        )
                        VoucherOptionCard(
                            title = "جميع المرشحين",
                            subtitle = "${beneficiaries.size} مستفيد",
                            selected = !onlyPending,
                            onClick = { onlyPending = false },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // 2) كثافة الصفحة
                    Text(
                        text = "كثافة الصفحة (ورق A4):",
                        color = VoucherSlateDark,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VoucherOptionCard(
                            title = "24 بطاقة (3×8)",
                            subtitle = "افتراضي وموفر للورق",
                            selected = selectedDensity == BulkVoucherDensity.CARDS_24,
                            onClick = { selectedDensity = BulkVoucherDensity.CARDS_24 },
                            modifier = Modifier.weight(1f)
                        )
                        VoucherOptionCard(
                            title = "21 بطاقة (3×7)",
                            subtitle = "حجم بطاقة أكبر",
                            selected = selectedDensity == BulkVoucherDensity.CARDS_21,
                            onClick = { selectedDensity = BulkVoucherDensity.CARDS_21 },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // 3) تاريخ الاستلام مع أزرار سريعة (اليوم / غداً)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📅 تاريخ الاستلام:",
                                color = VoucherSlateDark,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                QuickDatePill(
                                    label = "اليوم",
                                    selected = pickupDate == todayFormatted,
                                    onClick = { pickupDate = todayFormatted }
                                )
                                QuickDatePill(
                                    label = "غداً",
                                    selected = pickupDate == tomorrowFormatted,
                                    onClick = { pickupDate = tomorrowFormatted }
                                )
                            }
                        }
                        OutlinedTextField(
                            value = pickupDate,
                            onValueChange = { pickupDate = it },
                            placeholder = { Text("مثال: 2026-05-10", fontSize = 12.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White.copy(alpha = 0.85f),
                                focusedBorderColor = VoucherEmerald,
                                unfocusedBorderColor = VoucherNeutralBorder
                            )
                        )
                    }

                    // 4) وقت الاستلام
                    OutlinedTextField(
                        value = pickupTime,
                        onValueChange = { pickupTime = it },
                        label = { Text("⏰ وقت الاستلام", fontSize = 12.sp) },
                        placeholder = { Text("09:00 صباحاً - 02:00 ظهراً", fontSize = 12.sp) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White.copy(alpha = 0.85f),
                            focusedBorderColor = VoucherEmerald,
                            unfocusedBorderColor = VoucherNeutralBorder
                        )
                    )

                    // 5) تفاصيل وعنوان مكان الاستلام
                    OutlinedTextField(
                        value = pickupLocation,
                        onValueChange = { pickupLocation = it },
                        label = { Text("📍 تفاصيل وعنوان مكان الاستلام", fontSize = 12.sp) },
                        placeholder = { Text("مثال: نقطة توزيع الرمال الشمالي - بجوار...", fontSize = 12.sp) },
                        minLines = 2,
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White.copy(alpha = 0.85f),
                            focusedBorderColor = VoucherEmerald,
                            unfocusedBorderColor = VoucherNeutralBorder
                        )
                    )

                    if (isProcessing) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = VoucherEmeraldSoft,
                            border = BorderStroke(1.dp, VoucherEmeraldBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CircularProgressIndicator(
                                    color = VoucherEmerald,
                                    strokeWidth = 2.5.dp,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = processingLabel.ifBlank { "جاري تجهيز ملف البطاقات (A4)..." },
                                    color = VoucherEmeraldDark,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // أزرار التنفيذ في أسفل النافذة
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (selectedBeneficiaries.isEmpty()) {
                                    Toast.makeText(
                                        context,
                                        "لا يوجد مستفيدون ضمن النطاق المحدد",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    scope.launch {
                                        isProcessing = true
                                        processingLabel = "جاري توليد وحفظ $targetCardsCount بطاقة ($expectedPagesCount صفحة A4)..."
                                        runCatching {
                                            BulkA4VouchersPdfGenerator.generateAndSaveToDownloads(
                                                context = context,
                                                config = buildConfig(),
                                                beneficiaries = selectedBeneficiaries
                                            )
                                        }.onSuccess { exportResult ->
                                            savedPdfResult = exportResult
                                        }.onFailure { err ->
                                            Toast.makeText(
                                                context,
                                                "تعذر حفظ ملف البطاقات: ${err.message ?: "خطأ غير متوقع"}",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                        isProcessing = false
                                        processingLabel = ""
                                    }
                                }
                            },
                            enabled = !isProcessing && targetCardsCount > 0,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = VoucherEmerald,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "📥 تصدير وحفظ PDF في الجوال",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                if (selectedBeneficiaries.isEmpty()) {
                                    Toast.makeText(
                                        context,
                                        "لا يوجد مستفيدون ضمن النطاق المحدد",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                } else {
                                    scope.launch {
                                        isProcessing = true
                                        processingLabel = "جاري تجهيز $expectedPagesCount صفحة للطباعة المباشرة..."
                                        runCatching {
                                            BulkA4VouchersPdfGenerator.generateTempPdfForPrinting(
                                                context = context,
                                                config = buildConfig(),
                                                beneficiaries = selectedBeneficiaries
                                            )
                                        }.onSuccess { printResult ->
                                            val launched = BulkA4VouchersPdfGenerator.launchAndroidPrintManager(
                                                context = context,
                                                printFileResult = printResult
                                            )
                                            if (!launched) {
                                                Toast.makeText(
                                                    context,
                                                    "خدمة الطباعة غير متوفرة على هذا الجهاز؛ استخدم خيار حفظ PDF في الجوال",
                                                    Toast.LENGTH_LONG
                                                ).show()
                                            }
                                        }.onFailure { err ->
                                            Toast.makeText(
                                                context,
                                                "تعذر تجهيز ملف الطباعة: ${err.message ?: "خطأ غير متوقع"}",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                        isProcessing = false
                                        processingLabel = ""
                                    }
                                }
                            },
                            enabled = !isProcessing && targetCardsCount > 0,
                            border = BorderStroke(1.2.dp, VoucherEmeraldDark),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color.White,
                                contentColor = VoucherEmeraldDark
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "🖨️ طباعة مباشرة (A4)",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(
                    onClick = onDismiss,
                    enabled = !isProcessing
                ) {
                    Text(
                        text = "إغلاق",
                        color = VoucherSlateMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )

        // نافذة تأكيد الحفظ في مجلد التنزيلات العام مع أزرار الفتح والمشاركة
        val activeSaved = savedPdfResult
        if (activeSaved != null) {
            AlertDialog(
                onDismissRequest = { savedPdfResult = null },
                containerColor = Color.White,
                shape = RoundedCornerShape(18.dp),
                title = {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Text(
                            text = "✅ تم حفظ بطاقات التوزيع (A4) في الجوال بنجاح",
                            color = VoucherEmeraldDark,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                text = {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFF1F5F9),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "تم تجهيز ${activeSaved.totalCards} بطاقة توزيع في ${activeSaved.totalPages} صفحة A4 جاهزة للطباعة والقص.",
                                    color = VoucherSlateDark,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                                )
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = "اسم الملف:",
                                    color = VoucherSlateMuted,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = activeSaved.savedResult.fileName,
                                    color = VoucherSlateDark,
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }

                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "مكان الحفظ:",
                                    color = VoucherSlateMuted,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = VoucherEmeraldSoft,
                                    border = BorderStroke(1.dp, VoucherEmeraldBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = activeSaved.savedResult.humanReadablePath,
                                        color = VoucherSlateDark,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        lineHeight = 18.sp,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = {
                                    val opened = PublicDownloadsExporter.openSavedPdf(
                                        context = context,
                                        result = activeSaved.savedResult
                                    )
                                    if (!opened) {
                                        Toast.makeText(
                                            context,
                                            "لا يوجد تطبيق PDF مثبّت؛ يمكنك فتح الملف من مجلد التنزيلات (Downloads/HumanitarianAid)",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = VoucherEmerald),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = "📂 فتح الملف",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    val shared = PublicDownloadsExporter.shareSavedPdf(
                                        context = context,
                                        result = activeSaved.savedResult,
                                        subject = "بطاقات توزيع $projectName (A4)"
                                    )
                                    if (!shared) {
                                        Toast.makeText(
                                            context,
                                            "تعذر فتح قائمة المشاركة",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                },
                                border = BorderStroke(1.dp, VoucherIndigo),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                Text(
                                    text = "📤 مشاركة",
                                    color = VoucherIndigo,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { savedPdfResult = null }) {
                        Text(
                            text = "إغلاق",
                            color = VoucherSlateMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            )
        }
    }
}

@Composable
private fun VoucherOptionCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        color = if (selected) VoucherEmeraldSoft else Color.White,
        border = BorderStroke(
            width = if (selected) 1.6.dp else 1.dp,
            color = if (selected) VoucherEmerald else VoucherNeutralBorder
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Text(
                text = title,
                color = if (selected) VoucherEmeraldDark else VoucherSlateDark,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                color = if (selected) VoucherEmerald else VoucherSlateMuted,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun QuickDatePill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) VoucherEmerald else Color.White)
            .border(
                1.dp,
                if (selected) VoucherEmerald else VoucherNeutralBorder,
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = label,
            color = if (selected) Color.White else VoucherSlateDark,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
