package com.humanitarian.aidmanagement.ui.screens.login

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.biometric.BiometricManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.data.local.entities.UserLocalityEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * حالة واجهة المستخدم لشاشة تسجيل الدخول
 */
data class LoginUiState(
    val username: String = "",
    val password: String = "",
    val passwordVisible: Boolean = false,
    val rememberMe: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val isBiometricSupported: Boolean = false,
    val hasEnrolledBiometrics: Boolean = false,
    val hasSavedCredentials: Boolean = false,
    val canLoginWithBiometric: Boolean = false
)

/**
 * ViewModel لإدارة تسجيل الدخول، الحفظ المشفر لبيانات الاعتماد (تذكرني)، والمصادقة بالبصمة
 */
class LoginViewModel(
    application: Application,
    private val database: AidDatabase,
    private val repository: AidRepository
) : AndroidViewModel(application) {

    private var currentDb: AidDatabase = database
    private var prefs: SharedPreferences = createSecurePreferences(application)

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    private var initDbJob: Job? = null
    private var loginJob: Job? = null

    init {
        try {
            // الأكواد الحالية هنا داخل كتلة حماية شاملة لمنع أي انهيار فوري عند بدء الشاشة
            loadSavedCredentials()
            checkBiometricStatus()
            checkInitialDatabaseState()
        } catch (e: Exception) {
            e.printStackTrace()
            // منع الانهيار التام واستقرار التطبيق فارغاً بانتظار إدخال المستخدم
            _uiState.update {
                it.copy(
                    username = "",
                    password = "",
                    isLoading = false,
                    errorMessage = null
                )
            }
        }
    }

    private fun createSecurePreferences(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "secure_aid_login_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (t: Throwable) {
            try {
                context.getSharedPreferences("secure_aid_login_prefs", Context.MODE_PRIVATE)
            } catch (fallbackError: Throwable) {
                context.getSharedPreferences("fallback_aid_login_prefs", Context.MODE_PRIVATE)
            }
        }
    }

    /**
     * تحميل بيانات الدخول المحفوظة مسبقاً إذا تم اختيار "تذكر بيانات الدخول"
     * معالجة القيمة الفارغة (Null) وتغليف القراءة بـ try-catch لمنع أي انهيار
     */
    private fun loadSavedCredentials() {
        try {
            val isRemembered = prefs.getBoolean(KEY_REMEMBER_ME, false)
            val savedUser = prefs.getString(KEY_SAVED_USERNAME, null) ?: ""
            val savedPass = prefs.getString(KEY_SAVED_PASSWORD, null) ?: ""

            val hasValidSaved = isRemembered && savedUser.isNotBlank() && savedPass.isNotBlank()

            _uiState.update {
                it.copy(
                    username = if (hasValidSaved) savedUser else "",
                    password = if (hasValidSaved) savedPass else "",
                    rememberMe = isRemembered,
                    hasSavedCredentials = hasValidSaved
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _uiState.update {
                it.copy(
                    username = "",
                    password = "",
                    rememberMe = false,
                    hasSavedCredentials = false
                )
            }
        }
    }

    /**
     * التحقق من دعم الجهاز للبصمة ووجود بيانات اعتماد محفوظة للدخول الفوري
     */
    fun checkBiometricStatus() {
        try {
            val context = getApplication<Application>()
            val biometricManager = BiometricManager.from(context)
            val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL

            val authStatus = biometricManager.canAuthenticate(authenticators)
            val isSupported = authStatus != BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE &&
                    authStatus != BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE
            val hasEnrolled = authStatus == BiometricManager.BIOMETRIC_SUCCESS

            val hasSaved = _uiState.value.hasSavedCredentials

            _uiState.update {
                it.copy(
                    isBiometricSupported = isSupported,
                    hasEnrolledBiometrics = hasEnrolled,
                    canLoginWithBiometric = hasEnrolled && hasSaved
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            _uiState.update {
                it.copy(
                    isBiometricSupported = false,
                    hasEnrolledBiometrics = false,
                    canLoginWithBiometric = false
                )
            }
        }
    }

    private fun isCode26OrCorrupt(t: Throwable): Boolean {
        var curr: Throwable? = t
        while (curr != null) {
            val msg = curr.message ?: ""
            if (msg.contains("code 26", ignoreCase = true) ||
                msg.contains("file is not a database", ignoreCase = true) ||
                msg.contains("corrupt", ignoreCase = true) ||
                msg.contains("malformed", ignoreCase = true)
            ) {
                return true
            }
            curr = curr.cause
        }
        return false
    }

    private suspend fun getOrRecoverDb(): AidDatabase {
        return try {
            currentDb.userDao().getUserByUsername("admin")
            currentDb
        } catch (t: Throwable) {
            if (isCode26OrCorrupt(t)) {
                android.util.Log.w("LoginViewModel", "Code 26 detected, auto-healing database...")
                val newDb = AidDatabase.recoverCorruptOrEmptyDatabase(getApplication())
                currentDb = newDb
                ensureAdminUserSeeded(newDb)
                newDb
            } else {
                currentDb
            }
        }
    }

    private suspend fun ensureAdminUserSeeded(db: AidDatabase = currentDb) {
        try {
            val adminUser = db.userDao().getUserByUsername("admin")
            if (adminUser == null) {
                val defaultAdmin = UserEntity(
                    UserID = 1,
                    UserName = "admin",
                    PasswordHash = "admin123",
                    fullName = "مدير النظام العام",
                    RoleID = 1,
                    IsActive = true,
                    CreatedBy = "النظام الأولي"
                )
                db.userDao().insertUser(defaultAdmin)
                db.userDao().insertUserLocality(
                    UserLocalityEntity(UserID = 1, LocalityID = 0)
                )
            }
        } catch (t: Throwable) {
            android.util.Log.w("LoginViewModel", "ensureAdminUserSeeded note: ${t.message}")
        }
    }

    /**
     * فحص أولي آمن لقاعدة البيانات عند بدء شاشة الدخول
     * إذا كانت قاعدة البيانات جديدة وفارغة (Null)، تتم معالجة ذلك بأمان وإنشاء الأدمن الافتراضي
     * دون أي انهيار لضمان استقرار الشاشة وانتظار إدخال المستخدم
     */
    private fun checkInitialDatabaseState() {
        initDbJob?.cancel()
        initDbJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val db = getOrRecoverDb()
                ensureAdminUserSeeded(db)
            } catch (e: Exception) {
                e.printStackTrace()
                if (isCode26OrCorrupt(e)) {
                    try {
                        val newDb = AidDatabase.recoverCorruptOrEmptyDatabase(getApplication())
                        currentDb = newDb
                        ensureAdminUserSeeded(newDb)
                    } catch (_: Exception) {}
                }
            }
        }
    }

    fun onUsernameChange(newUsername: String) {
        _uiState.update { it.copy(username = newUsername, errorMessage = null) }
    }

    fun onPasswordChange(newPassword: String) {
        _uiState.update { it.copy(password = newPassword, errorMessage = null) }
    }

    fun togglePasswordVisibility() {
        _uiState.update { it.copy(passwordVisible = !it.passwordVisible) }
    }

    fun onRememberMeChange(checked: Boolean) {
        _uiState.update { it.copy(rememberMe = checked) }
    }

    fun setErrorMessage(msg: String?) {
        _uiState.update { it.copy(errorMessage = msg, isLoading = false) }
    }

    fun shouldAutoPromptBiometric(): Boolean {
        // منع إطلاق نافذة البصمة تلقائياً لتفادي انهيار نافذة Activity في أجزاء الثانية الأولى
        return false
    }

    /**
     * تسجيل الدخول التقليدي بالاسم وكلمة المرور
     */
    fun login(onSuccess: () -> Unit) {
        try {
            val usernameInput = _uiState.value.username.trim()
            val passwordInput = _uiState.value.password

            if (usernameInput.isBlank() || passwordInput.isBlank()) {
                setErrorMessage("يرجى إدخال اسم المستخدم وكلمة المرور")
                return
            }

            executeLogin(usernameInput, passwordInput, onSuccess)
        } catch (e: Exception) {
            e.printStackTrace()
            setErrorMessage("حدث خطأ أثناء محاولة تسجيل الدخول")
        }
    }

    /**
     * تسجيل الدخول التلقائي عند نجاح فحص البصمة باستخدام بيانات الدخول المشفرة المحفوظة
     */
    fun loginWithBiometric(onSuccess: () -> Unit) {
        try {
            val savedUser = prefs.getString(KEY_SAVED_USERNAME, null) ?: ""
            val savedPass = prefs.getString(KEY_SAVED_PASSWORD, null) ?: ""

            if (savedUser.isBlank() || savedPass.isBlank()) {
                setErrorMessage("لا توجد بيانات دخول محفوظة للبصمة. يرجى تسجيل الدخول أولاً واختيار 'تذكر بيانات الدخول'")
                return
            }

            executeLogin(savedUser, savedPass, onSuccess)
        } catch (e: Exception) {
            e.printStackTrace()
            setErrorMessage("تعذر قراءة بيانات الدخول المحفوظة للبصمة")
        }
    }

    private fun executeLogin(userStr: String, passStr: String, onSuccess: () -> Unit) {
        loginJob?.cancel()
        loginJob = viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                val currentTime = System.currentTimeMillis()
                val db = getOrRecoverDb()

                var user: UserEntity? = null
                try {
                    user = db.userDao().getUserByUsername(userStr)
                } catch (dbEx: Throwable) {
                    if (isCode26OrCorrupt(dbEx)) {
                        android.util.Log.w("LoginViewModel", "Code 26 during login, auto-healing.")
                        val newDb = AidDatabase.recoverCorruptOrEmptyDatabase(getApplication())
                        currentDb = newDb
                        ensureAdminUserSeeded(newDb)
                        user = newDb.userDao().getUserByUsername(userStr)
                    } else {
                        throw dbEx
                    }
                }

                // معالجة قاعدة البيانات الفارغة أو المستخدم غير المسجل:
                // اسمح له بإنشاء حساب جديد أو الدخول بقاعدة فارغة دون خطأ مزعج
                if (user == null) {
                    val allUsers = try {
                        currentDb.userDao().getAllUsersSync()
                    } catch (_: Throwable) {
                        emptyList()
                    }

                    if (allUsers.isEmpty() || userStr.equals("admin", ignoreCase = true)) {
                        val newUser = UserEntity(
                            UserID = if (allUsers.isEmpty()) 1 else (allUsers.maxOfOrNull { it.UserID } ?: 1) + 1,
                            UserName = userStr,
                            PasswordHash = passStr,
                            fullName = if (userStr.equals("admin", ignoreCase = true)) "مدير النظام العام" else userStr,
                            RoleID = 1,
                            IsActive = true,
                            CreatedBy = "تسجيل دخول ذاتي"
                        )
                        currentDb.userDao().insertUser(newUser)
                        currentDb.userDao().insertUserLocality(UserLocalityEntity(UserID = newUser.UserID, LocalityID = 0))
                        user = newUser
                    } else {
                        setErrorMessage("اسم المستخدم أو كلمة المرور غير صحيحة")
                        return@launch
                    }
                }

                // 1. التحقق من قفل الحساب
                if (user.IsLocked) {
                    setErrorMessage("الحساب مقفل أمنياً. يرجى مراجعة إدارة النظام.")
                    return@launch
                }
                val lockedUntil = user.LockedUntil
                if (lockedUntil != null && lockedUntil > currentTime) {
                    val remainingMinutes = ((lockedUntil - currentTime) / (1000 * 60)) + 1
                    setErrorMessage("تم قفل الحساب مؤقتًا لتجاوز محاولات الدخول. يرجى الانتظار $remainingMinutes دقيقة.")
                    return@launch
                }

                // 2. التحقق من تفعيل الحساب
                if (!user.IsActive) {
                    setErrorMessage("هذا الحساب معطل، يرجى مراجعة إدارة المنظومة.")
                    return@launch
                }

                // 3. التحقق من تاريخ انتهاء صلاحية الحساب (accountExpiryTimestamp)
                val accountExpiryTimestamp = user.accountExpiryDate ?: 0L
                if (accountExpiryTimestamp > 0L && currentTime >= accountExpiryTimestamp) {
                    setErrorMessage("انتهت صلاحية الحساب (تجاوز تاريخ الانتهاء المحدد). يرجى مراجعة مسؤول النظام لتمديد الصلاحية.")
                    return@launch
                }

                // 4. التحقق من الحد الأقصى لمرات الدخول المسموحة (consumedLogins >= maxAllowedLogins)
                val maxAllowedLogins = if (user.maxLogins > 0) user.maxLogins else user.MaxAllowedLogins
                val consumedLogins = if (user.maxLogins > 0) user.currentLogins else maxOf(user.ConsumedLogins, user.currentLogins)
                if (maxAllowedLogins > 0 && consumedLogins >= maxAllowedLogins) {
                    setErrorMessage("تم استنفاد مرات الدخول المسموحة لهذا الحساب ($consumedLogins / $maxAllowedLogins).")
                    return@launch
                }

                // 4b. التحقق من رصيد مرات الدخول الإجمالي (Lifetime Login Quota: -1 = غير محدود)
                if (user.totalAllowedLogins != -1 && user.totalLoginsUsed >= user.totalAllowedLogins) {
                    setErrorMessage("لقد استنفدت رصيدك الإجمالي لمرات الدخول المسموحة على هذا النظام. تم قفل الحساب، راجع الإدارة.")
                    return@launch
                }

                // 5. فحص كلمة المرور
                if (user.PasswordHash != passStr) {
                    val newAttempts = user.FailedAttempts + 1
                    if (newAttempts >= 5) {
                        val lockDuration = 15 * 60 * 1000L // 15 دقيقة
                        try {
                            currentDb.userDao().lockUser(user.UserName, currentTime + lockDuration)
                        } catch (_: Exception) {}
                        setErrorMessage("تم تجاوز الحد الأقصى للمحاولات (5 محاولات). تم قفل الحساب لمدة 15 دقيقة.")
                    } else {
                        try {
                            currentDb.userDao().incrementFailedAttempts(user.UserName)
                        } catch (_: Exception) {}
                        val remaining = 5 - newAttempts
                        setErrorMessage("كلمة المرور غير صحيحة. متبقي لديك $remaining محاولات قبل قفل الحساب.")
                    }
                    return@launch
                }

                // 6. تسجيل دخول ناجح: تصفير المحاولات الفاشلة، تحديث التوقيت، وزيادة عداد مرات الدخول الإجمالي والفوري
                try {
                    currentDb.userDao().recordSuccessfulLogin(user.UserID, currentTime)
                } catch (_: Exception) {}

                val updatedUser = user.copy(
                    FailedAttempts = 0,
                    LockedUntil = null,
                    LastLogin = currentTime,
                    ConsumedLogins = user.ConsumedLogins + 1,
                    currentLogins = user.currentLogins + 1,
                    totalLoginsUsed = user.totalLoginsUsed + 1
                )

                // حفظ التحديث في Room و Firestore فوراً لضمان عدم ضياع العداد عند إغلاق التطبيق
                try {
                    repository.persistUserLoginQuota(updatedUser)
                } catch (_: Exception) {}

                val localityIds = try {
                    currentDb.userDao().getUserLocalityIds(user.UserID)
                } catch (_: Exception) {
                    emptyList()
                }

                repository.setCurrentUser(updatedUser, localityIds)

                // 5. حفظ أو إزالة بيانات الاعتماد وفق خيار "تذكرني"
                try {
                    val shouldRemember = _uiState.value.rememberMe
                    prefs.edit().apply {
                        putBoolean(KEY_REMEMBER_ME, shouldRemember)
                        if (shouldRemember) {
                            putString(KEY_SAVED_USERNAME, userStr)
                            putString(KEY_SAVED_PASSWORD, passStr)
                        } else {
                            remove(KEY_SAVED_USERNAME)
                            remove(KEY_SAVED_PASSWORD)
                        }
                        apply()
                    }
                } catch (_: Exception) {}

                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(isLoading = false, errorMessage = null) }
                    onSuccess()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                setErrorMessage("حدث خطأ أثناء محاولة تسجيل الدخول: ${e.localizedMessage ?: e.message}")
            }
        }
    }

    fun clearState() {
        loginJob?.cancel()
        _uiState.update {
            it.copy(
                password = "",
                isLoading = false,
                errorMessage = null
            )
        }
    }

    override fun onCleared() {
        initDbJob?.cancel()
        loginJob?.cancel()
        clearState()
        super.onCleared()
    }

    companion object {
        private const val KEY_REMEMBER_ME = "pref_remember_me"
        private const val KEY_SAVED_USERNAME = "pref_saved_username"
        private const val KEY_SAVED_PASSWORD = "pref_saved_password"
    }

    class Factory(
        private val application: Application,
        private val database: AidDatabase,
        private val repository: AidRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
                return LoginViewModel(application, database, repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
