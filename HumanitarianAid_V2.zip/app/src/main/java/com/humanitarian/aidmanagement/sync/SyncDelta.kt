package com.humanitarian.aidmanagement.sync

data class SyncDelta(
    val entityType: String, // "Family", "AidRecord", "Selection"
    val entityId: String,
    val operation: String, // "INSERT", "UPDATE", "DELETE"
    val timestamp: Long = System.currentTimeMillis(),
    val payloadJson: String = ""
)

enum class SyncStatus {
    IDLE,
    SYNCING,
    SUCCESS,
    ERROR
}
