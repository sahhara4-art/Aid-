package com.humanitarian.aidmanagement.ui.components.charts

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat

enum class AnalyticsChartTab(val label: String) {
    LOCALITY("المحليات"),
    AID_TYPE("أنواع المعونة"),
    QUOTA_COMPLETION("الحصص والإنجاز")
}

@Composable
fun InteractiveAnalyticsChartsCard(
    localityStats: List<LocalityDistributionStat>,
    aidTypeStats: List<AidTypeDistributionStat>,
    modifier: Modifier = Modifier,
    onNavigateToReports: () -> Unit = {}
) {
    var selectedTab by remember { mutableStateOf(AnalyticsChartTab.LOCALITY) }
    var selectedLocalityId by remember { mutableStateOf<Int?>(1) }
    var selectedAidTypeId by remember { mutableStateOf<Int?>(1) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header with badge and interactive switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = "الرسوم البيانية التفاعلية",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "تحليلات التوزيع التفاعلية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "Vico Analytics",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "رصد حي لتوزيع المساعدات حسب المنطقة ونوع المعونة",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                    }
                }

                IconButton(onClick = onNavigateToReports) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "فتح التفاصيل",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Tab Selector
            SingleChoiceSegmentedRow(
                selectedTab = selectedTab,
                onTabSelected = { selectedTab = it }
            )

            Spacer(modifier = Modifier.height(16.dp))

            when (selectedTab) {
                AnalyticsChartTab.LOCALITY -> {
                    LocalityInteractiveChart(
                        localityStats = localityStats,
                        selectedLocalityId = selectedLocalityId,
                        onSelectLocality = { selectedLocalityId = it }
                    )
                }
                AnalyticsChartTab.AID_TYPE -> {
                    AidTypeInteractiveChart(
                        aidTypeStats = aidTypeStats,
                        selectedAidTypeId = selectedAidTypeId,
                        onSelectAidType = { selectedAidTypeId = it }
                    )
                }
                AnalyticsChartTab.QUOTA_COMPLETION -> {
                    QuotaComparisonChart(
                        localityStats = localityStats
                    )
                }
            }
        }
    }
}

@Composable
private fun SingleChoiceSegmentedRow(
    selectedTab: AnalyticsChartTab,
    onTabSelected: (AnalyticsChartTab) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        AnalyticsChartTab.values().forEach { tab ->
            val isSelected = selectedTab == tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent
                    )
                    .clickable { onTabSelected(tab) }
                    .padding(vertical = 8.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = tab.label,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * 1. مخطط توزيع المحليات التفاعلي (Interactive Bar & Donut Chart)
 */
@Composable
fun LocalityInteractiveChart(
    localityStats: List<LocalityDistributionStat>,
    selectedLocalityId: Int?,
    onSelectLocality: (Int) -> Unit
) {
    // استبعاد المحليات الفارغة حصراً والاعتماد 100% على بيانات Room
    val activeStats = remember(localityStats) {
        localityStats.filter { it.familiesCount > 0 || it.deliveredAidCount > 0 }
    }

    if (activeStats.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.Analytics,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.size(44.dp)
                )
                Text(
                    text = "لا توجد بيانات مسجلة للمحليات في قاعدة البيانات",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
        return
    }

    val selectedItem = activeStats.find { it.localityId == selectedLocalityId } ?: activeStats.firstOrNull()

    val colors = listOf(
        Color(0xFF0D9488),
        Color(0xFF3B82F6),
        Color(0xFF8B5CF6),
        Color(0xFFF59E0B),
        Color(0xFF10B981),
        Color(0xFFEC4899),
        Color(0xFF06B6D4),
        Color(0xFFF97316)
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // بطاقة ملخص العنصر المحدد
        if (selectedItem != null) {
            val itemIndex = activeStats.indexOf(selectedItem).coerceAtLeast(0)
            val itemColor = colors[itemIndex % colors.size]

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = itemColor.copy(alpha = 0.1f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, itemColor.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(itemColor)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = selectedItem.localityName,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "الحصة المعتمدة: ${selectedItem.quotaPercent.toInt()}% • عدد الأسر: ${selectedItem.familiesCount}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${selectedItem.deliveredAidCount} طرد",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            color = itemColor
                        )
                        Text(
                            text = "إنجاز: ${selectedItem.completionPercent}%",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                        )
                    }
                }
            }
        }

        // رسم الأعمدة التفاعلية الديناميكية (Dynamic Reactive Column Chart)
        val maxCount = (activeStats.maxOfOrNull { it.deliveredAidCount } ?: 100).coerceAtLeast(1)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                activeStats.forEachIndexed { index, stat ->
                    val isSelected = stat.localityId == selectedLocalityId
                    val barColor = colors[index % colors.size]
                    val animatedFraction by animateFloatAsState(
                        targetValue = (stat.deliveredAidCount.toFloat() / maxCount.toFloat()).coerceIn(0.12f, 1f),
                        animationSpec = spring(stiffness = Spring.StiffnessLow),
                        label = "barHeight"
                    )

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable { onSelectLocality(stat.localityId) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        // فقاعة القيمة العلوية
                        if (isSelected) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = barColor,
                                modifier = Modifier.padding(bottom = 4.dp)
                            ) {
                                Text(
                                    text = "${stat.deliveredAidCount}",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }

                        // العمود البياني
                        Box(
                            modifier = Modifier
                                .width(if (isSelected) 26.dp else 20.dp)
                                .fillMaxHeight(animatedFraction * 0.75f)
                                .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            barColor,
                                            barColor.copy(alpha = if (isSelected) 0.85f else 0.5f)
                                        )
                                    )
                                )
                                .then(
                                    if (isSelected) Modifier.border(1.5.dp, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                    else Modifier
                                )
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // نسبة الحصة المئوية
                        Text(
                            text = "${stat.quotaPercent.toInt()}%",
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) barColor else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )

                        // اسم المنطقة الفعلي من قاعدة البيانات (X-Axis Label)
                        Text(
                            text = stat.localityName,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        // شريط النسبة التراكمية الإجمالية
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "توزيع الحصص الميدانية (100% الإجمالي)",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Text(
                    text = "${activeStats.size} محليات مسجلة",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(12.dp)
                    .clip(RoundedCornerShape(6.dp))
            ) {
                activeStats.forEachIndexed { index, stat ->
                    val barColor = colors[index % colors.size]
                    Box(
                        modifier = Modifier
                            .weight(stat.quotaPercent.toFloat().coerceAtLeast(1f))
                            .fillMaxHeight()
                            .background(barColor)
                            .clickable { onSelectLocality(stat.localityId) }
                    )
                }
            }
        }
    }
}

/**
 * 2. مخطط أنواع المعونة التفاعلي (مستمد ديناميكياً من قاعدة البيانات)
 */
@Composable
fun AidTypeInteractiveChart(
    aidTypeStats: List<AidTypeDistributionStat>,
    selectedAidTypeId: Int?,
    onSelectAidType: (Int) -> Unit
) {
    // استبعاد الأنواع بصفر تسليمات تماماً
    val activeAidStats = remember(aidTypeStats) {
        aidTypeStats.filter { it.deliveredCount > 0 }
    }

    if (activeAidStats.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    Icons.Default.Category,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.size(40.dp)
                )
                Text(
                    text = "لا توجد مساعدات مسلمة مسجلة في هذا النطاق الزمني",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
        return
    }

    val selectedItem = activeAidStats.find { it.aidTypeId == selectedAidTypeId } ?: activeAidStats.firstOrNull()
    val maxCount = (activeAidStats.maxOfOrNull { it.deliveredCount } ?: 300).coerceAtLeast(1)

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (selectedItem != null) {
            val itemColor = Color(selectedItem.colorHex)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = itemColor.copy(alpha = 0.1f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, itemColor.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(itemColor)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = selectedItem.aidTypeName,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = "الهدف المخطط: ${selectedItem.quotaTarget} طرد",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${selectedItem.deliveredCount} مسجل",
                            fontWeight = FontWeight.Bold,
                            color = itemColor,
                            style = MaterialTheme.typography.titleMedium
                        )
                        val percent = ((selectedItem.deliveredCount.toDouble() / selectedItem.quotaTarget.coerceAtLeast(1).toDouble()) * 100).toInt()
                        Text(
                            text = "التغطية: $percent%",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }

        // عرض أنواع المعونة في خطوط أفقية تفاعلية
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            activeAidStats.forEach { stat ->
                val isSelected = stat.aidTypeId == selectedAidTypeId
                val itemColor = Color(stat.colorHex)
                val animatedRatio by animateFloatAsState(
                    targetValue = (stat.deliveredCount.toFloat() / maxCount.toFloat()).coerceIn(0.08f, 1f),
                    animationSpec = spring(stiffness = Spring.StiffnessLow),
                    label = "aidTypeBar"
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onSelectAidType(stat.aidTypeId) }
                        .padding(vertical = 4.dp, horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stat.aidTypeName,
                        modifier = Modifier.width(100.dp),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(14.dp)
                            .clip(RoundedCornerShape(7.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(animatedRatio)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(7.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        colors = listOf(itemColor, itemColor.copy(alpha = 0.75f))
                                    )
                                )
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = "${stat.deliveredCount}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) itemColor else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.width(40.dp),
                        textAlign = TextAlign.End
                    )
                }
            }
        }
    }
}

/**
 * 3. مقارنة الحصص المستهدفة بالإنجاز الفعلي
 */
@Composable
fun QuotaComparisonChart(
    localityStats: List<LocalityDistributionStat>
) {
    val activeStats = remember(localityStats) {
        localityStats.filter { it.familiesCount > 0 || it.deliveredAidCount > 0 }
    }

    if (activeStats.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "لا توجد حصص مسجلة للمحليات في قاعدة البيانات",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        activeStats.forEach { stat ->
            val completion = stat.completionPercent.coerceIn(0, 100)
            val progressColor = when {
                completion >= 80 -> Color(0xFF10B981)
                completion >= 50 -> Color(0xFF3B82F6)
                else -> Color(0xFFF59E0B)
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stat.localityName,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "الحصة: ${stat.quotaPercent.toInt()}%",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "$completion%",
                            fontWeight = FontWeight.Bold,
                            color = progressColor,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                LinearProgressIndicator(
                    progress = { completion / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = progressColor,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
    }
}

