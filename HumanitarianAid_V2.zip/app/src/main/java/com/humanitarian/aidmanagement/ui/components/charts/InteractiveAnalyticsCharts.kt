package com.humanitarian.aidmanagement.ui.components.charts

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.dao.DynamicLocalityStat

@Composable
fun InteractiveAnalyticsCharts(
    stats: List<DynamicLocalityStat>,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "التوزيع الجغرافي الديناميكي (GROUP BY)",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = Color(0xFF0F172A)
            )

            val maxVal = (stats.maxOfOrNull { it.totalCount } ?: 1).coerceAtLeast(1)

            stats.forEach { stat ->
                val ratio = stat.totalCount.toFloat() / maxVal.toFloat()
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(stat.localityName, fontSize = 12.sp, color = Color(0xFF334155))
                        Text("${stat.totalCount} أسرة", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF1976D2))
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(4.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(ratio)
                                .height(8.dp)
                                .background(Color(0xFF1976D2), RoundedCornerShape(4.dp))
                        )
                    }
                }
            }
        }
    }
}
