package com.humanitarian.aidmanagement.engine

import androidx.sqlite.db.SimpleSQLiteQuery
import androidx.sqlite.db.SupportSQLiteQuery
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityDistributionEntity
import com.humanitarian.aidmanagement.data.local.entities.SelectedCitizenEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.floor

enum class ChildrenFilterMode(val label: String) {
    IGNORE("تجاهل"),
    YES("نعم (يوجد أطفال)"),
    NO("لا (بدون أطفال)")
}

data class DynamicNominationCriteria(
    val exclusionDays: Int? = 30, // استثناء من استلم خلال X يوماً (أو null للتجاهل)
    val childrenFilter: ChildrenFilterMode = ChildrenFilterMode.IGNORE,
    val minChildAge: Int? = null, // الحد الأدنى لعمر الأطفال
    val maxChildAge: Int? = null, // الحد الأقصى لعمر الأطفال
    val selectedDamageTypes: Set<String> = emptySet(), // خيارات متعددة لحالة الضرر
    val selectedWorksApprovals: Set<String> = emptySet(), // خيارات متعددة لاعتماد الأشغال
    val selectedShelterStatuses: Set<String> = emptySet(), // خيارات متعددة لحالة الإيواء
    val selectedLocalityId: Int? = 0, // 0 = كافة المحليات
    val selectedAidTypeId: Int = 1, // تصنيف المساعدة المستهدفة
    val projectId: Long = 1L, // المشروع المنفذ
    val minFamilyMembers: Int = 1,
    val limit: Int = 300
)

enum class CandidateStatus {
    MATCHED_100, // مطابقة 100% للشروط المحددة (GreenSecondary)
    WARNING,     // تحذير: استلام قريب لنوع آخر أو اقتراب اكتمال الحصة (AmberWarning)
    EXCLUDED     // مستبعد: مع ذكر سبب الاستبعاد (RedError)
}

data class DynamicCandidateModel(
    val family: FamilyEntity,
    val status: CandidateStatus,
    val matchScore: Double,
    val childrenCount: Int = 0,
    val lastAidDate: String? = null,
    val lastAidTypeName: String? = null,
    val daysSinceLastAid: Long? = null,
    val localityName: String = "",
    val exclusionReason: String? = null,
    val warningReason: String? = null,
    val auditTrail: List<String> = emptyList()
)

data class DynamicNominationResult(
    val candidates: List<DynamicCandidateModel>,
    val totalMatched: Int,
    val fullMatchCount: Int,
    val warningCount: Int,
    val excludedCount: Int,
    val quotas: List<LocalityQuota> = emptyList(),
    val executedSql: String = ""
)

class DynamicNominationEngine(
    private val database: AidDatabase
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    /**
     * بناء استعلام SQL آمن وديناميكي عبر SupportSQLiteQuery (@RawQuery)
     * يطبق الثوابت الإجبارية: (حالة التنمية = معتمد) و (حالة الإقامة = مقيم)
     * مع مرونة تامة في دمج الشروط المتعددة المحددة وتجاهل الشروط المتروكة فارغة
     */
    fun buildSupportQuery(criteria: DynamicNominationCriteria): SupportSQLiteQuery {
        val whereClauses = mutableListOf<String>()
        val args = mutableListOf<Any>()

        // 1. الثوابت الإجبارية الصارمة (Mandatory System Rules)
        whereClauses.add("(developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')")
        whereClauses.add("(residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%')")

        // 2. تصفية المحلية (إن حددت محلية خاصة غير 0)
        if (criteria.selectedLocalityId != null && criteria.selectedLocalityId > 0) {
            whereClauses.add("localityID = ?")
            args.add(criteria.selectedLocalityId)
        }

        // 3. متعدد الخيارات (Multi-select) لحالة الضرر
        if (criteria.selectedDamageTypes.isNotEmpty()) {
            val placeholders = criteria.selectedDamageTypes.joinToString(",") { "?" }
            whereClauses.add("damageType IN ($placeholders)")
            args.addAll(criteria.selectedDamageTypes)
        }

        // 4. متعدد الخيارات (Multi-select) لاعتماد الأشغال
        if (criteria.selectedWorksApprovals.isNotEmpty()) {
            val placeholders = criteria.selectedWorksApprovals.joinToString(",") { "?" }
            whereClauses.add("worksApproval IN ($placeholders)")
            args.addAll(criteria.selectedWorksApprovals)
        }

        // 5. متعدد الخيارات (Multi-select) لحالة الإيواء
        if (criteria.selectedShelterStatuses.isNotEmpty()) {
            val placeholders = criteria.selectedShelterStatuses.joinToString(",") { "?" }
            whereClauses.add("shelterStatus IN ($placeholders)")
            args.addAll(criteria.selectedShelterStatuses)
        }

        // 6. استثناء من استلم خلال X يوماً (Exclusion Cutoff)
        if (criteria.exclusionDays != null && criteria.exclusionDays > 0) {
            val cal = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, -criteria.exclusionDays)
            }
            val cutoffDate = dateFormat.format(cal.time)
            whereClauses.add("""
                familyID NOT IN (
                    SELECT DISTINCT familyID FROM aid_records 
                    WHERE (deliveryDate >= ? OR aidDate >= ?)
                      AND (recipientStatus = 'مستلم' OR recipientStatus = 'مستفيد' OR deliveryDate IS NOT NULL)
                )
            """.trimIndent())
            args.add(cutoffDate)
            args.add(cutoffDate)
        }

        // 7. شرط الأطفال ونطاق أعمارهم
        when (criteria.childrenFilter) {
            ChildrenFilterMode.YES -> {
                if (criteria.minChildAge != null || criteria.maxChildAge != null) {
                    val minAge = criteria.minChildAge ?: 0
                    val maxAge = criteria.maxChildAge ?: 18
                    whereClauses.add("""
                        nationalID IN (
                            SELECT familyNationalID FROM children 
                            WHERE (CAST(strftime('%Y', 'now') AS INTEGER) - CAST(substr(birthDate, 1, 4) AS INTEGER)) BETWEEN ? AND ?
                        )
                    """.trimIndent())
                    args.add(minAge)
                    args.add(maxAge)
                } else {
                    whereClauses.add("nationalID IN (SELECT DISTINCT familyNationalID FROM children)")
                }
            }
            ChildrenFilterMode.NO -> {
                whereClauses.add("nationalID NOT IN (SELECT DISTINCT familyNationalID FROM children)")
            }
            ChildrenFilterMode.IGNORE -> {
                if (criteria.minChildAge != null || criteria.maxChildAge != null) {
                    val minAge = criteria.minChildAge ?: 0
                    val maxAge = criteria.maxChildAge ?: 18
                    whereClauses.add("""
                        nationalID IN (
                            SELECT familyNationalID FROM children 
                            WHERE (CAST(strftime('%Y', 'now') AS INTEGER) - CAST(substr(birthDate, 1, 4) AS INTEGER)) BETWEEN ? AND ?
                        )
                    """.trimIndent())
                    args.add(minAge)
                    args.add(maxAge)
                }
            }
        }

        // 8. الحد الأدنى لعدد أفراد الأسرة
        if (criteria.minFamilyMembers > 1) {
            whereClauses.add("familyMembersCount >= ?")
            args.add(criteria.minFamilyMembers)
        }

        val sql = buildString {
            append("SELECT * FROM families")
            if (whereClauses.isNotEmpty()) {
                append(" WHERE ")
                append(whereClauses.joinToString(" AND "))
            }
            append(" ORDER BY familyMembersCount DESC, familyID ASC")
            if (criteria.limit > 0) {
                append(" LIMIT ?")
                args.add(criteria.limit)
            }
        }

        return SimpleSQLiteQuery(sql, args.toTypedArray())
    }

    /**
     * تنفيذ محرك الفلترة والترشيح التفاعلي بالكامل عبر CoroutineScope(Dispatchers.IO)
     */
    suspend fun runDynamicNomination(
        criteria: DynamicNominationCriteria
    ): DynamicNominationResult = withContext(Dispatchers.IO) {
        val query = buildSupportQuery(criteria)
        val rawFamilies = database.familyDao().getFamiliesRaw(query)

        val localitiesMap = database.localityDao().getAllLocalitiesSync().associate { it.LocalityID to it.LocalityName }
        val distributions = database.localityDao().getDistributions().firstOrNull() ?: emptyList()
        val aidTypesMap = database.aidTypeDao().getAllActiveAidTypesSync().associate { it.aidTypeID to it.aidTypeName }

        val now = System.currentTimeMillis()
        val resultList = mutableListOf<DynamicCandidateModel>()

        // تتبع الحصص لتوليد تنبيهات اقتراب اكتمال حصة المنطقة
        val localityCounts = mutableMapOf<Int, Int>()

        for (family in rawFamilies) {
            val childrenCount = database.childDao().getChildrenCountForFamily(family.nationalID)
            val latestAid = database.aidRecordDao().getLastAidForFamily(family.familyID)

            var lastDateStr: String? = null
            var daysAgo: Long? = null
            var aidTypeName: String? = null

            if (latestAid != null) {
                lastDateStr = latestAid.deliveryDate ?: latestAid.aidDate
                aidTypeName = aidTypesMap[latestAid.aidTypeID] ?: "مساعدة #${latestAid.aidTypeID}"
                try {
                    val d = dateFormat.parse(lastDateStr)
                    if (d != null) {
                        daysAgo = TimeUnit.MILLISECONDS.toDays(now - d.time)
                    }
                } catch (_: Exception) {}
            }

            val locName = localitiesMap[family.localityID] ?: "محلية #${family.localityID}"
            val currentLocCount = localityCounts.getOrDefault(family.localityID, 0) + 1
            localityCounts[family.localityID] = currentLocCount

            // فحص حالة العائلة (مطابقة 100% أو تحذير)
            var status = CandidateStatus.MATCHED_100
            var warningReason: String? = null
            val auditList = mutableListOf<String>()

            auditList.add("✓ الثوابت الإجبارية: معتمد في التطوير (${family.developmentApproval}) ومقيم (${family.residentStatus})")

            if (criteria.exclusionDays != null && criteria.exclusionDays > 0) {
                if (daysAgo != null) {
                    auditList.add("✓ فحص تاريخ المساعدات: آخر استلام قبل $daysAgo يوماً (أكبر من حد الاستثناء المطلوب ${criteria.exclusionDays} يوماً)")
                } else {
                    auditList.add("✓ فحص تاريخ المساعدات: لم تسجل أي معونة سابقة لهذه الأسرة (أهلية تامة)")
                }
            }

            when (criteria.childrenFilter) {
                ChildrenFilterMode.YES -> auditList.add("✓ شرط الأطفال: يوجد أطفال لدى الأسرة (العدد: $childrenCount)")
                ChildrenFilterMode.NO -> auditList.add("✓ شرط الأطفال: لا يوجد أطفال لدى الأسرة (العدد: 0)")
                ChildrenFilterMode.IGNORE -> auditList.add("• شرط الأطفال: تم تجاهل الشرط (عدد الأطفال الحالي: $childrenCount)")
            }

            if (criteria.minChildAge != null || criteria.maxChildAge != null) {
                val ageRangeStr = "${criteria.minChildAge ?: 0} إلى ${criteria.maxChildAge ?: 18} سنة"
                auditList.add("✓ نطاق أعمار الأطفال: متوافق مع النطاق المطلوب ($ageRangeStr)")
            }

            if (criteria.selectedDamageTypes.isNotEmpty()) {
                auditList.add("✓ حالة الضرر: (${family.damageType}) مطابقة للخيارات المحددة")
            }
            if (criteria.selectedShelterStatuses.isNotEmpty()) {
                auditList.add("✓ حالة الإيواء: (${family.shelterStatus}) مطابقة للخيارات المحددة")
            }
            if (criteria.selectedWorksApprovals.isNotEmpty()) {
                auditList.add("✓ اعتماد الأشغال: (${family.worksApproval}) مطابقة للخيارات المحددة")
            }

            if (daysAgo != null && daysAgo < 45 && latestAid?.aidTypeID != criteria.selectedAidTypeId) {
                status = CandidateStatus.WARNING
                warningReason = "تنبيه: استلم مساعدة من نوع ($aidTypeName) قبل $daysAgo يوماً"
                auditList.add("⚠ تنبيه المدير: تم استلام مساعدة سابقة قريبة من نوع آخر ($aidTypeName) قبل $daysAgo يوماً")
            } else if (currentLocCount > 35) {
                status = CandidateStatus.WARNING
                warningReason = "تنبيه: اقتراب اكتمال حصة محلية ($locName) بالمرشحين"
                auditList.add("⚠ تنبيه المدير: الحصة الجغرافية المخصصة لمحلية ($locName) اقتربت من الاكتمال ($currentLocCount مرشح حتى الآن)")
            } else {
                auditList.add("✓ الحصة الجغرافية: محلية ($locName) ضمن السعة الاستيعابية المتاحة")
            }

            resultList.add(
                DynamicCandidateModel(
                    family = family,
                    status = status,
                    matchScore = if (status == CandidateStatus.MATCHED_100) 100.0 else 85.0,
                    childrenCount = childrenCount,
                    lastAidDate = lastDateStr,
                    lastAidTypeName = aidTypeName,
                    daysSinceLastAid = daysAgo,
                    localityName = locName,
                    warningReason = warningReason,
                    auditTrail = auditList
                )
            )
        }

        // جلب عينة من العائلات المستبعدة لإيضاح أسباب الاستبعاد في الواجهة باللون الأحمر
        if (criteria.exclusionDays != null && criteria.exclusionDays > 0) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -criteria.exclusionDays) }
            val cutoff = dateFormat.format(cal.time)
            val excludedQuery = SimpleSQLiteQuery("""
                SELECT f.* FROM families f
                INNER JOIN aid_records a ON f.familyID = a.familyID
                WHERE (f.developmentApproval = 'معتمد' OR f.developmentApproval LIKE '%معتمد%')
                  AND (f.residentStatus = 'مقيم' OR f.residentStatus LIKE '%مقيم%')
                  AND (a.deliveryDate >= '$cutoff' OR a.aidDate >= '$cutoff')
                GROUP BY f.familyID
                LIMIT 15
            """.trimIndent())
            val excludedFamilies = database.familyDao().getFamiliesRaw(excludedQuery)
            for (exFam in excludedFamilies) {
                val latest = database.aidRecordDao().getLastAidForFamily(exFam.familyID)
                val dStr = latest?.deliveryDate ?: latest?.aidDate ?: cutoff
                var dAgo = 5L
                try {
                    val d = dateFormat.parse(dStr)
                    if (d != null) dAgo = TimeUnit.MILLISECONDS.toDays(now - d.time).coerceAtLeast(1)
                } catch (_: Exception) {}

                val exAudit = listOf(
                    "✓ الثوابت الإجبارية: معتمد في التطوير ومقيم (مطابق)",
                    "✗ سبب الاستبعاد: استلم مساعدة سابقة بتاريخ $dStr (قبل $dAgo يوماً)",
                    "✗ الشرط المخالف: أقل من الحد الأدنى المسموح للاستفادة (${criteria.exclusionDays} يوماً)",
                    "✗ الإجراء: تم الاستبعاد آلياً بواسطة المحرك لمنع الازدواجية وضمان عدالة التوزيع"
                )

                resultList.add(
                    DynamicCandidateModel(
                        family = exFam,
                        status = CandidateStatus.EXCLUDED,
                        matchScore = 0.0,
                        childrenCount = database.childDao().getChildrenCountForFamily(exFam.nationalID),
                        lastAidDate = dStr,
                        lastAidTypeName = aidTypesMap[latest?.aidTypeID] ?: "معونة سابقة",
                        daysSinceLastAid = dAgo,
                        localityName = localitiesMap[exFam.localityID] ?: "محلية #${exFam.localityID}",
                        exclusionReason = "مستبعد - استلم قبل $dAgo يوماً (${dStr})",
                        auditTrail = exAudit
                    )
                )
            }
        }

        // حساب الحصص
        val totalQuotas = calculateLocalityQuotas(
            totalRequired = resultList.count { it.status != CandidateStatus.EXCLUDED },
            distributions = distributions,
            localitiesMap = localitiesMap
        )

        DynamicNominationResult(
            candidates = resultList,
            totalMatched = resultList.count { it.status != CandidateStatus.EXCLUDED },
            fullMatchCount = resultList.count { it.status == CandidateStatus.MATCHED_100 },
            warningCount = resultList.count { it.status == CandidateStatus.WARNING },
            excludedCount = resultList.count { it.status == CandidateStatus.EXCLUDED },
            quotas = totalQuotas,
            executedSql = query.sql
        )
    }

    /**
     * اعتماد الترشيح وحفظ العائلات المرشحة في tbl_Selected_Citizens
     */
    suspend fun approveNominationBatch(
        candidates: List<DynamicCandidateModel>,
        projectId: Long,
        aidTypeId: Int,
        userId: Int
    ): Int = withContext(Dispatchers.IO) {
        val todayStr = dateFormat.format(Date())
        val selectedEntities = candidates
            .filter { it.status != CandidateStatus.EXCLUDED }
            .map { cand ->
                SelectedCitizenEntity(
                    CitizenID = cand.family.familyID,
                    SelectionDate = todayStr,
                    ActualNominationDate = todayStr,
                    SelectionType = "محرك ديناميكي",
                    AidTypeID = aidTypeId,
                    ProjectID = projectId,
                    UserID = userId,
                    NominationNotes = "مرشح عبر محرك القواعد الديناميكي (درجة المطابقة: ${cand.matchScore}%)"
                )
            }

        database.nominationDao().insertSelectedCitizens(selectedEntities)
        selectedEntities.size
    }

    private fun calculateLocalityQuotas(
        totalRequired: Int,
        distributions: List<LocalityDistributionEntity>,
        localitiesMap: Map<Int, String>
    ): List<LocalityQuota> {
        if (distributions.isEmpty() || totalRequired <= 0) return emptyList()

        val totalPercentage = distributions.sumOf { it.distributionPercentage }
        val normalizedList = distributions.map { dist ->
            val effectivePercent = if (totalPercentage > 0) (dist.distributionPercentage / totalPercentage) * 100.0 else 0.0
            val exactFloatShare = (effectivePercent / 100.0) * totalRequired
            val floorShare = floor(exactFloatShare).toInt()
            val remainder = exactFloatShare - floorShare
            dist to Pair(floorShare, remainder)
        }

        var assignedTotal = normalizedList.sumOf { it.second.first }
        var deficit = totalRequired - assignedTotal

        val sortedByRemainder = normalizedList.sortedByDescending { it.second.second }.toMutableList()
        val finalAllocations = mutableMapOf<Int, Int>()
        for (item in sortedByRemainder) {
            val dist = item.first
            var share = item.second.first
            if (deficit > 0) {
                share += 1
                deficit -= 1
            }
            finalAllocations[dist.localityID] = share
        }

        return distributions.map { dist ->
            LocalityQuota(
                localityId = dist.localityID,
                localityName = localitiesMap[dist.localityID] ?: "محلية #${dist.localityID}",
                percentage = dist.distributionPercentage,
                allocatedCount = finalAllocations[dist.localityID] ?: 0
            )
        }
    }
}
