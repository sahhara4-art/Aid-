package com.humanitarian.aidmanagement.engine

import androidx.sqlite.db.SimpleSQLiteQuery
import androidx.sqlite.db.SupportSQLiteQuery
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.EligibleFamiliesView
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityDistributionEntity
import com.humanitarian.aidmanagement.data.local.entities.SelectedCitizenEntity
import com.humanitarian.aidmanagement.data.local.entities.toFamilyEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.floor

enum class ChildrenFilterMode(val label: String) {
    IGNORE("تجاهل"),
    YES("نعم (يوجد أطفال)"),
    NO("لا (بدون أطفال)")
}

enum class ExclusionMode(val label: String) {
    DAYS("بالأيام"),
    DATE("بتاريخ محدد")
}

data class DynamicNominationCriteria(
    val exclusionMode: ExclusionMode = ExclusionMode.DAYS,
    val exclusionDays: Int? = 30, // استثناء من استلم خلال X يوماً (أو null للتجاهل)
    val exclusionDateCutoff: String? = null, // أو تاريخ استثناء محدد YYYY-MM-DD
    val excludedAidTypeIds: Set<Int> = emptySet(), // تصنيفات المساعدات المستثناة (فارغ = جميع التصنيفات)
    val hasChildrenOnly: Boolean = false, // مفتاح تبديل: يوجد أطفال
    val minChildAge: Int? = null, // الحد الأدنى لعمر الأطفال
    val maxChildAge: Int? = null, // الحد الأقصى لعمر الأطفال
    val selectedDamageTypes: Set<String> = emptySet(), // خيارات متعددة ديناميكية لحالة الضرر
    val excludeDamageTypes: Boolean = false, // مفتاح استثناء حالة الضرر (NOT IN)
    val selectedMaritalStatuses: Set<String> = emptySet(), // خيارات متعددة ديناميكية للحالة الاجتماعية (أرملة، مطلقة...)
    val excludeMaritalStatuses: Boolean = false, // مفتاح استثناء الحالة الاجتماعية (NOT IN)
    val selectedWorksApprovals: Set<String> = emptySet(), // خيارات متعددة ديناميكية لاعتماد الأشغال
    val excludeWorksApprovals: Boolean = false, // مفتاح استثناء اعتماد الأشغال (NOT IN)
    val selectedShelterStatuses: Set<String> = emptySet(), // خيارات متعددة ديناميكية لحالة الإيواء
    val excludeShelterStatuses: Boolean = false, // مفتاح استثناء حالة الإيواء (NOT IN)
    val selectedIncomeSources: Set<String> = emptySet(), // خيارات متعددة ديناميكية لمصدر الدخل
    val excludeIncomeSources: Boolean = false, // مفتاح استثناء مصدر الدخل (NOT IN)
    val selectedInjuryStatuses: Set<String> = emptySet(), // خيارات متعددة ديناميكية لحالة الإصابة
    val excludeInjuryStatuses: Boolean = false, // مفتاح استثناء حالة الإصابة (NOT IN)
    val selectedSubAreas: Set<String> = emptySet(), // خيارات متعددة ديناميكية للمناطق الفرعية
    val excludeSubAreas: Boolean = false, // مفتاح استثناء المناطق الفرعية (NOT IN)
    val selectedLocalityId: Int? = 0, // 0 = كافة المحليات أو تقييد حسب الصلاحية
    val excludeLocality: Boolean = false, // مفتاح استثناء المحلية (NOT IN)
    val selectedAidTypeId: Int = 1, // تصنيف المساعدة المستهدفة للمشروع
    val projectId: Long = 1L, // المشروع المنفذ
    val minFamilyMembers: Int = 1,
    val limit: Int = 300,
    val targetBeneficiaries: Int = 100, // العدد المطلوب للمشروع
    val childrenFilter: ChildrenFilterMode = ChildrenFilterMode.IGNORE // للتوافق العكسي
)

enum class CandidateStatus {
    MATCHED_100, // مطابقة 100% للشروط المحددة (GreenSecondary)
    WARNING,     // تحذير: استلام قريب لنوع آخر أو اقتراب اكتمال الحصة (AmberWarning)
    EXCLUDED     // مستبعد: مع ذكر سبب الاستبعاد (RedError)
}

data class DynamicCandidateModel(
    val family: FamilyEntity,
    val status: CandidateStatus,
    val matchScore: Double,
    val childrenCount: Int = 0,
    val lastAidDate: String? = null,
    val lastAidTypeName: String? = null,
    val daysSinceLastAid: Long? = null,
    val localityName: String = "",
    val exclusionReason: String? = null,
    val warningReason: String? = null,
    val auditTrail: List<String> = emptyList()
)

data class DynamicNominationResult(
    val candidates: List<DynamicCandidateModel>,
    val totalMatched: Int,
    val fullMatchCount: Int,
    val warningCount: Int,
    val excludedCount: Int,
    val quotas: List<LocalityQuota> = emptyList(),
    val executedSql: String = ""
)

class DynamicNominationEngine(
    private val database: AidDatabase
) {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    /**
     * بناء استعلام SQL آمن وديناميكي عبر SupportSQLiteQuery (@RawQuery)
     * معتمد حصراً على EligibleFamiliesView (حالة التنمية = معتمد وَ حالة الإقامة = مقيم)
     * ويدعم التضمين IN (...) والاستثناء NOT IN (...) لجميع المعايير بناءً على مفاتيح التبديل
     */
    fun buildSupportQuery(criteria: DynamicNominationCriteria): SupportSQLiteQuery {
        val whereClauses = mutableListOf<String>()
        val args = mutableListOf<Any>()

        // 0. شرط منع التكرار الصارم للمشروع نفسه: استبعاد الأسرة تلقائياً إذا كانت قد استلمت مساعدة سابقة أو رُشحت لنفس هذا المشروع
        // مع السماح التام للأسرة بالترشيح إذا كان مشروعاً مختلفاً
        if (criteria.projectId > 0) {
            whereClauses.add("""
                familyID NOT IN (
                    SELECT a.familyID FROM aid_records a 
                    WHERE a.projectID = ?
                )
            """.trimIndent())
            args.add(criteria.projectId)
        }

        // 1. تصفية المحلية (تضمين أو استثناء)
        if (criteria.selectedLocalityId != null && criteria.selectedLocalityId > 0) {
            if (criteria.excludeLocality) {
                whereClauses.add("localityID != ?")
            } else {
                whereClauses.add("localityID = ?")
            }
            args.add(criteria.selectedLocalityId)
        }

        // 2. تصفية متعددة لحالة الضرر (IN أو NOT IN)
        if (criteria.selectedDamageTypes.isNotEmpty()) {
            val placeholders = criteria.selectedDamageTypes.joinToString(",") { "?" }
            if (criteria.excludeDamageTypes) {
                whereClauses.add("(damageType NOT IN ($placeholders) OR damageType IS NULL)")
            } else {
                whereClauses.add("damageType IN ($placeholders)")
            }
            args.addAll(criteria.selectedDamageTypes)
        }

        // 3. تصفية متعددة للحالة الاجتماعية (IN أو NOT IN)
        if (criteria.selectedMaritalStatuses.isNotEmpty()) {
            val placeholders = criteria.selectedMaritalStatuses.joinToString(",") { "?" }
            if (criteria.excludeMaritalStatuses) {
                whereClauses.add("(maritalStatus NOT IN ($placeholders) OR maritalStatus IS NULL)")
            } else {
                whereClauses.add("maritalStatus IN ($placeholders)")
            }
            args.addAll(criteria.selectedMaritalStatuses)
        }

        // 4. تصفية متعددة لاعتماد الأشغال (IN أو NOT IN)
        if (criteria.selectedWorksApprovals.isNotEmpty()) {
            val placeholders = criteria.selectedWorksApprovals.joinToString(",") { "?" }
            if (criteria.excludeWorksApprovals) {
                whereClauses.add("(worksApproval NOT IN ($placeholders) OR worksApproval IS NULL)")
            } else {
                whereClauses.add("worksApproval IN ($placeholders)")
            }
            args.addAll(criteria.selectedWorksApprovals)
        }

        // 5. تصفية متعددة لحالة الإيواء مع دعم 'بدون تصنيف' (IN أو NOT IN)
        if (criteria.selectedShelterStatuses.isNotEmpty()) {
            val includesUnclassified = criteria.selectedShelterStatuses.contains("بدون تصنيف")
            val normalStatuses = criteria.selectedShelterStatuses.filter { it != "بدون تصنيف" }

            if (criteria.excludeShelterStatuses) {
                if (normalStatuses.isNotEmpty()) {
                    val placeholders = normalStatuses.joinToString(",") { "?" }
                    if (includesUnclassified) {
                        whereClauses.add("(shelterStatus NOT IN ($placeholders) AND shelterStatus IS NOT NULL AND shelterStatus != '' AND shelterStatus != 'بدون تصنيف')")
                    } else {
                        whereClauses.add("(shelterStatus NOT IN ($placeholders) OR shelterStatus IS NULL OR shelterStatus = '' OR shelterStatus = 'بدون تصنيف')")
                    }
                    args.addAll(normalStatuses)
                } else if (includesUnclassified) {
                    whereClauses.add("(shelterStatus IS NOT NULL AND shelterStatus != '' AND shelterStatus != 'بدون تصنيف')")
                }
            } else {
                val shelterParts = mutableListOf<String>()
                if (normalStatuses.isNotEmpty()) {
                    val placeholders = normalStatuses.joinToString(",") { "?" }
                    shelterParts.add("shelterStatus IN ($placeholders)")
                    args.addAll(normalStatuses)
                }
                if (includesUnclassified) {
                    shelterParts.add("(shelterStatus IS NULL OR shelterStatus = '' OR shelterStatus = 'بدون تصنيف')")
                }
                if (shelterParts.isNotEmpty()) {
                    whereClauses.add("(${shelterParts.joinToString(" OR ")})")
                }
            }
        }

        // 6. تصفية متعددة لمصدر الدخل (IN أو NOT IN)
        if (criteria.selectedIncomeSources.isNotEmpty()) {
            val placeholders = criteria.selectedIncomeSources.joinToString(",") { "?" }
            if (criteria.excludeIncomeSources) {
                whereClauses.add("(incomeSource1 NOT IN ($placeholders) OR incomeSource1 IS NULL)")
            } else {
                whereClauses.add("incomeSource1 IN ($placeholders)")
            }
            args.addAll(criteria.selectedIncomeSources)
        }

        // 7. تصفية متعددة لحالة الإصابة (IN أو NOT IN)
        if (criteria.selectedInjuryStatuses.isNotEmpty()) {
            val placeholders = criteria.selectedInjuryStatuses.joinToString(",") { "?" }
            if (criteria.excludeInjuryStatuses) {
                whereClauses.add("(injuryStatus NOT IN ($placeholders) OR injuryStatus IS NULL)")
            } else {
                whereClauses.add("injuryStatus IN ($placeholders)")
            }
            args.addAll(criteria.selectedInjuryStatuses)
        }

        // 8. تصفية متعددة للمناطق الفرعية (IN أو NOT IN)
        if (criteria.selectedSubAreas.isNotEmpty()) {
            val placeholders = criteria.selectedSubAreas.joinToString(",") { "?" }
            if (criteria.excludeSubAreas) {
                whereClauses.add("(currentSubArea NOT IN ($placeholders) OR currentSubArea IS NULL)")
            } else {
                whereClauses.add("currentSubArea IN ($placeholders)")
            }
            args.addAll(criteria.selectedSubAreas)
        }

        // 9. استثناء زمني ومكاني: بالأيام أو بتاريخ محدد مع تصنيفات المساعدات المستثناة
        val cutoffDate: String? = when (criteria.exclusionMode) {
            ExclusionMode.DAYS -> {
                if (criteria.exclusionDays != null && criteria.exclusionDays > 0) {
                    val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -criteria.exclusionDays) }
                    dateFormat.format(cal.time)
                } else null
            }
            ExclusionMode.DATE -> {
                criteria.exclusionDateCutoff?.takeIf { it.isNotBlank() }
            }
        }

        if (cutoffDate != null) {
            val aidTypeCondition = if (criteria.excludedAidTypeIds.isNotEmpty()) {
                val placeholders = criteria.excludedAidTypeIds.joinToString(",") { "?" }
                "AND aidTypeID IN ($placeholders)"
            } else ""

            whereClauses.add("""
                familyID NOT IN (
                    SELECT DISTINCT familyID FROM aid_records 
                    WHERE (deliveryDate >= ? OR aidDate >= ?)
                      AND (recipientStatus = 'مستلم' OR recipientStatus = 'مستفيد' OR deliveryDate IS NOT NULL)
                      $aidTypeCondition
                )
            """.trimIndent())
            args.add(cutoffDate)
            args.add(cutoffDate)
            if (criteria.excludedAidTypeIds.isNotEmpty()) {
                args.addAll(criteria.excludedAidTypeIds)
            }
        }

        // 10. شرط الأطفال ونطاق أعمارهم عبر جدول children
        val hasChildrenActive = criteria.hasChildrenOnly || criteria.childrenFilter == ChildrenFilterMode.YES
        if (hasChildrenActive) {
            if (criteria.minChildAge != null || criteria.maxChildAge != null) {
                val minAge = criteria.minChildAge ?: 0
                val maxAge = criteria.maxChildAge ?: 18
                whereClauses.add("""
                    nationalID IN (
                        SELECT familyNationalID FROM children 
                        WHERE (CAST(strftime('%Y', 'now') AS INTEGER) - CAST(substr(birthDate, 1, 4) AS INTEGER)) BETWEEN ? AND ?
                    )
                """.trimIndent())
                args.add(minAge)
                args.add(maxAge)
            } else {
                whereClauses.add("nationalID IN (SELECT DISTINCT familyNationalID FROM children)")
            }
        } else if (criteria.childrenFilter == ChildrenFilterMode.NO) {
            whereClauses.add("nationalID NOT IN (SELECT DISTINCT familyNationalID FROM children)")
        }

        // 11. الحد الأدنى لعدد أفراد الأسرة
        if (criteria.minFamilyMembers > 1) {
            whereClauses.add("familyMembersCount >= ?")
            args.add(criteria.minFamilyMembers)
        }

        val sql = buildString {
            append("SELECT * FROM EligibleFamiliesView")
            if (whereClauses.isNotEmpty()) {
                append(" WHERE ")
                append(whereClauses.joinToString(" AND "))
            }
            append(" ORDER BY familyMembersCount DESC, familyID ASC")
            if (criteria.limit > 0) {
                append(" LIMIT ?")
                args.add(criteria.limit)
            }
        }

        return SimpleSQLiteQuery(sql, args.toTypedArray())
    }

    /**
     * تنفيذ محرك الفلترة والترشيح التفاعلي بالكامل عبر CoroutineScope(Dispatchers.IO)
     */
    suspend fun runDynamicNomination(
        criteria: DynamicNominationCriteria
    ): DynamicNominationResult = withContext(Dispatchers.IO) {
        val query = buildSupportQuery(criteria)
        val rawFamilies = database.eligibleFamiliesDao().queryEligibleFamiliesRawSync(query).map { it.toFamilyEntity() }

        val localitiesMap = database.localityDao().getAllLocalitiesSync().associate { it.LocalityID to it.LocalityName }
        val distributions = database.localityDao().getDistributions().firstOrNull() ?: emptyList()
        val aidTypesMap = database.aidTypeDao().getAllActiveAidTypesSync().associate { it.aidTypeID to it.aidTypeName }

        val now = System.currentTimeMillis()
        val resultList = mutableListOf<DynamicCandidateModel>()

        // تتبع الحصص لتوليد تنبيهات اقتراب اكتمال حصة المنطقة
        val localityCounts = mutableMapOf<Int, Int>()

        for (family in rawFamilies) {
            val childrenCount = database.childDao().getChildrenCountForFamily(family.nationalID)
            val latestAid = database.aidRecordDao().getLastAidForFamily(family.familyID)

            var lastDateStr: String? = null
            var daysAgo: Long? = null
            var aidTypeName: String? = null

            if (latestAid != null) {
                lastDateStr = latestAid.deliveryDate ?: latestAid.aidDate
                aidTypeName = aidTypesMap[latestAid.aidTypeID] ?: "مساعدة #${latestAid.aidTypeID}"
                try {
                    val d = dateFormat.parse(lastDateStr)
                    if (d != null) {
                        daysAgo = TimeUnit.MILLISECONDS.toDays(now - d.time)
                    }
                } catch (_: Exception) {}
            }

            val locName = localitiesMap[family.localityID] ?: "محلية #${family.localityID}"
            val currentLocCount = localityCounts.getOrDefault(family.localityID, 0) + 1
            localityCounts[family.localityID] = currentLocCount

            // فحص حالة العائلة (مطابقة 100% أو تحذير)
            var status = CandidateStatus.MATCHED_100
            var warningReason: String? = null
            val auditList = mutableListOf<String>()

            auditList.add("✓ الأهلية الصارمة عبر EligibleFamiliesView: معتمد ومقيم")

            if (criteria.exclusionDays != null && criteria.exclusionDays > 0) {
                if (daysAgo != null) {
                    auditList.add("✓ فحص تاريخ المساعدات: آخر استلام قبل $daysAgo يوماً (أكبر من حد الاستثناء المطلوب ${criteria.exclusionDays} يوماً)")
                } else {
                    auditList.add("✓ فحص تاريخ المساعدات: لم تسجل أي معونة سابقة لهذه الأسرة (أهلية تامة)")
                }
            }

            when (criteria.childrenFilter) {
                ChildrenFilterMode.YES -> auditList.add("✓ شرط الأطفال: يوجد أطفال لدى الأسرة (العدد: $childrenCount)")
                ChildrenFilterMode.NO -> auditList.add("✓ شرط الأطفال: لا يوجد أطفال لدى الأسرة (العدد: 0)")
                ChildrenFilterMode.IGNORE -> auditList.add("• شرط الأطفال: تم تجاهل الشرط (عدد الأطفال الحالي: $childrenCount)")
            }

            if (criteria.minChildAge != null || criteria.maxChildAge != null) {
                val ageRangeStr = "${criteria.minChildAge ?: 0} إلى ${criteria.maxChildAge ?: 18} سنة"
                auditList.add("✓ نطاق أعمار الأطفال: متوافق مع النطاق المطلوب ($ageRangeStr)")
            }

            if (criteria.selectedDamageTypes.isNotEmpty()) {
                val modeText = if (criteria.excludeDamageTypes) "مستبعدة من" else "ضمن"
                auditList.add("✓ حالة الضرر: (${family.damageType}) $modeText الخيارات المحددة")
            }
            if (criteria.selectedMaritalStatuses.isNotEmpty()) {
                val modeText = if (criteria.excludeMaritalStatuses) "مستبعدة من" else "ضمن"
                auditList.add("✓ الحالة الاجتماعية: (${family.maritalStatus}) $modeText الخيارات المحددة")
            }
            if (criteria.selectedShelterStatuses.isNotEmpty()) {
                val modeText = if (criteria.excludeShelterStatuses) "مستبعدة من" else "ضمن"
                auditList.add("✓ حالة الإيواء: (${family.shelterStatus}) $modeText الخيارات المحددة")
            }
            if (criteria.selectedWorksApprovals.isNotEmpty()) {
                val modeText = if (criteria.excludeWorksApprovals) "مستبعدة من" else "ضمن"
                auditList.add("✓ اعتماد الأشغال: (${family.worksApproval}) $modeText الخيارات المحددة")
            }

            if (daysAgo != null && daysAgo < 45 && latestAid?.aidTypeID != criteria.selectedAidTypeId) {
                status = CandidateStatus.WARNING
                warningReason = "تنبيه: استلم مساعدة من نوع ($aidTypeName) قبل $daysAgo يوماً"
                auditList.add("⚠ تنبيه المدير: تم استلام مساعدة سابقة قريبة من نوع آخر ($aidTypeName) قبل $daysAgo يوماً")
            } else if (currentLocCount > 35) {
                status = CandidateStatus.WARNING
                warningReason = "تنبيه: اقتراب اكتمال حصة محلية ($locName) بالمرشحين"
                auditList.add("⚠ تنبيه المدير: الحصة الجغرافية المخصصة لمحلية ($locName) اقتربت من الاكتمال ($currentLocCount مرشح حتى الآن)")
            } else {
                auditList.add("✓ الحصة الجغرافية: محلية ($locName) ضمن السعة الاستيعابية المتاحة")
            }

            resultList.add(
                DynamicCandidateModel(
                    family = family,
                    status = status,
                    matchScore = if (status == CandidateStatus.MATCHED_100) 100.0 else 85.0,
                    childrenCount = childrenCount,
                    lastAidDate = lastDateStr,
                    lastAidTypeName = aidTypeName,
                    daysSinceLastAid = daysAgo,
                    localityName = locName,
                    warningReason = warningReason,
                    auditTrail = auditList
                )
            )
        }

        // جلب عينة من العائلات المستبعدة لإيضاح أسباب الاستبعاد في الواجهة باللون الأحمر
        if (criteria.exclusionDays != null && criteria.exclusionDays > 0) {
            val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -criteria.exclusionDays) }
            val cutoff = dateFormat.format(cal.time)
            val excludedQuery = SimpleSQLiteQuery("""
                SELECT f.* FROM EligibleFamiliesView f
                INNER JOIN aid_records a ON f.familyID = a.familyID
                WHERE (a.deliveryDate >= '$cutoff' OR a.aidDate >= '$cutoff')
                GROUP BY f.familyID
                LIMIT 15
            """.trimIndent())
            val excludedFamilies = database.eligibleFamiliesDao().queryEligibleFamiliesRawSync(excludedQuery).map { it.toFamilyEntity() }
            for (exFam in excludedFamilies) {
                val latest = database.aidRecordDao().getLastAidForFamily(exFam.familyID)
                val dStr = latest?.deliveryDate ?: latest?.aidDate ?: cutoff
                var dAgo = 5L
                try {
                    val d = dateFormat.parse(dStr)
                    if (d != null) dAgo = TimeUnit.MILLISECONDS.toDays(now - d.time).coerceAtLeast(1)
                } catch (_: Exception) {}

                val exAudit = listOf(
                    "✓ الأهلية: مسجل في EligibleFamiliesView (معتمد ومقيم)",
                    "✗ سبب الاستبعاد: استلم مساعدة سابقة بتاريخ $dStr (قبل $dAgo يوماً)",
                    "✗ الشرط المخالف: أقل من الحد الأدنى المسموح للاستفادة (${criteria.exclusionDays} يوماً)",
                    "✗ الإجراء: تم الاستبعاد آلياً بواسطة المحرك لمنع الازدواجية وضمان عدالة التوزيع"
                )

                resultList.add(
                    DynamicCandidateModel(
                        family = exFam,
                        status = CandidateStatus.EXCLUDED,
                        matchScore = 0.0,
                        childrenCount = database.childDao().getChildrenCountForFamily(exFam.nationalID),
                        lastAidDate = dStr,
                        lastAidTypeName = aidTypesMap[latest?.aidTypeID] ?: "معونة سابقة",
                        daysSinceLastAid = dAgo,
                        localityName = localitiesMap[exFam.localityID] ?: "محلية #${exFam.localityID}",
                        exclusionReason = "مستبعد - استلم قبل $dAgo يوماً (${dStr})",
                        auditTrail = exAudit
                    )
                )
            }
        }

        // جلب عينة من العائلات المستبعدة بسبب الاستفادة المسبقة من نفس المشروع (منع التكرار)
        if (criteria.projectId > 0) {
            val duplicateQuery = SimpleSQLiteQuery("""
                SELECT f.* FROM EligibleFamiliesView f
                INNER JOIN aid_records a ON f.familyID = a.familyID
                WHERE a.projectID = ${criteria.projectId}
                GROUP BY f.familyID
                LIMIT 10
            """.trimIndent())
            val dupFamilies = database.eligibleFamiliesDao().queryEligibleFamiliesRawSync(duplicateQuery).map { it.toFamilyEntity() }
            for (dupFam in dupFamilies) {
                if (resultList.none { it.family.familyID == dupFam.familyID }) {
                    val rec = database.aidRecordDao().getAidRecordForFamilyAndProject(dupFam.familyID, criteria.projectId)
                    val recDate = rec?.deliveryDate ?: rec?.aidDate ?: "مسجل"
                    val dupAudit = listOf(
                        "✓ الأهلية العامة: مسجل ومعتمد في النظام",
                        "✗ سبب الاستبعاد: مستفيد مسبقاً من نفس المشروع (#${criteria.projectId}) بتاريخ $recDate",
                        "✓ قاعدة منع التكرار: استبعاد آلي لمنع تكرار صرف نفس المشروع لنفس الأسرة",
                        "• ملحوظة: يحق للأسرة الاستفادة من أي مشاريع أخرى مختلفة"
                    )
                    resultList.add(
                        DynamicCandidateModel(
                            family = dupFam,
                            status = CandidateStatus.EXCLUDED,
                            matchScore = 0.0,
                            childrenCount = database.childDao().getChildrenCountForFamily(dupFam.nationalID),
                            lastAidDate = recDate,
                            lastAidTypeName = aidTypesMap[criteria.selectedAidTypeId] ?: "نفس المشروع",
                            daysSinceLastAid = null,
                            localityName = localitiesMap[dupFam.localityID] ?: "محلية #${dupFam.localityID}",
                            exclusionReason = "مستبعد تلقائياً: مستفيد مسبقاً من نفس المشروع (#${criteria.projectId})",
                            auditTrail = dupAudit
                        )
                    )
                }
            }
        }

        // حساب الحصص الجغرافية بناءً على المعادلة المطلوبة: (العدد المطلوب * (المعتمد في المحلية / إجمالي المعتمد))
        val targetBenf = if (criteria.targetBeneficiaries > 0) criteria.targetBeneficiaries else resultList.count { it.status != CandidateStatus.EXCLUDED }
        val totalQuotas = calculateLocalityQuotas(
            totalRequired = targetBenf,
            localitiesMap = localitiesMap
        )

        DynamicNominationResult(
            candidates = resultList,
            totalMatched = resultList.count { it.status != CandidateStatus.EXCLUDED },
            fullMatchCount = resultList.count { it.status == CandidateStatus.MATCHED_100 },
            warningCount = resultList.count { it.status == CandidateStatus.WARNING },
            excludedCount = resultList.count { it.status == CandidateStatus.EXCLUDED },
            quotas = totalQuotas,
            executedSql = query.sql
        )
    }

    /**
     * اعتماد وترحيل المرشحين رسمياً وقفل الترشيح:
     * حفظ العائلات المرشحة في tbl_Selected_Citizens وتوليد سجلات الصرف في aid_records
     */
    suspend fun approveNominationBatch(
        candidates: List<DynamicCandidateModel>,
        projectId: Long,
        aidTypeId: Int,
        userId: Int,
        notes: String? = null
    ): Int = withContext(Dispatchers.IO) {
        val prj = database.projectDao().getProjectById(projectId)
        if (prj?.isLocked == true) {
            throw IllegalStateException("المشروع مقفل ولا يمكن إضافة ترشيحات جديدة له")
        }

        val eligibleCandidates = candidates.filter { it.status != CandidateStatus.EXCLUDED && it.family.familyID > 0 }

        // فحص صارم لمنع تكرار المساعدة: استبعاد أي أسرة مسجلة مسبقاً في نفس المشروع (familyId + projectId)
        val nonDuplicateCandidates = eligibleCandidates.filter { cand ->
            !database.aidRecordDao().checkIfAidExists(cand.family.familyID, projectId)
        }

        val selectedEntities = nonDuplicateCandidates.map { cand ->
            SelectedCitizenEntity(
                CitizenID = cand.family.familyID,
                SelectionDate = todayStr,
                ActualNominationDate = todayStr,
                SelectionType = "محرك ديناميكي ذكي",
                AidTypeID = aidTypeId,
                ProjectID = projectId,
                UserID = userId,
                NominationNotes = notes ?: "مرشح عبر محرك القواعد الديناميكي (درجة المطابقة: ${cand.matchScore}%)"
            )
        }

        database.nominationDao().insertSelectedCitizens(selectedEntities)

        // ترحيل وإرسال السجلات لجدول التسليم والصرف (tbl_Aid_Records) بحالة معتمد للصرف
        val aidRecordEntities = nonDuplicateCandidates.map { cand ->
            AidRecordEntity(
                familyID = cand.family.familyID,
                aidTypeID = aidTypeId,
                projectID = projectId,
                aidDate = todayStr,
                selectionDate = todayStr,
                deliveryDate = null,
                recipientStatus = "معتمد للترحيل والتسليم",
                warehouse = "المستودع الرئيسي",
                aidValue = 50.0,
                notes = "مشروع #$projectId - ${cand.localityName} | ${notes ?: "مرشح ومعتمد آلياً"}"
            )
        }
        if (aidRecordEntities.isNotEmpty()) {
            database.aidRecordDao().insertAidRecords(aidRecordEntities)
        }

        selectedEntities.size
    }

    /**
     * حساب الحصص الجغرافية للمحليات بناءً على المعادلة الرسمية من EligibleFamiliesView حصراً:
     * الحصة = العدد المطلوب * (COUNT(المحلية في EligibleFamiliesView) / إجمالي الأسر في EligibleFamiliesView)
     */
    suspend fun calculateLocalityQuotas(
        totalRequired: Int,
        localitiesMap: Map<Int, String>
    ): List<LocalityQuota> = withContext(Dispatchers.IO) {
        if (totalRequired <= 0) return@withContext emptyList()

        // استخراج الحصص والنسب الرياضية حصراً عبر EligibleFamiliesView: (COUNT(المحلية) / إجمالي الأسر في EligibleFamiliesView) * 100
        val shares = database.eligibleFamiliesDao().getLocalitySharesSync()
        if (shares.isEmpty()) return@withContext emptyList()

        val rawCalculations = shares.map { share ->
            val exactShare = (share.percentage / 100.0) * totalRequired
            val floorShare = floor(exactShare).toInt()
            val remainder = exactShare - floorShare
            Triple(share, floorShare, remainder)
        }

        val assignedTotal = rawCalculations.sumOf { it.second }
        var deficit = totalRequired - assignedTotal
        val sortedByRemainder = rawCalculations.sortedByDescending { it.third }

        val finalAllocations = mutableMapOf<Int, Int>()
        for (item in sortedByRemainder) {
            val share = item.first
            var count = item.second
            if (deficit > 0) {
                count += 1
                deficit -= 1
            }
            finalAllocations[share.localityId] = count
        }

        shares.map { share ->
            LocalityQuota(
                localityId = share.localityId,
                localityName = share.localityName.ifEmpty { localitiesMap[share.localityId] ?: "محلية #${share.localityId}" },
                percentage = kotlin.math.round(share.percentage * 10.0) / 10.0,
                allocatedCount = finalAllocations[share.localityId] ?: 0
            )
        }
    }
}
