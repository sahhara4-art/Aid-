package com.humanitarian.aidmanagement.ui.screens.families

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.SyncDetailsDialog
import com.humanitarian.aidmanagement.ui.components.SyncStatusBanner
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun FamiliesScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToFamilyDetails: (Long) -> Unit = {},
    onNavigateToExcel: () -> Unit = {}
) {
    val currentUser = repository.getCurrentUser()
    val isLocalityRestricted = (currentUser?.AllowedLocalityID ?: 0) != 0 && !repository.isSuperAdmin()
    val allowedLocalityId = currentUser?.AllowedLocalityID ?: 0

    val viewModel: FamiliesViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = FamiliesViewModel.Factory(repository)
    )
    val uiState by viewModel.uiState.collectAsState()
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedLocalityId by remember { mutableStateOf(if (isLocalityRestricted) allowedLocalityId else 0) }
    var selectedShelterStatus by remember { mutableStateOf("") }
    var selectedFamilyForDetails by remember { mutableStateOf<FamilyEntity?>(null) }
    var selectedFamilyForEdit by remember { mutableStateOf<FamilyEntity?>(null) }
    var familyToDelete by remember { mutableStateOf<FamilyEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showSyncDialog by remember { mutableStateOf(false) }
    val syncState by repository.getSyncState().collectAsState()

    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val allowedLocalities = remember(localities, currentUser) {
        if (isLocalityRestricted) {
            localities.filter { it.LocalityID == allowedLocalityId }
        } else {
            localities.filter { repository.canAccessLocality(it.LocalityID) }
        }
    }

    LaunchedEffect(isLocalityRestricted, allowedLocalityId) {
        if (isLocalityRestricted && allowedLocalityId != 0) {
            selectedLocalityId = allowedLocalityId
            viewModel.onLocalitySelected(allowedLocalityId)
        }
    }

    val shouldLoadMore by remember {
        derivedStateOf {
            val totalItems = listState.layoutInfo.totalItemsCount
            val lastVisibleItemIndex = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisibleItemIndex >= totalItems - 4
        }
    }

    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore && uiState.hasMorePages && !uiState.isLoadingMore) {
            viewModel.loadNextPage()
        }
    }

    val scope = rememberCoroutineScope()
    val canAddFamily = repository.hasPermission("families_create") && allowedLocalities.isNotEmpty()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "سجل الأسر والمستفيدين",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                if (uiState.totalCount > 0) "عرض ${uiState.families.size} من أصل ${uiState.totalCount} أسرة" else "${uiState.families.size} أسرة مسجلة",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = { showSyncDialog = true }) {
                            Icon(
                                imageVector = if (syncState.isOnline) Icons.Default.CloudSync else Icons.Default.CloudOff,
                                contentDescription = "التزامن والعمل دون اتصال",
                                tint = if (syncState.isOnline) MaterialTheme.colorScheme.primary else Color(0xFFF59E0B)
                            )
                        }
                        if (canAddFamily) {
                            IconButton(onClick = { showAddDialog = true }) {
                                Icon(Icons.Default.PersonAdd, contentDescription = "إضافة أسرة", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            floatingActionButton = {
                if (canAddFamily) {
                    ExtendedFloatingActionButton(
                        onClick = { showAddDialog = true },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        icon = { Icon(Icons.Default.Add, contentDescription = null) },
                        text = { Text("إضافة أسرة جديدة", fontWeight = FontWeight.Bold) }
                    )
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // شريط التزامن المصغر
                SyncStatusBanner(
                    repository = repository,
                    onOpenSyncDetails = { showSyncDialog = true }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // مربع البحث السريع
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = {
                        searchQuery = it
                        viewModel.onSearchQueryChanged(it)
                    },
                    placeholder = { Text("ابحث بالاسم الرباعي أو برقم الهوية الوطنية...", style = MaterialTheme.typography.bodyMedium) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = {
                                searchQuery = ""
                                viewModel.onSearchQueryChanged("")
                            }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // قائمة منسدلة ديناميكية لتصفية المحليات (Dynamic Data-Driven DropdownMenu)
                var localityFilterExpanded by remember { mutableStateOf(false) }
                val currentLocalityName = remember(selectedLocalityId, allowedLocalities) {
                    if (selectedLocalityId == 0) "كل المحليات (${allowedLocalities.size})"
                    else allowedLocalities.find { it.LocalityID == selectedLocalityId }?.LocalityName ?: "محلية #$selectedLocalityId"
                }

                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = currentLocalityName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("المحلية المحددة للعرض والتصفية") },
                        trailingIcon = {
                            IconButton(onClick = { localityFilterExpanded = !localityFilterExpanded }) {
                                Icon(
                                    imageVector = if (localityFilterExpanded) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { localityFilterExpanded = true },
                        shape = RoundedCornerShape(12.dp)
                    )

                    DropdownMenu(
                        expanded = localityFilterExpanded,
                        onDismissRequest = { localityFilterExpanded = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        if (!isLocalityRestricted) {
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("كل المحليات (${allowedLocalities.size})", fontWeight = if (selectedLocalityId == 0) FontWeight.Bold else FontWeight.Normal)
                                        if (selectedLocalityId == 0) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                        }
                                    }
                                },
                                onClick = {
                                    selectedLocalityId = 0
                                    viewModel.onLocalitySelected(0)
                                    localityFilterExpanded = false
                                }
                            )
                        }

                        if (allowedLocalities.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("لا توجد بيانات محليات مسجلة", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                                onClick = { localityFilterExpanded = false },
                                enabled = false
                            )
                        } else {
                            allowedLocalities.forEach { loc ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(loc.LocalityName, fontWeight = if (selectedLocalityId == loc.LocalityID) FontWeight.Bold else FontWeight.Normal)
                                            if (selectedLocalityId == loc.LocalityID) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    },
                                    onClick = {
                                        selectedLocalityId = loc.LocalityID
                                        viewModel.onLocalitySelected(loc.LocalityID)
                                        localityFilterExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // شريط تصفية المحليات السريع
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!isLocalityRestricted) {
                        item {
                            FilterChip(
                                selected = selectedLocalityId == 0,
                                onClick = {
                                    selectedLocalityId = 0
                                    viewModel.onLocalitySelected(0)
                                },
                                label = { Text("كل المحليات (${allowedLocalities.size})", fontWeight = if (selectedLocalityId == 0) FontWeight.Bold else FontWeight.Normal) },
                                shape = RoundedCornerShape(10.dp)
                            )
                        }
                    }
                    items(allowedLocalities, key = { it.LocalityID }) { loc ->
                        FilterChip(
                            selected = selectedLocalityId == loc.LocalityID,
                            onClick = {
                                selectedLocalityId = loc.LocalityID
                                viewModel.onLocalitySelected(loc.LocalityID)
                            },
                            label = { Text(loc.LocalityName, fontWeight = if (selectedLocalityId == loc.LocalityID) FontWeight.Bold else FontWeight.Normal) },
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // قائمة البطاقات المعتمدة على الـ Pagination (50 أسرة في كل دفعة لمنع استنزاف الذاكرة)
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 80.dp)
                ) {
                    if (uiState.families.isEmpty() && !uiState.isLoading) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 48.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Default.PersonSearch,
                                        contentDescription = null,
                                        modifier = Modifier.size(52.dp),
                                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "لا توجد أسر مطابقة للبحث أو المحلية المصرح بها",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                            }
                        }
                    } else {
                        items(uiState.families, key = { it.familyID }) { family ->
                            val locName = localities.find { it.LocalityID == family.localityID }?.LocalityName
                                ?: family.currentSubArea.ifBlank { "محلية #${family.localityID}" }
                            val canModify = repository.canModifyFamily(family)
                            val canDelete = repository.canDeleteFamily(family)

                            FamilyCardItem(
                                family = family,
                                localityName = locName,
                                canEdit = canModify,
                                canDelete = canDelete,
                                onClick = { onNavigateToFamilyDetails(family.familyID) },
                                onEdit = { selectedFamilyForEdit = family },
                                onDelete = { familyToDelete = family },
                                modifier = Modifier.animateItemPlacement(
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioLowBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                )
                            )
                        }

                        // مؤشر تحميل الدفعة التالية تلقائياً عند السحب لأسفل (Lazy Pre-fetching)
                        if (uiState.isLoadingMore) {
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(24.dp),
                                        strokeWidth = 2.5.dp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        "جاري تحميل الدفعة التالية (50 أسرة)...",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else if (uiState.hasMorePages) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    OutlinedButton(
                                        onClick = { viewModel.loadNextPage() },
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.ExpandMore, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        val remaining = uiState.totalCount - uiState.families.size
                                        Text("تحميل المزيد من الأسر (متبقي $remaining)")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // نافذة تفاصيل الأسرة
        if (selectedFamilyForDetails != null) {
            val f = selectedFamilyForDetails!!
            val locName = localities.find { it.LocalityID == f.localityID }?.LocalityName ?: "محلية #${f.localityID}"
            AlertDialog(
                onDismissRequest = { selectedFamilyForDetails = null },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.FamilyRestroom, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = f.name,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DetailRow("رقم الهوية الوطنية:", f.nationalID)
                        DetailRow("المحلية والمنطقة:", locName)
                        DetailRow("عدد أفراد الأسرة:", "${f.familyMembersCount} أفراد")
                        DetailRow("الحالة الاجتماعية:", "${f.maritalStatus} (${f.gender})")
                        DetailRow("اسم الزوجة:", f.wifeName ?: "غير مسجل")
                        DetailRow("رقم البطاقة التموينية:", f.rationCardNumber ?: "غير مسجل")
                        DetailRow("اعتماد التنمية الاجتماعية:", f.developmentApproval)
                        DetailRow("اعتماد وزارة الأشغال:", f.worksApproval)
                        DetailRow("حالة الإقامة:", f.residentStatus)
                        DetailRow("نوع الضرر المسجل:", f.damageType)
                        DetailRow("حالة الإيواء الحالية:", f.shelterStatus)
                        DetailRow("العنوان التفصيلي:", listOf(f.currentMainArea, f.currentSubArea, f.currentBranch, f.currentMosque).filter { it.isNotBlank() }.joinToString(" - ").ifEmpty { locName })
                        DetailRow("رقم الجوال:", f.primaryPhone.ifBlank { "غير مسجل" })
                        val altPhone = f.alternative_phone_1
                        if (!altPhone.isNullOrBlank()) {
                            DetailRow("جوال بديل:", altPhone)
                        }
                        val familyNotes = f.notes
                        if (!familyNotes.isNullOrBlank()) {
                            DetailRow("ملاحظات:", familyNotes)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { selectedFamilyForDetails = null },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إغلاق")
                    }
                }
            )
        }

        // نافذة إضافة أسرة جديدة شاملة لكافة الحقول الـ 36
        if (showAddDialog) {
            AddEditFamilyDialog(
                family = null,
                localities = allowedLocalities,
                repository = repository,
                onDismiss = { showAddDialog = false },
                onSave = { newFamily ->
                    scope.launch {
                        repository.insertFamily(newFamily)
                        viewModel.refresh()
                        showAddDialog = false
                    }
                }
            )
        }

        // نافذة تعديل بيانات الأسرة
        if (selectedFamilyForEdit != null) {
            AddEditFamilyDialog(
                family = selectedFamilyForEdit,
                localities = allowedLocalities,
                repository = repository,
                onDismiss = { selectedFamilyForEdit = null },
                onSave = { updatedFamily ->
                    scope.launch {
                        repository.updateFamily(updatedFamily)
                        viewModel.refresh()
                        selectedFamilyForEdit = null
                    }
                }
            )
        }

        if (showSyncDialog) {
            SyncDetailsDialog(
                repository = repository,
                onDismiss = { showSyncDialog = false }
            )
        }

        if (familyToDelete != null) {
            com.humanitarian.aidmanagement.ui.components.AdminPasswordConfirmDialog(
                title = "حذف ملف الأسرة نهائياً",
                itemName = familyToDelete!!.name,
                itemTypeLabel = "الأسرة",
                repository = repository,
                onConfirm = {
                    val fam = familyToDelete!!
                    familyToDelete = null
                    scope.launch {
                        repository.deleteFamily(fam)
                        viewModel.refresh()
                    }
                },
                onDismiss = { familyToDelete = null }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FamilyCardItem(
    family: FamilyEntity,
    localityName: String,
    canEdit: Boolean = true,
    canDelete: Boolean = true,
    onClick: () -> Unit,
    onEdit: () -> Unit = {},
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = family.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "${family.familyMembersCount} أفراد",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "هوية: ${family.nationalID}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "•",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Text(
                    text = localityName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (family.primaryPhone.isNotBlank()) {
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Text(
                        text = family.primaryPhone,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // شارات الحالة المتجاوبة
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatusTag(
                    text = family.developmentApproval,
                    bgColor = Color(0xFFD1FAE5),
                    textColor = Color(0xFF065F46)
                )
                if (family.currentSubArea.isNotBlank()) {
                    StatusTag(
                        text = family.currentSubArea,
                        bgColor = Color(0xFFE8F5E9),
                        textColor = Color(0xFF2E7D32)
                    )
                }
                StatusTag(
                    text = family.shelterStatus,
                    bgColor = Color(0xFFE0F2FE),
                    textColor = Color(0xFF0369A1)
                )
                StatusTag(
                    text = family.damageType,
                    bgColor = Color(0xFFFEF3C7),
                    textColor = Color(0xFF92400E)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.clickable { onClick() }
                ) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "الملف الشامل للأسرة",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (canEdit) {
                        IconButton(
                            onClick = onEdit,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "تعديل",
                                tint = PalestineGreen,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    if (canDelete) {
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "حذف",
                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "الانتقال",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StatusTag(text: String, bgColor: Color, textColor: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bgColor
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = textColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(0.58f)
        )
    }
}
