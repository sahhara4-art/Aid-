package com.humanitarian.aidmanagement.ui.screens.families

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.SyncDetailsDialog
import com.humanitarian.aidmanagement.ui.components.SyncStatusBanner
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FamiliesScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToFamilyDetails: (Long) -> Unit = {},
    onNavigateToExcel: () -> Unit = {}
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedLocalityId by remember { mutableStateOf(0) }
    var selectedShelterStatus by remember { mutableStateOf("") }
    var selectedFamilyForDetails by remember { mutableStateOf<FamilyEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var showSyncDialog by remember { mutableStateOf(false) }
    val syncState by repository.getSyncState().collectAsState()

    val familiesFlow = remember(searchQuery, selectedLocalityId, selectedShelterStatus) {
        repository.getFamilies(
            searchQuery,
            selectedLocalityId,
            if (selectedShelterStatus.isEmpty()) null else selectedShelterStatus
        )
    }
    val families by familiesFlow.collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "سجل الأسر والمستفيدين",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                "${families.size} أسرة مسجلة",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = { showSyncDialog = true }) {
                            Icon(
                                imageVector = if (syncState.isOnline) Icons.Default.CloudSync else Icons.Default.CloudOff,
                                contentDescription = "التزامن والعمل دون اتصال",
                                tint = if (syncState.isOnline) MaterialTheme.colorScheme.primary else Color(0xFFF59E0B)
                            )
                        }
                        IconButton(onClick = { showAddDialog = true }) {
                            Icon(Icons.Default.PersonAdd, contentDescription = "إضافة أسرة", tint = MaterialTheme.colorScheme.primary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            floatingActionButton = {
                ExtendedFloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("إضافة أسرة جديدة", fontWeight = FontWeight.Bold) }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // شريط التزامن المصغر
                SyncStatusBanner(
                    repository = repository,
                    onOpenSyncDetails = { showSyncDialog = true }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // مربع البحث السريع
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث بالاسم الرباعي أو برقم الهوية الوطنية...", style = MaterialTheme.typography.bodyMedium) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // شريط تصفية المحليات القابل للتمرير أفقياً لمنع التداخل
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item {
                        FilterChip(
                            selected = selectedLocalityId == 0,
                            onClick = { selectedLocalityId = 0 },
                            label = { Text("كل المحليات (${localities.size})", fontWeight = if (selectedLocalityId == 0) FontWeight.Bold else FontWeight.Normal) },
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                    items(localities, key = { it.LocalityID }) { loc ->
                        val isPermitted = repository.canAccessLocality(loc.LocalityID)
                        FilterChip(
                            selected = selectedLocalityId == loc.LocalityID,
                            onClick = {
                                if (isPermitted) selectedLocalityId = loc.LocalityID
                            },
                            enabled = isPermitted,
                            label = { Text(loc.LocalityName, fontWeight = if (selectedLocalityId == loc.LocalityID) FontWeight.Bold else FontWeight.Normal) },
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // قائمة البطاقات الممتدة على كامل المساحة الشاغرة
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 80.dp)
                ) {
                    if (families.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 48.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Default.PersonSearch,
                                        contentDescription = null,
                                        modifier = Modifier.size(52.dp),
                                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "لا توجد أسر مطابقة للبحث أو المحلية المحددة",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                            }
                        }
                    } else {
                        items(families, key = { it.familyID }) { family ->
                            FamilyCardItem(
                                family = family,
                                localityName = localities.find { it.LocalityID == family.localityID }?.LocalityName ?: "محلية #${family.localityID}",
                                onClick = { onNavigateToFamilyDetails(family.familyID) },
                                onDelete = {
                                    scope.launch {
                                        repository.deleteFamily(family)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        // نافذة تفاصيل الأسرة الكاملة
        if (selectedFamilyForDetails != null) {
            val f = selectedFamilyForDetails!!
            val locName = localities.find { it.LocalityID == f.localityID }?.LocalityName ?: "محلية #${f.localityID}"
            AlertDialog(
                onDismissRequest = { selectedFamilyForDetails = null },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.FamilyRestroom, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = f.name,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DetailRow("رقم الهوية الوطنية:", f.nationalID)
                        DetailRow("المحلية والمنطقة:", locName)
                        DetailRow("عدد أفراد الأسرة:", "${f.familyMembersCount} أفراد")
                        DetailRow("الحالة الاجتماعية:", "${f.maritalStatus} (${f.gender})")
                        DetailRow("اسم الزوجة:", f.wifeName ?: "غير مسجل")
                        DetailRow("رقم البطاقة التموينية:", f.rationCardNumber ?: "غير مسجل")
                        DetailRow("اعتماد التنمية الاجتماعية:", f.developmentApproval)
                        DetailRow("اعتماد وزارة الأشغال:", f.worksApproval)
                        DetailRow("حالة الإقامة:", f.residentStatus)
                        DetailRow("نوع الضرر المسجل:", f.damageType)
                        DetailRow("حالة الإيواء الحالية:", f.shelterStatus)
                        DetailRow("العنوان التفصيلي:", listOf(f.currentMainArea, f.currentSubArea, f.currentBranch, f.currentMosque).filter { it.isNotBlank() }.joinToString(" - ").ifEmpty { locName })
                        DetailRow("رقم الجوال:", f.primaryPhone.ifBlank { "غير مسجل" })
                        if (!f.alternativePhone1.isNullOrBlank()) {
                            DetailRow("جوال بديل:", f.alternativePhone1)
                        }
                        if (!f.notes.isNullOrBlank()) {
                            DetailRow("ملاحظات:", f.notes)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { selectedFamilyForDetails = null },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إغلاق")
                    }
                }
            )
        }

        // نافذة إضافة أسرة جديدة
        if (showAddDialog) {
            AddFamilyDialog(
                localities = localities,
                onDismiss = { showAddDialog = false },
                onSave = { newFamily ->
                    scope.launch {
                        repository.insertFamily(newFamily)
                        showAddDialog = false
                    }
                }
            )
        }

        if (showSyncDialog) {
            SyncDetailsDialog(
                repository = repository,
                onDismiss = { showSyncDialog = false }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FamilyCardItem(
    family: FamilyEntity,
    localityName: String,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = family.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "${family.familyMembersCount} أفراد",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "هوية: ${family.nationalID}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "•",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Text(
                    text = localityName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (family.primaryPhone.isNotBlank()) {
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Text(
                        text = family.primaryPhone,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // شارات الحالة المتجاوبة بخلفيات فاتحة وألوان واضحة
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                StatusTag(
                    text = family.developmentApproval,
                    bgColor = Color(0xFFD1FAE5),
                    textColor = Color(0xFF065F46)
                )
                if (family.currentSubArea.isNotBlank()) {
                    StatusTag(
                        text = family.currentSubArea,
                        bgColor = Color(0xFFE8F5E9),
                        textColor = Color(0xFF2E7D32)
                    )
                }
                StatusTag(
                    text = family.shelterStatus,
                    bgColor = Color(0xFFE0F2FE),
                    textColor = Color(0xFF0369A1)
                )
                StatusTag(
                    text = family.damageType,
                    bgColor = Color(0xFFFEF3C7),
                    textColor = Color(0xFF92400E)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "فتح الملف الشامل للأسرة",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "حذف",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "الانتقال",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StatusTag(text: String, bgColor: Color, textColor: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bgColor
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = textColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(0.58f)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddFamilyDialog(
    localities: List<LocalityEntity>,
    onDismiss: () -> Unit,
    onSave: (FamilyEntity) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var nationalId by remember { mutableStateOf("") }
    var membersCountText by remember { mutableStateOf("6") }
    var selectedLocalityId by remember { mutableStateOf(localities.firstOrNull()?.LocalityID ?: 1) }
    var shelterStatus by remember { mutableStateOf("إيواء داخلي") }
    var damageType by remember { mutableStateOf("ضرر جزئي بليغ") }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = {
                Text(
                    "إضافة أسرة جديدة للمنظومة",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("الاسم الرباعي للمواطن") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = nationalId,
                        onValueChange = { nationalId = it },
                        label = { Text("رقم الهوية الوطنية (9 أرقام)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = membersCountText,
                        onValueChange = { membersCountText = it },
                        label = { Text("عدد أفراد الأسرة") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Text(
                        text = "المحلية التابع لها:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )

                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(localities) { loc ->
                            FilterChip(
                                selected = selectedLocalityId == loc.LocalityID,
                                onClick = { selectedLocalityId = loc.LocalityID },
                                label = { Text(loc.LocalityName) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank() && nationalId.isNotBlank()) {
                            val newFamily = FamilyEntity(
                                nationalID = nationalId.trim(),
                                name = name.trim(),
                                familyMembersCount = membersCountText.toIntOrNull() ?: 1,
                                localityID = selectedLocalityId,
                                shelterStatus = shelterStatus,
                                damageType = damageType,
                                developmentApproval = "معتمد",
                                worksApproval = "معتمد",
                                maritalStatus = "متزوج",
                                gender = "ذكر",
                                residentStatus = "مقيم",
                                rationCardNumber = "RC-${nationalId.takeLast(5)}"
                            )
                            onSave(newFamily)
                        }
                    },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("حفظ الأسرة")
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("إلغاء")
                }
            }
        )
    }
}
