package com.humanitarian.aidmanagement.ui.screens.families

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.SyncDetailsDialog
import com.humanitarian.aidmanagement.ui.components.SyncStatusBanner
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun FamiliesScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToFamilyDetails: (Long) -> Unit = {},
    onNavigateToExcel: () -> Unit = {},
    onNavigateToAddFamily: () -> Unit = {}
) {
    val currentUser by repository.currentUserFlow.collectAsStateWithLifecycle(initialValue = repository.getCurrentUser())
    val isLocalityRestricted = (currentUser?.AllowedLocalityID ?: 0) != 0
    val allowedLocalityId = currentUser?.AllowedLocalityID ?: 0

    val viewModel: FamiliesViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = FamiliesViewModel.Factory(repository)
    )
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val pagedFamilies = viewModel.pagedFamilies.collectAsLazyPagingItems()
    val dynamicLocalities by viewModel.dynamicLocalities.collectAsStateWithLifecycle()
    val canViewAllLocalities by viewModel.canViewAllLocalities.collectAsStateWithLifecycle()
    val isLocalityLocked by viewModel.isLocalityLocked.collectAsStateWithLifecycle()
    val lockedLocalityName by viewModel.lockedLocalityName.collectAsStateWithLifecycle()
    val assignedSubArea by viewModel.assignedSubArea.collectAsStateWithLifecycle()
    val availableBranches by viewModel.availableBranches.collectAsStateWithLifecycle()
    val isBranchLocked by viewModel.isBranchLocked.collectAsStateWithLifecycle()
    val lockedBranchName by viewModel.lockedBranchName.collectAsStateWithLifecycle()
    val canViewAllBranches by viewModel.canViewAllBranches.collectAsStateWithLifecycle()
    val allowedBranches by viewModel.allowedBranches.collectAsStateWithLifecycle()
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedLocalityId by remember { mutableStateOf(if (isLocalityRestricted) allowedLocalityId else 0) }
    var selectedShelterStatus by remember { mutableStateOf("") }
    var selectedFamilyForDetails by remember { mutableStateOf<FamilyEntity?>(null) }
    var selectedFamilyForEdit by remember { mutableStateOf<FamilyEntity?>(null) }
    var familyToDelete by remember { mutableStateOf<FamilyEntity?>(null) }
    var showSyncDialog by remember { mutableStateOf(false) }
    var showCameraScanner by remember { mutableStateOf(false) }
    var localityDropdownExpanded by remember { mutableStateOf(false) }
    var branchDropdownExpanded by remember { mutableStateOf(false) }
    val syncState by repository.getSyncState().collectAsStateWithLifecycle()

    val localities by repository.getLocalities().collectAsStateWithLifecycle(initialValue = emptyList())
    val allowedLocalities = remember(localities, currentUser) {
        if (isLocalityRestricted) {
            localities.filter { it.LocalityID == allowedLocalityId }
        } else {
            localities.filter {
                repository.canAccessLocality(it.LocalityID) &&
                    com.humanitarian.aidmanagement.security.AccessControlManager.isLocalityAllowed(it.LocalityName)
            }
        }
    }

    LaunchedEffect(isLocalityRestricted, allowedLocalityId) {
        if (isLocalityRestricted && allowedLocalityId != 0) {
            selectedLocalityId = allowedLocalityId
            viewModel.onLocalitySelected(allowedLocalityId)
        }
    }

    val scope = rememberCoroutineScope()
    val canAddFamily = currentUser != null &&
        (repository.isSuperAdmin() || repository.hasPermission("families_create")) &&
        com.humanitarian.aidmanagement.security.AccessControlManager.hasActionPermission(
            com.humanitarian.aidmanagement.security.AccessControlManager.ACTION_ADD
        ) &&
        allowedLocalities.isNotEmpty()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFFEDF7F2),
                            Color(0xFFF6FAF8),
                            Color(0xFFEAF4EF)
                        )
                    )
                )
        ) {
            Scaffold(
                containerColor = Color.Transparent,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    "سجل الأسر والمستفيدين",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    if (uiState.totalCount > 0) "إجمالي الأسر: ${uiState.totalCount} أسرة" else "${pagedFamilies.itemCount} أسرة مسجلة",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = {
                                viewModel.resetFilters()
                                onNavigateBack()
                            }) {
                                Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                            }
                        },
                        actions = {
                            if (repository.isSuperAdmin() || com.humanitarian.aidmanagement.security.AccessControlManager.canBackupCloud() || com.humanitarian.aidmanagement.security.AccessControlManager.canBackupLocal()) {
                                IconButton(onClick = { showSyncDialog = true }) {
                                    Icon(
                                        imageVector = if (syncState.isOnline) Icons.Default.CloudSync else Icons.Default.CloudOff,
                                        contentDescription = "التزامن والعمل دون اتصال",
                                        tint = if (syncState.isOnline) MaterialTheme.colorScheme.primary else Color(0xFF9A5B00)
                                    )
                                }
                            }
                            if (canAddFamily) {
                                IconButton(onClick = { onNavigateToAddFamily() }) {
                                    Icon(Icons.Rounded.Add, contentDescription = "إضافة أسرة جديدة", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = Color.White.copy(alpha = 0.88f),
                            titleContentColor = MaterialTheme.colorScheme.onSurface
                        )
                    )
                },
                floatingActionButton = {
                    if (canAddFamily) {
                        FloatingActionButton(
                            onClick = { onNavigateToAddFamily() },
                            shape = RoundedCornerShape(18.dp),
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                            elevation = FloatingActionButtonDefaults.elevation(
                                defaultElevation = 4.dp,
                                pressedElevation = 8.dp
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Add,
                                    contentDescription = "إضافة أسرة",
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = "إضافة أسرة",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            ) { paddingValues ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    // شريط التزامن المصغر
                    SyncStatusBanner(
                        repository = repository,
                        onOpenSyncDetails = { showSyncDialog = true }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // فلاتر العزل الجغرافي (المحلية + الشعبة)
                    val effectiveLocalityLock = isLocalityLocked || assignedSubArea != null
                    val effectiveLocalityOptions = remember(dynamicLocalities, allowedLocalities) {
                        if (dynamicLocalities.isNotEmpty()) dynamicLocalities
                        else allowedLocalities.map { it.LocalityName }.filter { it.isNotBlank() }.distinct()
                    }
                    val localityDisplayValue = lockedLocalityName
                        ?: assignedSubArea
                        ?: uiState.selectedLocalityName.ifBlank {
                            if (canViewAllLocalities) "جميع المحليات" else effectiveLocalityOptions.firstOrNull() ?: "جميع المحليات"
                        }
                    val branchDisplayValue = lockedBranchName
                        ?: uiState.selectedBranchName.ifBlank {
                            if (canViewAllBranches) "جميع الشعب" else "كافة الشعب المصرح بها"
                        }

                    // 1. شريط البحث الموحد بإطار واحد نظيف (ارتفاع 48.dp وزوايا 16.dp بدون إطار مزدوج)
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.88f),
                        border = BorderStroke(1.dp, Color(0xFFD6E8DF)),
                        shadowElevation = 0.dp,
                        tonalElevation = 0.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = null,
                                tint = Color(0xFF0F7B53),
                                modifier = Modifier.size(20.dp)
                            )

                            Box(
                                modifier = Modifier.weight(1f),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (searchQuery.isEmpty()) {
                                    Text(
                                        text = "ابحث بالاسم، الهوية، الجوال، أو الزوجة...",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFF64748B),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                BasicTextField(
                                    value = searchQuery,
                                    onValueChange = {
                                        searchQuery = it
                                        viewModel.onSearchQueryChanged(it)
                                    },
                                    singleLine = true,
                                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onSurface
                                    ),
                                    cursorBrush = SolidColor(Color(0xFF0F7B53)),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            if (searchQuery.isNotEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFF1F5F9))
                                        .clickable {
                                            searchQuery = ""
                                            viewModel.onSearchQueryChanged("")
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "مسح",
                                        tint = Color(0xFF475569),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE6F4EA))
                                    .clickable { showCameraScanner = true },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CameraAlt,
                                    contentDescription = "مسح بالكاميرا",
                                    tint = Color(0xFF0F7B53),
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // 2. صف فلاتر المحلية والشعبة المدمج أسفل شريط البحث مباشرة (ارتفاع 44.dp وظل 0.dp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // فلتر المحلية / المنطقة
                        Box(modifier = Modifier.weight(1f)) {
                            Surface(
                                onClick = {
                                    if (!effectiveLocalityLock) {
                                        localityDropdownExpanded = true
                                    }
                                },
                                enabled = !effectiveLocalityLock,
                                shape = RoundedCornerShape(14.dp),
                                color = if (effectiveLocalityLock) Color(0xFFFFF4E5) else Color.White.copy(alpha = 0.88f),
                                border = BorderStroke(
                                    1.dp,
                                    if (effectiveLocalityLock) Color(0xFFF5C26B) else Color(0xFFD6E8DF)
                                ),
                                shadowElevation = 0.dp,
                                tonalElevation = 0.dp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = if (effectiveLocalityLock) Icons.Default.Lock else Icons.Default.LocationOn,
                                            contentDescription = null,
                                            tint = if (effectiveLocalityLock) Color(0xFF9A5B00) else Color(0xFF0F7B53),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (effectiveLocalityLock) "المحلية (مقفلة)" else "المحلية / المنطقة",
                                                fontSize = 9.sp,
                                                color = Color(0xFF64748B),
                                                lineHeight = 10.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = localityDisplayValue,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                lineHeight = 13.sp
                                            )
                                        }
                                    }
                                    if (!effectiveLocalityLock) {
                                        Icon(
                                            imageVector = if (localityDropdownExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                            contentDescription = null,
                                            tint = Color(0xFF64748B),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                            if (!effectiveLocalityLock) {
                                DropdownMenu(
                                    expanded = localityDropdownExpanded,
                                    onDismissRequest = { localityDropdownExpanded = false }
                                ) {
                                    if (canViewAllLocalities) {
                                        DropdownMenuItem(
                                            text = { Text("جميع المحليات", fontWeight = FontWeight.Bold) },
                                            onClick = {
                                                localityDropdownExpanded = false
                                                viewModel.onLocalityNameSelected("الكل")
                                            }
                                        )
                                    }
                                    effectiveLocalityOptions.forEach { loc ->
                                        DropdownMenuItem(
                                            text = { Text(loc) },
                                            onClick = {
                                                localityDropdownExpanded = false
                                                viewModel.onLocalityNameSelected(loc)
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // فلتر الشعبة الميدانية
                        val branchEnabled = !isBranchLocked && availableBranches.isNotEmpty()
                        Box(modifier = Modifier.weight(1f)) {
                            Surface(
                                onClick = {
                                    if (branchEnabled) {
                                        branchDropdownExpanded = true
                                    }
                                },
                                enabled = branchEnabled,
                                shape = RoundedCornerShape(14.dp),
                                color = if (isBranchLocked) Color(0xFFFFF4E5) else Color.White.copy(alpha = 0.88f),
                                border = BorderStroke(
                                    1.dp,
                                    if (isBranchLocked) Color(0xFFF5C26B) else Color(0xFFD6E8DF)
                                ),
                                shadowElevation = 0.dp,
                                tonalElevation = 0.dp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(horizontal = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = if (isBranchLocked) Icons.Default.Lock else Icons.Default.AccountTree,
                                            contentDescription = null,
                                            tint = if (isBranchLocked) Color(0xFF9A5B00) else Color(0xFF0F766E),
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (isBranchLocked) "الشعبة (مقفلة)" else "الشعبة الميدانية",
                                                fontSize = 9.sp,
                                                color = Color(0xFF64748B),
                                                lineHeight = 10.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = branchDisplayValue,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                lineHeight = 13.sp
                                            )
                                        }
                                    }
                                    if (branchEnabled) {
                                        Icon(
                                            imageVector = if (branchDropdownExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                            contentDescription = null,
                                            tint = Color(0xFF64748B),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                            if (branchEnabled) {
                                DropdownMenu(
                                    expanded = branchDropdownExpanded,
                                    onDismissRequest = { branchDropdownExpanded = false }
                                ) {
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                if (canViewAllBranches) "جميع الشعب" else "كافة الشعب المصرح بها",
                                                fontWeight = FontWeight.Bold
                                            )
                                        },
                                        onClick = {
                                            branchDropdownExpanded = false
                                            viewModel.onBranchSelected("الكل")
                                        }
                                    )
                                    availableBranches.forEach { branch ->
                                        DropdownMenuItem(
                                            text = { Text(branch) },
                                            onClick = {
                                                branchDropdownExpanded = false
                                                viewModel.onBranchSelected(branch)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (allowedBranches.isNotEmpty() && !isBranchLocked) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الشعب المصرح بها: ${allowedBranches.joinToString("، ")}",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF0F766E),
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // قائمة البطاقات فائقة الأداء المعتمدة حصراً على Paging 3 (دون أي تغيير في منطق جلب البيانات)
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        contentPadding = PaddingValues(top = 2.dp, bottom = 84.dp)
                    ) {
                        if (pagedFamilies.loadState.refresh is LoadState.Loading) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = Color.White.copy(alpha = 0.88f),
                                    border = BorderStroke(1.dp, Color(0xFFD6E8DF)),
                                    shadowElevation = 0.dp,
                                    tonalElevation = 0.dp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 20.dp)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(32.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(36.dp),
                                            strokeWidth = 3.dp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "جاري تحميل سجلات الأسر...",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            }
                        } else if (pagedFamilies.itemCount == 0) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = Color.White.copy(alpha = 0.88f),
                                    border = BorderStroke(1.dp, Color(0xFFD6E8DF)),
                                    shadowElevation = 0.dp,
                                    tonalElevation = 0.dp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 20.dp)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(32.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(
                                            Icons.Default.PersonSearch,
                                            contentDescription = null,
                                            modifier = Modifier.size(52.dp),
                                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f)
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = "لا توجد أسر مطابقة للبحث أو المحلية المصرح بها",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                        )
                                    }
                                }
                            }
                        } else {
                        items(
                            count = pagedFamilies.itemCount,
                            key = { index -> pagedFamilies[index]?.familyID ?: index.toLong() }
                        ) { index ->
                            val family = pagedFamilies[index]
                            if (family != null) {
                                val locName = family.currentSubArea.ifBlank {
                                    localities.find { it.LocalityID == family.localityID }?.LocalityName
                                        ?: "محلية #${family.localityID}"
                                }
                                val canModify = repository.canModifyFamily(family)
                                val canDelete = repository.canDeleteFamily(family)

                                FamilyCardItem(
                                    family = family,
                                    localityName = locName,
                                    canEdit = canModify,
                                    canDelete = canDelete,
                                    onClick = { onNavigateToFamilyDetails(family.familyID) },
                                    onEdit = { selectedFamilyForEdit = family },
                                    onDelete = { familyToDelete = family }
                                )
                            }
                        }

                        // مؤشر تحميل الصفحات التالية بسلاسة عبر Paging 3
                        if (pagedFamilies.loadState.append is LoadState.Loading) {
                            item {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(24.dp),
                                        strokeWidth = 2.5.dp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        "جاري جلب الدفعة التالية بسلاسة...",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

        // نافذة تفاصيل الأسرة
        if (selectedFamilyForDetails != null) {
            val f = selectedFamilyForDetails!!
            val locName = localities.find { it.LocalityID == f.localityID }?.LocalityName ?: "محلية #${f.localityID}"
            AlertDialog(
                onDismissRequest = { selectedFamilyForDetails = null },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.FamilyRestroom, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = f.name,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DetailRow("رقم الهوية الوطنية:", f.nationalID)
                        DetailRow("المحلية المعتمدة:", f.currentSubArea.ifBlank { locName })
                        DetailRow("عدد أفراد الأسرة:", "${f.familyMembersCount} أفراد")
                        DetailRow("الحالة الاجتماعية:", "${f.maritalStatus} (${f.gender})")
                        DetailRow("اسم الزوجة:", f.wifeName ?: "غير مسجل")
                        DetailRow("رقم البطاقة التموينية:", f.rationCardNumber ?: "غير مسجل")
                        DetailRow("اعتماد التنمية الاجتماعية:", f.developmentApproval)
                        DetailRow("اعتماد وزارة الأشغال:", f.worksApproval)
                        DetailRow("حالة الإقامة:", f.residentStatus)
                        DetailRow("نوع الضرر المسجل:", f.damageType)
                        DetailRow("حالة الإيواء الحالية:", f.shelterStatus)
                        DetailRow("العنوان التفصيلي:", listOf(f.currentMainArea, f.currentSubArea, f.currentBranch, f.currentMosque).filter { it.isNotBlank() }.joinToString(" - ").ifEmpty { locName })
                        DetailRow("رقم الجوال:", f.primaryPhone.ifBlank { "غير مسجل" })
                        val altPhone = f.alternative_phone_1
                        if (!altPhone.isNullOrBlank()) {
                            DetailRow("جوال بديل:", altPhone)
                        }
                        val familyNotes = f.notes
                        if (!familyNotes.isNullOrBlank()) {
                            DetailRow("ملاحظات:", familyNotes)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { selectedFamilyForDetails = null },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إغلاق")
                    }
                }
            )
        }

        // نافذة تعديل بيانات الأسرة
        if (selectedFamilyForEdit != null) {
            AddEditFamilyDialog(
                family = selectedFamilyForEdit,
                localities = allowedLocalities,
                repository = repository,
                onDismiss = { selectedFamilyForEdit = null },
                onSave = { updatedFamily ->
                    scope.launch {
                        repository.updateFamily(updatedFamily)
                        viewModel.refresh()
                        selectedFamilyForEdit = null
                    }
                }
            )
        }

        if (showSyncDialog) {
            SyncDetailsDialog(
                repository = repository,
                onDismiss = { showSyncDialog = false }
            )
        }

        if (familyToDelete != null) {
            com.humanitarian.aidmanagement.ui.components.AdminPasswordConfirmDialog(
                title = "حذف ملف الأسرة نهائياً",
                itemName = familyToDelete!!.name,
                itemTypeLabel = "الأسرة",
                repository = repository,
                onConfirm = {
                    val fam = familyToDelete!!
                    familyToDelete = null
                    scope.launch {
                        repository.deleteFamily(fam)
                        viewModel.refresh()
                    }
                },
                onDismiss = { familyToDelete = null }
            )
        }

        if (showCameraScanner) {
            com.humanitarian.aidmanagement.ui.components.CameraScannerDialog(
                onIdScanned = { scannedId ->
                    searchQuery = scannedId
                    viewModel.onSearchQueryChanged(scannedId)
                    showCameraScanner = false
                },
                onDismiss = { showCameraScanner = false }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FamilyCardItem(
    family: FamilyEntity,
    localityName: String,
    canEdit: Boolean = true,
    canDelete: Boolean = true,
    onClick: () -> Unit,
    onEdit: () -> Unit = {},
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = Color.White.copy(alpha = 0.88f),
        border = BorderStroke(1.dp, Color(0xFFD6E8DF)),
        shadowElevation = 0.dp,
        tonalElevation = 0.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 1. صف العنوان: اسم رب الأسرة مع مسافة فاصلة واضحة عن أزرار التعديل والحذف الدائرية
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE6F4EA)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = Color(0xFF0F7B53),
                        modifier = Modifier.size(19.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = family.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                if (canEdit || canDelete) {
                    Spacer(modifier = Modifier.width(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (canEdit) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE6F4EA))
                                    .clickable(onClick = onEdit),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "تعديل",
                                    tint = Color(0xFF0F7B53),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        if (canDelete) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFDECEC))
                                    .clickable(onClick = onDelete),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "حذف",
                                    tint = Color(0xFFC62828),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // البيانات الأساسية منسقة بأيقونات صغيرة (الهوية + عدد الأفراد + المحلية + الجوال)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Badge,
                        contentDescription = "رقم الهوية",
                        tint = Color(0xFF0F7B53),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = family.nationalID,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF475569)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Groups,
                        contentDescription = "عدد الأفراد",
                        tint = Color(0xFF0284C7),
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${family.familyMembersCount} أفراد",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0369A1)
                    )
                }

                if (localityName.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "المحلية",
                            tint = Color(0xFF0F766E),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = localityName,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF0F766E),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (family.primaryPhone.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "الجوال",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = family.primaryPhone,
                            fontSize = 11.sp,
                            color = Color(0xFF475569)
                        )
                    }
                }
            }

            // 2. شارات الحالة الدلالية الزجاجية المتجاوبة (FlowRow)
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (family.developmentApproval.isNotBlank()) {
                    val isApproved = family.developmentApproval.contains("معتمد") && !family.developmentApproval.contains("غير")
                    val isRejected = family.developmentApproval.contains("غير") || family.developmentApproval.contains("مرفوض")
                    SemanticGlassChip(
                        text = family.developmentApproval,
                        icon = when {
                            isApproved -> Icons.Default.Verified
                            isRejected -> Icons.Default.Cancel
                            else -> Icons.Default.HourglassTop
                        },
                        bgColor = when {
                            isApproved -> Color(0xFF10B981).copy(alpha = 0.14f)
                            isRejected -> Color(0xFFEF4444).copy(alpha = 0.12f)
                            else -> Color(0xFFF59E0B).copy(alpha = 0.14f)
                        },
                        textColor = when {
                            isApproved -> Color(0xFF047857)
                            isRejected -> Color(0xFFB91C1C)
                            else -> Color(0xFFB45309)
                        },
                        borderColor = when {
                            isApproved -> Color(0xFF10B981).copy(alpha = 0.35f)
                            isRejected -> Color(0xFFEF4444).copy(alpha = 0.3f)
                            else -> Color(0xFFF59E0B).copy(alpha = 0.35f)
                        }
                    )
                }

                if (family.damageType.isNotBlank()) {
                    val isTotalDamage = family.damageType.contains("كلي")
                    val isPartialDamage = family.damageType.contains("جزئ") || family.damageType.contains("بليغ")
                    SemanticGlassChip(
                        text = family.damageType,
                        icon = if (isTotalDamage) Icons.Default.WarningAmber else Icons.Default.HomeWork,
                        bgColor = when {
                            isTotalDamage -> Color(0xFFEF4444).copy(alpha = 0.13f)
                            isPartialDamage -> Color(0xFFF59E0B).copy(alpha = 0.14f)
                            else -> Color(0xFF64748B).copy(alpha = 0.12f)
                        },
                        textColor = when {
                            isTotalDamage -> Color(0xFFB91C1C)
                            isPartialDamage -> Color(0xFFB45309)
                            else -> Color(0xFF334155)
                        },
                        borderColor = when {
                            isTotalDamage -> Color(0xFFEF4444).copy(alpha = 0.32f)
                            isPartialDamage -> Color(0xFFF59E0B).copy(alpha = 0.35f)
                            else -> Color(0xFF64748B).copy(alpha = 0.25f)
                        }
                    )
                }

                if (family.shelterStatus.isNotBlank()) {
                    val isOutsideShelter = family.shelterStatus.contains("خارج")
                    SemanticGlassChip(
                        text = family.shelterStatus,
                        icon = if (isOutsideShelter) Icons.Default.Apartment else Icons.Default.NightShelter,
                        bgColor = if (isOutsideShelter) Color(0xFF0EA5E9).copy(alpha = 0.13f) else Color(0xFF6366F1).copy(alpha = 0.13f),
                        textColor = if (isOutsideShelter) Color(0xFF0369A1) else Color(0xFF4338CA),
                        borderColor = if (isOutsideShelter) Color(0xFF0EA5E9).copy(alpha = 0.32f) else Color(0xFF6366F1).copy(alpha = 0.3f)
                    )
                }

                if (family.currentBranch.isNotBlank()) {
                    SemanticGlassChip(
                        text = family.currentBranch,
                        icon = Icons.Default.AccountTree,
                        bgColor = Color(0xFF14B8A6).copy(alpha = 0.12f),
                        textColor = Color(0xFF0F766E),
                        borderColor = Color(0xFF14B8A6).copy(alpha = 0.3f)
                    )
                }
            }
        }
    }
}

@Composable
private fun SemanticGlassChip(
    text: String,
    icon: ImageVector,
    bgColor: Color,
    textColor: Color,
    borderColor: Color
) {
    if (text.isBlank()) return
    Surface(
        shape = RoundedCornerShape(50),
        color = bgColor,
        border = BorderStroke(0.8.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(12.dp)
            )
            Text(
                text = text,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = textColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun StatusTag(text: String, bgColor: Color, textColor: Color) {
    if (text.isBlank()) return
    com.humanitarian.aidmanagement.ui.components.GlassStatusBadge(status = text)
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(0.42f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(0.58f)
        )
    }
}
