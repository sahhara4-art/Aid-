package com.humanitarian.aidmanagement.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.data.repository.SubAreaBenefitRatioStat
import org.apache.poi.ss.usermodel.BorderStyle
import org.apache.poi.ss.usermodel.CellStyle
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.HorizontalAlignment
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.ss.usermodel.VerticalAlignment
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.util.CellRangeAddress
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AidRecordWithBeneficiary(
    val record: AidRecordEntity,
    val family: FamilyEntity?
)

data class ProjectReportData(
    val project: ProjectEntity,
    val aidTypeName: String,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String,
    val notes: String? = null
)

data class LocalityReportData(
    val localityName: String,
    val subAreas: List<SubAreaBenefitRatioStat>,
    val totalFamilies: Int,
    val totalBeneficiaries: Int,
    val totalDelivered: Int,
    val dateGenerated: String,
    val supervisorName: String
)

data class ComprehensivePeriodReportData(
    val fromDate: String,
    val toDate: String,
    val totalDeliveries: Int,
    val localityStats: List<LocalityDistributionStat>,
    val aidTypeStats: List<AidTypeDistributionStat>,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String
)

class ProfessionalReportExporter(private val context: Context) {

    private val a4Width = 595
    private val a4Height = 842
    private val marginH = 28f
    private val contentWidth = a4Width - (marginH * 2)

    fun generateProjectBeneficiariesPdf(data: ProjectReportData): File {
        val pdfDocument = PdfDocument()

        val st1 = "مستلم"
        val st2 = "تم التسليم"
        val deliveredCount = data.records.count { 
            it.record.recipientStatus.contains(st1) || 
            it.record.recipientStatus.contains(st2) 
        }
        val pendingCount = data.records.size - deliveredCount
        val ratePercent = if (data.records.isNotEmpty()) (deliveredCount * 100 / data.records.size) else 0

        val itemsPerPage = 22
        val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val tTitle = "كشف مستفيدي المشروع الإنساني المعتمد"
            val tSub1 = "المشروع: "
            val tSub2 = " ("
            val tSub3 = ")"
            val fullSub = tSub1.plus(data.project.projectName).plus(tSub2).plus(data.project.projectNumber).plus(tSub3)
            
            val tPer1 = "الممول: "
            val tPer2 = " | نوع المعونة: "
            val fullPer = tPer1.plus(data.project.fundingInstitution).plus(tPer2).plus(data.aidTypeName)

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = tTitle,
                subtitle = fullSub,
                periodOrFilter = fullPer,
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                val kL1 = "إجمالي الكشف"
                val kU1 = "مستفيد"
                val kL2 = "تم التسليم"
                val kU2 = "طرد"
                val kL3 = "بانتظار الصرف"
                val kU3 = "مرشح"
                val kL4 = "نسبة الإنجاز"
                val kU4 = "مكتمل"
                val pctStr = ratePercent.toString().plus("%")
                
                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem(kL1, data.records.size.toString(), kU1, Color.rgb(13, 148, 136)),
                        KpiItem(kL2, deliveredCount.toString(), kU2, Color.rgb(16, 185, 129)),
                        KpiItem(kL3, pendingCount.toString(), kU3, Color.rgb(245, 158, 11)),
                        KpiItem(kL4, pctStr, kU4, Color.rgb(2, 132, 199))
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
            val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

            currentY = drawProjectBeneficiaryTable(
                canvas = canvas,
                records = pageRecords,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fName1 = "Project_"
        val fName2 = "_"
        val fName3 = ".pdf"
        val outName = fName1.plus(data.project.projectNumber).plus(fName2).plus(timeStamp).plus(fName3)
        val outputFile = File(reportsDir, outName)

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    fun generateLocalitySubAreasPdf(data: LocalityReportData): File {
        val pdfDocument = PdfDocument()
        val itemsPerPage = 20
        val totalPages = if (data.subAreas.isEmpty()) 1 else ((data.subAreas.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val tTitle = "تقرير التغطية الميدانية ونسب الاستفادة للمحلية"
            val tSub = "المحلية المعتمدة: "
            val fullSub = tSub.plus(data.localityName)
            val tPer = "حساب الاستحقاق الصارم: المستفيدين / الأسر المستحقة"

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = tTitle,
                subtitle = fullSub,
                periodOrFilter = tPer,
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                val totalEligible = data.subAreas.sumOf { it.eligibleFamiliesCount }
                val totalDelivered = data.subAreas.sumOf { it.deliveredBeneficiariesCount }
                val overallRatio = if (totalEligible > 0) (totalDelivered * 100 / totalEligible) else 0

                val kL1 = "إجمالي الأسر"
                val kU1 = "أسرة"
                val kL2 = "المستحقين"
                val kU2 = "مقيم+معتمد"
                val kL3 = "المستفيدين الفعليين"
                val kU3 = "مستفيد"
                val kL4 = "معدل التغطية"
                val kU4 = "إنجاز"
                val pctStr = overallRatio.toString().plus("%")

                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem(kL1, data.totalFamilies.toString(), kU1, Color.rgb(13, 148, 136)),
                        KpiItem(kL2, totalEligible.toString(), kU2, Color.rgb(2, 132, 199)),
                        KpiItem(kL3, totalDelivered.toString(), kU3, Color.rgb(16, 185, 129)),
                        KpiItem(kL4, pctStr, kU4, Color.rgb(245, 158, 11))
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.subAreas.size)
            val pageSubAreas = if (data.subAreas.isNotEmpty()) data.subAreas.subList(startIndex, endIndex) else emptyList()

            currentY = drawLocalitySubAreaTable(
                canvas = canvas,
                subAreas = pageSubAreas,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fName1 = "Locality_"
        val fName2 = "_"
        val fName3 = ".pdf"
        val outName = fName1.plus(data.localityName).plus(fName2).plus(timeStamp).plus(fName3)
        val outputFile = File(reportsDir, outName)

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    fun generateComprehensivePeriodPdf(data: ComprehensivePeriodReportData): File {
        val pdfDocument = PdfDocument()
        val itemsPerPage = 22
        val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            val tTitle = "تقرير التوزيع الشامل والعمليات الميدانية"
            val tSub1 = "نطاق الفترة الزمنية: من "
            val tSub2 = " إلى "
            val fullSub = tSub1.plus(data.fromDate).plus(tSub2).plus(data.toDate)
            
            val tPer1 = "المحليات النشطة: "
            val tPer2 = " | أصناف المساعدات: "
            val fullPer = tPer1.plus(data.localityStats.size.toString()).plus(tPer2).plus(data.aidTypeStats.size.toString())

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = tTitle,
                subtitle = fullSub,
                periodOrFilter = fullPer,
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                val kL1 = "مساعدات الفترة"
                val kU1 = "سجل/طرد"
                val kL2 = "المستفيدين الموثقين"
                val kU2 = "مستلم"
                val kL3 = "المحليات المشمولة"
                val kU3 = "محلية"
                val kL4 = "أنواع المعونة"
                val kU4 = "صنف"
                
                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem(kL1, data.totalDeliveries.toString(), kU1, Color.rgb(13, 148, 136)),
                        KpiItem(kL2, data.records.size.toString(), kU2, Color.rgb(16, 185, 129)),
                        KpiItem(kL3, data.localityStats.size.toString(), kU3, Color.rgb(2, 132, 199)),
                        KpiItem(kL4, data.aidTypeStats.size.toString(), kU4, Color.rgb(139, 92, 246))
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
            val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

            currentY = drawProjectBeneficiaryTable(
                canvas = canvas,
                records = pageRecords,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fName1 = "Comp_"
        val fName2 = "_"
        val fName3 = ".pdf"
        val outName = fName1.plus(data.fromDate).plus(fName2).plus(data.toDate).plus(fName2).plus(timeStamp).plus(fName3)
        val outputFile = File(reportsDir, outName)

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    fun generateProjectBeneficiariesExcel(data: ProjectReportData): File {
        val workbook: Workbook = XSSFWorkbook()
        val sheetName = "كشف_مستفيدي_المشروع"
        val sheet = workbook.createSheet(sheetName)
        sheet.isRightToLeft = true

        val headerStyle = createHeaderCellStyle(workbook)
        val titleStyle = createTitleCellStyle(workbook)
        val dataStyleEven = createDataCellStyle(workbook, isEven = true)
        val dataStyleOdd = createDataCellStyle(workbook, isEven = false)
        val metaLabelStyle = createMetaLabelStyle(workbook)
        val metaValueStyle = createMetaValueStyle(workbook)

        var rowIdx = 0

        val tTitle = "كشف مستفيدي المشروع الإنساني المعتمد - "
        val fullTitle = tTitle.plus(data.project.projectName)
        
        val titleRow = sheet.createRow(rowIdx++)
        titleRow.heightInPoints = 30f
        val titleCell = titleRow.createCell(0)
        titleCell.setCellValue(fullTitle)
        titleCell.cellStyle = titleStyle
        sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 7))

        rowIdx++ 

        val rL1 = "رقم المشروع:"
        val rL2 = "الجهة الممولة:"
        val rL3 = "نوع المساعدة:"
        val rL4 = "تاريخ التقرير:"
        val rL5 = "المشرف الميداني:"
        val rL6 = "إجمالي السجلات:"
        val uL1 = " مستفيد"

        val metaRow1 = sheet.createRow(rowIdx++)
        metaRow1.createCell(0).apply { setCellValue(rL1); cellStyle = metaLabelStyle }
        metaRow1.createCell(1).apply { setCellValue(data.project.projectNumber); cellStyle = metaValueStyle }
        metaRow1.createCell(2).apply { setCellValue(rL2); cellStyle = metaLabelStyle }
        metaRow1.createCell(3).apply { setCellValue(data.project.fundingInstitution); cellStyle = metaValueStyle }

        val metaRow2 = sheet.createRow(rowIdx++)
        metaRow2.createCell(0).apply { setCellValue(rL3); cellStyle = metaLabelStyle }
        metaRow2.createCell(1).apply { setCellValue(data.aidTypeName); cellStyle = metaValueStyle }
        metaRow2.createCell(2).apply { setCellValue(rL4); cellStyle = metaLabelStyle }
        metaRow2.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

        val metaRow3 = sheet.createRow(rowIdx++)
        metaRow3.createCell(0).apply { setCellValue(rL5); cellStyle = metaLabelStyle }
        metaRow3.createCell(1).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }
        metaRow3.createCell(2).apply { setCellValue(rL6); cellStyle = metaLabelStyle }
        metaRow3.createCell(3).apply { setCellValue(data.records.size.toString().plus(uL1)); cellStyle = metaValueStyle }

        rowIdx++

        val h1 = "م"
        val h2 = "اسم رب الأسرة الرباعي"
        val h3 = "رقم الهوية الوطنية"
        val h4 = "أفراد الأسرة"
        val h5 = "رقم الجوال"
        val h6 = "المنطقة / الشعبة"
        val h7 = "حالة الاستلام"
        val h8 = "ملاحظات الصرف والتحقق"
        val headers = arrayOf(h1, h2, h3, h4, h5, h6, h7, h8)

        val tableHeaderRow = sheet.createRow(rowIdx++)
        tableHeaderRow.heightInPoints = 24f
        
        headers.forEachIndexed { colIdx, header ->
            tableHeaderRow.createCell(colIdx).apply {
                setCellValue(header)
                cellStyle = headerStyle
            }
        }

        val emptyDash = "-"
        val emptyStr = ""

        data.records.forEachIndexed { i, item ->
            val row = sheet.createRow(rowIdx++)
            row.heightInPoints = 20f
            val style = if (i % 2 == 0) dataStyleEven else dataStyleOdd

            row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
            row.createCell(1).apply { setCellValue(item.family?.name ?: emptyDash); cellStyle = style }
            row.createCell(2).apply { setCellValue(item.family?.nationalID ?: emptyDash); cellStyle = style }
            row.createCell(3).apply { setCellValue((item.family?.familyMembersCount ?: 0).toDouble()); cellStyle = style }
            row.createCell(4).apply { setCellValue(item.family?.primaryPhone ?: emptyDash); cellStyle = style }
            row.createCell(5).apply { setCellValue(item.family?.currentSubArea ?: emptyDash); cellStyle = style }
            row.createCell(6).apply { setCellValue(item.record.recipientStatus); cellStyle = style }
            row.createCell(7).apply { setCellValue(item.record.notes ?: emptyStr); cellStyle = style }
        }

        for (c in headers.indices) {
            sheet.autoSizeColumn(c)
            sheet.setColumnWidth(c, (sheet.getColumnWidth(c) + 1400).coerceAtMost(10000))
        }

        val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fName1 = "Project_"
        val fName2 = "_"
        val fName3 = ".xlsx"
        val outName = fName1.plus(data.project.projectNumber).plus(fName2).plus(timeStamp).plus(fName3)
        val outputFile = File(reportsDir, outName)

        FileOutputStream(outputFile).use { fos ->
            workbook.write(fos)
        }
        workbook.close()
        return outputFile
    }

    fun generateLocalitySubAreasExcel(data: LocalityReportData): File {
        val workbook: Workbook = XSSFWorkbook()
        val sName = "تغطية_المحلية_والشعب"
        val sheet = workbook.createSheet(sName)
        sheet.isRightToLeft = true

        val headerStyle = createHeaderCellStyle(workbook)
        val titleStyle = createTitleCellStyle(workbook)
        val dataStyleEven = createDataCellStyle(workbook, isEven = true)
        val dataStyleOdd = createDataCellStyle(workbook, isEven = false)
        val metaLabelStyle = createMetaLabelStyle(workbook)
        val metaValueStyle = createMetaValueStyle(workbook)

        var rowIdx = 0

        val tTitle = "تقرير التغطية الميدانية ونسب الاستفادة - محلية "
        val fullTitle = tTitle.plus(data.localityName)

        val titleRow = sheet.createRow(rowIdx++)
        titleRow.heightInPoints = 30f
        val titleCell = titleRow.createCell(0)
        titleCell.setCellValue(fullTitle)
        titleCell.cellStyle = titleStyle
        sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 6))

        rowIdx++

        val rL1 = "المحلية المعتمدة:"
        val rL2 = "تاريخ التقرير:"
        val rL3 = "المشرف الميداني:"
        val rL4 = "إجمالي الأسر المسجلة:"
        val uL1 = " أسرة"

        val metaRow1 = sheet.createRow(rowIdx++)
        metaRow1.createCell(0).apply { setCellValue(rL1); cellStyle = metaLabelStyle }
        metaRow1.createCell(1).apply { setCellValue(data.localityName); cellStyle = metaValueStyle }
        metaRow1.createCell(2).apply { setCellValue(rL2); cellStyle = metaLabelStyle }
        metaRow1.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

        val metaRow2 = sheet.createRow(rowIdx++)
        metaRow2.createCell(0).apply { setCellValue(rL3); cellStyle = metaLabelStyle }
        metaRow2.createCell(1).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }
        metaRow2.createCell(2).apply { setCellValue(rL4); cellStyle = metaLabelStyle }
        metaRow2.createCell(3).apply { setCellValue(data.totalFamilies.toString().plus(uL1)); cellStyle = metaValueStyle }

        rowIdx++

        val h1 = "م"
        val h2 = "الشعبة / المنطقة الفرعية"
        val h3 = "المستحقين (مقيم + معتمد)"
        val h4 = "المستفيدين الفعليين"
        val h5 = "إجمالي الأسر المسجلة"
        val h6 = "نسبة التغطية والاستفادة"
        val h7 = "حالة التغطية الميدانية"
        val headers = arrayOf(h1, h2, h3, h4, h5, h6, h7)

        val tableHeaderRow = sheet.createRow(rowIdx++)
        tableHeaderRow.heightInPoints = 24f
        
        headers.forEachIndexed { colIdx, header ->
            tableHeaderRow.createCell(colIdx).apply {
                setCellValue(header)
                cellStyle = headerStyle
            }
        }

        val statGood = "تغطية ممتازة"
        val statWait = "قيد التوزيع والمتابعة"

        data.subAreas.forEachIndexed { i, sub ->
            val row = sheet.createRow(rowIdx++)
            row.heightInPoints = 20f
            val style = if (i % 2 == 0) dataStyleEven else dataStyleOdd

            row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
            row.createCell(1).apply { setCellValue(sub.subAreaName); cellStyle = style }
            row.createCell(2).apply { setCellValue(sub.eligibleFamiliesCount.toDouble()); cellStyle = style }
            row.createCell(3).apply { setCellValue(sub.deliveredBeneficiariesCount.toDouble()); cellStyle = style }
            row.createCell(4).apply { setCellValue(sub.totalFamiliesCount.toDouble()); cellStyle = style }
            row.createCell(5).apply { setCellValue(sub.formattedRatio); cellStyle = style }
            row.createCell(6).apply {
                val statusText = if (sub.ratioPercentage >= 50) statGood else statWait
                setCellValue(statusText)
                cellStyle = style
            }
        }

        for (c in headers.indices) {
            sheet.autoSizeColumn(c)
            sheet.setColumnWidth(c, (sheet.getColumnWidth(c) + 1400).coerceAtMost(10000))
        }

        val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fName1 = "Locality_"
        val fName2 = "_"
        val fName3 = ".xlsx"
        val outName = fName1.plus(data.localityName).plus(fName2).plus(timeStamp).plus(fName3)
        val outputFile = File(reportsDir, outName)

        FileOutputStream(outputFile).use { fos ->
            workbook.write(fos)
        }
        workbook.close()
        return outputFile
    }

    fun generateComprehensivePeriodExcel(data: ComprehensivePeriodReportData): File {
        val workbook: Workbook = XSSFWorkbook()
        val sName = "تقرير_التوزيع_الشامل"
        val sheet = workbook.createSheet(sName)
        sheet.isRightToLeft = true

        val headerStyle = createHeaderCellStyle(workbook)
        val titleStyle = createTitleCellStyle(workbook)
        val dataStyleEven = createDataCellStyle(workbook, isEven = true)
        val dataStyleOdd = createDataCellStyle(workbook, isEven = false)
        val metaLabelStyle = createMetaLabelStyle(workbook)
        val metaValueStyle = createMetaValueStyle(workbook)

        var rowIdx = 0

        val tTitle1 = "تقرير التوزيع الشامل والعمليات الميدانية ("
        val tTitle2 = " إلى "
        val tTitle3 = ")"
        val fullTitle = tTitle1.plus(data.fromDate).plus(tTitle2).plus(data.toDate).plus(tTitle3)

        val titleRow = sheet.createRow(rowIdx++)
        titleRow.heightInPoints = 30f
        val titleCell = titleRow.createCell(0)
        titleCell.setCellValue(fullTitle)
        titleCell.cellStyle = titleStyle
        sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 7))

        rowIdx++

        val rL1 = "نطاق الفترة:"
        val rV1 = data.fromDate.plus(tTitle2).plus(data.toDate)
        val rL2 = "تاريخ التقرير:"
        val rL3 = "إجمالي مساعدات الفترة:"
        val rV3 = data.totalDeliveries.toString().plus(" طرد")
        val rL4 = "المشرف المسؤول:"

        val metaRow1 = sheet.createRow(rowIdx++)
        metaRow1.createCell(0).apply { setCellValue(rL1); cellStyle = metaLabelStyle }
        metaRow1.createCell(1).apply { setCellValue(rV1); cellStyle = metaValueStyle }
        metaRow1.createCell(2).apply { setCellValue(rL2); cellStyle = metaLabelStyle }
        metaRow1.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

        val metaRow2 = sheet.createRow(rowIdx++)
        metaRow2.createCell(0).apply { setCellValue(rL3); cellStyle = metaLabelStyle }
        metaRow2.createCell(1).apply { setCellValue(rV3); cellStyle = metaValueStyle }
        metaRow2.createCell(2).apply { setCellValue(rL4); cellStyle = metaLabelStyle }
        metaRow2.createCell(3).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }

        rowIdx++

        val h1 = "م"
        val h2 = "اسم المستفيد الرباعي"
        val h3 = "رقم الهوية"
        val h4 = "المحلية / المنطقة"
        val h5 = "المشروع الإغاثي"
        val h6 = "تاريخ التسليم"
        val h7 = "حالة الاستلام"
        val h8 = "المستلم الفعلي والملاحظات"
        val headers = arrayOf(h1, h2, h3, h4, h5, h6, h7, h8)

        val tableHeaderRow = sheet.createRow(rowIdx++)
        tableHeaderRow.heightInPoints = 24f
        
        headers.forEachIndexed { colIdx, header ->
            tableHeaderRow.createCell(colIdx).apply {
                setCellValue(header)
                cellStyle = headerStyle
            }
        }

        val emptyDash = "-"
        val emptyStr = ""
        val pPrefix = "مشروع #"

        data.records.forEachIndexed { i, item ->
            val row = sheet.createRow(rowIdx++)
            row.heightInPoints = 20f
            val style = if (i % 2 == 0) dataStyleEven else dataStyleOdd

            row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
            row.createCell(1).apply { setCellValue(item.family?.name ?: emptyDash); cellStyle = style }
            row.createCell(2).apply { setCellValue(item.family?.nationalID ?: emptyDash); cellStyle = style }
            row.createCell(3).apply { setCellValue(item.family?.currentSubArea ?: emptyDash); cellStyle = style }
            row.createCell(4).apply { setCellValue(pPrefix.plus(item.record.projectID.toString())); cellStyle = style }
            row.createCell(5).apply { setCellValue(item.record.deliveryDate ?: item.record.aidDate); cellStyle = style }
            row.createCell(6).apply { setCellValue(item.record.recipientStatus); cellStyle = style }
            row.createCell(7).apply { setCellValue(item.record.notes ?: emptyStr); cellStyle = style }
        }

        for (c in headers.indices) {
            sheet.autoSizeColumn(c)
            sheet.setColumnWidth(c, (sheet.getColumnWidth(c) + 1400).coerceAtMost(10000))
        }

        val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fName1 = "Comp_"
        val fName2 = "_"
        val fName3 = ".xlsx"
        val outName = fName1.plus(data.fromDate).plus(fName2).plus(data.toDate).plus(fName2).plus(timeStamp).plus(fName3)
        val outputFile = File(reportsDir, outName)

        FileOutputStream(outputFile).use { fos ->
            workbook.write(fos)
        }
        workbook.close()
        return outputFile
    }

    private fun drawOfficialHeader(
        canvas: Canvas,
        reportTitle: String,
        subtitle: String,
        periodOrFilter: String,
        dateStr: String,
        startY: Float
    ): Float {
        var y = startY

        val topBarPaint = Paint().apply { color = Color.rgb(13, 148, 136) }
        canvas.drawRect(0f, 0f, a4Width.toFloat(), 12f, topBarPaint)

        val accentBarPaint = Paint().apply { color = Color.rgb(245, 158, 11) }
        canvas.drawRect(0f, 12f, a4Width.toFloat(), 15f, accentBarPaint)

        y = 38f
        val orgPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(15, 23, 42) 
            textSize = 14f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        val orgName = "نظام إدارة المساعدات الإنسانية والعمليات الميدانية المعتمد"
        canvas.drawText(orgName, a4Width - marginH, y, orgPaint)

        y += 18f
        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(13, 148, 136)
            textSize = 15f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(reportTitle, a4Width - marginH, y, titlePaint)

        y += 10f
        val boxHeight = 44f
        val boxRect = RectF(marginH, y, a4Width - marginH, y + boxHeight)
        val boxPaint = Paint().apply { color = Color.rgb(248, 250, 252) }
        val boxStroke = Paint().apply {
            color = Color.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(boxRect, 6f, 6f, boxPaint)
        canvas.drawRoundRect(boxRect, 6f, 6f, boxStroke)

        val metaPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(51, 65, 85)
            textSize = 8.5f
            textAlign = Paint.Align.RIGHT
        }

        val datePaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(100, 116, 139)
            textSize = 8f
            textAlign = Paint.Align.LEFT
        }

        val dtPre = "تاريخ الإصدار: "
        val dtFull = dtPre.plus(dateStr)
        val szFull = "المقاس: A4 Standard (رسمي للطباعة)"

        canvas.drawText(subtitle, a4Width - marginH - 10f, y + 16f, metaPaint)
        canvas.drawText(periodOrFilter, a4Width - marginH - 10f, y + 32f, metaPaint)
        canvas.drawText(dtFull, marginH + 10f, y + 16f, datePaint)
        canvas.drawText(szFull, marginH + 10f, y + 32f, datePaint)

        return y + boxHeight
    }

    private data class KpiItem(
        val label: String, 
        val value: String, 
        val unit: String, 
        val colorInt: Int
    )

    private fun drawKpiCards(
        canvas: Canvas,
        startY: Float,
        kpis: List<KpiItem>
    ): Float {
        val count = kpis.size
        val gap = 8f
        val totalGaps = gap * (count - 1)
        val cardWidth = (contentWidth - totalGaps) / count
        val cardHeight = 40f

        var currentX = a4Width - marginH

        kpis.forEach { kpi ->
            val left = currentX - cardWidth
            val rect = RectF(left, startY, currentX, startY + cardHeight)

            val bgPaint = Paint().apply { color = Color.rgb(255, 255, 255) }
            val borderPaint = Paint().apply {
                color = kpi.colorInt
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRoundRect(rect, 6f, 6f, bgPaint)
            canvas.drawRoundRect(rect, 6f, 6f, borderPaint)

            val sideBar = RectF(currentX - 4f, startY, currentX, startY + cardHeight)
            val sidePaint = Paint().apply { color = kpi.colorInt }
            canvas.drawRoundRect(sideBar, 2f, 2f, sidePaint)

            val labelPaint = Paint().apply {
                isAntiAlias = true
                color = Color.rgb(100, 116, 139)
                textSize = 7.5f
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(kpi.label, currentX - 10f, startY + 14f, labelPaint)

            val valPaint = Paint().apply {
                isAntiAlias = true
                color = kpi.colorInt
                textSize = 12f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            val spc = " "
            val fullVal = kpi.value.plus(spc).plus(kpi.unit)
            canvas.drawText(fullVal, currentX - 10f, startY + 31f, valPaint)

            currentX -= (cardWidth + gap)
        }

        return startY + cardHeight
    }

    private fun drawProjectBeneficiaryTable(
        canvas: Canvas,
        records: List<AidRecordWithBeneficiary>,
        startIndex: Int,
        startY: Float
    ): Float {
        var y = startY
        val colWidths = floatArrayOf(24f, 155f, 75f, 40f, 90f, 85f, 70f)
        
        val h1 = "م"
        val h2 = "اسم المستفيد الرباعي"
        val h3 = "رقم الهوية"
        val h4 = "الأفراد"
        val h5 = "المنطقة / الشعبة"
        val h6 = "حالة الاستلام"
        val h7 = "التوقيع / البصمة"
        val colHeaders = arrayOf(h1, h2, h3, h4, h5, h6, h7)

        val headerHeight = 22f
        val headerBg = Paint().apply { color = Color.rgb(13, 148, 136) }
        canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, headerBg)

        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = Color.WHITE
            textSize = 8.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        var curX = a4Width - marginH
        colHeaders.forEachIndexed { i, title ->
            val w = colWidths[i]
            canvas.drawText(title, curX - (w / 2f), y + 14f, headerTextPaint)
            curX -= w
        }
        y += headerHeight

        val rowHeight = 18f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = Color.rgb(248, 250, 252) }

        val defName = "مستفيد #"
        val emptyDash = "-"
        val st1 = "مستلم"
        val st2 = "تم التسليم"
        val dotStr = "..."

        records.forEachIndexed { idx, item ->
            val isEven = idx % 2 == 0
            if (isEven) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            
            val numStr = (startIndex + idx + 1).toString()
            canvas.drawText(numStr, x - (colWidths[0] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[0]

            val name = item.family?.name ?: defName.plus(item.record.familyID.toString())
            val clippedName = if (name.length > 32) name.substring(0, 30).plus(dotStr) else name
            canvas.drawText(clippedName, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[1]

            val idStr = item.family?.nationalID ?: emptyDash
            canvas.drawText(idStr, x - (colWidths[2] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[2]

            val countStr = (item.family?.familyMembersCount ?: 0).toString()
            canvas.drawText(countStr, x - (colWidths[3] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[3]

            val area = item.family?.currentSubArea ?: emptyDash
            val clippedArea = if (area.length > 18) area.substring(0, 16).plus(dotStr) else area
            canvas.drawText(clippedArea, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[4]

            val status = item.record.recipientStatus
            val statusPaint = Paint().apply {
                isAntiAlias = true
                textSize = 7.5f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
                color = if (status.contains(st1) || status.contains(st2)) 
                            Color.rgb(16, 185, 129) 
                        else 
                            Color.rgb(217, 119, 6)
            }
            canvas.drawText(status, x - (colWidths[5] / 2f), y + 12f, statusPaint)
            x -= colWidths[5]

            val boxPaint = Paint().apply {
                color = Color.rgb(203, 213, 225)
                style = Paint.Style.STROKE
                strokeWidth = 0.5f
            }
            canvas.drawRect(x - colWidths[6] + 8f, y + 3f, x - 8f, y + rowHeight - 3f, boxPaint)

            y += rowHeight
        }

        return y
    }

    private fun drawLocalitySubAreaTable(
        canvas: Canvas,
        subAreas: List<SubAreaBenefitRatioStat>,
        startIndex: Int,
        startY: Float
    ): Float {
        var y = startY
        val colWidths = floatArrayOf(24f, 155f, 80f, 80f, 70f, 65f, 65f)
        
        val h1 = "م"
        val h2 = "الشعبة / المنطقة الفرعية"
        val h3 = "المستحقين (مقيم+معتمد)"
        val h4 = "المستفيدين الفعليين"
        val h5 = "إجمالي الأسر"
        val h6 = "نسبة الإنجاز"
        val h7 = "حالة التغطية"
        val colHeaders = arrayOf(h1, h2, h3, h4, h5, h6, h7)

        val headerHeight = 22f
        val headerBg = Paint().apply { color = Color.rgb(13, 148, 136) }
        canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, headerBg)

        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = Color.WHITE
            textSize = 8f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        var curX = a4Width - marginH
        colHeaders.forEachIndexed { i, title ->
            val w = colWidths[i]
            canvas.drawText(title, curX - (w / 2f), y + 14f, headerTextPaint)
            curX -= w
        }
        y += headerHeight

        val rowHeight = 18f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = Color.rgb(248, 250, 252) }

        val statGood = "تغطية ممتازة"
        val statWait = "قيد التوزيع"

        subAreas.forEachIndexed { idx, sub ->
            val isEven = idx % 2 == 0
            if (isEven) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            
            val numStr = (startIndex + idx + 1).toString()
            canvas.drawText(numStr, x - (colWidths[0] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[0]

            canvas.drawText(sub.subAreaName, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[1]

            val ecStr = sub.eligibleFamiliesCount.toString()
            canvas.drawText(ecStr, x - (colWidths[2] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[2]

            val dcStr = sub.deliveredBeneficiariesCount.toString()
            canvas.drawText(dcStr, x - (colWidths[3] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[3]

            val tcStr = sub.totalFamiliesCount.toString()
            canvas.drawText(tcStr, x - (colWidths[4] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[4]

            val ratioPaint = Paint().apply {
                isAntiAlias = true
                textSize = 8f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
                color = if (sub.ratioPercentage >= 50) 
                            Color.rgb(16, 185, 129) 
                        else 
                            Color.rgb(245, 158, 11)
            }
            canvas.drawText(sub.formattedRatio, x - (colWidths[5] / 2f), y + 12f, ratioPaint)
            x -= colWidths[5]

            val statusPaint = Paint().apply {
                isAntiAlias = true
                textSize = 7f
                textAlign = Paint.Align.CENTER
                color = if (sub.ratioPercentage >= 50) 
                            Color.rgb(4, 120, 87) 
                        else 
                            Color.rgb(180, 83, 9)
            }
            val statusStr = if (sub.ratioPercentage >= 50) statGood else statWait
            canvas.drawText(statusStr, x - (colWidths[6] / 2f), y + 12f, statusPaint)

            y += rowHeight
        }

        return y
    }

    private fun drawOfficialFooterWithSignatures(
        canvas: Canvas,
        supervisorName: String,
        pageIndex: Int,
        totalPages: Int
    ) {
        val y = a4Height - 85f

        val divPaint = Paint().apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }
        canvas.drawLine(marginH, y, a4Width - marginH, y, divPaint)

        val boxWidth = (contentWidth - 24f) / 3f
        val boxHeight = 44f
        val boxY = y + 8f

        val boxPaint = Paint().apply {
            color = Color.rgb(248, 250, 252)
        }
        val borderPaint = Paint().apply {
            color = Color.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val sigHeaderPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(71, 85, 105)
            textSize = 7.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val sigSubPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(100, 116, 139)
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }

        val b1 = RectF(a4Width - marginH - boxWidth, boxY, a4Width - marginH, boxY + boxHeight)
        canvas.drawRoundRect(b1, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b1, 4f, 4f, borderPaint)
        
        val tSig1 = "المشرف الميداني المسؤول"
        val tSigLine = "التوقيع: ....................."
        canvas.drawText(tSig1, b1.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText(supervisorName, b1.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText(tSigLine, b1.centerX(), boxY + 36f, sigSubPaint)

        val b2 = RectF(a4Width - marginH - (boxWidth * 2) - 12f, boxY, a4Width - marginH - boxWidth - 12f, boxY + boxHeight)
        canvas.drawRoundRect(b2, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b2, 4f, 4f, borderPaint)
        
        val tSig2 = "التدقيق والمطابقة الرقابية"
        val tSig2b = "مطابق لكشوفات الاستحقاق"
        canvas.drawText(tSig2, b2.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText(tSig2b, b2.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText(tSigLine, b2.centerX(), boxY + 36f, sigSubPaint)

        val b3 = RectF(marginH, boxY, marginH + boxWidth, boxY + boxHeight)
        canvas.drawRoundRect(b3, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b3, 4f, 4f, borderPaint)
        
        val tSig3 = "الختم والاعتماد الرسمي"
        val tSig3b = "إدارة المنظومة الإنسانية"
        val tStamp = "[ ختم المنظمة المعتمد ]"
        canvas.drawText(tSig3, b3.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText(tSig3b, b3.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText(tStamp, b3.centerX(), boxY + 36f, sigSubPaint)

        val footerTextPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(148, 163, 184)
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }
        
        val ft1 = "صفحة "
        val ft2 = " من "
        val ft3 = "  •  نظام إدارة المساعدات الإنسانية - مستند رسمي معتمد وغير قابل للتعديل"
        val fullFooter = ft1.plus(pageIndex.toString()).plus(ft2).plus(totalPages.toString()).plus(ft3)
        canvas.drawText(fullFooter, a4Width / 2f, a4Height - 12f, footerTextPaint)
    }

    private fun drawPageNumberOnly(canvas: Canvas, pageIndex: Int, totalPages: Int) {
        val footerTextPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(148, 163, 184)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val ft1 = "صفحة "
        val ft2 = " من "
        val ft3 = "  •  نظام إدارة المساعدات الإنسانية"
        val fullFooter = ft1.plus(pageIndex.toString()).plus(ft2).plus(totalPages.toString()).plus(ft3)
        canvas.drawText(fullFooter, a4Width / 2f, a4Height - 14f, footerTextPaint)
    }

    private fun createTitleCellStyle(workbook: Workbook): CellStyle {
        val style = workbook.createCellStyle()
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 14
            color = IndexedColors.DARK_TEAL.index
        }
        style.setFont(font)
        style.alignment = HorizontalAlignment.CENTER
        style.verticalAlignment = VerticalAlignment.CENTER
        return style
    }

    private fun createHeaderCellStyle(workbook: Workbook): CellStyle {
        val style = workbook.createCellStyle()
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 10
            color = IndexedColors.WHITE.index
        }
        style.setFont(font)
        style.fillForegroundColor = IndexedColors.TEAL.index
        style.fillPattern = FillPatternType.SOLID_FOREGROUND
        style.alignment = HorizontalAlignment.CENTER
        style.verticalAlignment = VerticalAlignment.CENTER
        setThinBorders(style)
        return style
    }

    private fun createDataCellStyle(workbook: Workbook, isEven: Boolean): CellStyle {
        val style = workbook.createCellStyle()
        val font = workbook.createFont().apply {
            fontHeightInPoints = 9.toShort()
        }
        style.setFont(font)
        if (isEven) {
            style.fillForegroundColor = IndexedColors.GREY_25_PERCENT.index
            style.fillPattern = FillPatternType.SOLID_FOREGROUND
        }
        style.alignment = HorizontalAlignment.CENTER
        style.verticalAlignment = VerticalAlignment.CENTER
        setThinBorders(style)
        return style
    }

    private fun createMetaLabelStyle(workbook: Workbook): CellStyle {
        val style = workbook.createCellStyle()
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 9.toShort()
            color = IndexedColors.DARK_BLUE.index
        }
        style.setFont(font)
        style.alignment = HorizontalAlignment.RIGHT
        return style
    }

    private fun createMetaValueStyle(workbook: Workbook): CellStyle {
        val style = workbook.createCellStyle()
        val font = workbook.createFont().apply {
            fontHeightInPoints = 9.toShort()
        }
        style.setFont(font)
        style.alignment = HorizontalAlignment.RIGHT
        return style
    }

    private fun setThinBorders(style: CellStyle) {
        style.borderTop = BorderStyle.THIN
        style.borderBottom = BorderStyle.THIN
        style.borderLeft = BorderStyle.THIN
        style.borderRight = BorderStyle.THIN
    }

    fun shareFile(file: File, mimeType: String, title: String) {
        val pFix = ".fileprovider"
        val fullAuth = context.packageName.plus(pFix)
        val uri = FileProvider.getUriForFile(context, fullAuth, file)
        
        val txt1 = "مرفق مستند معتمد: "
        val txt2 = " - صادر عن نظام إدارة المساعدات الإنسانية."
        val fullTxt = txt1.plus(title).plus(txt2)

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, fullTxt)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chMsg = "مشاركة المستند المعتمد:"
        val chooser = Intent.createChooser(intent, chMsg)
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun openFile(file: File, mimeType: String) {
        val pFix = ".fileprovider"
        val fullAuth = context.packageName.plus(pFix)
        val uri = FileProvider.getUriForFile(context, fullAuth, file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val chMsg = "فتح المستند بواسطة:"
        context.startActivity(Intent.createChooser(intent, chMsg))
    }

    fun printPdfReport(pdfFile: File, jobName: String = "Aid_Management_Report") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return

        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = android.print.PrintDocumentInfo.Builder(jobName)
                    .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out android.print.PageRange>?,
                destination: android.os.ParcelFileDescriptor?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    val input = java.io.FileInputStream(pdfFile)
                    val output = java.io.FileOutputStream(destination?.fileDescriptor)

                    val buf = ByteArray(1024)
                    var bytesRead: Int
                    while (input.read(buf).also { bytesRead = it } > 0) {
                        output.write(buf, 0, bytesRead)
                    }

                    callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                    input.close()
                    output.close()
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                }
            }
        }

        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    }
}
