package com.humanitarian.aidmanagement.util

import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidGraphicsColor
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.data.repository.SubAreaBenefitRatioStat
import org.apache.poi.ss.usermodel.BorderStyle
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.CellStyle
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.HorizontalAlignment
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.ss.usermodel.Sheet
import org.apache.poi.ss.usermodel.VerticalAlignment
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.util.CellRangeAddress
import org.apache.poi.ss.usermodel.Font
import org.apache.poi.xssf.streaming.SXSSFSheet
import org.apache.poi.xssf.streaming.SXSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * بيانات سجل مساعدة مع تفاصيل الأسرة المستفيدة
 */
data class AidRecordWithBeneficiary(
    val record: AidRecordEntity,
    val family: FamilyEntity?
)

/**
 * بيانات تقرير المشروع والمستفيدين
 */
data class ProjectReportData(
    val project: ProjectEntity,
    val aidTypeName: String,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String,
    val notes: String? = null
)

/**
 * بيانات تقرير المحلية والشعب التابعة
 */
data class LocalityReportData(
    val localityName: String,
    val subAreas: List<SubAreaBenefitRatioStat>,
    val totalFamilies: Int,
    val totalBeneficiaries: Int,
    val totalDelivered: Int,
    val dateGenerated: String,
    val supervisorName: String
)

/**
 * بيانات تقرير التوزيع الشامل حسب الفترة الزمنية
 */
data class ComprehensivePeriodReportData(
    val fromDate: String,
    val toDate: String,
    val totalDeliveries: Int,
    val localityStats: List<LocalityDistributionStat>,
    val aidTypeStats: List<AidTypeDistributionStat>,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String
)

/**
 * بيانات عناصر التحليل الجغرافي للتقرير الإداري
 */
data class ExecutiveGeoItem(
    val name: String,
    val count: Int,
    val percentage: Double
)

/**
 * بيانات عناصر التصنيف للتقرير الإداري (الإيواء وأضرار الحرب)
 */
data class ExecutiveCategoryItem(
    val label: String,
    val count: Int,
    val percentage: Double
)

/**
 * نموذج بيانات التقرير الإداري التنفيذي الموحد (Executive Reporting Dashboard)
 */
data class ExecutiveReportData(
    val fromDate: String,
    val toDate: String,
    val totalFamilies: Int,
    val totalDelivered: Int,
    val deliveryPercentage: Double,
    val geoBreakdown: List<ExecutiveGeoItem>,
    val shelterBreakdown: List<ExecutiveCategoryItem>,
    val damageBreakdown: List<ExecutiveCategoryItem>,
    val dateGenerated: String = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
    val supervisorName: String = "مدير العمليات المركزية"
)

/**
 * فئة احترافية متكاملة لتوليد تقارير A4 PDF رسمية وتصدير ملفات Excel (.xlsx) عبر Apache POI
 */
class ProfessionalReportExporter(private val context: Context) {

    // أبعاد صفحة A4 القياسية بنظام النقاط (Standard A4 Dimensions at 72 DPI)
    private val a4Width = 595
    private val a4Height = 842
    private val marginH = 28f
    private val contentWidth = a4Width - (marginH * 2) // 539 pt

    // =========================================================================
    // 1. توليد تقرير المشروع ومستفيديه بصيغة A4 PDF
    // =========================================================================
    suspend fun generateProjectBeneficiariesPdf(data: ProjectReportData): Result<File> = withContext(Dispatchers.IO) {
        var pdfDocument: PdfDocument? = null
        try {
            pdfDocument = PdfDocument()

            val deliveredCount = data.records.count { it.record.recipientStatus.contains("مستلم") || it.record.recipientStatus.contains("تم التسليم") }
            val pendingCount = data.records.size - deliveredCount
            val ratePercent = if (data.records.isNotEmpty()) (deliveredCount * 100 / data.records.size) else 0

            val itemsPerPage = 22
            val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                var currentY = 16f
                currentY = drawOfficialHeader(
                    canvas = canvas,
                    reportTitle = "كشف مستفيدي المشروع الإنساني المعتمد",
                    subtitle = "المشروع: ${data.project.projectName} (${data.project.projectNumber})",
                    periodOrFilter = "الممول: ${data.project.fundingInstitution} | نوع المعونة: ${data.aidTypeName}",
                    dateStr = data.dateGenerated,
                    startY = currentY
                )

                if (pageIndex == 0) {
                    currentY = drawKpiCards(
                        canvas = canvas,
                        startY = currentY + 6f,
                        kpis = listOf(
                            KpiItem("إجمالي الكشف", "${data.records.size}", "مستفيد", android.graphics.Color.rgb(13, 148, 136)),
                            KpiItem("تم التسليم", "$deliveredCount", "طرد", android.graphics.Color.rgb(16, 185, 129)),
                            KpiItem("بانتظار الصرف", "$pendingCount", "مرشح", android.graphics.Color.rgb(245, 158, 11)),
                            KpiItem("نسبة الإنجاز", "$ratePercent%", "مكتمل", android.graphics.Color.rgb(2, 132, 199))
                        )
                    )
                } else {
                    currentY += 8f
                }

                // رسم جدول المستفيدين
                val startIndex = pageIndex * itemsPerPage
                val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
                val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

                currentY = drawProjectBeneficiaryTable(
                    canvas = canvas,
                    records = pageRecords,
                    startIndex = startIndex,
                    startY = currentY + 8f
                )

                // التذييل والتواقيع
                if (pageIndex == totalPages - 1) {
                    drawOfficialFooterWithSignatures(
                        canvas = canvas,
                        supervisorName = data.supervisorName,
                        pageIndex = pageIndex + 1,
                        totalPages = totalPages
                    )
                } else {
                    drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
                }

                pdfDocument.finishPage(page)
            }

            val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Project_${data.project.projectNumber}_$timeStamp.pdf")

            FileOutputStream(outputFile).use { fos ->
                pdfDocument.writeTo(fos)
            }
            pdfDocument.close()
            pdfDocument = null
            Result.success(outputFile)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during PDF generation", oom)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء توليد تقرير PDF (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error during PDF generation", e)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }

    // =========================================================================
    // 2. توليد تقرير المحلية والشعب التابعة بصيغة A4 PDF
    // =========================================================================
    suspend fun generateLocalitySubAreasPdf(data: LocalityReportData): Result<File> = withContext(Dispatchers.IO) {
        var pdfDocument: PdfDocument? = null
        try {
            pdfDocument = PdfDocument()

            val itemsPerPage = 20
            val totalPages = if (data.subAreas.isEmpty()) 1 else ((data.subAreas.size - 1) / itemsPerPage) + 1

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                var currentY = 16f
                currentY = drawOfficialHeader(
                    canvas = canvas,
                    reportTitle = "تقرير التغطية الميدانية ونسب الاستفادة للمحلية",
                    subtitle = "المحلية المعتمدة: ${data.localityName}",
                    periodOrFilter = "حساب الاستحقاق الصارم: المستفيدين / الأسر المستحقة (مقيم + معتمد)",
                    dateStr = data.dateGenerated,
                    startY = currentY
                )

                if (pageIndex == 0) {
                    val totalEligible = data.subAreas.sumOf { it.eligibleFamiliesCount }
                    val totalDelivered = data.subAreas.sumOf { it.deliveredBeneficiariesCount }
                    val overallRatio = if (totalEligible > 0) (totalDelivered * 100 / totalEligible) else 0

                    currentY = drawKpiCards(
                        canvas = canvas,
                        startY = currentY + 6f,
                        kpis = listOf(
                            KpiItem("إجمالي الأسر", "${data.totalFamilies}", "أسرة", android.graphics.Color.rgb(13, 148, 136)),
                            KpiItem("المستحقين", "$totalEligible", "مقيم+معتمد", android.graphics.Color.rgb(2, 132, 199)),
                            KpiItem("المستفيدين الفعليين", "$totalDelivered", "مستفيد", android.graphics.Color.rgb(16, 185, 129)),
                            KpiItem("معدل التغطية", "$overallRatio%", "إنجاز", android.graphics.Color.rgb(245, 158, 11))
                        )
                    )
                } else {
                    currentY += 8f
                }

                val startIndex = pageIndex * itemsPerPage
                val endIndex = minOf(startIndex + itemsPerPage, data.subAreas.size)
                val pageSubAreas = if (data.subAreas.isNotEmpty()) data.subAreas.subList(startIndex, endIndex) else emptyList()

                currentY = drawLocalitySubAreaTable(
                    canvas = canvas,
                    subAreas = pageSubAreas,
                    startIndex = startIndex,
                    startY = currentY + 8f
                )

                if (pageIndex == totalPages - 1) {
                    drawOfficialFooterWithSignatures(
                        canvas = canvas,
                        supervisorName = data.supervisorName,
                        pageIndex = pageIndex + 1,
                        totalPages = totalPages
                    )
                } else {
                    drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
                }

                pdfDocument.finishPage(page)
            }

            val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Locality_${data.localityName}_$timeStamp.pdf")

            FileOutputStream(outputFile).use { fos ->
                pdfDocument.writeTo(fos)
            }
            pdfDocument.close()
            pdfDocument = null
            Result.success(outputFile)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during PDF generation", oom)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء توليد تقرير PDF (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error during PDF generation", e)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }

    // =========================================================================
    // 3. توليد تقرير التوزيع الشامل حسب الفترة بصيغة A4 PDF
    // =========================================================================
    suspend fun generateComprehensivePeriodPdf(data: ComprehensivePeriodReportData): Result<File> = withContext(Dispatchers.IO) {
        var pdfDocument: PdfDocument? = null
        try {
            pdfDocument = PdfDocument()

            val itemsPerPage = 22
            val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                var currentY = 16f
                currentY = drawOfficialHeader(
                    canvas = canvas,
                    reportTitle = "تقرير التوزيع الشامل والعمليات الميدانية",
                    subtitle = "نطاق الفترة الزمنية المحددة: من ${data.fromDate} إلى ${data.toDate}",
                    periodOrFilter = "إجمالي المحليات النشطة: ${data.localityStats.size} | أصناف المساعدات: ${data.aidTypeStats.size}",
                    dateStr = data.dateGenerated,
                    startY = currentY
                )

                if (pageIndex == 0) {
                    currentY = drawKpiCards(
                        canvas = canvas,
                        startY = currentY + 6f,
                        kpis = listOf(
                            KpiItem("مساعدات الفترة", "${data.totalDeliveries}", "سجل/طرد", android.graphics.Color.rgb(13, 148, 136)),
                            KpiItem("المستفيدين الموثقين", "${data.records.size}", "مستلم", android.graphics.Color.rgb(16, 185, 129)),
                            KpiItem("المحليات المشمولة", "${data.localityStats.size}", "محلية", android.graphics.Color.rgb(2, 132, 199)),
                            KpiItem("أنواع المعونة", "${data.aidTypeStats.size}", "صنف", android.graphics.Color.rgb(139, 92, 246))
                        )
                    )
                } else {
                    currentY += 8f
                }

                val startIndex = pageIndex * itemsPerPage
                val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
                val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

                currentY = drawProjectBeneficiaryTable(
                    canvas = canvas,
                    records = pageRecords,
                    startIndex = startIndex,
                    startY = currentY + 8f
                )

                if (pageIndex == totalPages - 1) {
                    drawOfficialFooterWithSignatures(
                        canvas = canvas,
                        supervisorName = data.supervisorName,
                        pageIndex = pageIndex + 1,
                        totalPages = totalPages
                    )
                } else {
                    drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
                }

                pdfDocument.finishPage(page)
            }

            val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Comprehensive_${data.fromDate}_to_${data.toDate}_$timeStamp.pdf")

            FileOutputStream(outputFile).use { fos ->
                pdfDocument.writeTo(fos)
            }
            pdfDocument.close()
            pdfDocument = null
            Result.success(outputFile)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during PDF generation", oom)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء توليد تقرير PDF (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error during PDF generation", e)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }

    // =========================================================================
    // =========================================================================
    // 4. تصدير تقرير المشروع ومستفيديه إلى Excel (.xlsx) عبر SXSSFWorkbook (Streaming SAF)
    // =========================================================================
    suspend fun exportProjectBeneficiariesExcelToUri(uri: Uri, data: ProjectReportData): Result<Unit> = withContext(Dispatchers.IO) {
        var workbook: SXSSFWorkbook? = null
        try {
            // استخدام SXSSFWorkbook بنافذة تدفق متتالية (100 سطر) لمنع الـ OOM
            workbook = SXSSFWorkbook(100)
            val sheet = workbook.createSheet("كشف_مستفيدي_المشروع")
            sheet.isRightToLeft = true

            val headerStyle: CellStyle = createHeaderCellStyle(workbook)
            val titleStyle: CellStyle = createTitleCellStyle(workbook)
            val dataStyleEven: CellStyle = createDataCellStyle(workbook, isEven = true)
            val dataStyleOdd: CellStyle = createDataCellStyle(workbook, isEven = false)
            val metaLabelStyle: CellStyle = createMetaLabelStyle(workbook)
            val metaValueStyle: CellStyle = createMetaValueStyle(workbook)

            var rowIdx = 0

            // عنوان التقرير
            val titleRow = sheet.createRow(rowIdx++)
            titleRow.heightInPoints = 30f
            val titleCell = titleRow.createCell(0)
            titleCell.setCellValue("كشف مستفيدي المشروع الإنساني المعتمد - ${data.project.projectName}")
            titleCell.cellStyle = titleStyle
            sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 7))

            rowIdx++ // سطر فارغ

            // البيانات التعريفية للمشروع
            val metaRow1 = sheet.createRow(rowIdx++)
            metaRow1.createCell(0).apply { setCellValue("رقم المشروع:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(1).apply { setCellValue(data.project.projectNumber); cellStyle = metaValueStyle }
            metaRow1.createCell(2).apply { setCellValue("الجهة الممولة:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(3).apply { setCellValue(data.project.fundingInstitution ?: ""); cellStyle = metaValueStyle }

            val metaRow2 = sheet.createRow(rowIdx++)
            metaRow2.createCell(0).apply { setCellValue("نوع المساعدة:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(1).apply { setCellValue(data.aidTypeName); cellStyle = metaValueStyle }
            metaRow2.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

            val metaRow3 = sheet.createRow(rowIdx++)
            metaRow3.createCell(0).apply { setCellValue("المشرف الميداني:"); cellStyle = metaLabelStyle }
            metaRow3.createCell(1).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }
            metaRow3.createCell(2).apply { setCellValue("إجمالي السجلات:"); cellStyle = metaLabelStyle }
            metaRow3.createCell(3).apply { setCellValue("${data.records.size} مستفيد"); cellStyle = metaValueStyle }

            rowIdx++ // سطر فارغ

            // ترويسة الجدول
            val tableHeaderRow = sheet.createRow(rowIdx++)
            tableHeaderRow.heightInPoints = 24f
            val headers = listOf(
                "م",
                "اسم رب الأسرة الرباعي",
                "رقم الهوية الوطنية",
                "أفراد الأسرة",
                "رقم الجوال",
                "المنطقة / الشعبة",
                "حالة الاستلام",
                "ملاحظات الصرف والتحقق"
            )
            headers.forEachIndexed { colIdx, header ->
                tableHeaderRow.createCell(colIdx).apply {
                    setCellValue(header)
                    cellStyle = headerStyle
                }
            }

            // صفوف البيانات المتدفقة
            data.records.forEachIndexed { i, item ->
                val row = sheet.createRow(rowIdx++)
                row.heightInPoints = 20f
                val style: CellStyle = if (i % 2 == 0) dataStyleEven else dataStyleOdd

                row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
                row.createCell(1).apply { setCellValue(item.family?.name ?: "-"); cellStyle = style }
                row.createCell(2).apply { setCellValue(item.family?.nationalID ?: "-"); cellStyle = style }
                row.createCell(3).apply { setCellValue((item.family?.familyMembersCount ?: 0).toDouble()); cellStyle = style }
                row.createCell(4).apply { setCellValue(item.family?.primaryPhone ?: "-"); cellStyle = style }
                row.createCell(5).apply { setCellValue(item.family?.currentSubArea ?: "-"); cellStyle = style }
                row.createCell(6).apply { setCellValue(item.record.recipientStatus); cellStyle = style }
                row.createCell(7).apply { setCellValue(item.record.notes ?: ""); cellStyle = style }
            }

            // تحديد عرض الأعمدة دون تحميل الذاكرة
            val colWidths = listOf(1800, 9500, 5000, 3200, 4500, 6000, 4200, 8500)
            colWidths.forEachIndexed { c, w ->
                sheet.setColumnWidth(c, w)
            }

            // الكتابة أولاً في الملف المؤقت لتفادي أخطاء الذاكرة وSAF I/O (Cache-First)
            val tempFile = File(context.cacheDir, "export_prj_${System.currentTimeMillis()}.xlsx")
            try {
                FileOutputStream(tempFile).use { fos ->
                    workbook.write(fos)
                    fos.flush()
                }
                workbook.dispose()
                workbook.close()
                workbook = null

                val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                    ?: return@withContext Result.failure(Exception("تعذر فتح مجرى الكتابة للتخزين عبر ContentResolver."))
                tempFile.inputStream().use { input ->
                    outputStream.use { output ->
                        input.copyTo(output)
                        output.flush()
                    }
                }
                Result.success(Unit)
            } finally {
                try {
                    if (tempFile.exists()) tempFile.delete()
                } catch (_: Throwable) {}
            }
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during Excel export to URI", oom)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء تصدير ملف الإكسل (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error during Excel export to URI", e)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }

    suspend fun generateProjectBeneficiariesExcel(data: ProjectReportData): Result<File> = withContext(Dispatchers.IO) {
        var workbook: SXSSFWorkbook? = null
        try {
            workbook = SXSSFWorkbook(100)
            val sheet = workbook.createSheet("كشف_مستفيدي_المشروع")
            sheet.isRightToLeft = true

            val headerStyle: CellStyle = createHeaderCellStyle(workbook)
            val titleStyle: CellStyle = createTitleCellStyle(workbook)
            val dataStyleEven: CellStyle = createDataCellStyle(workbook, isEven = true)
            val dataStyleOdd: CellStyle = createDataCellStyle(workbook, isEven = false)
            val metaLabelStyle: CellStyle = createMetaLabelStyle(workbook)
            val metaValueStyle: CellStyle = createMetaValueStyle(workbook)

            var rowIdx = 0

            val titleRow = sheet.createRow(rowIdx++)
            titleRow.heightInPoints = 30f
            val titleCell = titleRow.createCell(0)
            titleCell.setCellValue("كشف مستفيدي المشروع الإنساني المعتمد - ${data.project.projectName}")
            titleCell.cellStyle = titleStyle
            sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 7))

            rowIdx++

            val metaRow1 = sheet.createRow(rowIdx++)
            metaRow1.createCell(0).apply { setCellValue("رقم المشروع:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(1).apply { setCellValue(data.project.projectNumber); cellStyle = metaValueStyle }
            metaRow1.createCell(2).apply { setCellValue("الجهة الممولة:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(3).apply { setCellValue(data.project.fundingInstitution ?: ""); cellStyle = metaValueStyle }

            val metaRow2 = sheet.createRow(rowIdx++)
            metaRow2.createCell(0).apply { setCellValue("نوع المساعدة:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(1).apply { setCellValue(data.aidTypeName); cellStyle = metaValueStyle }
            metaRow2.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

            val metaRow3 = sheet.createRow(rowIdx++)
            metaRow3.createCell(0).apply { setCellValue("المشرف الميداني:"); cellStyle = metaLabelStyle }
            metaRow3.createCell(1).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }
            metaRow3.createCell(2).apply { setCellValue("إجمالي السجلات:"); cellStyle = metaLabelStyle }
            metaRow3.createCell(3).apply { setCellValue("${data.records.size} مستفيد"); cellStyle = metaValueStyle }

            rowIdx++

            val tableHeaderRow = sheet.createRow(rowIdx++)
            tableHeaderRow.heightInPoints = 24f
            val headers = listOf(
                "م",
                "اسم رب الأسرة الرباعي",
                "رقم الهوية الوطنية",
                "أفراد الأسرة",
                "رقم الجوال",
                "المنطقة / الشعبة",
                "حالة الاستلام",
                "ملاحظات الصرف والتحقق"
            )
            headers.forEachIndexed { colIdx, header ->
                tableHeaderRow.createCell(colIdx).apply {
                    setCellValue(header)
                    cellStyle = headerStyle
                }
            }

            data.records.forEachIndexed { i, item ->
                val row = sheet.createRow(rowIdx++)
                row.heightInPoints = 20f
                val style: CellStyle = if (i % 2 == 0) dataStyleEven else dataStyleOdd

                row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
                row.createCell(1).apply { setCellValue(item.family?.name ?: "-"); cellStyle = style }
                row.createCell(2).apply { setCellValue(item.family?.nationalID ?: "-"); cellStyle = style }
                row.createCell(3).apply { setCellValue((item.family?.familyMembersCount ?: 0).toDouble()); cellStyle = style }
                row.createCell(4).apply { setCellValue(item.family?.primaryPhone ?: "-"); cellStyle = style }
                row.createCell(5).apply { setCellValue(item.family?.currentSubArea ?: "-"); cellStyle = style }
                row.createCell(6).apply { setCellValue(item.record.recipientStatus); cellStyle = style }
                row.createCell(7).apply { setCellValue(item.record.notes ?: ""); cellStyle = style }
            }

            val colWidths = listOf(1800, 9500, 5000, 3200, 4500, 6000, 4200, 8500)
            colWidths.forEachIndexed { c, w ->
                sheet.setColumnWidth(c, w)
            }

            val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Project_${data.project.projectNumber}_$timeStamp.xlsx")

            FileOutputStream(outputFile).use { fos ->
                workbook.write(fos)
                fos.flush()
            }
            workbook.dispose()
            workbook.close()
            workbook = null
            Result.success(outputFile)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during Excel export", oom)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء تصدير ملف الإكسل (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error during Excel export", e)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }

    // =========================================================================
    // 5. تصدير تقرير المحلية والشعب إلى Excel (.xlsx) عبر SXSSFWorkbook (Streaming SAF)
    // =========================================================================
    suspend fun exportLocalitySubAreasExcelToUri(uri: Uri, data: LocalityReportData): Result<Unit> = withContext(Dispatchers.IO) {
        var workbook: SXSSFWorkbook? = null
        try {
            workbook = SXSSFWorkbook(100)
            val sheet = workbook.createSheet("تغطية_المحلية_والشعب")
            sheet.isRightToLeft = true

            val headerStyle: CellStyle = createHeaderCellStyle(workbook)
            val titleStyle: CellStyle = createTitleCellStyle(workbook)
            val dataStyleEven: CellStyle = createDataCellStyle(workbook, isEven = true)
            val dataStyleOdd: CellStyle = createDataCellStyle(workbook, isEven = false)
            val metaLabelStyle: CellStyle = createMetaLabelStyle(workbook)
            val metaValueStyle: CellStyle = createMetaValueStyle(workbook)

            var rowIdx = 0

            val titleRow = sheet.createRow(rowIdx++)
            titleRow.heightInPoints = 30f
            val titleCell = titleRow.createCell(0)
            titleCell.setCellValue("تقرير التغطية الميدانية ونسب الاستفادة - محلية ${data.localityName}")
            titleCell.cellStyle = titleStyle
            sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 6))

            rowIdx++

            val metaRow1 = sheet.createRow(rowIdx++)
            metaRow1.createCell(0).apply { setCellValue("المحلية المعتمدة:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(1).apply { setCellValue(data.localityName); cellStyle = metaValueStyle }
            metaRow1.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

            val metaRow2 = sheet.createRow(rowIdx++)
            metaRow2.createCell(0).apply { setCellValue("المشرف الميداني:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(1).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }
            metaRow2.createCell(2).apply { setCellValue("إجمالي الأسر المسجلة:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(3).apply { setCellValue("${data.totalFamilies} أسرة"); cellStyle = metaValueStyle }

            rowIdx++

            val tableHeaderRow = sheet.createRow(rowIdx++)
            tableHeaderRow.heightInPoints = 24f
            val headers = listOf(
                "م",
                "الشعبة / المنطقة الفرعية",
                "المستحقين (مقيم + معتمد)",
                "المستفيدين الفعليين",
                "إجمالي الأسر المسجلة",
                "نسبة التغطية والاستفادة",
                "حالة التغطية الميدانية"
            )
            headers.forEachIndexed { colIdx, header ->
                tableHeaderRow.createCell(colIdx).apply {
                    setCellValue(header)
                    cellStyle = headerStyle
                }
            }

            data.subAreas.forEachIndexed { i, sub ->
                val row = sheet.createRow(rowIdx++)
                row.heightInPoints = 20f
                val style: CellStyle = if (i % 2 == 0) dataStyleEven else dataStyleOdd

                row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
                row.createCell(1).apply { setCellValue(sub.subAreaName); cellStyle = style }
                row.createCell(2).apply { setCellValue(sub.eligibleFamiliesCount.toDouble()); cellStyle = style }
                row.createCell(3).apply { setCellValue(sub.deliveredBeneficiariesCount.toDouble()); cellStyle = style }
                row.createCell(4).apply { setCellValue(sub.totalFamiliesCount.toDouble()); cellStyle = style }
                row.createCell(5).apply { setCellValue(sub.formattedRatio); cellStyle = style }
                row.createCell(6).apply {
                    val statusText = if (sub.ratioPercentage >= 50) "تغطية ممتازة" else "قيد التوزيع والمتابعة"
                    setCellValue(statusText)
                    cellStyle = style
                }
            }

            val colWidths = listOf(1800, 7500, 5500, 5500, 5500, 5000, 6000)
            colWidths.forEachIndexed { c, w ->
                sheet.setColumnWidth(c, w)
            }

            // الكتابة أولاً في الملف المؤقت لتفادي أخطاء الذاكرة وSAF I/O (Cache-First)
            val tempFile = File(context.cacheDir, "export_loc_${System.currentTimeMillis()}.xlsx")
            try {
                FileOutputStream(tempFile).use { fos ->
                    workbook.write(fos)
                    fos.flush()
                }
                workbook.dispose()
                workbook.close()
                workbook = null

                val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                    ?: return@withContext Result.failure(Exception("تعذر فتح مجرى الكتابة للتخزين عبر ContentResolver."))
                tempFile.inputStream().use { input ->
                    outputStream.use { output ->
                        input.copyTo(output)
                        output.flush()
                    }
                }
                Result.success(Unit)
            } finally {
                try {
                    if (tempFile.exists()) tempFile.delete()
                } catch (_: Throwable) {}
            }
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during Excel export to URI", oom)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء تصدير ملف الإكسل (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error during Excel export to URI", e)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }

    suspend fun generateLocalitySubAreasExcel(data: LocalityReportData): Result<File> = withContext(Dispatchers.IO) {
        var workbook: SXSSFWorkbook? = null
        try {
            workbook = SXSSFWorkbook(100)
            val sheet = workbook.createSheet("تغطية_المحلية_والشعب")
            sheet.isRightToLeft = true

            val headerStyle: CellStyle = createHeaderCellStyle(workbook)
            val titleStyle: CellStyle = createTitleCellStyle(workbook)
            val dataStyleEven: CellStyle = createDataCellStyle(workbook, isEven = true)
            val dataStyleOdd: CellStyle = createDataCellStyle(workbook, isEven = false)
            val metaLabelStyle: CellStyle = createMetaLabelStyle(workbook)
            val metaValueStyle: CellStyle = createMetaValueStyle(workbook)

            var rowIdx = 0

            val titleRow = sheet.createRow(rowIdx++)
            titleRow.heightInPoints = 30f
            val titleCell = titleRow.createCell(0)
            titleCell.setCellValue("تقرير التغطية الميدانية ونسب الاستفادة - محلية ${data.localityName}")
            titleCell.cellStyle = titleStyle
            sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 6))

            rowIdx++

            val metaRow1 = sheet.createRow(rowIdx++)
            metaRow1.createCell(0).apply { setCellValue("المحلية المعتمدة:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(1).apply { setCellValue(data.localityName); cellStyle = metaValueStyle }
            metaRow1.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

            val metaRow2 = sheet.createRow(rowIdx++)
            metaRow2.createCell(0).apply { setCellValue("المشرف الميداني:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(1).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }
            metaRow2.createCell(2).apply { setCellValue("إجمالي الأسر المسجلة:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(3).apply { setCellValue("${data.totalFamilies} أسرة"); cellStyle = metaValueStyle }

            rowIdx++

            val tableHeaderRow = sheet.createRow(rowIdx++)
            tableHeaderRow.heightInPoints = 24f
            val headers = listOf(
                "م",
                "الشعبة / المنطقة الفرعية",
                "المستحقين (مقيم + معتمد)",
                "المستفيدين الفعليين",
                "إجمالي الأسر المسجلة",
                "نسبة التغطية والاستفادة",
                "حالة التغطية الميدانية"
            )
            headers.forEachIndexed { colIdx, header ->
                tableHeaderRow.createCell(colIdx).apply {
                    setCellValue(header)
                    cellStyle = headerStyle
                }
            }

            data.subAreas.forEachIndexed { i, sub ->
                val row = sheet.createRow(rowIdx++)
                row.heightInPoints = 20f
                val style: CellStyle = if (i % 2 == 0) dataStyleEven else dataStyleOdd

                row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
                row.createCell(1).apply { setCellValue(sub.subAreaName); cellStyle = style }
                row.createCell(2).apply { setCellValue(sub.eligibleFamiliesCount.toDouble()); cellStyle = style }
                row.createCell(3).apply { setCellValue(sub.deliveredBeneficiariesCount.toDouble()); cellStyle = style }
                row.createCell(4).apply { setCellValue(sub.totalFamiliesCount.toDouble()); cellStyle = style }
                row.createCell(5).apply { setCellValue(sub.formattedRatio); cellStyle = style }
                row.createCell(6).apply {
                    val statusText = if (sub.ratioPercentage >= 50) "تغطية ممتازة" else "قيد التوزيع والمتابعة"
                    setCellValue(statusText)
                    cellStyle = style
                }
            }

            val colWidths = listOf(1800, 7500, 5500, 5500, 5500, 5000, 6000)
            colWidths.forEachIndexed { c, w ->
                sheet.setColumnWidth(c, w)
            }

            val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Locality_${data.localityName}_$timeStamp.xlsx")

            FileOutputStream(outputFile).use { fos ->
                workbook.write(fos)
                fos.flush()
            }
            workbook.dispose()
            workbook.close()
            workbook = null
            Result.success(outputFile)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during Excel export", oom)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء تصدير ملف الإكسل (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error during Excel export", e)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }

    // =========================================================================
    // 6. تصدير تقرير التوزيع الشامل إلى Excel (.xlsx) عبر SXSSFWorkbook (Streaming SAF)
    // =========================================================================
    suspend fun exportComprehensivePeriodExcelToUri(uri: Uri, data: ComprehensivePeriodReportData): Result<Unit> = withContext(Dispatchers.IO) {
        var workbook: SXSSFWorkbook? = null
        try {
            workbook = SXSSFWorkbook(100)
            val sheet = workbook.createSheet("تقرير_التوزيع_الشامل")
            sheet.isRightToLeft = true

            val headerStyle: CellStyle = createHeaderCellStyle(workbook)
            val titleStyle: CellStyle = createTitleCellStyle(workbook)
            val dataStyleEven: CellStyle = createDataCellStyle(workbook, isEven = true)
            val dataStyleOdd: CellStyle = createDataCellStyle(workbook, isEven = false)
            val metaLabelStyle: CellStyle = createMetaLabelStyle(workbook)
            val metaValueStyle: CellStyle = createMetaValueStyle(workbook)

            var rowIdx = 0

            val titleRow = sheet.createRow(rowIdx++)
            titleRow.heightInPoints = 30f
            val titleCell = titleRow.createCell(0)
            titleCell.setCellValue("تقرير التوزيع الشامل والعمليات الميدانية (${data.fromDate} إلى ${data.toDate})")
            titleCell.cellStyle = titleStyle
            sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 7))

            rowIdx++

            val metaRow1 = sheet.createRow(rowIdx++)
            metaRow1.createCell(0).apply { setCellValue("نطاق الفترة:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(1).apply { setCellValue("${data.fromDate} إلى ${data.toDate}"); cellStyle = metaValueStyle }
            metaRow1.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

            val metaRow2 = sheet.createRow(rowIdx++)
            metaRow2.createCell(0).apply { setCellValue("إجمالي مساعدات الفترة:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(1).apply { setCellValue("${data.totalDeliveries} طرد"); cellStyle = metaValueStyle }
            metaRow2.createCell(2).apply { setCellValue("المشرف المسؤول:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(3).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }

            rowIdx++

            val tableHeaderRow = sheet.createRow(rowIdx++)
            tableHeaderRow.heightInPoints = 24f
            val headers = listOf(
                "م",
                "اسم المستفيد الرباعي",
                "رقم الهوية",
                "المحلية / المنطقة",
                "المشروع الإغاثي",
                "تاريخ التسليم",
                "حالة الاستلام",
                "المستلم الفعلي والملاحظات"
            )
            headers.forEachIndexed { colIdx, header ->
                tableHeaderRow.createCell(colIdx).apply {
                    setCellValue(header)
                    cellStyle = headerStyle
                }
            }

            data.records.forEachIndexed { i, item ->
                val row = sheet.createRow(rowIdx++)
                row.heightInPoints = 20f
                val style: CellStyle = if (i % 2 == 0) dataStyleEven else dataStyleOdd

                row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
                row.createCell(1).apply { setCellValue(item.family?.name ?: "-"); cellStyle = style }
                row.createCell(2).apply { setCellValue(item.family?.nationalID ?: "-"); cellStyle = style }
                row.createCell(3).apply { setCellValue(item.family?.currentSubArea ?: "-"); cellStyle = style }
                row.createCell(4).apply { setCellValue("مشروع #${item.record.projectID}"); cellStyle = style }
                row.createCell(5).apply { setCellValue(item.record.deliveryDate ?: item.record.aidDate); cellStyle = style }
                row.createCell(6).apply { setCellValue(item.record.recipientStatus); cellStyle = style }
                row.createCell(7).apply { setCellValue(item.record.notes ?: ""); cellStyle = style }
            }

            val colWidths = listOf(1800, 9500, 5000, 6000, 4500, 4500, 4200, 8500)
            colWidths.forEachIndexed { c, w ->
                sheet.setColumnWidth(c, w)
            }

            // الكتابة أولاً في الملف المؤقت لتفادي أخطاء الذاكرة وSAF I/O (Cache-First)
            val tempFile = File(context.cacheDir, "export_comp_${System.currentTimeMillis()}.xlsx")
            try {
                FileOutputStream(tempFile).use { fos ->
                    workbook.write(fos)
                    fos.flush()
                }
                workbook.dispose()
                workbook.close()
                workbook = null

                val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                    ?: return@withContext Result.failure(Exception("تعذر فتح مجرى الكتابة للتخزين عبر ContentResolver."))
                tempFile.inputStream().use { input ->
                    outputStream.use { output ->
                        input.copyTo(output)
                        output.flush()
                    }
                }
                Result.success(Unit)
            } finally {
                try {
                    if (tempFile.exists()) tempFile.delete()
                } catch (_: Throwable) {}
            }
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during Excel export to URI", oom)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء تصدير ملف الإكسل (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error during Excel export to URI", e)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }

    suspend fun generateComprehensivePeriodExcel(data: ComprehensivePeriodReportData): Result<File> = withContext(Dispatchers.IO) {
        var workbook: SXSSFWorkbook? = null
        try {
            workbook = SXSSFWorkbook(100)
            val sheet = workbook.createSheet("تقرير_التوزيع_الشامل")
            sheet.isRightToLeft = true

            val headerStyle: CellStyle = createHeaderCellStyle(workbook)
            val titleStyle: CellStyle = createTitleCellStyle(workbook)
            val dataStyleEven: CellStyle = createDataCellStyle(workbook, isEven = true)
            val dataStyleOdd: CellStyle = createDataCellStyle(workbook, isEven = false)
            val metaLabelStyle: CellStyle = createMetaLabelStyle(workbook)
            val metaValueStyle: CellStyle = createMetaValueStyle(workbook)

            var rowIdx = 0

            val titleRow = sheet.createRow(rowIdx++)
            titleRow.heightInPoints = 30f
            val titleCell = titleRow.createCell(0)
            titleCell.setCellValue("تقرير التوزيع الشامل والعمليات الميدانية (${data.fromDate} إلى ${data.toDate})")
            titleCell.cellStyle = titleStyle
            sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 7))

            rowIdx++

            val metaRow1 = sheet.createRow(rowIdx++)
            metaRow1.createCell(0).apply { setCellValue("نطاق الفترة:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(1).apply { setCellValue("${data.fromDate} إلى ${data.toDate}"); cellStyle = metaValueStyle }
            metaRow1.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
            metaRow1.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

            val metaRow2 = sheet.createRow(rowIdx++)
            metaRow2.createCell(0).apply { setCellValue("إجمالي مساعدات الفترة:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(1).apply { setCellValue("${data.totalDeliveries} طرد"); cellStyle = metaValueStyle }
            metaRow2.createCell(2).apply { setCellValue("المشرف المسؤول:"); cellStyle = metaLabelStyle }
            metaRow2.createCell(3).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }

            rowIdx++

            val tableHeaderRow = sheet.createRow(rowIdx++)
            tableHeaderRow.heightInPoints = 24f
            val headers = listOf(
                "م",
                "اسم المستفيد الرباعي",
                "رقم الهوية",
                "المحلية / المنطقة",
                "المشروع الإغاثي",
                "تاريخ التسليم",
                "حالة الاستلام",
                "المستلم الفعلي والملاحظات"
            )
            headers.forEachIndexed { colIdx, header ->
                tableHeaderRow.createCell(colIdx).apply {
                    setCellValue(header)
                    cellStyle = headerStyle
                }
            }

            data.records.forEachIndexed { i, item ->
                val row = sheet.createRow(rowIdx++)
                row.heightInPoints = 20f
                val style: CellStyle = if (i % 2 == 0) dataStyleEven else dataStyleOdd

                row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
                row.createCell(1).apply { setCellValue(item.family?.name ?: "-"); cellStyle = style }
                row.createCell(2).apply { setCellValue(item.family?.nationalID ?: "-"); cellStyle = style }
                row.createCell(3).apply { setCellValue(item.family?.currentSubArea ?: "-"); cellStyle = style }
                row.createCell(4).apply { setCellValue("مشروع #${item.record.projectID}"); cellStyle = style }
                row.createCell(5).apply { setCellValue(item.record.deliveryDate ?: item.record.aidDate); cellStyle = style }
                row.createCell(6).apply { setCellValue(item.record.recipientStatus); cellStyle = style }
                row.createCell(7).apply { setCellValue(item.record.notes ?: ""); cellStyle = style }
            }

            val colWidths = listOf(1800, 9500, 5000, 6000, 4500, 4500, 4200, 8500)
            colWidths.forEachIndexed { c, w ->
                sheet.setColumnWidth(c, w)
            }

            val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Comprehensive_${data.fromDate}_to_${data.toDate}_$timeStamp.xlsx")

            FileOutputStream(outputFile).use { fos ->
                workbook.write(fos)
                fos.flush()
            }
            workbook.dispose()
            workbook.close()
            workbook = null
            Result.success(outputFile)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during Excel export", oom)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء تصدير ملف الإكسل (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error during Excel export", e)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            Result.failure(e)
        }
    }
    // =========================================================================
    // 7. التصدير الديناميكي المتقدم للأسر والمستفيدين إلى Excel عبر Cache-First SAF
    // =========================================================================
    suspend fun exportDynamicFamiliesExcelToUri(
        uri: Uri,
        title: String,
        metaRows: List<Pair<String, String>>,
        records: List<AidRecordWithBeneficiary>,
        selectedColumnKeys: List<String>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val defs = ExportColumnRegistry.getOrderedDefs(selectedColumnKeys)
        if (defs.isEmpty()) {
            return@withContext Result.failure(Exception("لم يتم اختيار أي عمود للتصدير."))
        }
        var workbook: SXSSFWorkbook? = null
        val tempFile = File(context.cacheDir, "dynamic_export_${System.currentTimeMillis()}.xlsx")
        try {
            workbook = SXSSFWorkbook(100)
            val sheet = workbook.createSheet("كشف_المستفيدين")
            sheet.isRightToLeft = true

            val headerStyle = createHeaderCellStyle(workbook)
            val titleStyle = createTitleCellStyle(workbook)
            val dataStyleEven = createDataCellStyle(workbook, isEven = true)
            val dataStyleOdd = createDataCellStyle(workbook, isEven = false)
            val metaLabelStyle = createMetaLabelStyle(workbook)
            val metaValueStyle = createMetaValueStyle(workbook)

            var rowIdx = 0

            // 1. عنوان التقرير
            val titleRow = sheet.createRow(rowIdx++)
            titleRow.heightInPoints = 32f
            val titleCell = titleRow.createCell(0)
            titleCell.setCellValue(title)
            titleCell.cellStyle = titleStyle
            val mergeEndCol = (defs.size - 1).coerceAtLeast(1)
            sheet.addMergedRegion(CellRangeAddress(0, 0, 0, mergeEndCol))

            rowIdx++ // فارغ

            // 2. البيانات التعريفية (Meta Rows)
            for (chunk in metaRows.chunked(2)) {
                val metaRow = sheet.createRow(rowIdx++)
                var col = 0
                for ((label, value) in chunk) {
                    metaRow.createCell(col++).apply { setCellValue(label); cellStyle = metaLabelStyle }
                    metaRow.createCell(col++).apply { setCellValue(value); cellStyle = metaValueStyle }
                }
            }

            rowIdx++ // فارغ

            // 3. ترويسة الجدول الديناميكية
            val headerRow = sheet.createRow(rowIdx++)
            headerRow.heightInPoints = 26f
            defs.forEachIndexed { colIdx, def ->
                headerRow.createCell(colIdx).apply {
                    setCellValue(def.label)
                    cellStyle = headerStyle
                }
            }

            // 4. صفوف البيانات الديناميكية
            records.forEachIndexed { i, item ->
                val family = item.family ?: FamilyEntity(nationalID = "", name = "غير محدد")
                val row = sheet.createRow(rowIdx++)
                row.heightInPoints = 20f
                val style = if (i % 2 == 0) dataStyleEven else dataStyleOdd

                defs.forEachIndexed { colIdx, def ->
                    val cellVal = def.valueExtractor(family, item.record, i + 1)
                    val cell = row.createCell(colIdx)
                    cell.cellStyle = style
                    val num = if (def.key == "row_index" || def.key == "familyMembersCount" || def.key == "age") {
                        cellVal.toDoubleOrNull()
                    } else null

                    if (num != null) {
                        cell.setCellValue(num)
                    } else {
                        cell.setCellValue(cellVal)
                    }
                }
            }

            // 5. ضبط عرض الأعمدة
            defs.forEachIndexed { colIdx, def ->
                sheet.setColumnWidth(colIdx, def.excelWidth)
            }

            // 6. الكتابة أولاً للملف المؤقت في cacheDir (Cache-First)
            FileOutputStream(tempFile).use { fos ->
                workbook.write(fos)
                fos.flush()
            }
            workbook.dispose()
            workbook.close()
            workbook = null

            // 7. التدفق الآمن لمسار الـ SAF Uri
            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى التخزين عبر ContentResolver."))
            tempFile.inputStream().use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }
            Result.success(Unit)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError in dynamic Excel export", oom)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء التصدير (OOM). يرجى تقليل الأعمدة أو الحجم.", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error in dynamic Excel export", e)
            try { workbook?.dispose() } catch (_: Throwable) {}
            try { workbook?.close() } catch (_: Throwable) {}
            Result.failure(e)
        } finally {
            try {
                if (tempFile.exists()) tempFile.delete()
            } catch (_: Throwable) {}
        }
    }

    /**
     * تصدير مخصص لكشف المستفيدين (List<FamilyEntity>) عبر الأعمدة المختارة
     */
    suspend fun exportDynamicFamiliesExcelToUri(
        uri: Uri,
        reportTitle: String,
        selectedColumnKeys: List<String>,
        families: List<FamilyEntity>
    ): Result<Unit> {
        val todayStr = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date())
        val records = families.map { family ->
            AidRecordWithBeneficiary(
                record = AidRecordEntity(
                    aidRecordID = 0L,
                    familyID = family.familyID,
                    aidTypeID = 1,
                    projectID = 0L,
                    aidDate = todayStr,
                    selectionDate = todayStr,
                    recipientStatus = "معتمد"
                ),
                family = family
            )
        }
        val metaRows = listOf(
            "إجمالي الأسر المشمولة" to "${families.size} أسرة",
            "تاريخ التقرير" to todayStr
        )
        return exportDynamicFamiliesExcelToUri(
            uri = uri,
            title = reportTitle,
            metaRows = metaRows,
            records = records,
            selectedColumnKeys = selectedColumnKeys
        )
    }

    // =========================================================================
    // 8. التصدير الديناميكي المتقدم للأسر والمستفيدين إلى PDF عبر Cache-First SAF
    // =========================================================================
    suspend fun exportDynamicFamiliesPdfToUri(
        uri: Uri,
        title: String,
        subtitle: String,
        metaRows: List<Pair<String, String>>,
        records: List<AidRecordWithBeneficiary>,
        selectedColumnKeys: List<String>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val defs = ExportColumnRegistry.getOrderedDefs(selectedColumnKeys)
        if (defs.isEmpty()) {
            return@withContext Result.failure(Exception("لم يتم اختيار أي عمود للتصدير."))
        }
        var pdfDocument: PdfDocument? = null
        val tempFile = File(context.cacheDir, "dynamic_export_${System.currentTimeMillis()}.pdf")
        try {
            pdfDocument = PdfDocument()

            val useLandscape = defs.size > 6
            val pageWidth = if (useLandscape) 842 else 595
            val pageHeight = if (useLandscape) 595 else 842
            val marginH = 24f
            val availableWidth = pageWidth - (marginH * 2)

            val totalWeight = defs.sumOf { it.pdfWeight.toDouble() }.toFloat().coerceAtLeast(1f)
            val colWidths = defs.map { (it.pdfWeight / totalWeight) * availableWidth }

            val itemsPerPage = if (useLandscape) 18 else 22
            val totalPages = if (records.isEmpty()) 1 else ((records.size - 1) / itemsPerPage) + 1

            val paint = Paint().apply { isAntiAlias = true }
            val textPaint = Paint().apply {
                isAntiAlias = true
                textSize = if (defs.size > 8) 7.5f else 8.5f
                color = AndroidGraphicsColor.BLACK
                typeface = Typeface.DEFAULT
            }
            val headerTextPaint = Paint().apply {
                isAntiAlias = true
                textSize = if (defs.size > 8) 8f else 9f
                color = AndroidGraphicsColor.WHITE
                isFakeBoldText = true
            }

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                var currentY = 16f
                currentY = drawDynamicOfficialHeader(
                    canvas = canvas,
                    reportTitle = title,
                    subtitle = subtitle,
                    periodOrFilter = metaRows.joinToString(" • ") { "${it.first}: ${it.second}" },
                    dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                    pageWidth = pageWidth,
                    marginH = marginH,
                    startY = currentY
                )

                val headerHeight = 22f
                val rowHeight = 19f
                var tableX = pageWidth - marginH

                paint.color = AndroidGraphicsColor.rgb(15, 23, 42)
                paint.style = Paint.Style.FILL
                canvas.drawRect(marginH, currentY, pageWidth - marginH, currentY + headerHeight, paint)

                defs.forEachIndexed { colIdx, def ->
                    val w = colWidths[colIdx]
                    val cellLeft = tableX - w
                    tableX -= w

                    paint.color = AndroidGraphicsColor.rgb(51, 65, 85)
                    paint.strokeWidth = 0.5f
                    canvas.drawLine(cellLeft, currentY, cellLeft, currentY + headerHeight, paint)

                    val labelText = def.label
                    val textW = headerTextPaint.measureText(labelText)
                    val textX = cellLeft + (w - textW) / 2f
                    val textY = currentY + (headerHeight / 2f) - ((headerTextPaint.descent() + headerTextPaint.ascent()) / 2f)
                    canvas.drawText(labelText, textX, textY, headerTextPaint)
                }

                currentY += headerHeight

                val pageStartIndex = pageIndex * itemsPerPage
                val pageEndIndex = minOf(pageStartIndex + itemsPerPage, records.size)
                val pageRecords = records.subList(pageStartIndex, pageEndIndex)

                pageRecords.forEachIndexed { rIdx, item ->
                    val globalIdx = pageStartIndex + rIdx + 1
                    val family = item.family ?: FamilyEntity(nationalID = "", name = "غير محدد")
                    val isEven = rIdx % 2 == 0

                    paint.color = if (isEven) AndroidGraphicsColor.WHITE else AndroidGraphicsColor.rgb(241, 245, 249)
                    paint.style = Paint.Style.FILL
                    canvas.drawRect(marginH, currentY, pageWidth - marginH, currentY + rowHeight, paint)

                    paint.color = AndroidGraphicsColor.rgb(226, 232, 240)
                    paint.strokeWidth = 0.5f
                    canvas.drawLine(marginH, currentY + rowHeight, pageWidth - marginH, currentY + rowHeight, paint)

                    var cellX = pageWidth - marginH
                    defs.forEachIndexed { colIdx, def ->
                        val w = colWidths[colIdx]
                        val cellLeft = cellX - w
                        cellX -= w

                        paint.color = AndroidGraphicsColor.rgb(226, 232, 240)
                        paint.strokeWidth = 0.5f
                        canvas.drawLine(cellLeft, currentY, cellLeft, currentY + rowHeight, paint)

                        val rawValue = def.valueExtractor(family, item.record, globalIdx)
                        val maxTextW = w - 6f
                        var displayText = rawValue
                        if (textPaint.measureText(displayText) > maxTextW && maxTextW > 10f) {
                            while (displayText.isNotEmpty() && textPaint.measureText("$displayText…") > maxTextW) {
                                displayText = displayText.dropLast(1)
                            }
                            displayText = "$displayText…"
                        }

                        val tw = textPaint.measureText(displayText)
                        val tx = cellLeft + (w - tw) / 2f
                        val ty = currentY + (rowHeight / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f)
                        canvas.drawText(displayText, tx, ty, textPaint)
                    }

                    currentY += rowHeight
                }

                val pageFooterText = "صفحة ${pageIndex + 1} من $totalPages • نظام إدارة المساعدات الإنسانية - دولة فلسطين"
                val footerPaint = Paint().apply {
                    isAntiAlias = true
                    textSize = 8f
                    color = AndroidGraphicsColor.GRAY
                }
                val fw = footerPaint.measureText(pageFooterText)
                canvas.drawText(pageFooterText, (pageWidth - fw) / 2f, pageHeight - 16f, footerPaint)

                pdfDocument.finishPage(page)
            }

            FileOutputStream(tempFile).use { fos ->
                pdfDocument.writeTo(fos)
                fos.flush()
            }
            pdfDocument.close()
            pdfDocument = null

            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى التخزين عبر ContentResolver."))
            tempFile.inputStream().use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }
            Result.success(Unit)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError in dynamic PDF export", oom)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء تصدير PDF (OOM).", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error in dynamic PDF export", e)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            Result.failure(e)
        } finally {
            try {
                if (tempFile.exists()) tempFile.delete()
            } catch (_: Throwable) {}
        }
    }

    /**
     * تصدير كشف المستفيدين (List<FamilyEntity>) بصيغة PDF وفق الأعمدة المحددة
     */
    suspend fun exportDynamicFamiliesPdfToUri(
        uri: Uri,
        reportTitle: String,
        selectedColumnKeys: List<String>,
        families: List<FamilyEntity>,
        supervisorName: String
    ): Result<Unit> {
        val todayStr = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date())
        val records = families.map { family ->
            AidRecordWithBeneficiary(
                record = AidRecordEntity(
                    aidRecordID = 0L,
                    familyID = family.familyID,
                    aidTypeID = 1,
                    projectID = 0L,
                    aidDate = todayStr,
                    selectionDate = todayStr,
                    recipientStatus = "معتمد"
                ),
                family = family
            )
        }
        val metaRows = listOf(
            "إجمالي الأسر المشمولة" to "${families.size} أسرة",
            "المشرف المسؤول" to supervisorName,
            "تاريخ التقرير" to todayStr
        )
        return exportDynamicFamiliesPdfToUri(
            uri = uri,
            title = reportTitle,
            subtitle = "كشف المستفيدين التنفيذي المعتمد للعمليات الميدانية",
            metaRows = metaRows,
            records = records,
            selectedColumnKeys = selectedColumnKeys
        )
    }

    /**
     * تصدير التقرير الإداري التنفيذي (Executive Reporting Dashboard) بصيغة A4 PDF معتمدة
     * وفق معمارية Cache-First الصارمة لمنع التعارض وانهيار SAF
     */
    suspend fun exportExecutiveReportPdfToUri(
        uri: Uri,
        data: ExecutiveReportData
    ): Result<Unit> = withContext(Dispatchers.IO) {
        var pdfDocument: PdfDocument? = null
        val tempFile = File(context.cacheDir, "exec_dashboard_${System.currentTimeMillis()}.pdf")
        try {
            pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            // 1. الترويسة الرسمية
            var currentY = drawDynamicOfficialHeader(
                canvas = canvas,
                reportTitle = "التقرير الإداري التنفيذي الموحد لمؤشرات المساعدات والإيواء",
                subtitle = "الإدارة العامة للإغاثة والطوارئ • القيادة والسيطرة الميدانية",
                periodOrFilter = "الفترة التحليلية: من ${data.fromDate} إلى ${data.toDate}",
                dateStr = data.dateGenerated,
                pageWidth = a4Width,
                marginH = marginH,
                startY = 0f
            )
            currentY += 10f

            // 2. بطاقات المؤشرات الرئيسية (Executive KPI Cards)
            val kpis = listOf(
                KpiItem("إجمالي الأسر في النطاق", String.format(Locale.US, "%,d", data.totalFamilies), "أسرة", AndroidGraphicsColor.rgb(13, 148, 136)),
                KpiItem("المساعدات المسلمة فعلياً", String.format(Locale.US, "%,d", data.totalDelivered), "مساعدة", AndroidGraphicsColor.rgb(2, 132, 199)),
                KpiItem("نسبة التغطية الميدانية", String.format(Locale.US, "%.1f%%", data.deliveryPercentage), "إنجاز", AndroidGraphicsColor.rgb(16, 185, 129))
            )
            currentY = drawKpiCards(canvas, currentY, kpis)
            currentY += 12f

            // 3. قسم التوزيع الجغرافي ونسب التغطية (Geographic Breakdown)
            currentY = drawExecutiveGeoSection(canvas, currentY, data.geoBreakdown)
            currentY += 12f

            // 4. أقسام التصنيفات الميدانية: الإيواء وأضرار الحرب (Shelter & Damage Breakdown)
            currentY = drawExecutiveBreakdownsSection(canvas, currentY, data.shelterBreakdown, data.damageBreakdown)

            // 5. التذييل الرسمي والأختام
            drawOfficialFooterWithSignatures(canvas, data.supervisorName, 1, 1)

            pdfDocument.finishPage(page)

            // حفظ الملف مؤقتاً في ذاكرة التخزين المؤقت (Cache-First)
            FileOutputStream(tempFile).use { fos ->
                pdfDocument.writeTo(fos)
                fos.flush()
            }
            pdfDocument.close()
            pdfDocument = null

            // دفق المحتوى بأمان إلى Storage Access Framework Uri
            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى التخزين عبر ContentResolver."))
            tempFile.inputStream().use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }
            Result.success(Unit)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemory in executive PDF export", oom)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء تصدير التقرير التنفيذي (OOM).", oom))
        } catch (e: Exception) {
            Log.e("ProfessionalReportExporter", "Error in executive PDF export", e)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            Result.failure(e)
        } finally {
            try {
                if (tempFile.exists()) tempFile.delete()
            } catch (_: Throwable) {}
        }
    }

    private fun drawExecutiveGeoSection(
        canvas: Canvas,
        startY: Float,
        geoItems: List<ExecutiveGeoItem>
    ): Float {
        var y = startY
        val sectionTitlePaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(15, 23, 42)
            textSize = 10f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("1. التوزيع الجغرافي ونسب التغطية الميدانية بالمحليات (Geographic Breakdown):", a4Width - marginH, y + 10f, sectionTitlePaint)
        y += 16f

        val headerHeight = 18f
        val headerBg = Paint().apply { color = AndroidGraphicsColor.rgb(15, 23, 42) }
        canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, headerBg)

        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.WHITE
            textSize = 7.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        val colWidths = floatArrayOf(24f, 150f, 90f, 85f, 190f)
        val colHeaders = arrayOf("م", "المحلية / النطاق الميداني", "عدد الأسر المسجلة", "النسبة المئوية", "مستوى التغطية الجغرافية")

        var curX = a4Width - marginH
        colHeaders.forEachIndexed { i, title ->
            val w = colWidths[i]
            canvas.drawText(title, curX - (w / 2f), y + 12f, headerTextPaint)
            curX -= w
        }
        y += headerHeight

        val rowHeight = 16f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = AndroidGraphicsColor.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = AndroidGraphicsColor.rgb(248, 250, 252) }
        val barBg = Paint().apply { color = AndroidGraphicsColor.rgb(226, 232, 240) }
        val barFill = Paint().apply { color = AndroidGraphicsColor.rgb(13, 148, 136) }

        val displayItems = geoItems.take(6)
        displayItems.forEachIndexed { idx, item ->
            val isEven = idx % 2 == 0
            if (isEven) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            // 0: م
            canvas.drawText("${idx + 1}", x - (colWidths[0] / 2f), y + 11f, rowTextCenter)
            x -= colWidths[0]

            // 1: اسم المحلية
            val name = if (item.name.length > 25) item.name.substring(0, 23) + ".." else item.name
            canvas.drawText(name, x - 6f, y + 11f, rowTextRight)
            x -= colWidths[1]

            // 2: عدد الأسر
            canvas.drawText(String.format(Locale.US, "%,d", item.count), x - (colWidths[2] / 2f), y + 11f, rowTextCenter)
            x -= colWidths[2]

            // 3: النسبة المئوية
            canvas.drawText(String.format(Locale.US, "%.1f%%", item.percentage), x - (colWidths[3] / 2f), y + 11f, rowTextCenter)
            x -= colWidths[3]

            // 4: شريط بياني أفقي
            val barW = colWidths[4] - 20f
            val barLeft = x - colWidths[4] + 10f
            val barTop = y + 5f
            val barBottom = y + 11f
            val fillW = (barW * (item.percentage.toFloat() / 100f).coerceIn(0f, 1f))
            canvas.drawRoundRect(RectF(barLeft, barTop, barLeft + barW, barBottom), 2f, 2f, barBg)
            if (fillW > 0f) {
                canvas.drawRoundRect(RectF(barLeft, barTop, barLeft + fillW, barBottom), 2f, 2f, barFill)
            }

            y += rowHeight
        }

        return y
    }

    private fun drawExecutiveBreakdownsSection(
        canvas: Canvas,
        startY: Float,
        shelterItems: List<ExecutiveCategoryItem>,
        damageItems: List<ExecutiveCategoryItem>
    ): Float {
        var y = startY
        val colGap = 12f
        val halfWidth = (contentWidth - colGap) / 2f

        val sectionTitlePaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(15, 23, 42)
            textSize = 10f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }

        // عناوين العمودين المتجاورين
        val rightColX = a4Width - marginH
        val leftColX = rightColX - halfWidth - colGap

        canvas.drawText("2. تصنيف حالة الإيواء (Shelter Status):", rightColX, y + 10f, sectionTitlePaint)
        canvas.drawText("3. تصنيف أضرار الحرب (War Damage):", leftColX, y + 10f, sectionTitlePaint)
        y += 16f

        val headerHeight = 16f
        val headerPaint = Paint().apply { color = AndroidGraphicsColor.rgb(51, 65, 85) }
        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.WHITE
            textSize = 7f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        // هيدر الإيواء (اليمين)
        canvas.drawRoundRect(RectF(rightColX - halfWidth, y, rightColX, y + headerHeight), 3f, 3f, headerPaint)
        canvas.drawText("نوع الإيواء", rightColX - 60f, y + 11f, headerTextPaint)
        canvas.drawText("الأسر", rightColX - halfWidth + 70f, y + 11f, headerTextPaint)
        canvas.drawText("النسبة", rightColX - halfWidth + 25f, y + 11f, headerTextPaint)

        // هيدر الأضرار (اليسار)
        canvas.drawRoundRect(RectF(leftColX - halfWidth, y, leftColX, y + headerHeight), 3f, 3f, headerPaint)
        canvas.drawText("حجم الضرر", leftColX - 60f, y + 11f, headerTextPaint)
        canvas.drawText("الأسر", leftColX - halfWidth + 70f, y + 11f, headerTextPaint)
        canvas.drawText("النسبة", leftColX - halfWidth + 25f, y + 11f, headerTextPaint)

        y += headerHeight

        val rowHeight = 15f
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(30, 41, 59)
            textSize = 7f
            textAlign = Paint.Align.RIGHT
        }
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(30, 41, 59)
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }
        val linePaint = Paint().apply {
            color = AndroidGraphicsColor.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }

        val maxRows = maxOf(shelterItems.size, damageItems.size).coerceAtMost(6)
        for (i in 0 until maxRows) {
            val shelter = shelterItems.getOrNull(i)
            val damage = damageItems.getOrNull(i)

            // رسم صف الإيواء (اليمين)
            if (shelter != null) {
                canvas.drawLine(rightColX - halfWidth, y + rowHeight, rightColX, y + rowHeight, linePaint)
                val sName = if (shelter.label.length > 18) shelter.label.substring(0, 16) + ".." else shelter.label
                canvas.drawText(sName, rightColX - 6f, y + 11f, rowTextRight)
                canvas.drawText(String.format(Locale.US, "%,d", shelter.count), rightColX - halfWidth + 70f, y + 11f, rowTextCenter)
                canvas.drawText(String.format(Locale.US, "%.1f%%", shelter.percentage), rightColX - halfWidth + 25f, y + 11f, rowTextCenter)
            }

            // رسم صف الأضرار (اليسار)
            if (damage != null) {
                canvas.drawLine(leftColX - halfWidth, y + rowHeight, leftColX, y + rowHeight, linePaint)
                val dName = if (damage.label.length > 18) damage.label.substring(0, 16) + ".." else damage.label
                canvas.drawText(dName, leftColX - 6f, y + 11f, rowTextRight)
                canvas.drawText(String.format(Locale.US, "%,d", damage.count), leftColX - halfWidth + 70f, y + 11f, rowTextCenter)
                canvas.drawText(String.format(Locale.US, "%.1f%%", damage.percentage), leftColX - halfWidth + 25f, y + 11f, rowTextCenter)
            }

            y += rowHeight
        }

        return y
    }

    private fun drawDynamicOfficialHeader(
        canvas: Canvas,
        reportTitle: String,
        subtitle: String,
        periodOrFilter: String,
        dateStr: String,
        pageWidth: Int,
        marginH: Float,
        startY: Float
    ): Float {
        var y = startY

        val topBarPaint = Paint().apply { color = AndroidGraphicsColor.rgb(13, 148, 136) }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 12f, topBarPaint)

        val accentBarPaint = Paint().apply { color = AndroidGraphicsColor.rgb(245, 158, 11) }
        canvas.drawRect(0f, 12f, pageWidth.toFloat(), 15f, accentBarPaint)

        y = 38f
        val orgPaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(15, 23, 42)
            textSize = 14f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("نظام إدارة المساعدات الإنسانية والعمليات الميدانية المعتمد", pageWidth - marginH, y, orgPaint)

        y += 18f
        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(13, 148, 136)
            textSize = 15f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(reportTitle, pageWidth - marginH, y, titlePaint)

        y += 10f
        val boxHeight = 44f
        val boxRect = RectF(marginH, y, pageWidth - marginH, y + boxHeight)
        val boxPaint = Paint().apply { color = AndroidGraphicsColor.rgb(248, 250, 252) }
        val boxStroke = Paint().apply {
            color = AndroidGraphicsColor.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(boxRect, 6f, 6f, boxPaint)
        canvas.drawRoundRect(boxRect, 6f, 6f, boxStroke)

        val metaPaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(51, 65, 85)
            textSize = 8.5f
            textAlign = Paint.Align.RIGHT
        }

        val datePaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(100, 116, 139)
            textSize = 8f
            textAlign = Paint.Align.LEFT
        }

        canvas.drawText(subtitle, pageWidth - marginH - 10f, y + 16f, metaPaint)
        canvas.drawText(periodOrFilter, pageWidth - marginH - 10f, y + 32f, metaPaint)
        canvas.drawText("تاريخ الإصدار: $dateStr", marginH + 10f, y + 16f, datePaint)
        canvas.drawText("المقاس: A4 Standard (رسمي للطباعة)", marginH + 10f, y + 32f, datePaint)

        return y + boxHeight
    }

    // =========================================================================
    // دوال رسم وتنسيق مستند A4 PDF
    // =========================================================================

    private fun drawOfficialHeader(
        canvas: Canvas,
        reportTitle: String,
        subtitle: String,
        periodOrFilter: String,
        dateStr: String,
        startY: Float
    ): Float {
        var y = startY

        // شريط علوي ملون متدرج بلون التركواز الداكن المؤسسي
        val topBarPaint = Paint().apply { color = android.graphics.Color.rgb(13, 148, 136) }
        canvas.drawRect(0f, 0f, a4Width.toFloat(), 12f, topBarPaint)

        // شريط ذهبي خفيف للرقي
        val accentBarPaint = Paint().apply { color = android.graphics.Color.rgb(245, 158, 11) }
        canvas.drawRect(0f, 12f, a4Width.toFloat(), 15f, accentBarPaint)

        y = 38f
        val orgPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(15, 23, 42) // Dark Slate
            textSize = 14f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("نظام إدارة المساعدات الإنسانية والعمليات الميدانية المعتمد", a4Width - marginH, y, orgPaint)

        y += 18f
        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(13, 148, 136)
            textSize = 15f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(reportTitle, a4Width - marginH, y, titlePaint)

        // صندوق البيانات الوصفية (Metadata Box)
        y += 10f
        val boxHeight = 44f
        val boxRect = RectF(marginH, y, a4Width - marginH, y + boxHeight)
        val boxPaint = Paint().apply { color = android.graphics.Color.rgb(248, 250, 252) }
        val boxStroke = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(boxRect, 6f, 6f, boxPaint)
        canvas.drawRoundRect(boxRect, 6f, 6f, boxStroke)

        val metaPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(51, 65, 85)
            textSize = 8.5f
            textAlign = Paint.Align.RIGHT
        }

        val datePaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(100, 116, 139)
            textSize = 8f
            textAlign = Paint.Align.LEFT
        }

        canvas.drawText(subtitle, a4Width - marginH - 10f, y + 16f, metaPaint)
        canvas.drawText(periodOrFilter, a4Width - marginH - 10f, y + 32f, metaPaint)
        canvas.drawText("تاريخ الإصدار: $dateStr", marginH + 10f, y + 16f, datePaint)
        canvas.drawText("المقاس: A4 Standard (رسمي للطباعة)", marginH + 10f, y + 32f, datePaint)

        return y + boxHeight
    }

    private data class KpiItem(val label: String, val value: String, val unit: String, val colorInt: Int)

    private fun drawKpiCards(
        canvas: Canvas,
        startY: Float,
        kpis: List<KpiItem>
    ): Float {
        val count = kpis.size
        val gap = 8f
        val totalGaps = gap * (count - 1)
        val cardWidth = (contentWidth - totalGaps) / count
        val cardHeight = 40f

        var currentX = a4Width - marginH

        kpis.forEach { kpi ->
            val left = currentX - cardWidth
            val rect = RectF(left, startY, currentX, startY + cardHeight)

            val bgPaint = Paint().apply { color = android.graphics.Color.rgb(255, 255, 255) }
            val borderPaint = Paint().apply {
                color = kpi.colorInt
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRoundRect(rect, 6f, 6f, bgPaint)
            canvas.drawRoundRect(rect, 6f, 6f, borderPaint)

            // علامة شريطية بلون الـ KPI
            val sideBar = RectF(currentX - 4f, startY, currentX, startY + cardHeight)
            val sidePaint = Paint().apply { color = kpi.colorInt }
            canvas.drawRoundRect(sideBar, 2f, 2f, sidePaint)

            val labelPaint = Paint().apply {
                isAntiAlias = true
                color = android.graphics.Color.rgb(100, 116, 139)
                textSize = 7.5f
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(kpi.label, currentX - 10f, startY + 14f, labelPaint)

            val valPaint = Paint().apply {
                isAntiAlias = true
                color = kpi.colorInt
                textSize = 12f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText("${kpi.value} ${kpi.unit}", currentX - 10f, startY + 31f, valPaint)

            currentX -= (cardWidth + gap)
        }

        return startY + cardHeight
    }

    private fun drawProjectBeneficiaryTable(
        canvas: Canvas,
        records: List<AidRecordWithBeneficiary>,
        startIndex: Int,
        startY: Float
    ): Float {
        var y = startY
        val colWidths = floatArrayOf(24f, 155f, 75f, 40f, 90f, 85f, 70f)
        val colHeaders = arrayOf("م", "اسم المستفيد الرباعي", "رقم الهوية", "الأفراد", "المنطقة / الشعبة", "حالة الاستلام", "التوقيع / البصمة")

        // رأس الجدول
        val headerHeight = 22f
        val headerBg = Paint().apply { color = android.graphics.Color.rgb(13, 148, 136) }
        canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, headerBg)

        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textSize = 8.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        var curX = a4Width - marginH
        colHeaders.forEachIndexed { i, title ->
            val w = colWidths[i]
            canvas.drawText(title, curX - (w / 2f), y + 14f, headerTextPaint)
            curX -= w
        }
        y += headerHeight

        // صفوف الجدول
        val rowHeight = 18f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = android.graphics.Color.rgb(248, 250, 252) }

        records.forEachIndexed { idx, item ->
            val isEven = idx % 2 == 0
            if (isEven) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            // 0: م
            canvas.drawText("${startIndex + idx + 1}", x - (colWidths[0] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[0]

            // 1: اسم المستفيد
            val name = item.family?.name ?: "مستفيد #${item.record.familyID}"
            val clippedName = if (name.length > 32) name.substring(0, 30) + "..." else name
            canvas.drawText(clippedName, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[1]

            // 2: الهوية
            canvas.drawText(item.family?.nationalID ?: "-", x - (colWidths[2] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[2]

            // 3: أفراد
            canvas.drawText("${item.family?.familyMembersCount ?: 0}", x - (colWidths[3] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[3]

            // 4: المنطقة
            val area = item.family?.currentSubArea ?: "-"
            val clippedArea = if (area.length > 18) area.substring(0, 16) + ".." else area
            canvas.drawText(clippedArea, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[4]

            // 5: حالة الاستلام
            val status = item.record.recipientStatus
            val statusPaint = Paint().apply {
                isAntiAlias = true
                textSize = 7.5f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
                color = if (status.contains("مستلم") || status.contains("تم التسليم")) android.graphics.Color.rgb(16, 185, 129) else android.graphics.Color.rgb(217, 119, 6)
            }
            canvas.drawText(status, x - (colWidths[5] / 2f), y + 12f, statusPaint)
            x -= colWidths[5]

            // 6: التوقيع / البصمة (مربع منقط خفيف)
            val boxPaint = Paint().apply {
                color = android.graphics.Color.rgb(203, 213, 225)
                style = Paint.Style.STROKE
                strokeWidth = 0.5f
            }
            canvas.drawRect(x - colWidths[6] + 8f, y + 3f, x - 8f, y + rowHeight - 3f, boxPaint)

            y += rowHeight
        }

        return y
    }

    private fun drawLocalitySubAreaTable(
        canvas: Canvas,
        subAreas: List<SubAreaBenefitRatioStat>,
        startIndex: Int,
        startY: Float
    ): Float {
        var y = startY
        val colWidths = floatArrayOf(24f, 155f, 80f, 80f, 70f, 65f, 65f)
        val colHeaders = arrayOf("م", "الشعبة / المنطقة الفرعية", "المستحقين (مقيم+معتمد)", "المستفيدين الفعليين", "إجمالي الأسر", "نسبة الإنجاز", "حالة التغطية")

        val headerHeight = 22f
        val headerBg = Paint().apply { color = android.graphics.Color.rgb(13, 148, 136) }
        canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, headerBg)

        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textSize = 8f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        var curX = a4Width - marginH
        colHeaders.forEachIndexed { i, title ->
            val w = colWidths[i]
            canvas.drawText(title, curX - (w / 2f), y + 14f, headerTextPaint)
            curX -= w
        }
        y += headerHeight

        val rowHeight = 18f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = android.graphics.Color.rgb(248, 250, 252) }

        subAreas.forEachIndexed { idx, sub ->
            val isEven = idx % 2 == 0
            if (isEven) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            // 0: م
            canvas.drawText("${startIndex + idx + 1}", x - (colWidths[0] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[0]

            // 1: اسم الشعبة
            canvas.drawText(sub.subAreaName, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[1]

            // 2: المستحقين
            canvas.drawText("${sub.eligibleFamiliesCount}", x - (colWidths[2] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[2]

            // 3: المستفيدين
            canvas.drawText("${sub.deliveredBeneficiariesCount}", x - (colWidths[3] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[3]

            // 4: إجمالي الأسر
            canvas.drawText("${sub.totalFamiliesCount}", x - (colWidths[4] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[4]

            // 5: نسبة الإنجاز
            val ratioPaint = Paint().apply {
                isAntiAlias = true
                textSize = 8f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
                color = if (sub.ratioPercentage >= 50) android.graphics.Color.rgb(16, 185, 129) else android.graphics.Color.rgb(245, 158, 11)
            }
            canvas.drawText(sub.formattedRatio, x - (colWidths[5] / 2f), y + 12f, ratioPaint)
            x -= colWidths[5]

            // 6: الحالة
            val statusPaint = Paint().apply {
                isAntiAlias = true
                textSize = 7f
                textAlign = Paint.Align.CENTER
                color = if (sub.ratioPercentage >= 50) android.graphics.Color.rgb(4, 120, 87) else android.graphics.Color.rgb(180, 83, 9)
            }
            val statusStr = if (sub.ratioPercentage >= 50) "تغطية ممتازة" else "قيد التوزيع"
            canvas.drawText(statusStr, x - (colWidths[6] / 2f), y + 12f, statusPaint)

            y += rowHeight
        }

        return y
    }

    private fun drawOfficialFooterWithSignatures(
        canvas: Canvas,
        supervisorName: String,
        pageIndex: Int,
        totalPages: Int
    ) {
        val y = a4Height - 85f

        // خط فاصل علوي
        val divPaint = Paint().apply {
            color = android.graphics.Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }
        canvas.drawLine(marginH, y, a4Width - marginH, y, divPaint)

        // 3 مربعات توقيع وخاتم رسمي
        val boxWidth = (contentWidth - 24f) / 3f
        val boxHeight = 44f
        val boxY = y + 8f

        val boxPaint = Paint().apply {
            color = android.graphics.Color.rgb(248, 250, 252)
        }
        val borderPaint = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val sigHeaderPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(71, 85, 105)
            textSize = 7.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val sigSubPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(100, 116, 139)
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }

        // 1. المشرف الميداني
        val b1 = RectF(a4Width - marginH - boxWidth, boxY, a4Width - marginH, boxY + boxHeight)
        canvas.drawRoundRect(b1, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b1, 4f, 4f, borderPaint)
        canvas.drawText("المشرف الميداني المسؤول", b1.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText(supervisorName, b1.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText("التوقيع: .....................", b1.centerX(), boxY + 36f, sigSubPaint)

        // 2. مدقق الرقابة والمطابقة
        val b2 = RectF(a4Width - marginH - (boxWidth * 2) - 12f, boxY, a4Width - marginH - boxWidth - 12f, boxY + boxHeight)
        canvas.drawRoundRect(b2, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b2, 4f, 4f, borderPaint)
        canvas.drawText("التدقيق والمطابقة الرقابية", b2.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText("مطابق لكشوفات الاستحقاق", b2.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText("التوقيع: .....................", b2.centerX(), boxY + 36f, sigSubPaint)

        // 3. خاتم الاعتماد الرسمي
        val b3 = RectF(marginH, boxY, marginH + boxWidth, boxY + boxHeight)
        canvas.drawRoundRect(b3, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b3, 4f, 4f, borderPaint)
        canvas.drawText("الختم والاعتماد الرسمي", b3.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText("إدارة المنظومة الإنسانية", b3.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText("[ ختم المنظمة المعتمد ]", b3.centerX(), boxY + 36f, sigSubPaint)

        // التذييل السفلي وأرقام الصفحات
        val footerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(148, 163, 184)
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("صفحة $pageIndex من $totalPages  •  نظام إدارة المساعدات الإنسانية - مستند رسمي معتمد وغير قابل للتعديل", a4Width / 2f, a4Height - 12f, footerTextPaint)
    }

    private fun drawPageNumberOnly(canvas: Canvas, pageIndex: Int, totalPages: Int) {
        val footerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(148, 163, 184)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("صفحة $pageIndex من $totalPages  •  نظام إدارة المساعدات الإنسانية", a4Width / 2f, a4Height - 14f, footerTextPaint)
    }

    // =========================================================================
    // دوال مساعدة لإنشاء أنماط خلايا Apache POI
    // =========================================================================

    private fun createTitleCellStyle(workbook: Workbook): CellStyle {
        val style = workbook.createCellStyle()
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 14
            color = IndexedColors.DARK_TEAL.index
        }
        style.setFont(font)
        style.alignment = HorizontalAlignment.CENTER
        style.verticalAlignment = VerticalAlignment.CENTER
        return style
    }

    private fun createHeaderCellStyle(workbook: Workbook): CellStyle {
        val style = workbook.createCellStyle()
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 10
            color = IndexedColors.WHITE.index
        }
        style.setFont(font)
        style.fillForegroundColor = IndexedColors.TEAL.index
        style.fillPattern = FillPatternType.SOLID_FOREGROUND
        style.alignment = HorizontalAlignment.CENTER
        style.verticalAlignment = VerticalAlignment.CENTER
        setThinBorders(style)
        return style
    }

    private fun createDataCellStyle(workbook: Workbook, isEven: Boolean): CellStyle {
        val style = workbook.createCellStyle()
        val font = workbook.createFont().apply {
            fontHeightInPoints = 9.toShort()
        }
        style.setFont(font)
        if (isEven) {
            style.fillForegroundColor = IndexedColors.GREY_25_PERCENT.index
            style.fillPattern = FillPatternType.SOLID_FOREGROUND
        }
        style.alignment = HorizontalAlignment.CENTER
        style.verticalAlignment = VerticalAlignment.CENTER
        setThinBorders(style)
        return style
    }

    private fun createMetaLabelStyle(workbook: Workbook): CellStyle {
        val style = workbook.createCellStyle()
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 9.toShort()
            color = IndexedColors.DARK_BLUE.index
        }
        style.setFont(font)
        style.alignment = HorizontalAlignment.RIGHT
        return style
    }

    private fun createMetaValueStyle(workbook: Workbook): CellStyle {
        val style = workbook.createCellStyle()
        val font = workbook.createFont().apply {
            fontHeightInPoints = 9.toShort()
        }
        style.setFont(font)
        style.alignment = HorizontalAlignment.RIGHT
        return style
    }

    private fun setThinBorders(style: CellStyle) {
        style.borderTop = BorderStyle.THIN
        style.borderBottom = BorderStyle.THIN
        style.borderLeft = BorderStyle.THIN
        style.borderRight = BorderStyle.THIN
    }

    // =========================================================================
    // دوال المشاركة، الطباعة، وفتح الملفات
    // =========================================================================

    fun shareFile(file: File, mimeType: String, title: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, "مرفق مستند معتمد: $title - صادر عن نظام إدارة المساعدات الإنسانية.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "مشاركة المستند المعتمد:")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun openFile(file: File, mimeType: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "فتح المستند بواسطة:"))
    }

    fun printPdfReport(pdfFile: File, jobName: String = "Aid_Management_Report") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return

        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = android.print.PrintDocumentInfo.Builder(jobName)
                    .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out android.print.PageRange>?,
                destination: android.os.ParcelFileDescriptor?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    val input = java.io.FileInputStream(pdfFile)
                    val output = java.io.FileOutputStream(destination?.fileDescriptor)

                    val buf = ByteArray(1024)
                    var bytesRead: Int
                    while (input.read(buf).also { bytesRead = it } > 0) {
                        output.write(buf, 0, bytesRead)
                    }

                    callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                    input.close()
                    output.close()
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                }
            }
        }

        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    }
}
