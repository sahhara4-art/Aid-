package com.humanitarian.aidmanagement.util

import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidGraphicsColor
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.currentSubRegion
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.data.repository.SubAreaBenefitRatioStat
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * بيانات سجل مساعدة مع تفاصيل الأسرة المستفيدة
 */
data class AidRecordWithBeneficiary(
    val record: AidRecordEntity,
    val family: FamilyEntity?
)

/**
 * بيانات تقرير المشروع والمستفيدين
 */
data class ProjectReportData(
    val project: ProjectEntity,
    val aidTypeName: String,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String,
    val notes: String? = null
)

/**
 * بيانات تقرير المحلية والشعب التابعة
 */
data class LocalityReportData(
    val localityName: String,
    val subAreas: List<SubAreaBenefitRatioStat>,
    val totalFamilies: Int,
    val totalBeneficiaries: Int,
    val totalDelivered: Int,
    val dateGenerated: String,
    val supervisorName: String
)

/**
 * بيانات تقرير التوزيع الشامل حسب الفترة الزمنية
 */
data class ComprehensivePeriodReportData(
    val fromDate: String,
    val toDate: String,
    val totalDeliveries: Int,
    val localityStats: List<LocalityDistributionStat>,
    val aidTypeStats: List<AidTypeDistributionStat>,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String
)

/**
 * بيانات عناصر التحليل الجغرافي للتقرير الإداري
 */
data class ExecutiveGeoItem(
    val name: String,
    val count: Int,
    val percentage: Double
)

/**
 * بيانات عناصر التصنيف للتقرير الإداري (الإيواء، أضرار الحرب، وأصناف المساعدات)
 */
data class ExecutiveCategoryItem(
    val label: String,
    val count: Int,
    val percentage: Double,
    val beneficiaryFamiliesCount: Int = 0
)

/**
 * إحصائيات تصنيف الأسر الرسمية حسب حالة الاعتماد والإقامة (معتمد / مقيم)
 */
data class ExecutiveFamilyStatusStats(
    val totalFamilies: Int = 0,
    val approvedFamilies: Int = 0,
    val approvedIndividuals: Int = 0,
    val residentFamilies: Int = 0,
    val residentIndividuals: Int = 0,
    val eligibleBothFamilies: Int = 0,
    val eligibleBothIndividuals: Int = 0,
    val otherFamilies: Int = 0,
    val otherIndividuals: Int = 0
)

/**
 * بيانات التحليل الديموغرافي الجغرافي الشامل (الأسر والأفراد)
 */
data class ExecutiveGeoDemographicItem(
    val regionName: String,
    val familyCount: Int,
    val familyPercentage: Double,
    val individualCount: Int,
    val individualPercentage: Double
)

/**
 * بيانات أداء وإنجاز المشاريع الإغاثية
 */
data class ProjectPerformanceStat(
    val projectId: Long,
    val projectName: String,
    val aidTypeName: String,
    val projectDate: String,
    val targetQuota: Int,
    val deliveredCount: Int,
    val completionPercentage: Double
)

/**
 * نموذج بيانات التقرير الإداري التنفيذي الموحد (Executive Reporting Dashboard)
 */
data class ExecutiveReportData(
    val fromDate: String,
    val toDate: String,
    val totalFamilies: Int,
    val totalDelivered: Int,
    val deliveryPercentage: Double,
    val geoBreakdown: List<ExecutiveGeoItem> = emptyList(),
    val shelterBreakdown: List<ExecutiveCategoryItem> = emptyList(),
    val damageBreakdown: List<ExecutiveCategoryItem> = emptyList(),
    val totalIndividuals: Int = 0,
    val activeProjectsCount: Int = 0,
    val geoDemographics: List<ExecutiveGeoDemographicItem> = emptyList(),
    val aidTypeBreakdown: List<ExecutiveCategoryItem> = emptyList(),
    val damageByRegionBreakdown: Map<String, List<ExecutiveCategoryItem>> = emptyMap(),
    val projectStatsList: List<ProjectPerformanceStat> = emptyList(),
    val familyStatusStats: ExecutiveFamilyStatusStats = ExecutiveFamilyStatusStats(),
    val dateGenerated: String = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.US).apply {
        calendar = GregorianCalendar(TimeZone.getDefault(), Locale.US)
    }.format(Date()),
    val supervisorName: String = "مدير العمليات المركزية"
)

/**
 * فئة احترافية متكاملة لتوليد تقارير A4 PDF رسمية وتصدير ملفات Excel (.xlsx) عبر Apache POI
 */
class ProfessionalReportExporter(private val context: Context) {

    // أبعاد صفحة A4 القياسية بنظام النقاط (Standard A4 Dimensions at 72 DPI)
    private val a4Width = 595
    private val a4Height = 842
    private val marginH = 28f
    private val contentWidth = a4Width - (marginH * 2) // 539 pt

    /**
     * الحصول على المجلد الآمن للمستندات المتوافق مع Scoped Storage (API 29+)
     */
    fun getSafeDocumentsDirectory(subDir: String): File {
        val baseDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_DOCUMENTS)
            ?: File(context.filesDir, "Documents")
        return File(baseDir, subDir).apply { mkdirs() }
    }

    // =========================================================================
    // 1. توليد تقرير المشروع ومستفيديه بصيغة A4 PDF
    // =========================================================================
    suspend fun generateProjectBeneficiariesPdf(data: ProjectReportData): Result<File> = withContext(Dispatchers.IO) {
        var pdfDocument: PdfDocument? = null
        try {
            pdfDocument = PdfDocument()

            val deliveredCount = data.records.count { it.record.recipientStatus.contains("مستلم") || it.record.recipientStatus.contains("تم التسليم") }
            val pendingCount = data.records.size - deliveredCount
            val ratePercent = if (data.records.isNotEmpty()) (deliveredCount * 100 / data.records.size) else 0

            val itemsPerPage = 22
            val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                var currentY = 16f
                currentY = drawOfficialHeader(
                    canvas = canvas,
                    reportTitle = "كشف مستفيدي المشروع الإنساني المعتمد",
                    subtitle = "المشروع: ${data.project.projectName} (${data.project.projectNumber})",
                    periodOrFilter = "الممول: ${data.project.fundingInstitution} | نوع المعونة: ${data.aidTypeName}",
                    dateStr = data.dateGenerated,
                    startY = currentY
                )

                if (pageIndex == 0) {
                    currentY = drawKpiCards(
                        canvas = canvas,
                        startY = currentY + 6f,
                        kpis = listOf(
                            KpiItem("إجمالي الكشف", "${data.records.size}", "مستفيد", android.graphics.Color.rgb(13, 148, 136)),
                            KpiItem("تم التسليم", "$deliveredCount", "طرد", android.graphics.Color.rgb(16, 185, 129)),
                            KpiItem("بانتظار الصرف", "$pendingCount", "مرشح", android.graphics.Color.rgb(245, 158, 11)),
                            KpiItem("نسبة الإنجاز", "$ratePercent%", "مكتمل", android.graphics.Color.rgb(2, 132, 199))
                        )
                    )
                } else {
                    currentY += 8f
                }

                // رسم جدول المستفيدين
                val startIndex = pageIndex * itemsPerPage
                val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
                val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

                currentY = drawProjectBeneficiaryTable(
                    canvas = canvas,
                    records = pageRecords,
                    startIndex = startIndex,
                    startY = currentY + 8f
                )

                // التذييل والتواقيع
                if (pageIndex == totalPages - 1) {
                    drawOfficialFooterWithSignatures(
                        canvas = canvas,
                        supervisorName = data.supervisorName,
                        pageIndex = pageIndex + 1,
                        totalPages = totalPages
                    )
                } else {
                    drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
                }

                pdfDocument.finishPage(page)
            }

            val reportsDir = getSafeDocumentsDirectory("pdf_reports")
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Project_${data.project.projectNumber}_$timeStamp.pdf")

            val currentDoc = pdfDocument
            FileOutputStream(outputFile).use { fos ->
                currentDoc?.let { doc -> doc.writeTo(fos) }
            }
            pdfDocument.close()
            pdfDocument = null
            Result.success(outputFile)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during PDF generation", oom)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء توليد تقرير PDF (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during PDF generation", t)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            Result.failure(Exception(t.message ?: "خطأ أثناء معالجة المستند", t))
        }
    }

    // =========================================================================
    // 2. توليد تقرير المحلية والشعب التابعة بصيغة A4 PDF
    // =========================================================================
    suspend fun generateLocalitySubAreasPdf(data: LocalityReportData): Result<File> = withContext(Dispatchers.IO) {
        var pdfDocument: PdfDocument? = null
        try {
            pdfDocument = PdfDocument()

            val itemsPerPage = 20
            val totalPages = if (data.subAreas.isEmpty()) 1 else ((data.subAreas.size - 1) / itemsPerPage) + 1

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                var currentY = 16f
                currentY = drawOfficialHeader(
                    canvas = canvas,
                    reportTitle = "تقرير التغطية الميدانية ونسب الاستفادة للمحلية",
                    subtitle = "المحلية المعتمدة: ${data.localityName}",
                    periodOrFilter = "حساب الاستحقاق الصارم: المستفيدين / الأسر المستحقة (مقيم + معتمد)",
                    dateStr = data.dateGenerated,
                    startY = currentY
                )

                if (pageIndex == 0) {
                    val totalEligible = data.subAreas.sumOf { it.eligibleFamiliesCount }
                    val totalDelivered = data.subAreas.sumOf { it.deliveredBeneficiariesCount }
                    val overallRatio = if (totalEligible > 0) (totalDelivered * 100 / totalEligible) else 0

                    currentY = drawKpiCards(
                        canvas = canvas,
                        startY = currentY + 6f,
                        kpis = listOf(
                            KpiItem("إجمالي الأسر", "${data.totalFamilies}", "أسرة", android.graphics.Color.rgb(13, 148, 136)),
                            KpiItem("المستحقين", "$totalEligible", "مقيم+معتمد", android.graphics.Color.rgb(2, 132, 199)),
                            KpiItem("المستفيدين الفعليين", "$totalDelivered", "مستفيد", android.graphics.Color.rgb(16, 185, 129)),
                            KpiItem("معدل التغطية", "$overallRatio%", "إنجاز", android.graphics.Color.rgb(245, 158, 11))
                        )
                    )
                } else {
                    currentY += 8f
                }

                val startIndex = pageIndex * itemsPerPage
                val endIndex = minOf(startIndex + itemsPerPage, data.subAreas.size)
                val pageSubAreas = if (data.subAreas.isNotEmpty()) data.subAreas.subList(startIndex, endIndex) else emptyList()

                currentY = drawLocalitySubAreaTable(
                    canvas = canvas,
                    subAreas = pageSubAreas,
                    startIndex = startIndex,
                    startY = currentY + 8f
                )

                if (pageIndex == totalPages - 1) {
                    drawOfficialFooterWithSignatures(
                        canvas = canvas,
                        supervisorName = data.supervisorName,
                        pageIndex = pageIndex + 1,
                        totalPages = totalPages
                    )
                } else {
                    drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
                }

                pdfDocument.finishPage(page)
            }

            val reportsDir = getSafeDocumentsDirectory("pdf_reports")
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Locality_${data.localityName}_$timeStamp.pdf")

            val currentDoc = pdfDocument
            FileOutputStream(outputFile).use { fos ->
                currentDoc?.let { doc -> doc.writeTo(fos) }
            }
            pdfDocument.close()
            pdfDocument = null
            Result.success(outputFile)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during PDF generation", oom)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء توليد تقرير PDF (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during PDF generation", t)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            Result.failure(Exception(t.message ?: "خطأ أثناء معالجة المستند", t))
        }
    }

    // =========================================================================
    // 3. توليد تقرير التوزيع الشامل حسب الفترة بصيغة A4 PDF
    // =========================================================================
    suspend fun generateComprehensivePeriodPdf(data: ComprehensivePeriodReportData): Result<File> = withContext(Dispatchers.IO) {
        var pdfDocument: PdfDocument? = null
        try {
            pdfDocument = PdfDocument()

            val itemsPerPage = 22
            val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                var currentY = 16f
                currentY = drawOfficialHeader(
                    canvas = canvas,
                    reportTitle = "تقرير التوزيع الشامل والعمليات الميدانية",
                    subtitle = "نطاق الفترة الزمنية المحددة: من ${data.fromDate} إلى ${data.toDate}",
                    periodOrFilter = "إجمالي المحليات النشطة: ${data.localityStats.size} | أصناف المساعدات: ${data.aidTypeStats.size}",
                    dateStr = data.dateGenerated,
                    startY = currentY
                )

                if (pageIndex == 0) {
                    currentY = drawKpiCards(
                        canvas = canvas,
                        startY = currentY + 6f,
                        kpis = listOf(
                            KpiItem("مساعدات الفترة", "${data.totalDeliveries}", "سجل/طرد", android.graphics.Color.rgb(13, 148, 136)),
                            KpiItem("المستفيدين الموثقين", "${data.records.size}", "مستلم", android.graphics.Color.rgb(16, 185, 129)),
                            KpiItem("المحليات المشمولة", "${data.localityStats.size}", "محلية", android.graphics.Color.rgb(2, 132, 199)),
                            KpiItem("أنواع المعونة", "${data.aidTypeStats.size}", "صنف", android.graphics.Color.rgb(139, 92, 246))
                        )
                    )
                } else {
                    currentY += 8f
                }

                val startIndex = pageIndex * itemsPerPage
                val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
                val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

                currentY = drawProjectBeneficiaryTable(
                    canvas = canvas,
                    records = pageRecords,
                    startIndex = startIndex,
                    startY = currentY + 8f
                )

                if (pageIndex == totalPages - 1) {
                    drawOfficialFooterWithSignatures(
                        canvas = canvas,
                        supervisorName = data.supervisorName,
                        pageIndex = pageIndex + 1,
                        totalPages = totalPages
                    )
                } else {
                    drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
                }

                pdfDocument.finishPage(page)
            }

            val reportsDir = getSafeDocumentsDirectory("pdf_reports")
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Comprehensive_${data.fromDate}_to_${data.toDate}_$timeStamp.pdf")

            val currentDoc = pdfDocument
            FileOutputStream(outputFile).use { fos ->
                currentDoc?.let { doc -> doc.writeTo(fos) }
            }
            pdfDocument.close()
            pdfDocument = null
            Result.success(outputFile)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError during PDF generation", oom)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء توليد تقرير PDF (Out of Memory). يرجى تقليل حجم البيانات.", oom))
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during PDF generation", t)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            Result.failure(Exception(t.message ?: "خطأ أثناء معالجة المستند", t))
        }
    }

    // =========================================================================
    // دوال مساعدة لمعالجة نصوص CSV وتوافق Microsoft Excel مع اللغة العربية
    // =========================================================================
    private fun escapeCsvCell(value: String): String {
        val clean = value.replace("\"", "\"\"")
        return if (clean.contains(",") || clean.contains("\"") || clean.contains("\n") || clean.contains("\r")) {
            "\"$clean\""
        } else {
            clean
        }
    }

    // =========================================================================
    // 4. تصدير تقرير المشروع ومستفيديه إلى Excel / CSV متوافق عبر SAF (Streaming SAF)
    // =========================================================================
    suspend fun exportProjectBeneficiariesExcelToUri(uri: Uri, data: ProjectReportData): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (data.records.isEmpty()) {
                return@withContext Result.failure(Exception("لا توجد بيانات مستفيدين مسجلة في هذا المشروع للتصدير."))
            }
            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى الكتابة للتخزين عبر ContentResolver."))

            outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
                // UTF-8 BOM لضمان قراءة اللغة العربية والأرقام مباشرة في Microsoft Excel
                writer.write("\uFEFF")
                writer.write(escapeCsvCell("كشف مستفيدي المشروع الإنساني المعتمد - ${data.project.projectName}") + "\n\n")
                writer.write("رقم المشروع:," + escapeCsvCell(data.project.projectNumber) + ",")
                writer.write("الجهة الممولة:," + escapeCsvCell(data.project.fundingInstitution ?: "غير محدد") + "\n")
                writer.write("نوع المساعدة:," + escapeCsvCell(data.aidTypeName) + ",")
                writer.write("تاريخ التقرير:," + escapeCsvCell(data.dateGenerated) + "\n")
                writer.write("المشرف الميداني:," + escapeCsvCell(data.supervisorName) + ",")
                writer.write("إجمالي السجلات:,${data.records.size} مستفيد\n\n")

                val headers = listOf(
                    "م",
                    "اسم رب الأسرة الرباعي",
                    "رقم الهوية الوطنية",
                    "أفراد الأسرة",
                    "رقم الجوال",
                    "المنطقة الفرعية الحالية",
                    "حالة الاستلام",
                    "ملاحظات الصرف والتحقق"
                )
                writer.write(headers.joinToString(",") { escapeCsvCell(it) } + "\n")

                data.records.forEachIndexed { i, item ->
                    val f = item.family
                    val r = item.record
                    val row = listOf(
                        (i + 1).toString(),
                        f?.name ?: "مستفيد #${r.familyID}",
                        f?.nationalID ?: "-",
                        (f?.familyMembersCount ?: 0).toString(),
                        f?.primaryPhone ?: "-",
                        f?.currentSubRegion ?: "-",
                        r.recipientStatus,
                        r.notes ?: ""
                    )
                    writer.write(row.joinToString(",") { escapeCsvCell(it) } + "\n")
                    if ((i + 1) % 500 == 0) writer.flush()
                }
                writer.flush()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during Project CSV export to URI", t)
            Result.failure(Exception("فشل تصدير كشف المشروع: ${t.message ?: "خطأ غير متوقع"}", t))
        }
    }

    suspend fun generateProjectBeneficiariesExcel(data: ProjectReportData): Result<File> = withContext(Dispatchers.IO) {
        try {
            if (data.records.isEmpty()) {
                return@withContext Result.failure(Exception("لا توجد بيانات مستفيدين مسجلة في هذا المشروع للتصدير."))
            }
            val reportsDir = getSafeDocumentsDirectory("excel_reports")
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Project_${data.project.projectNumber}_$timeStamp.csv")

            val sb = StringBuilder()
            sb.append("\uFEFF")
            sb.append(escapeCsvCell("كشف مستفيدي المشروع الإنساني المعتمد - ${data.project.projectName}")).append("\n\n")
            sb.append("رقم المشروع:,").append(escapeCsvCell(data.project.projectNumber)).append(",")
            sb.append("الجهة الممولة:,").append(escapeCsvCell(data.project.fundingInstitution ?: "غير محدد")).append("\n")
            sb.append("نوع المساعدة:,").append(escapeCsvCell(data.aidTypeName)).append(",")
            sb.append("تاريخ التقرير:,").append(escapeCsvCell(data.dateGenerated)).append("\n")
            sb.append("المشرف الميداني:,").append(escapeCsvCell(data.supervisorName)).append(",")
            sb.append("إجمالي السجلات:,").append("${data.records.size} مستفيد").append("\n\n")

            val headers = listOf(
                "م",
                "اسم رب الأسرة الرباعي",
                "رقم الهوية الوطنية",
                "أفراد الأسرة",
                "رقم الجوال",
                "المنطقة الفرعية الحالية",
                "حالة الاستلام",
                "ملاحظات الصرف والتحقق"
            )
            sb.append(headers.joinToString(",") { escapeCsvCell(it) }).append("\n")

            data.records.forEachIndexed { i, item ->
                val f = item.family
                val r = item.record
                val row = listOf(
                    (i + 1).toString(),
                    f?.name ?: "مستفيد #${r.familyID}",
                    f?.nationalID ?: "-",
                    (f?.familyMembersCount ?: 0).toString(),
                    f?.primaryPhone ?: "-",
                    f?.currentSubRegion ?: "-",
                    r.recipientStatus,
                    r.notes ?: ""
                )
                sb.append(row.joinToString(",") { escapeCsvCell(it) }).append("\n")
            }

            FileOutputStream(outputFile).use { fos ->
                fos.write(sb.toString().toByteArray(Charsets.UTF_8))
                fos.flush()
            }
            Result.success(outputFile)
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during Project CSV generation", t)
            Result.failure(Exception("فشل إنشاء ملف كشف المشروع: ${t.message ?: "خطأ غير متوقع"}", t))
        }
    }

    // =========================================================================
    // 5. تصدير تقرير المحلية والشعب إلى Excel (.xlsx) عبر SXSSFWorkbook (Streaming SAF)
    // =========================================================================
    suspend fun exportLocalitySubAreasExcelToUri(uri: Uri, data: LocalityReportData): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (data.subAreas.isEmpty()) {
                return@withContext Result.failure(Exception("لا توجد بيانات مناطق فرعية في هذه المحلية للتصدير."))
            }
            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى الكتابة للتخزين عبر ContentResolver."))

            val sb = StringBuilder()
            sb.append("\uFEFF")

            sb.append(escapeCsvCell("تقرير التغطية الميدانية ونسب الاستفادة - محلية ${data.localityName}")).append("\n\n")
            sb.append("المحلية المعتمدة:,").append(escapeCsvCell(data.localityName)).append(",")
            sb.append("تاريخ التقرير:,").append(escapeCsvCell(data.dateGenerated)).append("\n")
            sb.append("المشرف الميداني:,").append(escapeCsvCell(data.supervisorName)).append(",")
            sb.append("إجمالي الأسر المسجلة:,").append("${data.totalFamilies} أسرة").append("\n")
            sb.append("إجمالي المستحقين:,").append("${data.totalBeneficiaries} أسرة مستحقة").append(",")
            sb.append("إجمالي المستلمين:,").append("${data.totalDelivered} مستفيد").append("\n\n")

            val headers = listOf("م", "الشعبة / المنطقة الفرعية", "المستحقين (مقيم + معتمد)", "المستفيدين الفعليين", "إجمالي الأسر المسجلة", "نسبة التغطية والاستفادة", "حالة التغطية الميدانية")
            sb.append(headers.joinToString(",") { escapeCsvCell(it) }).append("\n")

            data.subAreas.forEachIndexed { i, sub ->
                val coverage = if (sub.ratioPercentage >= 50) "تغطية ممتازة" else "قيد التوزيع والمتابعة"
                val row = listOf(
                    (i + 1).toString(),
                    sub.subAreaName,
                    sub.eligibleFamiliesCount.toString(),
                    sub.deliveredBeneficiariesCount.toString(),
                    sub.totalFamiliesCount.toString(),
                    sub.formattedRatio,
                    coverage
                )
                sb.append(row.joinToString(",") { escapeCsvCell(it) }).append("\n")
            }

            outputStream.use { os ->
                os.write(sb.toString().toByteArray(Charsets.UTF_8))
                os.flush()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during Locality CSV export to URI", t)
            Result.failure(Exception("فشل تصدير كشف المحلية: ${t.message ?: "خطأ غير متوقع"}", t))
        }
    }

    suspend fun generateLocalitySubAreasExcel(data: LocalityReportData): Result<File> = withContext(Dispatchers.IO) {
        try {
            if (data.subAreas.isEmpty()) {
                return@withContext Result.failure(Exception("لا توجد بيانات مناطق فرعية في هذه المحلية للتصدير."))
            }
            val reportsDir = getSafeDocumentsDirectory("excel_reports")
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Locality_${data.localityName}_$timeStamp.csv")

            val sb = StringBuilder()
            sb.append("\uFEFF")
            sb.append(escapeCsvCell("تقرير التغطية الميدانية ونسب الاستفادة - محلية ${data.localityName}")).append("\n\n")
            sb.append("المحلية المعتمدة:,").append(escapeCsvCell(data.localityName)).append(",")
            sb.append("تاريخ التقرير:,").append(escapeCsvCell(data.dateGenerated)).append("\n")
            sb.append("المشرف الميداني:,").append(escapeCsvCell(data.supervisorName)).append(",")
            sb.append("إجمالي الأسر المسجلة:,").append("${data.totalFamilies} أسرة").append("\n\n")

            val headers = listOf("م", "الشعبة / المنطقة الفرعية", "المستحقين (مقيم + معتمد)", "المستفيدين الفعليين", "إجمالي الأسر المسجلة", "نسبة التغطية والاستفادة", "حالة التغطية الميدانية")
            sb.append(headers.joinToString(",") { escapeCsvCell(it) }).append("\n")

            data.subAreas.forEachIndexed { i, sub ->
                val coverage = if (sub.ratioPercentage >= 50) "تغطية ممتازة" else "قيد التوزيع والمتابعة"
                val row = listOf(
                    (i + 1).toString(),
                    sub.subAreaName,
                    sub.eligibleFamiliesCount.toString(),
                    sub.deliveredBeneficiariesCount.toString(),
                    sub.totalFamiliesCount.toString(),
                    sub.formattedRatio,
                    coverage
                )
                sb.append(row.joinToString(",") { escapeCsvCell(it) }).append("\n")
            }

            FileOutputStream(outputFile).use { fos ->
                fos.write(sb.toString().toByteArray(Charsets.UTF_8))
                fos.flush()
            }
            Result.success(outputFile)
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during Locality CSV file generation", t)
            Result.failure(Exception("فشل إنشاء ملف كشف المحلية: ${t.message ?: "خطأ غير متوقع"}", t))
        }
    }

    // =========================================================================
    // 6. تصدير تقرير التوزيع الشامل إلى Excel / CSV عبر SAF (Streaming SAF)
    // =========================================================================
    suspend fun exportComprehensivePeriodExcelToUri(uri: Uri, data: ComprehensivePeriodReportData): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (data.records.isEmpty()) {
                return@withContext Result.failure(Exception("لا توجد بيانات توزيع مسجلة في هذه الفترة للتصدير."))
            }
            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى الكتابة للتخزين عبر ContentResolver."))

            val sb = StringBuilder()
            sb.append("\uFEFF") // UTF-8 BOM

            sb.append(escapeCsvCell("تقرير التوزيع الشامل والعمليات الميدانية (${data.fromDate} إلى ${data.toDate})")).append("\n\n")
            sb.append("نطاق الفترة:,").append(escapeCsvCell("${data.fromDate} إلى ${data.toDate}")).append(",")
            sb.append("تاريخ التقرير:,").append(escapeCsvCell(data.dateGenerated)).append("\n")
            sb.append("المشرف المسؤول:,").append(escapeCsvCell(data.supervisorName)).append(",")
            sb.append("إجمالي المساعدات:,").append("${data.totalDeliveries} معونة").append("\n\n")

            val headers = listOf("م", "اسم المستفيد الرباعي", "رقم الهوية", "المنطقة الفرعية الحالية", "المشروع الإغاثي", "تاريخ التسليم", "حالة الاستلام", "المستلم الفعلي والملاحظات")
            sb.append(headers.joinToString(",") { escapeCsvCell(it) }).append("\n")

            data.records.forEachIndexed { i, item ->
                val f = item.family
                val r = item.record
                val row = listOf(
                    (i + 1).toString(),
                    f?.name ?: "-",
                    f?.nationalID ?: "-",
                    f?.currentSubRegion ?: "-",
                    "مشروع #${r.projectID}",
                    r.deliveryDate ?: r.aidDate,
                    r.recipientStatus,
                    r.notes ?: ""
                )
                sb.append(row.joinToString(",") { escapeCsvCell(it) }).append("\n")
            }

            outputStream.use { os ->
                os.write(sb.toString().toByteArray(Charsets.UTF_8))
                os.flush()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during comprehensive CSV export to URI", t)
            Result.failure(Exception("فشل تصدير تقرير التوزيع الشامل: ${t.message ?: "خطأ غير متوقع"}", t))
        }
    }

    suspend fun generateComprehensivePeriodExcel(data: ComprehensivePeriodReportData): Result<File> = withContext(Dispatchers.IO) {
        try {
            if (data.records.isEmpty()) {
                return@withContext Result.failure(Exception("لا توجد بيانات توزيع مسجلة في هذه الفترة للتصدير."))
            }
            val reportsDir = getSafeDocumentsDirectory("excel_reports")
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val outputFile = File(reportsDir, "Comprehensive_${data.fromDate}_to_${data.toDate}_$timeStamp.csv")

            val sb = StringBuilder()
            sb.append("\uFEFF")
            sb.append(escapeCsvCell("تقرير التوزيع الشامل والعمليات الميدانية (${data.fromDate} إلى ${data.toDate})")).append("\n\n")
            sb.append("نطاق الفترة:,").append(escapeCsvCell("${data.fromDate} إلى ${data.toDate}")).append(",")
            sb.append("تاريخ التقرير:,").append(escapeCsvCell(data.dateGenerated)).append("\n")
            sb.append("المشرف المسؤول:,").append(escapeCsvCell(data.supervisorName)).append(",")
            sb.append("إجمالي المساعدات:,").append("${data.totalDeliveries} معونة").append("\n\n")

            val headers = listOf("م", "اسم المستفيد الرباعي", "رقم الهوية", "المنطقة الفرعية الحالية", "المشروع الإغاثي", "تاريخ التسليم", "حالة الاستلام", "الملاحظات")
            sb.append(headers.joinToString(",") { escapeCsvCell(it) }).append("\n")

            data.records.forEachIndexed { i, item ->
                val f = item.family
                val r = item.record
                val row = listOf(
                    (i + 1).toString(),
                    f?.name ?: "-",
                    f?.nationalID ?: "-",
                    f?.currentSubRegion ?: "-",
                    "مشروع #${r.projectID}",
                    r.deliveryDate ?: r.aidDate,
                    r.recipientStatus,
                    r.notes ?: ""
                )
                sb.append(row.joinToString(",") { escapeCsvCell(it) }).append("\n")
            }

            FileOutputStream(outputFile).use { fos ->
                fos.write(sb.toString().toByteArray(Charsets.UTF_8))
                fos.flush()
            }
            Result.success(outputFile)
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during Comprehensive CSV file generation", t)
            Result.failure(Exception("فشل إنشاء ملف التوزيع الشامل: ${t.message ?: "خطأ غير متوقع"}", t))
        }
    }

    // =========================================================================
    // 7. التصدير الديناميكي المعتمد للأسر والمستفيدين إلى CSV / Excel المتوافق
    // بنية خفيفة الوزن فائقة السرعة بدون استهلاك ذاكرة (Zero-OOM Bulletproof CSV)
    // =========================================================================
    suspend fun exportDynamicFamiliesExcelToUri(
        uri: Uri,
        title: String,
        metaRows: List<Pair<String, String>>,
        records: List<AidRecordWithBeneficiary>,
        selectedColumnKeys: List<String>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val defs = ExportColumnRegistry.getOrderedDefs(selectedColumnKeys)
            if (defs.isEmpty()) {
                return@withContext Result.failure(Exception("لم يتم اختيار أي عمود للتصدير."))
            }
            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى التخزين عبر ContentResolver."))

            outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
                // UTF-8 BOM so Microsoft Excel renders Arabic characters natively
                writer.write("\uFEFF")

                if (title.isNotBlank()) {
                    writer.write(escapeCsvCell(title) + "\n\n")
                }
                if (metaRows.isNotEmpty()) {
                    for ((label, value) in metaRows) {
                        writer.write(escapeCsvCell(label) + "," + escapeCsvCell(value) + "\n")
                    }
                    writer.write("\n")
                }

                val headerLine = defs.joinToString(",") { escapeCsvCell(it.label) }
                writer.write(headerLine + "\n")

                records.forEachIndexed { i, item ->
                    val family = item.family ?: FamilyEntity(
                        familyID = item.record.familyID,
                        nationalID = "",
                        name = item.record.actualRecipientName?.takeIf { it.isNotBlank() } ?: "مستفيد #${item.record.familyID}"
                    )
                    val rowLine = defs.joinToString(",") { def ->
                        escapeCsvCell(def.valueExtractor(family, item.record, i + 1))
                    }
                    writer.write(rowLine + "\n")
                    if ((i + 1) % 500 == 0) writer.flush()
                }
                writer.flush()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during CSV export", t)
            Result.failure(Exception(t.message ?: "خطأ أثناء معالجة المستند", t))
        }
    }

    /**
     * التصدير الديناميكي المتدفق بالدفعات (Chunked Streaming Export - Zero OOM / Zero ANR)
     * يسحب السجلات على دفعات من SQLite (LIMIT 5000 OFFSET X) ويكتبها مباشرة على القرص سطراً بسطر
     */
    suspend fun exportDynamicFamiliesExcelChunkedToUri(
        uri: Uri,
        title: String,
        metaRows: List<Pair<String, String>>,
        selectedColumnKeys: List<String>,
        chunkSize: Int = 5000,
        fetchChunk: suspend (limit: Int, offset: Int) -> List<AidRecordWithBeneficiary>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val defs = ExportColumnRegistry.getOrderedDefs(selectedColumnKeys)
            if (defs.isEmpty()) {
                return@withContext Result.failure(Exception("لم يتم اختيار أي عمود للتصدير."))
            }

            val firstChunk = fetchChunk(chunkSize, 0)
            if (firstChunk.isEmpty()) {
                return@withContext Result.failure(Exception("لا توجد سجلات مطابقة للتصدير."))
            }

            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى التخزين عبر ContentResolver."))

            outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
                writer.write("\uFEFF") // UTF-8 BOM
                if (title.isNotBlank()) {
                    writer.write(escapeCsvCell(title) + "\n\n")
                }
                if (metaRows.isNotEmpty()) {
                    for ((label, value) in metaRows) {
                        writer.write(escapeCsvCell(label) + "," + escapeCsvCell(value) + "\n")
                    }
                    writer.write("\n")
                }
                writer.write(defs.joinToString(",") { escapeCsvCell(it.label) } + "\n")

                var offset = 0
                var rowIndex = 0
                var currentChunk = firstChunk
                while (currentChunk.isNotEmpty()) {
                    for (item in currentChunk) {
                        rowIndex++
                        val family = item.family ?: FamilyEntity(
                            familyID = item.record.familyID,
                            nationalID = "",
                            name = item.record.actualRecipientName?.takeIf { it.isNotBlank() } ?: "مستفيد #${item.record.familyID}"
                        )
                        val rowLine = defs.joinToString(",") { def ->
                            escapeCsvCell(def.valueExtractor(family, item.record, rowIndex))
                        }
                        writer.write(rowLine + "\n")
                    }
                    writer.flush()
                    if (currentChunk.size < chunkSize) break
                    offset += currentChunk.size
                    currentChunk = fetchChunk(chunkSize, offset)
                }
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during chunked CSV export", t)
            Result.failure(Exception(t.message ?: "خطأ أثناء معالجة المستند", t))
        }
    }

    /**
     * التصدير المتدفق بالدفعات لجدول الأسر (Chunked Streaming Families Export - Zero OOM)
     */
    suspend fun exportFamiliesExcelChunkedToUri(
        uri: Uri,
        reportTitle: String,
        selectedColumnKeys: List<String>,
        chunkSize: Int = 5000,
        fetchChunk: suspend (limit: Int, offset: Int) -> List<FamilyEntity>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val defs = ExportColumnRegistry.getOrderedDefs(selectedColumnKeys)
            if (defs.isEmpty()) {
                return@withContext Result.failure(Exception("لم يتم اختيار أي عمود للتصدير."))
            }

            val firstChunk = fetchChunk(chunkSize, 0)
            if (firstChunk.isEmpty()) {
                return@withContext Result.failure(Exception("لا توجد بيانات مستفيدين للتصدير."))
            }

            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى التخزين عبر ContentResolver."))

            outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
                writer.write("\uFEFF")
                if (reportTitle.isNotBlank()) {
                    writer.write(escapeCsvCell(reportTitle) + "\n\n")
                }
                writer.write(defs.joinToString(",") { escapeCsvCell(it.label) } + "\n")

                var offset = 0
                var rowIndex = 0
                var currentChunk = firstChunk
                while (currentChunk.isNotEmpty()) {
                    for (family in currentChunk) {
                        rowIndex++
                        val rowLine = defs.joinToString(",") { def ->
                            escapeCsvCell(def.valueExtractor(family, null, rowIndex))
                        }
                        writer.write(rowLine + "\n")
                    }
                    writer.flush()
                    if (currentChunk.size < chunkSize) break
                    offset += currentChunk.size
                    currentChunk = fetchChunk(chunkSize, offset)
                }
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during chunked families CSV export", t)
            Result.failure(Exception(t.message ?: "خطأ أثناء معالجة المستند", t))
        }
    }

    /**
     * تصدير مخصص لكشف المستفيدين (List<FamilyEntity>) مباشرة بصيغة CSV المتوافقة مع Excel
     */
    suspend fun exportDynamicFamiliesExcelToUri(
        uri: Uri,
        reportTitle: String,
        selectedColumnKeys: List<String>,
        families: List<FamilyEntity>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val defs = ExportColumnRegistry.getOrderedDefs(selectedColumnKeys)
            if (defs.isEmpty()) {
                return@withContext Result.failure(Exception("لم يتم اختيار أي عمود للتصدير."))
            }
            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى التخزين عبر ContentResolver."))

            outputStream.bufferedWriter(Charsets.UTF_8).use { writer ->
                writer.write("\uFEFF")
                writer.write(defs.joinToString(",") { escapeCsvCell(it.label) } + "\n")

                families.forEachIndexed { i, family ->
                    val rowLine = defs.joinToString(",") { def ->
                        escapeCsvCell(def.valueExtractor(family, null, i + 1))
                    }
                    writer.write(rowLine + "\n")
                    if ((i + 1) % 500 == 0) writer.flush()
                }
                writer.flush()
            }
            Result.success(Unit)
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error during CSV export", t)
            Result.failure(Exception(t.message ?: "خطأ أثناء معالجة المستند", t))
        }
    }

    // =========================================================================
    // 8. التصدير الديناميكي المتقدم للأسر والمستفيدين إلى PDF عبر Cache-First SAF
    // =========================================================================
    suspend fun exportDynamicFamiliesPdfToUri(
        uri: Uri,
        title: String,
        subtitle: String,
        metaRows: List<Pair<String, String>>,
        records: List<AidRecordWithBeneficiary>,
        selectedColumnKeys: List<String>
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val defs = ExportColumnRegistry.getOrderedDefs(selectedColumnKeys)
        if (defs.isEmpty()) {
            return@withContext Result.failure(Exception("لم يتم اختيار أي عمود للتصدير."))
        }
        var pdfDocument: PdfDocument? = null
        val tempFile = File(getSafeDocumentsDirectory("temp_reports"), "dynamic_export_${System.currentTimeMillis()}.pdf")
        try {
            pdfDocument = PdfDocument()

            val useLandscape = defs.size > 6
            val pageWidth = if (useLandscape) 842 else 595
            val pageHeight = if (useLandscape) 595 else 842
            val marginH = 24f
            val availableWidth = pageWidth - (marginH * 2)

            val totalWeight = defs.sumOf { it.pdfWeight.toDouble() }.toFloat().coerceAtLeast(1f)
            val colWidths = defs.map { (it.pdfWeight / totalWeight) * availableWidth }

            val itemsPerPage = if (useLandscape) 18 else 22
            val totalPages = if (records.isEmpty()) 1 else ((records.size - 1) / itemsPerPage) + 1

            val paint = Paint().apply { isAntiAlias = true }
            val textPaint = Paint().apply {
                isAntiAlias = true
                textSize = if (defs.size > 8) 7.5f else 8.5f
                color = AndroidGraphicsColor.BLACK
                typeface = Typeface.DEFAULT
            }
            val headerTextPaint = Paint().apply {
                isAntiAlias = true
                textSize = if (defs.size > 8) 8f else 9f
                color = AndroidGraphicsColor.WHITE
                isFakeBoldText = true
            }

            for (pageIndex in 0 until totalPages) {
                val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
                val page = pdfDocument.startPage(pageInfo)
                val canvas = page.canvas

                var currentY = 16f
                currentY = drawDynamicOfficialHeader(
                    canvas = canvas,
                    reportTitle = title,
                    subtitle = subtitle,
                    periodOrFilter = metaRows.joinToString(" • ") { "${it.first}: ${it.second}" },
                    dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()),
                    pageWidth = pageWidth,
                    marginH = marginH,
                    startY = currentY
                )

                val headerHeight = 22f
                val rowHeight = 19f
                var tableX = pageWidth - marginH

                paint.color = AndroidGraphicsColor.rgb(15, 23, 42)
                paint.style = Paint.Style.FILL
                canvas.drawRect(marginH, currentY, pageWidth - marginH, currentY + headerHeight, paint)

                defs.forEachIndexed { colIdx, def ->
                    val w = colWidths[colIdx]
                    val cellLeft = tableX - w
                    tableX -= w

                    paint.color = AndroidGraphicsColor.rgb(51, 65, 85)
                    paint.strokeWidth = 0.5f
                    canvas.drawLine(cellLeft, currentY, cellLeft, currentY + headerHeight, paint)

                    val labelText = def.label
                    val textW = headerTextPaint.measureText(labelText)
                    val textX = cellLeft + (w - textW) / 2f
                    val textY = currentY + (headerHeight / 2f) - ((headerTextPaint.descent() + headerTextPaint.ascent()) / 2f)
                    canvas.drawText(labelText, textX, textY, headerTextPaint)
                }

                currentY += headerHeight

                val pageStartIndex = pageIndex * itemsPerPage
                val pageEndIndex = minOf(pageStartIndex + itemsPerPage, records.size)
                val pageRecords = records.subList(pageStartIndex, pageEndIndex)

                pageRecords.forEachIndexed { rIdx, item ->
                    val globalIdx = pageStartIndex + rIdx + 1
                    val family = item.family ?: FamilyEntity(
                        familyID = item.record.familyID,
                        nationalID = "",
                        name = item.record.actualRecipientName?.takeIf { it.isNotBlank() } ?: "مستفيد #${item.record.familyID}"
                    )
                    val isEven = rIdx % 2 == 0

                    paint.color = if (isEven) AndroidGraphicsColor.WHITE else AndroidGraphicsColor.rgb(241, 245, 249)
                    paint.style = Paint.Style.FILL
                    canvas.drawRect(marginH, currentY, pageWidth - marginH, currentY + rowHeight, paint)

                    paint.color = AndroidGraphicsColor.rgb(226, 232, 240)
                    paint.strokeWidth = 0.5f
                    canvas.drawLine(marginH, currentY + rowHeight, pageWidth - marginH, currentY + rowHeight, paint)

                    var cellX = pageWidth - marginH
                    defs.forEachIndexed { colIdx, def ->
                        val w = colWidths[colIdx]
                        val cellLeft = cellX - w
                        cellX -= w

                        paint.color = AndroidGraphicsColor.rgb(226, 232, 240)
                        paint.strokeWidth = 0.5f
                        canvas.drawLine(cellLeft, currentY, cellLeft, currentY + rowHeight, paint)

                        val rawValue = def.valueExtractor(family, item.record, globalIdx)
                        val maxTextW = w - 6f
                        var displayText = rawValue
                        if (textPaint.measureText(displayText) > maxTextW && maxTextW > 10f) {
                            while (displayText.isNotEmpty() && textPaint.measureText("$displayText…") > maxTextW) {
                                displayText = displayText.dropLast(1)
                            }
                            displayText = "$displayText…"
                        }

                        val tw = textPaint.measureText(displayText)
                        val tx = cellLeft + (w - tw) / 2f
                        val ty = currentY + (rowHeight / 2f) - ((textPaint.descent() + textPaint.ascent()) / 2f)
                        canvas.drawText(displayText, tx, ty, textPaint)
                    }

                    currentY += rowHeight
                }

                val pageFooterText = "صفحة ${pageIndex + 1} من $totalPages • نظام إدارة المساعدات الإنسانية - دولة فلسطين"
                val footerPaint = Paint().apply {
                    isAntiAlias = true
                    textSize = 8f
                    color = AndroidGraphicsColor.GRAY
                }
                val fw = footerPaint.measureText(pageFooterText)
                canvas.drawText(pageFooterText, (pageWidth - fw) / 2f, pageHeight - 16f, footerPaint)

                pdfDocument.finishPage(page)
            }

            val currentDoc = pdfDocument
            FileOutputStream(tempFile).use { fos ->
                currentDoc?.let { doc ->
                    doc.writeTo(fos)
                    fos.flush()
                }
            }
            pdfDocument.close()
            pdfDocument = null

            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى التخزين عبر ContentResolver."))
            tempFile.inputStream().use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }
            Result.success(Unit)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemoryError in dynamic PDF export", oom)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء تصدير PDF (OOM).", oom))
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error in dynamic PDF export", t)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            Result.failure(Exception(t.message ?: "خطأ أثناء معالجة المستند", t))
        } finally {
            try {
                if (tempFile.exists()) tempFile.delete()
            } catch (_: Throwable) {}
        }
    }

    /**
     * تصدير كشف المستفيدين (List<FamilyEntity>) بصيغة PDF وفق الأعمدة المحددة
     */
    suspend fun exportDynamicFamiliesPdfToUri(
        uri: Uri,
        reportTitle: String,
        selectedColumnKeys: List<String>,
        families: List<FamilyEntity>,
        supervisorName: String = "مدير العمليات المركزية"
    ): Result<Unit> {
        val todayStr = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date())
        val records = families.map { family ->
            AidRecordWithBeneficiary(
                record = AidRecordEntity(
                    aidRecordID = 0L,
                    familyID = family.familyID,
                    aidTypeID = 1,
                    projectID = 0L,
                    aidDate = todayStr,
                    selectionDate = todayStr,
                    recipientStatus = "معتمد"
                ),
                family = family
            )
        }
        val metaRows = listOf(
            "إجمالي الأسر المشمولة" to "${families.size} أسرة",
            "المشرف المسؤول" to supervisorName,
            "تاريخ التقرير" to todayStr
        )
        return exportDynamicFamiliesPdfToUri(
            uri = uri,
            title = reportTitle,
            subtitle = "كشف المستفيدين التنفيذي المعتمد للعمليات الميدانية",
            metaRows = metaRows,
            records = records,
            selectedColumnKeys = selectedColumnKeys
        )
    }

    /**
     * تصدير التقرير الإداري التنفيذي الموحد (Executive BI PDF Report) بصيغة A4 قياسية (595 × 842 pt)
     * - محرك تدفق ديناميكي ذكي (Dynamic Flow Layout Engine) على مرحلتين لإلغاء الفراغات وتكرار رؤوس الجداول تلقائياً
     * - رسوم بيانية متجهة (Native Vector Canvas Charts): رسم حلقي (Donut) + أعمدة أفقية + أشرطة مقارنة
     * - معمارية Cache-First الصارمة على Dispatchers.IO لمنع تعارض SAF وحماية الذاكرة
     */
    suspend fun exportExecutiveReportPdfToUri(
        uri: Uri,
        data: ExecutiveReportData
    ): Result<Unit> = withContext(Dispatchers.IO) {
        var pdfDocument: PdfDocument? = null
        val tempFile = File(getSafeDocumentsDirectory("temp_reports"), "exec_bi_dashboard_${System.currentTimeMillis()}.pdf")
        try {
            // المرحلة الأولى: تمريرة قياس سريعة لحساب العدد الدقيق للصفحات قبل الترقيم
            val exactTotalPages = renderExecutiveReportPass(
                pdfDocument = null,
                data = data,
                knownTotalPages = 1
            ).coerceAtLeast(1)

            // المرحلة الثانية: الرسم الفعلي المتجه عالي الدقة في مستند PdfDocument
            pdfDocument = PdfDocument()
            renderExecutiveReportPass(
                pdfDocument = pdfDocument,
                data = data,
                knownTotalPages = exactTotalPages
            )

            // حفظ الملف مؤقتاً في ذاكرة التخزين المؤقت (Cache-First)
            val currentDoc = pdfDocument
            FileOutputStream(tempFile).use { fos ->
                currentDoc?.let { doc ->
                    doc.writeTo(fos)
                    fos.flush()
                }
            }
            pdfDocument.close()
            pdfDocument = null

            // دفق المحتوى بأمان إلى Storage Access Framework Uri
            val outputStream: OutputStream = context.contentResolver.openOutputStream(uri)
                ?: return@withContext Result.failure(Exception("تعذر فتح مجرى التخزين عبر ContentResolver."))
            tempFile.inputStream().use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }
            Result.success(Unit)
        } catch (oom: OutOfMemoryError) {
            Log.e("ProfessionalReportExporter", "OutOfMemory in executive PDF export", oom)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            System.gc()
            Result.failure(Exception("نفدت ذاكرة التطبيق أثناء تصدير التقرير التنفيذي (OOM).", oom))
        } catch (t: Throwable) {
            Log.e("ProfessionalReportExporter", "Error in executive PDF export", t)
            try { pdfDocument?.close() } catch (_: Throwable) {}
            Result.failure(Exception(t.message ?: "خطأ أثناء معالجة المستند", t))
        } finally {
            try {
                if (tempFile.exists()) tempFile.delete()
            } catch (_: Throwable) {}
        }
    }

    // ألوان الهوية البصرية للتقرير التنفيذي المتجه
    private val execEmerald = AndroidGraphicsColor.rgb(13, 148, 136)
    private val execNavy = AndroidGraphicsColor.rgb(15, 23, 42)
    private val execRoyalBlue = AndroidGraphicsColor.rgb(30, 64, 175)
    private val execSkyBlue = AndroidGraphicsColor.rgb(2, 132, 199)
    private val execGold = AndroidGraphicsColor.rgb(217, 119, 6)
    private val execSlate = AndroidGraphicsColor.rgb(100, 116, 139)
    private val execSlateDark = AndroidGraphicsColor.rgb(30, 41, 59)
    private val execBorder = AndroidGraphicsColor.rgb(226, 232, 240)
    private val execSoftBg = AndroidGraphicsColor.rgb(248, 250, 252)
    private val execCrimson = AndroidGraphicsColor.rgb(220, 38, 38)
    private val execGreen = AndroidGraphicsColor.rgb(22, 163, 74)

    private data class ExecutiveChartSlice(
        val label: String,
        val count: Int,
        val percentage: Double,
        val color: Int,
        val subLabel: String = ""
    )

    /**
     * تنسيق تاريخ الإصدار بالتقويم الميلادي الصريح (dd-MM-yyyy HH:mm) بأرقام غربية واضحة
     */
    private fun formatExecutiveIssueDate(rawDate: String?): String {
        val gregorianFormatter = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale.US).apply {
            calendar = GregorianCalendar(TimeZone.getDefault(), Locale.US)
        }
        val trimmed = rawDate?.trim().orEmpty()
        if (trimmed.isEmpty()) return gregorianFormatter.format(Date())

        val candidates = listOf(
            "dd-MM-yyyy HH:mm",
            "yyyy-MM-dd HH:mm",
            "yyyy/MM/dd HH:mm",
            "dd/MM/yyyy HH:mm",
            "yyyy-MM-dd"
        )
        for (pattern in candidates) {
            try {
                val parser = SimpleDateFormat(pattern, Locale.US).apply {
                    isLenient = false
                    calendar = GregorianCalendar(TimeZone.getDefault(), Locale.US)
                }
                val parsed = parser.parse(trimmed)
                if (parsed != null) {
                    val cal = GregorianCalendar(TimeZone.getDefault(), Locale.US).apply { time = parsed }
                    if (cal.get(Calendar.YEAR) >= 2020) {
                        return gregorianFormatter.format(parsed)
                    }
                }
            } catch (_: Exception) {
            }
        }
        return gregorianFormatter.format(Date())
    }

    /**
     * صياغة الفترة التحليلية بذكاء: استبدال النطاق الافتراضي الوهمي بعبارة رسمية معتمدة
     */
    private fun formatExecutivePeriodLabel(fromDate: String, toDate: String): String {
        val from = fromDate.trim()
        val to = toDate.trim()
        val isDefaultOrBlank = from.isEmpty() || to.isEmpty() ||
            (from == "2020-01-01" && to == "2030-12-31") ||
            (from == "2020/01/01" && to == "2030/12/31")
        return if (isDefaultOrBlank) {
            "الفترة التحليلية: البيانات التراكمية المعتمدة حتى تاريخ الإصدار"
        } else {
            "الفترة التحليلية: من \u2066$from\u2069 إلى \u2066$to\u2069"
        }
    }

    /**
     * تقسيم النص العربي متعدد الأسطر بدقة وفق العرض الفعلي بالبكسل دون قص أو بتر
     */
    private fun wrapExecutiveTextLines(text: String, paint: Paint, maxWidth: Float): List<String> {
        val cleaned = text.trim()
        if (cleaned.isEmpty()) return listOf("-")
        if (paint.measureText(cleaned) <= maxWidth) return listOf(cleaned)

        val result = mutableListOf<String>()
        // التقسيم المفضل عند فواصل البنود أولاً (•) ثم عند المسافات
        val segments = if (cleaned.contains(" • ")) {
            cleaned.split(" • ").mapIndexed { i, part -> if (i == 0) part else "• $part" }
        } else {
            cleaned.split(Regex("\\s+"))
        }

        var currentLine = ""
        for (segment in segments) {
            val candidate = if (currentLine.isEmpty()) segment else "$currentLine $segment"
            if (paint.measureText(candidate) <= maxWidth) {
                currentLine = candidate
            } else {
                if (currentLine.isNotEmpty()) {
                    result.add(currentLine)
                    currentLine = ""
                }
                if (paint.measureText(segment) <= maxWidth) {
                    currentLine = segment
                } else {
                    // تقسيم إضافي بالكلمات إذا كان البند الواحد أعرض من الخلية
                    val words = segment.split(Regex("\\s+"))
                    for (word in words) {
                        val wordCand = if (currentLine.isEmpty()) word else "$currentLine $word"
                        if (paint.measureText(wordCand) <= maxWidth) {
                            currentLine = wordCand
                        } else {
                            if (currentLine.isNotEmpty()) result.add(currentLine)
                            currentLine = word
                        }
                    }
                }
            }
        }
        if (currentLine.isNotEmpty()) result.add(currentLine)
        return result.ifEmpty { listOf(cleaned) }
    }

    /**
     * جلسة تدفق الصفحات الديناميكية للتقرير التنفيذي (Dynamic Flow Layout Engine)
     * تمنع الفراغات الكبيرة، وتفتح صفحة جديدة تلقائياً فقط عند عدم كفاية المساحة الفعلية
     */
    private inner class ExecutiveFlowSession(
        private val pdfDocument: PdfDocument?,
        private val periodLabel: String,
        private val formattedDate: String,
        private val knownTotalPages: Int
    ) {
        private var dummyBitmap: Bitmap? = if (pdfDocument == null) {
            Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8)
        } else null
        private val dummyCanvas: Canvas? = dummyBitmap?.let { Canvas(it) }

        var currentPage: PdfDocument.Page? = null
        var canvas: Canvas = dummyCanvas ?: Canvas()
        var pageNumber: Int = 0
        var currentY: Float = 0f

        val bottomLimit: Float = a4Height - 32f
        val sectionGap: Float = 15f

        fun startFirstPage() {
            pageNumber = 1
            if (pdfDocument != null) {
                val info = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageNumber).create()
                currentPage = pdfDocument.startPage(info)
                canvas = currentPage!!.canvas
            } else {
                canvas = dummyCanvas!!
            }
            currentY = drawDynamicOfficialHeader(
                canvas = canvas,
                reportTitle = "التقرير الإداري التنفيذي الموحد - مؤشرات العمليات",
                subtitle = "الإدارة العامة للإغاثة والطوارئ • وحدة ذكاء الأعمال والقيادة الميدانية",
                periodOrFilter = periodLabel,
                dateStr = formattedDate,
                pageWidth = a4Width,
                marginH = marginH,
                startY = 0f
            ) + 10f
        }

        fun startContinuationPage() {
            if (pageNumber > 0) {
                drawPageNumberOnly(canvas, pageNumber, knownTotalPages)
                if (pdfDocument != null && currentPage != null) {
                    pdfDocument.finishPage(currentPage!!)
                    currentPage = null
                }
            }
            pageNumber++
            if (pdfDocument != null) {
                val info = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageNumber).create()
                currentPage = pdfDocument.startPage(info)
                canvas = currentPage!!.canvas
            } else {
                canvas = dummyCanvas!!
            }
            currentY = drawExecutiveContinuationHeader(canvas, periodLabel, formattedDate) + 10f
        }

        fun ensureSpace(requiredHeight: Float): Boolean {
            if (currentY + requiredHeight > bottomLimit) {
                startContinuationPage()
                return true
            }
            return false
        }

        fun finishWithSignatures(supervisorName: String) {
            val signatureRequiredHeight = 92f
            if (currentY + signatureRequiredHeight > a4Height - 10f) {
                startContinuationPage()
            }
            drawOfficialFooterWithSignatures(canvas, supervisorName, pageNumber, knownTotalPages)
            if (pdfDocument != null && currentPage != null) {
                pdfDocument.finishPage(currentPage!!)
                currentPage = null
            }
        }

        fun release() {
            try {
                if (pdfDocument != null && currentPage != null) {
                    pdfDocument.finishPage(currentPage!!)
                    currentPage = null
                }
            } catch (_: Throwable) {}
            try {
                dummyBitmap?.recycle()
                dummyBitmap = null
            } catch (_: Throwable) {}
        }
    }

    /**
     * شريط ترويسة مدمج للصفحات التالية يمنح هوية بصرية متسقة دون إهدار مساحة الصفحة
     */
    private fun drawExecutiveContinuationHeader(
        canvas: Canvas,
        periodLabel: String,
        formattedDate: String
    ): Float {
        val topBar = Paint().apply { color = execEmerald }
        canvas.drawRect(0f, 0f, a4Width.toFloat(), 6f, topBar)
        val goldBar = Paint().apply { color = execGold }
        canvas.drawRect(0f, 6f, a4Width.toFloat(), 8f, goldBar)

        val bgRect = RectF(marginH, 14f, a4Width - marginH, 42f)
        canvas.drawRoundRect(bgRect, 5f, 5f, Paint().apply { color = execSoftBg })
        canvas.drawRoundRect(
            bgRect,
            5f,
            5f,
            Paint().apply {
                color = execBorder
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }
        )

        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = execNavy
            textSize = 8.5f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        val subPaint = Paint().apply {
            isAntiAlias = true
            color = execSlate
            textSize = 7f
            textAlign = Paint.Align.RIGHT
        }
        val leftMetaPaint = Paint().apply {
            isAntiAlias = true
            color = execSlate
            textSize = 7f
            textAlign = Paint.Align.LEFT
        }

        canvas.drawText("تابع: التقرير الإداري التنفيذي الموحد - مؤشرات العمليات", a4Width - marginH - 8f, 25f, titlePaint)
        canvas.drawText(periodLabel, a4Width - marginH - 8f, 36.5f, subPaint)
        canvas.drawText("تاريخ الإصدار: \u2066$formattedDate\u2069", marginH + 8f, 25f, leftMetaPaint)
        canvas.drawText("المقاس: \u2066A4\u2069 قياسي للطباعة", marginH + 8f, 36.5f, leftMetaPaint)

        return 42f
    }

    /**
     * تمريرة بناء التقرير التنفيذي بالكامل (قياس أو رسم فعلي) بتدفق ديناميكي ذكي
     */
    private fun renderExecutiveReportPass(
        pdfDocument: PdfDocument?,
        data: ExecutiveReportData,
        knownTotalPages: Int
    ): Int {
        val formattedDate = formatExecutiveIssueDate(data.dateGenerated)
        val periodLabel = formatExecutivePeriodLabel(data.fromDate, data.toDate)
        val session = ExecutiveFlowSession(pdfDocument, periodLabel, formattedDate, knownTotalPages)
        try {
            session.startFirstPage()

            // =================================================================
            // 1. بطاقات المؤشرات الاستراتيجية العليا (4 Executive KPI Cards)
            // =================================================================
            val kpis = listOf(
                KpiItem("إجمالي الأسر المسجلة", String.format(Locale.US, "%,d", data.totalFamilies), "أسرة", execEmerald),
                KpiItem("إجمالي الأفراد المستهدفين", String.format(Locale.US, "%,d", if (data.totalIndividuals > 0) data.totalIndividuals else data.totalFamilies * 5), "فرد", execRoyalBlue),
                KpiItem("المساعدات المسلمة فعلياً", String.format(Locale.US, "%,d", data.totalDelivered), "طرد / معونة", execSkyBlue),
                KpiItem("المشاريع الإغاثية النشطة", String.format(Locale.US, "%,d", data.activeProjectsCount), "مشروع", execGreen)
            )
            session.currentY = drawKpiCards(session.canvas, session.currentY, kpis) + session.sectionGap

            // =================================================================
            // 2. تصنيف الأسر الرسمية بشرطي (معتمد / مقيم) + رسم حلقي (Donut Chart)
            // =================================================================
            drawExecutiveFamilyStatusSection(session, data.familyStatusStats, data.totalFamilies)

            // =================================================================
            // 3. التحليل الديموغرافي والجغرافي (رسم أفقي Vector Bar Chart + الجدول)
            // =================================================================
            if (data.geoDemographics.isNotEmpty()) {
                drawExecutiveGeoDemographicsFlow(session, data.geoDemographics)
            } else if (data.geoBreakdown.isNotEmpty()) {
                val mapped = data.geoBreakdown.map {
                    ExecutiveGeoDemographicItem(
                        regionName = it.name,
                        familyCount = it.count,
                        familyPercentage = it.percentage,
                        individualCount = 0,
                        individualPercentage = 0.0
                    )
                }
                drawExecutiveGeoDemographicsFlow(session, mapped)
            }

            // =================================================================
            // 4. توزيع المساعدات المسلمة حسب الأصناف الإغاثية (شريط مقارن + معدل الحصة)
            // =================================================================
            val activeAidItems = if (data.aidTypeBreakdown.isNotEmpty()) data.aidTypeBreakdown else data.shelterBreakdown
            if (activeAidItems.isNotEmpty()) {
                drawExecutiveAidCategoriesFlow(session, activeAidItems)
            }

            // =================================================================
            // 5. تصنيف أضرار الحرب والتوزيع بالمناطق الفرعية الحالية (بدون قص أو عكس)
            // =================================================================
            if (data.damageBreakdown.isNotEmpty()) {
                drawExecutiveDamagesWithRegionFlow(session, data.damageBreakdown, data.damageByRegionBreakdown)
            }

            // =================================================================
            // 6. مصفوفة إنجاز وأداء المشاريع الإغاثية النشطة (منطق مستهدف/مسلم دقيق)
            // =================================================================
            if (data.projectStatsList.isNotEmpty()) {
                drawExecutiveProjectsPerformanceFlow(session, data.projectStatsList, data.activeProjectsCount)
            }

            // =================================================================
            // 7. شريط الاعتماد والتواقيع وختم المنظمة الرسمي في أسفل الصفحة الأخيرة
            // =================================================================
            session.finishWithSignatures(data.supervisorName)
            return session.pageNumber
        } finally {
            session.release()
        }
    }

    private fun drawExecutiveSectionHeader(
        canvas: Canvas,
        y: Float,
        title: String,
        subtitle: String? = null,
        accentColor: Int = execEmerald
    ): Float {
        // علامة شريطية جانبية أنيقة على اليمين
        val badgeRect = RectF(a4Width - marginH - 4f, y + 1f, a4Width - marginH, y + 13f)
        canvas.drawRoundRect(badgeRect, 2f, 2f, Paint().apply { color = accentColor })

        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = execNavy
            textSize = 9.5f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(title, a4Width - marginH - 9f, y + 10.5f, titlePaint)

        var nextY = y + 16f
        if (!subtitle.isNullOrBlank()) {
            val subPaint = Paint().apply {
                isAntiAlias = true
                color = execSlate
                textSize = 7.2f
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(subtitle, a4Width - marginH - 9f, nextY + 3f, subPaint)
            nextY += 10f
        }
        return nextY
    }

    /**
     * قسم تصنيف الأسر الرسمية بشرطي (معتمد / مقيم) مع رسم بياني حلقي متجه (Donut Chart)
     */
    private fun drawExecutiveFamilyStatusSection(
        session: ExecutiveFlowSession,
        stats: ExecutiveFamilyStatusStats,
        fallbackTotalFamilies: Int
    ) {
        val totalFam = maxOf(stats.totalFamilies, fallbackTotalFamilies, 0)
        val approvedOnlyFam = (stats.approvedFamilies - stats.eligibleBothFamilies).coerceAtLeast(0)
        val approvedOnlyIndiv = (stats.approvedIndividuals - stats.eligibleBothIndividuals).coerceAtLeast(0)
        val residentOnlyFam = (stats.residentFamilies - stats.eligibleBothFamilies).coerceAtLeast(0)
        val residentOnlyIndiv = (stats.residentIndividuals - stats.eligibleBothIndividuals).coerceAtLeast(0)
        val accounted = stats.eligibleBothFamilies + approvedOnlyFam + residentOnlyFam
        val computedOtherFam = maxOf(stats.otherFamilies, (totalFam - accounted).coerceAtLeast(0))
        val computedOtherIndiv = stats.otherIndividuals.coerceAtLeast(0)

        fun pct(part: Int): Double = if (totalFam > 0) (part.toDouble() / totalFam.toDouble()) * 100.0 else 0.0

        // بناء شرائح الرسم الحلقي بتقسيم تام يساوي 100.0% بدقة دون ازدواجية
        val slices = mutableListOf<ExecutiveChartSlice>()
        if (stats.eligibleBothFamilies > 0) {
            slices.add(
                ExecutiveChartSlice(
                    label = "معتمد ومقيم معاً",
                    count = stats.eligibleBothFamilies,
                    percentage = pct(stats.eligibleBothFamilies),
                    color = execEmerald,
                    subLabel = "${String.format(Locale.US, "%,d", stats.eligibleBothIndividuals)} فرد"
                )
            )
            if (approvedOnlyFam > 0) {
                slices.add(
                    ExecutiveChartSlice(
                        label = "معتمد فقط (غير مقيم)",
                        count = approvedOnlyFam,
                        percentage = pct(approvedOnlyFam),
                        color = execRoyalBlue,
                        subLabel = "${String.format(Locale.US, "%,d", approvedOnlyIndiv)} فرد"
                    )
                )
            }
            if (residentOnlyFam > 0) {
                slices.add(
                    ExecutiveChartSlice(
                        label = "مقيم فقط (غير معتمد)",
                        count = residentOnlyFam,
                        percentage = pct(residentOnlyFam),
                        color = execGold,
                        subLabel = "${String.format(Locale.US, "%,d", residentOnlyIndiv)} فرد"
                    )
                )
            }
            if (computedOtherFam > 0) {
                slices.add(
                    ExecutiveChartSlice(
                        label = "حالات أخرى غير مصنفة",
                        count = computedOtherFam,
                        percentage = pct(computedOtherFam),
                        color = execSlate,
                        subLabel = "${String.format(Locale.US, "%,d", computedOtherIndiv)} فرد"
                    )
                )
            }
        } else {
            slices.add(
                ExecutiveChartSlice(
                    label = "الأسر المعتمدة (معتمد)",
                    count = stats.approvedFamilies,
                    percentage = pct(stats.approvedFamilies),
                    color = execEmerald,
                    subLabel = "${String.format(Locale.US, "%,d", stats.approvedIndividuals)} فرد"
                )
            )
            slices.add(
                ExecutiveChartSlice(
                    label = "الأسر المقيمة (مقيم)",
                    count = stats.residentFamilies,
                    percentage = pct(stats.residentFamilies),
                    color = execRoyalBlue,
                    subLabel = "${String.format(Locale.US, "%,d", stats.residentIndividuals)} فرد"
                )
            )
            if (computedOtherFam > 0) {
                slices.add(
                    ExecutiveChartSlice(
                        label = "حالات أخرى غير مصنفة",
                        count = computedOtherFam,
                        percentage = pct(computedOtherFam),
                        color = execSlate,
                        subLabel = "${String.format(Locale.US, "%,d", computedOtherIndiv)} فرد"
                    )
                )
            }
        }

        val cardHeight = 132f
        val totalNeeded = 28f + cardHeight
        session.ensureSpace(totalNeeded)

        val canvas = session.canvas
        var y = drawExecutiveSectionHeader(
            canvas = canvas,
            y = session.currentY,
            title = "1. تصنيف الأسر الرسمية المسجلة حسب حالتي الاعتماد والإقامة (معتمد / مقيم):",
            subtitle = "مقارنة تفصيلية لأعداد الأسر والأفراد التابعين لكل شرط مع ضمان اكتمال التوزيع النسبي بنسبة 100.0%",
            accentColor = execEmerald
        )

        val cardRect = RectF(marginH, y, a4Width - marginH, y + cardHeight)
        canvas.drawRoundRect(cardRect, 7f, 7f, Paint().apply { color = AndroidGraphicsColor.WHITE })
        canvas.drawRoundRect(
            cardRect,
            7f,
            7f,
            Paint().apply {
                color = execBorder
                style = Paint.Style.STROKE
                strokeWidth = 0.9f
            }
        )

        // الجانب الأيسر: الرسم البياني الحلقي المتجه (Vector Donut Chart)
        val donutAreaLeft = marginH + 10f
        val donutAreaWidth = 148f
        val centerX = donutAreaLeft + donutAreaWidth / 2f
        val centerY = y + cardHeight / 2f
        val radius = 44f
        val donutStrokeWidth = 17f
        drawExecutiveDonutChart(
            canvas = canvas,
            cx = centerX,
            cy = centerY,
            radius = radius,
            strokeW = donutStrokeWidth,
            slices = slices,
            centerValue = String.format(Locale.US, "%,d", totalFam),
            centerLabel = "إجمالي الأسر"
        )

        // خط فاصل عمودي رفيع بين الرسم الحلقي والأرقام التفصيلية
        val dividerX = donutAreaLeft + donutAreaWidth + 6f
        canvas.drawLine(
            dividerX,
            y + 12f,
            dividerX,
            y + cardHeight - 12f,
            Paint().apply {
                color = execBorder
                this.strokeWidth = 0.8f
            }
        )

        // الجانب الأيمن: بطاقتان بارزتان لشرطي (معتمد) و(مقيم) + جدول مفتاح الألوان الحلقي
        val rightEdge = a4Width - marginH - 10f
        val leftEdge = dividerX + 10f
        val panelWidth = rightEdge - leftEdge
        val halfBoxGap = 8f
        val statBoxW = (panelWidth - halfBoxGap) / 2f
        val statBoxH = 42f
        val statTop = y + 10f

        drawMiniStatusHighlightCard(
            canvas = canvas,
            rect = RectF(rightEdge - statBoxW, statTop, rightEdge, statTop + statBoxH),
            title = "الأسر المعتمدة (معتمد)",
            familyCount = stats.approvedFamilies,
            percentage = pct(stats.approvedFamilies),
            individualsCount = stats.approvedIndividuals,
            accentColor = execEmerald
        )
        drawMiniStatusHighlightCard(
            canvas = canvas,
            rect = RectF(leftEdge, statTop, leftEdge + statBoxW, statTop + statBoxH),
            title = "الأسر المقيمة (مقيم)",
            familyCount = stats.residentFamilies,
            percentage = pct(stats.residentFamilies),
            individualsCount = stats.residentIndividuals,
            accentColor = execRoyalBlue
        )

        // مفتاح ألوان الرسم الحلقي (Donut Legend) بإجمالي 100.0%
        var legY = statTop + statBoxH + 9f
        val legHeaderPaint = Paint().apply {
            isAntiAlias = true
            color = execSlate
            textSize = 6.8f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("توزيع شرائح الرسم الحلقي (الإجمالي = 100.0%):", rightEdge, legY + 5f, legHeaderPaint)
        legY += 10f

        val legNamePaint = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7.2f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        val legMetricPaint = Paint().apply {
            isAntiAlias = true
            color = execSlate
            textSize = 7.0f
            textAlign = Paint.Align.LEFT
        }
        val legRowH = 14.5f
        val visibleSlices = slices.take(4)
        visibleSlices.forEachIndexed { i, slice ->
            if (i % 2 == 0) {
                canvas.drawRoundRect(
                    RectF(leftEdge, legY, rightEdge, legY + legRowH - 1.5f),
                    3f,
                    3f,
                    Paint().apply { color = execSoftBg }
                )
            }
            // مربع لون المؤشر على اليمين
            canvas.drawRoundRect(
                RectF(rightEdge - 9f, legY + 3.2f, rightEdge - 2f, legY + 10.2f),
                2f,
                2f,
                Paint().apply { color = slice.color }
            )
            canvas.drawText(slice.label, rightEdge - 14f, legY + 9.8f, legNamePaint)
            val metricText = "\u2066${String.format(Locale.US, "%,d", slice.count)}\u2069 أسرة  •  \u2066${String.format(Locale.US, "%.1f%%", slice.percentage)}\u2069  •  ${slice.subLabel}"
            canvas.drawText(metricText, leftEdge + 4f, legY + 9.8f, legMetricPaint)
            legY += legRowH
        }

        session.currentY = y + cardHeight + session.sectionGap
    }

    private fun drawMiniStatusHighlightCard(
        canvas: Canvas,
        rect: RectF,
        title: String,
        familyCount: Int,
        percentage: Double,
        individualsCount: Int,
        accentColor: Int
    ) {
        canvas.drawRoundRect(rect, 5f, 5f, Paint().apply { color = execSoftBg })
        canvas.drawRoundRect(
            rect,
            5f,
            5f,
            Paint().apply {
                color = accentColor
                style = Paint.Style.STROKE
                strokeWidth = 0.85f
            }
        )
        canvas.drawRoundRect(
            RectF(rect.right - 3.5f, rect.top, rect.right, rect.bottom),
            2f,
            2f,
            Paint().apply { color = accentColor }
        )

        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = execSlate
            textSize = 7.2f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        val mainValPaint = Paint().apply {
            isAntiAlias = true
            color = accentColor
            textSize = 10.5f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        val pctBadgePaint = Paint().apply {
            isAntiAlias = true
            color = execNavy
            textSize = 8.2f
            isFakeBoldText = true
            textAlign = Paint.Align.LEFT
        }
        val subPaint = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 6.8f
            textAlign = Paint.Align.RIGHT
        }

        canvas.drawText(title, rect.right - 8f, rect.top + 11.5f, titlePaint)
        canvas.drawText("${String.format(Locale.US, "%,d", familyCount)} أسرة", rect.right - 8f, rect.top + 25.5f, mainValPaint)
        canvas.drawText(String.format(Locale.US, "%.1f%%", percentage), rect.left + 7f, rect.top + 25.5f, pctBadgePaint)
        canvas.drawText("الأفراد التابعون: ${String.format(Locale.US, "%,d", individualsCount)} فرد", rect.right - 8f, rect.top + 37f, subPaint)
    }

    /**
     * رسم بياني حلقي متجه عالي الدقة (Native Vector Donut Chart) مباشرة عبر Canvas.drawArc
     */
    private fun drawExecutiveDonutChart(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        radius: Float,
        strokeW: Float,
        slices: List<ExecutiveChartSlice>,
        centerValue: String,
        centerLabel: String
    ) {
        val oval = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        val trackPaint = Paint().apply {
            isAntiAlias = true
            color = execBorder
            style = Paint.Style.STROKE
            strokeWidth = strokeW
        }
        canvas.drawArc(oval, 0f, 360f, false, trackPaint)

        val nonZeroSlices = slices.filter { it.count > 0 }
        val total = nonZeroSlices.sumOf { it.count }.toFloat()
        if (total > 0f) {
            val gapDeg = if (nonZeroSlices.size > 1) 2.2f else 0f
            var startAngle = -90f
            nonZeroSlices.forEach { slice ->
                val rawSweep = (slice.count.toFloat() / total) * 360f
                val drawSweep = (rawSweep - gapDeg).coerceAtLeast(1.2f)
                val arcPaint = Paint().apply {
                    isAntiAlias = true
                    color = slice.color
                    style = Paint.Style.STROKE
                    strokeWidth = strokeW
                    strokeCap = Paint.Cap.BUTT
                }
                canvas.drawArc(oval, startAngle, drawSweep, false, arcPaint)
                startAngle += rawSweep
            }
        }

        val centerValPaint = Paint().apply {
            isAntiAlias = true
            color = execNavy
            textSize = 10.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val centerSubPaint = Paint().apply {
            isAntiAlias = true
            color = execSlate
            textSize = 6.5f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(centerValue, cx, cy + 1f, centerValPaint)
        canvas.drawText(centerLabel, cx, cy + 11.5f, centerSubPaint)
    }

    /**
     * رسم بياني بالأعمدة الأفقية المتجهة (Horizontal Bar Chart) للتوزيع الجغرافي للأسر والأفراد
     */
    private fun drawExecutiveGeoHorizontalBarChart(
        canvas: Canvas,
        startY: Float,
        items: List<ExecutiveGeoDemographicItem>
    ): Float {
        val chartItems = items.take(6)
        if (chartItems.isEmpty()) return startY

        val rowStep = 18.5f
        val chartHeight = 24f + (chartItems.size * rowStep) + 8f
        val box = RectF(marginH, startY, a4Width - marginH, startY + chartHeight)
        canvas.drawRoundRect(box, 6f, 6f, Paint().apply { color = execSoftBg })
        canvas.drawRoundRect(
            box,
            6f,
            6f,
            Paint().apply {
                color = execBorder
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }
        )

        // عنوان ومفتاح الرسم البياني الأفقي
        val legendPaint = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("التوزيع النسبي للأسر والأفراد حسب المناطق الفرعية (أبرز ${chartItems.size} مناطق):", a4Width - marginH - 8f, startY + 13f, legendPaint)

        // مفتاح اللونين على اليسار
        val keyPaint = Paint().apply {
            isAntiAlias = true
            color = execSlate
            textSize = 6.6f
            textAlign = Paint.Align.LEFT
        }
        canvas.drawRoundRect(RectF(marginH + 10f, startY + 7.5f, marginH + 17f, startY + 13.5f), 1.5f, 1.5f, Paint().apply { color = execEmerald })
        canvas.drawText("نسبة الأسر", marginH + 20f, startY + 13f, keyPaint)
        canvas.drawRoundRect(RectF(marginH + 64f, startY + 7.5f, marginH + 71f, startY + 13.5f), 1.5f, 1.5f, Paint().apply { color = execRoyalBlue })
        canvas.drawText("نسبة الأفراد", marginH + 74f, startY + 13f, keyPaint)

        val labelRight = a4Width - marginH - 8f
        val barAreaRight = a4Width - marginH - 122f
        val barAreaLeft = marginH + 92f
        val barMaxW = (barAreaRight - barAreaLeft).coerceAtLeast(100f)

        // خطوط شبكة رأسية خفيفة (25% / 50% / 75% / 100%)
        val gridPaint = Paint().apply {
            color = execBorder
            strokeWidth = 0.5f
        }
        val maxPct = chartItems.maxOf { maxOf(it.familyPercentage, it.individualPercentage) }.coerceAtLeast(10.0)
        val scaleMax = when {
            maxPct <= 25.0 -> 25.0
            maxPct <= 50.0 -> 50.0
            maxPct <= 75.0 -> 75.0
            else -> 100.0
        }
        for (step in 0..4) {
            val gx = barAreaRight - (barMaxW * step / 4f)
            canvas.drawLine(gx, startY + 20f, gx, startY + chartHeight - 6f, gridPaint)
        }

        val regionPaint = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7.2f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        val valPaint = Paint().apply {
            isAntiAlias = true
            color = execSlate
            textSize = 6.7f
            textAlign = Paint.Align.LEFT
        }
        val famBarPaint = Paint().apply { color = execEmerald }
        val indBarPaint = Paint().apply { color = execRoyalBlue }

        var rowY = startY + 24f
        chartItems.forEach { item ->
            val cleanName = if (item.regionName.length > 20) item.regionName.take(19) + "…" else item.regionName
            canvas.drawText(cleanName, labelRight, rowY + 9.5f, regionPaint)

            val famW = (barMaxW * (item.familyPercentage / scaleMax).toFloat().coerceIn(0f, 1f)).coerceAtLeast(if (item.familyCount > 0) 3f else 0f)
            val indW = (barMaxW * (item.individualPercentage / scaleMax).toFloat().coerceIn(0f, 1f)).coerceAtLeast(if (item.individualCount > 0) 3f else 0f)

            // شريط الأسر (علوي)
            canvas.drawRoundRect(
                RectF(barAreaRight - famW, rowY + 1.5f, barAreaRight, rowY + 7f),
                2f,
                2f,
                famBarPaint
            )
            // شريط الأفراد (سفلي)
            if (item.individualCount > 0) {
                canvas.drawRoundRect(
                    RectF(barAreaRight - indW, rowY + 8.5f, barAreaRight, rowY + 14f),
                    2f,
                    2f,
                    indBarPaint
                )
            }

            val metricStr = "\u2066${String.format(Locale.US, "%,d", item.familyCount)}\u2069 (\u2066${String.format(Locale.US, "%.1f%%", item.familyPercentage)}\u2069)"
            canvas.drawText(metricStr, marginH + 8f, rowY + 10f, valPaint)
            rowY += rowStep
        }

        return startY + chartHeight
    }

    /**
     * رسم بياني شريطي مقارن متراكم (Comparative Stacked Horizontal Bar + Legend)
     */
    private fun drawExecutiveStackedBarChart(
        canvas: Canvas,
        startY: Float,
        title: String,
        slices: List<ExecutiveChartSlice>
    ): Float {
        if (slices.isEmpty()) return startY
        val legendItems = slices.take(6)
        val rowsCount = if (legendItems.size > 3) 2 else 1
        val boxHeight = 32f + (rowsCount * 12f) + 6f

        val box = RectF(marginH, startY, a4Width - marginH, startY + boxHeight)
        canvas.drawRoundRect(box, 6f, 6f, Paint().apply { color = execSoftBg })
        canvas.drawRoundRect(
            box,
            6f,
            6f,
            Paint().apply {
                color = execBorder
                style = Paint.Style.STROKE
                strokeWidth = 0.8f
            }
        )

        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7.1f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(title, a4Width - marginH - 8f, startY + 12f, titlePaint)

        // الشريط التراكمي الكامل (من اليمين إلى اليسار)
        val barLeft = marginH + 8f
        val barRight = a4Width - marginH - 8f
        val barW = barRight - barLeft
        val barTop = startY + 17f
        val barBottom = barTop + 11f

        canvas.drawRoundRect(RectF(barLeft, barTop, barRight, barBottom), 4f, 4f, Paint().apply { color = execBorder })

        val totalPct = slices.sumOf { it.percentage }.coerceAtLeast(0.01)
        var curRight = barRight
        slices.forEachIndexed { idx, slice ->
            if (slice.percentage <= 0.0) return@forEachIndexed
            val segW = if (idx == slices.lastIndex) {
                (curRight - barLeft).coerceAtLeast(0f)
            } else {
                (barW * (slice.percentage / totalPct).toFloat()).coerceIn(2f, curRight - barLeft)
            }
            val segLeft = (curRight - segW).coerceAtLeast(barLeft)
            canvas.drawRoundRect(
                RectF(segLeft, barTop, curRight, barBottom),
                2f,
                2f,
                Paint().apply { color = slice.color }
            )
            curRight = (segLeft - 1.2f).coerceAtLeast(barLeft)
        }

        // مفتاح الألوان أسفل الشريط (3 أعمدة في الصف)
        val colW = barW / 3f
        val legPaint = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 6.7f
            textAlign = Paint.Align.RIGHT
        }
        legendItems.forEachIndexed { idx, slice ->
            val r = idx / 3
            val c = idx % 3
            val cellRight = barRight - (c * colW)
            val ly = barBottom + 10.5f + (r * 12f)
            canvas.drawRoundRect(
                RectF(cellRight - 7f, ly - 5.5f, cellRight, ly + 1.2f),
                1.5f,
                1.5f,
                Paint().apply { color = slice.color }
            )
            val shortLabel = if (slice.label.length > 18) slice.label.take(17) + "…" else slice.label
            val text = "\u2067$shortLabel\u2069 (\u2066${String.format(Locale.US, "%.1f%%", slice.percentage)}\u2069)"
            canvas.drawText(text, cellRight - 10f, ly, legPaint)
        }

        return startY + boxHeight
    }

    /**
     * القسم الديموغرافي والجغرافي بنظام التدفق الديناميكي وتكرار رأس الجدول تلقائياً
     */
    private fun drawExecutiveGeoDemographicsFlow(
        session: ExecutiveFlowSession,
        items: List<ExecutiveGeoDemographicItem>
    ) {
        val chartItemsCount = items.take(6).size
        val estimatedChartHeight = 24f + (chartItemsCount * 18.5f) + 8f
        session.ensureSpace(26f + estimatedChartHeight + 36f)

        session.currentY = drawExecutiveSectionHeader(
            canvas = session.canvas,
            y = session.currentY,
            title = "2. التحليل الديموغرافي والجغرافي بالمحليات والمناطق الفرعية:",
            subtitle = "توزيع الأسر والأفراد المسجلين مع التمثيل البياني الأفقي للثقل السكاني في كل منطقة",
            accentColor = execEmerald
        )

        // الرسم البياني الأفقي المتجه
        session.currentY = drawExecutiveGeoHorizontalBarChart(session.canvas, session.currentY, items) + 8f

        val colWidths = floatArrayOf(24f, 134f, 74f, 64f, 74f, 64f, 105f)
        val colHeaders = arrayOf("م", "المنطقة الفرعية الحالية", "عدد الأسر", "% الأسر", "عدد الأفراد", "% الأفراد", "الكثافة النسبية")
        val headerHeight = 17f

        fun drawGeoHeader() {
            val canvas = session.canvas
            val y = session.currentY
            canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, Paint().apply { color = execNavy })
            val hp = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.WHITE
                textSize = 7f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
            }
            var cx = a4Width - marginH
            colHeaders.forEachIndexed { i, title ->
                val w = colWidths[i]
                canvas.drawText(title, cx - (w / 2f), y + 11.2f, hp)
                cx -= w
            }
            session.currentY += headerHeight
        }

        session.ensureSpace(headerHeight + 18f)
        drawGeoHeader()

        val rowHeight = 15.5f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = execBorder
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = execSoftBg }
        val barBg = Paint().apply { color = execBorder }
        val barFill = Paint().apply { color = execEmerald }

        items.forEachIndexed { idx, item ->
            if (session.ensureSpace(rowHeight)) {
                drawGeoHeader()
            }
            val canvas = session.canvas
            val y = session.currentY
            if (idx % 2 == 0) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            canvas.drawText("${idx + 1}", x - (colWidths[0] / 2f), y + 10.5f, rowTextCenter)
            x -= colWidths[0]

            val name = if (item.regionName.length > 24) item.regionName.take(23) + "…" else item.regionName
            canvas.drawText(name, x - 5f, y + 10.5f, rowTextRight)
            x -= colWidths[1]

            canvas.drawText(String.format(Locale.US, "%,d", item.familyCount), x - (colWidths[2] / 2f), y + 10.5f, rowTextCenter)
            x -= colWidths[2]

            canvas.drawText(String.format(Locale.US, "%.1f%%", item.familyPercentage), x - (colWidths[3] / 2f), y + 10.5f, rowTextCenter)
            x -= colWidths[3]

            canvas.drawText(String.format(Locale.US, "%,d", item.individualCount), x - (colWidths[4] / 2f), y + 10.5f, rowTextCenter)
            x -= colWidths[4]

            canvas.drawText(String.format(Locale.US, "%.1f%%", item.individualPercentage), x - (colWidths[5] / 2f), y + 10.5f, rowTextCenter)
            x -= colWidths[5]

            val barW = colWidths[6] - 14f
            val barLeft = x - colWidths[6] + 7f
            val barTop = y + 4.8f
            val barBottom = y + 10.8f
            val fillW = (barW * (item.familyPercentage.toFloat() / 100f).coerceIn(0f, 1f))
            canvas.drawRoundRect(RectF(barLeft, barTop, barLeft + barW, barBottom), 2f, 2f, barBg)
            if (fillW > 0f) {
                canvas.drawRoundRect(RectF(barLeft, barTop, barLeft + fillW, barBottom), 2f, 2f, barFill)
            }

            session.currentY += rowHeight
        }

        session.currentY += session.sectionGap
    }

    /**
     * قسم توزيع المساعدات المسلمة حسب الأصناف الإغاثية + شريط مقارن + عمود «معدل الحصة» الفعلي
     */
    private fun drawExecutiveAidCategoriesFlow(
        session: ExecutiveFlowSession,
        items: List<ExecutiveCategoryItem>
    ) {
        val chartPalette = listOf(
            execEmerald,
            execSkyBlue,
            execRoyalBlue,
            execGold,
            AndroidGraphicsColor.rgb(16, 185, 129),
            execSlate
        )
        val slices = items.mapIndexed { idx, item ->
            ExecutiveChartSlice(
                label = item.label,
                count = item.count,
                percentage = item.percentage,
                color = chartPalette[idx % chartPalette.size]
            )
        }

        session.ensureSpace(115f)
        session.currentY = drawExecutiveSectionHeader(
            canvas = session.canvas,
            y = session.currentY,
            title = "3. توزيع المساعدات المسلمة حسب الأصناف الإغاثية:",
            subtitle = "إجمالي الكميات المسلمة ونسبتها ومعدل الحصة الفعلي لكل أسرة مستفيدة من الصنف",
            accentColor = execSkyBlue
        )

        session.currentY = drawExecutiveStackedBarChart(
            canvas = session.canvas,
            startY = session.currentY,
            title = "التوزيع النسبي المقارن للأصناف الإغاثية المسلمة:",
            slices = slices
        ) + 8f

        val colWidths = floatArrayOf(24f, 200f, 110f, 80f, 125f)
        val colHeaders = arrayOf("م", "صنف المعونة / فئة المساعدة", "إجمالي المساعدات المسلمة", "النسبة من الإجمالي", "معدل الحصة")
        val headerHeight = 17f

        fun drawAidHeader() {
            val canvas = session.canvas
            val y = session.currentY
            canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, Paint().apply { color = execSlateDark })
            val hp = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.WHITE
                textSize = 7f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
            }
            var cx = a4Width - marginH
            colHeaders.forEachIndexed { i, title ->
                val w = colWidths[i]
                canvas.drawText(title, cx - (w / 2f), y + 11.2f, hp)
                cx -= w
            }
            session.currentY += headerHeight
        }

        session.ensureSpace(headerHeight + 18f)
        drawAidHeader()

        val rowHeight = 16f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7f
            textAlign = Paint.Align.RIGHT
        }
        val quotaPaint = Paint().apply {
            isAntiAlias = true
            color = execSkyBlue
            textSize = 7.1f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val linePaint = Paint().apply {
            color = execBorder
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = execSoftBg }

        items.forEachIndexed { idx, item ->
            if (session.ensureSpace(rowHeight)) {
                drawAidHeader()
            }
            val canvas = session.canvas
            val y = session.currentY
            if (idx % 2 == 0) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            canvas.drawText("${idx + 1}", x - (colWidths[0] / 2f), y + 11f, rowTextCenter)
            x -= colWidths[0]

            val name = if (item.label.length > 34) item.label.take(33) + "…" else item.label
            canvas.drawText(name, x - 5f, y + 11f, rowTextRight)
            x -= colWidths[1]

            canvas.drawText("${String.format(Locale.US, "%,d", item.count)} طرد / معونة", x - (colWidths[2] / 2f), y + 11f, rowTextCenter)
            x -= colWidths[2]

            canvas.drawText(String.format(Locale.US, "%.1f%%", item.percentage), x - (colWidths[3] / 2f), y + 11f, rowTextCenter)
            x -= colWidths[3]

            // حساب وطباعة معدل الحصة الفعلي لكل صنف (إجمالي المساعدات ÷ الأسر المستفيدة من الصنف)
            val quotaText = if (item.count <= 0) {
                "0.0 طرد/أسرة"
            } else {
                val beneficiaryFam = if (item.beneficiaryFamiliesCount > 0) item.beneficiaryFamiliesCount else item.count
                val avgQuota = item.count.toDouble() / beneficiaryFam.toDouble()
                "\u2066${String.format(Locale.US, "%.1f", avgQuota)}\u2069 طرد/أسرة"
            }
            canvas.drawText(quotaText, x - (colWidths[4] / 2f), y + 11f, quotaPaint)

            session.currentY += rowHeight
        }

        session.currentY += session.sectionGap
    }

    /**
     * قسم تصنيف أضرار الحرب والتوزيع بالمناطق الفرعية الحالية
     * - بدون أسماء متغيرات برمجية
     * - بدون قص أسماء المناطق أو انعكاس الأقواس (عزل اتجاه + التفاف متعدد الأسطر)
     * - شريط مقارن متراكم + ملاحظة توضيحية أسفل الجدول
     */
    private fun drawExecutiveDamagesWithRegionFlow(
        session: ExecutiveFlowSession,
        damageItems: List<ExecutiveCategoryItem>,
        damageByRegion: Map<String, List<ExecutiveCategoryItem>>
    ) {
        val damagePalette = listOf(
            execCrimson,
            AndroidGraphicsColor.rgb(234, 88, 12),
            execGold,
            execRoyalBlue,
            execSlate
        )
        val slices = damageItems.mapIndexed { idx, item ->
            ExecutiveChartSlice(
                label = item.label,
                count = item.count,
                percentage = item.percentage,
                color = damagePalette[idx % damagePalette.size]
            )
        }

        session.ensureSpace(120f)
        session.currentY = drawExecutiveSectionHeader(
            canvas = session.canvas,
            y = session.currentY,
            title = "4. تصنيف أضرار الحرب والتوزيع بالمناطق الفرعية الحالية:",
            subtitle = "توزيع الأسر المتضررة حسب درجة الضرر وأبرز المناطق الفرعية المتأثرة ميدانياً",
            accentColor = execCrimson
        )

        session.currentY = drawExecutiveStackedBarChart(
            canvas = session.canvas,
            startY = session.currentY,
            title = "المقارنة النسبية لتصنيفات أضرار الحرب:",
            slices = slices
        ) + 8f

        val colWidths = floatArrayOf(24f, 125f, 72f, 58f, 260f)
        val colHeaders = arrayOf("م", "تصنيف الضرر", "الأسر المتضررة", "النسبة", "أبرز المناطق الفرعية المتأثرة")
        val headerHeight = 17f

        fun drawDamageHeader() {
            val canvas = session.canvas
            val y = session.currentY
            canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, Paint().apply { color = execCrimson })
            val hp = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.WHITE
                textSize = 7f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
            }
            var cx = a4Width - marginH
            colHeaders.forEachIndexed { i, title ->
                val w = colWidths[i]
                canvas.drawText(title, cx - (w / 2f), y + 11.2f, hp)
                cx -= w
            }
            session.currentY += headerHeight
        }

        session.ensureSpace(headerHeight + 22f)
        drawDamageHeader()

        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7f
            textAlign = Paint.Align.RIGHT
        }
        val regionCellPaint = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 6.9f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = execBorder
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = AndroidGraphicsColor.rgb(254, 242, 242) }

        damageItems.forEachIndexed { idx, item ->
            val subList = damageByRegion[item.label].orEmpty()
            val formattedRegions = if (subList.isEmpty()) {
                "-"
            } else {
                subList.take(5).joinToString(" • ") { reg ->
                    "\u2067${reg.label} (\u2066${String.format(Locale.US, "%,d", reg.count)}\u2069)\u2069"
                }
            }
            val wrappedRegionLines = wrapExecutiveTextLines(formattedRegions, regionCellPaint, colWidths[4] - 12f)
            val lineStep = 10.5f
            val rowHeight = maxOf(17f, (wrappedRegionLines.size * lineStep) + 7f)

            if (session.ensureSpace(rowHeight)) {
                drawDamageHeader()
            }

            val canvas = session.canvas
            val y = session.currentY
            if (idx % 2 == 0) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            val centerBaseline = y + (rowHeight / 2f) + 2.5f
            var x = a4Width - marginH
            canvas.drawText("${idx + 1}", x - (colWidths[0] / 2f), centerBaseline, rowTextCenter)
            x -= colWidths[0]

            canvas.drawText(item.label, x - 5f, centerBaseline, rowTextRight)
            x -= colWidths[1]

            canvas.drawText(String.format(Locale.US, "%,d", item.count), x - (colWidths[2] / 2f), centerBaseline, rowTextCenter)
            x -= colWidths[2]

            canvas.drawText(String.format(Locale.US, "%.1f%%", item.percentage), x - (colWidths[3] / 2f), centerBaseline, rowTextCenter)
            x -= colWidths[3]

            var lineY = y + 10.5f
            wrappedRegionLines.forEach { line ->
                canvas.drawText(line, x - 6f, lineY, regionCellPaint)
                lineY += lineStep
            }

            session.currentY += rowHeight
        }

        // ملاحظة توضيحية أسفل جدول الأضرار
        session.ensureSpace(16f)
        val notePaint = Paint().apply {
            isAntiAlias = true
            color = execSlate
            textSize = 6.9f
            textAlign = Paint.Align.RIGHT
        }
        session.canvas.drawText(
            "ملاحظة: تصنيف (غير مصنف) يشمل الأسر قيد الحصر الميداني أو غير المتضررة سكنياً",
            a4Width - marginH - 4f,
            session.currentY + 11f,
            notePaint
        )
        session.currentY += 16f + session.sectionGap
    }

    /**
     * مصفوفة إنجاز وأداء المشاريع الإغاثية النشطة
     * - عنوان عربي رسمي بالكامل مع توضيح عدد المشاريع المعروضة من إجمالي المشاريع
     * - تصحيح منطق المستهدف/المسلم («حسب الكشف» عند عدم إدخال مستهدف أو يساوي 1 مع مسلم أكبر من 1)
     * - تكرار رأس الجدول تلقائياً عند الامتداد لصفحة جديدة
     */
    private fun drawExecutiveProjectsPerformanceFlow(
        session: ExecutiveFlowSession,
        projects: List<ProjectPerformanceStat>,
        totalActiveProjectsCount: Int
    ) {
        val totalProjects = maxOf(totalActiveProjectsCount, projects.size)
        val displayProjects = projects
        val subtitle = "عرض أبرز ${displayProjects.size} مشروعاً نشطاً من إجمالي $totalProjects مشروع"

        session.ensureSpace(64f)
        session.currentY = drawExecutiveSectionHeader(
            canvas = session.canvas,
            y = session.currentY,
            title = "5. مصفوفة إنجاز وأداء المشاريع الإغاثية النشطة:",
            subtitle = subtitle,
            accentColor = execGreen
        )

        val colWidths = floatArrayOf(24f, 165f, 92f, 66f, 62f, 60f, 70f)
        val colHeaders = arrayOf("م", "اسم المشروع الإغاثي", "صنف المعونة", "المستهدف", "المسلم", "% الإنجاز", "مؤشر الأداء")
        val headerHeight = 17f

        fun drawProjectsHeader() {
            val canvas = session.canvas
            val y = session.currentY
            canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, Paint().apply { color = execEmerald })
            val hp = Paint().apply {
                isAntiAlias = true
                color = AndroidGraphicsColor.WHITE
                textSize = 7f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
            }
            var cx = a4Width - marginH
            colHeaders.forEachIndexed { i, title ->
                val w = colWidths[i]
                canvas.drawText(title, cx - (w / 2f), y + 11.2f, hp)
                cx -= w
            }
            session.currentY += headerHeight
        }

        session.ensureSpace(headerHeight + 20f)
        drawProjectsHeader()

        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = execSlateDark
            textSize = 7f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = execBorder
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = AndroidGraphicsColor.rgb(240, 253, 244) }
        val barBg = Paint().apply { color = execBorder }

        displayProjects.forEachIndexed { idx, p ->
            val wrappedProjectName = wrapExecutiveTextLines(p.projectName, rowTextRight, colWidths[1] - 10f).take(2)
            val lineStep = 10f
            val rowHeight = maxOf(16.5f, (wrappedProjectName.size * lineStep) + 6.5f)

            if (session.ensureSpace(rowHeight)) {
                drawProjectsHeader()
            }

            val canvas = session.canvas
            val y = session.currentY
            if (idx % 2 == 0) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            val centerBaseline = y + (rowHeight / 2f) + 2.5f
            var x = a4Width - marginH
            canvas.drawText("${idx + 1}", x - (colWidths[0] / 2f), centerBaseline, rowTextCenter)
            x -= colWidths[0]

            if (wrappedProjectName.size == 1) {
                canvas.drawText(wrappedProjectName[0], x - 5f, centerBaseline, rowTextRight)
            } else {
                var py = y + 10f
                wrappedProjectName.forEach { line ->
                    canvas.drawText(line, x - 5f, py, rowTextRight)
                    py += lineStep
                }
            }
            x -= colWidths[1]

            val aidName = if (p.aidTypeName.length > 16) p.aidTypeName.take(15) + "…" else p.aidTypeName
            canvas.drawText(aidName, x - (colWidths[2] / 2f), centerBaseline, rowTextCenter)
            x -= colWidths[2]

            // تصحيح منطق المستهدف والمسلم: منع ظهور مستهدف = 1 مقابل مسلم > 1
            val isUnsetOrDummyTarget = p.targetQuota <= 0 || (p.targetQuota <= 1 && p.deliveredCount > 1)
            val targetText = if (isUnsetOrDummyTarget) {
                "حسب الكشف"
            } else {
                String.format(Locale.US, "%,d", p.targetQuota)
            }
            val effectiveCompletion = when {
                isUnsetOrDummyTarget && p.deliveredCount > 0 -> 100.0
                isUnsetOrDummyTarget -> 0.0
                p.targetQuota > 0 -> (p.deliveredCount.toDouble() / p.targetQuota.toDouble() * 100.0).coerceIn(0.0, 100.0)
                else -> 0.0
            }

            canvas.drawText(targetText, x - (colWidths[3] / 2f), centerBaseline, rowTextCenter)
            x -= colWidths[3]

            canvas.drawText(String.format(Locale.US, "%,d", p.deliveredCount), x - (colWidths[4] / 2f), centerBaseline, rowTextCenter)
            x -= colWidths[4]

            canvas.drawText(String.format(Locale.US, "%.1f%%", effectiveCompletion), x - (colWidths[5] / 2f), centerBaseline, rowTextCenter)
            x -= colWidths[5]

            val progressColor = when {
                effectiveCompletion >= 90.0 -> execGreen
                effectiveCompletion >= 50.0 -> execGold
                else -> execCrimson
            }
            val fillPaint = Paint().apply { color = progressColor }
            val barW = colWidths[6] - 12f
            val barLeft = x - colWidths[6] + 6f
            val barTop = y + (rowHeight / 2f) - 3f
            val barBottom = barTop + 6f
            val fillW = (barW * (effectiveCompletion.toFloat() / 100f).coerceIn(0f, 1f))
            canvas.drawRoundRect(RectF(barLeft, barTop, barLeft + barW, barBottom), 2f, 2f, barBg)
            if (fillW > 0f) {
                canvas.drawRoundRect(RectF(barLeft, barTop, barLeft + fillW, barBottom), 2f, 2f, fillPaint)
            }

            session.currentY += rowHeight
        }

        session.currentY += session.sectionGap
    }

    private fun drawExecutiveGeoSection(
        canvas: Canvas,
        startY: Float,
        geoItems: List<ExecutiveGeoItem>
    ): Float {
        var y = startY
        val sectionTitlePaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(15, 23, 42)
            textSize = 10f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("1. التوزيع الجغرافي ونسب التغطية الميدانية بالمحليات (Geographic Breakdown):", a4Width - marginH, y + 10f, sectionTitlePaint)
        y += 16f

        val headerHeight = 18f
        val headerBg = Paint().apply { color = AndroidGraphicsColor.rgb(15, 23, 42) }
        canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, headerBg)

        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.WHITE
            textSize = 7.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        val colWidths = floatArrayOf(24f, 150f, 90f, 85f, 190f)
        val colHeaders = arrayOf("م", "المحلية / النطاق الميداني", "عدد الأسر المسجلة", "النسبة المئوية", "مستوى التغطية الجغرافية")

        var curX = a4Width - marginH
        colHeaders.forEachIndexed { i, title ->
            val w = colWidths[i]
            canvas.drawText(title, curX - (w / 2f), y + 12f, headerTextPaint)
            curX -= w
        }
        y += headerHeight

        val rowHeight = 16f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = AndroidGraphicsColor.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = AndroidGraphicsColor.rgb(248, 250, 252) }
        val barBg = Paint().apply { color = AndroidGraphicsColor.rgb(226, 232, 240) }
        val barFill = Paint().apply { color = AndroidGraphicsColor.rgb(13, 148, 136) }

        val displayItems = geoItems.take(6)
        displayItems.forEachIndexed { idx, item ->
            val isEven = idx % 2 == 0
            if (isEven) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            // 0: م
            canvas.drawText("${idx + 1}", x - (colWidths[0] / 2f), y + 11f, rowTextCenter)
            x -= colWidths[0]

            // 1: اسم المحلية
            val name = if (item.name.length > 25) item.name.substring(0, 23) + ".." else item.name
            canvas.drawText(name, x - 6f, y + 11f, rowTextRight)
            x -= colWidths[1]

            // 2: عدد الأسر
            canvas.drawText(String.format(Locale.US, "%,d", item.count), x - (colWidths[2] / 2f), y + 11f, rowTextCenter)
            x -= colWidths[2]

            // 3: النسبة المئوية
            canvas.drawText(String.format(Locale.US, "%.1f%%", item.percentage), x - (colWidths[3] / 2f), y + 11f, rowTextCenter)
            x -= colWidths[3]

            // 4: شريط بياني أفقي
            val barW = colWidths[4] - 20f
            val barLeft = x - colWidths[4] + 10f
            val barTop = y + 5f
            val barBottom = y + 11f
            val fillW = (barW * (item.percentage.toFloat() / 100f).coerceIn(0f, 1f))
            canvas.drawRoundRect(RectF(barLeft, barTop, barLeft + barW, barBottom), 2f, 2f, barBg)
            if (fillW > 0f) {
                canvas.drawRoundRect(RectF(barLeft, barTop, barLeft + fillW, barBottom), 2f, 2f, barFill)
            }

            y += rowHeight
        }

        return y
    }

    private fun drawExecutiveBreakdownsSection(
        canvas: Canvas,
        startY: Float,
        shelterItems: List<ExecutiveCategoryItem>,
        damageItems: List<ExecutiveCategoryItem>
    ): Float {
        var y = startY
        val colGap = 12f
        val halfWidth = (contentWidth - colGap) / 2f

        val sectionTitlePaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(15, 23, 42)
            textSize = 10f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }

        // عناوين العمودين المتجاورين
        val rightColX = a4Width - marginH
        val leftColX = rightColX - halfWidth - colGap

        canvas.drawText("2. تصنيف حالة الإيواء (Shelter Status):", rightColX, y + 10f, sectionTitlePaint)
        canvas.drawText("3. تصنيف أضرار الحرب (War Damage):", leftColX, y + 10f, sectionTitlePaint)
        y += 16f

        val headerHeight = 16f
        val headerPaint = Paint().apply { color = AndroidGraphicsColor.rgb(51, 65, 85) }
        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.WHITE
            textSize = 7f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        // هيدر الإيواء (اليمين)
        canvas.drawRoundRect(RectF(rightColX - halfWidth, y, rightColX, y + headerHeight), 3f, 3f, headerPaint)
        canvas.drawText("نوع الإيواء", rightColX - 60f, y + 11f, headerTextPaint)
        canvas.drawText("الأسر", rightColX - halfWidth + 70f, y + 11f, headerTextPaint)
        canvas.drawText("النسبة", rightColX - halfWidth + 25f, y + 11f, headerTextPaint)

        // هيدر الأضرار (اليسار)
        canvas.drawRoundRect(RectF(leftColX - halfWidth, y, leftColX, y + headerHeight), 3f, 3f, headerPaint)
        canvas.drawText("حجم الضرر", leftColX - 60f, y + 11f, headerTextPaint)
        canvas.drawText("الأسر", leftColX - halfWidth + 70f, y + 11f, headerTextPaint)
        canvas.drawText("النسبة", leftColX - halfWidth + 25f, y + 11f, headerTextPaint)

        y += headerHeight

        val rowHeight = 15f
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(30, 41, 59)
            textSize = 7f
            textAlign = Paint.Align.RIGHT
        }
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(30, 41, 59)
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }
        val linePaint = Paint().apply {
            color = AndroidGraphicsColor.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }

        val maxRows = maxOf(shelterItems.size, damageItems.size).coerceAtMost(6)
        for (i in 0 until maxRows) {
            val shelter = shelterItems.getOrNull(i)
            val damage = damageItems.getOrNull(i)

            // رسم صف الإيواء (اليمين)
            if (shelter != null) {
                canvas.drawLine(rightColX - halfWidth, y + rowHeight, rightColX, y + rowHeight, linePaint)
                val sName = if (shelter.label.length > 18) shelter.label.substring(0, 16) + ".." else shelter.label
                canvas.drawText(sName, rightColX - 6f, y + 11f, rowTextRight)
                canvas.drawText(String.format(Locale.US, "%,d", shelter.count), rightColX - halfWidth + 70f, y + 11f, rowTextCenter)
                canvas.drawText(String.format(Locale.US, "%.1f%%", shelter.percentage), rightColX - halfWidth + 25f, y + 11f, rowTextCenter)
            }

            // رسم صف الأضرار (اليسار)
            if (damage != null) {
                canvas.drawLine(leftColX - halfWidth, y + rowHeight, leftColX, y + rowHeight, linePaint)
                val dName = if (damage.label.length > 18) damage.label.substring(0, 16) + ".." else damage.label
                canvas.drawText(dName, leftColX - 6f, y + 11f, rowTextRight)
                canvas.drawText(String.format(Locale.US, "%,d", damage.count), leftColX - halfWidth + 70f, y + 11f, rowTextCenter)
                canvas.drawText(String.format(Locale.US, "%.1f%%", damage.percentage), leftColX - halfWidth + 25f, y + 11f, rowTextCenter)
            }

            y += rowHeight
        }

        return y
    }

    private fun drawDynamicOfficialHeader(
        canvas: Canvas,
        reportTitle: String,
        subtitle: String,
        periodOrFilter: String,
        dateStr: String,
        pageWidth: Int,
        marginH: Float,
        startY: Float
    ): Float {
        var y = startY

        val topBarPaint = Paint().apply { color = AndroidGraphicsColor.rgb(13, 148, 136) }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 12f, topBarPaint)

        val accentBarPaint = Paint().apply { color = AndroidGraphicsColor.rgb(245, 158, 11) }
        canvas.drawRect(0f, 12f, pageWidth.toFloat(), 15f, accentBarPaint)

        y = 38f
        val orgPaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(15, 23, 42)
            textSize = 14f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("نظام إدارة المساعدات الإنسانية والعمليات الميدانية المعتمد", pageWidth - marginH, y, orgPaint)

        y += 18f
        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(13, 148, 136)
            textSize = 15f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(reportTitle, pageWidth - marginH, y, titlePaint)

        y += 10f
        val boxHeight = 44f
        val boxRect = RectF(marginH, y, pageWidth - marginH, y + boxHeight)
        val boxPaint = Paint().apply { color = AndroidGraphicsColor.rgb(248, 250, 252) }
        val boxStroke = Paint().apply {
            color = AndroidGraphicsColor.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(boxRect, 6f, 6f, boxPaint)
        canvas.drawRoundRect(boxRect, 6f, 6f, boxStroke)

        val metaPaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(51, 65, 85)
            textSize = 8.5f
            textAlign = Paint.Align.RIGHT
        }

        val datePaint = Paint().apply {
            isAntiAlias = true
            color = AndroidGraphicsColor.rgb(100, 116, 139)
            textSize = 8f
            textAlign = Paint.Align.LEFT
        }

        canvas.drawText(subtitle, pageWidth - marginH - 10f, y + 16f, metaPaint)
        canvas.drawText(periodOrFilter, pageWidth - marginH - 10f, y + 32f, metaPaint)
        canvas.drawText("تاريخ الإصدار: \u2066${formatExecutiveIssueDate(dateStr)}\u2069", marginH + 10f, y + 16f, datePaint)
        canvas.drawText("المقاس: \u2066A4\u2069 قياسي للطباعة", marginH + 10f, y + 32f, datePaint)

        return y + boxHeight
    }

    // =========================================================================
    // دوال رسم وتنسيق مستند A4 PDF
    // =========================================================================

    private fun drawOfficialHeader(
        canvas: Canvas,
        reportTitle: String,
        subtitle: String,
        periodOrFilter: String,
        dateStr: String,
        startY: Float
    ): Float {
        var y = startY

        // شريط علوي ملون متدرج بلون التركواز الداكن المؤسسي
        val topBarPaint = Paint().apply { color = android.graphics.Color.rgb(13, 148, 136) }
        canvas.drawRect(0f, 0f, a4Width.toFloat(), 12f, topBarPaint)

        // شريط ذهبي خفيف للرقي
        val accentBarPaint = Paint().apply { color = android.graphics.Color.rgb(245, 158, 11) }
        canvas.drawRect(0f, 12f, a4Width.toFloat(), 15f, accentBarPaint)

        y = 38f
        val orgPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(15, 23, 42) // Dark Slate
            textSize = 14f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("نظام إدارة المساعدات الإنسانية والعمليات الميدانية المعتمد", a4Width - marginH, y, orgPaint)

        y += 18f
        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(13, 148, 136)
            textSize = 15f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(reportTitle, a4Width - marginH, y, titlePaint)

        // صندوق البيانات الوصفية (Metadata Box)
        y += 10f
        val boxHeight = 44f
        val boxRect = RectF(marginH, y, a4Width - marginH, y + boxHeight)
        val boxPaint = Paint().apply { color = android.graphics.Color.rgb(248, 250, 252) }
        val boxStroke = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(boxRect, 6f, 6f, boxPaint)
        canvas.drawRoundRect(boxRect, 6f, 6f, boxStroke)

        val metaPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(51, 65, 85)
            textSize = 8.5f
            textAlign = Paint.Align.RIGHT
        }

        val datePaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(100, 116, 139)
            textSize = 8f
            textAlign = Paint.Align.LEFT
        }

        canvas.drawText(subtitle, a4Width - marginH - 10f, y + 16f, metaPaint)
        canvas.drawText(periodOrFilter, a4Width - marginH - 10f, y + 32f, metaPaint)
        canvas.drawText("تاريخ الإصدار: \u2066${formatExecutiveIssueDate(dateStr)}\u2069", marginH + 10f, y + 16f, datePaint)
        canvas.drawText("المقاس: \u2066A4\u2069 قياسي للطباعة", marginH + 10f, y + 32f, datePaint)

        return y + boxHeight
    }

    private data class KpiItem(val label: String, val value: String, val unit: String, val colorInt: Int)

    private fun drawKpiCards(
        canvas: Canvas,
        startY: Float,
        kpis: List<KpiItem>
    ): Float {
        val count = kpis.size
        val gap = 8f
        val totalGaps = gap * (count - 1)
        val cardWidth = (contentWidth - totalGaps) / count
        val cardHeight = 40f

        var currentX = a4Width - marginH

        kpis.forEach { kpi ->
            val left = currentX - cardWidth
            val rect = RectF(left, startY, currentX, startY + cardHeight)

            val bgPaint = Paint().apply { color = android.graphics.Color.rgb(255, 255, 255) }
            val borderPaint = Paint().apply {
                color = kpi.colorInt
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRoundRect(rect, 6f, 6f, bgPaint)
            canvas.drawRoundRect(rect, 6f, 6f, borderPaint)

            // علامة شريطية بلون الـ KPI
            val sideBar = RectF(currentX - 4f, startY, currentX, startY + cardHeight)
            val sidePaint = Paint().apply { color = kpi.colorInt }
            canvas.drawRoundRect(sideBar, 2f, 2f, sidePaint)

            val labelPaint = Paint().apply {
                isAntiAlias = true
                color = android.graphics.Color.rgb(100, 116, 139)
                textSize = 7.5f
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(kpi.label, currentX - 10f, startY + 14f, labelPaint)

            val valPaint = Paint().apply {
                isAntiAlias = true
                color = kpi.colorInt
                textSize = 12f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText("${kpi.value} ${kpi.unit}", currentX - 10f, startY + 31f, valPaint)

            currentX -= (cardWidth + gap)
        }

        return startY + cardHeight
    }

    private fun drawProjectBeneficiaryTable(
        canvas: Canvas,
        records: List<AidRecordWithBeneficiary>,
        startIndex: Int,
        startY: Float
    ): Float {
        var y = startY
        val colWidths = floatArrayOf(24f, 155f, 75f, 40f, 90f, 85f, 70f)
        val colHeaders = arrayOf("م", "اسم المستفيد الرباعي", "رقم الهوية", "الأفراد", "المنطقة / الشعبة", "حالة الاستلام", "التوقيع / البصمة")

        // رأس الجدول
        val headerHeight = 22f
        val headerBg = Paint().apply { color = android.graphics.Color.rgb(13, 148, 136) }
        canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, headerBg)

        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textSize = 8.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        var curX = a4Width - marginH
        colHeaders.forEachIndexed { i, title ->
            val w = colWidths[i]
            canvas.drawText(title, curX - (w / 2f), y + 14f, headerTextPaint)
            curX -= w
        }
        y += headerHeight

        // صفوف الجدول
        val rowHeight = 18f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = android.graphics.Color.rgb(248, 250, 252) }

        records.forEachIndexed { idx, item ->
            val isEven = idx % 2 == 0
            if (isEven) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            // 0: م
            canvas.drawText("${startIndex + idx + 1}", x - (colWidths[0] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[0]

            // 1: اسم المستفيد
            val name = item.family?.name ?: "مستفيد #${item.record.familyID}"
            val clippedName = if (name.length > 32) name.substring(0, 30) + "..." else name
            canvas.drawText(clippedName, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[1]

            // 2: الهوية
            canvas.drawText(item.family?.nationalID ?: "-", x - (colWidths[2] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[2]

            // 3: أفراد
            canvas.drawText("${item.family?.familyMembersCount ?: 0}", x - (colWidths[3] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[3]

            // 4: المنطقة
            val area = item.family?.currentSubArea ?: "-"
            val clippedArea = if (area.length > 18) area.substring(0, 16) + ".." else area
            canvas.drawText(clippedArea, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[4]

            // 5: حالة الاستلام
            val status = item.record.recipientStatus
            val statusPaint = Paint().apply {
                isAntiAlias = true
                textSize = 7.5f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
                color = if (status.contains("مستلم") || status.contains("تم التسليم")) android.graphics.Color.rgb(16, 185, 129) else android.graphics.Color.rgb(217, 119, 6)
            }
            canvas.drawText(status, x - (colWidths[5] / 2f), y + 12f, statusPaint)
            x -= colWidths[5]

            // 6: التوقيع / البصمة (مربع منقط خفيف)
            val boxPaint = Paint().apply {
                color = android.graphics.Color.rgb(203, 213, 225)
                style = Paint.Style.STROKE
                strokeWidth = 0.5f
            }
            canvas.drawRect(x - colWidths[6] + 8f, y + 3f, x - 8f, y + rowHeight - 3f, boxPaint)

            y += rowHeight
        }

        return y
    }

    private fun drawLocalitySubAreaTable(
        canvas: Canvas,
        subAreas: List<SubAreaBenefitRatioStat>,
        startIndex: Int,
        startY: Float
    ): Float {
        var y = startY
        val colWidths = floatArrayOf(24f, 155f, 80f, 80f, 70f, 65f, 65f)
        val colHeaders = arrayOf("م", "الشعبة / المنطقة الفرعية", "المستحقين (مقيم+معتمد)", "المستفيدين الفعليين", "إجمالي الأسر", "نسبة الإنجاز", "حالة التغطية")

        val headerHeight = 22f
        val headerBg = Paint().apply { color = android.graphics.Color.rgb(13, 148, 136) }
        canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, headerBg)

        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textSize = 8f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        var curX = a4Width - marginH
        colHeaders.forEachIndexed { i, title ->
            val w = colWidths[i]
            canvas.drawText(title, curX - (w / 2f), y + 14f, headerTextPaint)
            curX -= w
        }
        y += headerHeight

        val rowHeight = 18f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = android.graphics.Color.rgb(248, 250, 252) }

        subAreas.forEachIndexed { idx, sub ->
            val isEven = idx % 2 == 0
            if (isEven) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            // 0: م
            canvas.drawText("${startIndex + idx + 1}", x - (colWidths[0] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[0]

            // 1: اسم الشعبة
            canvas.drawText(sub.subAreaName, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[1]

            // 2: المستحقين
            canvas.drawText("${sub.eligibleFamiliesCount}", x - (colWidths[2] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[2]

            // 3: المستفيدين
            canvas.drawText("${sub.deliveredBeneficiariesCount}", x - (colWidths[3] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[3]

            // 4: إجمالي الأسر
            canvas.drawText("${sub.totalFamiliesCount}", x - (colWidths[4] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[4]

            // 5: نسبة الإنجاز
            val ratioPaint = Paint().apply {
                isAntiAlias = true
                textSize = 8f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
                color = if (sub.ratioPercentage >= 50) android.graphics.Color.rgb(16, 185, 129) else android.graphics.Color.rgb(245, 158, 11)
            }
            canvas.drawText(sub.formattedRatio, x - (colWidths[5] / 2f), y + 12f, ratioPaint)
            x -= colWidths[5]

            // 6: الحالة
            val statusPaint = Paint().apply {
                isAntiAlias = true
                textSize = 7f
                textAlign = Paint.Align.CENTER
                color = if (sub.ratioPercentage >= 50) android.graphics.Color.rgb(4, 120, 87) else android.graphics.Color.rgb(180, 83, 9)
            }
            val statusStr = if (sub.ratioPercentage >= 50) "تغطية ممتازة" else "قيد التوزيع"
            canvas.drawText(statusStr, x - (colWidths[6] / 2f), y + 12f, statusPaint)

            y += rowHeight
        }

        return y
    }

    private fun drawOfficialFooterWithSignatures(
        canvas: Canvas,
        supervisorName: String,
        pageIndex: Int,
        totalPages: Int
    ) {
        val y = a4Height - 85f

        // خط فاصل علوي
        val divPaint = Paint().apply {
            color = android.graphics.Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }
        canvas.drawLine(marginH, y, a4Width - marginH, y, divPaint)

        // 3 مربعات توقيع وخاتم رسمي
        val boxWidth = (contentWidth - 24f) / 3f
        val boxHeight = 44f
        val boxY = y + 8f

        val boxPaint = Paint().apply {
            color = android.graphics.Color.rgb(248, 250, 252)
        }
        val borderPaint = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val sigHeaderPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(71, 85, 105)
            textSize = 7.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val sigSubPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(100, 116, 139)
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }

        // 1. المشرف الميداني
        val b1 = RectF(a4Width - marginH - boxWidth, boxY, a4Width - marginH, boxY + boxHeight)
        canvas.drawRoundRect(b1, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b1, 4f, 4f, borderPaint)
        canvas.drawText("المشرف الميداني المسؤول", b1.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText(supervisorName, b1.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText("التوقيع: .....................", b1.centerX(), boxY + 36f, sigSubPaint)

        // 2. مدقق الرقابة والمطابقة
        val b2 = RectF(a4Width - marginH - (boxWidth * 2) - 12f, boxY, a4Width - marginH - boxWidth - 12f, boxY + boxHeight)
        canvas.drawRoundRect(b2, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b2, 4f, 4f, borderPaint)
        canvas.drawText("التدقيق والمطابقة الرقابية", b2.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText("مطابق لكشوفات الاستحقاق", b2.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText("التوقيع: .....................", b2.centerX(), boxY + 36f, sigSubPaint)

        // 3. خاتم الاعتماد الرسمي
        val b3 = RectF(marginH, boxY, marginH + boxWidth, boxY + boxHeight)
        canvas.drawRoundRect(b3, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b3, 4f, 4f, borderPaint)
        canvas.drawText("الختم والاعتماد الرسمي", b3.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText("إدارة المنظومة الإنسانية", b3.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText("ختم المنظمة المعتمد", b3.centerX(), boxY + 36f, sigSubPaint)

        // التذييل السفلي وأرقام الصفحات
        val footerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(148, 163, 184)
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("صفحة $pageIndex من $totalPages  •  نظام إدارة المساعدات الإنسانية - مستند رسمي معتمد وغير قابل للتعديل", a4Width / 2f, a4Height - 12f, footerTextPaint)
    }

    private fun drawPageNumberOnly(canvas: Canvas, pageIndex: Int, totalPages: Int) {
        val footerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(148, 163, 184)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("صفحة $pageIndex من $totalPages  •  نظام إدارة المساعدات الإنسانية", a4Width / 2f, a4Height - 14f, footerTextPaint)
    }

    // =========================================================================
    // =========================================================================
    // دوال المشاركة، الطباعة، وفتح الملفات
    // =========================================================================

    fun shareFile(file: File, mimeType: String, title: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, "مرفق مستند معتمد: $title - صادر عن نظام إدارة المساعدات الإنسانية.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "مشاركة المستند المعتمد:")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun openFile(file: File, mimeType: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "فتح المستند بواسطة:"))
    }

    fun printPdfReport(pdfFile: File, jobName: String = "Aid_Management_Report") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return

        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = android.print.PrintDocumentInfo.Builder(jobName)
                    .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out android.print.PageRange>?,
                destination: android.os.ParcelFileDescriptor?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    val input = java.io.FileInputStream(pdfFile)
                    val output = java.io.FileOutputStream(destination?.fileDescriptor)

                    val buf = ByteArray(1024)
                    var bytesRead: Int
                    while (input.read(buf).also { bytesRead = it } > 0) {
                        output.write(buf, 0, bytesRead)
                    }

                    callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                    input.close()
                    output.close()
                } catch (t: Throwable) {
                    callback?.onWriteFailed(t.message)
                }
            }
        }

        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    }
}
