package com.humanitarian.aidmanagement.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.data.repository.SubAreaBenefitRatioStat
import org.apache.poi.ss.usermodel.BorderStyle
import org.apache.poi.ss.usermodel.CellStyle
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.HorizontalAlignment
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.ss.usermodel.VerticalAlignment
import org.apache.poi.ss.util.CellRangeAddress
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AidRecordWithBeneficiary(
    val record: AidRecordEntity,
    val family: FamilyEntity?
)

data class ProjectReportData(
    val project: ProjectEntity,
    val aidTypeName: String,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String,
    val notes: String? = null
)

data class LocalityReportData(
    val localityName: String,
    val subAreas: List<SubAreaBenefitRatioStat>,
    val totalFamilies: Int,
    val totalBeneficiaries: Int,
    val totalDelivered: Int,
    val dateGenerated: String,
    val supervisorName: String
)

data class ComprehensivePeriodReportData(
    val fromDate: String,
    val toDate: String,
    val totalDeliveries: Int,
    val localityStats: List<LocalityDistributionStat>,
    val aidTypeStats: List<AidTypeDistributionStat>,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String
)

class ProfessionalReportExporter(private val context: Context) {

    private val a4Width = 595
    private val a4Height = 842
    private val marginH = 28f
    private val contentWidth = a4Width - (marginH * 2)

    fun generateProjectBeneficiariesPdf(data: ProjectReportData): File {
        val pdfDocument = PdfDocument()

        val deliveredCount = data.records.count { 
            it.record.recipientStatus.contains("مستلم") || 
            it.record.recipientStatus.contains("تم التسليم") 
        }
        val pendingCount = data.records.size - deliveredCount
        val ratePercent = if (data.records.isNotEmpty()) (deliveredCount * 100 / data.records.size) else 0

        val itemsPerPage = 22
        val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = "كشف مستفيدي المشروع الإنساني المعتمد",
                subtitle = String.format(Locale.US, "المشروع: %s (%s)", data.project.projectName, data.project.projectNumber),
                periodOrFilter = String.format(Locale.US, "الممول: %s | نوع المعونة: %s", data.project.fundingInstitution, data.aidTypeName),
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem("إجمالي الكشف", data.records.size.toString(), "مستفيد", Color.rgb(13, 148, 136)),
                        KpiItem("تم التسليم", deliveredCount.toString(), "طرد", Color.rgb(16, 185, 129)),
                        KpiItem("بانتظار الصرف", pendingCount.toString(), "مرشح", Color.rgb(245, 158, 11)),
                        KpiItem("نسبة الإنجاز", String.format(Locale.US, "%d%%", ratePercent), "مكتمل", Color.rgb(2, 132, 199))
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
            val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

            currentY = drawProjectBeneficiaryTable(
                canvas = canvas,
                records = pageRecords,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, String.format(Locale.US, "Project_%s_%s.pdf", data.project.projectNumber, timeStamp))

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    fun generateLocalitySubAreasPdf(data: LocalityReportData): File {
        val pdfDocument = PdfDocument()

        val itemsPerPage = 20
        val totalPages = if (data.subAreas.isEmpty()) 1 else ((data.subAreas.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = "تقرير التغطية الميدانية ونسب الاستفادة للمحلية",
                subtitle = String.format(Locale.US, "المحلية المعتمدة: %s", data.localityName),
                periodOrFilter = "حساب الاستحقاق الصارم: المستفيدين / الأسر المستحقة",
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                val totalEligible = data.subAreas.sumOf { it.eligibleFamiliesCount }
                val totalDelivered = data.subAreas.sumOf { it.deliveredBeneficiariesCount }
                val overallRatio = if (totalEligible > 0) (totalDelivered * 100 / totalEligible) else 0

                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem("إجمالي الأسر", data.totalFamilies.toString(), "أسرة", Color.rgb(13, 148, 136)),
                        KpiItem("المستحقين", totalEligible.toString(), "مقيم+معتمد", Color.rgb(2, 132, 199)),
                        KpiItem("المستفيدين الفعليين", totalDelivered.toString(), "مستفيد", Color.rgb(16, 185, 129)),
                        KpiItem("معدل التغطية", String.format(Locale.US, "%d%%", overallRatio), "إنجاز", Color.rgb(245, 158, 11))
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.subAreas.size)
            val pageSubAreas = if (data.subAreas.isNotEmpty()) data.subAreas.subList(startIndex, endIndex) else emptyList()

            currentY = drawLocalitySubAreaTable(
                canvas = canvas,
                subAreas = pageSubAreas,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, String.format(Locale.US, "Locality_%s_%s.pdf", data.localityName, timeStamp))

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    fun generateComprehensivePeriodPdf(data: ComprehensivePeriodReportData): File {
        val pdfDocument = PdfDocument()

        val itemsPerPage = 22
        val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = "تقرير التوزيع الشامل والعمليات الميدانية",
                subtitle = String.format(Locale.US, "نطاق الفترة الزمنية: من %s إلى %s", data.fromDate, data.toDate),
                periodOrFilter = String.format(Locale.US, "المحليات النشطة: %d | أصناف المساعدات: %d", data.localityStats.size, data.aidTypeStats.size),
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem("مساعدات الفترة", data.totalDeliveries.toString(), "سجل/طرد", Color.rgb(13, 148, 136)),
                        KpiItem("المستفيدين الموثقين", data.records.size.toString(), "مستلم", Color.rgb(16, 185, 129)),
                        KpiItem("المحليات المشمولة", data.localityStats.size.toString(), "محلية", Color.rgb(2, 132, 199)),
                        KpiItem("أنواع المعونة", data.aidTypeStats.size.toString(), "صنف", Color.rgb(139, 92, 246))
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
            val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

            currentY = drawProjectBeneficiaryTable(
                canvas = canvas,
                records = pageRecords,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, String.format(Locale.US, "Comprehensive_%s_to_%s_%s.pdf", data.fromDate, data.toDate, timeStamp))

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    fun generateProjectBeneficiariesExcel(data: ProjectReportData): File {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("كشف_مستفيدي_المشروع")
        sheet.isRightToLeft = true

        val headerStyle = createHeaderCellStyle(workbook)
        val titleStyle = createTitleCellStyle(workbook)
        val dataStyleEven = createDataCellStyle(workbook, isEven = true)
        val dataStyleOdd = createDataCellStyle(workbook, isEven = false)
        val metaLabelStyle = createMetaLabelStyle(workbook)
        val metaValueStyle = createMetaValueStyle(workbook)

        var rowIdx = 0

        val titleRow = sheet.createRow(rowIdx++)
        titleRow.heightInPoints = 30f
        val titleCell = titleRow.createCell(0)
        titleCell.setCellValue(String.format(Locale.US, "كشف مستفيدي المشروع الإنساني المعتمد - %s", data.project.projectName))
        titleCell.cellStyle = titleStyle
        sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 7))

        rowIdx++ 

        val metaRow1 = sheet.createRow(rowIdx++)
        metaRow1.createCell(0).apply { setCellValue("رقم المشروع:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(1).apply { setCellValue(data.project.projectNumber); cellStyle = metaValueStyle }
        metaRow1.createCell(2).apply { setCellValue("الجهة الممولة:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(3).apply { setCellValue(data.project.fundingInstitution); cellStyle = metaValueStyle }

        val metaRow2 = sheet.createRow(rowIdx++)
        metaRow2.createCell(0).apply { setCellValue("نوع المساعدة:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(1).apply { setCellValue(data.aidTypeName); cellStyle = metaValueStyle }
        metaRow2.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

        val metaRow3 = sheet.createRow(rowIdx++)
        metaRow3.createCell(0).apply { setCellValue("المشرف الميداني:"); cellStyle = metaLabelStyle }
        metaRow3.createCell(1).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }
        metaRow3.createCell(2).apply { setCellValue("إجمالي السجلات:"); cellStyle = metaLabelStyle }
        metaRow3.createCell(3).apply { setCellValue(String.format(Locale.US, "%d مستفيد", data.records.size)); cellStyle = metaValueStyle }

        rowIdx++

        val tableHeaderRow = sheet.createRow(rowIdx++)
        tableHeaderRow.heightInPoints = 24f
        val headers = listOf(
            "م", "اسم رب الأسرة الرباعي", "رقم الهوية الوطنية", "أفراد الأسرة",
            "رقم الجوال", "المنطقة / الشعبة", "حالة الاستلام", "ملاحظات الصرف والتحقق"
        )
        headers.forEachIndexed { colIdx, header ->
            tableHeaderRow.createCell(colIdx).apply {
                setCellValue(header)
                cellStyle = headerStyle
            }
        }

        data.records.forEachIndexed { i, item ->
            val row = sheet.createRow(rowIdx++)
            row.heightInPoints = 20f
            val style = if (i % 2 == 0) dataStyleEven else dataStyleOdd

            row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
            row.createCell(1).apply { setCellValue(item.family?.name ?: "-"); cellStyle = style }
            row.createCell(2).apply { setCellValue(item.family?.nationalID ?: "-"); cellStyle = style }
            row.createCell(3).apply { setCellValue((item.family?.familyMembersCount ?: 0).toDouble()); cellStyle = style }
            row.createCell(4).apply { setCellValue(item.family?.primaryPhone ?: "-"); cellStyle = style }
            row.createCell(5).apply { setCellValue(item.family?.currentSubArea ?: "-"); cellStyle = style }
            row.createCell(6).apply { setCellValue(item.record.recipientStatus); cellStyle = style }
            row.createCell(7).apply { setCellValue(item.record.notes ?: ""); cellStyle = style }
        }

        for (c in headers.indices) {
            sheet.autoSizeColumn(c)
            sheet.setColumnWidth(c, (sheet.getColumnWidth(c) + 1400).coerceAtMost(10000))
        }

        val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, String.format(Locale.US, "Project_%s_%s.xlsx", data.project.projectNumber, timeStamp))

        FileOutputStream(outputFile).use { fos ->
            workbook.write(fos)
        }
        workbook.close()
        return outputFile
    }

    fun generateLocalitySubAreasExcel(data: LocalityReportData): File {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("تغطية_المحلية_والشعب")
        sheet.isRightToLeft = true

        val headerStyle = createHeaderCellStyle(workbook)
        val titleStyle = createTitleCellStyle(workbook)
        val dataStyleEven = createDataCellStyle(workbook, isEven = true)
        val dataStyleOdd = createDataCellStyle(workbook, isEven = false)
        val metaLabelStyle = createMetaLabelStyle(workbook)
        val metaValueStyle = createMetaValueStyle(workbook)

        var rowIdx = 0

        val titleRow = sheet.createRow(rowIdx++)
        titleRow.heightInPoints = 30f
        val titleCell = titleRow.createCell(0)
        titleCell.setCellValue(String.format(Locale.US, "تقرير التغطية الميدانية ونسب الاستفادة - محلية %s", data.localityName))
        titleCell.cellStyle = titleStyle
        sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 6))

        rowIdx++

        val metaRow1 = sheet.createRow(rowIdx++)
        metaRow1.createCell(0).apply { setCellValue("المحلية المعتمدة:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(1).apply { setCellValue(data.localityName); cellStyle = metaValueStyle }
        metaRow1.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

        val metaRow2 = sheet.createRow(rowIdx++)
        metaRow2.createCell(0).apply { setCellValue("المشرف الميداني:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(1).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }
        metaRow2.createCell(2).apply { setCellValue("إجمالي الأسر المسجلة:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(3).apply { setCellValue(String.format(Locale.US, "%d أسرة", data.totalFamilies)); cellStyle = metaValueStyle }

        rowIdx++

        val tableHeaderRow = sheet.createRow(rowIdx++)
        tableHeaderRow.heightInPoints = 24f
        val headers = listOf(
            "م", "الشعبة / المنطقة الفرعية", "المستحقين (مقيم + معتمد)",
            "المستفيدين الفعليين", "إجمالي الأسر المسجلة", "نسبة التغطية والاستفادة", "حالة التغطية الميدانية"
        )
        headers.forEachIndexed { colIdx, header ->
            tableHeaderRow.createCell(colIdx).apply {
                setCellValue(header)
                cellStyle = headerStyle
            }
        }

        data.subAreas.forEachIndexed { i, sub ->
            val row = sheet.createRow(rowIdx++)
            row.heightInPoints = 20f
            val style = if (i % 2 == 0) dataStyleEven else dataStyleOdd

            row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
            row.createCell(1).apply { setCellValue(sub.subAreaName); cellStyle = style }
            row.createCell(2).apply { setCellValue(sub.eligibleFamiliesCount.toDouble()); cellStyle = style }
            row.createCell(3).apply { setCellValue(sub.deliveredBeneficiariesCount.toDouble()); cellStyle = style }
            row.createCell(4).apply { setCellValue(sub.totalFamiliesCount.toDouble()); cellStyle = style }
            row.createCell(5).apply { setCellValue(sub.formattedRatio); cellStyle = style }
            row.createCell(6).apply {
                val statusText = if (sub.ratioPercentage >= 50) "تغطية ممتازة" else "قيد التوزيع والمتابعة"
                setCellValue(statusText)
                cellStyle = style
            }
        }

        for (c in headers.indices) {
            sheet.autoSizeColumn(c)
            sheet.setColumnWidth(c, (sheet.getColumnWidth(c) + 1400).coerceAtMost(10000))
        }

        val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, String.format(Locale.US, "Locality_%s_%s.xlsx", data.localityName, timeStamp))

        FileOutputStream(outputFile).use { fos ->
            workbook.write(fos)
        }
        workbook.close()
        return outputFile
    }

    fun generateComprehensivePeriodExcel(data: ComprehensivePeriodReportData): File {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("تقرير_التوزيع_الشامل")
        sheet.isRightToLeft = true

        val headerStyle = createHeaderCellStyle(workbook)
        val titleStyle = createTitleCellStyle(workbook)
        val dataStyleEven = createDataCellStyle(workbook, isEven = true)
        val dataStyleOdd = createDataCellStyle(workbook, isEven = false)
        val metaLabelStyle = createMetaLabelStyle(workbook)
        val metaValueStyle = createMetaValueStyle(workbook)

        var rowIdx = 0

        val titleRow = sheet.createRow(rowIdx++)
        titleRow.heightInPoints = 30f
        val titleCell = titleRow.createCell(0)
        titleCell.setCellValue(String.format(Locale.US, "تقرير التوزيع الشامل والعمليات الميدانية (%s إلى %s)", data.fromDate, data.toDate))
        titleCell.cellStyle = titleStyle
        sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 7))

        rowIdx++

        val metaRow1 = sheet.createRow(rowIdx++)
        metaRow1.createCell(0).apply { setCellValue("نطاق الفترة:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(1).apply { setCellValue(String.format(Locale.US, "%s إلى %s", data.fromDate, data.toDate)); cellStyle = metaValueStyle }
        metaRow1.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

        val metaRow2 = sheet.createRow(rowIdx++)
        metaRow2.createCell(0).apply { setCellValue("إجمالي مساعدات الفترة:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(1).apply { setCellValue(String.format(Locale.US, "%d طرد", data.totalDeliveries)); cellStyle = metaValueStyle }
        metaRow2.createCell(2).apply { setCellValue("المشرف المسؤول:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(3).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }

        rowIdx++

        val tableHeaderRow = sheet.createRow(rowIdx++)
        tableHeaderRow.heightInPoints = 24f
        val headers = listOf(
            "م", "اسم المستفيد الرباعي", "رقم الهوية", "المحلية / المنطقة",
            "المشروع الإغاثي", "تاريخ التسليم", "حالة الاستلام", "المستلم الفعلي والملاحظات"
        )
        headers.forEachIndexed { colIdx, header ->
            tableHeaderRow.createCell(colIdx).apply {
                setCellValue(header)
                cellStyle = headerStyle
            }
        }

        data.records.forEachIndexed { i, item ->
            val row = sheet.createRow(rowIdx++)
            row.heightInPoints = 20f
            val style = if (i % 2 == 0) dataStyleEven else dataStyleOdd

            row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
            row.createCell(1).apply { setCellValue(item.family?.name ?: "-"); cellStyle = style }
            row.createCell(2).apply { setCellValue(item.family?.nationalID ?: "-"); cellStyle = style }
            row.createCell(3).apply { setCellValue(item.family?.currentSubArea ?: "-"); cellStyle = style }
            row.createCell(4).apply { setCellValue(String.
