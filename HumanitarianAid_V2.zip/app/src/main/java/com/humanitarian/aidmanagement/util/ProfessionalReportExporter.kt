package com.humanitarian.aidmanagement.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.data.repository.SubAreaBenefitRatioStat
import org.apache.poi.ss.usermodel.BorderStyle
import org.apache.poi.ss.usermodel.CellStyle
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.HorizontalAlignment
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.ss.usermodel.VerticalAlignment
import org.apache.poi.ss.util.CellRangeAddress
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * بيانات سجل مساعدة مع تفاصيل الأسرة المستفيدة
 */
data class AidRecordWithBeneficiary(
    val record: AidRecordEntity,
    val family: FamilyEntity?
)

/**
 * بيانات تقرير المشروع والمستفيدين
 */
data class ProjectReportData(
    val project: ProjectEntity,
    val aidTypeName: String,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String,
    val notes: String? = null
)

/**
 * بيانات تقرير المحلية والشعب التابعة
 */
data class LocalityReportData(
    val localityName: String,
    val subAreas: List<SubAreaBenefitRatioStat>,
    val totalFamilies: Int,
    val totalBeneficiaries: Int,
    val totalDelivered: Int,
    val dateGenerated: String,
    val supervisorName: String
)

/**
 * بيانات تقرير التوزيع الشامل حسب الفترة الزمنية
 */
data class ComprehensivePeriodReportData(
    val fromDate: String,
    val toDate: String,
    val totalDeliveries: Int,
    val localityStats: List<LocalityDistributionStat>,
    val aidTypeStats: List<AidTypeDistributionStat>,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String
)

/**
 * فئة احترافية متكاملة لتوليد تقارير A4 PDF رسمية وتصدير ملفات Excel (.xlsx) عبر Apache POI
 */
class ProfessionalReportExporter(private val context: Context) {

    private val a4Width = 595
    private val a4Height = 842
    private val marginH = 28f
    private val contentWidth = a4Width - (marginH * 2)

    // =========================================================================
    // 1. توليد تقرير المشروع ومستفيديه بصيغة A4 PDF
    // =========================================================================
    fun generateProjectBeneficiariesPdf(data: ProjectReportData): File {
        val pdfDocument = PdfDocument()

        val deliveredCount = data.records.count { 
            it.record.recipientStatus.contains("مستلم") || 
            it.record.recipientStatus.contains("تم التسليم") 
        }
        val pendingCount = data.records.size - deliveredCount
        val ratePercent = if (data.records.isNotEmpty()) (deliveredCount * 100 / data.records.size) else 0

        val itemsPerPage = 22
        val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = "كشف مستفيدي المشروع الإنساني المعتمد",
                subtitle = "المشروع: ${data.project.projectName} (${data.project.projectNumber})",
                periodOrFilter = "الممول: ${data.project.fundingInstitution} \vert{} نوع المعونة: ${data.aidTypeName}",
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem(
                            "إجمالي الكشف", 
                            "${data.records.size}", 
                            "مستفيد", 
                            android.graphics.Color.rgb(13, 148, 136)
                        ),
                        KpiItem(
                            "تم التسليم", 
                            "$deliveredCount", 
                            "طرد", 
                            android.graphics.Color.rgb(16, 185, 129)
                        ),
                        KpiItem(
                            "بانتظار الصرف", 
                            "$pendingCount", 
                            "مرشح", 
                            android.graphics.Color.rgb(245, 158, 11)
                        ),
                        KpiItem(
                            "نسبة الإنجاز", 
                            "$ratePercent%", 
                            "مكتمل", 
                            android.graphics.Color.rgb(2, 132, 199)
                        )
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
            val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

            currentY = drawProjectBeneficiaryTable(
                canvas = canvas,
                records = pageRecords,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, "Project_${data.project.projectNumber}_$timeStamp.pdf")

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    // =========================================================================
    // 2. توليد تقرير المحلية والشعب التابعة بصيغة A4 PDF
    // =========================================================================
    fun generateLocalitySubAreasPdf(data: LocalityReportData): File {
        val pdfDocument = PdfDocument()

        val itemsPerPage = 20
        val totalPages = if (data.subAreas.isEmpty()) 1 else ((data.subAreas.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = "تقرير التغطية الميدانية ونسب الاستفادة للمحلية",
                subtitle = "المحلية المعتمدة: ${data.localityName}",
                periodOrFilter = "حساب الاستحقاق الصارم: المستفيدين / الأسر المستحقة",
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                val totalEligible = data.subAreas.sumOf { it.eligibleFamiliesCount }
                val totalDelivered = data.subAreas.sumOf { it.deliveredBeneficiariesCount }
                val overallRatio = if (totalEligible > 0) (totalDelivered * 100 / totalEligible) else 0

                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem(
                            "إجمالي الأسر", 
                            "${data.totalFamilies}", 
                            "أسرة", 
                            android.graphics.Color.rgb(13, 148, 136)
                        ),
                        KpiItem(
                            "المستحقين", 
                            "$totalEligible", 
                            "مقيم+معتمد", 
                            android.graphics.Color.rgb(2, 132, 199)
                        ),
                        KpiItem(
                            "المستفيدين الفعليين", 
                            "$totalDelivered", 
                            "مستفيد", 
                            android.graphics.Color.rgb(16, 185, 129)
                        ),
                        KpiItem(
                            "معدل التغطية", 
                            "$overallRatio%", 
                            "إنجاز", 
                            android.graphics.Color.rgb(245, 158, 11)
                        )
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.subAreas.size)
            val pageSubAreas = if (data.subAreas.isNotEmpty()) data.subAreas.subList(startIndex, endIndex) else emptyList()

            currentY = drawLocalitySubAreaTable(
                canvas = canvas,
                subAreas = pageSubAreas,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, "Locality_${data.localityName}_$timeStamp.pdf")

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    // =========================================================================
    // 3. توليد تقرير التوزيع الشامل حسب الفترة بصيغة A4 PDF
    // =========================================================================
    fun generateComprehensivePeriodPdf(data: ComprehensivePeriodReportData): File {
        val pdfDocument = PdfDocument()

        val itemsPerPage = 22
        val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = "تقرير التوزيع الشامل والعمليات الميدانية",
                subtitle = "نطاق الفترة الزمنية: من ${data.fromDate} إلى ${data.toDate}",
                periodOrFilter = "المحليات النشطة: ${data.localityStats.size} \vert{} أصناف المساعدات: ${data.aidTypeStats.size}",
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem(
                            "مساعدات الفترة", 
                            "${data.totalDeliveries}", 
                            "سجل/طرد", 
                            android.graphics.Color.rgb(13, 148, 136)
                        ),
                        KpiItem(
                            "المستفيدين الموثقين", 
                            "${data.records.size}", 
                            "مستلم", 
                            android.graphics.Color.rgb(16, 185, 129)
                        ),
                        KpiItem(
                            "المحليات المشمولة", 
                            "${data.localityStats.size}", 
                            "محلية", 
                            android.graphics.Color.rgb(2, 132, 199)
                        ),
                        KpiItem(
                            "أنواع المعونة", 
                            "${data.aidTypeStats.size}", 
                            "صنف", 
                            android.graphics.Color.rgb(139, 92, 246)
                        )
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
            val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

            currentY = drawProjectBeneficiaryTable(
                canvas = canvas,
                records = pageRecords,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

