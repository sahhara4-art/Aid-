# إعداد المزامنة السحابية (Cloud Integration Guide)

يوضح هذا الدليل كيفية ربط تطبيق "نظام إدارة المساعدات الإنسانية" بالخادم السحابي وقاعدة بيانات Firebase / Firestore للمزامنة ثنائية الاتجاه مع الحفاظ على العمل دون اتصال (Offline-first architecture).

## 1. متطلبات الربط:
- حساب Firebase نشط مع مشروع مُفعّل فيه Firebase Firestore و Authentication.
- وضع ملف `google-services.json` داخل مجلد `android/app/`.

## 2. آليات المزامنة:
- مراقبة حالة الشبكة تلقائياً عبر `NetworkConnectivityObserver`.
- جدولة مزامنة الفروقات (Delta Sync) بالخلفية عبر `WorkManager` و `SyncWorker`.
- فحص وحل التعارضات (Conflict Resolution) مع منح الأولوية للتعديل الأحدث زمنياً.
