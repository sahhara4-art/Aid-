import React, { useState, useMemo } from 'react';
import {
  INITIAL_FAMILIES,
  AID_CATEGORIES,
  INITIAL_LOCALITIES,
  MOCK_CHILDREN,
  INITIAL_FAMILY_BENEFITS,
  DEFAULT_CATEGORY_EXCLUSION_DAYS,
  MockFamily
} from './AndroidEmulator';
import {
  Shield,
  Layers,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Users,
  Award,
  Sparkles,
  Calculator,
  ChevronRight,
  ChevronLeft,
  ArrowDown,
  Sliders,
  Calendar,
  Building,
  Home,
  Check,
  Download,
  AlertTriangle,
  RotateCcw,
  BarChart3,
  FileCheck2,
  Info
} from 'lucide-react';

export function NominationVisualizer() {
  // Active Stage in the Pipeline Visualizer
  const [activeStage, setActiveStage] = useState<number>(1);

  // Strategy Presets
  const [strategyPreset, setStrategyPreset] = useState<'balanced' | 'children' | 'damage' | 'time'>('balanced');

  // Sliders for Priority Weights
  const [weightFamilySize, setWeightFamilySize] = useState<number>(10);
  const [weightChildren, setWeightChildren] = useState<number>(5);
  const [weightDamage, setWeightDamage] = useState<number>(20);
  const [weightTimeElapsed, setWeightTimeElapsed] = useState<number>(15);

  // Filter Simulation Controls
  const [selectedAidIds, setSelectedAidIds] = useState<number[]>([1]); // default: غذائي
  const [exclusionMode, setExclusionMode] = useState<'days' | 'date'>('days');
  const [exclusionDays, setExclusionDays] = useState<number>(30);
  const [useDynamicCategoryExclusion, setUseDynamicCategoryExclusion] = useState<boolean>(true);
  const [categoryExclusionDaysMap, setCategoryExclusionDaysMap] = useState<Record<number, number>>(DEFAULT_CATEGORY_EXCLUSION_DAYS);
  const [exclusionCutoffDate, setExclusionCutoffDate] = useState<string>('2024-12-01');
  const [shelterFilter, setShelterFilter] = useState<string>('الكل');
  const [damageFilter, setDamageFilter] = useState<string>('الكل');
  const [worksFilter, setWorksFilter] = useState<string>('الكل');
  const [minMembers, setMinMembers] = useState<number>(1);
  const [requireChildren, setRequireChildren] = useState<boolean>(false);
  const [maxChildAge, setMaxChildAge] = useState<number>(5);
  const [totalRequired, setTotalRequired] = useState<number>(10);

  // Selected Family for Detailed Breakdown Modal/Drawer
  const [selectedFamilyId, setSelectedFamilyId] = useState<number>(1);

  // Apply Presets
  const applyPreset = (preset: 'balanced' | 'children' | 'damage' | 'time') => {
    setStrategyPreset(preset);
    if (preset === 'balanced') {
      setWeightFamilySize(10);
      setWeightChildren(5);
      setWeightDamage(20);
      setWeightTimeElapsed(15);
    } else if (preset === 'children') {
      setWeightFamilySize(8);
      setWeightChildren(25);
      setWeightDamage(10);
      setWeightTimeElapsed(10);
      setRequireChildren(true);
      setMaxChildAge(5);
    } else if (preset === 'damage') {
      setWeightFamilySize(8);
      setWeightChildren(5);
      setWeightDamage(35);
      setWeightTimeElapsed(10);
      setShelterFilter('إيواء داخلي');
    } else if (preset === 'time') {
      setWeightFamilySize(6);
      setWeightChildren(4);
      setWeightDamage(10);
      setWeightTimeElapsed(35);
      setExclusionDays(60);
    }
  };

  // Funnel Pipeline Calculations in Real-time
  const pipelineMetrics = useMemo(() => {
    const total = INITIAL_FAMILIES.length;
    const now = new Date().getTime();

    // Stage 1: Development Approval Filter (دائم وإلزامي: معتمد فقط، واستبعاد حجب اعتماد أو مجمد)
    const stage1Passed = INITIAL_FAMILIES.filter(f => f.developmentApproval === 'معتمد');

    // Stage 2: Custom Criteria Filters
    const stage2Passed = stage1Passed.filter(f => {
      if (shelterFilter !== 'الكل') {
        if (shelterFilter === 'إيواء داخلي' && f.shelterStatus !== 'إيواء داخلي') return false;
        if (shelterFilter === 'خارج الإيواء' && f.shelterStatus === 'إيواء داخلي') return false;
      }
      if (damageFilter !== 'الكل' && f.damageType !== damageFilter) return false;
      if (worksFilter !== 'الكل') {
        if (worksFilter === 'اعتماد أشغال' && f.worksApproval !== 'اعتماد أشغال') return false;
        if (worksFilter === 'غير معتمد' && f.worksApproval === 'اعتماد أشغال') return false;
      }
      if (f.membersCount < minMembers) return false;
      if (requireChildren) {
        const familyChildren = MOCK_CHILDREN.filter(c => c.parentNationalID === f.nationalID);
        if (!familyChildren.some(c => c.age <= maxChildAge)) return false;
      }
      return true;
    });

    // Stage 3: Multi-Category Exclusion Matrix
    const stage3Passed = stage2Passed.filter(f => {
      const familyBenefits = INITIAL_FAMILY_BENEFITS[f.familyID] || {};
      for (const aidId of selectedAidIds) {
        const rec = familyBenefits[aidId];
        if (rec && rec.date) {
          if (exclusionMode === 'days') {
            const aidTime = new Date(rec.date).getTime();
            const diffDays = Math.floor((now - aidTime) / (1000 * 60 * 60 * 24));
            const prohibitedDays = useDynamicCategoryExclusion
              ? (categoryExclusionDaysMap[aidId] || exclusionDays)
              : exclusionDays;
            if (diffDays < prohibitedDays) return false;
          } else {
            if (rec.date >= exclusionCutoffDate) return false;
          }
        }
      }
      return true;
    });

    // Stage 4: Scoring & Ranking
    const scoredList = stage3Passed.map(f => {
      const fChildren = MOCK_CHILDREN.filter(c => c.parentNationalID === f.nationalID);
      const childrenCount = fChildren.length;
      
      const familyBenefits = INITIAL_FAMILY_BENEFITS[f.familyID] || {};
      let minDays = 999;
      Object.values(familyBenefits).forEach(b => {
        if (b.date) {
          const diff = Math.floor((now - new Date(b.date).getTime()) / (1000 * 60 * 60 * 24));
          if (diff < minDays) minDays = diff;
        }
      });
      if (minDays === 999) minDays = 365;

      const sizeScore = f.membersCount * weightFamilySize;
      const childScore = childrenCount * weightChildren;
      const damageScore = f.damageType === 'أضرار كلية' ? weightDamage : (f.damageType === 'أضرار جزئية بليغة' ? weightDamage * 0.6 : weightDamage * 0.3);
      const timeScore = (Math.min(minDays, 365) / 365.0) * weightTimeElapsed;
      const totalScore = parseFloat((sizeScore + childScore + damageScore + timeScore).toFixed(1));

      return {
        family: f,
        childrenCount,
        minDays,
        sizeScore,
        childScore,
        damageScore,
        timeScore,
        totalScore
      };
    }).sort((a, b) => b.totalScore - a.totalScore);

    const nominatedCount = Math.min(totalRequired, scoredList.length);
    const finalNominated = scoredList.slice(0, nominatedCount);

    return {
      total,
      devPassedCount: stage1Passed.length,
      criteriaPassedCount: stage2Passed.length,
      exclusionPassedCount: stage3Passed.length,
      nominatedCount,
      scoredList,
      finalNominated
    };
  }, [
    shelterFilter,
    damageFilter,
    worksFilter,
    minMembers,
    requireChildren,
    maxChildAge,
    selectedAidIds,
    exclusionMode,
    exclusionDays,
    exclusionCutoffDate,
    weightFamilySize,
    weightChildren,
    weightDamage,
    weightTimeElapsed,
    totalRequired
  ]);

  // Hamilton Largest Remainder Quota calculation for localities
  const localityQuotas = useMemo(() => {
    const totalPercent = INITIAL_LOCALITIES.reduce((sum, l) => sum + l.percent, 0);
    const exactShares = INITIAL_LOCALITIES.map(l => {
      const exact = (l.percent / totalPercent) * totalRequired;
      const floor = Math.floor(exact);
      return {
        ...l,
        exact: parseFloat(exact.toFixed(2)),
        floor,
        remainder: parseFloat((exact - floor).toFixed(4))
      };
    });

    let assigned = exactShares.reduce((sum, s) => sum + s.floor, 0);
    let deficit = totalRequired - assigned;

    const sortedByRemainder = [...exactShares].sort((a, b) => b.remainder - a.remainder);
    const bonusMap = new Set<number>();
    for (const item of sortedByRemainder) {
      if (deficit > 0) {
        bonusMap.add(item.id);
        deficit -= 1;
      }
    }

    return exactShares.map(s => ({
      ...s,
      allocated: s.floor + (bonusMap.has(s.id) ? 1 : 0),
      hasBonus: bonusMap.has(s.id)
    }));
  }, [totalRequired]);

  // Selected Family Object & Breakdown
  const selectedFamilyData = useMemo(() => {
    const candidate = pipelineMetrics.scoredList.find(c => c.family.familyID === selectedFamilyId);
    if (candidate) return candidate;
    const base = INITIAL_FAMILIES.find(f => f.familyID === selectedFamilyId) || INITIAL_FAMILIES[0];
    return {
      family: base,
      childrenCount: MOCK_CHILDREN.filter(c => c.parentNationalID === base.nationalID).length,
      minDays: 120,
      sizeScore: base.membersCount * weightFamilySize,
      childScore: 0,
      damageScore: 10,
      timeScore: 5,
      totalScore: 50
    };
  }, [pipelineMetrics.scoredList, selectedFamilyId, weightFamilySize]);

  // Stages Definition for Pipeline
  const STAGES = [
    {
      id: 1,
      title: 'مجمع الأسر والمحليات',
      subtitle: 'السجل الشامل للأسر المسجلة في قاعدة البيانات',
      icon: Users,
      color: 'sky'
    },
    {
      id: 2,
      title: 'بوابة اعتماد التنمية',
      subtitle: 'الشرط الإلزامي الدائم (معتمد تنمية فقط)',
      icon: Shield,
      color: 'emerald'
    },
    {
      id: 3,
      title: 'مصفاة المعايير الميدانية',
      subtitle: 'الأطفال، الإيواء، الأشغال، الضرر، حجم الأسرة',
      icon: Filter,
      color: 'indigo'
    },
    {
      id: 4,
      title: 'مصفوفة الاستثناء الزمني (11 تصنيف)',
      subtitle: 'منع الازدواجية بالأيام أو بتاريخ محدد',
      icon: Clock,
      color: 'amber'
    },
    {
      id: 5,
      title: 'محرك سكور الأولوية وكوتا المحليات',
      subtitle: 'المعادلة المركبة وطريقة أكبر البواقي الرياضية',
      icon: Calculator,
      color: 'purple'
    },
    {
      id: 6,
      title: 'شاشة الترحيل واعتماد المشروع',
      subtitle: 'ربط بيانات المشروع المنفذ وسجل الاستفادة والتصدير',
      icon: FileCheck2,
      color: 'teal'
    }
  ];

  return (
    <div className="space-y-6 text-slate-100 font-sans" dir="rtl">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-850 to-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 left-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none -translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl pointer-events-none translate-x-1/2 translate-y-1/2" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                استوديو خوارزمية الترشيح الذكية
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] text-slate-400 bg-slate-800 border border-slate-700">
                Audited & Transparent Engine
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide">
              تصوير وشرح آلية الترشيح وتدقيق المعايير باحترافية
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              نموذج تفاعلي متكامل يوضح انتقال الأسر عبر مراحل الترشيح الست: من السجل الأساسي، مروراً ببوابة التنمية والمعايير المخصصة والاستثناء الزمني للتصنيفات الـ 11، وصولاً لحصص أكبر البواقي وشاشة الترحيل والاعتماد النهائي.
            </p>
          </div>

          {/* Quick Strategy Preset Buttons */}
          <div className="bg-slate-900/90 p-3 rounded-2xl border border-slate-750 shadow-inner space-y-2 shrink-0">
            <span className="text-[11px] text-slate-400 font-bold block mb-1">
              استراتيجيات وأولويات التوزيع الجاهزة:
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              <button
                onClick={() => applyPreset('balanced')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  strategyPreset === 'balanced'
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <span>⚖️ متوازنة معيارية</span>
              </button>
              <button
                onClick={() => applyPreset('children')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  strategyPreset === 'children'
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-600/30'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <span>👶 الأطفال والرُضّع</span>
              </button>
              <button
                onClick={() => applyPreset('damage')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  strategyPreset === 'damage'
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <span>🏚️ الأشد ضرراً وإيواءً</span>
              </button>
              <button
                onClick={() => applyPreset('time')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                  strategyPreset === 'time'
                    ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                }`}
              >
                <span>⏳ الأطول انقطاعاً</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* STAGE PIPELINE ROADMAP */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>المسار التدفقي سداسي المراحل لخوارزمية الترشيح:</span>
          </h3>
          <span className="text-xs text-slate-400">
            انقر على أي مرحلة لاستعراض فلاترها وتفاصيل تدقيقها
          </span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2.5">
          {STAGES.map((st, idx) => {
            const Icon = st.icon;
            const isActive = activeStage === st.id;
            return (
              <button
                key={st.id}
                onClick={() => setActiveStage(st.id)}
                className={`p-3.5 rounded-2xl text-right transition-all border relative flex flex-col justify-between h-32 ${
                  isActive
                    ? 'bg-slate-800 border-emerald-500 shadow-xl shadow-emerald-500/10 ring-2 ring-emerald-500/20'
                    : 'bg-slate-900/80 border-slate-800 hover:bg-slate-850 hover:border-slate-700'
                }`}
              >
                <div className="flex justify-between items-start w-full">
                  <span className={`w-6 h-6 rounded-lg text-xs font-bold flex items-center justify-center ${
                    isActive ? 'bg-emerald-500 text-slate-950 font-black' : 'bg-slate-800 text-slate-400'
                  }`}>
                    {idx + 1}
                  </span>
                  <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-500'}`} />
                </div>

                <div className="mt-2 space-y-0.5">
                  <span className={`text-xs font-bold block ${isActive ? 'text-white' : 'text-slate-300'}`}>
                    {st.title}
                  </span>
                  <span className="text-[10px] text-slate-400 block line-clamp-2">
                    {st.subtitle}
                  </span>
                </div>

                {isActive && (
                  <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-emerald-400 rounded-full" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* INTERACTIVE LIVE FUNNEL & REAL-TIME STATS BAR */}
      <div className="p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 shadow-lg">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-emerald-400" />
            <h4 className="text-xs font-bold text-white">مؤشر التحويل الحي للأسر وتطبيق الفلاتر (Live Eligibility Funnel):</h4>
          </div>
          <span className="text-[11px] text-emerald-300 font-mono">
            مستوفو الشروط: {pipelineMetrics.exclusionPassedCount} من أصل {pipelineMetrics.total} أسرة
          </span>
        </div>

        {/* Funnel Progress Steps */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 text-xs">
          {/* Step 1 */}
          <div className="p-2.5 rounded-xl bg-slate-850 border border-slate-750 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400">1. إجمالي السجل</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-base font-bold text-white font-mono">{pipelineMetrics.total}</span>
              <span className="text-[10px] text-slate-500">100%</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div className="bg-sky-500 h-full rounded-full w-full" />
            </div>
          </div>

          {/* Step 2 */}
          <div className="p-2.5 rounded-xl bg-slate-850 border border-slate-750 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400">2. اعتماد التنمية</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-base font-bold text-emerald-400 font-mono">{pipelineMetrics.devPassedCount}</span>
              <span className="text-[10px] text-emerald-400/80 font-mono">
                {Math.round((pipelineMetrics.devPassedCount / pipelineMetrics.total) * 100)}%
              </span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${(pipelineMetrics.devPassedCount / pipelineMetrics.total) * 100}%` }}
              />
            </div>
          </div>

          {/* Step 3 */}
          <div className="p-2.5 rounded-xl bg-slate-850 border border-slate-750 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400">3. مطابقة المعايير</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-base font-bold text-indigo-400 font-mono">{pipelineMetrics.criteriaPassedCount}</span>
              <span className="text-[10px] text-indigo-400/80 font-mono">
                {Math.round((pipelineMetrics.criteriaPassedCount / pipelineMetrics.total) * 100)}%
              </span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div
                className="bg-indigo-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${(pipelineMetrics.criteriaPassedCount / pipelineMetrics.total) * 100}%` }}
              />
            </div>
          </div>

          {/* Step 4 */}
          <div className="p-2.5 rounded-xl bg-slate-850 border border-slate-750 flex flex-col justify-between">
            <span className="text-[10px] text-slate-400">4. بعد الاستثناء الزمني</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-base font-bold text-amber-400 font-mono">{pipelineMetrics.exclusionPassedCount}</span>
              <span className="text-[10px] text-amber-400/80 font-mono">
                {Math.round((pipelineMetrics.exclusionPassedCount / pipelineMetrics.total) * 100)}%
              </span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div
                className="bg-amber-500 h-full rounded-full transition-all duration-300"
                style={{ width: `${(pipelineMetrics.exclusionPassedCount / pipelineMetrics.total) * 100}%` }}
              />
            </div>
          </div>

          {/* Step 5 */}
          <div className="p-2.5 rounded-xl bg-gradient-to-br from-emerald-950/40 to-slate-850 border border-emerald-500/40 flex flex-col justify-between">
            <span className="text-[10px] text-emerald-300 font-bold">5. المرشحون المعتمدون</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-base font-bold text-emerald-300 font-mono">{pipelineMetrics.nominatedCount}</span>
              <span className="text-[10px] text-emerald-400 font-bold">الكوتا المطلوبة</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div className="bg-emerald-400 h-full rounded-full w-full" />
            </div>
          </div>
        </div>
      </div>

      {/* TWO COLUMN WORKSPACE: CONTROLS & LIVE RADAR BREAKDOWN */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN (7 COLS): STAGE DRILL-DOWN & FORMULA EXPLAINER */}
        <div className="lg:col-span-7 space-y-5">
          {/* Detailed Stage Content Based on activeStage */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
            {activeStage === 1 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                  <div className="w-8 h-8 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">المرحلة الأولى: مجمع الأسر ومحليات التدخل</h4>
                    <p className="text-[11px] text-slate-400">قاعدة البيانات المركزية لكافة المواطنين والنازحين المحدثة ميدانياً</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-slate-400 block text-[11px]">الأسر في العينة الحالية:</span>
                    <span className="text-lg font-bold text-white font-mono">{INITIAL_FAMILIES.length} أسرة</span>
                    <span className="text-[10px] text-slate-500 block">عينة نموذجية كاملة الخصائص</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-slate-400 block text-[11px]">عدد المحليات المشمولة:</span>
                    <span className="text-lg font-bold text-sky-400 font-mono">5 محليات</span>
                    <span className="text-[10px] text-slate-500 block">شمال، رضوان، شاطئ، عامر</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-slate-400 block text-[11px]">تصنيفات المساعدات:</span>
                    <span className="text-lg font-bold text-emerald-400 font-mono">11 تصنيفاً</span>
                    <span className="text-[10px] text-slate-500 block">من الغذاء حتى المساعدات النقدية</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-slate-850/60 border border-slate-750 space-y-2 text-xs">
                  <span className="font-bold text-slate-200 block text-[11px]">توزيع المحليات ونسب الكوتا الافتراضية:</span>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-[10px]">
                    {INITIAL_LOCALITIES.map(loc => (
                      <div key={loc.id} className="p-2 rounded-xl bg-slate-900 border border-slate-800">
                        <span className="font-bold text-slate-200 block truncate">{loc.name}</span>
                        <span className="text-emerald-400 font-mono font-bold mt-1 block">{loc.percent}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeStage === 2 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">المرحلة الثانية: بوابة الاعتماد الحكومي الإلزامي</h4>
                    <p className="text-[11px] text-slate-400">فحص شرط اعتماد وزارة التنمية الاجتماعية الدائم لضمان النزاهة</p>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/40 text-xs space-y-2 text-slate-200">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>الشرط: اعتماد التنمية = "معتمد" (دائم وإلزامي لكافة الأسر)</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    يتم استبعاد أي أسرة حالتها "غير معتمد" أو "قيد التدقيق" أوتوماتيكياً في أول خطوة من خطوط الأنابيب البرمجية، ولا تمر إلى مرحلة الفلاتر المخصصة نهائياً.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 block text-[11px]">مستوفو اعتماد التنمية:</span>
                      <span className="text-lg font-bold text-emerald-400 font-mono">{pipelineMetrics.devPassedCount} أسرة</span>
                    </div>
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 flex items-center justify-between">
                    <div>
                      <span className="text-slate-400 block text-[11px]">المستبعدون لعدم الاعتماد:</span>
                      <span className="text-lg font-bold text-rose-400 font-mono">{pipelineMetrics.total - pipelineMetrics.devPassedCount} أسرة</span>
                    </div>
                    <XCircle className="w-6 h-6 text-rose-400" />
                  </div>
                </div>
              </div>
            )}

            {activeStage === 3 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                  <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
                    <Filter className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">المرحلة الثالثة: مصفاة المعايير الميدانية المخصصة</h4>
                    <p className="text-[11px] text-slate-400">تخصيص الفلاتر الميدانية بمرونة كاملة لكل مشروع</p>
                  </div>
                </div>

                {/* Filter Controls Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  {/* Children condition */}
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 space-y-2">
                    <label className="text-[11px] font-bold text-slate-200 block">
                      شرط الأطفال وعمر الطفل:
                    </label>
                    <div className="flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => setRequireChildren(!requireChildren)}
                        className={`px-3 py-1.5 rounded-xl font-bold text-xs transition flex-1 ${
                          requireChildren
                            ? 'bg-sky-600 text-white'
                            : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                        }`}
                      >
                        {requireChildren ? '✓ اشتراط أطفال' : 'لا يشترط أطفال'}
                      </button>
                      {requireChildren && (
                        <div className="flex items-center gap-1">
                          <span className="text-[10px] text-slate-400">عمر:</span>
                          <select
                            value={maxChildAge}
                            onChange={(e) => setMaxChildAge(Number(e.target.value))}
                            className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-sky-400 font-bold"
                          >
                            <option value={2}>≤ 2 سنة</option>
                            <option value={5}>≤ 5 سنوات</option>
                            <option value={10}>≤ 10 سنوات</option>
                            <option value={18}>≤ 18 سنة</option>
                          </select>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Shelter filter */}
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 space-y-2">
                    <label className="text-[11px] font-bold text-slate-200 block">
                      حالة الإيواء (داخلي أو خارج الإيواء):
                    </label>
                    <select
                      value={shelterFilter}
                      onChange={(e) => setShelterFilter(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-1.5 text-xs text-slate-200"
                    >
                      <option value="الكل">الكل (إيواء داخلي + خارج الإيواء)</option>
                      <option value="إيواء داخلي">إيواء داخلي فقط</option>
                      <option value="خارج الإيواء">خارج الإيواء فقط (فارغ)</option>
                    </select>
                  </div>

                  {/* Works approval filter */}
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 space-y-2">
                    <label className="text-[11px] font-bold text-slate-200 block">
                      حالة اعتماد الأشغال:
                    </label>
                    <select
                      value={worksFilter}
                      onChange={(e) => setWorksFilter(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-1.5 text-xs text-slate-200"
                    >
                      <option value="الكل">الكل (معتمد أشغال + غير معتمد)</option>
                      <option value="اعتماد أشغال">اعتماد أشغال فقط</option>
                      <option value="غير معتمد">غير معتمد أشغال فقط (فارغ)</option>
                    </select>
                  </div>

                  {/* Damage filter */}
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 space-y-2">
                    <label className="text-[11px] font-bold text-slate-200 block">
                      حالة الضرر:
                    </label>
                    <select
                      value={damageFilter}
                      onChange={(e) => setDamageFilter(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-1.5 text-xs text-slate-200"
                    >
                      <option value="الكل">الكل (جميع درجات الضرر)</option>
                      <option value="أضرار كلية">أضرار كلية فقط</option>
                      <option value="أضرار جزئية بليغة">أضرار جزئية بليغة</option>
                      <option value="أضرار جزئية">أضرار جزئية</option>
                    </select>
                  </div>

                  {/* Min family members */}
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 space-y-2">
                    <label className="text-[11px] font-bold text-slate-200 block">
                      الحد الأدنى لعدد أفراد الأسرة:
                    </label>
                    <select
                      value={minMembers}
                      onChange={(e) => setMinMembers(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-1.5 text-xs text-slate-200"
                    >
                      <option value={1}>أي عدد (أفراد 1+)</option>
                      <option value={4}>4 أفراد فأكثر</option>
                      <option value={6}>6 أفراد فأكثر</option>
                      <option value={8}>8 أفراد فأكثر</option>
                    </select>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 text-xs flex justify-between items-center">
                  <span className="text-slate-300">الأسر المستوفية لهذه المعايير:</span>
                  <span className="font-bold text-indigo-400 font-mono text-sm">
                    {pipelineMetrics.criteriaPassedCount} أسرة
                  </span>
                </div>
              </div>
            )}

            {activeStage === 4 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                  <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">المرحلة الرابعة: مصفوفة الاستثناء الزمني للتصنيفات الـ 11</h4>
                    <p className="text-[11px] text-slate-400">منع الازدواجية والتكرار عبر فحص سجل الاستفادة في كافة التصنيفات</p>
                  </div>
                </div>

                {/* Multi-category select chips */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <label className="text-[11px] font-bold text-slate-200">
                      التصنيفات المفحوصة والمستثناة ({selectedAidIds.length} من {AID_CATEGORIES.length}):
                    </label>
                    <div className="flex gap-2 text-[10px]">
                      <button
                        onClick={() => setSelectedAidIds(AID_CATEGORIES.map(c => c.id))}
                        className="text-emerald-400 hover:underline font-bold"
                      >
                        تحديد الكل
                      </button>
                      <span className="text-slate-600">|</span>
                      <button
                        onClick={() => setSelectedAidIds([1])}
                        className="text-slate-400 hover:underline"
                      >
                        غذائي فقط
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {AID_CATEGORIES.map(cat => {
                      const isSel = selectedAidIds.includes(cat.id);
                      return (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => {
                            if (isSel) {
                              if (selectedAidIds.length > 1) {
                                setSelectedAidIds(selectedAidIds.filter(id => id !== cat.id));
                              }
                            } else {
                              setSelectedAidIds([...selectedAidIds, cat.id]);
                            }
                          }}
                          className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition border ${
                            isSel
                              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm'
                              : 'bg-slate-850 text-slate-400 border-slate-800 hover:bg-slate-800'
                          }`}
                        >
                          {cat.id}. {cat.name}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Exclusion Mode Toggle (Days vs Date) */}
                <div className="p-3.5 rounded-2xl bg-slate-850 border border-slate-750 space-y-3 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-slate-300">طريقة احتساب فترة الاستثناء:</span>
                    <div className="flex bg-slate-900 p-0.5 rounded-xl border border-slate-800">
                      <button
                        onClick={() => setExclusionMode('days')}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                          exclusionMode === 'days' ? 'bg-amber-600 text-white' : 'text-slate-400'
                        }`}
                      >
                        بالأيام (Days)
                      </button>
                      <button
                        onClick={() => setExclusionMode('date')}
                        className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                          exclusionMode === 'date' ? 'bg-amber-600 text-white' : 'text-slate-400'
                        }`}
                      >
                        بتاريخ محدد (Cutoff Date)
                      </button>
                    </div>
                  </div>

                  {exclusionMode === 'days' ? (
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-[11px] text-slate-400">
                        <span>فترة الاستثناء بالأيام:</span>
                        <span className="font-bold text-amber-400 font-mono">{exclusionDays} يوماً</span>
                      </div>
                      <input
                        type="range"
                        min={1}
                        max={180}
                        step={5}
                        value={exclusionDays}
                        onChange={(e) => setExclusionDays(Number(e.target.value))}
                        className="w-full accent-amber-500 cursor-pointer"
                      />
                      <div className="flex justify-between text-[10px] text-slate-500">
                        <span>1 يوم</span>
                        <span>30 يوماً</span>
                        <span>60 يوماً</span>
                        <span>90 يوماً</span>
                        <span>180 يوماً</span>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      <label className="text-[11px] text-slate-400 block">
                        تاريخ الاستثناء (يُستبعد من استلم في أو بعد هذا التاريخ):
                      </label>
                      <input
                        type="date"
                        value={exclusionCutoffDate}
                        onChange={(e) => setExclusionCutoffDate(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-amber-300 font-mono focus:outline-none"
                      />
                    </div>
                  )}
                </div>

                <div className="p-3 rounded-2xl bg-amber-950/20 border border-amber-500/30 text-xs flex justify-between items-center text-amber-300">
                  <span>المستوفون للاستثناء الزمني (المؤهلون للترشيح):</span>
                  <span className="font-bold font-mono text-sm">{pipelineMetrics.exclusionPassedCount} أسرة</span>
                </div>
              </div>
            )}

            {activeStage === 5 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                    <Calculator className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">المرحلة الخامسة: محرك سكور الأولوية وكوتا المحليات</h4>
                    <p className="text-[11px] text-slate-400">احتساب النقاط بالمعادلة المركبة وتوزيع الكوتا بنظام أكبر البواقي</p>
                  </div>
                </div>

                {/* Priority Weights Sliders */}
                <div className="p-3.5 rounded-2xl bg-slate-850 border border-slate-750 space-y-3 text-xs">
                  <span className="font-bold text-slate-200 block text-[11px]">
                    أوزان معادلة الأولوية (تخصيص الأوزان التنافسية):
                  </span>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-300">
                        <span>وزن أفراد الأسرة:</span>
                        <span className="font-bold text-emerald-400 font-mono">{weightFamilySize}x</span>
                      </div>
                      <input
                        type="range"
                        min={1}
                        max={30}
                        value={weightFamilySize}
                        onChange={(e) => setWeightFamilySize(Number(e.target.value))}
                        className="w-full accent-emerald-500"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-300">
                        <span>وزن عدد الأطفال:</span>
                        <span className="font-bold text-sky-400 font-mono">{weightChildren}x</span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={30}
                        value={weightChildren}
                        onChange={(e) => setWeightChildren(Number(e.target.value))}
                        className="w-full accent-sky-500"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-300">
                        <span>وزن شدة الضرر:</span>
                        <span className="font-bold text-rose-400 font-mono">{weightDamage}x</span>
                      </div>
                      <input
                        type="range"
                        min={5}
                        max={50}
                        value={weightDamage}
                        onChange={(e) => setWeightDamage(Number(e.target.value))}
                        className="w-full accent-rose-500"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] text-slate-300">
                        <span>وزن فترة الانقطاع:</span>
                        <span className="font-bold text-amber-400 font-mono">{weightTimeElapsed}x</span>
                      </div>
                      <input
                        type="range"
                        min={5}
                        max={50}
                        value={weightTimeElapsed}
                        onChange={(e) => setWeightTimeElapsed(Number(e.target.value))}
                        className="w-full accent-amber-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Formula Visual Box */}
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-[11px] font-mono space-y-1 text-slate-300 text-center">
                  <span className="text-[10px] text-slate-500 block">المعادلة الرياضية لاحتساب سكور كل أسرة:</span>
                  <div className="text-emerald-400 font-bold text-xs py-1">
                    Score = (الأفراد × {weightFamilySize}) + (الأطفال × {weightChildren}) + (الضرر × {weightDamage}) + (فترة_الانقطاع / 365 × {weightTimeElapsed})
                  </div>
                </div>
              </div>
            )}

            {activeStage === 6 && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
                  <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center">
                    <FileCheck2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">المرحلة السادسة: شاشة الترحيل واعتماد المشروع المنفذ</h4>
                    <p className="text-[11px] text-slate-400">تثبيت بيانات الترحيل والمستودع والجهة المانحة وتحديث السجلات</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-[10px] text-slate-400 block">اسم المشروع (يدوياً):</span>
                    <span className="font-bold text-white block mt-0.5 truncate">مشروع إغاثة المتضررين العاجل</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-[10px] text-slate-400 block">رقم المشروع:</span>
                    <span className="font-bold text-sky-400 font-mono block mt-0.5">PRJ-2026-089</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-[10px] text-slate-400 block">تاريخ الترشيح المجدول:</span>
                    <span className="font-bold text-slate-200 block mt-0.5 font-mono">2026-10-08</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-[10px] text-slate-400 block">تاريخ الترشيح الفعلي:</span>
                    <span className="font-bold text-amber-300 font-mono block mt-0.5">2026-10-08 14:30:00</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-[10px] text-slate-400 block">اسم المستخدم للمراحل:</span>
                    <span className="font-bold text-sky-300 block mt-0.5 truncate">أحمد الشوا - منسق لجان الترشيح</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-[10px] text-slate-400 block">نوع المساعدة:</span>
                    <span className="font-bold text-emerald-400 block mt-0.5">طرد غذائي عائلي طارئ</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-[10px] text-slate-400 block">قيمة المساعدة:</span>
                    <span className="font-bold text-emerald-300 font-mono block mt-0.5">250 ₪</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-[10px] text-slate-400 block">المخزن المنفذ:</span>
                    <span className="font-bold text-slate-200 block mt-0.5">المستودع المركزي - دير البلح</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750">
                    <span className="text-[10px] text-slate-400 block">الجهة الممولة:</span>
                    <span className="font-bold text-slate-200 block mt-0.5">WFP - برنامج الأغذية العالمي</span>
                  </div>
                  <div className="p-3 rounded-2xl bg-slate-850 border border-slate-750 col-span-2 sm:col-span-3">
                    <span className="text-[10px] text-slate-400 block">ملاحظات الترشيح وآلية الأفراد:</span>
                    <span className="text-[11px] text-slate-300 block mt-0.5">
                      يتم تدوين ملاحظات الترشيح يدوياً، مع تصنيف آلية الترشيح لكل شخص كـ (<span className="text-sky-300 font-bold">ترشيح يدوي ✍️</span>) أو (<span className="text-emerald-300 font-bold">ترشيح آلي ⚙️</span>) وتثبيتها بسجلات قاعدة البيانات والتقرير الرسمي.
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-teal-950/20 border border-teal-500/30 text-xs text-teal-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-teal-400" />
                  <span>
                    عند النقر على "اعتماد وترحيل المساعدة رسمياً"، يتم تسجيل قيود الاستحقاق في جدول <code className="font-mono bg-teal-900/50 px-1 rounded">tbl_Aid_Records</code> وتوليد وثيقة التسليم فورياً.
                  </span>
                </div>
              </div>
            )}
          </div>

          {/* HAMILTON LARGEST REMAINDER METHOD MATHEMATICAL TABLE */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3.5 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calculator className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-bold text-white">
                  جدول حساب كوتا المحليات بطريقة أكبر البواقي (Largest Remainder Method):
                </h4>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-400">إجمالي المطلوب:</span>
                <input
                  type="number"
                  min={5}
                  max={25}
                  value={totalRequired}
                  onChange={(e) => setTotalRequired(Math.max(1, Number(e.target.value)))}
                  className="w-16 bg-slate-950 border border-slate-700 rounded-lg p-1 text-xs text-emerald-400 font-mono font-bold text-center"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-[11px] text-slate-400">
                    <th className="pb-2 font-semibold">المحلية</th>
                    <th className="pb-2 font-semibold text-center">النسبة</th>
                    <th className="pb-2 font-semibold text-center">الحصة الدقيقة</th>
                    <th className="pb-2 font-semibold text-center">الحصة الصحيحة</th>
                    <th className="pb-2 font-semibold text-center">الكسر الباقي</th>
                    <th className="pb-2 font-semibold text-center text-emerald-400">الكوتا المعتمدة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {localityQuotas.map(item => (
                    <tr key={item.id} className="hover:bg-slate-850/50">
                      <td className="py-2 font-sans font-bold text-slate-200">{item.name}</td>
                      <td className="py-2 text-center text-slate-400">{item.percent}%</td>
                      <td className="py-2 text-center text-slate-300">{item.exact}</td>
                      <td className="py-2 text-center text-slate-400">{item.floor}</td>
                      <td className="py-2 text-center">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] ${
                          item.hasBonus ? 'bg-emerald-500/20 text-emerald-300 font-bold' : 'text-slate-500'
                        }`}>
                          {item.remainder} {item.hasBonus ? '(+1)' : ''}
                        </span>
                      </td>
                      <td className="py-2 text-center font-bold text-emerald-400 text-xs">
                        {item.allocated} أسرة
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN (5 COLS): CANDIDATE RADAR, DETAILED BREAKDOWN & BENEFIT MATRIX */}
        <div className="lg:col-span-5 space-y-5">
          {/* Top: Candidate Score Radar & Mathematical Breakdown Card */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-bold text-white">محلل بطاقة المرشح وتفاصيل السكور:</h4>
              </div>
              <span className="text-[10px] text-slate-400">انقر على أي أسرة أدناه للمعاينة</span>
            </div>

            {/* Selected Family Quick Selector */}
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">اختر أسرة لفحص معادلة أولوية ترشيحها:</label>
              <select
                value={selectedFamilyId}
                onChange={(e) => setSelectedFamilyId(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-750 rounded-xl p-2 text-xs text-white font-bold focus:outline-none"
              >
                {INITIAL_FAMILIES.map(f => (
                  <option key={f.familyID} value={f.familyID}>
                    {f.name} ({f.membersCount} أفراد - {f.damageType})
                  </option>
                ))}
              </select>
            </div>

            {/* Score Breakdown Bars */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex justify-between items-baseline">
                <span className="text-xs font-bold text-white">{selectedFamilyData.family.name}</span>
                <span className="text-base font-black text-emerald-400 font-mono">
                  {selectedFamilyData.totalScore} نقطة
                </span>
              </div>

              {/* Bar 1: Family Size */}
              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between text-slate-400">
                  <span>حجم الأسرة ({selectedFamilyData.family.membersCount} أفراد × {weightFamilySize}):</span>
                  <span className="font-bold text-emerald-400 font-mono">+{selectedFamilyData.sizeScore}</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full"
                    style={{ width: `${Math.min(100, (selectedFamilyData.sizeScore / 150) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Bar 2: Children */}
              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between text-slate-400">
                  <span>الأطفال ({selectedFamilyData.childrenCount} أطفال × {weightChildren}):</span>
                  <span className="font-bold text-sky-400 font-mono">+{selectedFamilyData.childScore}</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-sky-500 h-full rounded-full"
                    style={{ width: `${Math.min(100, (selectedFamilyData.childScore / 100) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Bar 3: Damage Severity */}
              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between text-slate-400">
                  <span>شدة الضرر ({selectedFamilyData.family.damageType}):</span>
                  <span className="font-bold text-rose-400 font-mono">+{selectedFamilyData.damageScore}</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-rose-500 h-full rounded-full"
                    style={{ width: `${Math.min(100, (selectedFamilyData.damageScore / 50) * 100)}%` }}
                  />
                </div>
              </div>

              {/* Bar 4: Time Elapsed */}
              <div className="space-y-1 text-[11px]">
                <div className="flex justify-between text-slate-400">
                  <span>فترة الانقطاع عن المساعدات:</span>
                  <span className="font-bold text-amber-400 font-mono">+{selectedFamilyData.timeScore.toFixed(1)}</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-500 h-full rounded-full"
                    style={{ width: `${Math.min(100, (selectedFamilyData.timeScore / 50) * 100)}%` }}
                  />
                </div>
              </div>
            </div>

            {/* 11 CATEGORIES BENEFIT HEATMAP FOR SELECTED FAMILY */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold text-slate-300 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-amber-400" />
                <span>سجل استفادة الأسرة في كافة الـ 11 تصنيفاً:</span>
              </span>

              <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                {AID_CATEGORIES.map(cat => {
                  const familyRecs = INITIAL_FAMILY_BENEFITS[selectedFamilyData.family.familyID] || {};
                  const rec = familyRecs[cat.id];
                  return (
                    <div
                      key={cat.id}
                      className={`p-2 rounded-xl border flex flex-col justify-between ${
                        rec && rec.date
                          ? 'bg-emerald-950/30 border-emerald-500/40 text-slate-200'
                          : 'bg-slate-950/60 border-slate-800/80 text-slate-500'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-semibold truncate">{cat.id}. {cat.name}</span>
                        {rec && rec.date && (
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        )}
                      </div>
                      <span className="font-mono pt-1 text-[9px]">
                        {rec && rec.date ? `🗓️ ${rec.date}` : 'لم يستفد قط'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Top Ranked Candidates List under Current Settings */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 space-y-3.5 shadow-xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>المرشحون الأوائل حسب الترتيب الحالي ({pipelineMetrics.finalNominated.length}):</span>
              </h4>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                كوتا: {totalRequired}
              </span>
            </div>

            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {pipelineMetrics.finalNominated.map((cand, idx) => (
                <div
                  key={cand.family.familyID}
                  onClick={() => setSelectedFamilyId(cand.family.familyID)}
                  className={`p-2.5 rounded-xl border cursor-pointer transition flex items-center justify-between text-xs ${
                    selectedFamilyId === cand.family.familyID
                      ? 'bg-slate-800 border-emerald-500 shadow-md ring-1 ring-emerald-500/30'
                      : 'bg-slate-950/70 border-slate-800 hover:bg-slate-850'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-5 h-5 rounded-md bg-slate-800 text-slate-300 font-bold text-[10px] flex items-center justify-center font-mono">
                      {idx + 1}
                    </span>
                    <div className="min-w-0">
                      <span className="font-bold text-white block truncate">{cand.family.name}</span>
                      <span className="text-[10px] text-slate-400 block">
                        {cand.family.membersCount} أفراد • {cand.family.localityName} • {cand.family.damageType}
                      </span>
                    </div>
                  </div>

                  <div className="text-left shrink-0">
                    <span className="font-mono font-bold text-emerald-400 text-xs block">
                      {cand.totalScore}
                    </span>
                    <span className="text-[9px] text-slate-500 block">نقطة</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
