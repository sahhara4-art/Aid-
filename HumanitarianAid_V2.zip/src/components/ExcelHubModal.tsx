import React, { useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  Upload,
  Download,
  Calendar,
  Filter,
  CheckCircle2,
  AlertCircle,
  X,
  Users,
  Baby,
  PackageCheck,
  FileText,
  Sparkles,
  Layers,
  ArrowRight,
  Database,
  SlidersHorizontal,
  RefreshCw,
  Check,
  Clock,
  Play,
  HelpCircle,
  AlertTriangle
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { MockFamily, MockChild, DeliveryRecord } from './AndroidEmulator';

interface ExcelHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  familiesList: MockFamily[];
  setFamiliesList: React.Dispatch<React.SetStateAction<MockFamily[]>>;
  deliveryRecords: DeliveryRecord[];
  setDeliveryRecords: React.Dispatch<React.SetStateAction<DeliveryRecord[]>>;
  childrenList: MockChild[];
  setChildrenList: React.Dispatch<React.SetStateAction<MockChild[]>>;
}

interface SystemFieldDef {
  key: string;
  label: string;
  isRequired: boolean;
  description: string;
  autoMatchKeywords: string[];
}

const FAMILY_SYSTEM_FIELDS: SystemFieldDef[] = [
  { key: 'nationalID', label: 'رقم الهوية الوطنية', isRequired: true, description: 'رقم هوية رب الأسرة (9 أرقام)', autoMatchKeywords: ['nationalid', 'national_id', 'هوية', 'رقم الهوية', 'الهوية', 'id', 'رقم_الهوية', 'بطاقة', 'رقم هوية رب الاسرة'] },
  { key: 'name', label: 'اسم المستفيد الرباعي', isRequired: true, description: 'الاسم الكامل لرب الأسرة', autoMatchKeywords: ['name', 'fullname', 'الاسم', 'اسم المستفيد', 'الاسم رباعي', 'رب الأسرة', 'اسم_المستفيد', 'الاسم كاملا'] },
  { key: 'membersCount', label: 'عدد أفراد الأسرة', isRequired: false, description: 'إجمالي عدد أفراد الأسرة', autoMatchKeywords: ['members', 'memberscount', 'عدد الأفراد', 'عدد الافراد', 'الأفراد', 'العدد', 'عدد_الأفراد', 'حجم الاسرة'] },
  { key: 'primaryPhone', label: 'رقم الجوال للتواصل', isRequired: false, description: 'رقم الهاتف المحمول الأساسي', autoMatchKeywords: ['phone', 'primaryphone', 'جوال', 'رقم الجوال', 'الهاتف', 'موبايل', 'رقم_الجوال', 'رقم الهاتف'] },
  { key: 'currentSubArea', label: 'المحلية / الحي / المخيم', isRequired: false, description: 'مكان السكن أو المخيم الميداني الحالي', autoMatchKeywords: ['locality', 'subarea', 'المحلية', 'الحي', 'المنطقة', 'المخيم', 'المنطقة الفرعية', 'المحافظة', 'السكن'] },
  { key: 'shelterStatus', label: 'حالة الإيواء', isRequired: false, description: 'إيواء داخلي / مركز إيواء / خيمة / خارج الإيواء', autoMatchKeywords: ['shelter', 'shelterstatus', 'حالة الإيواء', 'الإيواء', 'مركز الإيواء', 'حالة_الإيواء', 'نوع المأوى'] },
  { key: 'damageType', label: 'حالة أو نوع الضرر', isRequired: false, description: 'أضرار كلية / جزئية بليغة / طفيفة / غير متضرر', autoMatchKeywords: ['damage', 'damagetype', 'حالة الضرر', 'الضرر', 'نوع الضرر', 'حجم الضرر'] },
  { key: 'wifeName', label: 'اسم الزوج/الزوجة', isRequired: false, description: 'اسم الزوجة الرباعي', autoMatchKeywords: ['wifename', 'wife_name', 'اسم الزوجة', 'الزوجة', 'اسم الزوج'] },
  { key: 'wifeNationalID', label: 'رقم هوية الزوج/الزوجة', isRequired: false, description: 'رقم هوية الزوجة (9 أرقام)', autoMatchKeywords: ['wifenationalid', 'wife_id', 'هوية الزوجة', 'رقم هوية الزوجة'] },
  { key: 'birthDate', label: 'تاريخ الميلاد', isRequired: false, description: 'تاريخ ميلاد رب الأسرة (YYYY-MM-DD)', autoMatchKeywords: ['birthdate', 'birth_date', 'تاريخ الميلاد', 'الميلاد', 'سنة الميلاد'] },
  { key: 'notes', label: 'ملاحظات ميدانية', isRequired: false, description: 'أي شروط أو تفاصيل إضافية', autoMatchKeywords: ['notes', 'ملاحظات', 'الملاحظات', 'بيان', 'ملاحظة'] }
];

const AID_RECORD_SYSTEM_FIELDS: SystemFieldDef[] = [
  { key: 'familyNationalID', label: 'رقم هوية المستفيد', isRequired: true, description: 'رقم هوية رب الأسرة المستفيدة', autoMatchKeywords: ['familynationalid', 'nationalid', 'هوية', 'رقم الهوية', 'الهوية', 'id'] },
  { key: 'aidTypeName', label: 'نوع أو تصنيف المساعدة', isRequired: true, description: 'سلة غذائية / نقدية / طرود صحية / كسوة...', autoMatchKeywords: ['aidtypename', 'aidtype', 'نوع المساعدة', 'المساعدة', 'نوع_المساعدة', 'التصنيف', 'نوع المعونة'] },
  { key: 'projectName', label: 'اسم المشروع الإغاثي', isRequired: false, description: 'اسم المنحة أو المشروع والجهة المانحة', autoMatchKeywords: ['projectname', 'project', 'المشروع', 'اسم المشروع', 'المانح', 'المشروع الإغاثي'] },
  { key: 'deliveryDate', label: 'تاريخ الصرف والتسليم', isRequired: false, description: 'تاريخ الاستلام الفعلي', autoMatchKeywords: ['date', 'aiddate', 'التاريخ', 'تاريخ الصرف', 'تاريخ التسليم', 'تاريخ الاستلام'] },
  { key: 'warehouse', label: 'نقطة التوزيع أو المستودع', isRequired: false, description: 'مستودع أو نقطة الصرف الميداني', autoMatchKeywords: ['warehouse', 'المستودع', 'نقطة التوزيع', 'نقطة الصرف', 'المركز'] },
  { key: 'status', label: 'حالة الاستلام', isRequired: false, description: 'مستلم / بانتظار الصرف', autoMatchKeywords: ['status', 'recipientstatus', 'حالة الاستلام', 'الحالة', 'وضع الاستلام'] }
];

const CHILD_SYSTEM_FIELDS: SystemFieldDef[] = [
  { key: 'childNationalID', label: 'رقم هوية الطفل/التابع', isRequired: true, description: 'رقم هوية الطفل (9 أرقام)', autoMatchKeywords: ['childnationalid', 'هوية الطفل', 'رقم هوية الطفل', 'هوية التابع', 'رقم هوية الابن'] },
  { key: 'childName', label: 'اسم الطفل الرباعي', isRequired: true, description: 'اسم الطفل أو التابع كاملاً', autoMatchKeywords: ['childname', 'اسم الطفل', 'اسم التابع', 'الاسم', 'اسم الابن'] },
  { key: 'parentNationalID', label: 'رقم هوية رب الأسرة/المعيل', isRequired: true, description: 'رقم هوية المعيل التابع له', autoMatchKeywords: ['parentnationalid', 'familynationalid', 'هوية الأسرة', 'هوية المعيل', 'هوية الأب', 'هوية رب الأسرة'] },
  { key: 'birthDate', label: 'تاريخ ميلاد الطفل', isRequired: false, description: 'تاريخ الميلاد (YYYY-MM-DD)', autoMatchKeywords: ['birthdate', 'تاريخ الميلاد', 'الميلاد', 'عمر الطفل'] },
  { key: 'gender', label: 'الجنس (ذكر / أنثى)', isRequired: false, description: 'ذكر أو أنثى', autoMatchKeywords: ['gender', 'الجنس', 'نوع الجنس'] }
];

function detectBestMatch(field: SystemFieldDef, headers: string[]): string {
  const cleanHeader = (s: string) => s.trim().toLowerCase().replace(/[\s_\-–]/g, '');
  for (const kw of field.autoMatchKeywords) {
    const target = cleanHeader(kw);
    const found = headers.find(h => {
      const c = cleanHeader(h);
      return c === target || c.includes(target) || target.includes(c);
    });
    if (found) return found;
  }
  return '';
}

export function ExcelHubModal({
  isOpen,
  onClose,
  familiesList,
  setFamiliesList,
  deliveryRecords,
  setDeliveryRecords,
  childrenList,
  setChildrenList
}: ExcelHubModalProps) {
  if (!isOpen) return null;

  const [activeTab, setActiveTab] = useState<'export' | 'import_families' | 'import_aid' | 'import_children'>('export');

  // فلاتر التصدير حسب الفترة
  const [startDate, setStartDate] = useState('2026-01-01');
  const [endDate, setEndDate] = useState('2026-10-14');
  const [selectedLocality, setSelectedLocality] = useState('الكل');
  const [selectedAidCategory, setSelectedAidCategory] = useState('الكل');
  const [selectedGroup, setSelectedGroup] = useState('كافة المجموعات');

  // رسائل الحالة والعمليات
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // بيانات الاستيراد والمطابقة
  const [parsedRows, setParsedRows] = useState<any[]>([]);
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
  const [detectedHeaders, setDetectedHeaders] = useState<string[]>([]);
  const [fieldMappings, setFieldMappings] = useState<Record<string, string>>({});
  
  // معالجة المكرر (تحديث مقابل تخطي)
  const [duplicateHandlingMode, setDuplicateHandlingMode] = useState<'update' | 'skip'>('update');

  // حالة الاستيراد غير المتزامن والتقدم
  const [isImporting, setIsImporting] = useState(false);
  const [importProgressPct, setImportProgressPct] = useState(0);
  const [importCurrentCount, setImportCurrentCount] = useState(0);
  const [importTotalCount, setImportTotalCount] = useState(0);
  const [showProgressModal, setShowProgressModal] = useState(false);
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [summaryStats, setSummaryStats] = useState<{
    total: number;
    inserted: number;
    updated: number;
    skipped: number;
    failed: number;
    title: string;
  } | null>(null);

  const LOCALITY_OPTIONS = [
    'الكل',
    'غزة - الرمال والشاطئ',
    'شمال غزة - جباليا وبيت لاهيا',
    'المحافظة الوسطى - دير البلح والبريج',
    'خان يونس - البلد والكتيبة',
    'رفح - تل السلطان والمخيم'
  ];

  const AID_CATEGORIES = [
    'الكل',
    'سلات غذائية وطعام ساخن',
    'مساعدات مالية ونقدية عاجلة',
    'طرود صحية ومستلزمات نظافة',
    'شوادر وخيام إيواء شتوية',
    'كسوة وملابس شتوية',
    'مستلزمات أطفال ورضع'
  ];

  const GROUPS_OPTIONS = [
    'كافة المجموعات',
    'مجموعة الشمال أ (إغاثة عاجلة)',
    'مجموعة مدينة غزة ب (توزيع رئيسي)',
    'مجموعة الوسطى ودير البلح ج (إيواء)',
    'مجموعة خان يونس د (ميداني)',
    'مجموعة رفح هـ (مخيمات)',
    'فريق الإسناد والطوارئ و'
  ];

  // الحقول المستهدفة حسب التبويب النشط
  const currentTargetFields = useMemo(() => {
    switch (activeTab) {
      case 'import_families':
        return FAMILY_SYSTEM_FIELDS;
      case 'import_aid':
        return AID_RECORD_SYSTEM_FIELDS;
      case 'import_children':
        return CHILD_SYSTEM_FIELDS;
      default:
        return [];
    }
  }, [activeTab]);

  // تشغيل المطابقة التلقائية الذكية عند توفر ملف وترويسات
  const autoMapFields = (headers: string[], fields: SystemFieldDef[]) => {
    const newMap: Record<string, string> = {};
    fields.forEach(f => {
      const best = detectBestMatch(f, headers);
      if (best) {
        newMap[f.key] = best;
      }
    });
    setFieldMappings(newMap);
  };

  // ================= 1. تصدير ملف الإكسل مع تحديد الفترة =================
  const handleExportExcelWithPeriod = () => {
    try {
      const filteredRecords = deliveryRecords.filter(record => {
        const recordDate = record.deliveryDate || record.dueDistributionDate || '2026-10-14';
        const dateMatch = recordDate >= startDate && recordDate <= endDate;
        const categoryMatch = selectedAidCategory === 'الكل' || record.aidTypeName === selectedAidCategory;
        const localityMatch = selectedLocality === 'الكل' ||
          (record.family?.localityName && record.family.localityName.includes(selectedLocality)) ||
          (record.family?.currentMainArea && record.family.currentMainArea.includes(selectedLocality));
        return dateMatch && categoryMatch && localityMatch;
      });

      if (filteredRecords.length === 0) {
        setStatusMessage({
          type: 'error',
          text: 'لم يتم العثور على أي سجلات مطابقة للفترة المحددة والفلاتر المختارة.'
        });
        return;
      }

      const rowsForExcel = filteredRecords.map((r, index) => ({
        'م': index + 1,
        'رقم السجل': r.id,
        'رقم المشروع': r.projectNumber,
        'اسم المشروع': r.projectName,
        'نوع المعونة': r.aidTypeName,
        'القيمة (شيكل)': r.aidValue,
        'تاريخ التسليم الميداني': r.deliveryDate || r.dueDistributionDate,
        'وقت التسليم': r.deliveryTime || '10:00',
        'اسم المستفيد': r.family?.name || r.receiverName,
        'رقم الهوية الوطنية': r.family?.nationalID || r.receiverNationalId,
        'رقم الهاتف المحمول': r.family?.primaryPhone || '0590000000',
        'عدد أفراد الأسرة': r.family?.membersCount || 5,
        'المحافظة والمنطقة': r.family?.localityName || r.family?.currentMainArea || 'قطاع غزة',
        'حالة الإيواء': r.family?.shelterStatus || 'إيواء داخلي',
        'حالة الضرر': r.family?.damageType || 'أضرار كلية',
        'نقطة التوزيع / المستودع': r.warehouse,
        'اسم المانح': r.fundingOrg,
        'حالة الاستلام': r.status,
        'صفة المستلم': r.receiverType,
        'اسم الموزع الميداني': r.deliveredByStaff,
        'ملاحظات الصرف': r.deliveryNotes || ''
      }));

      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(rowsForExcel);

      ws['!cols'] = [
        { wch: 5 }, { wch: 16 }, { wch: 14 }, { wch: 25 }, { wch: 22 },
        { wch: 12 }, { wch: 16 }, { wch: 10 }, { wch: 25 }, { wch: 16 },
        { wch: 16 }, { wch: 12 }, { wch: 22 }, { wch: 16 }, { wch: 16 },
        { wch: 20 }, { wch: 20 }, { wch: 14 }, { wch: 16 }, { wch: 18 }, { wch: 25 }
      ];

      XLSX.utils.book_append_sheet(wb, ws, 'كشف المساعدات الميدانية');
      const filename = `Aid_Distribution_Report_${startDate}_to_${endDate}.xlsx`;
      XLSX.writeFile(wb, filename);

      setStatusMessage({
        type: 'success',
        text: `✅ تم تصدير ${filteredRecords.length} سجل بنجاح إلى ملف "${filename}".`
      });
    } catch (err: any) {
      setStatusMessage({
        type: 'error',
        text: `حدث خطأ أثناء تصدير ملف الإكسل: ${err.message}`
      });
    }
  };

  // ================= 2. قراءة ملف إكسل من جهاز المستخدم =================
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    const reader = new FileReader();

    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data: any[] = XLSX.utils.sheet_to_json(ws);

        if (data.length === 0) {
          setStatusMessage({ type: 'error', text: 'الملف المرفوع فارغ ولا يحتوي على صفوف بيانات صالحة.' });
          return;
        }

        const headers = Object.keys(data[0] || {});
        setDetectedHeaders(headers);
        setParsedRows(data);
        autoMapFields(headers, currentTargetFields);

        setStatusMessage({
          type: 'info',
          text: `تمت قراءة ${data.length} سجل بنجاح من ملف "${file.name}". يرجى التحقق من مطابقة الحقول أدناه ثم بدء الاستيراد.`
        });
      } catch (err: any) {
        setStatusMessage({ type: 'error', text: `فشل تحليل ملف الإكسل: ${err.message}` });
      }
    };

    reader.readAsBinaryString(file);
  };

  // تحميل نماذج جاهزة
  const loadPresetSample = (type: 'families' | 'aid' | 'children') => {
    if (type === 'families') {
      const sample = [
        { 'رقم الهوية': '901234567', 'الاسم رباعي': 'إبراهيم يوسف خليل الزهار', 'عدد الأفراد': 7, 'المحافظة': 'غزة - الرمال', 'رقم الهاتف': '0599112233', 'حالة الإيواء': 'إيواء داخلي', 'نوع الضرر': 'أضرار كلية', 'اسم الزوجة': 'منى خليل الزهار', 'رقم هوية الزوجة': '901234568', 'تاريخ الميلاد': '1982-05-14', 'ملاحظات': 'عائلة شهيد' },
        { 'رقم الهوية': '912345678', 'الاسم رباعي': 'خالد ناصر محمود رضوان', 'عدد الأفراد': 5, 'المحافظة': 'شمال غزة - جباليا', 'رقم الهاتف': '0599223344', 'حالة الإيواء': 'إيواء داخلي', 'نوع الضرر': 'أضرار جزئية بليغة', 'اسم الزوجة': 'فاطمة محمود رضوان', 'رقم هوية الزوجة': '912345679', 'تاريخ الميلاد': '1986-11-20', 'ملاحظات': 'منزل مدمر جزئياً' },
        { 'رقم الهوية': '923456789', 'الاسم رباعي': 'أحمد صلاح مصطفى الأسطل', 'عدد الأفراد': 8, 'المحافظة': 'خان يونس - السطر', 'رقم الهاتف': '0599334455', 'حالة الإيواء': 'إيواء داخلي', 'نوع الضرر': 'أضرار كلية', 'اسم الزوجة': 'سعاد أحمد الأسطل', 'رقم هوية الزوجة': '923456780', 'تاريخ الميلاد': '1979-02-10', 'ملاحظات': 'أسرة أيتام' },
        { 'رقم الهوية': '934567890', 'الاسم رباعي': 'صابر حسني عبد الله بربخ', 'عدد الأفراد': 6, 'المحافظة': 'رفح - تل السلطان', 'رقم الهاتف': '0599445566', 'حالة الإيواء': 'خارج الإيواء', 'نوع الضرر': 'أضرار كلية', 'اسم الزوجة': 'ريم حسني بربخ', 'رقم هوية الزوجة': '934567891', 'تاريخ الميلاد': '1988-08-30', 'ملاحظات': 'نازح في خيمة' },
        { 'رقم الهوية': '945678901', 'الاسم رباعي': 'منى فؤاد شكري المصري', 'عدد الأفراد': 4, 'المحافظة': 'المحافظة الوسطى - النصيرات', 'رقم الهاتف': '0599556677', 'حالة الإيواء': 'إيواء داخلي', 'نوع الضرر': 'أضرار جزئية بليغة', 'اسم الزوجة': '', 'رقم هوية الزوجة': '', 'تاريخ الميلاد': '1990-12-05', 'ملاحظات': 'معيلة أسرة' }
      ];
      setParsedRows(sample);
      const headers = Object.keys(sample[0]);
      setDetectedHeaders(headers);
      setUploadedFileName('Palestinian_Beneficiary_Families_Sample.xlsx');
      autoMapFields(headers, FAMILY_SYSTEM_FIELDS);
      setStatusMessage({ type: 'info', text: 'تم تحميل نموذج كشف الأسر الفلسطينية المعتمد ومطابقة الحقول تلقائياً.' });
    } else if (type === 'aid') {
      const sample = [
        { 'رقم الهوية': '901234567', 'اسم المستفيد': 'إبراهيم يوسف الزهار', 'نوع المعونة': 'سلات غذائية وطعام ساخن', 'المشروع': 'مشروع الإغاثة العاجلة', 'تاريخ التسليم': '2026-10-12', 'المستودع': 'مستودع الرمال', 'الحالة': 'تم التسليم' },
        { 'رقم الهوية': '912345678', 'اسم المستفيد': 'خالد ناصر رضوان', 'نوع المعونة': 'مساعدات مالية ونقدية عاجلة', 'المشروع': 'منحة الإغاثة النقدية', 'تاريخ التسليم': '2026-10-13', 'المستودع': 'مستودع جباليا', 'الحالة': 'تم التسليم' },
        { 'رقم الهوية': '923456789', 'اسم المستفيد': 'أحمد صلاح الأسطل', 'نوع المعونة': 'شوادر وخيام إيواء شتوية', 'المشروع': 'مشروع الإيواء الشتوي', 'تاريخ التسليم': '2026-10-14', 'المستودع': 'مستودع خان يونس', 'الحالة': 'تم التسليم' }
      ];
      setParsedRows(sample);
      const headers = Object.keys(sample[0]);
      setDetectedHeaders(headers);
      setUploadedFileName('Aid_Distribution_Log_Sample.xlsx');
      autoMapFields(headers, AID_RECORD_SYSTEM_FIELDS);
      setStatusMessage({ type: 'info', text: 'تم تحميل نموذج كشف تسليم المساعدات ومطابقة الحقول تلقائياً.' });
    } else {
      const sample = [
        { 'رقم هوية الطفل': '411223344', 'اسم الطفل': 'يوسف إبراهيم الزهار', 'تاريخ الميلاد': '2019-04-12', 'الجنس': 'ذكر', 'هوية المعيل': '901234567' },
        { 'رقم هوية الطفل': '422334455', 'اسم الطفل': 'مريم إبراهيم الزهار', 'تاريخ الميلاد': '2021-08-20', 'الجنس': 'أنثى', 'هوية المعيل': '901234567' },
        { 'رقم هوية الطفل': '433445566', 'اسم الطفل': 'سارة خالد رضوان', 'تاريخ الميلاد': '2018-11-05', 'الجنس': 'أنثى', 'هوية المعيل': '912345678' }
      ];
      setParsedRows(sample);
      const headers = Object.keys(sample[0]);
      setDetectedHeaders(headers);
      setUploadedFileName('Children_Registry_Sample.xlsx');
      autoMapFields(headers, CHILD_SYSTEM_FIELDS);
      setStatusMessage({ type: 'info', text: 'تم تحميل نموذج كشف الأطفال والتابعين ومطابقة الحقول تلقائياً.' });
    }
  };

  // التحقق من تعيين الحقول الإلزامية
  const areRequiredFieldsMapped = useMemo(() => {
    const required = currentTargetFields.filter(f => f.isRequired);
    return required.every(f => fieldMappings[f.key] && fieldMappings[f.key].trim() !== '');
  }, [currentTargetFields, fieldMappings]);

  // ================= 3. آلية الاستيراد بالدفعات غير المتزامنة مع نسبة الإنجاز =================
  const handleStartNonBlockingImport = async () => {
    if (parsedRows.length === 0 || !areRequiredFieldsMapped) return;

    setIsImporting(true);
    setShowProgressModal(true);
    setImportProgressPct(0);
    setImportCurrentCount(0);
    setImportTotalCount(parsedRows.length);

    const total = parsedRows.length;
    let inserted = 0;
    let updated = 0;
    let skipped = 0;
    let failed = 0;
    const errors: string[] = [];

    // معالجة بالدفعات (Chunking) لتفادي أي تجميد أو تعليق في واجهة المستخدم
    const BATCH_SIZE = 25;
    const totalBatches = Math.ceil(total / BATCH_SIZE);

    if (activeTab === 'import_families') {
      let currentFamilies = [...familiesList];

      for (let b = 0; b < totalBatches; b++) {
        const start = b * BATCH_SIZE;
        const end = Math.min(start + BATCH_SIZE, total);
        const batch = parsedRows.slice(start, end);

        for (let i = 0; i < batch.length; i++) {
          const r = batch[i];
          const globalIndex = start + i;

          try {
            const rawId = String(r[fieldMappings['nationalID']] || '').trim();
            const rawName = String(r[fieldMappings['name']] || '').trim();

            if (!rawId) {
              failed++;
              errors.push(`صف ${globalIndex + 1}: رقم الهوية فارغ`);
              continue;
            }

            const existingIdx = currentFamilies.findIndex(f => f.nationalID === rawId);

            if (existingIdx !== -1) {
              if (duplicateHandlingMode === 'update') {
                const old = currentFamilies[existingIdx];
                currentFamilies[existingIdx] = {
                  ...old,
                  name: rawName || old.name,
                  membersCount: fieldMappings['membersCount'] && r[fieldMappings['membersCount']] ? Number(r[fieldMappings['membersCount']]) : old.membersCount,
                  primaryPhone: fieldMappings['primaryPhone'] && r[fieldMappings['primaryPhone']] ? String(r[fieldMappings['primaryPhone']]) : old.primaryPhone,
                  currentSubArea: fieldMappings['currentSubArea'] && r[fieldMappings['currentSubArea']] ? String(r[fieldMappings['currentSubArea']]) : old.currentSubArea,
                  shelterStatus: fieldMappings['shelterStatus'] && r[fieldMappings['shelterStatus']] ? String(r[fieldMappings['shelterStatus']]) : old.shelterStatus,
                  damageType: fieldMappings['damageType'] && r[fieldMappings['damageType']] ? String(r[fieldMappings['damageType']]) : old.damageType,
                  wifeName: fieldMappings['wifeName'] && r[fieldMappings['wifeName']] ? String(r[fieldMappings['wifeName']]) : old.wifeName,
                  wifeNationalID: fieldMappings['wifeNationalID'] && r[fieldMappings['wifeNationalID']] ? String(r[fieldMappings['wifeNationalID']]) : old.wifeNationalID,
                  birthDate: fieldMappings['birthDate'] && r[fieldMappings['birthDate']] ? String(r[fieldMappings['birthDate']]) : old.birthDate,
                  notes: fieldMappings['notes'] && r[fieldMappings['notes']] ? String(r[fieldMappings['notes']]) : old.notes
                };
                updated++;
              } else {
                skipped++;
              }
            } else {
              const newFam: MockFamily = {
                familyID: currentFamilies.length + inserted + 100,
                nationalID: rawId,
                name: rawName || 'مستفيد مستورد',
                gender: 'ذكر',
                birthDate: fieldMappings['birthDate'] && r[fieldMappings['birthDate']] ? String(r[fieldMappings['birthDate']]) : '1985-01-01',
                age: 40,
                maritalStatus: 'متزوج',
                deathStatus: 'على قيد الحياة',
                primaryPhone: fieldMappings['primaryPhone'] && r[fieldMappings['primaryPhone']] ? String(r[fieldMappings['primaryPhone']]) : '0599000000',
                wifeName: fieldMappings['wifeName'] && r[fieldMappings['wifeName']] ? String(r[fieldMappings['wifeName']]) : '',
                wifeNationalID: fieldMappings['wifeNationalID'] && r[fieldMappings['wifeNationalID']] ? String(r[fieldMappings['wifeNationalID']]) : '',
                membersCount: fieldMappings['membersCount'] && r[fieldMappings['membersCount']] ? Number(r[fieldMappings['membersCount']]) : 5,
                damageType: fieldMappings['damageType'] && r[fieldMappings['damageType']] ? String(r[fieldMappings['damageType']]) : 'أضرار كلية',
                injuryStatus: 'لا يوجد',
                incomeSource1: 'لا يعمل',
                rationCardNumber: `RC-${Date.now()}-${inserted}`,
                originalMainArea: 'محافظة غزة',
                originalSubArea: 'الرمال الشمالي',
                originalBranch: 'شعبة 1',
                originalMosque: 'المسجد العمري',
                currentMainArea: 'غزة',
                currentSubArea: fieldMappings['currentSubArea'] && r[fieldMappings['currentSubArea']] ? String(r[fieldMappings['currentSubArea']]) : 'الرمال الشمالي',
                currentBranch: 'شعبة 1',
                currentMosque: 'مسجد الكنز',
                developmentApproval: 'معتمد',
                localityApproval: 'معتمد',
                residentStatus: 'نازح',
                worksApproval: 'معتمد أشغال',
                shelterStatus: fieldMappings['shelterStatus'] && r[fieldMappings['shelterStatus']] ? String(r[fieldMappings['shelterStatus']]) : 'إيواء داخلي',
                localityID: 1,
                localityName: 'مدينة غزة',
                notes: fieldMappings['notes'] && r[fieldMappings['notes']] ? String(r[fieldMappings['notes']]) : ''
              };
              currentFamilies.unshift(newFam);
              inserted++;
            }
          } catch (e: any) {
            failed++;
            errors.push(`خطأ في صف ${globalIndex + 1}: ${e.message}`);
          }
        }

        const currentDone = end;
        setImportCurrentCount(currentDone);
        setImportProgressPct(Math.round((currentDone / total) * 100));

        // السماح للواجهة بالرسم لمنع أي تعليق أو تجميد
        await new Promise(res => setTimeout(res, 20));
      }

      setFamiliesList(currentFamilies);
      setSummaryStats({
        title: 'استيراد كشف بيانات الأسر',
        total,
        inserted,
        updated,
        skipped,
        failed
      });

    } else if (activeTab === 'import_aid') {
      let currentAid = [...deliveryRecords];

      for (let b = 0; b < totalBatches; b++) {
        const start = b * BATCH_SIZE;
        const end = Math.min(start + BATCH_SIZE, total);
        const batch = parsedRows.slice(start, end);

        for (let i = 0; i < batch.length; i++) {
          const r = batch[i];
          const globalIndex = start + i;

          try {
            const familyIdStr = String(r[fieldMappings['familyNationalID']] || '').trim();
            const aidType = String(r[fieldMappings['aidTypeName']] || 'سلات غذائية وطعام ساخن').trim();
            const project = fieldMappings['projectName'] ? String(r[fieldMappings['projectName']] || 'مشروع الإغاثة') : 'مشروع الإغاثة';
            const date = fieldMappings['deliveryDate'] ? String(r[fieldMappings['deliveryDate']] || '2026-10-14') : '2026-10-14';
            const warehouse = fieldMappings['warehouse'] ? String(r[fieldMappings['warehouse']] || 'المستودع الرئيسي') : 'المستودع الرئيسي';
            const status = fieldMappings['status'] ? String(r[fieldMappings['status']] || 'تم التسليم') : 'تم التسليم';

            const matchedFamily = familiesList.find(f => f.nationalID === familyIdStr) || familiesList[0];

            const rec: DeliveryRecord = {
              id: `REC-IMP-${Date.now()}-${globalIndex}`,
              familyId: matchedFamily.familyID,
              family: matchedFamily,
              projectNumber: `PRJ-2026-${globalIndex + 1}`,
              projectName: project,
              aidTypeName: aidType,
              aidValue: 150,
              warehouse: warehouse,
              fundingOrg: 'جمعية الإغاثة الإنسانية',
              dueDistributionDate: date,
              status: status.includes('مستلم') || status.includes('تسليم') ? 'تم التسليم' : 'مرشح',
              deliveryDate: date,
              deliveryTime: '11:00',
              deliveredByStaff: 'أمين المستودع',
              receiverName: matchedFamily.name,
              receiverNationalId: matchedFamily.nationalID,
              receiverType: 'المستفيد شخصياً',
              deliveryNotes: 'مستورد وفق مطابقة الحقول الذكية'
            };

            currentAid.unshift(rec);
            inserted++;
          } catch (e: any) {
            failed++;
            errors.push(`خطأ في صف ${globalIndex + 1}: ${e.message}`);
          }
        }

        const currentDone = end;
        setImportCurrentCount(currentDone);
        setImportProgressPct(Math.round((currentDone / total) * 100));
        await new Promise(res => setTimeout(res, 20));
      }

      setDeliveryRecords(currentAid);
      setSummaryStats({
        title: 'استيراد سجلات المساعدات',
        total,
        inserted,
        updated: 0,
        skipped: 0,
        failed
      });

    } else {
      let currentChildren = [...childrenList];

      for (let b = 0; b < totalBatches; b++) {
        const start = b * BATCH_SIZE;
        const end = Math.min(start + BATCH_SIZE, total);
        const batch = parsedRows.slice(start, end);

        for (let i = 0; i < batch.length; i++) {
          const r = batch[i];
          const globalIndex = start + i;

          try {
            const childId = String(r[fieldMappings['childNationalID']] || `40000000${globalIndex}`).trim();
            const childName = String(r[fieldMappings['childName']] || 'طفل مستفيد').trim();
            const parentId = String(r[fieldMappings['parentNationalID']] || '901234567').trim();
            const birth = fieldMappings['birthDate'] ? String(r[fieldMappings['birthDate']] || '2020-01-01') : '2020-01-01';
            const gender = fieldMappings['gender'] && String(r[fieldMappings['gender']]).includes('أنثى') ? 'أنثى' : 'ذكر';

            const matchedFamily = familiesList.find(f => f.nationalID === parentId) || familiesList[0];

            const ch: MockChild = {
              id: currentChildren.length + inserted + 100,
              familyID: matchedFamily.familyID,
              name: childName,
              nationalID: childId,
              parentNationalID: parentId,
              gender: gender as 'ذكر' | 'أنثى',
              age: 5,
              birthDate: birth,
              relation: 'ابن'
            };

            currentChildren.unshift(ch);
            inserted++;
          } catch (e: any) {
            failed++;
            errors.push(`خطأ في صف ${globalIndex + 1}: ${e.message}`);
          }
        }

        const currentDone = end;
        setImportCurrentCount(currentDone);
        setImportProgressPct(Math.round((currentDone / total) * 100));
        await new Promise(res => setTimeout(res, 20));
      }

      setChildrenList(currentChildren);
      setSummaryStats({
        title: 'استيراد كشف الأبناء والتابعين',
        total,
        inserted,
        updated: 0,
        skipped: 0,
        failed
      });
    }

    setIsImporting(false);
    setShowProgressModal(false);
    setShowSummaryModal(true);
    setParsedRows([]);
    setUploadedFileName(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm">
      <div className="bg-white text-slate-800 rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* شريط العلم الفلسطيني العلوي الناعم */}
        <div className="w-full h-1.5 flex">
          <div className="w-1/3 bg-black"></div>
          <div className="w-1/3 bg-white"></div>
          <div className="w-1/3 bg-emerald-600"></div>
          <div className="w-16 bg-red-600"></div>
        </div>

        {/* ترويسة النافذة */}
        <div className="px-5 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 border border-emerald-200 text-emerald-800 flex items-center justify-center font-bold text-lg">
              🇵🇸
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900">
                  منظومة تبادل وملفات الإكسل المتقدمة (Excel Hub)
                </h2>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  فلسطين
                </span>
              </div>
              <p className="text-xs text-slate-500">
                تصدير بفترة زمنية محددة • مطابقة وتعيين حقول الإكسل الذكية • استيراد سلس غير متزامن
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-slate-200 text-slate-400 hover:text-slate-700 flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* التبويبات الأربعة الرئيسية */}
        <div className="px-5 pt-3 pb-2 border-b border-slate-200 bg-white flex gap-2 overflow-x-auto">
          <button
            onClick={() => { setActiveTab('export'); setParsedRows([]); setStatusMessage(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'export'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>تصدير إكسل بفترة زمنية محددة 📅</span>
          </button>

          <button
            onClick={() => { setActiveTab('import_families'); setParsedRows([]); setStatusMessage(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'import_families'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>رفع واستيراد كشف الأسر 👨‍👩‍👧</span>
          </button>

          <button
            onClick={() => { setActiveTab('import_aid'); setParsedRows([]); setStatusMessage(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'import_aid'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <PackageCheck className="w-4 h-4" />
            <span>رفع واستيراد سجلات المساعدات 📦</span>
          </button>

          <button
            onClick={() => { setActiveTab('import_children'); setParsedRows([]); setStatusMessage(null); }}
            className={`px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'import_children'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            <Baby className="w-4 h-4" />
            <span>رفع واستيراد كشف الأبناء 👶</span>
          </button>
        </div>

        {/* منطقة المحتوى القابلة للتمرير */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1 bg-slate-50/50">

          {/* رسائل التنبيه والنجاح */}
          {statusMessage && (
            <div className={`p-3.5 rounded-xl border flex items-center gap-3 text-xs sm:text-sm font-medium ${
              statusMessage.type === 'success' ? 'bg-emerald-50 border-emerald-300 text-emerald-800' :
              statusMessage.type === 'error' ? 'bg-red-50 border-red-300 text-red-800' :
              'bg-sky-50 border-sky-300 text-sky-800'
            }`}>
              {statusMessage.type === 'success' ? <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" /> :
               statusMessage.type === 'error' ? <AlertCircle className="w-5 h-5 text-red-600 shrink-0" /> :
               <Sparkles className="w-5 h-5 text-sky-600 shrink-0" />}
              <span>{statusMessage.text}</span>
            </div>
          )}

          {/* ======================================================== */}
          {/* التبويب 1: تصدير إكسل مع تحديد الفترة الزمنية            */}
          {/* ======================================================== */}
          {activeTab === 'export' && (
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm space-y-3">
                <div className="flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-emerald-600" />
                  <h3 className="text-sm font-bold text-slate-800">
                    تحديد نطاق الفترة الزمنية للكشف الميداني
                  </h3>
                </div>
                <p className="text-xs text-slate-500">
                  قم بتحديد تواريخ بدء ونهاية الفترة لاستخراج كافة المساعدات التي تم صرفها أو جدولتها في هذه الفترة
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">من تاريخ (Start Date):</label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">إلى تاريخ (End Date):</label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-800 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* فلاتر المنطقة ونوع المعونة والمجموعة */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">المنطقة / المحافظة:</label>
                  <select
                    value={selectedLocality}
                    onChange={(e) => setSelectedLocality(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-800 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {LOCALITY_OPTIONS.map(loc => <option key={loc} value={loc}>{loc}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">نوع المعونة الإنسانية:</label>
                  <select
                    value={selectedAidCategory}
                    onChange={(e) => setSelectedAidCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-800 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {AID_CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">مجموعة التوزيع المصرح بها:</label>
                  <select
                    value={selectedGroup}
                    onChange={(e) => setSelectedGroup(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-slate-800 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    {GROUPS_OPTIONS.map(grp => <option key={grp} value={grp}>{grp}</option>)}
                  </select>
                </div>
              </div>

              {/* بطاقة ملخص البيانات المطابقة */}
              <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h4 className="text-xs font-bold text-emerald-900">
                    ملخص الكشف الميداني للفترة المحددة:
                  </h4>
                  <p className="text-xs text-emerald-700 mt-0.5">
                    النطاق: من {startDate} إلى {endDate} • {selectedLocality} • {selectedGroup}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-emerald-600 block">السجلات المطابقة</span>
                    <span className="text-lg font-bold text-emerald-900">
                      {deliveryRecords.filter(r => {
                        const d = r.deliveryDate || r.dueDistributionDate || '';
                        return d >= startDate && d <= endDate;
                      }).length} مساعدة
                    </span>
                  </div>
                  <button
                    onClick={handleExportExcelWithPeriod}
                    className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow-md flex items-center gap-2 transition transform active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>تصدير كشف الإكسل (.xlsx)</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* التبويبات 2 و 3 و 4: رفع واستيراد ملفات الإكسل             */}
          {/* ======================================================== */}
          {activeTab !== 'export' && (
            <div className="space-y-4">
              
              {/* منطقة الرفع واختيار الملف */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm text-center space-y-3">
                <div className="w-12 h-12 mx-auto rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-800">
                    رفع ملف إكسل ({
                      activeTab === 'import_families' ? 'كشف بيانات الأسر' :
                      activeTab === 'import_aid' ? 'سجلات توزيع المساعدات' : 'سجل الأبناء والتابعين'
                    })
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    يدعم النظام صيغ Excel (.xlsx, .xls) و CSV مع التحقق التلقائي من صحة أرقام الهويات الفلسطينية (9 أرقام)
                  </p>
                </div>

                <div className="flex items-center justify-center gap-3 pt-2 flex-wrap">
                  <label className="cursor-pointer px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow flex items-center gap-2 transition">
                    <Upload className="w-4 h-4" />
                    <span>اختيار ملف من جهازك</span>
                    <input
                      type="file"
                      accept=".xlsx, .xls, .csv"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>

                  <button
                    onClick={() => {
                      if (activeTab === 'import_families') loadPresetSample('families');
                      else if (activeTab === 'import_aid') loadPresetSample('aid');
                      else loadPresetSample('children');
                    }}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs sm:text-sm border border-slate-300 flex items-center gap-2 transition"
                  >
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span>تحميل نموذج فلسطيني جاهز للتجربة</span>
                  </button>
                </div>

                {uploadedFileName && (
                  <div className="mt-2 text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 p-2 rounded-lg inline-flex items-center gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                    <span>الملف النشط: {uploadedFileName} ({parsedRows.length} سجل • {detectedHeaders.length} عمود)</span>
                  </div>
                )}
              </div>

              {/* قسم مطابقة الحقول التفاعلية المباشرة (Field Mapping) */}
              {parsedRows.length > 0 && (
                <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
                    <div className="flex items-center gap-2">
                      <SlidersHorizontal className="w-5 h-5 text-emerald-600" />
                      <div>
                        <h4 className="text-sm font-bold text-slate-800">
                          ١. شاشة مطابقة وتعيين حقول ملف الإكسل (Field Mapping)
                        </h4>
                        <p className="text-xs text-slate-500">
                          اختر لكل حقل في النظام العمود المقابل له في ملف الإكسل. يتم كشف الحقول الشائعة تلقائياً.
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => autoMapFields(detectedHeaders, currentTargetFields)}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition border border-slate-300"
                    >
                      <RefreshCw className="w-3.5 h-3.5 text-emerald-600" />
                      <span>إعادة الكشف التلقائي</span>
                    </button>
                  </div>

                  {/* شبكة حقول المطابقة */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {currentTargetFields.map(field => {
                      const selectedCol = fieldMappings[field.key] || '';
                      return (
                        <div
                          key={field.key}
                          className={`p-3 rounded-xl border transition ${
                            selectedCol
                              ? 'bg-emerald-50/40 border-emerald-300/80'
                              : field.isRequired
                              ? 'bg-red-50/40 border-red-200'
                              : 'bg-slate-50 border-slate-200'
                          }`}
                        >
                          <div className="flex items-center justify-between mb-1.5">
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-bold text-slate-800">{field.label}</span>
                              {field.isRequired ? (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-100 text-red-700 border border-red-200">
                                  إلزامي *
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-400">اختياري</span>
                              )}
                            </div>
                            {selectedCol && (
                              <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700">
                                <Check className="w-3.5 h-3.5" />
                                <span>تم التعيين</span>
                              </span>
                            )}
                          </div>
                          
                          <p className="text-[11px] text-slate-500 mb-2">{field.description}</p>

                          <select
                            value={selectedCol}
                            onChange={(e) => {
                              const val = e.target.value;
                              setFieldMappings(prev => ({
                                ...prev,
                                [field.key]: val
                              }));
                            }}
                            className={`w-full px-3 py-1.5 rounded-lg border text-xs font-medium bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                              selectedCol ? 'border-emerald-500 text-emerald-900 font-semibold' : 'border-slate-300 text-slate-600'
                            }`}
                          >
                            <option value="">🚫 تجاهل هذا الحقل (عدم الاستيراد)</option>
                            {detectedHeaders.map(col => (
                              <option key={col} value={col}>
                                عمود الإكسل: {col}
                              </option>
                            ))}
                          </select>
                        </div>
                      );
                    })}
                  </div>

                  {/* معاينة النتائج المباشرة وفقاً للمطابقة */}
                  <div className="pt-2 border-t border-slate-100 space-y-2">
                    <h5 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      <span>٢. معاينة النتائج المباشرة وفقاً للمطابقة المختارة (أول ٣ سجلات):</span>
                    </h5>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      {parsedRows.slice(0, 3).map((r, sIdx) => {
                        if (activeTab === 'import_families') {
                          const mId = r[fieldMappings['nationalID']] || '—';
                          const mName = r[fieldMappings['name']] || '—';
                          const mPhone = r[fieldMappings['primaryPhone']] || '—';
                          const mLocality = r[fieldMappings['currentSubArea']] || '—';
                          const mMembers = r[fieldMappings['membersCount']] || '—';

                          return (
                            <div key={sIdx} className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs space-y-1">
                              <div className="flex items-center justify-between">
                                <span className="font-bold text-slate-800 truncate">{sIdx + 1}. {mName}</span>
                                <span className="text-[10px] text-slate-400 font-mono">#{sIdx + 1}</span>
                              </div>
                              <div className="text-[11px] text-emerald-700 font-mono font-semibold">
                                الهوية: {mId}
                              </div>
                              <div className="text-[10px] text-slate-500 flex justify-between">
                                <span>أفراد: {mMembers}</span>
                                <span>جوال: {mPhone}</span>
                              </div>
                              <div className="text-[10px] text-slate-600 truncate">
                                المنطقة: {mLocality}
                              </div>
                            </div>
                          );
                        } else if (activeTab === 'import_aid') {
                          const mId = r[fieldMappings['familyNationalID']] || '—';
                          const mType = r[fieldMappings['aidTypeName']] || '—';
                          const mPrj = r[fieldMappings['projectName']] || '—';
                          const mDate = r[fieldMappings['deliveryDate']] || '—';

                          return (
                            <div key={sIdx} className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs space-y-1">
                              <span className="font-bold text-slate-800 block truncate">{sIdx + 1}. {mType}</span>
                              <div className="text-[11px] text-emerald-700 font-mono">الهوية: {mId}</div>
                              <div className="text-[10px] text-slate-500">المشروع: {mPrj}</div>
                              <div className="text-[10px] text-slate-500">التاريخ: {mDate}</div>
                            </div>
                          );
                        } else {
                          const cId = r[fieldMappings['childNationalID']] || '—';
                          const cName = r[fieldMappings['childName']] || '—';
                          const pId = r[fieldMappings['parentNationalID']] || '—';

                          return (
                            <div key={sIdx} className="bg-slate-50 p-2.5 rounded-lg border border-slate-200 text-xs space-y-1">
                              <span className="font-bold text-slate-800 block truncate">{sIdx + 1}. {cName}</span>
                              <div className="text-[11px] text-emerald-700 font-mono">هوية الطفل: {cId}</div>
                              <div className="text-[10px] text-slate-500">هوية المعيل: {pId}</div>
                            </div>
                          );
                        }
                      })}
                    </div>
                  </div>

                  {/* معالجة السجلات المكررة (سؤال المستخدم قبل البدء) */}
                  {activeTab === 'import_families' && (
                    <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                      <h5 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-amber-600" />
                        <span>٣. معالجة السجلات المكررة عند تطابق رقم الهوية الوطنية:</span>
                      </h5>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                        <label className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
                          duplicateHandlingMode === 'update' ? 'bg-emerald-50 border-emerald-400 text-emerald-950 shadow-sm' : 'bg-white border-slate-200 text-slate-700'
                        }`}>
                          <input
                            type="radio"
                            name="dup_mode"
                            checked={duplicateHandlingMode === 'update'}
                            onChange={() => setDuplicateHandlingMode('update')}
                            className="mt-0.5 text-emerald-600 focus:ring-emerald-500"
                          />
                          <div>
                            <span className="text-xs font-bold block">🔄 تحديث بيانات الأسرة السابقة بالقيم الجديدة (موصى به)</span>
                            <span className="text-[10px] text-slate-500 mt-0.5 block">
                              في حال تطابق رقم الهوية، يتم استبدال الحقول القديمة بالبيانات الأحدث المستوردة دون مسح سجل الاستفادات.
                            </span>
                          </div>
                        </label>

                        <label className={`flex items-start gap-2.5 p-2.5 rounded-xl border cursor-pointer transition ${
                          duplicateHandlingMode === 'skip' ? 'bg-emerald-50 border-emerald-400 text-emerald-950 shadow-sm' : 'bg-white border-slate-200 text-slate-700'
                        }`}>
                          <input
                            type="radio"
                            name="dup_mode"
                            checked={duplicateHandlingMode === 'skip'}
                            onChange={() => setDuplicateHandlingMode('skip')}
                            className="mt-0.5 text-emerald-600 focus:ring-emerald-500"
                          />
                          <div>
                            <span className="text-xs font-bold block">⏭️ تخطي السجل المكرر والاحتفاظ بالبيانات القديمة</span>
                            <span className="text-[10px] text-slate-500 mt-0.5 block">
                              يتم إبقاء الأسرة الحالية في قاعدة البيانات وتجاهل أي سجل يحمل نفس رقم الهوية.
                            </span>
                          </div>
                        </label>
                      </div>
                    </div>
                  )}

                  {/* زر البدء بالاستيراد غير المتزامن */}
                  <div className="pt-2 flex items-center justify-between gap-3">
                    <div className="text-xs text-slate-500">
                      {!areRequiredFieldsMapped && (
                        <span className="text-red-600 font-bold flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" />
                          <span>يرجى تعيين كافة الحقول الإلزامية (*) لتفعيل زر الاستيراد.</span>
                        </span>
                      )}
                    </div>

                    <button
                      onClick={handleStartNonBlockingImport}
                      disabled={!areRequiredFieldsMapped || isImporting}
                      className={`px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm shadow-md flex items-center gap-2 transition transform active:scale-95 ${
                        areRequiredFieldsMapped && !isImporting
                          ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                          : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      }`}
                    >
                      <Play className="w-4 h-4 fill-current" />
                      <span>تأكيد وبدء الاستيراد بالدفعات السلسة ({parsedRows.length} سجل)</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* تذييل النافذة */}
        <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span>الهيئة الوطنية لإدارة وتوزيع المساعدات الإنسانية</span>
            <span>•</span>
            <span className="text-emerald-700 font-bold">قطاع غزة - فلسطين 🇵🇸</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs transition"
          >
            إغلاق
          </button>
        </div>

      </div>

      {/* ======================================================== */}
      {/* نافذة نسبة التقدم أثناء الاستيراد غير المتزامن              */}
      {/* ======================================================== */}
      {showProgressModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-5 space-y-4 text-center">
            <div className="w-14 h-14 mx-auto rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
              <RefreshCw className="w-7 h-7 animate-spin" />
            </div>

            <div>
              <h3 className="text-base font-bold text-slate-800">
                جاري استيراد وحفظ البيانات بالدفعات...
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                العملية تعمل في الخلفية بدون أي تأثير على استجابة النظام وبدون أي تعليق للشاشة ⚡
              </p>
            </div>

            {/* شريط التقدم */}
            <div className="space-y-1.5">
              <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200">
                <div
                  className="h-full bg-emerald-500 rounded-full transition-all duration-150"
                  style={{ width: `${importProgressPct}%` }}
                ></div>
              </div>

              <div className="flex justify-between items-center text-xs font-semibold px-1">
                <span className="text-emerald-700 font-bold text-sm">{importProgressPct}%</span>
                <span className="text-slate-500">
                  تم إنجاز {importCurrentCount} من أصل {importTotalCount} سجل
                </span>
              </div>
            </div>

            <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-[11px] text-slate-500">
              يتم التحقق من تطابق الهويات الوطنية ومطابقة البيانات في قاعدة البيانات الداخلية...
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* نافذة ملخص نتائج الاستيراد (Summary Dialog)                */}
      {/* ======================================================== */}
      {showSummaryModal && summaryStats && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 max-w-md w-full p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 border border-emerald-200 text-emerald-700 flex items-center justify-center font-bold">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  اكتملت عملية الاستيراد بنجاح!
                </h3>
                <p className="text-xs text-slate-500">{summaryStats.title}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5 py-1">
              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl text-center">
                <span className="text-[11px] text-emerald-700 block">إجمالي المعالجة</span>
                <span className="text-lg font-bold text-emerald-900">{summaryStats.total}</span>
              </div>
              <div className="bg-sky-50 border border-sky-200 p-3 rounded-xl text-center">
                <span className="text-[11px] text-sky-700 block">سجلات مضافة جديدة</span>
                <span className="text-lg font-bold text-sky-900">+{summaryStats.inserted}</span>
              </div>
              <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl text-center">
                <span className="text-[11px] text-amber-700 block">سجلات محدثة</span>
                <span className="text-lg font-bold text-amber-900">{summaryStats.updated}</span>
              </div>
              <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl text-center">
                <span className="text-[11px] text-slate-600 block">سجلات متخطاة</span>
                <span className="text-lg font-bold text-slate-800">{summaryStats.skipped}</span>
              </div>
            </div>

            <button
              onClick={() => {
                setShowSummaryModal(false);
                setStatusMessage({
                  type: 'success',
                  text: `✅ اكتمل استيراد وحفظ ${summaryStats.total} سجل بنجاح في قاعدة البيانات.`
                });
              }}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm shadow transition"
            >
              تم ومتابعة العمل
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
