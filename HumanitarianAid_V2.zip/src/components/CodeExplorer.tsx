import React, { useState } from 'react';
import { androidProjectFiles, AndroidFile } from '../androidProjectFiles';
import { FileCode, Copy, Check, Folder, Code, Terminal, FileText } from 'lucide-react';

export const CodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFile>(androidProjectFiles[0]);
  const [copied, setCopied] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const filteredFiles = androidProjectFiles.filter(f => {
    if (filterCategory === 'all') return true;
    return f.category === filterCategory;
  });

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row h-[740px]">
      {/* File Tree Sidebar */}
      <div className="w-full md:w-80 bg-slate-950 border-b md:border-b-0 md:border-l border-slate-800 flex flex-col">
        <div className="p-4 border-b border-slate-800">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-2">
            <Folder className="w-4 h-4" />
            <span>شجرة ملفات Android Studio</span>
          </div>
          <div className="flex gap-1 overflow-x-auto pb-1 text-xs">
            <button
              onClick={() => setFilterCategory('all')}
              className={`px-2 py-1 rounded-md text-[11px] ${filterCategory === 'all' ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}
            >
              الكل ({androidProjectFiles.length})
            </button>
            <button
              onClick={() => setFilterCategory('kotlin')}
              className={`px-2 py-1 rounded-md text-[11px] ${filterCategory === 'kotlin' ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}
            >
              Kotlin
            </button>
            <button
              onClick={() => setFilterCategory('gradle')}
              className={`px-2 py-1 rounded-md text-[11px] ${filterCategory === 'gradle' ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}
            >
              Gradle
            </button>
            <button
              onClick={() => setFilterCategory('res')}
              className={`px-2 py-1 rounded-md text-[11px] ${filterCategory === 'res' ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}
            >
              الموارد (res)
            </button>
            <button
              onClick={() => setFilterCategory('manifest')}
              className={`px-2 py-1 rounded-md text-[11px] ${filterCategory === 'manifest' ? 'bg-emerald-600 text-white font-bold' : 'bg-slate-800 text-slate-400'}`}
            >
              Manifest
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filteredFiles.map(file => {
            const isSelected = selectedFile.path === file.path;
            return (
              <button
                key={file.path}
                onClick={() => setSelectedFile(file)}
                className={`w-full text-right p-2.5 rounded-xl text-xs flex items-center gap-2.5 transition ${
                  isSelected
                    ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-semibold'
                    : 'hover:bg-slate-800/80 text-slate-300'
                }`}
              >
                <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? 'text-emerald-400' : 'text-slate-500'}`} />
                <div className="truncate text-right flex-1">
                  <span className="block truncate font-mono text-[11px]">{file.name}</span>
                  <span className="block text-[9px] text-slate-500 truncate">{file.path}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Code Editor View */}
      <div className="flex-1 flex flex-col bg-slate-900 overflow-hidden">
        {/* Editor Top Bar */}
        <div className="p-3 bg-slate-950/80 border-b border-slate-800 flex justify-between items-center px-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-md border border-emerald-500/20">
              {selectedFile.path}
            </span>
          </div>
          {!selectedFile.isBinary && (
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 border border-slate-700 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ الكود'}</span>
            </button>
          )}
        </div>

        {/* Code Content */}
        <div className="flex-1 overflow-auto p-4 bg-slate-950/40 font-mono text-xs text-slate-200 leading-relaxed dir-ltr text-left selection:bg-emerald-500/30">
          {selectedFile.isBinary ? (
            <div className="flex flex-col items-center justify-center h-full p-8 text-center">
              {selectedFile.name.endsWith('.png') ? (
                <div className="space-y-4">
                  <img
                    src={`data:image/png;base64,${selectedFile.content}`}
                    alt={selectedFile.name}
                    className="w-24 h-24 mx-auto rounded-2xl shadow-xl border-2 border-emerald-500/40 bg-slate-800 p-2"
                  />
                  <div className="text-sm font-sans text-slate-300 font-bold">{selectedFile.name}</div>
                  <div className="text-xs font-sans text-slate-400">أيقونة تطبيق أندرويد الرسمية (PNG Asset)</div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Terminal className="w-12 h-12 text-emerald-400 mx-auto" />
                  <div className="text-sm font-sans text-slate-300 font-bold">{selectedFile.name}</div>
                  <div className="text-xs font-sans text-slate-400">ملف تنفيذي مدمج (Gradle Wrapper JAR Binary)</div>
                </div>
              )}
            </div>
          ) : (
            <pre className="whitespace-pre">
              {selectedFile.content}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
};
