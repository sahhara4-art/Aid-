import React, { useState, useMemo, useRef } from 'react';
import {
  Upload,
  Cloud,
  CloudLightning,
  RefreshCw,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  Database,
  ArrowRight,
  Download,
  Settings,
  Layers,
  Sparkles,
  Zap,
  Check,
  X,
  FileText,
  Sliders,
  ShieldCheck,
  HardDrive,
  Wifi,
  WifiOff,
  Server,
  ArrowUpRight,
  Play,
  RotateCcw,
  CheckCheck,
  Eye,
  Trash2,
  Phone,
  MapPin,
  Users,
  Package,
  Calendar,
  Building,
  DollarSign,
  AlertCircle,
  FileCode,
  Tag,
  Info,
  Baby,
  UserPlus,
  HeartHandshake
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { MockFamily, DeliveryRecord, MockChild, MockUser } from './AndroidEmulator';

export type LinkingMergeMode = 'upsert' | 'append' | 'update_only' | 'replace';
export type LinkingChannel = 'mobile_file' | 'cloud_sync' | 'fast_paste';
export type DataTargetMode = 'citizens' | 'children' | 'aids' | 'combined_all';

interface DataLinkingSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentFamilies: MockFamily[];
  currentDeliveries: DeliveryRecord[];
  currentChildren: MockChild[];
  onApplyLinkedData: (
    updatedFamilies: MockFamily[],
    updatedDeliveries: DeliveryRecord[],
    updatedChildren: MockChild[],
    report: {
      totalProcessed: number;
      addedCount: number;
      updatedCount: number;
      skippedCount?: number;
      aidsAddedCount?: number;
      childrenAddedCount?: number;
      childrenUpdatedCount?: number;
      sourceName: string;
      channel: string;
      targetMode?: string;
    }
  ) => void;
  currentUser?: MockUser | null;
  onAddAuditLog?: (action: string, status: 'ناجح' | 'مرفوض' | 'تحذير أمني', details: string) => void;
}

// 1. تخطيط حقول المواطنين والأسر الكاملة (41 حقلاً شاملاً دون استثناء)
interface CitizenColumnMapping {
  familyID: string;
  nationalID: string;
  name: string;
  gender: string;
  birthDate: string;
  age: string;
  maritalStatus: string;
  deathStatus: string;
  deathDate: string;
  primaryPhone: string;
  alternativePhone1: string;
  alternativePhone2: string;
  wifeName: string;
  wifeNationalID: string;
  membersCount: string;
  damageType: string;
  damageDescription: string;
  injuryStatus: string;
  injuryDate: string;
  incomeSource1: string;
  incomeSource2: string;
  rationCardNumber: string;
  originalMainArea: string;
  originalSubArea: string;
  originalBranch: string;
  originalMosque: string;
  currentMainArea: string;
  currentSubArea: string;
  currentBranch: string;
  currentMosque: string;
  developmentApproval: string;
  localityApproval: string;
  residentStatus: string;
  worksApproval: string;
  shelterStatus: string;
  campOrCenterName: string;
  localityID: string;
  localityName: string;
  lastAidType: string;
  lastAidDate: string;
  notes: string;
}

// 2. تخطيط حقول الأبناء والتابعين الكاملة (12 حقلاً شاملاً دون استثناء)
interface ChildColumnMapping {
  id: string;
  familyID: string;
  parentNationalID: string;
  nationalID: string;
  name: string;
  gender: string;
  age: string;
  birthDate: string;
  relation: string;
  educationLevel: string;
  healthStatus: string;
  notes: string;
}

// 3. تخطيط حقول المساعدات والتسليمات الكاملة (20 حقلاً شاملاً دون استثناء)
interface AidColumnMapping {
  deliveryId: string;
  familyId: string;
  receiverNationalId: string;
  projectNumber: string;
  projectName: string;
  aidTypeName: string;
  aidValue: string;
  warehouse: string;
  fundingOrg: string;
  dueDistributionDate: string;
  status: string;
  deliveryDate: string;
  deliveryTime: string;
  deliveredByStaff: string;
  receiverType: string;
  receiverName: string;
  receiptVoucherNumber: string;
  signatureVerified: string;
  deliveryNotes: string;
}

export function DataLinkingSyncModal({
  isOpen,
  onClose,
  currentFamilies,
  currentDeliveries,
  currentChildren,
  onApplyLinkedData,
  currentUser,
  onAddAuditLog
}: DataLinkingSyncModalProps) {
  // وضع نوع البيانات المراد استيرادها / مزامنتها
  const [targetMode, setTargetMode] = useState<DataTargetMode>('citizens');

  // قناة الربط
  const [activeChannel, setActiveChannel] = useState<LinkingChannel>('mobile_file');
  const [currentStep, setCurrentStep] = useState<'source' | 'mapping' | 'preview' | 'executing' | 'completed'>('source');

  // ملف الإدخال
  const [sourceName, setSourceName] = useState<string>('');
  const [fileExtension, setFileExtension] = useState<string>('xlsx');
  const [excelSheets, setExcelSheets] = useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = useState<string>('');
  const [workbookCache, setWorkbookCache] = useState<XLSX.WorkBook | null>(null);

  // البيانات المقروءة
  const [rawRows, setRawRows] = useState<any[]>([]);
  const [detectedHeaders, setDetectedHeaders] = useState<string[]>([]);
  const [manualPasteText, setManualPasteText] = useState<string>('');

  // استراتيجية الدمج والخيارات المتقدمة
  const [mergeMode, setMergeMode] = useState<LinkingMergeMode>('upsert');
  const [autoCreateMissingCitizens, setAutoCreateMissingCitizens] = useState<boolean>(true);
  const [validatePalestineIdChecksum, setValidatePalestineIdChecksum] = useState<boolean>(true);
  const [autoUpdateFamilyMemberCount, setAutoUpdateFamilyMemberCount] = useState<boolean>(true);

  // السحابة
  const [cloudEndpointUrl, setCloudEndpointUrl] = useState<string>(
    'https://api.humanitarian-aid-gaza.ps/v1/sync/comprehensive-database'
  );
  const [cloudApiKey, setCloudApiKey] = useState<string>('SEC_TOKEN_LIVE_7781_GZ');
  const [isCloudConnecting, setIsCloudConnecting] = useState<boolean>(false);
  const [cloudLastSyncTime, setCloudLastSyncTime] = useState<string>('2026-10-13 11:30:00');

  // 1. تخطيط حقول المواطنين والأسر
  const [citizenMapping, setCitizenMapping] = useState<CitizenColumnMapping>({
    familyID: '',
    nationalID: '',
    name: '',
    gender: '',
    birthDate: '',
    age: '',
    maritalStatus: '',
    deathStatus: '',
    deathDate: '',
    primaryPhone: '',
    alternativePhone1: '',
    alternativePhone2: '',
    wifeName: '',
    wifeNationalID: '',
    membersCount: '',
    damageType: '',
    damageDescription: '',
    injuryStatus: '',
    injuryDate: '',
    incomeSource1: '',
    incomeSource2: '',
    rationCardNumber: '',
    originalMainArea: '',
    originalSubArea: '',
    originalBranch: '',
    originalMosque: '',
    currentMainArea: '',
    currentSubArea: '',
    currentBranch: '',
    currentMosque: '',
    developmentApproval: '',
    localityApproval: '',
    residentStatus: '',
    worksApproval: '',
    shelterStatus: '',
    campOrCenterName: '',
    localityID: '',
    localityName: '',
    lastAidType: '',
    lastAidDate: '',
    notes: ''
  });

  // 2. تخطيط حقول الأبناء والتابعين
  const [childMapping, setChildMapping] = useState<ChildColumnMapping>({
    id: '',
    familyID: '',
    parentNationalID: '',
    nationalID: '',
    name: '',
    gender: '',
    age: '',
    birthDate: '',
    relation: '',
    educationLevel: '',
    healthStatus: '',
    notes: ''
  });

  // 3. تخطيط حقول المساعدات والتسليمات
  const [aidMapping, setAidMapping] = useState<AidColumnMapping>({
    deliveryId: '',
    familyId: '',
    receiverNationalId: '',
    projectNumber: '',
    projectName: '',
    aidTypeName: '',
    aidValue: '',
    warehouse: '',
    fundingOrg: '',
    dueDistributionDate: '',
    status: '',
    deliveryDate: '',
    deliveryTime: '',
    deliveredByStaff: '',
    receiverType: '',
    receiverName: '',
    receiptVoucherNumber: '',
    signatureVerified: '',
    deliveryNotes: ''
  });

  // فلتر المعاينة
  const [previewFilter, setPreviewFilter] = useState<'all' | 'valid' | 'updates' | 'errors'>('all');

  // التنفيذ والنتائج
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [progressStatusText, setProgressStatusText] = useState<string>('');
  const [linkedResultStats, setLinkedResultStats] = useState<{
    totalProcessed: number;
    citizensAdded: number;
    citizensUpdated: number;
    childrenAdded: number;
    childrenUpdated: number;
    aidsAdded: number;
    skippedCount: number;
    totalActiveFamiliesNow: number;
    totalActiveChildrenNow: number;
    totalActiveDeliveriesNow: number;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // دالة فحص وتدقيق رقم الهوية الفلسطينية
  const isValidNationalId = (id: string): boolean => {
    const cleanId = String(id || '').replace(/\D/g, '').trim();
    if (cleanId.length !== 9) return false;
    if (!validatePalestineIdChecksum) return true;

    // خوارزمية فحص الهوية (Mod 10 / Luhn المعدل)
    let sum = 0;
    for (let i = 0; i < 9; i++) {
      let digit = parseInt(cleanId.charAt(i), 10);
      let step = (i % 2 === 0) ? digit * 1 : digit * 2;
      if (step > 9) step = Math.floor(step / 10) + (step % 10);
      sum += step;
    }
    return sum % 10 === 0;
  };

  // كشف تلقائي ذكي لعناوين أعمدة المواطنين والأسر
  const autoDetectCitizenMapping = (headers: string[]): CitizenColumnMapping => {
    const clean = (s: string) => s.trim().toLowerCase().replace(/[\s_\-\/\\]+/g, '');

    const findMatch = (candidates: string[]): string => {
      for (const h of headers) {
        const cleanedH = clean(h);
        for (const c of candidates) {
          if (cleanedH === clean(c) || cleanedH.includes(clean(c))) {
            return h;
          }
        }
      }
      return '';
    };

    return {
      familyID: findMatch(['رقم الأسرة', 'كود الأسرة', 'معرف الأسرة', 'family_id', 'familyid']),
      nationalID: findMatch(['رقم الهوية', 'الهوية', 'national_id', 'id_number', 'رقم الهوية الوطنية', 'الهوية الوطنية', 'id']),
      name: findMatch(['اسم رب الأسرة', 'الاسم', 'الاسم رباعي', 'full_name', 'name', 'المستفيد', 'اسم المستفيد']),
      gender: findMatch(['الجنس', 'النوع', 'gender', 'ذكر/أنثى']),
      birthDate: findMatch(['تاريخ الميلاد', 'الميلاد', 'birth_date', 'dob']),
      age: findMatch(['العمر', 'السن', 'age']),
      maritalStatus: findMatch(['الحالة الاجتماعية', 'الوضع الاجتماعي', 'marital_status']),
      deathStatus: findMatch(['حالة الوفاة', 'الوفاة', 'على قيد الحياة', 'death_status']),
      deathDate: findMatch(['تاريخ الوفاة', 'death_date']),
      primaryPhone: findMatch(['رقم الجوال', 'الجوال', 'الهاتف', 'phone', 'mobile', 'رقم الهاتف الأساسي', 'جوال أساسي']),
      alternativePhone1: findMatch(['جوال بديل 1', 'هاتف بديل', 'جوال إضافي', 'alt_phone1', 'جوال بديل']),
      alternativePhone2: findMatch(['جوال بديل 2', 'هاتف آخر', 'alt_phone2']),
      wifeName: findMatch(['اسم الزوجة', 'اسم الزوج', 'الزوجة', 'wife_name']),
      wifeNationalID: findMatch(['هوية الزوجة', 'رقم هوية الزوجة', 'wife_id', 'wife_national_id']),
      membersCount: findMatch(['عدد أفراد الأسرة', 'عدد الأفراد', 'الأفراد', 'members_count', 'family_size', 'العدد', 'إجمالي أفراد الأسرة']),
      damageType: findMatch(['حالة الضرر', 'نوع الضرر', 'الضرر', 'damage_type']),
      damageDescription: findMatch(['وصف الضرر', 'damage_description']),
      injuryStatus: findMatch(['حالة الإصابة', 'الإصابة', 'جريح', 'injury_status']),
      injuryDate: findMatch(['تاريخ الإصابة', 'injury_date']),
      incomeSource1: findMatch(['مصدر الدخل 1', 'مصدر الدخل', 'الدخل', 'income_source']),
      incomeSource2: findMatch(['مصدر الدخل 2', 'income_source2']),
      rationCardNumber: findMatch(['رقم كرت المؤن', 'كرت المؤن', 'كرت التموين', 'unrwa', 'ration_card']),
      originalMainArea: findMatch(['المحافظة الأصلية', 'المنطقة الرئيسية الأصلية', 'original_area']),
      originalSubArea: findMatch(['المنطقة الفرعية الأصلية', 'الحي الأصلي', 'original_sub_area']),
      originalBranch: findMatch(['الشعبة الأصلية', 'original_branch']),
      originalMosque: findMatch(['المسجد الأصلي', 'original_mosque']),
      currentMainArea: findMatch(['المحافظة الحالية', 'المحافظة', 'المنطقة الرئيسية الحالية', 'current_main_area']),
      currentSubArea: findMatch(['المنطقة الفرعية الحالية', 'المنطقة الفرعية', 'المنطقة', 'الحي', 'current_sub_area', 'sub_area']),
      currentBranch: findMatch(['الشعبة الحالية', 'الشعبة', 'current_branch']),
      currentMosque: findMatch(['المسجد الحالي', 'المسجد', 'مسجد', 'current_mosque', 'mosque']),
      developmentApproval: findMatch(['حالة اعتماد التنمية', 'اعتماد التنمية', 'التنمية', 'development_approval']),
      localityApproval: findMatch(['اعتماد المحلية', 'اعتماد المناطق', 'locality_approval']),
      residentStatus: findMatch(['صفة الإقامة', 'الإقامة', 'نازح/مقيم', 'مقيم / نازح', 'حالة الإقامة', 'resident_status']),
      worksApproval: findMatch(['اعتماد الأشغال', 'الأشغال', 'works_approval']),
      shelterStatus: findMatch(['حالة الإيواء', 'الإيواء', 'shelter_status']),
      campOrCenterName: findMatch(['مركز الإيواء', 'المخيم', 'اسم المخيم', 'مركز / مخيم الإيواء', 'camp_name']),
      localityID: findMatch(['معرف المحلية', 'كود المحلية', 'locality_id']),
      localityName: findMatch(['اسم المحلية', 'المحلية', 'locality_name']),
      lastAidType: findMatch(['آخر مساعدة', 'نوع المساعدة', 'last_aid_type', 'aid_type']),
      lastAidDate: findMatch(['تاريخ آخر مساعدة', 'تاريخ الصرف', 'آخر تاريخ مساعدة', 'last_aid_date']),
      notes: findMatch(['ملاحظات', 'الملاحظات', 'ملاحظات الأسرة', 'notes'])
    };
  };

  // كشف تلقائي ذكي لعناوين أعمدة الأبناء والتابعين
  const autoDetectChildMapping = (headers: string[]): ChildColumnMapping => {
    const clean = (s: string) => s.trim().toLowerCase().replace(/[\s_\-\/\\]+/g, '');

    const findMatch = (candidates: string[]): string => {
      for (const h of headers) {
        const cleanedH = clean(h);
        for (const c of candidates) {
          if (cleanedH === clean(c) || cleanedH.includes(clean(c))) {
            return h;
          }
        }
      }
      return '';
    };

    return {
      id: findMatch(['معرف الابن', 'كود الابن', 'رقم الابن', 'child_id', 'م']),
      familyID: findMatch(['رقم أسرة الوالد', 'رقم الأسرة', 'كود الأسرة', 'family_id', 'familyid']),
      parentNationalID: findMatch(['رقم هوية رب الأسرة', 'هوية الوالد', 'هوية المعيل', 'هوية الأب', 'parent_id', 'parent_national_id', 'parentnationalid']),
      nationalID: findMatch(['رقم هوية الابن', 'هوية الابن', 'شهادة الميلاد', 'child_national_id', 'child_id_num', 'رقم هوية التابع']),
      name: findMatch(['اسم الابن', 'اسم الابن / التابع', 'اسم التابع', 'child_name', 'الاسم']),
      gender: findMatch(['الجنس', 'النوع', 'child_gender', 'gender']),
      age: findMatch(['العمر', 'العمر (بالسنوات)', 'العمر (سنوات)', 'child_age', 'السن']),
      birthDate: findMatch(['تاريخ الميلاد', 'تاريخ ميلاد الابن', 'child_birth_date', 'birth_date']),
      relation: findMatch(['صلة القرابة', 'القرابة', 'relation', 'الصلة']),
      educationLevel: findMatch(['المرحلة التعليمية', 'التعليم', 'الصف', 'education_level', 'education']),
      healthStatus: findMatch(['الحالة الصحية', 'صحة الابن', 'health_status', 'health']),
      notes: findMatch(['ملاحظات', 'ملاحظات خاصة', 'ملاحظات الابن', 'notes'])
    };
  };

  // كشف تلقائي ذكي لعناوين أعمدة المساعدات والتسليمات
  const autoDetectAidMapping = (headers: string[]): AidColumnMapping => {
    const clean = (s: string) => s.trim().toLowerCase().replace(/[\s_\-\/\\]+/g, '');

    const findMatch = (candidates: string[]): string => {
      for (const h of headers) {
        const cleanedH = clean(h);
        for (const c of candidates) {
          if (cleanedH === clean(c) || cleanedH.includes(clean(c))) {
            return h;
          }
        }
      }
      return '';
    };

    return {
      deliveryId: findMatch(['كود التسليم', 'رقم السند', 'رقم التسليم', 'delivery_id', 'id', 'رقم سند الصرف']),
      familyId: findMatch(['رقم الأسرة', 'كود الأسرة', 'family_id']),
      receiverNationalId: findMatch(['رقم الهوية', 'الهوية', 'هوية المستفيد', 'national_id', 'id_number', 'هوية المستلم', 'رقم الهوية الوطنية']),
      projectNumber: findMatch(['رقم المشروع', 'كود المشروع', 'project_number', 'project_id']),
      projectName: findMatch(['اسم المشروع', 'المشروع', 'project_name']),
      aidTypeName: findMatch(['نوع المساعدة', 'نوع وقيمة الطرد', 'المساعدة', 'الصنف', 'aid_type', 'aid_name']),
      aidValue: findMatch(['القيمة', 'قيمة المساعدة', 'المبلغ', 'قيمة المساعدة (₪)', 'aid_value', 'value']),
      warehouse: findMatch(['المستودع', 'المستودع المنفذ', 'المخزن', 'مركز التوزيع', 'warehouse']),
      fundingOrg: findMatch(['الجهة المانحة', 'الممول', 'الجهة الممولة', 'donor', 'funding_org']),
      dueDistributionDate: findMatch(['تاريخ الاستحقاق', 'تاريخ التوزيع المجدول', 'due_date']),
      status: findMatch(['حالة الصرف والتسليم', 'الحالة', 'حالة التسليم', 'status']),
      deliveryDate: findMatch(['تاريخ التسليم', 'تاريخ الاستلام', 'تاريخ الصرف', 'delivery_date', 'date']),
      deliveryTime: findMatch(['وقت التسليم', 'وقت الاستلام', 'الساعة', 'delivery_time', 'time']),
      deliveredByStaff: findMatch(['الموظف المسلّم', 'أمين المخزن', 'اسم الموظف', 'delivered_by']),
      receiverType: findMatch(['صفة المستلم', 'المستلم', 'نوع المستلم', 'receiver_type']),
      receiverName: findMatch(['اسم المستلم', 'المستلم الفعلي', 'اسم المستفيد', 'receiver_name']),
      receiptVoucherNumber: findMatch(['رقم الإيصال', 'سند الاستلام', 'رقم سند الصرف', 'voucher_number']),
      signatureVerified: findMatch(['التحقق من الهوية والتوقيع', 'التوقيع', 'signature_verified']),
      deliveryNotes: findMatch(['ملاحظات التسليم', 'ملاحظات', 'notes'])
    };
  };

  // معالجة قراءة وتحليل ملف الإكسل
  const processExcelBuffer = (buffer: ArrayBuffer, fileName: string, sheetNameToUse?: string) => {
    const wb = XLSX.read(buffer, { type: 'array' });
    setWorkbookCache(wb);
    setExcelSheets(wb.SheetNames);

    const activeSheetName = sheetNameToUse || wb.SheetNames[0];
    setSelectedSheet(activeSheetName);

    const ws = wb.Sheets[activeSheetName];
    const data = XLSX.utils.sheet_to_json<any>(ws, { header: 1 });

    if (!data || data.length < 2) {
      alert('الملف المرفوع فارغ أو لا يحتوي على صفوف بيانات كافية.');
      return;
    }

    const headers = (data[0] as string[]).map(h => String(h || '').trim()).filter(Boolean);
    const rows: any[] = [];

    for (let i = 1; i < data.length; i++) {
      const rowArr = data[i] as any[];
      if (!rowArr || rowArr.length === 0) continue;
      const rowObj: Record<string, any> = {};
      headers.forEach((h, idx) => {
        rowObj[h] = rowArr[idx] !== undefined ? String(rowArr[idx]).trim() : '';
      });
      rows.push(rowObj);
    }

    setSourceName(fileName);
    setDetectedHeaders(headers);
    setRawRows(rows);

    // تطبيق الكشف التلقائي بحسب الوضع المحدد
    if (targetMode === 'citizens' || targetMode === 'combined_all') {
      setCitizenMapping(autoDetectCitizenMapping(headers));
    }
    if (targetMode === 'children' || targetMode === 'combined_all') {
      setChildMapping(autoDetectChildMapping(headers));
    }
    if (targetMode === 'aids' || targetMode === 'combined_all') {
      setAidMapping(autoDetectAidMapping(headers));
    }

    setCurrentStep('mapping');
  };

  // تغيير الشيت النشط في ملف إكسل متعدد الشيتات
  const handleSheetChange = (sheetName: string) => {
    if (!workbookCache) return;
    const ws = workbookCache.Sheets[sheetName];
    if (!ws) return;
    setSelectedSheet(sheetName);

    const data = XLSX.utils.sheet_to_json<any>(ws, { header: 1 });
    if (!data || data.length < 2) return;

    const headers = (data[0] as string[]).map(h => String(h || '').trim()).filter(Boolean);
    const rows: any[] = [];
    for (let i = 1; i < data.length; i++) {
      const rowArr = data[i] as any[];
      if (!rowArr || rowArr.length === 0) continue;
      const rowObj: Record<string, any> = {};
      headers.forEach((h, idx) => {
        rowObj[h] = rowArr[idx] !== undefined ? String(rowArr[idx]).trim() : '';
      });
      rows.push(rowObj);
    }

    setDetectedHeaders(headers);
    setRawRows(rows);

    // الكشف التلقائي
    if (targetMode === 'citizens' || targetMode === 'combined_all') {
      setCitizenMapping(autoDetectCitizenMapping(headers));
    }
    if (targetMode === 'children' || targetMode === 'combined_all') {
      setChildMapping(autoDetectChildMapping(headers));
    }
    if (targetMode === 'aids' || targetMode === 'combined_all') {
      setAidMapping(autoDetectAidMapping(headers));
    }
  };

  // رفع ملف من الجوال أو الجهاز
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const ext = file.name.split('.').pop()?.toLowerCase() || 'xlsx';
    setFileExtension(ext);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result as ArrayBuffer;
        processExcelBuffer(buffer, file.name);
      } catch (err: any) {
        alert(`خطأ أثناء قراءة الملف: ${err.message}`);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // معالجة اللصق السريع للجداول
  const handleProcessPastedText = () => {
    if (!manualPasteText.trim()) {
      alert('يرجى لصق بيانات الجدول أولاً في الصندوق المخصص');
      return;
    }

    const lines = manualPasteText.trim().split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length < 2) {
      alert('البيانات الملصوقة يجب أن تحتوي على صف عناوين واحد على الأقل بالإضافة لصفوف البيانات');
      return;
    }

    const delimiter = lines[0].includes('\t') ? '\t' : lines[0].includes(';') ? ';' : ',';
    const headers = lines[0].split(delimiter).map(h => h.trim().replace(/^"|"$/g, ''));
    const rows: any[] = [];

    for (let i = 1; i < lines.length; i++) {
      const parts = lines[i].split(delimiter).map(p => p.trim().replace(/^"|"$/g, ''));
      const obj: Record<string, any> = {};
      headers.forEach((h, idx) => {
        obj[h] = parts[idx] || '';
      });
      rows.push(obj);
    }

    setSourceName(`جدول_منسوخ_${rows.length}_سجل.tsv`);
    setFileExtension('tsv');
    setDetectedHeaders(headers);
    setRawRows(rows);

    if (targetMode === 'citizens' || targetMode === 'combined_all') {
      setCitizenMapping(autoDetectCitizenMapping(headers));
    }
    if (targetMode === 'children' || targetMode === 'combined_all') {
      setChildMapping(autoDetectChildMapping(headers));
    }
    if (targetMode === 'aids' || targetMode === 'combined_all') {
      setAidMapping(autoDetectAidMapping(headers));
    }

    setCurrentStep('mapping');
  };

  // استدعاء الربط السحابي
  const handleFetchFromCloud = () => {
    setIsCloudConnecting(true);

    setTimeout(() => {
      if (targetMode === 'children') {
        // حزمة سحابية لجدول الأبناء
        const childHeaders = [
          'معرف الابن',
          'رقم أسرة الوالد',
          'رقم هوية رب الأسرة',
          'رقم هوية الابن',
          'اسم الابن',
          'الجنس',
          'العمر',
          'تاريخ الميلاد',
          'صلة القرابة',
          'المرحلة التعليمية',
          'الحالة الصحية',
          'ملاحظات'
        ];

        const childRows: any[] = [];
        const rels: ('ابن' | 'ابنة')[] = ['ابن', 'ابنة'];
        const edus = ['رياض أطفال', 'ابتدائي', 'إعدادي', 'ثانوي'];
        const firstBoy = ['عمر', 'إبراهيم', 'بلال', 'خليل', 'أنس', 'طارق'];
        const firstGirl = ['سارة', 'مريم', 'تسنيم', 'جنى', 'آية', 'فاطمة'];

        for (let i = 0; i < 60; i++) {
          const fam = currentFamilies[i % currentFamilies.length];
          const isBoy = i % 2 === 0;
          const name = isBoy ? `${firstBoy[i % firstBoy.length]} ${fam.name}` : `${firstGirl[i % firstGirl.length]} ${fam.name}`;
          const age = 3 + (i % 14);

          childRows.push({
            'معرف الابن': 200 + i,
            'رقم أسرة الوالد': fam.familyID,
            'رقم هوية رب الأسرة': fam.nationalID,
            'رقم هوية الابن': `410${String(100000 + i * 37).slice(0, 6)}`,
            'اسم الابن': name,
            'الجنس': isBoy ? 'ذكر' : 'أنثى',
            'العمر': age,
            'تاريخ الميلاد': `20${String(24 - age).padStart(2, '0')}-05-15`,
            'صلة القرابة': isBoy ? 'ابن' : 'ابنة',
            'المرحلة التعليمية': edus[i % edus.length],
            'الحالة الصحية': i % 10 === 0 ? 'مصاب حرب' : 'سليم',
            'ملاحظات': i % 10 === 0 ? 'إصابة شظايا - يحتاج متابعة' : 'مسجل بالتعليم'
          });
        }

        setSourceName(`سحابة_الأبناء_المحدثة_${cloudEndpointUrl.split('/')[2] || 'live'}`);
        setFileExtension('cloud_json');
        setDetectedHeaders(childHeaders);
        setRawRows(childRows);
        setChildMapping(autoDetectChildMapping(childHeaders));
      } else if (targetMode === 'aids') {
        // حزمة مساعدات سحابية
        const aidHeaders = [
          'كود التسليم',
          'رقم الهوية',
          'اسم المستفيد',
          'اسم المشروع',
          'كود المشروع',
          'نوع المساعدة',
          'القيمة',
          'المستودع',
          'الجهة المانحة',
          'تاريخ التسليم',
          'الموظف المسلّم',
          'صفة المستلم',
          'رقم الإيصال'
        ];

        const aidRows: any[] = [];
        const aidTypes = ['طرد غذائي شامل', 'سلة خضار طازجة', 'قسيمة نقدية 100$', 'كرتونة مياه وتمر', 'طرد صحي ونظافة'];
        const warehouses = ['المستودع المركزي - الشيخ رضوان', 'مستودع الشاطئ', 'نقطة توزيع الرمال'];

        for (let i = 0; i < 70; i++) {
          const fam = currentFamilies[i % currentFamilies.length];
          aidRows.push({
            'كود التسليم': `DEL-CLOUD-${Date.now().toString().slice(-4)}-${i + 1}`,
            'رقم الهوية': fam?.nationalID || String(901000000 + i * 11),
            'اسم المستفيد': fam?.name || `مستفيد سحابي ${i + 1}`,
            'اسم المشروع': 'مشروع الإغاثة العاجلة لشمال غزة',
            'كود المشروع': 'PRJ-2026-LIVE',
            'نوع المساعدة': aidTypes[i % aidTypes.length],
            'القيمة': 180,
            'المستودع': warehouses[i % warehouses.length],
            'الجهة المانحة': 'مركز الملك سلمان للإغاثة والأعمال الإنسانية',
            'تاريخ التسليم': '2026-10-12',
            'الموظف المسلّم': currentUser?.fullName || 'مسؤول التوزيع الميداني',
            'صفة المستلم': 'المستفيد شخصياً',
            'رقم الإيصال': `REC-CLOUD-${100 + i}`
          });
        }

        setSourceName(`سحابة_المساعدات_${cloudEndpointUrl.split('/')[2] || 'live'}`);
        setFileExtension('cloud_json');
        setDetectedHeaders(aidHeaders);
        setRawRows(aidRows);
        setAidMapping(autoDetectAidMapping(aidHeaders));
      } else {
        // حزمة مواطنين سحابية شاملة لكافة الحقول
        const cloudHeaders = [
          'رقم الهوية الوطنية',
          'اسم رب الأسرة',
          'الجنس',
          'تاريخ الميلاد',
          'العمر',
          'الحالة الاجتماعية',
          'رقم الجوال الأساسي',
          'اسم الزوجة',
          'هوية الزوجة',
          'عدد أفراد الأسرة',
          'حالة الضرر',
          'مصدر الدخل 1',
          'رقم كرت المؤن',
          'المحافظة الحالية',
          'المنطقة الفرعية الحالية',
          'المسجد الحالي',
          'حالة اعتماد التنمية',
          'صفة الإقامة',
          'حالة الإيواء',
          'آخر نوع مساعدة',
          'تاريخ آخر استلام',
          'ملاحظات'
        ];

        const areas = ['الشيخ رضوان', 'الرمال الشمالي', 'الشاطئ الشمالي والنصر', 'الشاطئ الجنوبي', 'مشروع عامر'];
        const mosques = ['مسجد الرضوان', 'مسجد فلسطين', 'مسجد الشاطئ الكبير', 'مسجد عامر بن الجراح', 'مسجد السلام'];
        const firstNames = ['محمود', 'إبراهيم', 'يوسف', 'خليل', 'عبد الله', 'زياد', 'طارق', 'جمال', 'علاء', 'تيسير'];
        const middleNames = ['أحمد', 'محمد', 'حسن', 'علي', 'عثمان', 'سالم', 'سامي', 'ماجد', 'فؤاد', 'رامي'];
        const familyNames = ['الأغا', 'النجار', 'صالح', 'قديح', 'بربخ', 'حبيب', 'فياض', 'عابد', 'العطار', 'أبو طه'];

        const generatedRows: any[] = [];
        const baseId = 907000000;

        for (let i = 0; i < 100; i++) {
          const id = String(baseId + i * 7 + 13);
          const name = `${firstNames[i % firstNames.length]} ${middleNames[(i * 3) % middleNames.length]} ${familyNames[(i * 2) % familyNames.length]}`;
          const area = areas[i % areas.length];
          const mosque = mosques[i % mosques.length];
          const members = 4 + (i % 7);
          const devApp = i % 8 === 0 ? 'حجب اعتماد' : i % 15 === 0 ? 'مجمد' : 'معتمد';
          const resStat = i % 5 === 0 ? 'نازح' : 'مقيم';
          const phone = `059${String(1000000 + i * 3421).slice(0, 7)}`;

          generatedRows.push({
            'رقم الهوية الوطنية': id,
            'اسم رب الأسرة': name,
            'الجنس': 'ذكر',
            'تاريخ الميلاد': '1982-01-01',
            'العمر': 44,
            'الحالة الاجتماعية': 'متزوج',
            'رقم الجوال الأساسي': phone,
            'اسم الزوجة': `زوجة ${name.split(' ')[0]}`,
            'هوية الزوجة': `90${String(8000000 + i * 31).slice(0, 7)}`,
            'عدد أفراد الأسرة': members,
            'حالة الضرر': i % 3 === 0 ? 'كلي' : 'جزئي بليغ',
            'مصدر الدخل 1': 'عمال مياومة',
            'رقم كرت المؤن': `UN-${id.slice(-6)}`,
            'المحافظة الحالية': 'غزة',
            'المنطقة الفرعية الحالية': area,
            'المسجد الحالي': mosque,
            'حالة اعتماد التنمية': devApp,
            'صفة الإقامة': resStat,
            'حالة الإيواء': 'خارج الإيواء',
            'آخر نوع مساعدة': i % 2 === 0 ? 'طرد غذائي أساسي' : 'سلة خضار طازجة',
            'تاريخ آخر استلام': `2024-11-${String(10 + (i % 18)).padStart(2, '0')}`,
            'ملاحظات': 'تمت المزامنة من قاعدة بيانات غزة الموحدة'
          });
        }

        setSourceName(`سحابة_المستفيدين_${cloudEndpointUrl.split('/')[2] || 'live'}`);
        setFileExtension('cloud_json');
        setDetectedHeaders(cloudHeaders);
        setRawRows(generatedRows);
        setCitizenMapping(autoDetectCitizenMapping(cloudHeaders));
      }

      setIsCloudConnecting(false);
      setCloudLastSyncTime(new Date().toISOString().replace('T', ' ').slice(0, 19));
      setCurrentStep('mapping');
    }, 850);
  };

  // تحميل نموذج إكسل جاهز وشامل لكافة الحقول دون استثناء
  const handleDownloadTemplate = (type: 'citizens' | 'children' | 'aids' | 'combined_all') => {
    const wb = XLSX.utils.book_new();

    // 1. ورقة المواطنين والأسر (41 حقلاً شاملاً)
    if (type === 'citizens' || type === 'combined_all') {
      const citizenSample = [
        {
          'رقم الأسرة': 1,
          'رقم الهوية الوطنية': '901234561',
          'الاسم رباعي': 'أحمد محمود خليل الأسطل',
          'الجنس': 'ذكر',
          'تاريخ الميلاد': '1980-05-14',
          'العمر': 44,
          'الحالة الاجتماعية': 'متزوج',
          'حالة الوفاة': 'على قيد الحياة',
          'تاريخ الوفاة': '',
          'رقم الجوال الأساسي': '0599123456',
          'جوال بديل 1': '0569123456',
          'جوال بديل 2': '',
          'اسم الزوج / الزوجة': 'فاطمة سليم الأسطل',
          'هوية الزوج / الزوجة': '908765432',
          'عدد أفراد الأسرة': 8,
          'حالة الضرر': 'جزئي بليغ',
          'وصف الضرر': 'تضرر في الجدران والأسقف',
          'حالة الإصابة': 'سليم',
          'تاريخ الإصابة': '',
          'مصدر الدخل 1': 'عمال مياومة',
          'مصدر الدخل 2': '',
          'رقم كرت المؤن': 'UN-123456',
          'المحافظة الأصلية': 'غزة',
          'المنطقة الفرعية الأصلية': 'الشيخ رضوان',
          'الشعبة الأصلية': 'الشعبة الأولى',
          'المسجد الأصلي': 'مسجد الرضوان',
          'المحافظة الحالية': 'غزة',
          'المنطقة الفرعية الحالية': 'الشيخ رضوان',
          'الشعبة الحالية': 'الشعبة الأولى',
          'المسجد الحالي': 'مسجد الرضوان',
          'حالة اعتماد التنمية': 'معتمد',
          'اعتماد المناطق': 'معتمد',
          'صفة الإقامة': 'مقيم',
          'اعتماد الأشغال': 'معتمد',
          'حالة الإيواء': 'خارج الإيواء',
          'مركز / مخيم الإيواء': '',
          'معرف المحلية': 1,
          'اسم المحلية': 'الشيخ رضوان',
          'آخر نوع مساعدة': 'طرد غذائي أساسي',
          'تاريخ آخر مساعدة': '2024-11-10',
          'ملاحظات الأسرة': 'أسرة ذات أولوية مرتفعة'
        },
        {
          'رقم الأسرة': 2,
          'رقم الهوية الوطنية': '902345672',
          'الاسم رباعي': 'محمد عبد الرحمن النجار',
          'الجنس': 'ذكر',
          'تاريخ الميلاد': '1985-09-20',
          'العمر': 39,
          'الحالة الاجتماعية': 'متزوج',
          'حالة الوفاة': 'على قيد الحياة',
          'تاريخ الوفاة': '',
          'رقم الجوال الأساسي': '0599234567',
          'جوال بديل 1': '',
          'جوال بديل 2': '',
          'اسم الزوج / الزوجة': 'مريم خليل النجار',
          'هوية الزوج / الزوجة': '909876543',
          'عدد أفراد الأسرة': 7,
          'حالة الضرر': 'كلي',
          'وصف الضرر': 'تدمير كلي للمنزل',
          'حالة الإصابة': 'جريح حرب',
          'تاريخ الإصابة': '2024-02-10',
          'مصدر الدخل 1': 'بطالة',
          'مصدر الدخل 2': '',
          'رقم كرت المؤن': 'UN-234567',
          'المحافظة الأصلية': 'غزة',
          'المنطقة الفرعية الأصلية': 'الشجاعية',
          'الشعبة الأصلية': 'الشعبة الثالثة',
          'المسجد الأصلي': 'مسجد المحطة',
          'المحافظة الحالية': 'غزة',
          'المنطقة الفرعية الحالية': 'الرمال الشمالي',
          'الشعبة الحالية': 'الشعبة الثانية',
          'المسجد الحالي': 'مسجد اليرموك',
          'حالة اعتماد التنمية': 'معتمد',
          'اعتماد المناطق': 'معتمد',
          'صفة الإقامة': 'نازح',
          'اعتماد الأشغال': 'معتمد',
          'حالة الإيواء': 'إيواء داخلي',
          'مركز / مخيم الإيواء': 'مدرسة إيواء النصر',
          'معرف المحلية': 2,
          'اسم المحلية': 'الرمال الشمالي',
          'آخر نوع مساعدة': 'قسيمة شرائية',
          'تاريخ آخر مساعدة': '2024-11-05',
          'ملاحظات الأسرة': 'نازح من الشجاعية'
        }
      ];
      const wsCit = XLSX.utils.json_to_sheet(citizenSample);
      XLSX.utils.book_append_sheet(wb, wsCit, 'جدول المواطنين والأسر');
    }

    // 2. ورقة الأبناء والتابعين (12 حقلاً شاملاً)
    if (type === 'children' || type === 'combined_all') {
      const childSample = [
        {
          'معرف الابن': 1,
          'رقم أسرة الوالد': 1,
          'رقم هوية رب الأسرة': '901234561',
          'رقم هوية الابن': '410111221',
          'اسم الابن / التابع': 'عمر أحمد محمود الأسطل',
          'الجنس': 'ذكر',
          'العمر (بالسنوات)': 4,
          'تاريخ الميلاد': '2022-03-15',
          'صلة القرابة': 'ابن',
          'المرحلة التعليمية': 'رياض أطفال',
          'الحالة الصحية': 'سليم',
          'ملاحظات خاصة': ''
        },
        {
          'معرف الابن': 2,
          'رقم أسرة الوالد': 1,
          'رقم هوية رب الأسرة': '901234561',
          'رقم هوية الابن': '410111222',
          'اسم الابن / التابع': 'سارة أحمد محمود الأسطل',
          'الجنس': 'أنثى',
          'العمر (بالسنوات)': 2,
          'تاريخ الميلاد': '2024-01-20',
          'صلة القرابة': 'ابنة',
          'المرحلة التعليمية': 'رضيع',
          'الحالة الصحية': 'سليم',
          'ملاحظات خاصة': 'تحتاج حليب أطفال وبامبرز'
        },
        {
          'معرف الابن': 3,
          'رقم أسرة الوالد': 1,
          'رقم هوية رب الأسرة': '901234561',
          'رقم هوية الابن': '410111223',
          'اسم الابن / التابع': 'محمد أحمد محمود الأسطل',
          'الجنس': 'ذكر',
          'العمر (بالسنوات)': 12,
          'تاريخ الميلاد': '2014-06-10',
          'صلة القرابة': 'ابن',
          'المرحلة التعليمية': 'إعدادي',
          'الحالة الصحية': 'مصاب حرب',
          'ملاحظات خاصة': 'إصابة شظايا بالطرف السفلي'
        },
        {
          'معرف الابن': 4,
          'رقم أسرة الوالد': 2,
          'رقم هوية رب الأسرة': '902345672',
          'رقم هوية الابن': '410222331',
          'اسم الابن / التابع': 'يوسف محمد عبد الرحمن النجار',
          'الجنس': 'ذكر',
          'العمر (بالسنوات)': 7,
          'تاريخ الميلاد': '2019-05-12',
          'صلة القرابة': 'ابن',
          'المرحلة التعليمية': 'ابتدائي',
          'الحالة الصحية': 'سليم',
          'ملاحظات خاصة': ''
        }
      ];
      const wsChild = XLSX.utils.json_to_sheet(childSample);
      XLSX.utils.book_append_sheet(wb, wsChild, 'جدول الأبناء والتابعين');
    }

    // 3. ورقة المساعدات والتسليمات (20 حقلاً شاملاً)
    if (type === 'aids' || type === 'combined_all') {
      const aidSample = [
        {
          'كود التسليم': 'DEL-2026-001',
          'رقم أسرة المستفيد': 1,
          'رقم هوية المستفيد': '901234561',
          'اسم المستفيد': 'أحمد محمود خليل الأسطل',
          'رقم المشروع': 'PRJ-2026-04',
          'اسم المشروع': 'مشروع الطرود الغذائية الطارئة',
          'نوع المساعدة': 'طرد غذائي أساسي',
          'قيمة المساعدة (₪)': 150,
          'المستودع المنفذ': 'المستودع المركزي - الشيخ رضوان',
          'الجهة الممولة والمانحة': 'برنامج الأغذية العالمي WFP',
          'تاريخ الاستحقاق المجدول': '2024-11-10',
          'حالة التسليم': 'تم التسليم',
          'تاريخ التسليم الفعلي': '2024-11-10',
          'وقت التسليم': '10:30',
          'الموظف المسلّم': 'خالد صيام',
          'صفة المستلم': 'المستفيد شخصياً',
          'اسم المستلم الفعلي': 'أحمد محمود خليل الأسطل',
          'رقم سند الصرف': 'VOUCH-9941',
          'التحقق من الهوية والتوقيع': 'تم التحقق وتوقيع المستند',
          'ملاحظات التسليم': 'تم التحقق من بطاقة الهوية الرسمية'
        },
        {
          'كود التسليم': 'DEL-2026-002',
          'رقم أسرة المستفيد': 2,
          'رقم هوية المستفيد': '902345672',
          'اسم المستفيد': 'محمد عبد الرحمن النجار',
          'رقم المشروع': 'PRJ-2026-08',
          'اسم المشروع': 'مشروع سلال الخضار الطازجة',
          'نوع المساعدة': 'سلة خضار وفواكه',
          'قيمة المساعدة (₪)': 80,
          'المستودع المنفذ': 'نقطة توزيع الرمال',
          'الجهة الممولة والمانحة': 'الإغاثة الإنسانية الدولية',
          'تاريخ الاستحقاق المجدول': '2024-11-05',
          'حالة التسليم': 'تم التسليم',
          'تاريخ التسليم الفعلي': '2024-11-05',
          'وقت التسليم': '11:15',
          'الموظف المسلّم': 'محمد رضوان',
          'صفة المستلم': 'الزوج / الزوجة',
          'اسم المستلم الفعلي': 'مريم خليل النجار',
          'رقم سند الصرف': 'VOUCH-9942',
          'التحقق من الهوية والتوقيع': 'تم التحقق وتوقيع المستند',
          'ملاحظات التسليم': 'استلمت الزوجة بموجب إثبات العائلة الرسمي'
        }
      ];
      const wsAid = XLSX.utils.json_to_sheet(aidSample);
      XLSX.utils.book_append_sheet(wb, wsAid, 'جدول المساعدات والتسليمات');
    }

    const filename =
      type === 'citizens'
        ? 'نموذج_جدول_المواطنين_الشامل_41_حقلا.xlsx'
        : type === 'children'
        ? 'نموذج_جدول_الأبناء_والتابعين_12_حقلا.xlsx'
        : type === 'aids'
        ? 'نموذج_جدول_المساعدات_والتسليمات_20_حقلا.xlsx'
        : 'نموذج_النظام_الشامل_المتكامل_كافة_الجداول.xlsx';

    XLSX.writeFile(wb, filename);
  };

  // تحميل حزمة بيانات غزة النموذجية التجريبية بنقرة واحدة
  const handleLoadDemoDataset = (mode: DataTargetMode) => {
    setTargetMode(mode);

    if (mode === 'children') {
      const sampleChildren = [
        {
          'معرف الابن': 1,
          'رقم أسرة الوالد': 1,
          'رقم هوية رب الأسرة': '901234561',
          'رقم هوية الابن': '410111221',
          'اسم الابن': 'عمر أحمد محمود الأسطل',
          'الجنس': 'ذكر',
          'العمر': 4,
          'تاريخ الميلاد': '2022-03-15',
          'صلة القرابة': 'ابن',
          'المرحلة التعليمية': 'رياض أطفال',
          'الحالة الصحية': 'سليم',
          'ملاحظات': ''
        },
        {
          'معرف الابن': 2,
          'رقم أسرة الوالد': 1,
          'رقم هوية رب الأسرة': '901234561',
          'رقم هوية الابن': '410111222',
          'اسم الابن': 'سارة أحمد محمود الأسطل',
          'الجنس': 'أنثى',
          'العمر': 2,
          'تاريخ الميلاد': '2024-01-20',
          'صلة القرابة': 'ابنة',
          'المرحلة التعليمية': 'رضيع',
          'الحالة الصحية': 'سليم',
          'ملاحظات': 'تحتاج حليب وبامبرز'
        },
        {
          'معرف الابن': 3,
          'رقم أسرة الوالد': 1,
          'رقم هوية رب الأسرة': '901234561',
          'رقم هوية الابن': '410111223',
          'اسم الابن': 'محمد أحمد محمود الأسطل',
          'الجنس': 'ذكر',
          'العمر': 12,
          'تاريخ الميلاد': '2014-06-10',
          'صلة القرابة': 'ابن',
          'المرحلة التعليمية': 'إعدادي',
          'الحالة الصحية': 'مصاب حرب',
          'ملاحظات': 'إصابة شظايا بالطرف السفلي'
        },
        {
          'معرف الابن': 4,
          'رقم أسرة الوالد': 2,
          'رقم هوية رب الأسرة': '902345672',
          'رقم هوية الابن': '410222331',
          'اسم الابن': 'يوسف محمد عبد الرحمن النجار',
          'الجنس': 'ذكر',
          'العمر': 7,
          'تاريخ الميلاد': '2019-05-12',
          'صلة القرابة': 'ابن',
          'المرحلة التعليمية': 'ابتدائي',
          'الحالة الصحية': 'سليم',
          'ملاحظات': ''
        },
        {
          'معرف الابن': 5,
          'رقم أسرة الوالد': 2,
          'رقم هوية رب الأسرة': '902345672',
          'رقم هوية الابن': '410222332',
          'اسم الابن': 'تسنيم محمد عبد الرحمن النجار',
          'الجنس': 'أنثى',
          'العمر': 1,
          'تاريخ الميلاد': '2025-02-14',
          'صلة القرابة': 'ابنة',
          'المرحلة التعليمية': 'رضيع',
          'الحالة الصحية': 'سليم',
          'ملاحظات': ''
        },
        {
          'معرف الابن': 6,
          'رقم أسرة الوالد': 3,
          'رقم هوية رب الأسرة': '903456783',
          'رقم هوية الابن': '410333441',
          'اسم الابن': 'كريم خالد إبراهيم بربخ',
          'الجنس': 'ذكر',
          'العمر': 3,
          'تاريخ الميلاد': '2023-04-10',
          'صلة القرابة': 'ابن',
          'المرحلة التعليمية': 'رياض أطفال',
          'الحالة الصحية': 'سليم',
          'ملاحظات': ''
        },
        {
          'معرف الابن': 7,
          'رقم أسرة الوالد': 3,
          'رقم هوية رب الأسرة': '903456783',
          'رقم هوية الابن': '410333442',
          'اسم الابن': 'محمود خالد إبراهيم بربخ',
          'الجنس': 'ذكر',
          'العمر': 13,
          'تاريخ الميلاد': '2013-07-15',
          'صلة القرابة': 'ابن',
          'المرحلة التعليمية': 'إعدادي',
          'الحالة الصحية': 'مصاب حرب',
          'ملاحظات': 'إصابة بالغة في العين'
        },
        {
          'معرف الابن': 8,
          'رقم أسرة الوالد': 10,
          'رقم هوية رب الأسرة': '910123450',
          'رقم هوية الابن': '411000111',
          'اسم الابن': 'يحيى علاء الدين صقر',
          'الجنس': 'ذكر',
          'العمر': 14,
          'تاريخ الميلاد': '2012-05-15',
          'صلة القرابة': 'ابن',
          'المرحلة التعليمية': 'إعدادي',
          'الحالة الصحية': 'سليم',
          'ملاحظات': 'يتيم ابن شهيد'
        }
      ];

      const headers = Object.keys(sampleChildren[0]);
      setSourceName('كشف_الأبناء_والتابعين_النموذجي.xlsx');
      setFileExtension('xlsx');
      setDetectedHeaders(headers);
      setRawRows(sampleChildren);
      setChildMapping(autoDetectChildMapping(headers));
    } else if (mode === 'citizens') {
      const sampleCitizens = [
        {
          'رقم الأسرة': 1,
          'رقم الهوية الوطنية': '901234561',
          'الاسم رباعي': 'أحمد محمود خليل الأسطل',
          'الجنس': 'ذكر',
          'تاريخ الميلاد': '1980-05-14',
          'العمر': 44,
          'الحالة الاجتماعية': 'متزوج',
          'حالة الوفاة': 'على قيد الحياة',
          'رقم الجوال الأساسي': '0599123456',
          'جوال بديل 1': '0569123456',
          'اسم الزوج / الزوجة': 'فاطمة الأسطل',
          'هوية الزوج / الزوجة': '908765432',
          'عدد أفراد الأسرة': 8,
          'حالة الضرر': 'جزئي بليغ',
          'وصف الضرر': 'تضرر بالأسقف',
          'حالة الإصابة': 'سليم',
          'مصدر الدخل 1': 'عمال مياومة',
          'رقم كرت المؤن': 'UN-123456',
          'المحافظة الأصلية': 'غزة',
          'المنطقة الفرعية الأصلية': 'الشيخ رضوان',
          'الشعبة الأصلية': 'الشعبة الأولى',
          'المسجد الأصلي': 'مسجد الرضوان',
          'المحافظة الحالية': 'غزة',
          'المنطقة الفرعية الحالية': 'الشيخ رضوان',
          'الشعبة الحالية': 'الشعبة الأولى',
          'المسجد الحالي': 'مسجد الرضوان',
          'حالة اعتماد التنمية': 'معتمد',
          'اعتماد المناطق': 'معتمد',
          'صفة الإقامة': 'مقيم',
          'اعتماد الأشغال': 'معتمد',
          'حالة الإيواء': 'خارج الإيواء',
          'آخر نوع مساعدة': 'طرد غذائي أساسي',
          'تاريخ آخر مساعدة': '2024-11-10',
          'ملاحظات الأسرة': 'أسرة ذات أولوية'
        },
        {
          'رقم الأسرة': 2,
          'رقم الهوية الوطنية': '902345672',
          'الاسم رباعي': 'محمد عبد الرحمن النجار',
          'الجنس': 'ذكر',
          'تاريخ الميلاد': '1985-09-20',
          'العمر': 39,
          'الحالة الاجتماعية': 'متزوج',
          'حالة الوفاة': 'على قيد الحياة',
          'رقم الجوال الأساسي': '0599234567',
          'اسم الزوج / الزوجة': 'مريم النجار',
          'هوية الزوج / الزوجة': '909876543',
          'عدد أفراد الأسرة': 7,
          'حالة الضرر': 'كلي',
          'وصف الضرر': 'تدمير كامل',
          'حالة الإصابة': 'جريح حرب',
          'مصدر الدخل 1': 'بطالة',
          'رقم كرت المؤن': 'UN-234567',
          'المحافظة الأصلية': 'غزة',
          'المنطقة الفرعية الأصلية': 'الشجاعية',
          'الشعبة الأصلية': 'الشعبة الثالثة',
          'المسجد الأصلي': 'مسجد المحطة',
          'المحافظة الحالية': 'غزة',
          'المنطقة الفرعية الحالية': 'الرمال الشمالي',
          'الشعبة الحالية': 'الشعبة الثانية',
          'المسجد الحالي': 'مسجد اليرموك',
          'حالة اعتماد التنمية': 'معتمد',
          'اعتماد المناطق': 'معتمد',
          'صفة الإقامة': 'نازح',
          'اعتماد الأشغال': 'معتمد',
          'حالة الإيواء': 'إيواء داخلي',
          'مركز / مخيم الإيواء': 'مدرسة إيواء النصر',
          'آخر نوع مساعدة': 'قسيمة شرائية',
          'تاريخ آخر مساعدة': '2024-11-05',
          'ملاحظات الأسرة': 'نازح من الشجاعية'
        },
        {
          'رقم الأسرة': 3,
          'رقم الهوية الوطنية': '903456783',
          'الاسم رباعي': 'خالد إبراهيم سليم بربخ',
          'الجنس': 'ذكر',
          'تاريخ الميلاد': '1978-03-11',
          'العمر': 46,
          'الحالة الاجتماعية': 'متزوج',
          'حالة الوفاة': 'على قيد الحياة',
          'رقم الجوال الأساسي': '0599345678',
          'اسم الزوج / الزوجة': 'إلهام بربخ',
          'هوية الزوج / الزوجة': '910987654',
          'عدد أفراد الأسرة': 9,
          'حالة الضرر': 'جزئي بليغ',
          'حالة الإصابة': 'سليم',
          'مصدر الدخل 1': 'عمال مياومة',
          'رقم كرت المؤن': 'UN-345678',
          'المحافظة الحالية': 'غزة',
          'المنطقة الفرعية الحالية': 'الشاطئ الشمالي والنصر',
          'المسجد الحالي': 'مسجد الشهداء',
          'حالة اعتماد التنمية': 'معتمد',
          'صفة الإقامة': 'مقيم',
          'حالة الإيواء': 'خارج الإيواء',
          'آخر نوع مساعدة': 'وجبة ساخنة جاهزة',
          'تاريخ آخر مساعدة': '2024-11-12'
        },
        {
          'رقم الأسرة': 10,
          'رقم الهوية الوطنية': '910123450',
          'الاسم رباعي': 'خلود إسماعيل صقر (معيلة أيتام)',
          'الجنس': 'أنثى',
          'تاريخ الميلاد': '1986-06-18',
          'العمر': 38,
          'الحالة الاجتماعية': 'أرملة',
          'حالة الوفاة': 'على قيد الحياة',
          'رقم الجوال الأساسي': '0599012345',
          'اسم الزوج / الزوجة': 'الشهيد علاء الدين صقر',
          'هوية الزوج / الزوجة': '901999888',
          'عدد أفراد الأسرة': 6,
          'حالة الضرر': 'كلي',
          'حالة الإصابة': 'سليم',
          'مصدر الدخل 1': 'شؤون وكفالة أيتام',
          'رقم كرت المؤن': 'UN-012345',
          'المحافظة الحالية': 'غزة',
          'المنطقة الفرعية الحالية': 'الشيخ رضوان',
          'المسجد الحالي': 'مسجد التقوى',
          'حالة اعتماد التنمية': 'مجمد',
          'صفة الإقامة': 'مقيم',
          'حالة الإيواء': 'خارج الإيواء',
          'آخر نوع مساعدة': 'كفالة أيتام ونقدية',
          'تاريخ آخر مساعدة': '2024-10-15',
          'ملاحظات الأسرة': 'أرملة شهيد ترعى 5 أيتام'
        }
      ];

      const headers = Object.keys(sampleCitizens[0]);
      setSourceName('كشف_المواطنين_الشامل_النموذجي.xlsx');
      setFileExtension('xlsx');
      setDetectedHeaders(headers);
      setRawRows(sampleCitizens);
      setCitizenMapping(autoDetectCitizenMapping(headers));
    } else if (mode === 'aids') {
      const sampleAids = [
        {
          'كود التسليم': 'DEL-2026-101',
          'رقم أسرة المستفيد': 1,
          'رقم هوية المستفيد': '901234561',
          'اسم المستفيد': 'أحمد محمود خليل الأسطل',
          'رقم المشروع': 'PRJ-GZ-2026',
          'اسم المشروع': 'مشروع الإغاثة الغذائية الموحدة',
          'نوع المساعدة': 'طرد غذائي أساسي',
          'قيمة المساعدة (₪)': 160,
          'المستودع المنفذ': 'المستودع المركزي - الشيخ رضوان',
          'الجهة الممولة والمانحة': 'مركز الملك سلمان للإغاثة',
          'تاريخ الاستحقاق المجدول': '2024-11-14',
          'حالة التسليم': 'تم التسليم',
          'تاريخ التسليم الفعلي': '2024-11-14',
          'الموظف المسلّم': 'أمين المستودع الرئيسي',
          'صفة المستلم': 'المستفيد شخصياً',
          'اسم المستلم الفعلي': 'أحمد محمود خليل الأسطل',
          'رقم سند الصرف': 'VOUCH-881'
        },
        {
          'كود التسليم': 'DEL-2026-102',
          'رقم أسرة المستفيد': 2,
          'رقم هوية المستفيد': '902345672',
          'اسم المستفيد': 'محمد عبد الرحمن النجار',
          'رقم المشروع': 'PRJ-GZ-2026',
          'اسم المشروع': 'مشروع الإغاثة الغذائية الموحدة',
          'نوع المساعدة': 'سلة خضار طازجة',
          'قيمة المساعدة (₪)': 75,
          'المستودع المنفذ': 'نقطة توزيع الرمال',
          'الجهة الممولة والمانحة': 'الهلال الأحمر الفلسطيني',
          'تاريخ الاستحقاق المجدول': '2024-11-13',
          'حالة التسليم': 'تم التسليم',
          'تاريخ التسليم الفعلي': '2024-11-13',
          'الموظف المسلّم': 'محمد رضوان',
          'صفة المستلم': 'الزوج / الزوجة',
          'اسم المستلم الفعلي': 'مريم خليل النجار',
          'رقم سند الصرف': 'VOUCH-882'
        }
      ];

      const headers = Object.keys(sampleAids[0]);
      setSourceName('كشف_تسليمات_المساعدات_الحديثة.xlsx');
      setFileExtension('xlsx');
      setDetectedHeaders(headers);
      setRawRows(sampleAids);
      setAidMapping(autoDetectAidMapping(headers));
    } else {
      // وضع مدمج شامل لكافة الجداول
      const combinedSample = [
        {
          'رقم الهوية الوطنية': '901234561',
          'اسم رب الأسرة': 'أحمد محمود خليل الأسطل',
          'رقم الجوال الأساسي': '0599123456',
          'المنطقة الفرعية الحالية': 'الشيخ رضوان',
          'المسجد الحالي': 'مسجد الرضوان',
          'عدد أفراد الأسرة': 8,
          'حالة اعتماد التنمية': 'معتمد',
          'صفة الإقامة': 'مقيم',
          'اسم الابن': 'عمر أحمد محمود الأسطل',
          'هوية الابن': '410111221',
          'عمر الابن': 4,
          'اسم المشروع': 'مشروع الإغاثة الشامل',
          'نوع المساعدة': 'طرد غذائي أساسي',
          'قيمة المساعدة (₪)': 150,
          'المستودع المنفذ': 'المستودع المركزي',
          'تاريخ التسليم الفعلي': '2024-11-10'
        },
        {
          'رقم الهوية الوطنية': '902345672',
          'اسم رب الأسرة': 'محمد عبد الرحمن النجار',
          'رقم الجوال الأساسي': '0599234567',
          'المنطقة الفرعية الحالية': 'الرمال الشمالي',
          'المسجد الحالي': 'مسجد اليرموك',
          'عدد أفراد الأسرة': 7,
          'حالة اعتماد التنمية': 'معتمد',
          'صفة الإقامة': 'نازح',
          'اسم الابن': 'يوسف محمد النجار',
          'هوية الابن': '410222331',
          'عمر الابن': 7,
          'اسم المشروع': 'مشروع سلال الخضار',
          'نوع المساعدة': 'سلة خضار وفواكه',
          'قيمة المساعدة (₪)': 80,
          'المستودع المنفذ': 'نقطة الرمال',
          'تاريخ التسليم الفعلي': '2024-11-05'
        }
      ];

      const headers = Object.keys(combinedSample[0]);
      setSourceName('الكشف_الشامل_المدمج_مواطنين_أبناء_مساعدات.xlsx');
      setFileExtension('xlsx');
      setDetectedHeaders(headers);
      setRawRows(combinedSample);
      setCitizenMapping(autoDetectCitizenMapping(headers));
      setChildMapping(autoDetectChildMapping(headers));
      setAidMapping(autoDetectAidMapping(headers));
    }

    setCurrentStep('mapping');
  };

  // معالجة الانتقال إلى مرحلة المعاينة والتدقيق
  const handleProceedToPreview = () => {
    if (targetMode === 'citizens' || targetMode === 'combined_all') {
      if (!citizenMapping.nationalID || !citizenMapping.name) {
        alert('يرجى تحديد عمودي (رقم الهوية) و (الاسم رباعي) للمواطنين على الأقل للاستمرار.');
        return;
      }
    }

    if (targetMode === 'children') {
      if (!childMapping.parentNationalID && !childMapping.familyID) {
        alert('يرجى تحديد عمود (رقم هوية رب الأسرة) أو (رقم أسرة الوالد) لربط الأبناء بآبائهم.');
        return;
      }
      if (!childMapping.name) {
        alert('يرجى تحديد عمود (اسم الابن / التابع) على الأقل للاستمرار.');
        return;
      }
    }

    if (targetMode === 'aids') {
      if (!aidMapping.receiverNationalId && !aidMapping.familyId) {
        alert('يرجى تحديد عمود (رقم هوية المستفيد) لربط كشوف المساعدات بملفات المواطنين.');
        return;
      }
      if (!aidMapping.aidTypeName) {
        alert('يرجى تحديد عمود (نوع أو صنف المساعدة) على الأقل للاستمرار.');
        return;
      }
    }

    setCurrentStep('preview');
  };

  // حساب إحصائيات المعاينة المسبقة (Dry Run Analysis)
  const previewAnalysis = useMemo(() => {
    const existingFamiliesMap = new Map<string, MockFamily>();
    currentFamilies.forEach(f => existingFamiliesMap.set(f.nationalID.trim(), f));

    const existingChildrenMap = new Map<string, MockChild>();
    currentChildren.forEach(c => {
      if (c.nationalID) existingChildrenMap.set(c.nationalID.trim(), c);
      else existingChildrenMap.set(`${c.parentNationalID}_${c.name}`, c);
    });

    let validRows = 0;
    let existingUpdates = 0;
    let newEntries = 0;
    let errorRows = 0;
    let duplicateInFileCount = 0;
    let linkedCount = 0;
    let unlinkedCount = 0;

    const seenIdsInFile = new Set<string>();

    const rowStatuses: {
      index: number;
      id: string;
      name: string;
      secondaryId?: string;
      status: 'new' | 'update' | 'error';
      errorReason?: string;
      isLinked: boolean;
      data: any;
    }[] = [];

    rawRows.forEach((row, idx) => {
      if (targetMode === 'children') {
        const parentId = String(row[childMapping.parentNationalID] || '').replace(/\D/g, '').trim();
        const childId = String(row[childMapping.nationalID] || '').replace(/\D/g, '').trim();
        const childName = String(row[childMapping.name] || '').trim();

        if (!parentId && !row[childMapping.familyID]) {
          errorRows++;
          rowStatuses.push({
            index: idx,
            id: childId || 'مجهول',
            name: childName || 'غير محدد',
            status: 'error',
            errorReason: 'رقم هوية الوالد أو رقم الأسرة مفقود',
            isLinked: false,
            data: row
          });
          return;
        }

        const isParentInSystem = existingFamiliesMap.has(parentId);
        const childKey = childId || `${parentId}_${childName}`;
        const isChildExists = existingChildrenMap.has(childKey);

        if (isChildExists) {
          existingUpdates++;
          rowStatuses.push({
            index: idx,
            id: childId || `ابن_${idx + 1}`,
            name: childName,
            secondaryId: parentId,
            status: 'update',
            isLinked: isParentInSystem,
            data: row
          });
        } else {
          newEntries++;
          rowStatuses.push({
            index: idx,
            id: childId || `ابن_${idx + 1}`,
            name: childName,
            secondaryId: parentId,
            status: 'new',
            isLinked: isParentInSystem,
            data: row
          });
        }

        if (isParentInSystem) linkedCount++;
        else unlinkedCount++;
        validRows++;
        return;
      }

      if (targetMode === 'aids') {
        const id = String(row[aidMapping.receiverNationalId] || '').replace(/\D/g, '').trim();
        const name = String(row[aidMapping.receiverName] || '').trim();

        if (!id || id.length < 8) {
          errorRows++;
          rowStatuses.push({
            index: idx,
            id: id || 'مفقود',
            name: name || 'غير محدد',
            status: 'error',
            errorReason: 'رقم هوية المستفيد غير صالح أو مفقود',
            isLinked: false,
            data: row
          });
          return;
        }

        const existsInSystem = existingFamiliesMap.has(id);
        if (existsInSystem) {
          linkedCount++;
          rowStatuses.push({
            index: idx,
            id,
            name: name || existingFamiliesMap.get(id)?.name || '',
            status: 'update',
            isLinked: true,
            data: row
          });
          existingUpdates++;
        } else {
          unlinkedCount++;
          rowStatuses.push({
            index: idx,
            id,
            name: name || `مستفيد جديد ${idx + 1}`,
            status: 'new',
            isLinked: false,
            data: row
          });
          newEntries++;
        }
        validRows++;
        return;
      }

      // وضع المواطنين أو المشترك
      const id = String(row[citizenMapping.nationalID] || '').replace(/\D/g, '').trim();
      const name = String(row[citizenMapping.name] || '').trim();

      if (!id || id.length < 8) {
        errorRows++;
        rowStatuses.push({
          index: idx,
          id: id || 'مفقود',
          name: name || 'غير محدد',
          status: 'error',
          errorReason: 'رقم الهوية غير مكتمل أو فارغ',
          isLinked: false,
          data: row
        });
        return;
      }

      if (seenIdsInFile.has(id)) {
        duplicateInFileCount++;
      } else {
        seenIdsInFile.add(id);
      }

      const existsInSystem = existingFamiliesMap.has(id);
      if (existsInSystem) {
        existingUpdates++;
        rowStatuses.push({
          index: idx,
          id,
          name: name || existingFamiliesMap.get(id)?.name || '',
          status: 'update',
          isLinked: true,
          data: row
        });
      } else {
        newEntries++;
        rowStatuses.push({
          index: idx,
          id,
          name: name || `سجل جديد ${idx + 1}`,
          status: 'new',
          isLinked: false,
          data: row
        });
      }
      validRows++;
    });

    return {
      validRows,
      existingUpdates,
      newEntries,
      errorRows,
      duplicateInFileCount,
      linkedCount,
      unlinkedCount,
      rowStatuses
    };
  }, [rawRows, targetMode, citizenMapping, childMapping, aidMapping, currentFamilies, currentChildren]);

  // تنفيذ عملية الربط الحقيقية الشاملة لكافة الجداول والحقول (Execution Engine)
  const executeDataLinking = () => {
    setIsExecuting(true);
    setCurrentStep('executing');
    setProgressPercent(10);
    setProgressStatusText('جاري فحص وتدقيق أرقام الهويات الوطنية والتحقق من عدم التكرار...');

    setTimeout(() => {
      setProgressPercent(35);
      setProgressStatusText('جاري مطابقة السجلات مع قاعدة البيانات الميدانية وفصل جداول الأسر والأبناء والمساعدات...');

      setTimeout(() => {
        setProgressPercent(70);
        setProgressStatusText('جاري ربط العلاقات الأسرية وتحديث كشوف الأبناء والتسليم وتطبيق استراتيجية الدمج...');

        setTimeout(() => {
          let citizensAdded = 0;
          let citizensUpdated = 0;
          let childrenAdded = 0;
          let childrenUpdated = 0;
          let aidsAdded = 0;
          let skippedCount = 0;

          const existingFamiliesMap = new Map<string, MockFamily>();
          currentFamilies.forEach(f => existingFamiliesMap.set(f.nationalID.trim(), f));

          const finalFamiliesMap = new Map<string, MockFamily>();
          if (mergeMode !== 'replace') {
            currentFamilies.forEach(f => finalFamiliesMap.set(f.nationalID.trim(), { ...f }));
          }

          const existingChildrenList = mergeMode === 'replace' ? [] : [...currentChildren];
          const finalChildrenMap = new Map<string, MockChild>();
          existingChildrenList.forEach(c => {
            const key = c.nationalID ? c.nationalID.trim() : `${c.parentNationalID.trim()}_${c.name.trim()}`;
            finalChildrenMap.set(key, { ...c });
          });

          const finalDeliveries: DeliveryRecord[] =
            mergeMode === 'replace' ? [] : currentDeliveries.map(d => ({ ...d }));

          const todayStr = new Date().toISOString().split('T')[0];
          let runningFamId = Math.max(...currentFamilies.map(f => f.familyID), 100);
          let runningChildId = Math.max(...currentChildren.map(c => c.id), 100);

          rawRows.forEach((row, idx) => {
            // ================= 1. معالجة جدول الأبناء والتابعين =================
            if (targetMode === 'children') {
              const parentId = String(row[childMapping.parentNationalID] || '').replace(/\D/g, '').trim();
              const rawChildId = String(row[childMapping.nationalID] || '').replace(/\D/g, '').trim();
              const childName = String(row[childMapping.name] || `ابن_${idx + 1}`).trim();

              if (!parentId && !row[childMapping.familyID]) {
                skippedCount++;
                return;
              }

              let fam = finalFamiliesMap.get(parentId) || existingFamiliesMap.get(parentId);

              // إذا لم يكن الوالد مسجلاً وكان خيار التوليد التلقائي مفعل
              if (!fam && autoCreateMissingCitizens && parentId) {
                runningFamId++;
                citizensAdded++;
                const newFam: MockFamily = {
                  familyID: runningFamId,
                  nationalID: parentId,
                  name: `رب أسرة هوية ${parentId}`,
                  gender: 'ذكر',
                  birthDate: '1982-01-01',
                  age: 44,
                  maritalStatus: 'متزوج',
                  deathStatus: 'على قيد الحياة',
                  primaryPhone: '0590000000',
                  membersCount: 4,
                  damageType: 'جزئي صالح للسكن',
                  injuryStatus: 'سليم',
                  incomeSource1: 'عمال مياومة',
                  rationCardNumber: `UN-${parentId.slice(-6)}`,
                  originalMainArea: 'غزة',
                  originalSubArea: 'الشيخ رضوان',
                  originalBranch: 'الشعبة الأولى',
                  originalMosque: 'مسجد الرضوان',
                  currentMainArea: 'غزة',
                  currentSubArea: 'الشيخ رضوان',
                  currentBranch: 'الشعبة الأولى',
                  currentMosque: 'مسجد الرضوان',
                  developmentApproval: 'معتمد',
                  localityApproval: 'معتمد',
                  residentStatus: 'مقيم',
                  worksApproval: 'معتمد',
                  shelterStatus: 'خارج الإيواء',
                  localityID: 1,
                  localityName: 'الشيخ رضوان'
                };
                finalFamiliesMap.set(parentId, newFam);
                fam = newFam;
              }

              const famIdToUse = fam ? fam.familyID : parseInt(String(row[childMapping.familyID] || '1'), 10) || 1;
              const childKey = rawChildId || `${parentId}_${childName}`;
              const existingChild = finalChildrenMap.get(childKey);

              const childAge = childMapping.age ? parseInt(String(row[childMapping.age] || '5').replace(/\D/g, ''), 10) || 5 : 5;
              const childGender = (row[childMapping.gender] as any) || (childName.includes('ة') || childName.includes('منى') || childName.includes('فاطمة') ? 'أنثى' : 'ذكر');
              const childRel = (row[childMapping.relation] as any) || (childGender === 'ذكر' ? 'ابن' : 'ابنة');
              const childBirth = String(row[childMapping.birthDate] || '').trim();
              const childEdu = (row[childMapping.educationLevel] as any) || (childAge < 5 ? 'دون سن الدراسة' : childAge <= 11 ? 'ابتدائي' : childAge <= 15 ? 'إعدادي' : 'ثانوي');
              const childHealth = (row[childMapping.healthStatus] as any) || 'سليم';
              const childNotes = String(row[childMapping.notes] || '').trim();

              if (existingChild) {
                if (mergeMode === 'append') {
                  skippedCount++;
                  return;
                }
                childrenUpdated++;
                finalChildrenMap.set(childKey, {
                  ...existingChild,
                  name: childName || existingChild.name,
                  age: childAge || existingChild.age,
                  gender: childGender || existingChild.gender,
                  birthDate: childBirth || existingChild.birthDate,
                  relation: childRel || existingChild.relation,
                  educationLevel: childEdu || existingChild.educationLevel,
                  healthStatus: childHealth || existingChild.healthStatus,
                  notes: childNotes || existingChild.notes
                });
              } else {
                childrenAdded++;
                runningChildId++;
                finalChildrenMap.set(childKey, {
                  id: runningChildId,
                  familyID: famIdToUse,
                  parentNationalID: parentId,
                  nationalID: rawChildId || `410${String(100000 + runningChildId * 3).slice(0, 6)}`,
                  name: childName,
                  gender: childGender,
                  age: childAge,
                  birthDate: childBirth,
                  relation: childRel,
                  educationLevel: childEdu,
                  healthStatus: childHealth,
                  notes: childNotes
                });
              }

              // تحديث عدد أفراد الأسرة تلقائياً إن كان الخيار مفعلاً
              if (fam && autoUpdateFamilyMemberCount) {
                fam.membersCount = Math.max(fam.membersCount, 2 + childrenAdded);
                finalFamiliesMap.set(fam.nationalID, { ...fam });
              }
              return;
            }

            // ================= 2. معالجة جدول المساعدات والتسليمات =================
            if (targetMode === 'aids') {
              const rawId = String(row[aidMapping.receiverNationalId] || '').replace(/\D/g, '').trim();
              if (!rawId || rawId.length < 8) {
                skippedCount++;
                return;
              }

              let fam = finalFamiliesMap.get(rawId) || existingFamiliesMap.get(rawId);

              if (!fam && autoCreateMissingCitizens) {
                runningFamId++;
                citizensAdded++;
                const createdFam: MockFamily = {
                  familyID: runningFamId,
                  nationalID: rawId,
                  name: String(row[aidMapping.receiverName] || `مستفيد هوية ${rawId}`).trim(),
                  gender: 'ذكر',
                  birthDate: '1982-01-01',
                  age: 44,
                  maritalStatus: 'متزوج',
                  deathStatus: 'على قيد الحياة',
                  primaryPhone: '0590000000',
                  membersCount: 5,
                  damageType: 'جزئي صالح للسكن',
                  injuryStatus: 'سليم',
                  incomeSource1: 'عمال مياومة',
                  rationCardNumber: `UN-${rawId.slice(-6)}`,
                  originalMainArea: 'غزة',
                  originalSubArea: 'الشيخ رضوان',
                  originalBranch: 'الشعبة الأولى',
                  originalMosque: 'مسجد الرضوان',
                  currentMainArea: 'غزة',
                  currentSubArea: 'الشيخ رضوان',
                  currentBranch: 'الشعبة الأولى',
                  currentMosque: 'مسجد الرضوان',
                  developmentApproval: 'معتمد',
                  localityApproval: 'معتمد',
                  residentStatus: 'مقيم',
                  worksApproval: 'معتمد',
                  shelterStatus: 'خارج الإيواء',
                  localityID: 1,
                  localityName: 'الشيخ رضوان',
                  lastAidType: String(row[aidMapping.aidTypeName] || 'طرد غذائي').trim(),
                  lastAidDate: String(row[aidMapping.deliveryDate] || todayStr).trim()
                };
                finalFamiliesMap.set(rawId, createdFam);
                fam = createdFam;
              }

              if (!fam) {
                skippedCount++;
                return;
              }

              const aidType = String(row[aidMapping.aidTypeName] || 'طرد غذائي أساسي').trim();
              const delDate = String(row[aidMapping.deliveryDate] || todayStr).trim();
              const projName = String(row[aidMapping.projectName] || 'مشروع الإغاثة العاجلة').trim();
              const projNum = String(row[aidMapping.projectNumber] || `PRJ-${Date.now().toString().slice(-4)}`).trim();
              const aidVal = parseFloat(String(row[aidMapping.aidValue] || '150').replace(/[^\d.]/g, '')) || 150;
              const warehouse = String(row[aidMapping.warehouse] || 'المستودع الرئيسي').trim();
              const donor = String(row[aidMapping.fundingOrg] || 'منظمة الإغاثة الإنسانية').trim();

              aidsAdded++;
              finalDeliveries.push({
                id: String(row[aidMapping.deliveryId] || `DEL-${Date.now().toString().slice(-5)}-${aidsAdded}`),
                familyId: fam.familyID,
                family: fam,
                projectNumber: projNum,
                projectName: projName,
                aidTypeName: aidType,
                aidValue: aidVal,
                warehouse: warehouse,
                fundingOrg: donor,
                dueDistributionDate: delDate,
                deliveryDate: delDate,
                deliveryTime: String(row[aidMapping.deliveryTime] || '10:30').trim(),
                deliveredByStaff: String(row[aidMapping.deliveredByStaff] || currentUser?.fullName || 'أمين المستودع').trim(),
                receiverType: (row[aidMapping.receiverType] as any) || 'المستفيد شخصياً',
                receiverName: String(row[aidMapping.receiverName] || fam.name).trim(),
                receiverNationalId: fam.nationalID,
                receiptVoucherNumber: String(row[aidMapping.receiptVoucherNumber] || `REC-${aidsAdded}`).trim(),
                signatureVerified: Boolean(row[aidMapping.signatureVerified] || true),
                status: (row[aidMapping.status] as any) || 'تم التسليم',
                deliveryNotes: String(row[aidMapping.deliveryNotes] || 'تم الربط والمزامنة الآلية بنجاح').trim()
              });

              fam.lastAidType = aidType;
              fam.lastAidDate = delDate;
              finalFamiliesMap.set(rawId, { ...fam });
              return;
            }

            // ================= 3. معالجة جدول المواطنين أو الوضع المشترك =================
            const rawId = String(row[citizenMapping.nationalID] || '').replace(/\D/g, '').trim();
            if (!rawId || rawId.length < 8) {
              skippedCount++;
              return;
            }

            const rawName = String(row[citizenMapping.name] || `مستفيد رقم ${idx + 1}`).trim();
            const rawPhone = citizenMapping.primaryPhone ? String(row[citizenMapping.primaryPhone] || '').trim() : '0590000000';
            const rawAltPhone1 = citizenMapping.alternativePhone1 ? String(row[citizenMapping.alternativePhone1] || '').trim() : '';
            const rawAltPhone2 = citizenMapping.alternativePhone2 ? String(row[citizenMapping.alternativePhone2] || '').trim() : '';
            const rawArea = citizenMapping.currentSubArea ? String(row[citizenMapping.currentSubArea] || 'الشيخ رضوان').trim() : 'الشيخ رضوان';
            const rawMainArea = citizenMapping.currentMainArea ? String(row[citizenMapping.currentMainArea] || 'غزة').trim() : 'غزة';
            const rawMosque = citizenMapping.currentMosque ? String(row[citizenMapping.currentMosque] || 'مسجد مركزي').trim() : 'مسجد مركزي';
            const rawBranch = citizenMapping.currentBranch ? String(row[citizenMapping.currentBranch] || 'الشعبة الأولى').trim() : 'الشعبة الأولى';
            const rawMembers = citizenMapping.membersCount ? Math.max(1, parseInt(String(row[citizenMapping.membersCount] || '5').replace(/\D/g, ''), 10) || 5) : 5;
            const rawDev = citizenMapping.developmentApproval ? String(row[citizenMapping.developmentApproval] || 'معتمد').trim() : 'معتمد';
            const rawRes = citizenMapping.residentStatus ? String(row[citizenMapping.residentStatus] || 'مقيم').trim() : 'مقيم';
            const rawWorks = citizenMapping.worksApproval ? String(row[citizenMapping.worksApproval] || 'معتمد').trim() : 'معتمد';
            const rawShelter = citizenMapping.shelterStatus ? String(row[citizenMapping.shelterStatus] || 'خارج الإيواء').trim() : 'خارج الإيواء';
            const rawCamp = citizenMapping.campOrCenterName ? String(row[citizenMapping.campOrCenterName] || '').trim() : '';
            const rawWifeId = citizenMapping.wifeNationalID ? String(row[citizenMapping.wifeNationalID] || '').trim() : '';
            const rawWifeName = citizenMapping.wifeName ? String(row[citizenMapping.wifeName] || '').trim() : '';
            const rawDamage = citizenMapping.damageType ? String(row[citizenMapping.damageType] || 'جزئي صالح للسكن').trim() : 'جزئي صالح للسكن';
            const rawDamageDesc = citizenMapping.damageDescription ? String(row[citizenMapping.damageDescription] || '').trim() : '';
            const rawInjury = citizenMapping.injuryStatus ? String(row[citizenMapping.injuryStatus] || 'سليم').trim() : 'سليم';
            const rawInjuryDate = citizenMapping.injuryDate ? String(row[citizenMapping.injuryDate] || '').trim() : '';
            const rawIncome = citizenMapping.incomeSource1 ? String(row[citizenMapping.incomeSource1] || 'عمال مياومة').trim() : 'عمال مياومة';
            const rawIncome2 = citizenMapping.incomeSource2 ? String(row[citizenMapping.incomeSource2] || '').trim() : '';
            const rawRation = citizenMapping.rationCardNumber ? String(row[citizenMapping.rationCardNumber] || `UN-${rawId.slice(-6)}`).trim() : `UN-${rawId.slice(-6)}`;
            const rawAidType = citizenMapping.lastAidType ? String(row[citizenMapping.lastAidType] || '').trim() : '';
            const rawAidDate = citizenMapping.lastAidDate ? String(row[citizenMapping.lastAidDate] || '').trim() : '';
            const rawNotes = citizenMapping.notes ? String(row[citizenMapping.notes] || '').trim() : '';

            const exists = existingFamiliesMap.get(rawId);

            if (exists) {
              if (mergeMode === 'append') {
                skippedCount++;
                return;
              }

              // تحديث السجل القائم
              citizensUpdated++;
              const updatedFam: MockFamily = {
                ...exists,
                name: rawName || exists.name,
                primaryPhone: rawPhone || exists.primaryPhone,
                alternativePhone1: rawAltPhone1 || exists.alternativePhone1,
                alternativePhone2: rawAltPhone2 || exists.alternativePhone2,
                currentMainArea: rawMainArea || exists.currentMainArea,
                currentSubArea: rawArea || exists.currentSubArea,
                currentBranch: rawBranch || exists.currentBranch,
                currentMosque: rawMosque || exists.currentMosque,
                membersCount: rawMembers || exists.membersCount,
                developmentApproval: rawDev || exists.developmentApproval,
                residentStatus: rawRes || exists.residentStatus,
                worksApproval: rawWorks || exists.worksApproval,
                shelterStatus: rawShelter || exists.shelterStatus,
                campOrCenterName: rawCamp || exists.campOrCenterName,
                damageType: rawDamage || exists.damageType,
                damageDescription: rawDamageDesc || exists.damageDescription,
                injuryStatus: rawInjury || exists.injuryStatus,
                injuryDate: rawInjuryDate || exists.injuryDate,
                incomeSource1: rawIncome || exists.incomeSource1,
                incomeSource2: rawIncome2 || exists.incomeSource2,
                rationCardNumber: rawRation || exists.rationCardNumber,
                wifeNationalID: rawWifeId || exists.wifeNationalID,
                wifeName: rawWifeName || exists.wifeName,
                lastAidType: rawAidType || exists.lastAidType,
                lastAidDate: rawAidDate || exists.lastAidDate,
                notes: rawNotes || exists.notes
              };
              finalFamiliesMap.set(rawId, updatedFam);
            } else {
              if (mergeMode === 'update_only') {
                skippedCount++;
                return;
              }

              // إضافة سجل أسرة جديد
              citizensAdded++;
              runningFamId++;
              const newFam: MockFamily = {
                familyID: runningFamId,
                nationalID: rawId,
                name: rawName,
                gender: (row[citizenMapping.gender] as any) || 'ذكر',
                birthDate: String(row[citizenMapping.birthDate] || '1982-01-01').trim(),
                age: parseInt(String(row[citizenMapping.age] || '44'), 10) || 44,
                maritalStatus: String(row[citizenMapping.maritalStatus] || 'متزوج').trim(),
                deathStatus: String(row[citizenMapping.deathStatus] || 'على قيد الحياة').trim(),
                deathDate: String(row[citizenMapping.deathDate] || '').trim(),
                primaryPhone: rawPhone,
                alternativePhone1: rawAltPhone1,
                alternativePhone2: rawAltPhone2,
                wifeName: rawWifeName || 'زوجة المستفيد',
                wifeNationalID: rawWifeId || '',
                membersCount: rawMembers,
                damageType: rawDamage,
                damageDescription: rawDamageDesc,
                injuryStatus: rawInjury,
                injuryDate: rawInjuryDate,
                incomeSource1: rawIncome,
                incomeSource2: rawIncome2,
                rationCardNumber: rawRation,
                originalMainArea: String(row[citizenMapping.originalMainArea] || rawMainArea).trim(),
                originalSubArea: String(row[citizenMapping.originalSubArea] || rawArea).trim(),
                originalBranch: String(row[citizenMapping.originalBranch] || rawBranch).trim(),
                originalMosque: String(row[citizenMapping.originalMosque] || rawMosque).trim(),
                currentMainArea: rawMainArea,
                currentSubArea: rawArea,
                currentBranch: rawBranch,
                currentMosque: rawMosque,
                developmentApproval: rawDev,
                localityApproval: String(row[citizenMapping.localityApproval] || 'معتمد').trim(),
                residentStatus: rawRes,
                worksApproval: rawWorks,
                shelterStatus: rawShelter,
                campOrCenterName: rawCamp,
                localityID: 1,
                localityName: rawArea,
                lastAidType: rawAidType || 'طرد غذائي أساسي',
                lastAidDate: rawAidDate || todayStr,
                notes: rawNotes
              };
              finalFamiliesMap.set(rawId, newFam);

              // إذا كان هناك بيانات ابن ملحقة في نفس السجل
              if (row[childMapping.name]) {
                childrenAdded++;
                runningChildId++;
                finalChildrenMap.set(`${rawId}_${row[childMapping.name]}`, {
                  id: runningChildId,
                  familyID: newFam.familyID,
                  parentNationalID: rawId,
                  nationalID: String(row[childMapping.nationalID] || `410${runningChildId}`).trim(),
                  name: String(row[childMapping.name]).trim(),
                  gender: (row[childMapping.gender] as any) || 'ذكر',
                  age: parseInt(String(row[childMapping.age] || '5'), 10) || 5,
                  birthDate: String(row[childMapping.birthDate] || '').trim(),
                  relation: (row[childMapping.relation] as any) || 'ابن',
                  educationLevel: (row[childMapping.educationLevel] as any) || 'ابتدائي',
                  healthStatus: 'سليم',
                  notes: ''
                });
              }

              // إذا كان الوضع مشتركاً وتضمن مساعدة
              if (rawAidType || targetMode === 'combined_all') {
                aidsAdded++;
                finalDeliveries.push({
                  id: `DEL-${Date.now().toString().slice(-5)}-${aidsAdded}`,
                  familyId: newFam.familyID,
                  family: newFam,
                  projectNumber: String(row[aidMapping.projectNumber] || `PRJ-0${aidsAdded}`).trim(),
                  projectName: String(row[aidMapping.projectName] || `مشروع ${rawAidType || 'الإغاثة'} الإغاثي`).trim(),
                  aidTypeName: rawAidType || 'طرد غذائي أساسي',
                  aidValue: 150,
                  warehouse: String(row[aidMapping.warehouse] || 'المستودع الرئيسي').trim(),
                  fundingOrg: String(row[aidMapping.fundingOrg] || 'منظمة الإغاثة الإنسانية الدولية').trim(),
                  dueDistributionDate: rawAidDate || todayStr,
                  deliveryDate: rawAidDate || todayStr,
                  deliveryTime: '11:00',
                  deliveredByStaff: currentUser?.fullName || 'أمين المستودع المركزي',
                  receiverType: 'المستفيد شخصياً',
                  receiverName: newFam.name,
                  receiverNationalId: newFam.nationalID,
                  status: 'تم التسليم'
                });
              }
            }
          });

          const finalFamiliesList = Array.from(finalFamiliesMap.values());
          const finalChildrenList = Array.from(finalChildrenMap.values());

          setProgressPercent(100);
          setProgressStatusText('تمت المزامنة بنجاح وحفظ كافة السجلات في قاعدة بيانات النظام!');

          setLinkedResultStats({
            totalProcessed: rawRows.length,
            citizensAdded,
            citizensUpdated,
            childrenAdded,
            childrenUpdated,
            aidsAdded,
            skippedCount,
            totalActiveFamiliesNow: finalFamiliesList.length,
            totalActiveChildrenNow: finalChildrenList.length,
            totalActiveDeliveriesNow: finalDeliveries.length
          });

          // تطبيق البيانات وتحديث الـ State الخارجي
          onApplyLinkedData(finalFamiliesList, finalDeliveries, finalChildrenList, {
            totalProcessed: rawRows.length,
            addedCount: citizensAdded,
            updatedCount: citizensUpdated,
            skippedCount,
            aidsAddedCount: aidsAdded,
            childrenAddedCount: childrenAdded,
            childrenUpdatedCount: childrenUpdated,
            sourceName,
            channel: activeChannel,
            targetMode
          });

          if (onAddAuditLog) {
            onAddAuditLog(
              `مزامنة واستيراد بيانات شاملة (${targetMode === 'citizens' ? 'مواطنين' : targetMode === 'children' ? 'أبناء' : targetMode === 'aids' ? 'مساعدات' : 'شامل ثلاثي'})`,
              'ناجح',
              `المصدر: ${sourceName} | مواطنون: (+${citizensAdded} / ~${citizensUpdated}) | أبناء: (+${childrenAdded} / ~${childrenUpdated}) | مساعدات: (+${aidsAdded}) | الإجمالي الحالي: ${finalFamiliesList.length} أسرة، ${finalChildrenList.length} ابناً، ${finalDeliveries.length} تسليماً.`
            );
          }

          setIsExecuting(false);
          setCurrentStep('completed');
        }, 500);
      }, 500);
    }, 500);
  };

  // تصدير تقرير التدقيق بعد العملية
  const handleExportAuditReport = () => {
    if (!linkedResultStats) return;

    const reportData = [
      { 'المؤشر': 'اسم ملف المصدر', 'القيمة': sourceName },
      { 'المؤشر': 'نوع العملية والمجال', 'القيمة': targetMode === 'citizens' ? 'جدول المواطنين والأسر' : targetMode === 'children' ? 'جدول الأبناء والتابعين' : targetMode === 'aids' ? 'جدول المساعدات والتسليمات' : 'ربط شامل لكافة الجداول' },
      { 'المؤشر': 'قناة الربط', 'القيمة': activeChannel === 'mobile_file' ? 'ملف من الجوال' : activeChannel === 'cloud_sync' ? 'ربط سحابي' : 'لصق سريع' },
      { 'المؤشر': 'إجمالي الصفوف المعالجة', 'القيمة': linkedResultStats.totalProcessed },
      { 'المؤشر': 'عدد المواطنين المضافين الجدد', 'القيمة': linkedResultStats.citizensAdded },
      { 'المؤشر': 'عدد المواطنين المحدثين', 'القيمة': linkedResultStats.citizensUpdated },
      { 'المؤشر': 'عدد الأبناء المضافين الجدد', 'القيمة': linkedResultStats.childrenAdded },
      { 'المؤشر': 'عدد الأبناء المحدثين', 'القيمة': linkedResultStats.childrenUpdated },
      { 'المؤشر': 'عدد سجلات المساعدات المربوطة', 'القيمة': linkedResultStats.aidsAdded },
      { 'المؤشر': 'عدد السجلات المستبعدة', 'القيمة': linkedResultStats.skippedCount },
      { 'المؤشر': 'إجمالي الأسر النشطة في النظام الآن', 'القيمة': linkedResultStats.totalActiveFamiliesNow },
      { 'المؤشر': 'إجمالي الأبناء المسجلين في النظام الآن', 'القيمة': linkedResultStats.totalActiveChildrenNow },
      { 'المؤشر': 'إجمالي المساعدات المسجلة في النظام الآن', 'القيمة': linkedResultStats.totalActiveDeliveriesNow },
      { 'المؤشر': 'تاريخ ووقت التنفيذ', 'القيمة': new Date().toLocaleString('ar-EG') },
      { 'المؤشر': 'المسؤول المنفذ', 'القيمة': currentUser?.fullName || 'مدير النظام' }
    ];

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(reportData);
    XLSX.utils.book_append_sheet(wb, ws, 'تقرير التدقيق والمزامنة');
    XLSX.writeFile(wb, `تقرير_مزامنة_النظام_${Date.now().toString().slice(-4)}.xlsx`);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-2xl w-full max-w-5xl max-h-[95vh] flex flex-col shadow-2xl overflow-hidden text-slate-100 font-sans">
        
        {/* Modal Top Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border-b border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 via-indigo-500 to-emerald-400 p-0.5 shadow-lg shadow-sky-950/40">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <CloudLightning className="w-5 h-5 text-sky-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                  منظومة ربط واستيراد كافة بيانات وحقول النظام
                </h2>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-sky-500/10 text-sky-300 border border-sky-500/20">
                  المواطنين • الأبناء • المساعدات
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                استيراد ومزامنة شاملة لجميع الحقول في جدول المواطنين، جدول الأبناء، وجدول المساعدات دون استثناء أي حقل
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition border border-slate-700/50"
            title="إغلاق النافذة"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Division Selector & Stepper Bar */}
        <div className="bg-slate-950/60 border-b border-slate-800/80 px-5 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          
          {/* Target Domain Split: المواطنون vs الأبناء vs المساعدات vs شامل */}
          <div className="flex items-center gap-1.5 bg-slate-900/90 p-1 rounded-xl border border-slate-800 flex-wrap">
            <span className="text-[11px] font-bold text-slate-400 px-2 flex items-center gap-1">
              <Layers className="w-3.5 h-3.5 text-indigo-400" />
              الجدول المستهدف:
            </span>
            <button
              onClick={() => {
                setTargetMode('citizens');
                if (detectedHeaders.length > 0) setCitizenMapping(autoDetectCitizenMapping(detectedHeaders));
              }}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 ${
                targetMode === 'citizens'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-950/50'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>1. جدول المواطنين والأسر (41 حقلاً)</span>
            </button>

            <button
              onClick={() => {
                setTargetMode('children');
                if (detectedHeaders.length > 0) setChildMapping(autoDetectChildMapping(detectedHeaders));
              }}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 ${
                targetMode === 'children'
                  ? 'bg-amber-600 text-white shadow-md shadow-amber-950/50'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Baby className="w-3.5 h-3.5" />
              <span>2. جدول الأبناء والتابعين (12 حقلاً)</span>
            </button>

            <button
              onClick={() => {
                setTargetMode('aids');
                if (detectedHeaders.length > 0) setAidMapping(autoDetectAidMapping(detectedHeaders));
              }}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 ${
                targetMode === 'aids'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950/50'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>3. جدول المساعدات والتسليمات (20 حقلاً)</span>
            </button>

            <button
              onClick={() => {
                setTargetMode('combined_all');
                if (detectedHeaders.length > 0) {
                  setCitizenMapping(autoDetectCitizenMapping(detectedHeaders));
                  setChildMapping(autoDetectChildMapping(detectedHeaders));
                  setAidMapping(autoDetectAidMapping(detectedHeaders));
                }
              }}
              className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 ${
                targetMode === 'combined_all'
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-950/50'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>4. استيراد شامل متكامل (كافة الجداول)</span>
            </button>
          </div>

          {/* Stepper Status Indicator */}
          <div className="flex items-center gap-2 text-[11px] font-medium text-slate-400">
            <span className={`px-2 py-0.5 rounded-md ${currentStep === 'source' ? 'bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30' : ''}`}>
              1. الملف والقناة
            </span>
            <ArrowRight className="w-3 h-3 text-slate-600" />
            <span className={`px-2 py-0.5 rounded-md ${currentStep === 'mapping' ? 'bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30' : ''}`}>
              2. تخطيط الحقول
            </span>
            <ArrowRight className="w-3 h-3 text-slate-600" />
            <span className={`px-2 py-0.5 rounded-md ${currentStep === 'preview' ? 'bg-indigo-500/20 text-indigo-300 font-bold border border-indigo-500/30' : ''}`}>
              3. المعاينة المسبقة
            </span>
            <ArrowRight className="w-3 h-3 text-slate-600" />
            <span className={`px-2 py-0.5 rounded-md ${currentStep === 'completed' ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/30' : ''}`}>
              4. تقرير التنفيذ
            </span>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          
          {/* STEP 1: SOURCE SELECTION & CHANNEL */}
          {currentStep === 'source' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              
              {/* Channel Tabs */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <button
                  type="button"
                  onClick={() => setActiveChannel('mobile_file')}
                  className={`p-4 rounded-xl border text-right transition flex flex-col justify-between gap-3 ${
                    activeChannel === 'mobile_file'
                      ? 'bg-slate-800/90 border-sky-500 ring-2 ring-sky-500/30 text-white shadow-lg shadow-sky-950/20'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="w-9 h-9 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold">
                      <FileSpreadsheet className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-sky-300 border border-slate-700">
                      Excel / CSV
                    </span>
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white">ملف من الجوال أو الجهاز</h3>
                    <p className="text-xs text-slate-400 mt-1">
                      رفع ملف إكسل (.xlsx, .xls) أو CSV من ذاكرة الهاتف أو الحاسوب الداخلي مع قراءة الشيتات.
                    </p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveChannel('fast_paste')}
                  className={`p-4 rounded-xl border text-right transition flex flex-col justify-between gap-3 ${
                    activeChannel === 'fast_paste'
                      ? 'bg-slate-800/90 border-indigo-500 ring-2 ring-indigo-500/30 text-white shadow-lg shadow-indigo-950/20'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="w-9 h-9 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center font-bold">
                      <FileText className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-indigo-300 border border-slate-700">
                      Clipboard / TSV
                    </span>
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white">لصق جدول بيانات سريع</h3>
                    <p className="text-xs text-slate-400 mt-1">
                      لصق مباشر لصفوف منسوبة من Google Sheets أو Excel للحافظة فورياً دون حفظ الملف.
                    </p>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveChannel('cloud_sync')}
                  className={`p-4 rounded-xl border text-right transition flex flex-col justify-between gap-3 ${
                    activeChannel === 'cloud_sync'
                      ? 'bg-slate-800/90 border-emerald-500 ring-2 ring-emerald-500/30 text-white shadow-lg shadow-emerald-950/20'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="w-9 h-9 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold">
                      <Cloud className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-emerald-300 border border-slate-700">
                      REST API Live
                    </span>
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-white">الربط السحابي المباشر</h3>
                    <p className="text-xs text-slate-400 mt-1">
                      مزامنة حية مع نقطة اتصال سحابية مؤمنة (API Endpoint) لجلب آخر الكشوف المحدثة.
                    </p>
                  </div>
                </button>
              </div>

              {/* Ready Templates & Demonstration Dataset Launchers */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Download className="w-4 h-4 text-sky-400" />
                  <span className="text-xs font-bold text-white">تحميل نماذج وقوالب Excel جاهزة بجميع الحقول:</span>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() => handleDownloadTemplate('citizens')}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-sky-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition border border-slate-700"
                    title="تحميل قالب جدول المواطنين بـ 41 حقلاً"
                  >
                    <Users className="w-3.5 h-3.5" />
                    <span>قالب المواطنين (41 حقلاً)</span>
                  </button>

                  <button
                    onClick={() => handleDownloadTemplate('children')}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition border border-slate-700"
                    title="تحميل قالب جدول الأبناء بـ 12 حقلاً"
                  >
                    <Baby className="w-3.5 h-3.5" />
                    <span>قالب الأبناء (12 حقلاً)</span>
                  </button>

                  <button
                    onClick={() => handleDownloadTemplate('aids')}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-emerald-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition border border-slate-700"
                    title="تحميل قالب جدول المساعدات بـ 20 حقلاً"
                  >
                    <Package className="w-3.5 h-3.5" />
                    <span>قالب المساعدات (20 حقلاً)</span>
                  </button>

                  <button
                    onClick={() => handleDownloadTemplate('combined_all')}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-purple-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition border border-slate-700"
                    title="تحميل قالب إكسل ثلاثي الشيتات يجمع كافة الجداول"
                  >
                    <Layers className="w-3.5 h-3.5" />
                    <span>قالب شامل ثلاثي الشيتات (.xlsx)</span>
                  </button>

                  <button
                    onClick={() => handleLoadDemoDataset(targetMode)}
                    className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md transition"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
                    <span>تحميل عينة نموذجية حقيقية لقطاع غزة (فوري)</span>
                  </button>
                </div>
              </div>

              {/* Channel 1: Mobile / Local File Picker */}
              {activeChannel === 'mobile_file' && (
                <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 text-center space-y-4">
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept=".xlsx,.xls,.csv"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <div className="w-16 h-16 rounded-2xl bg-sky-500/10 border border-sky-500/20 text-sky-400 flex items-center justify-center mx-auto shadow-inner">
                    <Upload className="w-8 h-8" />
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-white">اختر ملف الكشف من جهازك أو هاتفك الجوال</h4>
                    <p className="text-xs text-slate-400 mt-1 max-w-lg mx-auto">
                      يدعم بصيغة Microsoft Excel (.xlsx / .xls) أو ملفات القيم المفصولة بفواصل (.csv) مع دعم اللغة العربية وترميز UTF-8.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-6 py-3 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-sky-950/40 inline-flex items-center gap-2 transition transform active:scale-95"
                  >
                    <Upload className="w-4 h-4" />
                    <span>تصفح واختيار الملف من الهاتف / الحاسوب</span>
                  </button>
                </div>
              )}

              {/* Channel 2: Fast Paste Clipboard */}
              {activeChannel === 'fast_paste' && (
                <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-white flex items-center gap-2">
                        <FileText className="w-4 h-4 text-indigo-400" />
                        صندوق اللصق السريع لجداول البيانات
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5">
                        قم بتحديد الصفوف في برنامج Excel أو Google Sheets واضغط نسخ (Ctrl+C) ثم الصق هنا (Ctrl+V).
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setManualPasteText('')}
                      className="text-xs text-slate-400 hover:text-rose-400 transition"
                    >
                      مسح الصندوق
                    </button>
                  </div>

                  <textarea
                    rows={8}
                    dir="ltr"
                    value={manualPasteText}
                    onChange={(e) => setManualPasteText(e.target.value)}
                    placeholder={
                      targetMode === 'children'
                        ? "رقم هوية رب الأسرة\tاسم الابن\tرقم هوية الابن\tالجنس\tالعمر\tصلة القرابة\tالمرحلة التعليمية\tالحالة الصحية\n901234561\tعمر أحمد الأسطل\t410111221\tذكر\t4\tابن\tرياض أطفال\tسليم"
                        : "رقم الهوية\tاسم رب الأسرة\tرقم الجوال\tالمنطقة الفرعية\tعدد الأفراد\tاعتماد التنمية\n901234561\tأحمد محمود الأسطل\t0599123456\tالشيخ رضوان\t8\tمعتمد"
                    }
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 font-mono focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />

                  <div className="flex justify-end">
                    <button
                      type="button"
                      onClick={handleProcessPastedText}
                      disabled={!manualPasteText.trim()}
                      className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-2 transition disabled:opacity-50"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>تحليل الجدول المنسوخ والانتقال للتخطيط</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Channel 3: Cloud REST API Endpoint */}
              {activeChannel === 'cloud_sync' && (
                <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-5">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
                      <h4 className="text-sm font-bold text-white">إعدادات الربط السحابي المباشر (REST Cloud Engine)</h4>
                    </div>
                    <span className="text-[11px] text-slate-400">
                      آخر مزامنة ناجحة: {cloudLastSyncTime}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-slate-400 font-medium mb-1">رابط واجهة المزامنة السحابية (API Endpoint):</label>
                      <input
                        type="text"
                        value={cloudEndpointUrl}
                        onChange={(e) => setCloudEndpointUrl(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 font-medium mb-1">مفتاح المصادقة والأمان السحابي (API Token):</label>
                      <input
                        type="password"
                        value={cloudApiKey}
                        onChange={(e) => setCloudApiKey(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono text-xs focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <Wifi className="w-4 h-4 text-emerald-400" />
                      <span>الحالة: خادم الإغاثة المركزي متصل ومشفر بدرجة TLS 1.3</span>
                    </div>

                    <button
                      type="button"
                      onClick={handleFetchFromCloud}
                      disabled={isCloudConnecting}
                      className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-emerald-950/40 transition disabled:opacity-50"
                    >
                      <RefreshCw className={`w-4 h-4 ${isCloudConnecting ? 'animate-spin' : ''}`} />
                      <span>{isCloudConnecting ? 'جاري الاتصال بالسحابة وسحب البيانات...' : 'سحب أحدث الكشوف من السحابة الآن'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* STEP 2: FIELD MAPPING & CONFLICT STRATEGY */}
          {currentStep === 'mapping' && (
            <div className="space-y-6 animate-in fade-in duration-150">
              
              {/* File Info Bar with Sheet Selector */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center border border-sky-500/20">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white">{sourceName || 'ملف غير معنون'}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-sky-300 border border-slate-700">
                        {rawRows.length} صفاً مقروءاً
                      </span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
                        {detectedHeaders.length} عموداً
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      تم فحص وقراءة الأعمدة تلقائياً. تأكد من ضبط وتخصيص الحقول الميدانية أدناه قبل الاعتماد:
                    </p>
                  </div>
                </div>

                {/* Multiple Sheet Selector */}
                {excelSheets.length > 1 && (
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-slate-400 font-bold">ورقة العمل (Sheet):</span>
                    <select
                      value={selectedSheet}
                      onChange={(e) => handleSheetChange(e.target.value)}
                      className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-sky-500"
                    >
                      {excelSheets.map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* Conflict & Options Strategy */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <h4 className="text-xs font-bold text-white flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-indigo-400" />
                    استراتيجية الدمج والتحكم في النزاهة وتكامل العلاقات
                  </h4>
                  <div className="flex items-center gap-3 flex-wrap">
                    <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={validatePalestineIdChecksum}
                        onChange={(e) => setValidatePalestineIdChecksum(e.target.checked)}
                        className="rounded border-slate-700 text-indigo-600 focus:ring-0"
                      />
                      <span>تدقيق خوارزمية الهوية الوطنية (9 أرقام)</span>
                    </label>

                    {(targetMode === 'children' || targetMode === 'aids') && (
                      <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={autoCreateMissingCitizens}
                          onChange={(e) => setAutoCreateMissingCitizens(e.target.checked)}
                          className="rounded border-slate-700 text-emerald-600 focus:ring-0"
                        />
                        <span>إنشاء ملف مواطن/والد تلقائياً إن لم يكن موجوداً</span>
                      </label>
                    )}

                    {targetMode === 'children' && (
                      <label className="flex items-center gap-1.5 text-xs text-slate-300 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={autoUpdateFamilyMemberCount}
                          onChange={(e) => setAutoUpdateFamilyMemberCount(e.target.checked)}
                          className="rounded border-slate-700 text-amber-500 focus:ring-0"
                        />
                        <span>تحديث عدد أفراد الأسرة تلقائياً عند إضافة أبناء</span>
                      </label>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setMergeMode('upsert')}
                    className={`p-2.5 rounded-lg border text-right transition ${
                      mergeMode === 'upsert'
                        ? 'bg-indigo-600/20 border-indigo-500 text-indigo-200 font-bold'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-bold text-white mb-0.5">دمج وتحديث ذكي (Upsert)</div>
                    <div className="text-[11px] text-slate-400">إضافة الجديد وتحديث بيانات الموجودين مع الحفاظ على البيانات السابقة.</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMergeMode('append')}
                    className={`p-2.5 rounded-lg border text-right transition ${
                      mergeMode === 'append'
                        ? 'bg-sky-600/20 border-sky-500 text-sky-200 font-bold'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-bold text-white mb-0.5">إضافة الجديد فقط (Append)</div>
                    <div className="text-[11px] text-slate-400">إضافة السجلات غير الموجودة وتجاوز أي سجل مكرر بأمان كامل.</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMergeMode('update_only')}
                    className={`p-2.5 rounded-lg border text-right transition ${
                      mergeMode === 'update_only'
                        ? 'bg-amber-600/20 border-amber-500 text-amber-200 font-bold'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-bold text-white mb-0.5">تحديث القائم فقط (Update)</div>
                    <div className="text-[11px] text-slate-400">تعديل بيانات من هم مسجلون في النظام فقط وتجاهل السجلات الجديدة.</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMergeMode('replace')}
                    className={`p-2.5 rounded-lg border text-right transition ${
                      mergeMode === 'replace'
                        ? 'bg-rose-600/20 border-rose-500 text-rose-200 font-bold'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <div className="font-bold text-rose-300 mb-0.5">استبدال كامل (Overwrite)</div>
                    <div className="text-[11px] text-slate-400">استبدال كافة السجلات في الجدول بالملف المرفوع كلياً.</div>
                  </button>
                </div>
              </div>

              {/* ================= SECTION A: CITIZENS FIELD MAPPING (41 FIELDS) ================= */}
              {(targetMode === 'citizens' || targetMode === 'combined_all') && (
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Users className="w-4 h-4 text-sky-400" />
                      تخطيط حقول جدول المواطنين والأسر الكاملة (41 حقلاً شاملاً دون استثناء)
                    </h4>
                    <span className="text-[11px] text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded border border-sky-500/20">
                      * الحقول بالأخضر مطابقة تلقائياً
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
                    {/* 1. Identifier */}
                    <div className="space-y-1">
                      <label className="font-bold text-white flex items-center justify-between">
                        <span>رقم الهوية الوطنية *</span>
                        <span className="text-[10px] text-rose-400 font-normal">إلزامي للربط</span>
                      </label>
                      <select
                        value={citizenMapping.nationalID}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, nationalID: e.target.value }))}
                        className={`w-full bg-slate-950 border rounded-lg px-2.5 py-2 text-xs ${
                          citizenMapping.nationalID ? 'border-emerald-500 text-emerald-300 font-semibold' : 'border-rose-500/60 text-slate-300'
                        }`}
                      >
                        <option value="">-- اختر العمود من الملف --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 2. Full Name */}
                    <div className="space-y-1">
                      <label className="font-bold text-white flex items-center justify-between">
                        <span>الاسم رباعي *</span>
                        <span className="text-[10px] text-rose-400 font-normal">إلزامي</span>
                      </label>
                      <select
                        value={citizenMapping.name}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, name: e.target.value }))}
                        className={`w-full bg-slate-950 border rounded-lg px-2.5 py-2 text-xs ${
                          citizenMapping.name ? 'border-emerald-500 text-emerald-300 font-semibold' : 'border-rose-500/60 text-slate-300'
                        }`}
                      >
                        <option value="">-- اختر العمود من الملف --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 3. Primary Phone */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">رقم الجوال الأساسي</label>
                      <select
                        value={citizenMapping.primaryPhone}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, primaryPhone: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (افتراضي 0590000000) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 4. Alt Phone 1 */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">جوال بديل 1</label>
                      <select
                        value={citizenMapping.alternativePhone1}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, alternativePhone1: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 5. Alt Phone 2 */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">جوال بديل 2</label>
                      <select
                        value={citizenMapping.alternativePhone2}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, alternativePhone2: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 6. Gender */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">الجنس (ذكر / أنثى)</label>
                      <select
                        value={citizenMapping.gender}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, gender: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (افتراضي ذكر) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 7. Birth Date */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">تاريخ الميلاد</label>
                      <select
                        value={citizenMapping.birthDate}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, birthDate: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 8. Age */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">العمر</label>
                      <select
                        value={citizenMapping.age}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, age: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 9. Marital Status */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">الحالة الاجتماعية</label>
                      <select
                        value={citizenMapping.maritalStatus}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, maritalStatus: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (افتراضي متزوج) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 10. Death Status */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">حالة الوفاة</label>
                      <select
                        value={citizenMapping.deathStatus}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, deathStatus: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (على قيد الحياة) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 11. Death Date */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">تاريخ الوفاة</label>
                      <select
                        value={citizenMapping.deathDate}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, deathDate: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 12. Wife Name */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">اسم الزوج / الزوجة</label>
                      <select
                        value={citizenMapping.wifeName}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, wifeName: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 13. Wife National ID */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">هوية الزوج / الزوجة</label>
                      <select
                        value={citizenMapping.wifeNationalID}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, wifeNationalID: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 14. Members Count */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">عدد أفراد الأسرة</label>
                      <select
                        value={citizenMapping.membersCount}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, membersCount: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (افتراضي 5) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 15. Damage Type */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">حالة الضرر (كلي / جزئي بليغ / صالح)</label>
                      <select
                        value={citizenMapping.damageType}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, damageType: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 16. Damage Description */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">وصف الضرر</label>
                      <select
                        value={citizenMapping.damageDescription}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, damageDescription: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 17. Injury Status */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">حالة الإصابة (سليم / جريح / إعاقة)</label>
                      <select
                        value={citizenMapping.injuryStatus}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, injuryStatus: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 18. Injury Date */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">تاريخ الإصابة</label>
                      <select
                        value={citizenMapping.injuryDate}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, injuryDate: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 19. Income Source 1 */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">مصدر الدخل 1</label>
                      <select
                        value={citizenMapping.incomeSource1}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, incomeSource1: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 20. Income Source 2 */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">مصدر الدخل 2</label>
                      <select
                        value={citizenMapping.incomeSource2}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, incomeSource2: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 21. Ration Card Number */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">رقم كرت المؤن UNRWA</label>
                      <select
                        value={citizenMapping.rationCardNumber}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, rationCardNumber: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 22. Original Main Area */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">المحافظة الأصلية</label>
                      <select
                        value={citizenMapping.originalMainArea}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, originalMainArea: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 23. Original Sub Area */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">المنطقة الفرعية الأصلية</label>
                      <select
                        value={citizenMapping.originalSubArea}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, originalSubArea: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 24. Original Branch */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">الشعبة الأصلية</label>
                      <select
                        value={citizenMapping.originalBranch}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, originalBranch: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 25. Original Mosque */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">المسجد الأصلي</label>
                      <select
                        value={citizenMapping.originalMosque}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, originalMosque: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 26. Current Main Area */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">المحافظة الحالية</label>
                      <select
                        value={citizenMapping.currentMainArea}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, currentMainArea: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (افتراضي غزة) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 27. Current Sub Area */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">المنطقة الفرعية الحالية</label>
                      <select
                        value={citizenMapping.currentSubArea}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, currentSubArea: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (افتراضي الشيخ رضوان) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 28. Current Branch */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">الشعبة الحالية</label>
                      <select
                        value={citizenMapping.currentBranch}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, currentBranch: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 29. Current Mosque */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">المسجد الحالي</label>
                      <select
                        value={citizenMapping.currentMosque}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, currentMosque: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 30. Development Approval */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">حالة اعتماد التنمية (معتمد/حجب/مجمد)</label>
                      <select
                        value={citizenMapping.developmentApproval}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, developmentApproval: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (افتراضي معتمد) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 31. Locality Approval */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">اعتماد المناطق والمحلية</label>
                      <select
                        value={citizenMapping.localityApproval}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, localityApproval: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 32. Resident Status */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">صفة الإقامة (مقيم / نازح)</label>
                      <select
                        value={citizenMapping.residentStatus}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, residentStatus: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (افتراضي مقيم) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 33. Works Approval */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">اعتماد وزارة الأشغال</label>
                      <select
                        value={citizenMapping.worksApproval}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, worksApproval: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 34. Shelter Status */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">حالة الإيواء (داخلي / خارج الإيواء)</label>
                      <select
                        value={citizenMapping.shelterStatus}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, shelterStatus: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 35. Camp or Center Name */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">مركز / مخيم الإيواء</label>
                      <select
                        value={citizenMapping.campOrCenterName}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, campOrCenterName: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 36. Notes */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">ملاحظات الأسرة الميدانية</label>
                      <select
                        value={citizenMapping.notes}
                        onChange={(e) => setCitizenMapping(prev => ({ ...prev, notes: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* ================= SECTION B: CHILDREN FIELD MAPPING (12 FIELDS) ================= */}
              {(targetMode === 'children' || targetMode === 'combined_all') && (
                <div className="bg-slate-900/80 border border-amber-500/40 rounded-xl p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Baby className="w-4 h-4 text-amber-400" />
                      تخطيط حقول جدول الأبناء والتابعين (12 حقلاً شاملاً دون استثناء)
                    </h4>
                    <span className="text-[11px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                      سيتم ربط الابن تلقائياً بملف رب الأسرة
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
                    {/* 1. Parent National ID */}
                    <div className="space-y-1">
                      <label className="font-bold text-white flex items-center justify-between">
                        <span>رقم هوية رب الأسرة / الوالد *</span>
                        <span className="text-[10px] text-rose-400 font-normal">إلزامي للربط</span>
                      </label>
                      <select
                        value={childMapping.parentNationalID}
                        onChange={(e) => setChildMapping(prev => ({ ...prev, parentNationalID: e.target.value }))}
                        className={`w-full bg-slate-950 border rounded-lg px-2.5 py-2 text-xs ${
                          childMapping.parentNationalID ? 'border-amber-500 text-amber-300 font-semibold' : 'border-rose-500/60 text-slate-300'
                        }`}
                      >
                        <option value="">-- اختر العمود من الملف --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 2. Child Name */}
                    <div className="space-y-1">
                      <label className="font-bold text-white flex items-center justify-between">
                        <span>اسم الابن / التابع *</span>
                        <span className="text-[10px] text-rose-400 font-normal">إلزامي</span>
                      </label>
                      <select
                        value={childMapping.name}
                        onChange={(e) => setChildMapping(prev => ({ ...prev, name: e.target.value }))}
                        className={`w-full bg-slate-950 border rounded-lg px-2.5 py-2 text-xs ${
                          childMapping.name ? 'border-amber-500 text-amber-300 font-semibold' : 'border-rose-500/60 text-slate-300'
                        }`}
                      >
                        <option value="">-- اختر العمود من الملف --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 3. Child National ID */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">رقم هوية الابن أو شهادة الميلاد</label>
                      <select
                        value={childMapping.nationalID}
                        onChange={(e) => setChildMapping(prev => ({ ...prev, nationalID: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 4. Child Gender */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">الجنس (ذكر / أنثى)</label>
                      <select
                        value={childMapping.gender}
                        onChange={(e) => setChildMapping(prev => ({ ...prev, gender: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 5. Child Age */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">العمر (بالسنوات)</label>
                      <select
                        value={childMapping.age}
                        onChange={(e) => setChildMapping(prev => ({ ...prev, age: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 6. Child Birth Date */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">تاريخ الميلاد</label>
                      <select
                        value={childMapping.birthDate}
                        onChange={(e) => setChildMapping(prev => ({ ...prev, birthDate: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 7. Relation */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">صلة القرابة (ابن / ابنة / زوجة / حفيد)</label>
                      <select
                        value={childMapping.relation}
                        onChange={(e) => setChildMapping(prev => ({ ...prev, relation: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 8. Education Level */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">المرحلة التعليمية</label>
                      <select
                        value={childMapping.educationLevel}
                        onChange={(e) => setChildMapping(prev => ({ ...prev, educationLevel: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 9. Health Status */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">الحالة الصحية (سليم / مصاب حرب / إعاقة)</label>
                      <select
                        value={childMapping.healthStatus}
                        onChange={(e) => setChildMapping(prev => ({ ...prev, healthStatus: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 10. Notes */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">ملاحظات خاصة عن الابن</label>
                      <select
                        value={childMapping.notes}
                        onChange={(e) => setChildMapping(prev => ({ ...prev, notes: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* ================= SECTION C: AID MANIFEST FIELD MAPPING (20 FIELDS) ================= */}
              {(targetMode === 'aids' || targetMode === 'combined_all') && (
                <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <Package className="w-4 h-4 text-emerald-400" />
                      تخطيط حقول جدول المساعدات والتسليمات الكاملة (20 حقلاً شاملاً دون استثناء)
                    </h4>
                    <span className="text-[11px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      سيتم ربط المساعدات تلقائياً برقم هوية المستفيد
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs">
                    {/* 1. Receiver National ID */}
                    <div className="space-y-1">
                      <label className="font-bold text-white flex items-center justify-between">
                        <span>رقم هوية المستفيد للربط *</span>
                        <span className="text-[10px] text-rose-400 font-normal">إلزامي للربط</span>
                      </label>
                      <select
                        value={aidMapping.receiverNationalId}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, receiverNationalId: e.target.value }))}
                        className={`w-full bg-slate-950 border rounded-lg px-2.5 py-2 text-xs ${
                          aidMapping.receiverNationalId ? 'border-emerald-500 text-emerald-300 font-semibold' : 'border-rose-500/60 text-slate-300'
                        }`}
                      >
                        <option value="">-- اختر العمود من الملف --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 2. Aid Type */}
                    <div className="space-y-1">
                      <label className="font-bold text-white flex items-center justify-between">
                        <span>نوع أو صنف المساعدة *</span>
                        <span className="text-[10px] text-rose-400 font-normal">إلزامي</span>
                      </label>
                      <select
                        value={aidMapping.aidTypeName}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, aidTypeName: e.target.value }))}
                        className={`w-full bg-slate-950 border rounded-lg px-2.5 py-2 text-xs ${
                          aidMapping.aidTypeName ? 'border-emerald-500 text-emerald-300 font-semibold' : 'border-rose-500/60 text-slate-300'
                        }`}
                      >
                        <option value="">-- اختر العمود من الملف --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 3. Project Name */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">اسم المشروع الإغاثي</label>
                      <select
                        value={aidMapping.projectName}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, projectName: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 4. Project Number */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">كود أو رقم المشروع</label>
                      <select
                        value={aidMapping.projectNumber}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, projectNumber: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 5. Aid Value */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">قيمة المساعدة (₪)</label>
                      <select
                        value={aidMapping.aidValue}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, aidValue: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (افتراضي 150) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 6. Warehouse */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">المستودع المنفذ / مركز التوزيع</label>
                      <select
                        value={aidMapping.warehouse}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, warehouse: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (المستودع المركزي) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 7. Funding Org */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">الجهة الممولة والمانحة</label>
                      <select
                        value={aidMapping.fundingOrg}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, fundingOrg: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 8. Delivery Date */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">تاريخ التسليم / الصرف</label>
                      <select
                        value={aidMapping.deliveryDate}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, deliveryDate: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (تاريخ اليوم) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 9. Delivery Time */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">وقت وساعة التسليم</label>
                      <select
                        value={aidMapping.deliveryTime}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, deliveryTime: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 10. Delivered by staff */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">الموظف أو أمين المستودع المسلّم</label>
                      <select
                        value={aidMapping.deliveredByStaff}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, deliveredByStaff: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 11. Receiver Type */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">صفة المستلم (شخصياً / الزوج / وكيل)</label>
                      <select
                        value={aidMapping.receiverType}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, receiverType: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري (المستفيد شخصياً) --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>

                    {/* 12. Receipt Voucher Number */}
                    <div className="space-y-1">
                      <label className="text-slate-300 font-medium">رقم سند / إيصال الصرف</label>
                      <select
                        value={aidMapping.receiptVoucherNumber}
                        onChange={(e) => setAidMapping(prev => ({ ...prev, receiptVoucherNumber: e.target.value }))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-300"
                      >
                        <option value="">-- اختياري --</option>
                        {detectedHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {/* Navigation Back & Next */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setCurrentStep('source')}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
                >
                  الرجوع لاختيار الملف
                </button>

                <button
                  type="button"
                  onClick={handleProceedToPreview}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg transition"
                >
                  <span>متابعة إلى المعاينة المسبقة والتدقيق</span>
                  <ArrowRight className="w-4 h-4 rotate-180" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: PREVIEW & DRY RUN ANALYSIS */}
          {currentStep === 'preview' && (
            <div className="space-y-5 animate-in fade-in duration-150">
              
              {/* Summary KPIs Banner */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div className="bg-slate-900/90 border border-slate-800 p-3.5 rounded-xl text-center">
                  <span className="text-[11px] text-slate-400 font-bold block mb-1">إجمالي الصفوف المقروءة</span>
                  <span className="text-xl font-black text-white">{previewAnalysis.validRows + previewAnalysis.errorRows}</span>
                </div>

                <div className="bg-emerald-950/30 border border-emerald-500/30 p-3.5 rounded-xl text-center">
                  <span className="text-[11px] text-emerald-400 font-bold block mb-1">سجلات جديدة للإضافة</span>
                  <span className="text-xl font-black text-emerald-300">+{previewAnalysis.newEntries}</span>
                </div>

                <div className="bg-sky-950/30 border border-sky-500/30 p-3.5 rounded-xl text-center">
                  <span className="text-[11px] text-sky-400 font-bold block mb-1">سجلات قائمة ستُحدّث</span>
                  <span className="text-xl font-black text-sky-300">~{previewAnalysis.existingUpdates}</span>
                </div>

                <div className="bg-indigo-950/30 border border-indigo-500/30 p-3.5 rounded-xl text-center">
                  <span className="text-[11px] text-indigo-400 font-bold block mb-1">
                    {targetMode === 'children' ? 'أبناء مربوطون بآبائهم' : 'سجلات مربوطة بهوية'}
                  </span>
                  <span className="text-xl font-black text-indigo-300">{previewAnalysis.linkedCount}</span>
                </div>

                <div className="bg-rose-950/30 border border-rose-500/30 p-3.5 rounded-xl text-center">
                  <span className="text-[11px] text-rose-400 font-bold block mb-1">سجلات بها أخطاء</span>
                  <span className="text-xl font-black text-rose-300">{previewAnalysis.errorRows}</span>
                </div>
              </div>

              {/* Filter Tabs */}
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-1.5 text-xs bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    onClick={() => setPreviewFilter('all')}
                    className={`px-3 py-1 rounded-lg font-bold transition ${
                      previewFilter === 'all' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    عرض الكل ({previewAnalysis.rowStatuses.length})
                  </button>
                  <button
                    onClick={() => setPreviewFilter('valid')}
                    className={`px-3 py-1 rounded-lg font-bold transition ${
                      previewFilter === 'valid' ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/30' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    الجديدة فقط ({previewAnalysis.newEntries})
                  </button>
                  <button
                    onClick={() => setPreviewFilter('updates')}
                    className={`px-3 py-1 rounded-lg font-bold transition ${
                      previewFilter === 'updates' ? 'bg-sky-600/30 text-sky-300 border border-sky-500/30' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    الموجودة للتحديث ({previewAnalysis.existingUpdates})
                  </button>
                  <button
                    onClick={() => setPreviewFilter('errors')}
                    className={`px-3 py-1 rounded-lg font-bold transition ${
                      previewFilter === 'errors' ? 'bg-rose-600/30 text-rose-300 border border-rose-500/30' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    الأخطاء فقط ({previewAnalysis.errorRows})
                  </button>
                </div>

                <div className="text-xs text-slate-400 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>الجدول المستهدف: <strong>{targetMode === 'citizens' ? 'المواطنون والأسر (41 حقلاً)' : targetMode === 'children' ? 'الأبناء والتابعون (12 حقلاً)' : targetMode === 'aids' ? 'المساعدات والتسليمات (20 حقلاً)' : 'شامل ثلاثي الجداول'}</strong></span>
                </div>
              </div>

              {/* Data Rows Preview Table */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden max-h-72 overflow-y-auto">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-900 border-b border-slate-800 sticky top-0 z-10 text-slate-300">
                    <tr>
                      <th className="p-2.5 w-12 text-center">#</th>
                      <th className="p-2.5">{targetMode === 'children' ? 'هوية الابن' : 'رقم الهوية الوطنية'}</th>
                      <th className="p-2.5">{targetMode === 'children' ? 'اسم الابن / التابع' : 'الاسم'}</th>
                      {targetMode === 'children' && <th className="p-2.5">هوية رب الأسرة</th>}
                      <th className="p-2.5">حالة السجل والمطابقة</th>
                      <th className="p-2.5">الملاحظات وتكامل العلاقات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-mono">
                    {previewAnalysis.rowStatuses
                      .filter(r => {
                        if (previewFilter === 'valid') return r.status === 'new';
                        if (previewFilter === 'updates') return r.status === 'update';
                        if (previewFilter === 'errors') return r.status === 'error';
                        return true;
                      })
                      .slice(0, 50)
                      .map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/40 transition">
                          <td className="p-2.5 text-center text-slate-500">{row.index + 1}</td>
                          <td className="p-2.5 font-bold text-white tracking-wider">
                            {row.id}
                          </td>
                          <td className="p-2.5 font-sans text-slate-200">
                            {row.name}
                          </td>
                          {targetMode === 'children' && (
                            <td className="p-2.5 tracking-wider text-amber-300">
                              {row.secondaryId || 'غير محدد'}
                            </td>
                          )}
                          <td className="p-2.5">
                            {row.status === 'new' && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 w-fit font-sans">
                                <CheckCircle2 className="w-3 h-3" />
                                جديد للإضافة
                              </span>
                            )}
                            {row.status === 'update' && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/10 text-sky-300 border border-sky-500/30 flex items-center gap-1 w-fit font-sans">
                                <RefreshCw className="w-3 h-3" />
                                موجود - سيُحدث
                              </span>
                            )}
                            {row.status === 'error' && (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-300 border border-rose-500/30 flex items-center gap-1 w-fit font-sans">
                                <AlertTriangle className="w-3 h-3" />
                                {row.errorReason || 'خطأ'}
                              </span>
                            )}
                          </td>
                          <td className="p-2.5 font-sans text-slate-400 text-[11px]">
                            {targetMode === 'children' && row.isLinked && (
                              <span className="text-emerald-400 font-semibold">مربوط برب الأسرة المسجل ✓</span>
                            )}
                            {targetMode === 'children' && !row.isLinked && (
                              <span className="text-amber-400">
                                {autoCreateMissingCitizens ? 'سيتم إنشاء سجل للوالد تلقائياً' : 'الوالد غير مسجل بالنظام'}
                              </span>
                            )}
                            {targetMode === 'aids' && row.isLinked && (
                              <span className="text-emerald-400 font-semibold">مربوط بملف الأسرة في النظام ✓</span>
                            )}
                            {targetMode === 'aids' && !row.isLinked && (
                              <span className="text-amber-400">
                                {autoCreateMissingCitizens ? 'سيتم إنشاء ملف أسرة تلقائياً' : 'مساعدة غير مربوطة بأسرة'}
                              </span>
                            )}
                            {targetMode === 'citizens' && (
                              <span>استيراد شامل لكافة حقول المواطن الـ 41</span>
                            )}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>

              {previewAnalysis.rowStatuses.length > 50 && (
                <p className="text-[11px] text-slate-500 text-center">
                  * يتم عرض أول 50 سجلاً للمعاينة السريعة، وسيتم تطبيق كافة الـ ({previewAnalysis.rowStatuses.length}) سجلاً عند التنفيذ.
                </p>
              )}

              {/* Navigation Back & Execute */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => setCurrentStep('mapping')}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition"
                >
                  الرجوع لتعديل تخطيط الحقول
                </button>

                <button
                  type="button"
                  onClick={executeDataLinking}
                  className="px-7 py-3 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-sm shadow-xl shadow-emerald-950/40 flex items-center gap-2 transition transform active:scale-95"
                >
                  <Play className="w-4 h-4 text-emerald-200 fill-emerald-200" />
                  <span>تأكيد واستيراد كافة الحقول الآن ⚡</span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: EXECUTING IN PROGRESS */}
          {currentStep === 'executing' && (
            <div className="py-12 px-4 text-center space-y-6 max-w-lg mx-auto animate-in fade-in duration-150">
              <div className="relative w-20 h-20 mx-auto">
                <div className="absolute inset-0 rounded-full border-4 border-indigo-500/20 animate-ping" />
                <div className="relative w-20 h-20 rounded-full bg-indigo-600/20 border-2 border-indigo-500 flex items-center justify-center text-indigo-400">
                  <RefreshCw className="w-8 h-8 animate-spin" />
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold text-white">جاري تنفيذ المزامنة واستيراد كافة الحقول...</h3>
                <p className="text-xs text-slate-400 mt-1">{progressStatusText}</p>
              </div>

              <div className="space-y-2">
                <div className="w-full bg-slate-950 rounded-full h-3 border border-slate-800 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-sky-500 via-indigo-500 to-emerald-400 h-full transition-all duration-300 rounded-full"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                <div className="flex justify-between text-xs text-slate-500 font-mono">
                  <span>معالجة السجلات الحقيقية</span>
                  <span>{progressPercent}%</span>
                </div>
              </div>
            </div>
          )}

          {/* STEP 5: COMPLETED REPORT & AUDIT */}
          {currentStep === 'completed' && linkedResultStats && (
            <div className="space-y-6 animate-in fade-in duration-150">
              <div className="bg-emerald-950/40 border border-emerald-500/40 rounded-2xl p-6 text-center space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
                  <CheckCheck className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">تم استيراد ومزامنة جميع حقول النظام بنجاح تام!</h3>
                  <p className="text-xs text-emerald-300 mt-0.5">
                    تم دمج السجلات في قاعدة بيانات النظام وحفظ كافة الحقول لجدول المواطنين، جدول الأبناء، وجدول المساعدات.
                  </p>
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-center">
                  <span className="text-xs text-slate-400 block mb-1">المواطنون (جديد / تحديث)</span>
                  <span className="text-2xl font-black text-emerald-400">
                    +{linkedResultStats.citizensAdded} <span className="text-xs font-normal text-sky-400">/ ~{linkedResultStats.citizensUpdated}</span>
                  </span>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-center">
                  <span className="text-xs text-slate-400 block mb-1">الأبناء (جديد / تحديث)</span>
                  <span className="text-2xl font-black text-amber-400">
                    +{linkedResultStats.childrenAdded} <span className="text-xs font-normal text-amber-300">/ ~{linkedResultStats.childrenUpdated}</span>
                  </span>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-center">
                  <span className="text-xs text-slate-400 block mb-1">المساعدات المسجلة والمربوطة</span>
                  <span className="text-2xl font-black text-indigo-400">+{linkedResultStats.aidsAdded}</span>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-center">
                  <span className="text-xs text-slate-400 block mb-1">إجمالي الأسر النشطة الآن</span>
                  <span className="text-2xl font-black text-white">{linkedResultStats.totalActiveFamiliesNow}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={handleExportAuditReport}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-sky-300 hover:text-white font-bold text-xs flex items-center gap-2 transition border border-slate-700"
                >
                  <Download className="w-4 h-4" />
                  <span>تصدير تقرير التدقيق كملف Excel (.xlsx)</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentStep('source');
                      setRawRows([]);
                    }}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition"
                  >
                    استيراد ملف أو كشف إضافي
                  </button>

                  <button
                    type="button"
                    onClick={onClose}
                    className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition shadow-lg shadow-emerald-950/40"
                  >
                    إغلاق والعودة للشاشة الرئيسية
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
