import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Shield,
  Users,
  Key,
  Clock,
  Calendar,
  Lock,
  Unlock,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  History,
  Check,
  X,
  Search,
  Filter,
  RefreshCw,
  Home,
  PackageCheck,
  FileText,
  Database,
  Sliders,
  Sparkles,
  Copy,
  ExternalLink,
  Laptop,
  Smartphone,
  Eye,
  AlertOctagon,
  Settings,
  LogIn,
  BarChart3,
  PieChart,
  TrendingUp,
  MapPin,
  Layers,
  Server,
  Activity,
  ArrowUpRight
} from 'lucide-react';
import {
  SubAreaItem,
  INITIAL_SUB_AREAS_DATA,
  checkGeographicPermission
} from '../types/subAreaService';
import {
  AppScreenId,
  APP_SCREENS_CATALOG,
  CURRENT_SUB_AREAS,
  WEEK_DAYS,
  SystemRole,
  INITIAL_SYSTEM_ROLES,
  MockUser,
  INITIAL_USERS,
  AuditLog,
  INITIAL_AUDIT_LOGS,
  checkUserWorkingHours,
  checkUserWorkingDay
} from '../types/adminSecurity';

interface AdminDashboardProps {
  rolesList?: SystemRole[];
  onUpdateRoles?: (roles: SystemRole[]) => void;
  usersList?: MockUser[];
  onUpdateUsers?: (users: MockUser[]) => void;
  auditLogs?: AuditLog[];
  onAddAuditLog?: (log: Omit<AuditLog, 'id'>) => void;
  onOpenEmulatorWithUser?: (username: string) => void;
  // Compatibility aliases
  roles?: SystemRole[];
  setRoles?: React.Dispatch<React.SetStateAction<SystemRole[]>>;
  users?: MockUser[];
  setUsers?: React.Dispatch<React.SetStateAction<MockUser[]>>;
  setAuditLogs?: React.Dispatch<React.SetStateAction<AuditLog[]>>;
  selectedEmulatorUser?: string;
  setSelectedEmulatorUser?: (username: string) => void;
  onOpenExcelHub?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  rolesList: externalRoles,
  onUpdateRoles,
  usersList: externalUsers,
  onUpdateUsers,
  auditLogs: externalAuditLogs,
  onAddAuditLog,
  onOpenEmulatorWithUser,
  roles: propRoles,
  setRoles: propSetRoles,
  users: propUsers,
  setUsers: propSetUsers,
  selectedEmulatorUser,
  setSelectedEmulatorUser,
  onOpenExcelHub
}) => {
  // Local state fallbacks if not provided from parent
  const [internalRoles, setInternalRoles] = useState<SystemRole[]>(INITIAL_SYSTEM_ROLES);
  const [internalUsers, setInternalUsers] = useState<MockUser[]>(INITIAL_USERS);
  const [internalAuditLogs, setInternalAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);

  const roles = propRoles || externalRoles || internalRoles;
  const setRoles = propSetRoles || onUpdateRoles || setInternalRoles;

  const users = propUsers || externalUsers || internalUsers;
  const setUsers = propSetUsers || onUpdateUsers || setInternalUsers;

  const logs = externalAuditLogs || internalAuditLogs;

  const addLog = (action: string, status: 'ناجح' | 'مرفوض' | 'تحذير أمني', details: string, userId = 1, username = 'admin') => {
    const newLogItem: AuditLog = {
      id: `LOG-${Date.now().toString().slice(-4)}`,
      userId,
      username,
      action,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
      ip: '192.168.1.10',
      device: 'Admin Station (Web)',
      status,
      details
    };
    if (onAddAuditLog) {
      onAddAuditLog({
        userId,
        username,
        action,
        timestamp: newLogItem.timestamp,
        ip: newLogItem.ip,
        device: newLogItem.device,
        status,
        details
      });
    } else {
      setInternalAuditLogs(prev => [newLogItem, ...prev]);
    }
  };

  // Active top navigation tab inside Admin Dashboard
  const [activeTab, setActiveTab] = useState<'overview' | 'subareas' | 'roles' | 'users' | 'matrix' | 'simulator' | 'logs'>('overview');

  // Sub-areas state for the backend service and geo-permissions
  const [subAreasList, setSubAreasList] = useState<SubAreaItem[]>(INITIAL_SUB_AREAS_DATA);
  const [selectedSubAreaForTest, setSelectedSubAreaForTest] = useState<string>('الشيخ رضوان');
  const [selectedRoleForTest, setSelectedRoleForTest] = useState<number>(2);
  const [selectedActionForTest, setSelectedActionForTest] = useState<'VIEW' | 'NOMINATE' | 'DELIVER' | 'EDIT' | 'REPORT'>('NOMINATE');

  // Search & Filter states
  const [userSearchTerm, setUserSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Role Editor Modal state
  const [roleModalOpen, setRoleModalOpen] = useState(false);
  const [editingRole, setEditingRole] = useState<SystemRole | null>(null);
  const [roleFormName, setRoleFormName] = useState('');
  const [roleFormBadge, setRoleFormBadge] = useState('');
  const [roleFormDesc, setRoleFormDesc] = useState('');
  const [roleFormColor, setRoleFormColor] = useState<SystemRole['color']>('indigo');
  const [roleFormIsManager, setRoleFormIsManager] = useState(false);
  const [roleFormScreens, setRoleFormScreens] = useState<AppScreenId[]>([]);
  const [roleFormScreenPermissions, setRoleFormScreenPermissions] = useState<Partial<Record<AppScreenId, string[]>>>({
    dashboard: ['view'],
    families: ['view'],
    nomination: [],
    delivery: [],
    reports: [],
    users: [],
    backup: []
  });
  const [roleFormMaxLogins, setRoleFormMaxLogins] = useState(25);
  const [roleFormMaxFailedAttempts, setRoleFormMaxFailedAttempts] = useState(3);
  const [roleFormSessionDuration, setRoleFormSessionDuration] = useState(60);
  const [roleFormStartTime, setRoleFormStartTime] = useState('08:00');
  const [roleFormEndTime, setRoleFormEndTime] = useState('17:00');
  const [roleFormViewSubAreas, setRoleFormViewSubAreas] = useState<string[]>(['*']);
  const [roleFormNominationSubAreas, setRoleFormNominationSubAreas] = useState<string[]>([]);
  const [roleFormDeliverySubAreas, setRoleFormDeliverySubAreas] = useState<string[]>([]);
  const [roleFormEditSubAreas, setRoleFormEditSubAreas] = useState<string[]>([]);

  // User Editor Modal state
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<MockUser | null>(null);
  const [userActiveTabInModal, setUserActiveTabInModal] = useState<'info' | 'time' | 'attempts' | 'screens' | 'areas'>('info');
  const [userFormFullName, setUserFormFullName] = useState('');
  const [userFormUsername, setUserFormUsername] = useState('');
  const [userFormPassword, setUserFormPassword] = useState('');
  const [userFormNationalID, setUserFormNationalID] = useState('');
  const [userFormEmail, setUserFormEmail] = useState('');
  const [userFormPhone, setUserFormPhone] = useState('');
  const [userFormRoleId, setUserFormRoleId] = useState<number>(2);
  const [userFormStartTime, setUserFormStartTime] = useState('08:00');
  const [userFormEndTime, setUserFormEndTime] = useState('17:00');
  const [userFormAllowedDays, setUserFormAllowedDays] = useState<string[]>([...WEEK_DAYS.slice(0, 5)]);
  const [userFormExpiryDate, setUserFormExpiryDate] = useState('2026-12-31');
  const [userFormSessionDuration, setUserFormSessionDuration] = useState(60);
  const [userFormMaxFailedAttempts, setUserFormMaxFailedAttempts] = useState(3);
  const [userFormFailedAttempts, setUserFormFailedAttempts] = useState(0);
  const [userFormMaxLogins, setUserFormMaxLogins] = useState(25);
  const [userFormConsumedLogins, setUserFormConsumedLogins] = useState(0);
  const [userFormIsLocked, setUserFormIsLocked] = useState(false);
  const [userFormLockReason, setUserFormLockReason] = useState('');
  const [userFormWarehouse, setUserFormWarehouse] = useState('كافة المستودعات (عام)');
  const [userFormLocality, setUserFormLocality] = useState('كافة المحليات');
  const [userFormAllowedScreens, setUserFormAllowedScreens] = useState<AppScreenId[]>([]);
  const [userFormScreenPermissions, setUserFormScreenPermissions] = useState<Partial<Record<AppScreenId, string[]>>>({
    dashboard: ['view'],
    families: ['view'],
    nomination: [],
    delivery: [],
    reports: [],
    users: [],
    backup: []
  });
  const [userFormViewSubAreas, setUserFormViewSubAreas] = useState<string[]>(['*']);
  const [userFormNominationSubAreas, setUserFormNominationSubAreas] = useState<string[]>([]);
  const [userFormDeliverySubAreas, setUserFormDeliverySubAreas] = useState<string[]>([]);
  const [userFormEditSubAreas, setUserFormEditSubAreas] = useState<string[]>([]);
  const [userFormIsActive, setUserFormIsActive] = useState(true);

  // Simulator Test state
  const [simSelectedUserId, setSimSelectedUserId] = useState<number>(users[0]?.id || 1);
  const [simEnteredPassword, setSimEnteredPassword] = useState('');
  const [simTestTime, setSimTestTime] = useState<string>('12:00');
  const [simTestDay, setSimTestDay] = useState<string>('الأحد');
  const [simFeedbackMessage, setSimFeedbackMessage] = useState<{ type: 'success' | 'error' | 'warning'; text: string } | null>(null);

  // Success banner notification
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // ==================== ROLE ACTIONS ====================

  const handleOpenCreateRole = () => {
    setEditingRole(null);
    setRoleFormName('');
    setRoleFormBadge('دور جديد');
    setRoleFormDesc('');
    setRoleFormColor('indigo');
    setRoleFormIsManager(false);
    setRoleFormScreens(['dashboard', 'families']);
    setRoleFormScreenPermissions({
      dashboard: ['view'],
      families: ['view'],
      nomination: [],
      delivery: [],
      reports: [],
      users: [],
      backup: []
    });
    setRoleFormMaxLogins(20);
    setRoleFormMaxFailedAttempts(3);
    setRoleFormSessionDuration(60);
    setRoleFormStartTime('08:00');
    setRoleFormEndTime('17:00');
    setRoleFormViewSubAreas(['الرمال الشمالي', 'الشيخ رضوان']);
    setRoleFormNominationSubAreas([]);
    setRoleFormDeliverySubAreas([]);
    setRoleFormEditSubAreas([]);
    setRoleModalOpen(true);
  };

  const handleOpenEditRole = (role: SystemRole) => {
    setEditingRole(role);
    setRoleFormName(role.name);
    setRoleFormBadge(role.badge);
    setRoleFormDesc(role.description);
    setRoleFormColor(role.color);
    setRoleFormIsManager(role.isManager);
    setRoleFormScreens([...role.allowedScreens]);
    setRoleFormScreenPermissions({ ...role.screenPermissions });
    setRoleFormMaxLogins(role.defaultMaxLogins);
    setRoleFormMaxFailedAttempts(role.defaultMaxFailedAttempts || 3);
    setRoleFormSessionDuration(role.defaultSessionDuration);
    setRoleFormStartTime(role.defaultStartTime);
    setRoleFormEndTime(role.defaultEndTime);
    setRoleFormViewSubAreas([...role.defaultViewSubAreas]);
    setRoleFormNominationSubAreas([...role.defaultNominationSubAreas]);
    setRoleFormDeliverySubAreas([...role.defaultDeliverySubAreas]);
    setRoleFormEditSubAreas([...role.defaultEditSubAreas]);
    setRoleModalOpen(true);
  };

  const handleSaveRole = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roleFormName.trim()) {
      alert('يرجى كتابة اسم الدور الوظيفي');
      return;
    }

    if (editingRole) {
      // Update existing
      const updatedRole: SystemRole = {
        ...editingRole,
        name: roleFormName.trim(),
        badge: roleFormBadge.trim() || 'دور وظيفي',
        description: roleFormDesc.trim(),
        color: roleFormColor,
        isManager: roleFormIsManager,
        allowedScreens: [...roleFormScreens],
        screenPermissions: { ...roleFormScreenPermissions },
        defaultMaxLogins: roleFormMaxLogins,
        defaultMaxFailedAttempts: roleFormMaxFailedAttempts,
        defaultSessionDuration: roleFormSessionDuration,
        defaultStartTime: roleFormStartTime,
        defaultEndTime: roleFormEndTime,
        defaultViewSubAreas: [...roleFormViewSubAreas],
        defaultNominationSubAreas: [...roleFormNominationSubAreas],
        defaultDeliverySubAreas: [...roleFormDeliverySubAreas],
        defaultEditSubAreas: [...roleFormEditSubAreas]
      };

      setRoles(roles.map(r => r.id === editingRole.id ? updatedRole : r));
      addLog('تعديل تعريف الدور الوظيفي والصلاحيات', 'ناجح', `تم تحديث الدور (${updatedRole.name}) وربط ${updatedRole.allowedScreens.length} شاشات.`);
      showToast(`تم بنجاح حفظ وتحديث الدور: ${updatedRole.name}`);
    } else {
      // Create new
      const nextId = Math.max(...roles.map(r => r.id), 0) + 1;
      const newRole: SystemRole = {
        id: nextId,
        name: roleFormName.trim(),
        badge: roleFormBadge.trim() || 'دور جديد',
        description: roleFormDesc.trim(),
        color: roleFormColor,
        isManager: roleFormIsManager,
        allowedScreens: [...roleFormScreens],
        screenPermissions: { ...roleFormScreenPermissions },
        defaultMaxLogins: roleFormMaxLogins,
        defaultMaxFailedAttempts: roleFormMaxFailedAttempts,
        defaultSessionDuration: roleFormSessionDuration,
        defaultStartTime: roleFormStartTime,
        defaultEndTime: roleFormEndTime,
        defaultViewSubAreas: [...roleFormViewSubAreas],
        defaultNominationSubAreas: [...roleFormNominationSubAreas],
        defaultDeliverySubAreas: [...roleFormDeliverySubAreas],
        defaultEditSubAreas: [...roleFormEditSubAreas]
      };

      setRoles([...roles, newRole]);
      addLog('تعريف دور وظيفي جديد بالمنظومة', 'ناجح', `تم إنشاء الدور (${newRole.name}) برقم معرف #${nextId}.`);
      showToast(`تم إنشاء الدور الوظيفي الجديد: ${newRole.name}`);
    }

    setRoleModalOpen(false);
  };

  const handleDeleteRole = (role: SystemRole) => {
    if (role.id === 1) {
      alert('لا يمكن حذف دور مدير النظام العام الأساسي للحفاظ على أمان النظام.');
      return;
    }
    const assignedUsers = users.filter(u => u.roleId === role.id);
    if (assignedUsers.length > 0) {
      alert(`لا يمكن حذف هذا الدور لوجود ${assignedUsers.length} مستخدمين مرتبطين به حالياً. قم بنقلهم لدور آخر أولاً.`);
      return;
    }

    if (confirm(`هل أنت متأكد من حذف الدور الوظيفي (${role.name}) نهائياً؟`)) {
      setRoles(roles.filter(r => r.id !== role.id));
      addLog('حذف دور وظيفي من المنظومة', 'تحذير أمني', `تم حذف الدور (${role.name}).`);
      showToast(`تم حذف الدور: ${role.name}`);
    }
  };

  const handleDuplicateRole = (role: SystemRole) => {
    const nextId = Math.max(...roles.map(r => r.id), 0) + 1;
    const clonedRole: SystemRole = {
      ...role,
      id: nextId,
      name: `${role.name} (نسخة مكررة)`,
      badge: `${role.badge} (نسخة)`
    };
    setRoles([...roles, clonedRole]);
    addLog('استنساخ دور وظيفي كقالب', 'ناجح', `تم استنساخ الدور (${role.name}) إلى دور جديد #${nextId}.`);
    showToast(`تم إنشاء نسخة من الدور: ${clonedRole.name}`);
  };

  // Toggle screen checkbox for a role
  const toggleRoleScreen = (screenId: AppScreenId) => {
    if (roleFormScreens.includes(screenId)) {
      setRoleFormScreens(roleFormScreens.filter(s => s !== screenId));
    } else {
      setRoleFormScreens([...roleFormScreens, screenId]);
      // Give basic view permission by default if empty
      if (!roleFormScreenPermissions[screenId] || roleFormScreenPermissions[screenId].length === 0) {
        setRoleFormScreenPermissions({
          ...roleFormScreenPermissions,
          [screenId]: ['view']
        });
      }
    }
  };

  // Toggle action permission on a screen for a role
  const toggleRoleScreenAction = (screenId: AppScreenId, actionKey: string) => {
    const currentActions = roleFormScreenPermissions[screenId] || [];
    let updatedActions: string[];
    if (currentActions.includes(actionKey)) {
      updatedActions = currentActions.filter(a => a !== actionKey);
    } else {
      updatedActions = [...currentActions, actionKey];
      // ensure screen itself is allowed
      if (!roleFormScreens.includes(screenId)) {
        setRoleFormScreens([...roleFormScreens, screenId]);
      }
    }
    setRoleFormScreenPermissions({
      ...roleFormScreenPermissions,
      [screenId]: updatedActions
    });
  };

  // ==================== USER ACTIONS ====================

  const handleOpenCreateUser = () => {
    setEditingUser(null);
    setUserActiveTabInModal('info');
    setUserFormFullName('');
    setUserFormUsername('');
    setUserFormPassword('123456');
    setUserFormNationalID('40' + Math.floor(1000000 + Math.random() * 9000000));
    setUserFormEmail('');
    setUserFormPhone('0599' + Math.floor(100000 + Math.random() * 900000));
    
    const defaultRole = roles.find(r => r.id === 2) || roles[0];
    setUserFormRoleId(defaultRole.id);
    setUserFormStartTime(defaultRole.defaultStartTime);
    setUserFormEndTime(defaultRole.defaultEndTime);
    setUserFormAllowedDays([...WEEK_DAYS.slice(0, 5)]);
    setUserFormExpiryDate('2026-12-31');
    setUserFormSessionDuration(defaultRole.defaultSessionDuration);
    setUserFormMaxFailedAttempts(defaultRole.defaultMaxFailedAttempts || 3);
    setUserFormFailedAttempts(0);
    setUserFormMaxLogins(defaultRole.defaultMaxLogins);
    setUserFormConsumedLogins(0);
    setUserFormIsLocked(false);
    setUserFormLockReason('');
    setUserFormWarehouse('مستودع الشيخ رضوان المركزي');
    setUserFormLocality('الشيخ رضوان');
    setUserFormAllowedScreens([...defaultRole.allowedScreens]);
    setUserFormScreenPermissions({ ...defaultRole.screenPermissions });
    setUserFormViewSubAreas([...defaultRole.defaultViewSubAreas]);
    setUserFormNominationSubAreas([...defaultRole.defaultNominationSubAreas]);
    setUserFormDeliverySubAreas([...defaultRole.defaultDeliverySubAreas]);
    setUserFormEditSubAreas([...defaultRole.defaultEditSubAreas]);
    setUserFormIsActive(true);

    setUserModalOpen(true);
  };

  const handleOpenEditUser = (user: MockUser) => {
    setEditingUser(user);
    setUserActiveTabInModal('info');
    setUserFormFullName(user.fullName);
    setUserFormUsername(user.username);
    setUserFormPassword(user.password);
    setUserFormNationalID(user.nationalID);
    setUserFormEmail(user.email || '');
    setUserFormPhone(user.phone || '');
    setUserFormRoleId(user.roleId);
    setUserFormStartTime(user.allowedStartTime || '08:00');
    setUserFormEndTime(user.allowedEndTime || '17:00');
    setUserFormAllowedDays(user.allowedDays || [...WEEK_DAYS.slice(0, 5)]);
    setUserFormExpiryDate(user.accountExpiryDate || '2026-12-31');
    setUserFormSessionDuration(user.sessionDurationMinutes || 60);
    setUserFormMaxFailedAttempts(user.maxFailedAttempts || 3);
    setUserFormFailedAttempts(user.failedAttempts || 0);
    setUserFormMaxLogins(user.maxAllowedLogins);
    setUserFormConsumedLogins(user.consumedLogins || 0);
    setUserFormIsLocked(user.isLocked || false);
    setUserFormLockReason(user.lockReason || '');
    setUserFormWarehouse(user.allowedWarehouse || 'كافة المستودعات (عام)');
    setUserFormLocality(user.allowedLocalityName || 'كافة المحليات');
    setUserFormAllowedScreens([...user.allowedScreens]);
    setUserFormScreenPermissions(user.screenPermissions ? { ...user.screenPermissions } : {
      dashboard: ['view'],
      families: ['view'],
      nomination: [],
      delivery: [],
      reports: [],
      users: [],
      backup: []
    });
    setUserFormViewSubAreas([...user.allowedViewSubAreas]);
    setUserFormNominationSubAreas([...user.allowedNominationSubAreas]);
    setUserFormDeliverySubAreas([...user.allowedDeliverySubAreas]);
    setUserFormEditSubAreas([...user.allowedEditSubAreas]);
    setUserFormIsActive(user.isActive);

    setUserModalOpen(true);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userFormFullName.trim() || !userFormUsername.trim()) {
      alert('يرجى إدخال الاسم الرباعي واسم المستخدم.');
      return;
    }

    const assignedRole = roles.find(r => r.id === userFormRoleId);
    const roleName = assignedRole ? assignedRole.name : 'مستخدم';

    if (editingUser) {
      const updatedUser: MockUser = {
        ...editingUser,
        fullName: userFormFullName.trim(),
        username: userFormUsername.trim().toLowerCase(),
        password: userFormPassword,
        nationalID: userFormNationalID.trim(),
        email: userFormEmail.trim(),
        phone: userFormPhone.trim(),
        roleId: userFormRoleId,
        roleName,
        allowedStartTime: userFormStartTime,
        allowedEndTime: userFormEndTime,
        allowedDays: userFormAllowedDays,
        accountExpiryDate: userFormExpiryDate,
        sessionDurationMinutes: userFormSessionDuration,
        maxFailedAttempts: userFormMaxFailedAttempts,
        failedAttempts: userFormFailedAttempts,
        isLocked: userFormIsLocked,
        lockReason: userFormIsLocked ? (userFormLockReason || 'قفل أمني بواسطة الإدارة') : undefined,
        maxAllowedLogins: userFormMaxLogins,
        consumedLogins: userFormConsumedLogins,
        allowedWarehouse: userFormWarehouse,
        allowedLocalityName: userFormLocality,
        allowedScreens: [...userFormAllowedScreens],
        screenPermissions: { ...userFormScreenPermissions },
        allowedViewSubAreas: [...userFormViewSubAreas],
        allowedNominationSubAreas: [...userFormNominationSubAreas],
        allowedDeliverySubAreas: [...userFormDeliverySubAreas],
        allowedEditSubAreas: [...userFormEditSubAreas],
        isActive: userFormIsActive
      };

      setUsers(users.map(u => u.id === editingUser.id ? updatedUser : u));
      addLog('تعديل حساب المستخدم وضوابط الأمان والفترات الزمنية', 'ناجح', `تم تحديث الحساب (${updatedUser.username}) وساعات العمل (${updatedUser.allowedStartTime}-${updatedUser.allowedEndTime}) وحد المحاولات (${updatedUser.maxFailedAttempts}).`);
      showToast(`تم حفظ وتحديث بيانات المستخدم: ${updatedUser.fullName}`);
    } else {
      const nextId = Math.max(...users.map(u => u.id), 0) + 1;
      const newUser: MockUser = {
        id: nextId,
        fullName: userFormFullName.trim(),
        username: userFormUsername.trim().toLowerCase(),
        password: userFormPassword,
        nationalID: userFormNationalID.trim(),
        email: userFormEmail.trim(),
        phone: userFormPhone.trim(),
        roleId: userFormRoleId,
        roleName,
        allowedStartTime: userFormStartTime,
        allowedEndTime: userFormEndTime,
        allowedDays: userFormAllowedDays,
        accountExpiryDate: userFormExpiryDate,
        sessionDurationMinutes: userFormSessionDuration,
        maxFailedAttempts: userFormMaxFailedAttempts,
        failedAttempts: 0,
        isLocked: false,
        maxAllowedLogins: userFormMaxLogins,
        consumedLogins: 0,
        allowedWarehouse: userFormWarehouse,
        allowedLocalityName: userFormLocality,
        allowedScreens: [...userFormAllowedScreens],
        screenPermissions: { ...userFormScreenPermissions },
        allowedViewSubAreas: [...userFormViewSubAreas],
        allowedNominationSubAreas: [...userFormNominationSubAreas],
        allowedDeliverySubAreas: [...userFormDeliverySubAreas],
        allowedEditSubAreas: [...userFormEditSubAreas],
        permissions: ['families_view'],
        isActive: userFormIsActive,
        createdDate: new Date().toISOString().split('T')[0],
        createdBy: 'admin'
      };

      setUsers([...users, newUser]);
      addLog('إنشاء حساب مستخدم جديد وضبط الفترات والمحاولات', 'ناجح', `تم إنشاء الحساب (${newUser.username}) برقم #${nextId} وربطه بالدور (${roleName}).`);
      showToast(`تم إنشاء المستخدم الجديد بنجاح: ${newUser.fullName}`);
    }

    setUserModalOpen(false);
  };

  // One-click Unlock and reset failed attempts
  const handleUnlockAndResetUser = (user: MockUser) => {
    const updatedUser: MockUser = {
      ...user,
      isLocked: false,
      failedAttempts: 0,
      lockReason: undefined,
      lockedAt: undefined,
      isActive: true
    };
    setUsers(users.map(u => u.id === user.id ? updatedUser : u));
    addLog('إلغاء قفل الحساب وتصفير محاولات الدخول الخاطئة', 'ناجح', `تم فك القفل وتصفير عداد المحاولات الفاشلة للمستخدم (${user.username}).`);
    showToast(`تم فك القفل وتصفير المحاولات بنجاح للمستخدم: ${user.fullName}`);
  };

  // Toggle user lock
  const handleToggleLock = (user: MockUser) => {
    if (user.id === 1) {
      alert('لا يمكن قفل حساب المدير العام الأساسي لضمان الوصول للنظام.');
      return;
    }
    const nextLocked = !user.isLocked;
    const updatedUser: MockUser = {
      ...user,
      isLocked: nextLocked,
      lockReason: nextLocked ? 'قفل إداري يدوي من قبل مدير النظام' : undefined,
      failedAttempts: nextLocked ? user.failedAttempts : 0
    };
    setUsers(users.map(u => u.id === user.id ? updatedUser : u));
    addLog(
      nextLocked ? 'قفل حساب مستخدم يدوياً' : 'فك قفل الحساب يدوياً',
      nextLocked ? 'تحذير أمني' : 'ناجح',
      `تم ${nextLocked ? 'قفل' : 'إلغاء قفل'} الحساب (${user.username}).`
    );
    showToast(`تم ${nextLocked ? 'قفل' : 'تفعيل'} الحساب: ${user.fullName}`);
  };

  // Renew user logins quota (+5 or custom)
  const handleRenewLogins = (user: MockUser, amount: number) => {
    const newMax = (user.maxAllowedLogins || 0) + amount;
    const updatedUser: MockUser = {
      ...user,
      maxAllowedLogins: newMax,
      isActive: true,
      isLocked: false
    };
    setUsers(users.map(u => u.id === user.id ? updatedUser : u));
    addLog('تجديد وزيادة حصة مرات الدخول', 'ناجح', `تمت إضافة +${amount} مرات دخول للمستخدم (${user.username}). الحد الجديد: ${newMax}.`);
    showToast(`تمت إضافة +${amount} مرات دخول للحساب: ${user.fullName}`);
  };

  // ==================== SIMULATOR EXECUTION ====================
  const handleSimulateLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const targetUser = users.find(u => u.id === simSelectedUserId);
    if (!targetUser) return;

    // 1. Check account locked
    if (targetUser.isLocked) {
      setSimFeedbackMessage({
        type: 'error',
        text: `⛔ الحساب مقفل حالياً: ${targetUser.lockReason || 'تم قفل الحساب لتجاوز محاولات الدخول الخاطئة.'} (يرجى الضغط على زر فك القفل في جدول المستخدمين).`
      });
      addLog('محاكاة دخول فاشلة - الحساب مقفل', 'تحذير أمني', `محاولة محاكاة لحساب مقفل (${targetUser.username}).`, targetUser.id, targetUser.username);
      return;
    }

    // 2. Check password
    if (simEnteredPassword !== targetUser.password) {
      const nextFailed = (targetUser.failedAttempts || 0) + 1;
      const maxAllowed = targetUser.maxFailedAttempts || 3;

      if (nextFailed >= maxAllowed) {
        // LOCK ACCOUNT!
        const lockedUser: MockUser = {
          ...targetUser,
          failedAttempts: nextFailed,
          isLocked: true,
          lockReason: `تم قفل الحساب تلقائياً بعد ${nextFailed} محاولات دخول خاطئة متتالية بكلمة مرور خاطئة.`
        };
        setUsers(users.map(u => u.id === targetUser.id ? lockedUser : u));
        setSimFeedbackMessage({
          type: 'error',
          text: `🚨 تم تجاوز الحد الأقصى للمحاولات الخاطئة (${maxAllowed} محاولات)! تم قفل حساب (${targetUser.fullName}) تلقائياً لحماية المنظومة.`
        });
        addLog('قفل حساب تلقائي لتجاوز محاولات الدخول', 'تحذير أمني', `محاولة الدخول ${nextFailed} من ${maxAllowed}. تم تفعيل القفل التلقائي لحساب (${targetUser.username}).`, targetUser.id, targetUser.username);
      } else {
        const remaining = maxAllowed - nextFailed;
        const updatedUser: MockUser = {
          ...targetUser,
          failedAttempts: nextFailed
        };
        setUsers(users.map(u => u.id === targetUser.id ? updatedUser : u));
        setSimFeedbackMessage({
          type: 'warning',
          text: `❌ كلمة المرور غير صحيحة! تم تسجيل محاولة فاشلة (${nextFailed} من ${maxAllowed}). متبقي لديك (${remaining}) محاولات قبل قفل الحساب التلقائي!`
        });
        addLog('محاولة دخول خاطئة بكلمة مرور غير مطابقة', 'مرفوض', `محاولة فاشلة رقم ${nextFailed} للمستخدم (${targetUser.username}).`, targetUser.id, targetUser.username);
      }
      return;
    }

    // 3. Password is correct -> check working hours window
    const hourCheck = checkUserWorkingHours(targetUser, simTestTime);
    if (!hourCheck.isAllowed) {
      setSimFeedbackMessage({
        type: 'error',
        text: `⏰ تم رفض الدخول: ${hourCheck.message}`
      });
      addLog('محاولة دخول خارج ساعات العمل المصرح بها', 'مرفوض', `الوقت ${simTestTime} خارج النافذة المحددة (${targetUser.allowedStartTime} إلى ${targetUser.allowedEndTime}) للمستخدم (${targetUser.username}).`, targetUser.id, targetUser.username);
      return;
    }

    // 4. Check working day
    const dayCheck = checkUserWorkingDay(targetUser, simTestDay);
    if (!dayCheck.isAllowed) {
      setSimFeedbackMessage({
        type: 'error',
        text: `📅 تم رفض الدخول: ${dayCheck.message}`
      });
      addLog('محاولة دخول في يوم غير مصرح به', 'مرفوض', `اليوم ${simTestDay} غير مصرح به في جدول عمل المستخدم (${targetUser.username}).`, targetUser.id, targetUser.username);
      return;
    }

    // 5. Check account expiry
    if (targetUser.accountExpiryDate) {
      const today = new Date().toISOString().split('T')[0];
      if (today > targetUser.accountExpiryDate) {
        setSimFeedbackMessage({
          type: 'error',
          text: `⏳ تم رفض الدخول: انتهت صلاحية هذا الحساب بتاريخ ${targetUser.accountExpiryDate}.`
        });
        addLog('محاولة دخول بعد انتهاء تاريخ الصلاحية', 'مرفوض', `انتهت صلاحية الحساب (${targetUser.username}) بتاريخ ${targetUser.accountExpiryDate}.`, targetUser.id, targetUser.username);
        return;
      }
    }

    // 6. Check login quota
    if (targetUser.maxAllowedLogins > 0 && (targetUser.consumedLogins || 0) >= targetUser.maxAllowedLogins) {
      setSimFeedbackMessage({
        type: 'error',
        text: `🚫 تم استنفاد كامل حصة مرات الدخول المخصصة لهذا الحساب (${targetUser.maxAllowedLogins} مرات). يرجى تجديد الحصة.`
      });
      addLog('محاولة دخول بعد استنفاد حصة الدخول', 'مرفوض', `استنفاد الحصة (${targetUser.maxAllowedLogins} من ${targetUser.maxAllowedLogins}) للمستخدم (${targetUser.username}).`, targetUser.id, targetUser.username);
      return;
    }

    // SUCCESS! Reset failed attempts, increment consumed logins
    const updatedUser: MockUser = {
      ...targetUser,
      failedAttempts: 0,
      consumedLogins: (targetUser.consumedLogins || 0) + 1,
      lastLogin: `${new Date().toISOString().split('T')[0]} ${simTestTime}`
    };
    setUsers(users.map(u => u.id === targetUser.id ? updatedUser : u));

    setSimFeedbackMessage({
      type: 'success',
      text: `🎉 تسجيل دخول ناجح ومصرح به للمستخدم (${targetUser.fullName})! تم التحقق من كلمة المرور وساعات العمل (${simTestTime}) ويوم الدوام (${simTestDay}) ومطابقة الصلاحيات.`
    });

    addLog('تسجيل دخول ناجح (عبر مختبر المحاكاة)', 'ناجح', `دخول ناجح للمستخدم (${targetUser.username}) بالدور (${targetUser.roleName}). الشاشات المتاحة: ${targetUser.allowedScreens.join('، ')}.`, targetUser.id, targetUser.username);
  };

  // Filtered users for table
  const filteredUsers = users.filter(u => {
    if (roleFilter !== 'all' && u.roleId !== Number(roleFilter)) return false;
    if (statusFilter === 'active' && (!u.isActive || u.isLocked)) return false;
    if (statusFilter === 'locked' && !u.isLocked) return false;
    if (statusFilter === 'limited' && u.maxAllowedLogins === 0) return false;
    if (userSearchTerm.trim()) {
      const term = userSearchTerm.trim().toLowerCase();
      return (
        u.fullName.toLowerCase().includes(term) ||
        u.username.toLowerCase().includes(term) ||
        u.nationalID.includes(term) ||
        (u.phone && u.phone.includes(term))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 text-slate-100 font-sans" dir="rtl">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-emerald-600 text-white px-5 py-2.5 rounded-2xl shadow-2xl flex items-center gap-2 border border-emerald-400 font-bold text-xs sm:text-sm animate-bounce">
          <CheckCircle2 className="w-5 h-5 text-emerald-200" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* ==================== 1. TOP HEADER & SYSTEM SECURITY HEALTH ==================== */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950/70 border border-slate-800 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2.5 flex-wrap">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400 shadow-lg">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white tracking-wide">
                لوحة التحكم الإدارية وإدارة الصلاحيات والأمان (Admin Dashboard)
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                منظومة RBAC المتقدمة
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">
              تحكم كامل بيد مدير النظام العام: تعريف أدوار المستخدمين وتخصيص صلاحيات كل شاشة، ضبط الفترات الزمنية وساعات الدوام، والتحكم بالحد الأقصى لمحاولات الدخول الخاطئة وقفل الحسابات التلقائي.
            </p>
          </div>

          {/* Quick CTA Actions */}
          <div className="flex items-center gap-2.5 flex-wrap">
            <button
              onClick={handleOpenCreateRole}
              className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 transition shadow-lg shadow-indigo-600/30"
            >
              <Plus className="w-4 h-4" />
              <span>تعريف دور وظيفي جديد</span>
            </button>
            <button
              onClick={handleOpenCreateUser}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 transition shadow-lg shadow-emerald-600/30"
            >
              <Users className="w-4 h-4" />
              <span>إضافة حساب مستخدم</span>
            </button>
          </div>
        </div>

        {/* Security Metric Counters */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-5 pt-4 border-t border-slate-800/80">
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-[11px] text-slate-400 block mb-0.5">الأدوار المعرفة</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-indigo-400 font-mono">{roles.length}</span>
              <span className="text-[10px] text-slate-500">أدوار</span>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-[11px] text-slate-400 block mb-0.5">إجمالي المستخدمين</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-white font-mono">{users.length}</span>
              <span className="text-[10px] text-slate-500">حسابات</span>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-[11px] text-emerald-400 block mb-0.5">حسابات نشطة</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-emerald-400 font-mono">{users.filter(u => u.isActive && !u.isLocked).length}</span>
              <span className="text-[10px] text-emerald-500/80">مفعل</span>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-[11px] text-rose-400 block mb-0.5">حسابات مقفلة أمنياً</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-rose-400 font-mono">{users.filter(u => u.isLocked).length}</span>
              <span className="text-[10px] text-rose-500/80">مقفل</span>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-[11px] text-amber-400 block mb-0.5">مقيدون بساعات عمل</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-amber-300 font-mono">{users.filter(u => u.allowedStartTime !== '00:00').length}</span>
              <span className="text-[10px] text-amber-500/80">دوام محدد</span>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-[11px] text-sky-400 block mb-0.5">محاولات الدخول المسجلة</span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl font-black text-sky-400 font-mono">{logs.length}</span>
              <span className="text-[10px] text-sky-500/80">حدث أمني</span>
            </div>
          </div>
        </div>
      </div>

      {/* ==================== 2. MAIN NAVIGATION TABS ==================== */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs sm:text-sm font-bold">
        <button
          onClick={() => setActiveTab('overview')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition ${
            activeTab === 'overview'
              ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-600/30 font-extrabold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-emerald-300" />
          <span>لوحة المؤشرات والرسوم البيانية</span>
        </button>

        <button
          onClick={() => setActiveTab('subareas')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition ${
            activeTab === 'subareas'
              ? 'bg-gradient-to-r from-sky-600 to-indigo-600 text-white shadow-md shadow-sky-600/30 font-extrabold'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Server className="w-4 h-4 text-sky-300" />
          <span>خدمة المناطق وقيود Room</span>
          <span className="text-[10px] bg-sky-400/20 px-1.5 py-0.2 rounded font-mono text-sky-200">Backend</span>
        </button>

        <button
          onClick={() => setActiveTab('roles')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition ${
            activeTab === 'roles'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sliders className="w-4 h-4 text-indigo-300" />
          <span>الأدوار وربط الشاشات ({roles.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition ${
            activeTab === 'users'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Users className="w-4 h-4 text-emerald-300" />
          <span>المستخدمون والفترات والمحاولات ({users.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('matrix')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition ${
            activeTab === 'matrix'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <CheckCircle2 className="w-4 h-4 text-teal-300" />
          <span>مصفوفة الصلاحيات والشاشات</span>
        </button>

        <button
          onClick={() => setActiveTab('simulator')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition ${
            activeTab === 'simulator'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-300" />
          <span>مختبر المحاكاة واختبار القفل</span>
        </button>

        <button
          onClick={() => setActiveTab('logs')}
          className={`flex-1 min-w-[130px] py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition ${
            activeTab === 'logs'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
          }`}
        >
          <History className="w-4 h-4 text-rose-300" />
          <span>سجل التدقيق والأمان ({logs.length})</span>
        </button>
      </div>

      {/* ==================== TAB 0: VISUAL ANALYTICS & CHARTS DASHBOARD ==================== */}
      {activeTab === 'overview' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 p-5 rounded-3xl border border-slate-800 shadow-xl">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <h3 className="font-extrabold text-lg text-white flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-emerald-400" />
                  <span>لوحة مؤشرات التوزيع وحالة تنفيذ الترشيح (Visual Analytics)</span>
                </h3>
              </div>
              <p className="text-xs text-slate-400">
                إحصائيات ورسوم بيانية تحليلية لصناع القرار توضح توزيع المساعدات عبر المحليات والمناطق الفرعية الحالية ونسب إنجاز عمليات الترشيح والصرف الميداني.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-emerald-400" />
                <span>تحديث لحظي مباشر</span>
              </span>
            </div>
          </div>

          {/* Quick Metrics KPI row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 transition">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400 font-semibold">إجمالي الحصص المستهدفة</span>
                <span className="p-1.5 rounded-xl bg-indigo-500/20 text-indigo-300">
                  <TrendingUp className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-black text-white font-mono">
                {subAreasList.reduce((acc, a) => acc + a.targetFamiliesQuota, 0).toLocaleString()}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">أسرة مستهدفة عبر المناطق الفرعية الـ 5</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-sky-500/40 transition">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400 font-semibold">المسجلون في السجل</span>
                <span className="p-1.5 rounded-xl bg-sky-500/20 text-sky-300">
                  <Users className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-black text-sky-400 font-mono">
                {subAreasList.reduce((acc, a) => acc + a.registeredFamiliesCount, 0).toLocaleString()}
              </div>
              <div className="text-[11px] text-slate-500 mt-1">نسبة التغطية الميدانية 92.4%</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 transition">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400 font-semibold">تم ترشيحهم بالمشاريع</span>
                <span className="p-1.5 rounded-xl bg-amber-500/20 text-amber-300">
                  <ShieldCheck className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-black text-amber-400 font-mono">
                {subAreasList.reduce((acc, a) => acc + a.nominatedCount, 0).toLocaleString()}
              </div>
              <div className="text-[11px] text-amber-400/80 mt-1">بانتظار وتجهيز الصرف</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 transition">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-slate-400 font-semibold">المسلم فعلياً للمستفيدين</span>
                <span className="p-1.5 rounded-xl bg-emerald-500/20 text-emerald-300">
                  <PackageCheck className="w-4 h-4" />
                </span>
              </div>
              <div className="text-2xl font-black text-emerald-400 font-mono">
                {subAreasList.reduce((acc, a) => acc + a.deliveredCount, 0).toLocaleString()}
              </div>
              <div className="text-[11px] text-emerald-400/80 mt-1">طرود وسندات مستلمة</div>
            </div>
          </div>

          {/* Charts Row 1: Distribution Bar Chart + Nomination Status Donut Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Chart 1: Visual Aid Distribution per Sub-Area (Bar Chart) */}
            <div className="lg:col-span-2 p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="font-bold text-sm text-white flex items-center gap-2">
                      <BarChart3 className="w-4 h-4 text-emerald-400" />
                      <span>مقارنة المساعدات (المستهدف vs المرشح vs المسلم) بالمناطق الفرعية</span>
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      توزيع كميات الطرود الإغاثية لكل منطقة فرعية حالية معتمدة
                    </p>
                  </div>
                  <div className="flex items-center gap-3 text-[10px]">
                    <span className="flex items-center gap-1 text-slate-400">
                      <span className="w-2.5 h-2.5 rounded-sm bg-slate-700" /> الحصة
                    </span>
                    <span className="flex items-center gap-1 text-amber-300">
                      <span className="w-2.5 h-2.5 rounded-sm bg-amber-500" /> الترشيح
                    </span>
                    <span className="flex items-center gap-1 text-emerald-300">
                      <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" /> التسليم
                    </span>
                  </div>
                </div>

                {/* SVG/HTML Comparative Bar Chart */}
                <div className="space-y-3.5 pt-2">
                  {subAreasList.map((area) => {
                    const maxVal = 4500;
                    const quotaPct = Math.min(100, (area.targetFamiliesQuota / maxVal) * 100);
                    const nomPct = Math.min(100, (area.nominatedCount / maxVal) * 100);
                    const delPct = Math.min(100, (area.deliveredCount / maxVal) * 100);
                    const execRate = Math.round((area.deliveredCount / area.targetFamiliesQuota) * 100);

                    return (
                      <div key={area.id} className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-200">{area.name}</span>
                            <span className="text-[10px] text-slate-500 font-mono">({area.code})</span>
                          </div>
                          <div className="flex items-center gap-2 text-[11px]">
                            <span className="text-emerald-400 font-bold font-mono">{area.deliveredCount.toLocaleString()} مسلم</span>
                            <span className="text-slate-500">/</span>
                            <span className="text-amber-400 font-mono">{area.nominatedCount.toLocaleString()} مرشح</span>
                            <span className="text-slate-500">/</span>
                            <span className="text-slate-400 font-mono">{area.targetFamiliesQuota.toLocaleString()} مستهدف</span>
                            <span className="px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-400 font-bold text-[10px] border border-emerald-500/20 mr-1">
                              {execRate}%
                            </span>
                          </div>
                        </div>

                        {/* Multi-layered track */}
                        <div className="h-4 bg-slate-950 rounded-lg overflow-hidden relative border border-slate-800">
                          {/* Target Quota bar background */}
                          <div
                            className="h-full bg-slate-800/80 rounded-lg absolute right-0 top-0 transition-all duration-500"
                            style={{ width: `${quotaPct}%` }}
                            title={`الحصة: ${area.targetFamiliesQuota}`}
                          />
                          {/* Nominated bar */}
                          <div
                            className="h-full bg-amber-500/70 rounded-lg absolute right-0 top-0 transition-all duration-500"
                            style={{ width: `${nomPct}%` }}
                            title={`المرشح: ${area.nominatedCount}`}
                          />
                          {/* Delivered bar */}
                          <div
                            className="h-full bg-emerald-500 rounded-lg absolute right-0 top-0 transition-all duration-500"
                            style={{ width: `${delPct}%` }}
                            title={`المسلم: ${area.deliveredCount}`}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                <span>المجموع التراكمي: {subAreasList.reduce((acc, a) => acc + a.deliveredCount, 0).toLocaleString()} طرد من أصل {subAreasList.reduce((acc, a) => acc + a.targetFamiliesQuota, 0).toLocaleString()} مستهدف</span>
                <span className="text-emerald-400 font-bold">متوسط الإنجاز العام: 52.8%</span>
              </div>
            </div>

            {/* Chart 2: Nomination Pipeline Status Donut / Pie Chart */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl flex flex-col justify-between">
              <div>
                <h4 className="font-bold text-sm text-white flex items-center gap-2 mb-1">
                  <PieChart className="w-4 h-4 text-sky-400" />
                  <span>حالة تنفيذ عمليات الترشيح الخوارزمي</span>
                </h4>
                <p className="text-[11px] text-slate-400 mb-4">
                  توزيع مراحل المستفيدين في دورة حياة المساعدات
                </p>

                {/* Circular Donut Graphic */}
                <div className="relative w-44 h-44 mx-auto my-3 flex items-center justify-center">
                  <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90 transform">
                    {/* Background Circle */}
                    <circle cx="18" cy="18" r="14" fill="transparent" stroke="#1e293b" strokeWidth="4.5" />
                    {/* Segment 1: Delivered (Emerald) - 45% */}
                    <circle
                      cx="18"
                      cy="18"
                      r="14"
                      fill="transparent"
                      stroke="#10b981"
                      strokeWidth="4.5"
                      strokeDasharray="45 55"
                      strokeDashoffset="0"
                      className="transition-all duration-700"
                    />
                    {/* Segment 2: Nominated In Prep (Amber) - 25% */}
                    <circle
                      cx="18"
                      cy="18"
                      r="14"
                      fill="transparent"
                      stroke="#f59e0b"
                      strokeWidth="4.5"
                      strokeDasharray="25 75"
                      strokeDashoffset="-45"
                      className="transition-all duration-700"
                    />
                    {/* Segment 3: Waiting Nomination (Sky) - 22% */}
                    <circle
                      cx="18"
                      cy="18"
                      r="14"
                      fill="transparent"
                      stroke="#0284c7"
                      strokeWidth="4.5"
                      strokeDasharray="22 78"
                      strokeDashoffset="-70"
                      className="transition-all duration-700"
                    />
                    {/* Segment 4: Excluded temporarily (Rose) - 8% */}
                    <circle
                      cx="18"
                      cy="18"
                      r="14"
                      fill="transparent"
                      stroke="#f43f5e"
                      strokeWidth="4.5"
                      strokeDasharray="8 92"
                      strokeDashoffset="-92"
                      className="transition-all duration-700"
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center justify-center text-center">
                    <span className="text-xl font-black text-white font-mono">10,880</span>
                    <span className="text-[10px] text-slate-400">أسرة مكتملة الصرف</span>
                  </div>
                </div>

                {/* Legend & Percentages */}
                <div className="space-y-2 pt-2 text-xs">
                  <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-md bg-emerald-500" />
                      <span className="text-slate-300 font-medium">تم الصرف والتسليم بنجاح</span>
                    </div>
                    <span className="font-bold text-emerald-400 font-mono">45% (10,880)</span>
                  </div>

                  <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-md bg-amber-500" />
                      <span className="text-slate-300 font-medium">مرشح ومعتمد بالمستودع</span>
                    </div>
                    <span className="font-bold text-amber-400 font-mono">25% (4,420)</span>
                  </div>

                  <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-md bg-sky-500" />
                      <span className="text-slate-300 font-medium">مؤهل بانتظار مشاريع قادمة</span>
                    </div>
                    <span className="font-bold text-sky-400 font-mono">22% (7,200)</span>
                  </div>

                  <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950/60 border border-slate-800">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-md bg-rose-500" />
                      <span className="text-slate-300 font-medium">مستبعد مؤقتاً (فترة حظر استثناء)</span>
                    </div>
                    <span className="font-bold text-rose-400 font-mono">8% (1,950)</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800 text-[10.5px] text-slate-400 text-center">
                يتم احتساب الاستثناءات آلياً استناداً لقاعدة بيانات Room وفترات الاستفادة
              </div>
            </div>
          </div>

          {/* Row 2: Aid Categories breakdown + Geographic supervisor readiness */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Aid Categories Breakdown */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-sm text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-indigo-400" />
                    <span>توزيع المساعدات حسب التصنيفات الإغاثية الـ 11</span>
                  </h4>
                  <p className="text-[11px] text-slate-400">حجم الطرود المنفذة حسب طبيعة الاحتياج</p>
                </div>
                <span className="text-[11px] font-mono text-indigo-300 bg-indigo-500/15 px-2 py-0.5 rounded-lg border border-indigo-500/30">
                  11 تصنيف رسمي
                </span>
              </div>

              <div className="space-y-2 text-xs">
                {[
                  { name: 'طرود غذائية طارئة', count: 5240, pct: 82, color: 'bg-emerald-500' },
                  { name: 'خضروات وفواكه طازجة', count: 3180, pct: 64, color: 'bg-teal-500' },
                  { name: 'لحوم ودواجن', count: 2450, pct: 51, color: 'bg-rose-500' },
                  { name: 'مساعدات نقدية عاجلة', count: 1890, pct: 40, color: 'bg-amber-500' },
                  { name: 'فرشات وشوادر وإيواء', count: 2750, pct: 58, color: 'bg-sky-500' },
                  { name: 'بامبرز ومستلزمات أطفال', count: 1420, pct: 33, color: 'bg-purple-500' },
                  { name: 'مساعدات صحية وحقائب نظافة', count: 2100, pct: 47, color: 'bg-indigo-500' }
                ].map(item => (
                  <div key={item.name} className="space-y-1">
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="font-medium text-slate-300">{item.name}</span>
                      <span className="font-mono text-white font-bold">{item.count.toLocaleString()} طرد ({item.pct}%)</span>
                    </div>
                    <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                      <div className={`h-full ${item.color} rounded-full`} style={{ width: `${item.pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Geographical Readiness & Room DB Constraints Summary */}
            <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-bold text-sm text-white flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-teal-400" />
                    <span>جاهزية الرقابة وصناع القرار بالمناطق الفرعية الحالية</span>
                  </h4>
                  <span className="text-[10px] bg-teal-500/10 text-teal-300 border border-teal-500/30 px-2 py-0.5 rounded-md font-bold">
                    5 مناطق فرعية معتمدة
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  كافة العمليات مقيدة بسجلات الصلاحيات الجغرافية في قاعدة بيانات Room لضمان عدم تداخل الطواقم الميدانية.
                </p>

                <div className="grid grid-cols-2 gap-2 mt-4">
                  {subAreasList.slice(0, 6).map(sub => (
                    <div key={sub.id} className="p-3 rounded-2xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 transition space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white text-xs">{sub.name}</span>
                        <span className="w-2 h-2 rounded-full bg-emerald-400" />
                      </div>
                      <div className="text-[10px] text-slate-400 flex items-center justify-between">
                        <span>المشرفون: {sub.activeSupervisorsCount}</span>
                        <span className="text-emerald-400 font-mono font-bold">
                          {Math.round((sub.deliveredCount / sub.nominatedCount) * 100)}% جاهزية
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <Server className="w-4 h-4 text-indigo-400" />
                  <span className="text-slate-200">التحكم بإعدادات المناطق وربط الصلاحيات:</span>
                </div>
                <button
                  onClick={() => setActiveTab('subareas')}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1 transition"
                >
                  <span>خدمة المناطق (Backend Service)</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== TAB 0.5: BACKEND SERVICE & SUB-AREAS ROOM DB ==================== */}
      {activeTab === 'subareas' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Header Banner */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gradient-to-r from-sky-950/80 via-slate-900 to-indigo-950/80 p-5 rounded-3xl border border-sky-500/30 shadow-xl">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-0.5 rounded-md bg-sky-500/20 text-sky-300 font-mono text-[10px] font-bold border border-sky-500/30">
                  Backend Service • Room DB SQLite
                </span>
                <h3 className="font-extrabold text-lg text-white flex items-center gap-2">
                  <Server className="w-5 h-5 text-sky-400" />
                  <span>الواجهة البرمجية لإدارة المناطق الفرعية الحالية ونظام الصلاحيات الموحد</span>
                </h3>
              </div>
              <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
                خدمة برمجية مركزية (SubAreaBackendService) تربط المناطق الفرعية بجدول <code className="text-sky-300 font-mono">tbl_SubAreas</code> و <code className="text-sky-300 font-mono">tbl_Role_SubArea_Permissions</code> لضمان تقييد كل دور وظيفي بمناطق محددة (مشاهدة، تعديل، ترشيح، تسليم، أو تصدير تقارير).
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                قاعدة البيانات متصلة ومزامنة ✓
              </span>
            </div>
          </div>

          {/* Interactive Permission Evaluator Tool (Live API Test) */}
          <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-bold text-sm text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>محاكي وفاحص الواجهة البرمجية (API Permission Verification Tool)</span>
                </h4>
                <p className="text-[11px] text-slate-400">
                  اختبر فحص الصلاحية اللحظي كما ينفذها كود Room Database على الهاتف المحمول
                </p>
              </div>
              <span className="text-xs font-mono text-slate-400 bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                POST /api/permissions/check-subarea
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-950/70 border border-slate-800 text-xs">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1.5 font-bold">1. الدور الوظيفي المفحوص:</label>
                <select
                  value={selectedRoleForTest}
                  onChange={(e) => setSelectedRoleForTest(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:border-sky-500"
                >
                  {roles.map(r => (
                    <option key={r.id} value={r.id}>{r.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1.5 font-bold">2. المنطقة الفرعية الحالية:</label>
                <select
                  value={selectedSubAreaForTest}
                  onChange={(e) => setSelectedSubAreaForTest(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:border-sky-500"
                >
                  {CURRENT_SUB_AREAS.map(area => (
                    <option key={area} value={area}>{area}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[11px] text-slate-400 block mb-1.5 font-bold">3. نوع الإجراء المطلوب:</label>
                <select
                  value={selectedActionForTest}
                  onChange={(e) => setSelectedActionForTest(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-bold focus:border-sky-500"
                >
                  <option value="VIEW">مشاهدة ومعاينة (VIEW)</option>
                  <option value="NOMINATE">ترشيح ومفاضلة (NOMINATE)</option>
                  <option value="DELIVER">تسليم وصرف ميداني (DELIVER)</option>
                  <option value="EDIT">تعديل وإضافة أسر (EDIT)</option>
                  <option value="REPORT">تصدير تقارير رسمية (REPORT)</option>
                </select>
              </div>
            </div>

            {/* Test Result Evaluation */}
            {(() => {
              const currentTestRole = roles.find(r => r.id === selectedRoleForTest);
              let allowedList: string[] = [];
              if (selectedActionForTest === 'VIEW') allowedList = currentTestRole?.defaultViewSubAreas || [];
              else if (selectedActionForTest === 'NOMINATE') allowedList = currentTestRole?.defaultNominationSubAreas || [];
              else if (selectedActionForTest === 'DELIVER') allowedList = currentTestRole?.defaultDeliverySubAreas || [];
              else if (selectedActionForTest === 'EDIT') allowedList = currentTestRole?.defaultEditSubAreas || [];
              else allowedList = currentTestRole?.defaultViewSubAreas || [];

              const actionLabels = {
                VIEW: 'مشاهدة ومعاينة الأسر',
                NOMINATE: 'ترشيح ومفاضلة الأسر',
                DELIVER: 'تسليم وصرف المساعدات',
                EDIT: 'تعديل بيانات الأسر والاعتمادات',
                REPORT: 'إصدار تقارير وكشوفات PDF'
              };

              const checkResult = checkGeographicPermission(
                allowedList,
                selectedSubAreaForTest,
                actionLabels[selectedActionForTest],
                currentTestRole?.name || 'غير معروف'
              );

              return (
                <div className={`p-4 rounded-2xl border flex items-start gap-3 transition ${
                  checkResult.isAllowed
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200'
                    : 'bg-rose-950/40 border-rose-500/50 text-rose-200'
                }`}>
                  <div className={`p-2 rounded-xl shrink-0 ${checkResult.isAllowed ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                    {checkResult.isAllowed ? <CheckCircle2 className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm">
                        {checkResult.isAllowed ? '✅ الاستجابة: مصرح (200 OK - PERMITTED)' : '🚫 الاستجابة: مرفوض ومقيد جغرافياً (403 FORBIDDEN)'}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded font-mono bg-slate-900 border border-slate-700">
                        Room Entity: tbl_Role_SubArea_Permissions
                      </span>
                    </div>
                    <p className="text-xs text-slate-300">
                      {checkResult.isAllowed
                        ? `الدور (${currentTestRole?.name}) يملك الصلاحية الكاملة لتنفيذ [${actionLabels[selectedActionForTest]}] في منطقة (${selectedSubAreaForTest}). النطاق: ${checkResult.scope === 'all' ? 'كافة المناطق (*)' : 'منطقة مقيدة ومصرحة'}.`
                        : checkResult.reason}
                    </p>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Sub-Areas Room Database Records Table */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
              <div>
                <h4 className="font-bold text-base text-white flex items-center gap-2">
                  <Database className="w-4 h-4 text-sky-400" />
                  <span>جدول المناطق الفرعية الحالية (tbl_SubAreas) في Room Database</span>
                </h4>
                <p className="text-xs text-slate-400">
                  إدارة وتعديل المناطق، الحصص المستهدفة، وبيانات الربط الجغرافي للمنظومة
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-bold text-sky-300 bg-sky-500/20 px-3 py-1 rounded-xl border border-sky-500/30">
                  {subAreasList.length} مناطق فرعية معتمدة
                </span>
              </div>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-950 text-slate-300 border-b border-slate-800 font-bold">
                  <tr>
                    <th className="p-3.5">المنطقة الفرعية الحالية</th>
                    <th className="p-3.5">رمز الكود (Code)</th>
                    <th className="p-3.5">المحلية التابعة</th>
                    <th className="p-3.5">الحصة المستهدفة</th>
                    <th className="p-3.5">الأسر المسجلة</th>
                    <th className="p-3.5">تم الترشيح</th>
                    <th className="p-3.5">تم التسليم</th>
                    <th className="p-3.5">المشرفون</th>
                    <th className="p-3.5">حالة المنطقة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {subAreasList.map((area) => (
                    <tr key={area.id} className="hover:bg-slate-800/40 transition">
                      <td className="p-3.5 font-bold text-white flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{area.name}</span>
                      </td>
                      <td className="p-3.5 font-mono text-sky-300 text-xs">
                        {area.code}
                      </td>
                      <td className="p-3.5 text-slate-300">
                        {area.localityName}
                      </td>
                      <td className="p-3.5 font-mono text-white font-bold">
                        {area.targetFamiliesQuota.toLocaleString()}
                      </td>
                      <td className="p-3.5 font-mono text-slate-300">
                        {area.registeredFamiliesCount.toLocaleString()}
                      </td>
                      <td className="p-3.5 font-mono text-amber-400 font-bold">
                        {area.nominatedCount.toLocaleString()}
                      </td>
                      <td className="p-3.5 font-mono text-emerald-400 font-bold">
                        {area.deliveredCount.toLocaleString()}
                      </td>
                      <td className="p-3.5 text-slate-300 font-mono">
                        {area.activeSupervisorsCount} باحثين
                      </td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                          نشطة ومعتمدة
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==================== TAB 1: ROLES MANAGEMENT ==================== */}
      {activeTab === 'roles' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-400" />
                <span>تعريف الأدوار وربطها بصلاحيات شاشات المنظومة</span>
              </h3>
              <p className="text-xs text-slate-400">
                يمكن للمدير إضافة أي دور وظيفي جديد، تحديد الشاشات التي تظهر له، وتحديد الصلاحيات الدقيقة لكل شاشة (عرض، إضافة، تعديل، حذف، ترحيل).
              </p>
            </div>
            <button
              onClick={handleOpenCreateRole}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 transition shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة دور وظيفي جديد</span>
            </button>
          </div>

          {/* Roles Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {roles.map(role => {
              const assignedUsersCount = users.filter(u => u.roleId === role.id).length;
              return (
                <div
                  key={role.id}
                  className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-indigo-500/40 transition flex flex-col justify-between space-y-4 shadow-lg group"
                >
                  <div className="space-y-3">
                    {/* Header */}
                    <div className="flex justify-between items-start gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className={`w-3 h-3 rounded-full ${
                            role.color === 'rose' ? 'bg-rose-500' :
                            role.color === 'indigo' ? 'bg-indigo-500' :
                            role.color === 'sky' ? 'bg-sky-500' :
                            role.color === 'emerald' ? 'bg-emerald-500' :
                            role.color === 'amber' ? 'bg-amber-500' : 'bg-purple-500'
                          }`} />
                          <h4 className="font-bold text-sm text-white">{role.name}</h4>
                        </div>
                        <span className="text-[10.5px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 inline-block">
                          {role.badge}
                        </span>
                      </div>

                      {role.isManager && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 shrink-0">
                          مدير عام 👑
                        </span>
                      )}
                    </div>

                    {/* Description */}
                    <p className="text-xs text-slate-400 leading-relaxed min-h-[3rem]">
                      {role.description}
                    </p>

                    {/* Linked Screens Badges */}
                    <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
                      <span className="text-[11px] font-bold text-slate-300 block">
                        الشاشات المصرح بها ({role.allowedScreens.length} شاشات):
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {role.allowedScreens.map(scrId => {
                          const scrDef = APP_SCREENS_CATALOG.find(s => s.id === scrId);
                          const actionsCount = role.screenPermissions?.[scrId]?.length || 0;
                          return (
                            <span
                              key={scrId}
                              className="text-[10px] px-2 py-0.5 rounded-lg bg-indigo-500/15 border border-indigo-500/30 text-indigo-200 font-medium flex items-center gap-1"
                            >
                              <span>{scrDef?.shortName || scrId}</span>
                              <span className="font-mono text-[9px] bg-indigo-900/60 px-1 rounded text-indigo-300">
                                {actionsCount} إجراء
                              </span>
                            </span>
                          );
                        })}
                      </div>
                    </div>

                    {/* Security Defaults */}
                    <div className="grid grid-cols-2 gap-2 text-[10.5px] text-slate-400 bg-slate-950/60 p-2.5 rounded-xl border border-slate-850">
                      <div>
                        <span>ساعات العمل: </span>
                        <strong className="text-slate-200 font-mono">{role.defaultStartTime} - {role.defaultEndTime}</strong>
                      </div>
                      <div>
                        <span>حد المحاولات: </span>
                        <strong className="text-amber-300 font-mono">{role.defaultMaxFailedAttempts || 3} محاولات</strong>
                      </div>
                      <div>
                        <span>حصة الدخول: </span>
                        <strong className="text-sky-300 font-mono">{role.defaultMaxLogins === 0 ? 'غير محدود' : `${role.defaultMaxLogins} مرات`}</strong>
                      </div>
                      <div>
                        <span>المستخدمون: </span>
                        <strong className="text-emerald-300 font-mono">{assignedUsersCount} موظف</strong>
                      </div>
                    </div>
                  </div>

                  {/* Actions buttons */}
                  <div className="flex items-center gap-1.5 pt-2 border-t border-slate-800">
                    <button
                      onClick={() => handleOpenEditRole(role)}
                      className="flex-1 py-1.5 px-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition border border-slate-700"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-indigo-400" />
                      <span>تعديل الدور والصلاحيات</span>
                    </button>
                    <button
                      onClick={() => handleDuplicateRole(role)}
                      className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 transition"
                      title="استنساخ كقالب"
                    >
                      <Copy className="w-3.5 h-3.5 text-sky-400" />
                    </button>
                    {role.id !== 1 && (
                      <button
                        onClick={() => handleDeleteRole(role)}
                        className="p-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 border border-slate-700 transition"
                        title="حذف الدور"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ==================== TAB 2: USERS, TIME PERIODS & LOGIN ATTEMPTS ==================== */}
      {activeTab === 'users' && (
        <div className="space-y-4">
          {/* Header & Controls */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>إدارة حسابات المستخدمين وضوابط الفترات الزمنية ومحاولات الدخول</span>
              </h3>
              <p className="text-xs text-slate-400">
                تحديد ساعات الدوام، أيام العمل، الحد الأقصى لمحاولات المرور الخاطئة، وحصة مرات الدخول لكل حساب، مع إمكانية فك القفل وتصفير المحاولات بنقرة واحدة.
              </p>
            </div>
            <button
              onClick={handleOpenCreateUser}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 transition shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة مستخدم جديد</span>
            </button>
          </div>

          {/* Search & Filters */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[240px]">
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
              <input
                type="text"
                value={userSearchTerm}
                onChange={(e) => setUserSearchTerm(e.target.value)}
                placeholder="بحث: الاسم، اسم المستخدم، رقم الهوية، الجوال..."
                className="w-full pr-10 pl-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
              />
            </div>

            <select
              value={roleFilter}
              onChange={(e) => setRoleFilter(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none"
            >
              <option value="all">كافة الأدوار الوظيفية</option>
              {roles.map(r => (
                <option key={r.id} value={r.id}>{r.name}</option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none"
            >
              <option value="all">كافة الحالات</option>
              <option value="active">الحسابات النشطة والمفعلة</option>
              <option value="locked">الحسابات المقفلة أمنياً</option>
              <option value="limited">المقيدون بحصة دخول</option>
            </select>
          </div>

          {/* Users Table */}
          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 font-bold">
                <tr>
                  <th className="p-3.5">المستخدم والبيانات</th>
                  <th className="p-3.5">الدور الوظيفي</th>
                  <th className="p-3.5">المناطق الفرعية المصرحة (الـ 5)</th>
                  <th className="p-3.5">الفترات الزمنية وساعات الدوام</th>
                  <th className="p-3.5">محاولات الدخول والقفل</th>
                  <th className="p-3.5">حصة مرات الدخول</th>
                  <th className="p-3.5">الحالة والإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredUsers.map(user => {
                  const roleDef = roles.find(r => r.id === user.roleId);
                  const isExhausted = user.maxAllowedLogins > 0 && (user.consumedLogins || 0) >= user.maxAllowedLogins;
                  const isExpired = user.accountExpiryDate && new Date().toISOString().split('T')[0] > user.accountExpiryDate;

                  return (
                    <tr key={user.id} className="hover:bg-slate-800/40 transition">
                      {/* Name & Username */}
                      <td className="p-3.5">
                        <div className="space-y-0.5">
                          <div className="font-bold text-white text-xs sm:text-sm">{user.fullName}</div>
                          <div className="text-[11px] text-slate-400 flex items-center gap-2">
                            <span>اسم الدخول: <strong className="font-mono text-emerald-400">{user.username}</strong></span>
                            <span>•</span>
                            <span>هوية: <strong className="font-mono text-slate-300">{user.nationalID}</strong></span>
                          </div>
                        </div>
                      </td>

                      {/* Role */}
                      <td className="p-3.5">
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 inline-block">
                          {user.roleName}
                        </span>
                      </td>

                      {/* Allowed Sub-Areas */}
                      <td className="p-3.5">
                        <div className="space-y-1 max-w-[200px]">
                          <div className="flex items-center gap-1 text-[11px] font-bold">
                            <MapPin className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                            {user.allowedViewSubAreas?.includes('*') ? (
                              <span className="text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                                كافة المناطق الـ 5 (شامل)
                              </span>
                            ) : user.allowedViewSubAreas?.length === 1 ? (
                              <span className="text-sky-300 bg-sky-500/10 px-2 py-0.5 rounded-md border border-sky-500/20">
                                منطقة واحدة ({user.allowedViewSubAreas[0]})
                              </span>
                            ) : (user.allowedViewSubAreas?.length || 0) > 1 ? (
                              <span className="text-indigo-300 bg-indigo-500/10 px-2 py-0.5 rounded-md border border-indigo-500/20">
                                {user.allowedViewSubAreas.length} مناطق: {user.allowedViewSubAreas.join('، ')}
                              </span>
                            ) : (
                              <span className="text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-md border border-rose-500/20">
                                غير مصرح بأي منطقة
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 text-[9.5px] text-slate-400">
                            <span title="ترشيح" className={user.allowedNominationSubAreas?.length ? 'text-amber-400' : 'text-slate-600'}>
                              ⚡ ترشيح ({user.allowedNominationSubAreas?.includes('*') ? 'كامل' : user.allowedNominationSubAreas?.length || 0})
                            </span>
                            <span>•</span>
                            <span title="تسليم" className={user.allowedDeliverySubAreas?.length ? 'text-sky-400' : 'text-slate-600'}>
                              📦 تسليم ({user.allowedDeliverySubAreas?.includes('*') ? 'كامل' : user.allowedDeliverySubAreas?.length || 0})
                            </span>
                            <span>•</span>
                            <span title="تعديل" className={user.allowedEditSubAreas?.length ? 'text-rose-400' : 'text-slate-600'}>
                              ✏️ تعديل ({user.allowedEditSubAreas?.includes('*') ? 'كامل' : user.allowedEditSubAreas?.length || 0})
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Time Periods */}
                      <td className="p-3.5">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5 text-slate-200">
                            <Clock className="w-3.5 h-3.5 text-amber-400" />
                            <span className="font-mono font-bold text-xs">
                              {user.allowedStartTime || '00:00'} إلى {user.allowedEndTime || '23:59'}
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-400 flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-slate-500" />
                            <span>{user.allowedDays?.length || 7} أيام بالأسبوع</span>
                            {user.accountExpiryDate && (
                              <span className={isExpired ? 'text-rose-400 font-bold' : ''}>
                                • حتى {user.accountExpiryDate}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Login Attempts & Lock */}
                      <td className="p-3.5">
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <Key className="w-3.5 h-3.5 text-indigo-400" />
                            <span className="text-[11px] text-slate-300">
                              الحد: <strong className="font-mono text-white">{user.maxFailedAttempts || 3} محاولات</strong>
                            </span>
                          </div>
                          <div className="text-[10.5px]">
                            {user.failedAttempts > 0 ? (
                              <span className="text-rose-400 font-bold font-mono">
                                {user.failedAttempts} محاولات خاطئة مسجلة
                              </span>
                            ) : (
                              <span className="text-emerald-400 text-[10px]">0 محاولات خاطئة ✓</span>
                            )}
                          </div>
                          {user.isLocked && (
                            <div className="text-[10px] text-rose-300 font-semibold bg-rose-950/50 p-1 rounded border border-rose-800">
                              🔒 {user.lockReason || 'الحساب مقفل أمنياً'}
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Login Quota */}
                      <td className="p-3.5">
                        {user.maxAllowedLogins > 0 ? (
                          <div className="space-y-1 min-w-[120px]">
                            <div className="flex justify-between text-[10px] font-mono">
                              <span className="text-slate-300">{user.consumedLogins} / {user.maxAllowedLogins}</span>
                              <span className={isExhausted ? 'text-rose-400 font-bold' : 'text-emerald-400'}>
                                متبقي {Math.max(0, user.maxAllowedLogins - user.consumedLogins)}
                              </span>
                            </div>
                            <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
                              <div
                                className={`h-full rounded-full transition-all ${
                                  isExhausted ? 'bg-rose-500' : 'bg-emerald-500'
                                }`}
                                style={{ width: `${Math.min(100, Math.round((user.consumedLogins / user.maxAllowedLogins) * 100))}%` }}
                              />
                            </div>
                            <button
                              onClick={() => handleRenewLogins(user, 5)}
                              className="text-[9.5px] text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-0.5"
                            >
                              <RefreshCw className="w-2.5 h-2.5" />
                              <span>تجديد (+5 مرات)</span>
                            </button>
                          </div>
                        ) : (
                          <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                            دخول غير محدود (∞)
                          </span>
                        )}
                      </td>

                      {/* Status & Actions */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {user.isLocked ? (
                            <button
                              onClick={() => handleUnlockAndResetUser(user)}
                              className="px-2.5 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10.5px] flex items-center gap-1 transition shadow-md shadow-emerald-700/30"
                              title="فك القفل وتصفير المحاولات الفاشلة"
                            >
                              <Unlock className="w-3 h-3" />
                              <span>فك القفل وتصفير</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => handleToggleLock(user)}
                              className="p-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/40 text-slate-300 hover:text-rose-400 border border-slate-700 transition"
                              title="قفل الحساب يدوياً"
                            >
                              <Lock className="w-3.5 h-3.5" />
                            </button>
                          )}

                          <button
                            onClick={() => handleOpenEditUser(user)}
                            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-indigo-300 border border-slate-700 transition"
                            title="تعديل المستخدم والصلاحيات"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {onOpenEmulatorWithUser && (
                            <button
                              onClick={() => onOpenEmulatorWithUser(user.username)}
                              className="px-2 py-1 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-200 text-[10px] font-bold flex items-center gap-1 transition"
                              title="تجربة الدخول في محاكي الهاتف"
                            >
                              <Smartphone className="w-3 h-3" />
                              <span>محاكاة</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================== TAB 3: SCREEN PERMISSIONS MATRIX ==================== */}
      {activeTab === 'matrix' && (
        <div className="space-y-4">
          <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
            <h3 className="font-bold text-base text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-400" />
              <span>مصفوفة الصلاحيات والشاشات التفاعلية (Screens & Permissions Matrix)</span>
            </h3>
            <p className="text-xs text-slate-400">
              استعراض شامل لربط الأدوار الوظيفية بكافة شاشات التطبيق والإجراءات المتاحة لكل شاشة بصورة بصرية واضحة.
            </p>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl">
            <table className="w-full text-center text-xs">
              <thead className="bg-slate-950 text-slate-300 border-b border-slate-800 font-bold">
                <tr>
                  <th className="p-3 text-right">الدور الوظيفي</th>
                  {APP_SCREENS_CATALOG.map(scr => (
                    <th key={scr.id} className="p-3 min-w-[120px]">
                      <div className="space-y-0.5">
                        <span className="block font-bold text-white text-xs">{scr.shortName}</span>
                        <span className="text-[9.5px] text-slate-400 font-normal">{scr.actions.length} إجراءات</span>
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {roles.map(role => (
                  <tr key={role.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-3 text-right font-bold text-white">
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${
                          role.color === 'rose' ? 'bg-rose-500' :
                          role.color === 'indigo' ? 'bg-indigo-500' :
                          role.color === 'sky' ? 'bg-sky-500' :
                          role.color === 'emerald' ? 'bg-emerald-500' : 'bg-amber-500'
                        }`} />
                        <span>{role.name}</span>
                      </div>
                    </td>

                    {APP_SCREENS_CATALOG.map(scr => {
                      const isAllowed = role.allowedScreens.includes(scr.id);
                      const actionsAllowed = role.screenPermissions?.[scr.id] || [];

                      return (
                        <td key={scr.id} className="p-3">
                          {isAllowed ? (
                            <div className="inline-flex flex-col items-center">
                              <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold text-xs">
                                ✓
                              </span>
                              <span className="text-[9.5px] font-mono text-emerald-300 mt-1">
                                {actionsAllowed.length} من {scr.actions.length}
                              </span>
                            </div>
                          ) : (
                            <span className="w-6 h-6 rounded-full bg-slate-800 text-slate-600 flex items-center justify-center font-bold text-xs mx-auto">
                              ✕
                            </span>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================== TAB 4: SIMULATOR & POLICY TESTER ==================== */}
      {activeTab === 'simulator' && (
        <div className="space-y-4">
          <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
            <h3 className="font-bold text-base text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>مختبر المحاكاة واختبار سياسات الدخول والقفل التلقائي</span>
            </h3>
            <p className="text-xs text-slate-400">
              يمكنك تجربة واختبار منظومة الأمان الحقيقية: اختر أي مستخدم، جرب إدخال كلمة مرور خاطئة متكررة لمشاهدة قفل الحساب عند تجاوز الحد الأقصى، أو اختبر تسجيل الدخول خارج ساعات العمل المحددة!
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Interactive Simulation Form */}
            <form onSubmit={handleSimulateLogin} className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl">
              <h4 className="font-bold text-sm text-white flex items-center gap-2 border-b border-slate-800 pb-2">
                <LogIn className="w-4 h-4 text-indigo-400" />
                <span>نموذج محاكاة تسجيل الدخول الحي</span>
              </h4>

              {/* Select User */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 block">اختر حساب المستخدم للتجربة:</label>
                <select
                  value={simSelectedUserId}
                  onChange={(e) => {
                    const id = Number(e.target.value);
                    setSimSelectedUserId(id);
                    setSimFeedbackMessage(null);
                  }}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500 font-bold"
                >
                  {users.map(u => (
                    <option key={u.id} value={u.id}>
                      {u.fullName} ({u.username}) - دور: {u.roleName} {u.isLocked ? '[🔒 مقفل]' : ''}
                    </option>
                  ))}
                </select>
              </div>

              {/* Target User Status Snapshot */}
              {(() => {
                const selected = users.find(u => u.id === simSelectedUserId);
                if (!selected) return null;
                return (
                  <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-slate-400">حالة الحساب:</span>
                      <span className={`font-bold px-2 py-0.5 rounded-full text-[10px] ${
                        selected.isLocked ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'
                      }`}>
                        {selected.isLocked ? '🔒 مقفل' : '✓ نشط ومفعل'}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="text-slate-400">ساعات الدوام المصرحة:</span>
                      <span className="font-mono text-amber-300 font-bold">{selected.allowedStartTime} إلى {selected.allowedEndTime}</span>
                    </div>
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="text-slate-400">الحد الأقصى لمحاولات المرور:</span>
                      <span className="font-mono text-white font-bold">{selected.maxFailedAttempts || 3} محاولات</span>
                    </div>
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="text-slate-400">المحاولات الفاشلة الحالية:</span>
                      <span className="font-mono text-rose-400 font-bold">{selected.failedAttempts || 0} من {selected.maxFailedAttempts || 3}</span>
                    </div>
                    <div className="flex justify-between items-center text-[11px] pt-1 border-t border-slate-900">
                      <span className="text-slate-400">كلمة المرور الصحيحة للحساب:</span>
                      <code className="text-emerald-400 font-mono bg-emerald-950/60 px-1.5 py-0.5 rounded font-bold">
                        {selected.password}
                      </code>
                    </div>
                  </div>
                );
              })()}

              {/* Password field */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-bold text-slate-300 block">كلمة المرور للتجربة:</label>
                  <span className="text-[10px] text-slate-400">جرب إدخال كلمة خاطئة لاختبار القفل</span>
                </div>
                <input
                  type="text"
                  value={simEnteredPassword}
                  onChange={(e) => setSimEnteredPassword(e.target.value)}
                  placeholder="أدخل كلمة مرور (صحيحة أو خاطئة)"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* Simulated Time & Day */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-300 block">وقت المحاكاة المفترض:</label>
                  <input
                    type="time"
                    value={simTestTime}
                    onChange={(e) => setSimTestTime(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono"
                  />
                  <span className="text-[9.5px] text-slate-500 block">لتجربة الدوام خارج الساعات</span>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] text-slate-300 block">يوم الأسبوع المفترض:</label>
                  <select
                    value={simTestDay}
                    onChange={(e) => setSimTestDay(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2 py-1.5 text-xs text-white"
                  >
                    {WEEK_DAYS.map(day => (
                      <option key={day} value={day}>{day}</option>
                    ))}
                  </select>
                  <span className="text-[9.5px] text-slate-500 block">لتجربة أيام الإجازة</span>
                </div>
              </div>

              {/* Submit Test Button */}
              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition shadow-lg shadow-indigo-600/30"
              >
                <LogIn className="w-4 h-4" />
                <span>تنفيذ تجربة محاكاة الدخول والتحقق الأمني</span>
              </button>
            </form>

            {/* Simulation Feedback Card */}
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4 shadow-xl flex flex-col justify-between">
              <div className="space-y-3">
                <h4 className="font-bold text-sm text-white flex items-center gap-2 border-b border-slate-800 pb-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>نتيجة الفحص الأمني المباشر</span>
                </h4>

                {simFeedbackMessage ? (
                  <div className={`p-4 rounded-2xl border text-xs sm:text-sm leading-relaxed space-y-2 ${
                    simFeedbackMessage.type === 'success'
                      ? 'bg-emerald-950/50 border-emerald-500/40 text-emerald-200'
                      : simFeedbackMessage.type === 'warning'
                      ? 'bg-amber-950/50 border-amber-500/40 text-amber-200'
                      : 'bg-rose-950/50 border-rose-500/40 text-rose-200'
                  }`}>
                    <div className="font-bold flex items-center gap-2">
                      {simFeedbackMessage.type === 'success' && <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />}
                      {simFeedbackMessage.type === 'warning' && <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />}
                      {simFeedbackMessage.type === 'error' && <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0" />}
                      <span>{simFeedbackMessage.type === 'success' ? 'دخول مصرح' : 'تنبيه أمني'}</span>
                    </div>
                    <p>{simFeedbackMessage.text}</p>
                  </div>
                ) : (
                  <div className="p-6 rounded-2xl bg-slate-950/60 border border-dashed border-slate-800 text-center space-y-2 text-slate-400">
                    <Shield className="w-8 h-8 mx-auto text-slate-600" />
                    <p className="text-xs">
                      قم باختيار المستخدم وإدخال كلمة المرور والوقت، ثم اضغط على زر "تنفيذ تجربة المحاكاة" لاختبار السياسات.
                    </p>
                  </div>
                )}
              </div>

              {/* Explanatory security notes */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] text-slate-300 space-y-1.5 leading-relaxed">
                <span className="font-bold text-indigo-400 block">💡 كيف تعمل سياسة الأمان:</span>
                <p>
                  1. كل محاولة مرور خاطئة ترفع عداد <strong className="text-rose-400 font-mono">failedAttempts</strong> الخاص بالمستخدم.
                </p>
                <p>
                  2. عند بلوغ <strong className="text-white font-mono">maxFailedAttempts</strong>، يتم تحويل حالة الحساب إلى <strong className="text-rose-400 font-mono">isLocked = true</strong> فوراً وتسجيل حدث في سجل التدقيق الأمني.
                </p>
                <p>
                  3. يمكن للمدير فك القفل وتصفير العداد في أي وقت بنقرة واحدة من جدول المستخدمين.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== TAB 5: AUDIT LOGS ==================== */}
      {activeTab === 'logs' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/60 p-4 rounded-2xl border border-slate-800">
            <div>
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <History className="w-4 h-4 text-rose-400" />
                <span>سجل التدقيق الأمني ومحاولات الدخول (Audit Logs)</span>
              </h3>
              <p className="text-xs text-slate-400">
                توثيق لحظي لكافة محاولات الدخول الناجحة، المحاولات الفاشلة، عمليات القفل التلقائي، وتعديلات الصلاحيات.
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-indigo-300 bg-indigo-500/20 px-3 py-1 rounded-xl border border-indigo-500/30">
              {logs.length} أحداث مسجلة
            </span>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900/90 shadow-xl">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-bold">
                <tr>
                  <th className="p-3.5">المعرف والتوقيت</th>
                  <th className="p-3.5">المستخدم</th>
                  <th className="p-3.5">العملية والحدث</th>
                  <th className="p-3.5">الحالة</th>
                  <th className="p-3.5">التفاصيل الفنية</th>
                  <th className="p-3.5">الجهاز و IP</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {logs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-3.5">
                      <span className="font-bold text-slate-300 block">{log.id}</span>
                      <span className="text-[10px] text-slate-500">{log.timestamp}</span>
                    </td>
                    <td className="p-3.5 font-bold text-white font-sans">
                      {log.username}
                    </td>
                    <td className="p-3.5 font-sans text-slate-200">
                      {log.action}
                    </td>
                    <td className="p-3.5">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        log.status === 'ناجح'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : log.status === 'مرفوض'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      }`}>
                        {log.status}
                      </span>
                    </td>
                    <td className="p-3.5 font-sans text-slate-300 text-[11px] max-w-xs truncate">
                      {log.details}
                    </td>
                    <td className="p-3.5 text-slate-400 text-[10px]">
                      <span>{log.ip}</span>
                      <span className="block truncate text-slate-500">{log.device}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================== ROLE EDITOR MODAL ==================== */}
      {roleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-3xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex justify-between items-center bg-slate-950/80">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
                  <Sliders className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    {editingRole ? `تعديل الدور الوظيفي: ${editingRole.name}` : 'تعريف دور وظيفي جديد بالمنظومة'}
                  </h3>
                  <p className="text-[11px] text-slate-400">ربط الدور بالشاشات والصلاحيات الدقيقة</p>
                </div>
              </div>
              <button
                onClick={() => setRoleModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleSaveRole} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
              {/* Basic Role Info */}
              <div className="p-4 rounded-2xl bg-slate-850 border border-slate-750 space-y-3">
                <span className="font-bold text-xs text-indigo-300 block">1. البيانات التعريفية للدور:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-[11px] text-slate-300 block mb-1">اسم الدور الوظيفي:</label>
                    <input
                      type="text"
                      value={roleFormName}
                      onChange={(e) => setRoleFormName(e.target.value)}
                      placeholder="مثال: مسؤول صرف المحافظة الوسطى"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-300 block mb-1">شارة الدور (Badge):</label>
                    <input
                      type="text"
                      value={roleFormBadge}
                      onChange={(e) => setRoleFormBadge(e.target.value)}
                      placeholder="مثال: مسؤول صرف"
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="text-[11px] text-slate-300 block mb-1">وصف المسؤوليات:</label>
                    <textarea
                      rows={2}
                      value={roleFormDesc}
                      onChange={(e) => setRoleFormDesc(e.target.value)}
                      placeholder="اشرح نطاق عمل هذا الدور..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-300 block mb-1">لون الشارة:</label>
                    <select
                      value={roleFormColor}
                      onChange={(e) => setRoleFormColor(e.target.value as any)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2 text-xs text-white"
                    >
                      <option value="indigo">نيلي (Indigo)</option>
                      <option value="sky">سماوي (Sky)</option>
                      <option value="emerald">زمردي (Emerald)</option>
                      <option value="amber">عنبري (Amber)</option>
                      <option value="purple">بنفسجي (Purple)</option>
                      <option value="rose">وردي (Rose)</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2 pt-4">
                    <input
                      type="checkbox"
                      id="isManagerRoleCheck"
                      checked={roleFormIsManager}
                      onChange={(e) => setRoleFormIsManager(e.target.checked)}
                      className="w-4 h-4 rounded text-indigo-600 bg-slate-900 border-slate-700"
                    />
                    <label htmlFor="isManagerRoleCheck" className="text-xs text-slate-200 cursor-pointer font-bold">
                      دور مدير عام (يمنح كامل الشاشات والإعدادات)
                    </label>
                  </div>
                </div>
              </div>

              {/* Screen Linkage & Granular Permissions */}
              <div className="p-4 rounded-2xl bg-slate-850 border border-slate-750 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-xs text-emerald-300 block">
                    2. ربط الدور بالشاشات والصلاحيات التفصيلية لكل شاشة:
                  </span>
                  <span className="text-[10px] text-slate-400">حدد ما يظهر وما يُسمح به</span>
                </div>

                <div className="space-y-3">
                  {APP_SCREENS_CATALOG.map(scr => {
                    const isScreenChecked = roleFormScreens.includes(scr.id);
                    const selectedActions = roleFormScreenPermissions[scr.id] || [];

                    return (
                      <div
                        key={scr.id}
                        className={`p-3.5 rounded-2xl border transition space-y-2.5 ${
                          isScreenChecked
                            ? 'bg-slate-900 border-indigo-500/40'
                            : 'bg-slate-900/40 border-slate-800 opacity-60'
                        }`}
                      >
                        {/* Screen Master Toggle */}
                        <div className="flex justify-between items-center">
                          <label className="flex items-center gap-2.5 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={isScreenChecked}
                              onChange={() => toggleRoleScreen(scr.id)}
                              className="w-4 h-4 rounded text-indigo-600 bg-slate-800 border-slate-750"
                            />
                            <div>
                              <span className="font-bold text-xs sm:text-sm text-white block">
                                {scr.name}
                              </span>
                              <span className="text-[10px] text-slate-400">{scr.description}</span>
                            </div>
                          </label>

                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                            isScreenChecked ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-500'
                          }`}>
                            {isScreenChecked ? 'مفعلة' : 'محجوبة'}
                          </span>
                        </div>

                        {/* Screen Actions Checkboxes */}
                        {isScreenChecked && (
                          <div className="pt-2 border-t border-slate-800/80">
                            <span className="text-[10px] font-bold text-slate-300 block mb-1.5">
                              الإجراءات المصرح بها داخل الشاشة:
                            </span>
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                              {scr.actions.map(action => {
                                const isActionChecked = selectedActions.includes(action.key);
                                return (
                                  <label
                                    key={action.key}
                                    className={`p-2 rounded-xl border text-[11px] flex items-start gap-2 cursor-pointer transition ${
                                      isActionChecked
                                        ? 'bg-indigo-950/40 border-indigo-500/50 text-indigo-200'
                                        : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:bg-slate-950'
                                    }`}
                                  >
                                    <input
                                      type="checkbox"
                                      checked={isActionChecked}
                                      onChange={() => toggleRoleScreenAction(scr.id, action.key)}
                                      className="w-3.5 h-3.5 rounded mt-0.5 text-indigo-600 bg-slate-800 border-slate-700"
                                    />
                                    <div className="space-y-0.5">
                                      <span className="font-bold block">{action.name}</span>
                                      <span className="text-[9.5px] text-slate-500 block leading-tight">{action.description}</span>
                                    </div>
                                  </label>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Default Security Limits */}
              <div className="p-4 rounded-2xl bg-slate-850 border border-slate-750 space-y-3">
                <span className="font-bold text-xs text-amber-300 block">3. السياسات والقيود الافتراضية المقترحة لهذا الدور:</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="text-[10.5px] text-slate-300 block mb-1">وقت بدء الدوام:</label>
                    <input
                      type="time"
                      value={roleFormStartTime}
                      onChange={(e) => setRoleFormStartTime(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10.5px] text-slate-300 block mb-1">وقت نهاية الدوام:</label>
                    <input
                      type="time"
                      value={roleFormEndTime}
                      onChange={(e) => setRoleFormEndTime(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10.5px] text-slate-300 block mb-1">حد المحاولات الخاطئة:</label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      value={roleFormMaxFailedAttempts}
                      onChange={(e) => setRoleFormMaxFailedAttempts(Math.max(1, Number(e.target.value)))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="text-[10.5px] text-slate-300 block mb-1">حصة الدخول (0=دائم):</label>
                    <input
                      type="number"
                      min="0"
                      max="999"
                      value={roleFormMaxLogins}
                      onChange={(e) => setRoleFormMaxLogins(Math.max(0, Number(e.target.value)))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex gap-2.5 pt-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm transition shadow-lg shadow-indigo-600/30"
                >
                  {editingRole ? 'حفظ وتطبيق تعديلات الدور' : 'إنشاء وحفظ الدور الوظيفي الجديد'}
                </button>
                <button
                  type="button"
                  onClick={() => setRoleModalOpen(false)}
                  className="py-2.5 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs sm:text-sm transition"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ==================== USER EDITOR MODAL ==================== */}
      {userModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-3xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex justify-between items-center bg-slate-950/80">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <Users className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    {editingUser ? `تعديل حساب: ${editingUser.fullName}` : 'إضافة وتخصيص حساب مستخدم جديد'}
                  </h3>
                  <p className="text-[11px] text-slate-400">ضبط الفترات الزمنية، عدد المحاولات، والصلاحيات</p>
                </div>
              </div>
              <button
                onClick={() => setUserModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Tab Navigation */}
            <div className="flex border-b border-slate-800 bg-slate-950 px-4 text-xs font-bold overflow-x-auto gap-2">
              <button
                type="button"
                onClick={() => setUserActiveTabInModal('info')}
                className={`py-2.5 px-3 border-b-2 transition shrink-0 ${
                  userActiveTabInModal === 'info'
                    ? 'border-indigo-500 text-indigo-400 font-bold'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                1. البيانات والدور
              </button>
              <button
                type="button"
                onClick={() => setUserActiveTabInModal('time')}
                className={`py-2.5 px-3 border-b-2 transition shrink-0 flex items-center gap-1.5 ${
                  userActiveTabInModal === 'time'
                    ? 'border-indigo-500 text-amber-300 font-bold'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>2. الفترات الزمنية والدوام</span>
              </button>
              <button
                type="button"
                onClick={() => setUserActiveTabInModal('attempts')}
                className={`py-2.5 px-3 border-b-2 transition shrink-0 flex items-center gap-1.5 ${
                  userActiveTabInModal === 'attempts'
                    ? 'border-indigo-500 text-rose-300 font-bold'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                <Key className="w-3.5 h-3.5 text-rose-400" />
                <span>3. محاولات الدخول والقفل</span>
              </button>
              <button
                type="button"
                onClick={() => setUserActiveTabInModal('screens')}
                className={`py-2.5 px-3 border-b-2 transition shrink-0 ${
                  userActiveTabInModal === 'screens'
                    ? 'border-indigo-500 text-indigo-400 font-bold'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                4. الشاشات المخصصة
              </button>
              <button
                type="button"
                onClick={() => setUserActiveTabInModal('areas')}
                className={`py-2.5 px-3 border-b-2 transition shrink-0 ${
                  userActiveTabInModal === 'areas'
                    ? 'border-indigo-500 text-indigo-400 font-bold'
                    : 'border-transparent text-slate-400 hover:text-white'
                }`}
              >
                5. المناطق الفرعية
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleSaveUser} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
              {/* TAB 1: BASIC INFO & ROLE */}
              {userActiveTabInModal === 'info' && (
                <div className="space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] text-slate-300 block mb-1">الاسم الرباعي الكامل:</label>
                      <input
                        type="text"
                        value={userFormFullName}
                        onChange={(e) => setUserFormFullName(e.target.value)}
                        placeholder="أحمد محمد الشوا"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-300 block mb-1">اسم المستخدم (Login Username):</label>
                      <input
                        type="text"
                        value={userFormUsername}
                        onChange={(e) => setUserFormUsername(e.target.value)}
                        placeholder="ahmed_shawa"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-300 block mb-1">كلمة المرور:</label>
                      <input
                        type="text"
                        value={userFormPassword}
                        onChange={(e) => setUserFormPassword(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-300 block mb-1">رقم الهوية الوطنية (9 أرقام):</label>
                      <input
                        type="text"
                        value={userFormNationalID}
                        onChange={(e) => setUserFormNationalID(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-300 block mb-1">رقم الجوال:</label>
                      <input
                        type="text"
                        value={userFormPhone}
                        onChange={(e) => setUserFormPhone(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-300 block mb-1">البريد الإلكتروني:</label>
                      <input
                        type="email"
                        value={userFormEmail}
                        onChange={(e) => setUserFormEmail(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                      />
                    </div>
                  </div>

                  {/* Role Selector with auto-populate */}
                  <div className="p-3.5 rounded-2xl bg-slate-850 border border-slate-750 space-y-2">
                    <label className="text-xs font-bold text-indigo-300 block">
                      🛡️ اختيار الدور الوظيفي المربوط بالحساب:
                    </label>
                    <select
                      value={userFormRoleId}
                      onChange={(e) => {
                        const rId = Number(e.target.value);
                        setUserFormRoleId(rId);
                        const r = roles.find(item => item.id === rId);
                        if (r) {
                          setUserFormAllowedScreens([...r.allowedScreens]);
                          setUserFormScreenPermissions({ ...r.screenPermissions });
                          setUserFormStartTime(r.defaultStartTime);
                          setUserFormEndTime(r.defaultEndTime);
                          setUserFormMaxLogins(r.defaultMaxLogins);
                          setUserFormMaxFailedAttempts(r.defaultMaxFailedAttempts || 3);
                          setUserFormSessionDuration(r.defaultSessionDuration);
                          setUserFormViewSubAreas([...r.defaultViewSubAreas]);
                          setUserFormNominationSubAreas([...r.defaultNominationSubAreas]);
                          setUserFormDeliverySubAreas([...r.defaultDeliverySubAreas]);
                          setUserFormEditSubAreas([...r.defaultEditSubAreas]);
                        }
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white font-bold"
                    >
                      {roles.map(r => (
                        <option key={r.id} value={r.id}>{r.name}</option>
                      ))}
                    </select>
                    <p className="text-[10.5px] text-slate-400">
                      يتم تحميل شاشات الدور وصلاحياته وفتراته الزمنية الافتراضية تلقائياً، مع إمكانية تعديلها في التبويبات التالية.
                    </p>
                  </div>
                </div>
              )}

              {/* TAB 2: TIME PERIODS & WORKING HOURS */}
              {userActiveTabInModal === 'time' && (
                <div className="space-y-4 text-xs">
                  <div className="p-4 rounded-2xl bg-slate-850 border border-slate-750 space-y-3">
                    <span className="font-bold text-xs text-amber-300 flex items-center gap-1.5">
                      <Clock className="w-4 h-4" />
                      <span>تحديد ساعات العمل المسموح بها يومياً:</span>
                    </span>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] text-slate-300 block mb-1">وقت بدء الدوام:</label>
                        <input
                          type="time"
                          value={userFormStartTime}
                          onChange={(e) => setUserFormStartTime(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-[11px] text-slate-300 block mb-1">وقت نهاية الدوام:</label>
                        <input
                          type="time"
                          value={userFormEndTime}
                          onChange={(e) => setUserFormEndTime(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                        />
                      </div>
                    </div>

                    {/* Quick Presets */}
                    <div className="space-y-1 pt-1">
                      <span className="text-[10px] text-slate-400 block">أوقات جاهزة سريعة:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          { label: 'كامل اليوم (24/7)', start: '00:00', end: '23:59' },
                          { label: 'دوام صباحي (08:00 - 15:00)', start: '08:00', end: '15:00' },
                          { label: 'دوام إداري (08:00 - 17:00)', start: '08:00', end: '17:00' },
                          { label: 'دوام مسائي (15:00 - 22:00)', start: '15:00', end: '22:00' }
                        ].map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => {
                              setUserFormStartTime(preset.start);
                              setUserFormEndTime(preset.end);
                            }}
                            className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] font-semibold text-slate-300 transition"
                          >
                            {preset.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Allowed Working Days */}
                  <div className="p-4 rounded-2xl bg-slate-850 border border-slate-750 space-y-2.5">
                    <span className="font-bold text-xs text-amber-300 flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" />
                      <span>أيام الأسبوع المصرح بالدخول والعمل فيها:</span>
                    </span>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {WEEK_DAYS.map(day => {
                        const isDayAllowed = userFormAllowedDays.includes(day);
                        return (
                          <button
                            key={day}
                            type="button"
                            onClick={() => {
                              if (isDayAllowed) {
                                setUserFormAllowedDays(userFormAllowedDays.filter(d => d !== day));
                              } else {
                                setUserFormAllowedDays([...userFormAllowedDays, day]);
                              }
                            }}
                            className={`p-2 rounded-xl text-center text-xs font-bold transition border ${
                              isDayAllowed
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                : 'bg-slate-900 text-slate-500 border-slate-800'
                            }`}
                          >
                            {day} {isDayAllowed ? '✓' : ''}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Account Expiry & Session duration */}
                  <div className="p-4 rounded-2xl bg-slate-850 border border-slate-750 space-y-3">
                    <span className="font-bold text-xs text-sky-300 block">صلاحية الحساب والجلسة:</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] text-slate-300 block mb-1">تاريخ انتهاء صلاحية الحساب:</label>
                        <input
                          type="date"
                          value={userFormExpiryDate}
                          onChange={(e) => setUserFormExpiryDate(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                        />
                        <span className="text-[10px] text-slate-500 block mt-0.5">يحظر الدخول تلقائياً بعد هذا التاريخ</span>
                      </div>

                      <div>
                        <label className="text-[11px] text-slate-300 block mb-1">مدة الجلسة القصوى (بالدقائق):</label>
                        <input
                          type="number"
                          min="15"
                          max="720"
                          value={userFormSessionDuration}
                          onChange={(e) => setUserFormSessionDuration(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono"
                        />
                        <span className="text-[10px] text-slate-500 block mt-0.5">تسجيل خروج تلقائي لانتهاء المهلة</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: LOGIN ATTEMPTS & LOCKOUT POLICY */}
              {userActiveTabInModal === 'attempts' && (
                <div className="space-y-4 text-xs">
                  {/* Failed attempts limit */}
                  <div className="p-4 rounded-2xl bg-slate-850 border border-slate-750 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-xs text-rose-300 flex items-center gap-1.5">
                        <Key className="w-4 h-4" />
                        <span>الحد الأقصى لمحاولات كلمة المرور الخاطئة قبل القفل:</span>
                      </span>
                      <span className="font-mono text-sm font-bold text-rose-400">
                        {userFormMaxFailedAttempts} محاولات
                      </span>
                    </div>

                    <p className="text-[10.5px] text-slate-400">
                      إذا أدخل المستخدم كلمة المرور بشكل غير صحيح متتالي هذا العدد من المرات، يتم قفل الحساب فوراً تلقائياً لمنع الهجمات والتخمين.
                    </p>

                    <div className="grid grid-cols-4 gap-2">
                      {[3, 5, 7, 10].map(cnt => (
                        <button
                          key={cnt}
                          type="button"
                          onClick={() => setUserFormMaxFailedAttempts(cnt)}
                          className={`py-2 rounded-xl border text-xs font-bold transition ${
                            userFormMaxFailedAttempts === cnt
                              ? 'bg-rose-600 text-white border-rose-500 shadow'
                              : 'bg-slate-900 text-slate-300 border-slate-800'
                          }`}
                        >
                          {cnt} محاولات
                        </button>
                      ))}
                    </div>

                    {/* Reset failed attempts */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                      <div>
                        <span className="text-slate-300 font-bold block">المحاولات الفاشلة الحالية المسجلة:</span>
                        <span className="text-[10px] text-slate-500">تم تسجيل {userFormFailedAttempts} محاولات خاطئة لهذا الحساب</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setUserFormFailedAttempts(0);
                          setUserFormIsLocked(false);
                          showToast('تم تصفير المحاولات الفاشلة!');
                        }}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-500/40 text-emerald-300 font-bold text-[11px] flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        <span>تصفير إلى 0 الآن</span>
                      </button>
                    </div>
                  </div>

                  {/* Overall Login Quota */}
                  <div className="p-4 rounded-2xl bg-slate-850 border border-slate-750 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-xs text-amber-300">
                        الحد الأقصى الإجمالي لعدد مرات الدخول (Login Quota):
                      </span>
                      <span className="font-mono text-xs font-bold text-amber-400">
                        {userFormMaxLogins === 0 ? 'غير محدود (∞)' : `${userFormMaxLogins} مرة`}
                      </span>
                    </div>

                    <div className="grid grid-cols-5 gap-1.5 text-center font-bold">
                      {[
                        { label: 'دائم (∞)', val: 0 },
                        { label: '10 مرات', val: 10 },
                        { label: '25 مرة', val: 25 },
                        { label: '50 مرة', val: 50 },
                        { label: '100 مرة', val: 100 }
                      ].map(opt => (
                        <button
                          key={opt.val}
                          type="button"
                          onClick={() => setUserFormMaxLogins(opt.val)}
                          className={`py-1.5 rounded-xl border text-[11px] transition ${
                            userFormMaxLogins === opt.val
                              ? 'bg-amber-600 text-white border-amber-500'
                              : 'bg-slate-900 text-slate-300 border-slate-800'
                          }`}
                        >
                          {opt.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Lock Toggle */}
                  <div className="p-4 rounded-2xl bg-slate-850 border border-slate-750 space-y-2">
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="userLockCheck"
                        checked={userFormIsLocked}
                        onChange={(e) => setUserFormIsLocked(e.target.checked)}
                        className="w-4 h-4 rounded text-rose-600 bg-slate-900 border-slate-700"
                      />
                      <label htmlFor="userLockCheck" className="text-xs font-bold text-rose-300 cursor-pointer">
                        قفل الحساب وحظر تسجيل الدخول (حساب مقفل 🔒)
                      </label>
                    </div>

                    {userFormIsLocked && (
                      <div className="pt-2">
                        <label className="text-[11px] text-slate-400 block mb-1">سبب القفل:</label>
                        <input
                          type="text"
                          value={userFormLockReason}
                          onChange={(e) => setUserFormLockReason(e.target.value)}
                          placeholder="تجاوز محاولات الدخول الخاطئة أو قفل يدوي"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white"
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: SCREENS PERMISSIONS CUSTOMIZATION */}
              {userActiveTabInModal === 'screens' && (
                <div className="space-y-3 text-xs">
                  <span className="font-bold text-xs text-indigo-300 block">
                    تخصيص الشاشات المصرح بها لهذا المستخدم (مستوردة من الدور الوظيفي):
                  </span>

                  <div className="space-y-2">
                    {APP_SCREENS_CATALOG.map(scr => {
                      const isAllowed = userFormAllowedScreens.includes(scr.id);
                      return (
                        <label
                          key={scr.id}
                          className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition ${
                            isAllowed
                              ? 'bg-slate-850 border-indigo-500/40 text-white'
                              : 'bg-slate-900/60 border-slate-800 text-slate-500'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <input
                              type="checkbox"
                              checked={isAllowed}
                              onChange={() => {
                                if (isAllowed) {
                                  setUserFormAllowedScreens(userFormAllowedScreens.filter(s => s !== scr.id));
                                } else {
                                  setUserFormAllowedScreens([...userFormAllowedScreens, scr.id]);
                                }
                              }}
                              className="w-4 h-4 rounded text-indigo-600 bg-slate-800 border-slate-700"
                            />
                            <div>
                              <span className="font-bold text-xs block">{scr.name}</span>
                              <span className="text-[10px] text-slate-400">{scr.description}</span>
                            </div>
                          </div>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            isAllowed ? 'bg-indigo-500/20 text-indigo-300' : 'bg-slate-800 text-slate-500'
                          }`}>
                            {isAllowed ? 'مصرح' : 'محجوب'}
                          </span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 5: SUB-AREAS SCOPE */}
              {userActiveTabInModal === 'areas' && (
                <div className="space-y-4 text-xs">
                  {/* Top explanation & bulk actions banner */}
                  <div className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-sky-500/30 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-sky-400" />
                        <span className="font-extrabold text-sm text-white">
                          نظام صلاحيات المناطق الفرعية الحالية (الـ 5 مناطق الأساسية المعتمدة)
                        </span>
                      </div>
                      <span className="text-[10px] bg-sky-500/20 text-sky-300 border border-sky-500/30 px-2 py-0.5 rounded-full font-bold">
                        حقل المنطقة الفرعية الحالية
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      يتم تقييد حساب المستخدم بالعمل في <strong>منطقة واحدة</strong>، <strong>عدة مناطق</strong>، أو <strong>كافة المناطق الـ 5</strong>. يطبق هذا القيد بشكل صارم على جميع أجزاء النظام (المشاهدة، الترشيح، الصرف، والتعديل).
                    </p>

                    {/* Quick Presets */}
                    <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-slate-800">
                      <span className="text-[10px] text-slate-400 font-bold">إجراءات سريعة:</span>
                      <button
                        type="button"
                        onClick={() => {
                          setUserFormViewSubAreas(['*']);
                          setUserFormNominationSubAreas(['*']);
                          setUserFormDeliverySubAreas(['*']);
                          setUserFormEditSubAreas(['*']);
                        }}
                        className="px-2.5 py-1 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-[10px] font-bold shadow-sm transition"
                      >
                        ⚡ منح كافة الـ 5 مناطق لجميع العمليات (شامل)
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setUserFormNominationSubAreas([...userFormViewSubAreas]);
                          setUserFormDeliverySubAreas([...userFormViewSubAreas]);
                          setUserFormEditSubAreas([...userFormViewSubAreas]);
                        }}
                        className="px-2.5 py-1 rounded-xl bg-indigo-600/80 hover:bg-indigo-600 text-white text-[10px] font-bold transition"
                      >
                        🔄 تطبيق نطاق المشاهدة على باقي العمليات
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setUserFormViewSubAreas([]);
                          setUserFormNominationSubAreas([]);
                          setUserFormDeliverySubAreas([]);
                          setUserFormEditSubAreas([]);
                        }}
                        className="px-2.5 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-bold transition"
                      >
                        🧹 تفريغ وحجب كافة المناطق
                      </button>
                    </div>
                  </div>

                  {/* 1. المشاهدة والمعاينة (VIEW) */}
                  <div className="p-3.5 rounded-2xl bg-slate-850 border border-slate-750 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Eye className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="font-bold text-xs text-emerald-300">
                          1. صلاحية المشاهدة والمعاينة (VIEW):
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setUserFormViewSubAreas(['*'])}
                          className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold hover:bg-emerald-500/30"
                        >
                          تحديد كافة الـ 5
                        </button>
                        <button
                          type="button"
                          onClick={() => setUserFormViewSubAreas([])}
                          className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] hover:text-white"
                        >
                          تفريغ
                        </button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                      {CURRENT_SUB_AREAS.map(area => {
                        const isSel = userFormViewSubAreas.includes('*') || userFormViewSubAreas.includes(area);
                        return (
                          <button
                            key={area}
                            type="button"
                            onClick={() => {
                              if (userFormViewSubAreas.includes('*')) {
                                setUserFormViewSubAreas(CURRENT_SUB_AREAS.filter(a => a !== area));
                              } else if (userFormViewSubAreas.includes(area)) {
                                setUserFormViewSubAreas(userFormViewSubAreas.filter(a => a !== area));
                              } else {
                                const next = [...userFormViewSubAreas, area];
                                setUserFormViewSubAreas(next.length === CURRENT_SUB_AREAS.length ? ['*'] : next);
                              }
                            }}
                            className={`p-2 rounded-xl text-right font-medium text-[11px] border transition flex items-center justify-between ${
                              isSel ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-200 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'
                            }`}
                          >
                            <span>{area}</span>
                            <span>{isSel ? '✓' : '○'}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 2. الترشيح والمفاضلة (NOMINATE) */}
                  <div className="p-3.5 rounded-2xl bg-slate-850 border border-slate-750 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        <span className="font-bold text-xs text-amber-300">
                          2. صلاحية الترشيح والمفاضلة بمحرك المعايير (NOMINATE):
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setUserFormNominationSubAreas(['*'])}
                          className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold hover:bg-amber-500/30"
                        >
                          تحديد كافة الـ 5
                        </button>
                        <button
                          type="button"
                          onClick={() => setUserFormNominationSubAreas([])}
                          className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] hover:text-white"
                        >
                          تفريغ
                        </button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                      {CURRENT_SUB_AREAS.map(area => {
                        const isSel = userFormNominationSubAreas.includes('*') || userFormNominationSubAreas.includes(area);
                        return (
                          <button
                            key={area}
                            type="button"
                            onClick={() => {
                              if (userFormNominationSubAreas.includes('*')) {
                                setUserFormNominationSubAreas(CURRENT_SUB_AREAS.filter(a => a !== area));
                              } else if (userFormNominationSubAreas.includes(area)) {
                                setUserFormNominationSubAreas(userFormNominationSubAreas.filter(a => a !== area));
                              } else {
                                const next = [...userFormNominationSubAreas, area];
                                setUserFormNominationSubAreas(next.length === CURRENT_SUB_AREAS.length ? ['*'] : next);
                              }
                            }}
                            className={`p-2 rounded-xl text-right font-medium text-[11px] border transition flex items-center justify-between ${
                              isSel ? 'bg-amber-500/20 border-amber-500/40 text-amber-200 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'
                            }`}
                          >
                            <span>{area}</span>
                            <span>{isSel ? '✓' : '○'}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 3. التسليم والصرف الميداني (DELIVER) */}
                  <div className="p-3.5 rounded-2xl bg-slate-850 border border-slate-750 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <PackageCheck className="w-3.5 h-3.5 text-sky-400" />
                        <span className="font-bold text-xs text-sky-300">
                          3. صلاحية التسليم والصرف الميداني بالباركود (DELIVER):
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setUserFormDeliverySubAreas(['*'])}
                          className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 text-[10px] font-bold hover:bg-sky-500/30"
                        >
                          تحديد كافة الـ 5
                        </button>
                        <button
                          type="button"
                          onClick={() => setUserFormDeliverySubAreas([])}
                          className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] hover:text-white"
                        >
                          تفريغ
                        </button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                      {CURRENT_SUB_AREAS.map(area => {
                        const isSel = userFormDeliverySubAreas.includes('*') || userFormDeliverySubAreas.includes(area);
                        return (
                          <button
                            key={area}
                            type="button"
                            onClick={() => {
                              if (userFormDeliverySubAreas.includes('*')) {
                                setUserFormDeliverySubAreas(CURRENT_SUB_AREAS.filter(a => a !== area));
                              } else if (userFormDeliverySubAreas.includes(area)) {
                                setUserFormDeliverySubAreas(userFormDeliverySubAreas.filter(a => a !== area));
                              } else {
                                const next = [...userFormDeliverySubAreas, area];
                                setUserFormDeliverySubAreas(next.length === CURRENT_SUB_AREAS.length ? ['*'] : next);
                              }
                            }}
                            className={`p-2 rounded-xl text-right font-medium text-[11px] border transition flex items-center justify-between ${
                              isSel ? 'bg-sky-500/20 border-sky-500/40 text-sky-200 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'
                            }`}
                          >
                            <span>{area}</span>
                            <span>{isSel ? '✓' : '○'}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* 4. التعديل والإضافة (EDIT) */}
                  <div className="p-3.5 rounded-2xl bg-slate-850 border border-slate-750 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <Edit2 className="w-3.5 h-3.5 text-rose-400" />
                        <span className="font-bold text-xs text-rose-300">
                          4. صلاحية التعديل وتحديث بيانات الأسر (EDIT):
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setUserFormEditSubAreas(['*'])}
                          className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[10px] font-bold hover:bg-rose-500/30"
                        >
                          تحديد كافة الـ 5
                        </button>
                        <button
                          type="button"
                          onClick={() => setUserFormEditSubAreas([])}
                          className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 text-[10px] hover:text-white"
                        >
                          تفريغ
                        </button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                      {CURRENT_SUB_AREAS.map(area => {
                        const isSel = userFormEditSubAreas.includes('*') || userFormEditSubAreas.includes(area);
                        return (
                          <button
                            key={area}
                            type="button"
                            onClick={() => {
                              if (userFormEditSubAreas.includes('*')) {
                                setUserFormEditSubAreas(CURRENT_SUB_AREAS.filter(a => a !== area));
                              } else if (userFormEditSubAreas.includes(area)) {
                                setUserFormEditSubAreas(userFormEditSubAreas.filter(a => a !== area));
                              } else {
                                const next = [...userFormEditSubAreas, area];
                                setUserFormEditSubAreas(next.length === CURRENT_SUB_AREAS.length ? ['*'] : next);
                              }
                            }}
                            className={`p-2 rounded-xl text-right font-medium text-[11px] border transition flex items-center justify-between ${
                              isSel ? 'bg-rose-500/20 border-rose-500/40 text-rose-200 font-bold' : 'bg-slate-900 border-slate-800 text-slate-400'
                            }`}
                          >
                            <span>{area}</span>
                            <span>{isSel ? '✓' : '○'}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-2.5 pt-3 border-t border-slate-800">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 text-white font-bold text-xs sm:text-sm transition shadow-lg shadow-emerald-700/30"
                >
                  {editingUser ? 'حفظ وتحديث بيانات المستخدم' : 'إنشاء وحفظ حساب المستخدم الجديد'}
                </button>
                <button
                  type="button"
                  onClick={() => setUserModalOpen(false)}
                  className="py-2.5 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs sm:text-sm transition"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
