import React, { useState, useMemo } from 'react';
import {
  MapPin,
  Layers,
  Compass,
  Navigation,
  Users,
  PackageCheck,
  Building2,
  Tent,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  Download,
  Printer,
  Sparkles,
  Info,
  Maximize2,
  Eye,
  Filter,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Search,
  Activity,
  HeartHandshake
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { MockFamily, DeliveryRecord, MockChild, MockUser } from './AndroidEmulator';
import { SubAreaItem, INITIAL_SUB_AREAS_DATA } from '../types/subAreaService';

export interface GeographicDistributionMapProps {
  familiesList: MockFamily[];
  deliveryRecords: DeliveryRecord[];
  childrenList?: MockChild[];
  subAreasList?: SubAreaItem[];
  currentUser?: MockUser | null;
  onSelectSubArea?: (subAreaName: string) => void;
  className?: string;
}

// Coordinate and shape definition for the 5 sub-areas in Gaza City & North
interface GeoSectorDef {
  id: number;
  name: string;
  code: string;
  locality: string;
  svgPath: string;
  centerPin: { x: number; y: number };
  warehouseName: string;
  sheltersCount: number;
  description: string;
  colorScheme: {
    base: string;
    hover: string;
    stroke: string;
    badgeBg: string;
    badgeText: string;
  };
}

const GAZA_SUB_AREAS_GEO: GeoSectorDef[] = [
  {
    id: 1,
    name: 'الرمال الشمالي',
    code: 'GZ-RML-N',
    locality: 'مدينة غزة',
    // SVG polygon path in 800x600 viewBox
    svgPath: 'M 280,240 L 410,230 L 440,310 L 310,340 L 260,280 Z',
    centerPin: { x: 345, y: 285 },
    warehouseName: 'مستودع الرمال الإغاثي الرئيسي (محيط مجمع الشفاء)',
    sheltersCount: 14,
    description: 'يضم شارع النصر، محيط مجمع الشفاء الطبي، وحي الميناء والواجهة البحرية',
    colorScheme: {
      base: 'fill-emerald-100 hover:fill-emerald-200',
      hover: 'fill-emerald-300',
      stroke: 'stroke-emerald-600',
      badgeBg: 'bg-emerald-50 text-emerald-800 border-emerald-300',
      badgeText: 'text-emerald-700'
    }
  },
  {
    id: 2,
    name: 'الشيخ رضوان',
    code: 'GZ-SH-RDW',
    locality: 'مدينة غزة',
    svgPath: 'M 410,230 L 580,210 L 610,320 L 440,310 Z',
    centerPin: { x: 505, y: 265 },
    warehouseName: 'مستودع الشيخ رضوان المركزي (قرب بركة رضوان وشارع الجلاء)',
    sheltersCount: 22,
    description: 'مركزية توزيع كبرى تضم أحياء بئر النعجة ومحيط بركة الشيخ رضوان وشارع النفق',
    colorScheme: {
      base: 'fill-sky-100 hover:fill-sky-200',
      hover: 'fill-sky-300',
      stroke: 'stroke-sky-600',
      badgeBg: 'bg-sky-50 text-sky-800 border-sky-300',
      badgeText: 'text-sky-700'
    }
  },
  {
    id: 3,
    name: 'الشاطئ الشمالي والنصر',
    code: 'GZ-SHT-NSR',
    locality: 'مدينة غزة',
    svgPath: 'M 250,140 L 380,130 L 410,230 L 280,240 Z',
    centerPin: { x: 330, y: 185 },
    warehouseName: 'نقطة توزيع مخيم الشاطئ والنصر (مدرسة الوكالة المركزية)',
    sheltersCount: 19,
    description: 'كثافة سكانية ونزوح مرتفع جداً - مخيم الشاطئ للاجئين والمناطق المتاخمة لشارع النصر',
    colorScheme: {
      base: 'fill-indigo-100 hover:fill-indigo-200',
      hover: 'fill-indigo-300',
      stroke: 'stroke-indigo-600',
      badgeBg: 'bg-indigo-50 text-indigo-800 border-indigo-300',
      badgeText: 'text-indigo-700'
    }
  },
  {
    id: 4,
    name: 'الشاطئ الجنوبي',
    code: 'GZ-SHT-SOU',
    locality: 'مدينة غزة',
    svgPath: 'M 220,290 L 310,340 L 280,440 L 190,390 Z',
    centerPin: { x: 250, y: 365 },
    warehouseName: 'نقطة توزيع الساحل الجنوبي (شارع الرشيد وميناء الصيادين)',
    sheltersCount: 11,
    description: 'الخط الساحلي الممتد جنوب ميناء غزة ومحاذاة وادي غزة وحي الشيخ عجلين',
    colorScheme: {
      base: 'fill-teal-100 hover:fill-teal-200',
      hover: 'fill-teal-300',
      stroke: 'stroke-teal-600',
      badgeBg: 'bg-teal-50 text-teal-800 border-teal-300',
      badgeText: 'text-teal-700'
    }
  },
  {
    id: 5,
    name: 'مشروع عامر',
    code: 'GZ-PRJ-AMR',
    locality: 'شمال غزة',
    svgPath: 'M 380,50 L 590,40 L 580,210 L 380,130 Z',
    centerPin: { x: 485, y: 110 },
    warehouseName: 'مستودع شمال غزة الإغاثي الميداني (محاذاة بيت لاهيا والندى)',
    sheltersCount: 16,
    description: 'منطقة حدودية شمالية مستهدفة ببرامج الإغاثة السريعة والطرود الغذائية العاجلة',
    colorScheme: {
      base: 'fill-amber-100 hover:fill-amber-200',
      hover: 'fill-amber-300',
      stroke: 'stroke-amber-600',
      badgeBg: 'bg-amber-50 text-amber-800 border-amber-300',
      badgeText: 'text-amber-700'
    }
  }
];

export function GeographicDistributionMap({
  familiesList,
  deliveryRecords,
  childrenList = [],
  subAreasList = INITIAL_SUB_AREAS_DATA,
  currentUser,
  onSelectSubArea,
  className = ''
}: GeographicDistributionMapProps) {
  // Mode of Visualization
  const [visualMode, setVisualMode] = useState<'density' | 'quota' | 'warehouses' | 'shelters'>('density');

  // Selected Sector
  const [selectedSectorId, setSelectedSectorId] = useState<number>(1);
  const [hoveredSectorId, setHoveredSectorId] = useState<number | null>(null);

  // Filters
  const [aidFilter, setAidFilter] = useState<string>('all');
  const [residentFilter, setResidentFilter] = useState<'all' | 'مقيم' | 'نازح'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Check if current user is restricted to specific sub-areas
  const userAllowedAreas = useMemo(() => {
    if (!currentUser) return ['*'];
    if (currentUser.roleId === 1) return ['*'];
    return currentUser.allowedViewSubAreas || ['*'];
  }, [currentUser]);

  // Dynamic Metrics per Sub-Area
  const enrichedSectors = useMemo(() => {
    return GAZA_SUB_AREAS_GEO.map(geo => {
      const configItem = subAreasList.find(s => s.name === geo.name) || {
        targetFamiliesQuota: 3000,
        registeredFamiliesCount: 2500,
        deliveredCount: 1200,
        nominatedCount: 1600,
        activeSupervisorsCount: 5
      };

      // Filter system families matching this subArea
      const matchingFamilies = familiesList.filter(f => {
        const matchesArea = f.currentSubArea === geo.name || (f.localityName && f.localityName.includes(geo.name));
        const matchesResident = residentFilter === 'all' || f.residentStatus === residentFilter;
        return matchesArea && matchesResident;
      });

      // Filter delivery records matching this subArea
      const matchingDeliveries = deliveryRecords.filter(d => {
        const matchesArea = d.family?.currentSubArea === geo.name || (d.family?.localityName && d.family.localityName.includes(geo.name));
        const matchesAid = aidFilter === 'all' || d.aidTypeName === aidFilter;
        return matchesArea && matchesAid;
      });

      const totalRegistered = matchingFamilies.length > 0 ? matchingFamilies.length : configItem.registeredFamiliesCount;
      const totalDelivered = matchingDeliveries.length > 0 ? matchingDeliveries.length : configItem.deliveredCount;
      const quota = configItem.targetFamiliesQuota;
      const progressPct = quota > 0 ? Math.min(100, Math.round((totalDelivered / quota) * 100)) : 0;

      // Children count
      const areaChildren = childrenList.filter(c => {
        const parentFam = familiesList.find(f => f.nationalID === c.parentNationalID);
        return parentFam && (parentFam.currentSubArea === geo.name || parentFam.localityName?.includes(geo.name));
      });
      const childrenCount = areaChildren.length > 0 ? areaChildren.length : Math.round(totalRegistered * 2.8);

      // Displaced in shelters
      const shelterFamilies = matchingFamilies.filter(f => f.shelterStatus === 'إيواء داخلي' || f.residentStatus === 'نازح');
      const shelterRate = totalRegistered > 0 ? Math.round((shelterFamilies.length / totalRegistered) * 100) : 65;

      // Completely Destroyed Homes
      const destroyedHomes = matchingFamilies.filter(f => f.damageType === 'أضرار كلية');
      const destroyedCount = destroyedHomes.length > 0 ? destroyedHomes.length : Math.round(totalRegistered * 0.42);

      // War Injuries
      const injuryCases = matchingFamilies.filter(f => f.injuryStatus && f.injuryStatus !== 'لا يوجد');
      const injuryCount = injuryCases.length > 0 ? injuryCases.length : Math.round(totalRegistered * 0.28);

      // User permission flag
      const isAllowedForUser = userAllowedAreas.includes('*') || userAllowedAreas.includes(geo.name);

      return {
        ...geo,
        quota,
        registeredCount: totalRegistered,
        deliveredCount: totalDelivered,
        progressPct,
        childrenCount,
        shelterFamiliesCount: shelterFamilies.length > 0 ? shelterFamilies.length : Math.round(totalRegistered * 0.65),
        shelterRate,
        destroyedCount,
        injuryCount,
        activeSupervisors: configItem.activeSupervisorsCount || 5,
        isAllowedForUser
      };
    });
  }, [familiesList, deliveryRecords, childrenList, subAreasList, aidFilter, residentFilter, userAllowedAreas]);

  // Selected Sector Object
  const activeSector = useMemo(() => {
    return enrichedSectors.find(s => s.id === selectedSectorId) || enrichedSectors[0];
  }, [enrichedSectors, selectedSectorId]);

  // Color logic based on visual mode
  const getSectorFillColor = (sector: typeof enrichedSectors[0]) => {
    if (!sector.isAllowedForUser) {
      return '#E2E8F0'; // Locked / Grayed out
    }

    if (visualMode === 'density') {
      // Density based on registeredCount (Darker green = higher density)
      if (sector.registeredCount >= 3500) return '#059669'; // Emerald 600
      if (sector.registeredCount >= 3000) return '#10B981'; // Emerald 500
      if (sector.registeredCount >= 2500) return '#34D399'; // Emerald 400
      return '#6EE7B7'; // Emerald 300
    }

    if (visualMode === 'quota') {
      // Quota completion: Green (high), Amber (mid), Rose (low)
      if (sector.progressPct >= 65) return '#10B981'; // Emerald 500
      if (sector.progressPct >= 45) return '#F59E0B'; // Amber 500
      return '#F43F5E'; // Rose 500
    }

    if (visualMode === 'warehouses') {
      return '#38BDF8'; // Sky blue
    }

    // shelters mode
    if (sector.shelterRate >= 60) return '#EF4444'; // Red high displacement
    return '#F97316'; // Orange
  };

  // Export geographic data to Excel
  const handleExportGeoExcel = () => {
    try {
      const exportRows = enrichedSectors.map((s, idx) => ({
        'م': idx + 1,
        'رمز المنطقة': s.code,
        'اسم المنطقة الفرعية': s.name,
        'المحافظة / المحلية': s.locality,
        'حصة الأسر المستهدفة': s.quota,
        'الأسر المسجلة بالنظام': s.registeredCount,
        'المساعدات المستلمة فعلياً': s.deliveredCount,
        'نسبة إنجاز الحصة': `${s.progressPct}%`,
        'عدد الأطفال والتابعين': s.childrenCount,
        'أسر نازحة في مراكز إيواء': s.shelterFamiliesCount,
        'منازل مهدمة كلياً': s.destroyedCount,
        'حالات إصابات حرب': s.injuryCount,
        'المستودع الرئيسي': s.warehouseName,
        'المشرفون الميدانيون': s.activeSupervisors,
        'حالة تصريح المستخدم': s.isAllowedForUser ? 'مصرح' : 'مقيد'
      }));

      const wb = XLSX.utils.book_new();
      const ws = XLSX.utils.json_to_sheet(exportRows);
      XLSX.utils.book_append_sheet(wb, ws, 'التوزيع الجغرافي للمناطق الفرعية');
      XLSX.writeFile(wb, `Geographic_Distribution_Report_${new Date().toISOString().slice(0, 10)}.xlsx`);
    } catch (err) {
      console.error('Error exporting geo excel:', err);
    }
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* ==================== رأس بطاقة الخريطة والهوية الوطنية ==================== */}
      <div className="bg-white rounded-3xl border border-slate-200 p-4 sm:p-5 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white flex items-center justify-center shadow-md shadow-emerald-700/20">
              <Compass className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-lg sm:text-xl text-slate-800">
                  العرض المرئي للتوزيع الجغرافي للمستفيدين 🇵🇸
                </h3>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[11px] font-bold border border-emerald-200">
                  المناطق الفرعية الـ 5 المعتمدة
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                تمثيل كارتوغرافي متفاعل يربط الأسر والمساعدات وحالات الإيواء بالنطاقات الميدانية المعتمدة في النظام
              </p>
            </div>
          </div>

          {/* أزرار التبديل وأدوات التصدير */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleExportGeoExcel}
              className="px-3.5 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 text-xs font-bold flex items-center gap-1.5 transition active:scale-95"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تصدير تقرير المناطق (Excel)</span>
            </button>

            <button
              onClick={() => window.print()}
              className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 text-xs font-bold flex items-center gap-1.5 transition"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة</span>
            </button>
          </div>
        </div>

        {/* أشرطة التحكم وأنماط العرض */}
        <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
          {/* محدد نمط الخريطة البصري */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-2xl">
            <button
              onClick={() => setVisualMode('density')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                visualMode === 'density'
                  ? 'bg-white text-emerald-800 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5 text-emerald-600" />
              <span>1. كثافة أعداد الأسر</span>
            </button>

            <button
              onClick={() => setVisualMode('quota')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                visualMode === 'quota'
                  ? 'bg-white text-emerald-800 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
              <span>2. نسبة تغطية الحصص (%)</span>
            </button>

            <button
              onClick={() => setVisualMode('warehouses')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                visualMode === 'warehouses'
                  ? 'bg-white text-emerald-800 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Building2 className="w-3.5 h-3.5 text-sky-600" />
              <span>3. المستودعات ونقاط الصرف</span>
            </button>

            <button
              onClick={() => setVisualMode('shelters')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                visualMode === 'shelters'
                  ? 'bg-white text-emerald-800 shadow-sm border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Tent className="w-3.5 h-3.5 text-rose-600" />
              <span>4. مراكز الإيواء والنزوح</span>
            </button>
          </div>

          {/* فلاتر سريعة */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-slate-500 font-bold">تصفية بنوع الإقامة:</span>
            <select
              value={residentFilter}
              onChange={(e) => setResidentFilter(e.target.value as any)}
              className="px-2.5 py-1.5 rounded-xl border border-slate-200 bg-white text-slate-700 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-emerald-500"
            >
              <option value="all">كافة الأسر (مقيم ونازح)</option>
              <option value="نازح">النازحون فقط</option>
              <option value="مقيم">المقيمون في منازلهم</option>
            </select>
          </div>
        </div>
      </div>

      {/* ==================== الحاوية المركزية: الخريطة التفاعلية + بطاقة التحليل الجانبية ==================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* عمود الخريطة الكارتوغرافية التفاعلية (7 أعمدة في الشاشات الكبيرة) */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-4 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-600" />
              <h4 className="text-sm font-black text-slate-800">
                مخطط قطاع غزة والمناطق الفرعية الحالية
              </h4>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono">
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
              <span>تحديث حي للمؤشرات الميدانية</span>
            </div>
          </div>

          {/* قماش الخريطة التفاعلي (Interactive SVG Map Canvas) */}
          <div className="relative w-full h-[430px] my-2 bg-gradient-to-b from-sky-50/50 via-slate-50 to-emerald-50/30 rounded-2xl border border-slate-200/80 overflow-hidden flex items-center justify-center">
            {/* مؤشر البحر الأبيض المتوسط على الجانب الساحلي */}
            <div className="absolute top-4 left-4 z-10 px-2.5 py-1 rounded-xl bg-sky-100/80 border border-sky-300 text-sky-800 text-[10px] font-bold flex items-center gap-1 shadow-sm backdrop-blur-xs">
              <Compass className="w-3 h-3 text-sky-600" />
              <span>البحر الأبيض المتوسط (الساحل الغربي)</span>
            </div>

            {/* سهم اتجاه الشمال */}
            <div className="absolute top-4 right-4 z-10 flex flex-col items-center bg-white/90 border border-slate-200 px-2 py-1.5 rounded-xl shadow-xs">
              <Navigation className="w-4 h-4 text-emerald-700" />
              <span className="text-[9px] font-bold text-slate-600 mt-0.5">الشمال</span>
            </div>

            {/* SVG الخريطة التفصيلية */}
            <svg
              viewBox="100 20 600 480"
              className="w-full h-full max-h-[420px] select-none transition-all duration-300"
            >
              {/* شريط الساحل والحدود الخارجية */}
              <defs>
                <filter id="sectorShadow" x="-10%" y="-10%" width="130%" height="130%">
                  <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.15" />
                </filter>
                <linearGradient id="seaGrad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#0284c7" stopOpacity="0.05" />
                </linearGradient>
              </defs>

              {/* تمثيل البحر الساحلي */}
              <rect x="100" y="20" width="120" height="480" fill="url(#seaGrad)" rx="8" />

              {/* مناطق قطاع غزة المعتمدة (الـ 5 مناطق الفرعية) */}
              {enrichedSectors.map((sector) => {
                const isSelected = activeSector.id === sector.id;
                const isHovered = hoveredSectorId === sector.id;
                const fillColor = getSectorFillColor(sector);

                return (
                  <g
                    key={sector.id}
                    className="cursor-pointer transition-transform duration-200"
                    onClick={() => {
                      setSelectedSectorId(sector.id);
                      if (onSelectSubArea) onSelectSubArea(sector.name);
                    }}
                    onMouseEnter={() => setHoveredSectorId(sector.id)}
                    onMouseLeave={() => setHoveredSectorId(null)}
                  >
                    {/* مضلع المنطقة */}
                    <path
                      d={sector.svgPath}
                      fill={fillColor}
                      stroke={isSelected ? '#047857' : isHovered ? '#1E293B' : '#64748B'}
                      strokeWidth={isSelected ? '3.5' : isHovered ? '2.5' : '1.5'}
                      strokeLinejoin="round"
                      filter={isSelected ? 'url(#sectorShadow)' : undefined}
                      className="transition-all duration-200"
                      opacity={sector.isAllowedForUser ? (isSelected ? 0.95 : 0.85) : 0.4}
                    />

                    {/* نقطة المركز ودبوس المنطقة */}
                    <circle
                      cx={sector.centerPin.x}
                      cy={sector.centerPin.y}
                      r={isSelected ? '14' : '10'}
                      fill={isSelected ? '#047857' : '#0F172A'}
                      stroke="#FFFFFF"
                      strokeWidth="2.5"
                      className="transition-all"
                    />

                    {/* نص رقم المنطقة داخل الدبوس */}
                    <text
                      x={sector.centerPin.x}
                      y={sector.centerPin.y + 4}
                      textAnchor="middle"
                      fill="#FFFFFF"
                      fontSize={isSelected ? '11' : '9'}
                      fontWeight="bold"
                      fontFamily="system-ui"
                    >
                      {sector.id}
                    </text>

                    {/* اسم المنطقة الفرعية على الخريطة */}
                    <text
                      x={sector.centerPin.x}
                      y={sector.centerPin.y + 24}
                      textAnchor="middle"
                      fill={isSelected ? '#065F46' : '#1E293B'}
                      fontSize={isSelected ? '12' : '10'}
                      fontWeight="bold"
                      fontFamily="system-ui"
                      className="pointer-events-none drop-shadow-xs"
                    >
                      {sector.name}
                    </text>

                    {/* مؤشر رقمي سريع */}
                    <text
                      x={sector.centerPin.x}
                      y={sector.centerPin.y + 36}
                      textAnchor="middle"
                      fill="#475569"
                      fontSize="9"
                      fontWeight="bold"
                      fontFamily="monospace"
                      className="pointer-events-none"
                    >
                      {visualMode === 'quota'
                        ? `${sector.progressPct}%`
                        : `${sector.registeredCount} أسرة`}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* دليل ألوان الخريطة (Legend) في أسفل يسار الخريطة */}
            <div className="absolute bottom-3 left-3 z-10 bg-white/95 border border-slate-200 px-3 py-2 rounded-xl shadow-xs text-[10px] space-y-1 backdrop-blur-xs">
              <span className="font-bold text-slate-700 block">دليل الألوان:</span>
              {visualMode === 'density' && (
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-600" />
                  <span className="text-slate-600">كثافة عالية (+3,500)</span>
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-400 mr-2" />
                  <span className="text-slate-600">متوسطة (-3,000)</span>
                </div>
              )}
              {visualMode === 'quota' && (
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" />
                  <span className="text-slate-600">≥ 65%</span>
                  <span className="w-2.5 h-2.5 rounded-sm bg-amber-500 mr-1.5" />
                  <span className="text-slate-600">45-64%</span>
                  <span className="w-2.5 h-2.5 rounded-sm bg-rose-500 mr-1.5" />
                  <span className="text-slate-600">&lt; 45%</span>
                </div>
              )}
              {visualMode === 'warehouses' && (
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-sky-500" />
                  <span className="text-slate-600">مستودعات ونقاط صرف نشطة</span>
                </div>
              )}
              {visualMode === 'shelters' && (
                <div className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-sm bg-rose-500" />
                  <span className="text-slate-600">نزوح مكثف (+60%)</span>
                </div>
              )}
            </div>
          </div>

          {/* شريط اختيار المناطق السريع أسفل الخريطة */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-2 border-t border-slate-100">
            {enrichedSectors.map((sector) => {
              const isSelected = activeSector.id === sector.id;
              return (
                <button
                  key={sector.id}
                  onClick={() => {
                    setSelectedSectorId(sector.id);
                    if (onSelectSubArea) onSelectSubArea(sector.name);
                  }}
                  className={`p-2 rounded-xl text-right transition border flex flex-col justify-between ${
                    isSelected
                      ? 'bg-emerald-50 border-emerald-400 shadow-xs'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[11px] text-slate-800 line-clamp-1">{sector.name}</span>
                    <span className="text-[10px] font-mono text-emerald-700 font-bold">{sector.id}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono mt-1">
                    {sector.registeredCount} أسرة • {sector.progressPct}%
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* عمود بطاقة الفحص والتحليل التفصيلي للمنطقة المحددة (5 أعمدة) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4">
            {/* ترويسة بطاقة المنطقة */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-lg bg-emerald-600 text-white font-mono text-xs font-bold">
                    #{activeSector.id}
                  </span>
                  <h4 className="font-black text-lg text-slate-800">{activeSector.name}</h4>
                </div>
                <span className="text-xs text-slate-500 mt-0.5 block">
                  {activeSector.locality} • رمز: <code className="text-emerald-700 font-mono font-bold">{activeSector.code}</code>
                </span>
              </div>

              <div className="text-left">
                <span className="text-[10px] text-slate-400 block">نسبة الإنجاز</span>
                <span className="text-lg font-black font-mono text-emerald-600">
                  {activeSector.progressPct}%
                </span>
              </div>
            </div>

            {/* شريط التقدم بين الحصة والمستلم والمسجل */}
            <div className="space-y-1.5 bg-slate-50 p-3 rounded-2xl border border-slate-100">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-700">تغطية الحصة الإغاثية:</span>
                <span className="font-mono text-slate-600">
                  <strong className="text-emerald-700">{activeSector.deliveredCount}</strong> مستلم من{' '}
                  <strong className="text-slate-800">{activeSector.quota}</strong> حصة
                </span>
              </div>
              <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden flex">
                <div
                  className="bg-gradient-to-r from-emerald-600 to-teal-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${activeSector.progressPct}%` }}
                />
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                <span>إجمالي المسجلين بالنظام: {activeSector.registeredCount} أسرة</span>
                <span>المتبقي للحصة: {Math.max(0, activeSector.quota - activeSector.deliveredCount)}</span>
              </div>
            </div>

            {/* مصفوفة العدادات الحية للمنطقة */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-100">
                <div className="flex items-center gap-1.5 text-xs text-emerald-800 font-bold mb-1">
                  <Users className="w-3.5 h-3.5 text-emerald-600" />
                  <span>الأفراد والأطفال المستفيدون</span>
                </div>
                <div className="text-lg font-black text-emerald-950 font-mono">
                  {activeSector.childrenCount} فرد
                </div>
                <span className="text-[10px] text-emerald-700">شاملاً التابعين دون 18 عاماً</span>
              </div>

              <div className="p-3 rounded-2xl bg-rose-50/60 border border-rose-100">
                <div className="flex items-center gap-1.5 text-xs text-rose-800 font-bold mb-1">
                  <Tent className="w-3.5 h-3.5 text-rose-600" />
                  <span>النزوح ومراكز الإيواء</span>
                </div>
                <div className="text-lg font-black text-rose-950 font-mono">
                  {activeSector.shelterFamiliesCount} أسرة ({activeSector.shelterRate}%)
                </div>
                <span className="text-[10px] text-rose-700">{activeSector.sheltersCount} مركز ومدرسة إيواء</span>
              </div>

              <div className="p-3 rounded-2xl bg-amber-50/60 border border-amber-100">
                <div className="flex items-center gap-1.5 text-xs text-amber-800 font-bold mb-1">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                  <span>أضرار كلية بالمساكن</span>
                </div>
                <div className="text-lg font-black text-amber-950 font-mono">
                  {activeSector.destroyedCount} منزل
                </div>
                <span className="text-[10px] text-amber-700">أولوية أولى في التوزيع</span>
              </div>

              <div className="p-3 rounded-2xl bg-purple-50/60 border border-purple-100">
                <div className="flex items-center gap-1.5 text-xs text-purple-800 font-bold mb-1">
                  <HeartHandshake className="w-3.5 h-3.5 text-purple-600" />
                  <span>مصابو الحرب وذوو الإعاقة</span>
                </div>
                <div className="text-lg font-black text-purple-950 font-mono">
                  {activeSector.injuryCount} حالة
                </div>
                <span className="text-[10px] text-purple-700">مشمولة بمعايير المفاضلة</span>
              </div>
            </div>

            {/* تفاصيل المركز والمستودع الميداني للمنطقة */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-sky-600" />
                <h5 className="font-bold text-xs text-slate-800">نقطة الصرف والمستودع المسؤول:</h5>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed font-medium">
                {activeSector.warehouseName}
              </p>
              <div className="flex items-center justify-between pt-2 border-t border-slate-200/80 text-[11px] text-slate-500">
                <span>المشرفون الميدانيون النشطون: <strong className="text-slate-800 font-mono">{activeSector.activeSupervisors}</strong></span>
                <span className="text-emerald-700 font-bold">جاهز للصرف الميداني ✅</span>
              </div>
            </div>

            {/* نبذة عن النطاق الجغرافي */}
            <div className="text-xs text-slate-500 leading-relaxed bg-slate-50/70 p-3 rounded-xl border border-dashed border-slate-200">
              <strong className="text-slate-700 block mb-0.5">معالم ونطاق المنطقة:</strong>
              {activeSector.description}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
