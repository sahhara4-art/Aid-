import React, { useState, useMemo } from 'react';
import {
  FileSpreadsheet,
  Upload,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Download,
  Search,
  RotateCcw,
  Sparkles,
  Info,
  ShieldCheck,
  UserCheck,
  UserX,
  Database,
  X,
  FileCheck2,
  Phone,
  Layers,
  ShieldAlert,
  MapPin,
  Lock,
  Eye,
  Filter
} from 'lucide-react';
import {
  exportNationalIdVerificationToExcel,
  extractNationalIdsFromExcelBuffer,
  NationalIdVerificationResult,
  NationalIdVerificationRowApproved,
  NationalIdVerificationRowRejected,
  NationalIdVerificationRowUnregistered
} from '../utils/excelGenerator';
import { MockFamily, DeliveryRecord, AID_CATEGORIES, MockUser } from './AndroidEmulator';

interface ExcelIdAuditModalProps {
  isOpen: boolean;
  onClose: () => void;
  familiesList?: MockFamily[];
  systemFamilies?: MockFamily[];
  familyBenefitStore?: Record<number, Record<number, { date: string; detail: string }>>;
  deliveryRecords?: DeliveryRecord[];
  systemDeliveries?: DeliveryRecord[];
  systemChildren?: any[];
  currentUser?: MockUser | null;
  usersList?: MockUser[];
  onSelectUser?: (user: MockUser) => void;
  onAddAuditLog?: (action: string, status: 'ناجح' | 'مرفوض' | 'تحذير أمني', details: string) => void;
}

export function ExcelIdAuditModal({
  isOpen,
  onClose,
  familiesList: propFamiliesList,
  systemFamilies,
  familyBenefitStore = {},
  deliveryRecords: propDeliveryRecords,
  systemDeliveries,
  systemChildren,
  currentUser,
  usersList,
  onSelectUser,
  onAddAuditLog
}: ExcelIdAuditModalProps) {
  const familiesList = propFamiliesList || systemFamilies || [];
  const deliveryRecords = propDeliveryRecords || systemDeliveries || [];
  // Active User State (can be dynamically switched to inspect area permissions effect)
  const [effectiveUser, setEffectiveUser] = useState<MockUser | null>(currentUser || null);

  // Sync with currentUser prop whenever it changes
  React.useEffect(() => {
    if (currentUser) {
      setEffectiveUser(currentUser);
    }
  }, [currentUser]);

  // Input State
  const [uploadedFileName, setUploadedFileName] = useState<string>('');
  const [manualIdsInput, setManualIdsInput] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'sheet1' | 'sheet2' | 'sheet3'>('sheet1');
  const [searchFilter, setSearchFilter] = useState<string>('');
  const [onlyMyAreasFilter, setOnlyMyAreasFilter] = useState<boolean>(false);
  const [selectedSubAreaAuditFilter, setSelectedSubAreaAuditFilter] = useState<string>('all');
  const [lastRawAudit, setLastRawAudit] = useState<{ rawIds: string[]; sourceName: string } | null>(null);

  // Results State
  const [verificationResult, setVerificationResult] = useState<NationalIdVerificationResult | null>(null);

  // Helper to cross-reference an array of National IDs against the system database
  const executeVerification = (rawIds: string[], sourceName: string, overrideUser?: MockUser | null) => {
    setIsProcessing(true);
    setLastRawAudit({ rawIds, sourceName });
    const userToUse = overrideUser !== undefined ? overrideUser : (effectiveUser || currentUser);

    setTimeout(() => {
      // 1. تنظيف وتصفية أرقام الهويات الفريدة
      const uniqueIds = Array.from(
        new Set(
          rawIds
            .map(id => id.replace(/\D/g, '').trim())
            .filter(id => id.length >= 8 && id.length <= 10)
        )
      );

      const approvedList: NationalIdVerificationRowApproved[] = [];
      const rejectedList: NationalIdVerificationRowRejected[] = [];
      const unregisteredList: NationalIdVerificationRowUnregistered[] = [];

      const todayStr = new Date().toISOString().split('T')[0];

      uniqueIds.forEach(id => {
        // البحث عن الأسرة بالهوية الرئيسية لرب الأسرة أو الزوجة
        const fam = familiesList.find(f => f.nationalID === id || f.wifeNationalID === id);

        if (!fam) {
          // الشيت 3: غير مسجل في النظام
          unregisteredList.push({
            nationalID: id,
            status: 'غير مسجل في النظام',
            actionRequired: 'توجيه المواطن للتسجيل وتحديث البيانات لدى لجان البحث الميداني',
            checkedDate: todayStr
          });
          return;
        }

        // حساب عدد المساعدات المستلمة
        const deliveredCount = deliveryRecords.filter(d => d.familyId === fam.familyID && d.status === 'تم التسليم').length;
        const benefitsCount = Object.keys(familyBenefitStore[fam.familyID] || {}).length;
        const totalAidsCount = Math.max(deliveredCount, benefitsCount, fam.lastAidDate ? 1 : 0);

        // تحديد آخر مساعدة وتاريخها وتصنيفها
        let lastDate = fam.lastAidDate || '';
        let lastType = fam.lastAidType || '';
        let lastCat = fam.lastAidType || 'مساعدات إغاثية';

        // فحص سجل المنافع لتحديد الأحدث
        const famBenefits = familyBenefitStore[fam.familyID] || {};
        Object.entries(famBenefits).forEach(([catIdStr, rec]) => {
          if (rec?.date) {
            if (!lastDate || new Date(rec.date).getTime() > new Date(lastDate).getTime()) {
              lastDate = rec.date;
              const catId = Number(catIdStr);
              const foundCat = AID_CATEGORIES.find(c => c.id === catId);
              lastCat = foundCat ? foundCat.name : 'مساعدات إنسانية';
              lastType = rec.detail || lastCat;
            }
          }
        });

        // فحص الصلاحية الجغرافية لمنطقة الأسرة بحسب صلاحيات المستخدم
        const isAreaPermitted = !userToUse ||
          userToUse.allowedViewSubAreas?.includes('*') ||
          userToUse.allowedViewSubAreas?.includes(fam.currentSubArea);

        const geoStatus = isAreaPermitted
          ? `مصرح بالمعاينة (${fam.currentSubArea})`
          : `خارج النطاق الجغرافي المصرح (${fam.currentSubArea})`;

        // الشروط المعتمدة المطلوبة:
        // 1. اعتماد التنمية = "معتمد"
        // 2. مقيم/نازح = "مقيم"
        const isDevApproved = fam.developmentApproval === 'معتمد';
        const isResident = fam.residentStatus === 'مقيم';

        if (isDevApproved && isResident) {
          // الشيت 1: تنطبق عليه شروط الاعتماد والإقامة
          approvedList.push({
            nationalID: fam.nationalID,
            name: fam.name,
            primaryPhone: fam.primaryPhone,
            currentMainArea: fam.currentMainArea || 'غزة',
            currentSubArea: fam.currentSubArea,
            currentMosque: fam.currentMosque,
            developmentApproval: fam.developmentApproval,
            residentStatus: fam.residentStatus,
            membersCount: fam.membersCount,
            totalAidsCount,
            lastAidType: lastType || 'طرد غذائي أساسي',
            lastAidDate: lastDate || '2024-11-10',
            lastAidCategory: lastCat,
            statusNotes: 'مستوفٍ لكافة الشروط المحددة',
            isAreaPermitted,
            geographicPermissionStatus: geoStatus
          });
        } else {
          // الشيت 2: لم تنطبق عليه الشروط مع سبب الرفض الدقيق كما حدده المستخدم
          let reason = '';
          if (!isDevApproved && !isResident) {
            reason = `غير معتمد تنمية (${fam.developmentApproval}) + صفة الإقامة نازح (مهوب مقيم)`;
          } else if (!isDevApproved) {
            reason = `غير معتمد في التنمية الاجتماعية (حالة الاعتماد: ${fam.developmentApproval})`;
          } else {
            reason = `صفة الإقامة: مهوب مقيم بل نازح (حالة الإقامة: ${fam.residentStatus})`;
          }

          rejectedList.push({
            nationalID: fam.nationalID,
            name: fam.name,
            primaryPhone: fam.primaryPhone,
            currentSubArea: fam.currentSubArea,
            developmentApproval: fam.developmentApproval,
            residentStatus: fam.residentStatus,
            rejectionReason: reason,
            membersCount: fam.membersCount,
            totalAidsCount,
            lastAidType: lastType || 'مساعدة سابقة',
            lastAidDate: lastDate || 'غير متوفر',
            isAreaPermitted,
            geographicPermissionStatus: geoStatus
          });
        }
      });

      const permittedAreaCount = [...approvedList, ...rejectedList].filter(r => r.isAreaPermitted).length;
      const restrictedAreaCount = [...approvedList, ...rejectedList].filter(r => !r.isAreaPermitted).length;
      const jurisdictionLabel = !userToUse || userToUse.allowedViewSubAreas?.includes('*')
        ? 'كافة المناطق (*)'
        : (userToUse.allowedViewSubAreas?.join('، ') || 'غير محدد');

      const result: NationalIdVerificationResult = {
        sourceFileName: sourceName,
        totalChecked: uniqueIds.length,
        approvedCount: approvedList.length,
        rejectedCount: rejectedList.length,
        unregisteredCount: unregisteredList.length,
        permittedAreaCount,
        restrictedAreaCount,
        userJurisdictionLabel: jurisdictionLabel,
        approvedList,
        rejectedList,
        unregisteredList
      };

      setVerificationResult(result);
      setIsProcessing(false);

      if (onAddAuditLog) {
        onAddAuditLog(
          'فحص ومطابقة ملف إكسل الهويات مع قاعدة النظام وفق الصلاحيات الجغرافية',
          'ناجح',
          `تم فحص (${uniqueIds.length}) هوية من ملف (${sourceName}): ${approvedList.length} معتمد ومقيم (${permittedAreaCount} ضمن نطاق الصلاحيات الجغرافية، ${restrictedAreaCount} خارج النطاق)، ${rejectedList.length} مستبعد، ${unregisteredList.length} غير مسجل.`
        );
      }
    }, 400);
  };

  // معالجة رفع ملف الإكسل من الجوال
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadedFileName(file.name);
    const reader = new FileReader();

    reader.onload = (evt) => {
      const buffer = evt.target?.result as ArrayBuffer;
      if (buffer) {
        const extractedIds = extractNationalIdsFromExcelBuffer(buffer);
        if (extractedIds.length === 0) {
          alert('لم يتم العثور على أرقام هويات صالحة (9 أرقام) في الملف المرفوع. يرجى التأكد من احتواء الملف على عمود رقم الهوية.');
          return;
        }
        executeVerification(extractedIds, file.name);
      }
    };

    reader.readAsArrayBuffer(file);
  };

  // تجربة ملف نموذجي محاكي بنقرة واحدة (أسر معتمدة ومقيمة، أسر مستبعدة، وهويات غير مسجلة)
  const handleLoadSampleDataset = () => {
    const sampleIds = [
      // معتمد ومقيم (ستظهر بالشيت 1)
      '901234561', // أحمد الأسطل
      '902345672', // محمد النجار
      '904567894', // ياسر فياض
      '907890127', // عصام حبيب
      '908901238', // سامي قديح
      // مستبعد لعدم توفر الشروط (نازح أو حجب اعتماد - ستظهر بالشيت 2)
      '903456783', // خالد بربخ (نازح)
      '905678905', // عبد الكريم عابد (حجب اعتماد)
      '906789016', // ماجد العطار (نازح)
      '910123450', // خلود صقر (مجمد)
      // غير مسجل في النظام بتاتاً (ستظهر بالشيت 3)
      '922334455', // غير مسجل 1
      '933445566', // غير مسجل 2
      '944556677'  // غير مسجل 3
    ];

    setUploadedFileName('كشف_هويات_المواطنين_عينة_ميدانية.xlsx');
    executeVerification(sampleIds, 'كشف_هويات_المواطنين_عينة_ميدانية.xlsx');
  };

  // معالجة فحص النص المكتوب يدوياً
  const handleProcessManualText = () => {
    if (!manualIdsInput.trim()) {
      alert('يرجى لصق أو كتابة أرقام الهويات أولاً');
      return;
    }
    const lines = manualIdsInput.split(/[\n,;\s]+/);
    const cleaned = lines.map(l => l.trim()).filter(l => l.length >= 8);
    if (cleaned.length === 0) {
      alert('لم يتم التعرف على أرقام هويات صالحة');
      return;
    }
    executeVerification(cleaned, 'إدخال_هويات_يدوي.xlsx');
  };

  // تنزيل ملف الإكسل ثلاثي الشيتات (شامل أو مقيّد بنطاق الصلاحيات الجغرافية فقط)
  const handleDownloadMultiSheetExcel = (onlyPermitted: boolean = false) => {
    if (!verificationResult) return;
    try {
      const generatedName = exportNationalIdVerificationToExcel(verificationResult, onlyPermitted);
      if (onlyPermitted) {
        alert(`✅ تم توليد وتنزيل ملف الإكسل المقيد بالصلاحيات الجغرافية بنجاح:\n"${generatedName}"\n\nيحتوي الملف على 3 أوراق عمل مستقلة تضم حصراً الأسر التابعة للمناطق المصرح بها لحسابك (${effectiveUser?.fullName || 'المستخدم'}).`);
      } else {
        alert(`✅ تم توليد وتنزيل ملف الإكسل متعدد الشيتات بنجاح:\n"${generatedName}"\n\nيحتوي الملف على 3 أوراق عمل مستقلة مع أعمدة الصلاحيات الجغرافية:\n1. المعتمدين والمقيمين (${verificationResult.approvedCount})\n2. غير المطابقين للشروط مع أسباب الرفض (${verificationResult.rejectedCount})\n3. غير المسجلين في النظام (${verificationResult.unregisteredCount})`);
      }
    } catch (err: any) {
      alert(`حدث خطأ أثناء تنزيل الملف: ${err.message}`);
    }
  };

  // قائمة المناطق الفرعية الظاهرة في نتائج الفحص
  const availableSubAreasInResult = useMemo(() => {
    if (!verificationResult) return [];
    const set = new Set<string>();
    verificationResult.approvedList.forEach(r => set.add(r.currentSubArea));
    verificationResult.rejectedList.forEach(r => set.add(r.currentSubArea));
    return Array.from(set);
  }, [verificationResult]);

  // التصفية والبحث في القوائم المعروضة مع مراعاة الصلاحيات الجغرافية والمنطقة المحددة
  const filteredApproved = useMemo(() => {
    if (!verificationResult) return [];
    let list = verificationResult.approvedList;
    if (onlyMyAreasFilter) {
      list = list.filter(r => r.isAreaPermitted);
    }
    if (selectedSubAreaAuditFilter !== 'all') {
      list = list.filter(r => r.currentSubArea === selectedSubAreaAuditFilter);
    }
    if (!searchFilter.trim()) return list;
    const q = searchFilter.trim();
    return list.filter(
      r => r.nationalID.includes(q) || r.name.includes(q) || r.currentSubArea.includes(q)
    );
  }, [verificationResult, searchFilter, onlyMyAreasFilter, selectedSubAreaAuditFilter]);

  const filteredRejected = useMemo(() => {
    if (!verificationResult) return [];
    let list = verificationResult.rejectedList;
    if (onlyMyAreasFilter) {
      list = list.filter(r => r.isAreaPermitted);
    }
    if (selectedSubAreaAuditFilter !== 'all') {
      list = list.filter(r => r.currentSubArea === selectedSubAreaAuditFilter);
    }
    if (!searchFilter.trim()) return list;
    const q = searchFilter.trim();
    return list.filter(
      r => r.nationalID.includes(q) || r.name.includes(q) || r.rejectionReason.includes(q) || r.currentSubArea.includes(q)
    );
  }, [verificationResult, searchFilter, onlyMyAreasFilter, selectedSubAreaAuditFilter]);

  const filteredUnregistered = useMemo(() => {
    if (!verificationResult) return [];
    if (!searchFilter.trim()) return verificationResult.unregisteredList;
    const q = searchFilter.trim();
    return verificationResult.unregisteredList.filter(r => r.nationalID.includes(q));
  }, [verificationResult, searchFilter]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4">
      <div className="bg-slate-900 border-2 border-emerald-500/60 rounded-3xl p-4 sm:p-5 max-w-4xl w-full space-y-4 shadow-2xl text-right max-h-[94vh] flex flex-col ring-2 ring-emerald-500/20">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold shrink-0">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-sm sm:text-base text-white">
                  فحص ومطابقة ملف إكسل الهويات مع قاعدة النظام (3 شيتات)
                </h3>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold border border-emerald-500/30">
                  Excel Multi-Sheet Engine
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                ارفع ملف إكسل يحتوي أرقام الهويات ليتم ربطه فورياً بالقاعدة وتصنيف المستفيدين لـ 3 أوراق عمل مستقلة مع التغذية الراجعة
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* شريط نطاق الصلاحيات الجغرافية للمستخدم الحالي وتبديل الحسابات */}
        <div className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2 text-xs shrink-0">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold shrink-0 border border-indigo-500/30">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-slate-400 text-[11px]">نطاق الصلاحيات الجغرافية لحسابك:</span>
                  <span className="font-bold text-emerald-400 text-xs font-mono">
                    {!effectiveUser || effectiveUser.allowedViewSubAreas?.includes('*')
                      ? 'كافة المناطق والمحليات الـ 5 (شامل *)'
                      : effectiveUser.allowedViewSubAreas?.join('، ')}
                  </span>
                  <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full font-bold border border-indigo-500/30">
                    {effectiveUser?.roleName || 'المستخدم'}
                  </span>
                </div>
                <p className="text-[10.5px] text-slate-400 mt-0.5">
                  تُفحص الهويات وتُصنف طبقاً لصلاحيات المناطق المعتمدة لحسابك، مع إبراز تنبيهات الحظر الجغرافي.
                </p>
              </div>
            </div>

            {verificationResult && (
              <button
                type="button"
                onClick={() => setOnlyMyAreasFilter(!onlyMyAreasFilter)}
                className={`py-1.5 px-3 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 shrink-0 ${
                  onlyMyAreasFilter
                    ? 'bg-emerald-600 text-white border-emerald-400 shadow-md'
                    : 'bg-slate-900 text-slate-300 border-slate-700 hover:border-slate-600'
                }`}
              >
                <Filter className="w-3.5 h-3.5 text-emerald-300" />
                <span>{onlyMyAreasFilter ? 'عرض نطاق صلاحياتي فقط (مفعل)' : 'تصفية حسب نطاق صلاحياتي الجغرافية'}</span>
              </button>
            )}
          </div>

          {/* شريط تبديل الحساب لمعاينة الصلاحيات فورياً */}
          {usersList && usersList.length > 0 && (
            <div className="pt-2 border-t border-slate-900 flex items-center gap-2 flex-wrap text-[11px]">
              <span className="text-slate-400 shrink-0">تبديل الحساب لفحص الصلاحيات:</span>
              <div className="flex gap-1 overflow-x-auto">
                {usersList.slice(0, 5).map(u => {
                  const isSelected = effectiveUser?.id === u.id;
                  return (
                    <button
                      key={u.id}
                      type="button"
                      onClick={() => {
                        setEffectiveUser(u);
                        if (onSelectUser) onSelectUser(u);
                        if (lastRawAudit) {
                          executeVerification(lastRawAudit.rawIds, lastRawAudit.sourceName, u);
                        }
                      }}
                      className={`py-1 px-2.5 rounded-xl text-[10.5px] font-bold border transition shrink-0 ${
                        isSelected
                          ? 'bg-indigo-600 text-white border-indigo-400 shadow'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      <span>{u.username === 'admin' ? '👑 المدير العام' : u.fullName.split(' ')[1] || u.fullName.split(' ')[0]}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Upload & Input Section (إذا لم يتم الفحص بعد أو لتغيير الملف) */}
        {!verificationResult ? (
          <div className="space-y-4 overflow-y-auto pr-0.5">
            {/* بطاقة الشرح والتوجيه */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950/40 border border-slate-800 text-xs text-slate-300 space-y-1.5 leading-relaxed">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <Info className="w-4 h-4 shrink-0" />
                <span>كيف يعمل نظام التدقيق ومطابقة أرقام الهويات؟</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-slate-300 pr-2">
                <li><strong className="text-emerald-300">الشيت الأول (المعتمدين والمقيمين):</strong> الأسر الموجودة بالنظام وحالة اعتماد التنمية <span className="text-emerald-400 font-bold">"معتمد"</span> وصفة الإقامة <span className="text-emerald-400 font-bold">"مقيم"</span>، مع كامل البيانات وعدد المساعدات وتاريخ وآخر نوع مساعدة.</li>
                <li><strong className="text-amber-300">الشيت الثاني (غير المطابقين للشروط):</strong> الأسر المسجلة التي لم تنطبق عليها الشروط مع توضيح سبب الرفض الدقيق <span className="text-amber-400">("غير معتمد تنمية" أو "صفة الإقامة نازح وليس مقيم")</span>.</li>
                <li><strong className="text-rose-300">الشيت الثالث (غير المسجلين في النظام):</strong> الهويات غير الموجودة بالقاعدة ويُكتب بجانبها <span className="text-rose-400 font-bold">"غير مسجل في النظام"</span>.</li>
              </ul>
            </div>

            {/* صندوق اختيار الملف من الجوال */}
            <div className="p-5 rounded-2xl bg-slate-950 border-2 border-dashed border-emerald-500/40 hover:border-emerald-400 transition text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/20">
                <Upload className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-white">اختر ملف الإكسل (Excel / CSV) من ذاكرة الجوال</h4>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  يدعم ملفات (.xlsx, .xls, .csv) ويستخرج أرقام الهويات الفلسطينية (9 أرقام) تلقائياً
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
                <label className="cursor-pointer py-2.5 px-5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-950/50 flex items-center gap-2">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>تصفح واختيار ملف من الجوال 📂</span>
                  <input
                    type="file"
                    accept=".xlsx, .xls, .csv"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>

                <button
                  type="button"
                  onClick={handleLoadSampleDataset}
                  className="py-2.5 px-4 bg-indigo-600/80 hover:bg-indigo-600 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>تجربة ملف نموذجي للهويات 🚀</span>
                </button>
              </div>
            </div>

            {/* أو إدخال الهويات يدوياً بالنص */}
            <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <label className="font-bold text-xs text-slate-300 block">
                ✍️ أو الصق أرقام الهويات مباشرة هنا (رقم هوية في كل سطر أو مفصولة بفواصل):
              </label>
              <textarea
                rows={3}
                value={manualIdsInput}
                onChange={(e) => setManualIdsInput(e.target.value)}
                placeholder="مثال:&#10;901234561&#10;903456783&#10;999000111"
                className="w-full bg-slate-900 border border-slate-750 rounded-xl p-2.5 text-xs text-white font-mono focus:outline-none focus:border-emerald-500 leading-relaxed"
              />
              <button
                type="button"
                onClick={handleProcessManualText}
                className="w-full py-2 bg-slate-800 hover:bg-slate-750 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>فحص ومطابقة الهويات المكتوبة الآن</span>
              </button>
            </div>
          </div>
        ) : (
          /* شاشة التغذية الراجعة والنتائج والـ 3 شيتات */
          <div className="flex-1 overflow-hidden flex flex-col space-y-3">
            {/* Header Stats / KPIs */}
            {/* Header Stats / KPIs */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-right shrink-0">
              <div className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">إجمالي الهويات المفحوصة</span>
                <span className="text-base font-extrabold text-white font-mono">{verificationResult.totalChecked}</span>
                <span className="text-[9px] text-slate-500 block truncate">ملف: {verificationResult.sourceFileName}</span>
              </div>

              <div className="p-2.5 rounded-2xl bg-emerald-950/30 border border-emerald-500/50">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-emerald-300 font-bold block">1. المعتمدين والمقيمين</span>
                  <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <span className="text-base font-extrabold text-emerald-400 font-mono">{verificationResult.approvedCount}</span>
                <span className="text-[9px] text-emerald-300/80 block">شيت 1: معتمد + مقيم</span>
              </div>

              <div className="p-2.5 rounded-2xl bg-amber-950/30 border border-amber-500/50">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-amber-300 font-bold block">2. غير المطابقين للشروط</span>
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                </div>
                <span className="text-base font-extrabold text-amber-400 font-mono">{verificationResult.rejectedCount}</span>
                <span className="text-[9px] text-amber-300/80 block">شيت 2: مستبعد وسبب الرفض</span>
              </div>

              <div className="p-2.5 rounded-2xl bg-rose-950/30 border border-rose-500/50">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-rose-300 font-bold block">3. غير المسجلين</span>
                  <UserX className="w-3.5 h-3.5 text-rose-400" />
                </div>
                <span className="text-base font-extrabold text-rose-400 font-mono">{verificationResult.unregisteredCount}</span>
                <span className="text-[9px] text-rose-300/80 block">شيت 3: غير موجود بالقاعدة</span>
              </div>

              <div className="p-2.5 rounded-2xl bg-indigo-950/30 border border-indigo-500/50 col-span-2 sm:col-span-1">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-indigo-300 font-bold block">4. الصلاحية الجغرافية</span>
                  <MapPin className="w-3.5 h-3.5 text-indigo-400" />
                </div>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-base font-extrabold text-emerald-400 font-mono">{verificationResult.permittedAreaCount || 0}</span>
                  <span className="text-[10px] text-slate-400">مصرح</span>
                  <span className="text-slate-600">/</span>
                  <span className="text-base font-extrabold text-rose-400 font-mono">{verificationResult.restrictedAreaCount || 0}</span>
                  <span className="text-[10px] text-slate-400">محظور</span>
                </div>
                <span className="text-[9px] text-indigo-300/80 block truncate">
                  نطاقك: {verificationResult.userJurisdictionLabel}
                </span>
              </div>
            </div>

            {/* Navigation Tabs for the 3 Sheets */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 shrink-0 border-b border-slate-800 pb-2">
              <div className="flex gap-1 overflow-x-auto text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setActiveTab('sheet1')}
                  className={`py-1.5 px-3 rounded-xl transition border flex items-center gap-1.5 shrink-0 ${
                    activeTab === 'sheet1'
                      ? 'bg-emerald-600 text-white border-emerald-400 shadow-md'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>ورقة 1: المعتمدين والمقيمين ({filteredApproved.length}{onlyMyAreasFilter ? ` من ${verificationResult.approvedCount}` : ''})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('sheet2')}
                  className={`py-1.5 px-3 rounded-xl transition border flex items-center gap-1.5 shrink-0 ${
                    activeTab === 'sheet2'
                      ? 'bg-amber-600 text-white border-amber-400 shadow-md'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>ورقة 2: المستبعدين وأسباب الرفض ({filteredRejected.length}{onlyMyAreasFilter ? ` من ${verificationResult.rejectedCount}` : ''})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveTab('sheet3')}
                  className={`py-1.5 px-3 rounded-xl transition border flex items-center gap-1.5 shrink-0 ${
                    activeTab === 'sheet3'
                      ? 'bg-rose-600 text-white border-rose-400 shadow-md'
                      : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-slate-200'
                  }`}
                >
                  <XCircle className="w-3.5 h-3.5" />
                  <span>ورقة 3: غير المسجلين ({verificationResult.unregisteredCount})</span>
                </button>
              </div>

              {/* Controls: SubArea Dropdown + Quick Search */}
              <div className="flex items-center gap-1.5 shrink-0 w-full sm:w-auto">
                {availableSubAreasInResult.length > 0 && (
                  <select
                    value={selectedSubAreaAuditFilter}
                    onChange={(e) => setSelectedSubAreaAuditFilter(e.target.value)}
                    className="bg-slate-950 border border-slate-800 text-[11px] rounded-xl px-2.5 py-1.5 text-slate-200 focus:outline-none focus:border-emerald-500"
                    title="تصفية النتائج حسب المنطقة الفرعية"
                  >
                    <option value="all">كافة المناطق ({availableSubAreasInResult.length})</option>
                    {availableSubAreasInResult.map(area => {
                      const isPerm = !effectiveUser || effectiveUser.allowedViewSubAreas?.includes('*') || effectiveUser.allowedViewSubAreas?.includes(area);
                      return (
                        <option key={area} value={area}>
                          {area} {isPerm ? '(مصرح ✓)' : '(🔒 خارج نطاقك)'}
                        </option>
                      );
                    })}
                  </select>
                )}

                <div className="relative shrink-0 w-full sm:w-48">
                  <Search className="w-3.5 h-3.5 absolute right-2.5 top-2.5 text-slate-500" />
                  <input
                    type="text"
                    value={searchFilter}
                    onChange={(e) => setSearchFilter(e.target.value)}
                    placeholder="بحث برقم الهوية أو الاسم..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-8 pl-2 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* Active Sheet Content (Scrollable Table) */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-0.5 text-xs">
              {/* TAB 1: APPROVED RESIDENTS */}
              {activeTab === 'sheet1' && (
                <div className="space-y-2">
                  {filteredApproved.length === 0 ? (
                    <div className="p-6 text-center text-slate-500 bg-slate-950 rounded-2xl border border-slate-800">
                      لا توجد أسر مطابقة في هذه الورقة
                    </div>
                  ) : (
                    filteredApproved.map((row, idx) => (
                      <div
                        key={row.nationalID}
                        className="p-3 rounded-2xl bg-slate-950 border border-emerald-500/30 hover:border-emerald-500/60 transition space-y-1.5"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-mono font-bold text-[10px]">
                                {idx + 1}
                              </span>
                              <h5 className="font-bold text-white text-xs sm:text-sm">{row.name}</h5>
                              <span className="text-[10px] bg-slate-900 text-slate-300 font-mono px-2 py-0.5 rounded font-bold border border-slate-800">
                                هوية: {row.nationalID}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400 flex items-center gap-2 pt-0.5 font-mono">
                              <span>جوال: {row.primaryPhone}</span>
                              <span>•</span>
                              <span className="font-sans text-sky-300">{row.currentSubArea}</span>
                              <span>•</span>
                              <span>{row.membersCount} أفراد</span>
                            </div>
                          </div>

                          <div className="flex flex-col items-end gap-1 shrink-0">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                              معتمد + مقيم ✓
                            </span>
                            {row.isAreaPermitted ? (
                              <span className="text-[9px] bg-emerald-500/10 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/20 flex items-center gap-1">
                                <CheckCircle2 className="w-2.5 h-2.5" />
                                <span>مصرح بالمعاينة</span>
                              </span>
                            ) : (
                              <span className="text-[9px] bg-rose-500/20 text-rose-300 px-1.5 py-0.2 rounded font-bold border border-rose-500/30 flex items-center gap-1">
                                <ShieldAlert className="w-2.5 h-2.5" />
                                <span>خارج نطاقك الجغرافي</span>
                              </span>
                            )}
                          </div>
                        </div>

                        {/* تنبيه أمني إن كانت الأسرة خارج نطاق الصلاحيات الجغرافية */}
                        {!row.isAreaPermitted && (
                          <div className="p-2 rounded-xl bg-amber-950/40 border border-amber-500/40 text-[10px] text-amber-200 flex items-center justify-between">
                            <div className="flex items-center gap-1.5">
                              <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                              <span>تنبيه الصلاحيات: تتبع منطقة ({row.currentSubArea}) وهي خارج نطاق الصلاحيات المصرح لحسابك ({currentUser?.roleName || 'المستخدم'}).</span>
                            </div>
                            <span className="text-[9px] bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.2 rounded border border-amber-500/30 shrink-0">
                              مقيد جغرافياً 🔒
                            </span>
                          </div>
                        )}

                        {/* بطاقة المساعدات وآخر استلام */}
                        <div className="p-2 rounded-xl bg-slate-900/80 border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-2 text-[10px]">
                          <div>
                            <span className="text-slate-400 block text-[9px]">عدد المساعدات:</span>
                            <span className="font-bold text-white font-mono">{row.totalAidsCount} مساعدات</span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[9px]">آخر نوع مساعدة:</span>
                            <span className="font-bold text-emerald-300 truncate block">{row.lastAidType}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[9px]">تاريخ آخر مساعدة:</span>
                            <span className="font-mono text-slate-200">{row.lastAidDate}</span>
                          </div>
                          <div>
                            <span className="text-slate-400 block text-[9px]">تصنيف المساعدة:</span>
                            <span className="font-bold text-amber-300">{row.lastAidCategory}</span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* TAB 2: REJECTED CRITERIA WITH DETAILED REASONS */}
              {activeTab === 'sheet2' && (
                <div className="space-y-2">
                  {filteredRejected.length === 0 ? (
                    <div className="p-6 text-center text-slate-500 bg-slate-950 rounded-2xl border border-slate-800">
                      لا توجد أسر مستبعدة في هذه الورقة
                    </div>
                  ) : (
                    filteredRejected.map((row, idx) => (
                      <div
                        key={row.nationalID}
                        className="p-3 rounded-2xl bg-slate-950 border border-amber-500/40 hover:border-amber-500/70 transition space-y-2"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center font-mono font-bold text-[10px]">
                                {idx + 1}
                              </span>
                              <h5 className="font-bold text-white text-xs sm:text-sm">{row.name}</h5>
                              <span className="text-[10px] bg-slate-900 text-slate-300 font-mono px-2 py-0.5 rounded font-bold border border-slate-800">
                                هوية: {row.nationalID}
                              </span>
                            </div>
                            <div className="text-[10px] text-slate-400 flex items-center gap-2 pt-0.5">
                              <span>المنطقة: {row.currentSubArea}</span>
                              <span>•</span>
                              <span>جوال: {row.primaryPhone}</span>
                              <span>•</span>
                              <span>{row.membersCount} أفراد</span>
                            </div>
                          </div>

                          <div className="text-left shrink-0 space-y-1">
                            <span className="text-[9.5px] px-2 py-0.5 rounded font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 block">
                              مستبعد من الاعتماد ⚠️
                            </span>
                            {row.isAreaPermitted ? (
                              <span className="text-[9px] bg-emerald-500/10 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-500/20 flex items-center gap-1 justify-end">
                                <CheckCircle2 className="w-2.5 h-2.5" />
                                <span>مصرح بالمعاينة</span>
                              </span>
                            ) : (
                              <span className="text-[9px] bg-rose-500/20 text-rose-300 px-1.5 py-0.2 rounded font-bold border border-rose-500/30 flex items-center gap-1 justify-end">
                                <ShieldAlert className="w-2.5 h-2.5" />
                                <span>خارج نطاقك الجغرافي</span>
                              </span>
                            )}
                          </div>
                        </div>

                        {/* تنبيه أمني إن كانت الأسرة خارج نطاق الصلاحيات الجغرافية */}
                        {!row.isAreaPermitted && (
                          <div className="p-2 rounded-xl bg-amber-950/40 border border-amber-500/40 text-[10px] text-amber-200 flex items-center justify-between">
                            <div className="flex items-center gap-1.5">
                              <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                              <span>تنبيه الصلاحيات: تتبع منطقة ({row.currentSubArea}) وهي خارج نطاق الصلاحيات المصرح لحسابك ({currentUser?.roleName || 'المستخدم'}).</span>
                            </div>
                            <span className="text-[9px] bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.5 rounded border border-amber-500/30 shrink-0">
                              مقيد جغرافياً 🔒
                            </span>
                          </div>
                        )}

                        {/* سبب الرفض البارز والمفصل كما طلبه المستخدم */}
                        <div className="p-2.5 rounded-xl bg-gradient-to-r from-amber-950/50 to-rose-950/40 border border-amber-500/50 space-y-1">
                          <span className="text-[10px] text-amber-300 font-bold flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                            <span>سبب الرفض الدقيق وعدم استيفاء الشروط:</span>
                          </span>
                          <p className="text-xs font-bold text-white leading-relaxed pr-4">
                            {row.rejectionReason}
                          </p>
                          <div className="flex items-center gap-3 text-[9.5px] text-slate-300 pt-0.5 pr-4">
                            <span>حالة اعتماد التنمية: <strong className="text-white">{row.developmentApproval}</strong></span>
                            <span>•</span>
                            <span>صفة الإقامة: <strong className="text-white">{row.residentStatus}</strong></span>
                          </div>
                        </div>

                        {/* سجل المساعدات السابقة */}
                        <div className="flex items-center justify-between text-[10px] text-slate-400 pt-0.5 px-1">
                          <span>المساعدات السابقة: <strong className="text-slate-200">{row.totalAidsCount}</strong></span>
                          <span>آخر مساعدة: {row.lastAidType} ({row.lastAidDate})</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {/* TAB 3: UNREGISTERED NATIONAL IDS */}
              {activeTab === 'sheet3' && (
                <div className="space-y-2">
                  {filteredUnregistered.length === 0 ? (
                    <div className="p-6 text-center text-slate-500 bg-slate-950 rounded-2xl border border-slate-800">
                      كافة أرقام الهويات مسجلة بالقاعدة
                    </div>
                  ) : (
                    filteredUnregistered.map((row, idx) => (
                      <div
                        key={row.nationalID}
                        className="p-3 rounded-2xl bg-slate-950 border border-rose-500/40 hover:border-rose-500/70 transition flex items-center justify-between gap-2"
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="w-5 h-5 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center font-mono font-bold text-[10px] shrink-0">
                            {idx + 1}
                          </span>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-bold text-white text-xs sm:text-sm">
                                رقم الهوية: {row.nationalID}
                              </span>
                              <span className="text-[10px] bg-rose-500 text-white font-bold px-2 py-0.5 rounded-full">
                                {row.status}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-400 mt-0.5">
                              {row.actionRequired}
                            </p>
                          </div>
                        </div>

                        <span className="text-[9.5px] text-slate-500 font-mono shrink-0">
                          {row.checkedDate}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>

            {/* Bottom Actions for Results */}
            <div className="pt-2 border-t border-slate-800 flex flex-wrap gap-2 shrink-0">
              <button
                type="button"
                onClick={() => handleDownloadMultiSheetExcel(true)}
                className="flex-1 py-2.5 px-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-1.5"
                title="تصدير شيتات الإكسل الثلاثة محصورة فقط بالمواطنين التابعين للمناطق المصرح بها لحسابك"
              >
                <Download className="w-4 h-4" />
                <span>تحميل إكسل مقيّد بصلاحيات مناطقي (3 شيتات) 🔒</span>
              </button>

              <button
                type="button"
                onClick={() => handleDownloadMultiSheetExcel(false)}
                className="py-2.5 px-3.5 bg-slate-800 hover:bg-slate-750 text-indigo-300 border border-indigo-500/40 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
                title="تصدير كافة أرقام الهويات مع وسم وتحديد نطاق الصلاحيات الجغرافية لكل صف"
              >
                <FileSpreadsheet className="w-4 h-4 text-indigo-400" />
                <span>تحميل إكسل شامل مع وسوم الصلاحيات 📊</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setVerificationResult(null);
                  setUploadedFileName('');
                  setManualIdsInput('');
                }}
                className="py-3 px-4 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-bold transition flex items-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4 text-amber-300" />
                <span>فحص ملف آخر 🔄</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="px-4 py-3 bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-white rounded-xl text-xs font-medium"
              >
                إغلاق
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
