import React from 'react';
import { Terminal, CheckCircle2, Smartphone, Cpu, Layers, HardDrive, ShieldCheck, ArrowRight } from 'lucide-react';

export const BuildGuide: React.FC = () => {
  return (
    <div className="space-y-6 max-w-4xl mx-auto py-2">
      {/* Hero Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-emerald-900/40 via-slate-800 to-sky-900/30 border border-emerald-500/30 shadow-xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
          <Smartphone className="w-3.5 h-3.5" />
          <span>Android Native • Kotlin & Jetpack Compose</span>
        </div>
        <h2 className="text-xl md:text-2xl font-bold text-white">
          دليل فتح المشروع وبناء ملف الـ APK في Android Studio
        </h2>
        <p className="text-sm text-slate-300 leading-relaxed">
          مشروع أندرويد نيتف حقيقي متوافق 100% مع معايير Google الرسمية ومعمارية MVVM مع Room Database بدون الحاجة لأي اتصال بالإنترنت في العمل الميداني.
        </p>
      </div>

      {/* Steps Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Step 1 */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-sm">
            1
          </div>
          <h3 className="font-bold text-base text-white">تحميل ملفات المشروع وفك الضغط</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            اضغط على زر <strong className="text-emerald-400">"تحميل مشروع Android Studio (ZIP)"</strong> في أعلى الصفحة. قم بفك الضغط عن الملف في مجلد مشاريعك (مثلاً: <code className="text-slate-300 font-mono">Projects/HumanitarianAid</code>).
          </p>
        </div>

        {/* Step 2 */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-sm">
            2
          </div>
          <h3 className="font-bold text-base text-white">فتح المشروع في Android Studio</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            افتح برنامج Android Studio (الإصدار Hedgehog 2023.1 أو أحدث)، واختر <strong className="text-slate-200">File &gt; Open</strong> ثم حدد مجلد المشروع واضغط OK.
          </p>
        </div>

        {/* Step 3 */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-sm">
            3
          </div>
          <h3 className="font-bold text-base text-white">مزامنة Gradle ومكتبات Room</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            سيقوم أندرويد ستوديو تلقائياً بمزامنة ملفات <code className="text-emerald-400 font-mono">build.gradle.kts</code> وتحميل مكتبات Jetpack Compose و Room Database و KSP.
          </p>
        </div>

        {/* Step 4 */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-sm">
            4
          </div>
          <h3 className="font-bold text-base text-white">بناء ملف الـ APK وتثبيته</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            من القائمة العلوية اختر:
            <br />
            <span className="font-bold text-emerald-300">Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</span>
            <br />
            أو نفذ الأمر في الطرفية (Terminal):
            <code className="block mt-1 p-2 bg-slate-950 rounded text-emerald-400 font-mono text-[11px] dir-ltr text-left">
              ./gradlew assembleDebug
            </code>
          </p>
        </div>
      </div>

      {/* Architecture Highlights */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <Layers className="w-5 h-5 text-emerald-400" />
          معمارية المشروع المطبقة (Architecture & Tech Stack)
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
            <span className="font-bold text-emerald-400 block mb-1">Jetpack Compose</span>
            <span className="text-slate-400">واجهات برمجية تصريحية حديثة مع Material 3 ودعم RTL للغة العربية.</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
            <span className="font-bold text-sky-400 block mb-1">Room SQLite Database</span>
            <span className="text-slate-400">13 جدولاً محلياً مع فهرسة للأداء وبذر تلقائي للبيانات بدون إنترنت.</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
            <span className="font-bold text-amber-400 block mb-1">Nomination Engine</span>
            <span className="text-slate-400">خوارزمية ذكية لاستثناء المساعدات السابقة وتقريب حصص المحليات بنظام الكسور.</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
            <span className="font-bold text-purple-400 block mb-1">Repository Pattern</span>
            <span className="text-slate-400">فصل طبقة البيانات عن واجهات العرض لضمان سهولة الفحص والاختبار.</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
            <span className="font-bold text-rose-400 block mb-1">حماية وأمان الدخول</span>
            <span className="text-slate-400">قفل الحساب بعد 5 محاولات فاشلة، وفحص الصلاحيات حسب المحليات.</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60">
            <span className="font-bold text-teal-400 block mb-1">Coroutines & Flow</span>
            <span className="text-slate-400">معالجة غير متزامنة وتحديثات فورية للواجهات في الوقت الحقيقي.</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60 col-span-1 sm:col-span-2 md:col-span-3">
            <span className="font-bold text-emerald-400 block mb-1">نسخ احتياطي واستعادة محلياً (JSON & SQL Dump)</span>
            <span className="text-slate-400">تصدير كامل قاعدة بيانات Room بجميع جداول الأسر والمساعدات إلى ملفات JSON أو SQL Dump واستعادتها بسهولة عبر شاشة مخصصة في حال تغيير الجهاز.</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60 col-span-1 sm:col-span-2 md:col-span-3">
            <span className="font-bold text-sky-400 block mb-1">تصدير وطباعة تقارير PDF الميدانية (PdfDocument & PrintManager)</span>
            <span className="text-slate-400">توليد كشوفات تسليم المساعدات الرسمية مع جداول المستفيدين ومربعات التوقيع والبصمة، مع إمكانية الطباعة المباشرة والمشاركة عبر WhatsApp و البريد الإلكتروني.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
