import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  PieChart,
  TrendingUp,
  MapPin,
  FolderKanban,
  PackageCheck,
  Users,
  ShieldCheck,
  ShieldAlert,
  FileSpreadsheet,
  Download,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  HeartHandshake,
  Building2,
  Warehouse,
  Baby,
  Calendar,
  Layers,
  ArrowUpRight,
  Eye,
  Sliders,
  Sparkles,
  Printer,
  ChevronDown,
  RefreshCw,
  Clock,
  UserCheck,
  UserX,
  Database,
  Lock,
  Shield,
  CloudLightning,
  Zap
} from 'lucide-react';
import { MockFamily, MockChild, DeliveryRecord, AID_CATEGORIES } from './AndroidEmulator';
import { MockUser, SystemRole } from '../types/adminSecurity';
import { SubAreaItem, INITIAL_SUB_AREAS_DATA } from '../types/subAreaService';
import * as XLSX from 'xlsx';

interface ProjectItem {
  projectNumber: string;
  projectName: string;
  aidTypeName: string;
  aidValue: number;
  warehouse: string;
  fundingOrg: string;
  distributionDate: string;
  targetBeneficiaries: number;
  deliveredCount: number;
  candidatesCount: number;
  status: string;
  officer?: string;
  subAreas?: string[];
}

interface ComprehensiveSystemDisplayHubProps {
  currentUser: MockUser | null;
  usersList: MockUser[];
  onSelectUser: (user: MockUser) => void;
  familiesList: MockFamily[];
  childrenList: MockChild[];
  deliveryRecords: DeliveryRecord[];
  comprehensiveProjectsList: ProjectItem[];
  subAreasList?: SubAreaItem[];
  onOpenExcelAudit?: () => void;
  onOpenDataLinking?: () => void;
  onNavigateToScreen?: (screen: string) => void;
}

export function ComprehensiveSystemDisplayHub({
  currentUser,
  usersList,
  onSelectUser,
  familiesList,
  childrenList,
  deliveryRecords,
  comprehensiveProjectsList,
  subAreasList = INITIAL_SUB_AREAS_DATA,
  onOpenExcelAudit,
  onOpenDataLinking,
  onNavigateToScreen
}: ComprehensiveSystemDisplayHubProps) {
  // Navigation Tabs for the Hub
  const [activeTab, setActiveTab] = useState<'analytics' | 'areas' | 'projects' | 'families' | 'reports' | 'geo_permissions'>('analytics');

  // Filter States
  const [selectedSubAreaFilter, setSelectedSubAreaFilter] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedResidentFilter, setSelectedResidentFilter] = useState<'all' | 'مقيم' | 'نازح'>('all');
  const [selectedDevFilter, setSelectedDevFilter] = useState<'all' | 'معتمد' | 'حجب اعتماد' | 'مجمد'>('all');
  const [selectedAidCategoryFilter, setSelectedAidCategoryFilter] = useState<number | 'all'>('all');

  // ==================== 1. التحقق من الصلاحيات الجغرافية وتصفية البيانات ====================
  const isSuperAdmin = useMemo(() => {
    if (!currentUser) return true;
    return currentUser.roleId === 1 || currentUser.allowedViewSubAreas?.includes('*');
  }, [currentUser]);

  const userAllowedAreas = useMemo(() => {
    if (!currentUser || isSuperAdmin) return ['*'];
    return currentUser.allowedViewSubAreas || [];
  }, [currentUser, isSuperAdmin]);

  // الأسر المصرح بمعاينتها
  const authorizedFamilies = useMemo(() => {
    if (isSuperAdmin) return familiesList;
    return familiesList.filter(f => userAllowedAreas.includes(f.currentSubArea));
  }, [familiesList, isSuperAdmin, userAllowedAreas]);

  // سجلات التسليم المصرح بمعاينتها
  const authorizedDeliveries = useMemo(() => {
    if (isSuperAdmin) return deliveryRecords;
    return deliveryRecords.filter(d => userAllowedAreas.includes(d.family.currentSubArea));
  }, [deliveryRecords, isSuperAdmin, userAllowedAreas]);

  // المناطق المصرح بها
  const authorizedSubAreas = useMemo(() => {
    if (isSuperAdmin) return subAreasList;
    return subAreasList.filter(s => userAllowedAreas.includes(s.name));
  }, [subAreasList, isSuperAdmin, userAllowedAreas]);

  // المناطق المحجوبة أمنياً خارج نطاق الصلاحيات الجغرافية للمستخدم
  const restrictedSubAreas = useMemo(() => {
    if (isSuperAdmin) return [];
    return subAreasList.filter(s => !userAllowedAreas.includes(s.name));
  }, [subAreasList, isSuperAdmin, userAllowedAreas]);

  // المشاريع المصرح بها
  const authorizedProjects = useMemo(() => {
    if (isSuperAdmin) return comprehensiveProjectsList;
    return comprehensiveProjectsList.filter(p => {
      if (!p.subAreas || p.subAreas.length === 0) return true;
      return p.subAreas.some(area => userAllowedAreas.includes(area));
    });
  }, [comprehensiveProjectsList, isSuperAdmin, userAllowedAreas]);

  // ==================== 2. حساب المؤشرات العامة والـ KPIs ====================
  const kpis = useMemo(() => {
    const totalFamilies = authorizedFamilies.length;
    const totalIndividuals = authorizedFamilies.reduce((sum, f) => sum + (f.membersCount || 0), 0);
    const totalChildren = authorizedFamilies.reduce((sum, f) => {
      const c = childrenList.filter(ch => ch.familyID === f.familyID || ch.parentNationalID === f.nationalID).length;
      return sum + c;
    }, 0);

    const deliveredRecords = authorizedDeliveries.filter(d => d.status === 'تم التسليم');
    const pendingCandidates = authorizedDeliveries.filter(d => d.status === 'مرشح');
    const totalDeliveredCount = deliveredRecords.length;
    const totalDeliveredValue = deliveredRecords.reduce((sum, d) => sum + (d.aidValue || 0), 0);

    const approvedDevCount = authorizedFamilies.filter(f => f.developmentApproval === 'معتمد').length;
    const residentCount = authorizedFamilies.filter(f => f.residentStatus === 'مقيم').length;
    const displacedCount = authorizedFamilies.filter(f => f.residentStatus === 'نازح').length;

    const totalTargetQuota = authorizedSubAreas.reduce((sum, s) => sum + (s.targetFamiliesQuota || 0), 0);
    const quotaAchievementPct = totalTargetQuota > 0 ? Math.min(100, Math.round((totalDeliveredCount / totalTargetQuota) * 100)) : 48;

    return {
      totalFamilies,
      totalIndividuals,
      totalChildren,
      totalDeliveredCount,
      totalDeliveredValue,
      pendingCandidatesCount: pendingCandidates.length,
      approvedDevCount,
      residentCount,
      displacedCount,
      totalTargetQuota,
      quotaAchievementPct,
      projectsCount: authorizedProjects.length,
      subAreasCount: authorizedSubAreas.length
    };
  }, [authorizedFamilies, childrenList, authorizedDeliveries, authorizedSubAreas, authorizedProjects]);

  // توزيع المساعدات حسب الـ 11 تصنيفاً ضمن نطاق الصلاحيات
  const aidCategoriesBreakdown = useMemo(() => {
    return AID_CATEGORIES.map(cat => {
      // حساب عدد المستفيدين في نطاق المستخدم
      const deliveredInCat = authorizedDeliveries.filter(d => {
        if (d.status !== 'تم التسليم') return false;
        return d.projectName.includes(cat.name) || d.aidTypeName.includes(cat.name);
      }).length;

      const candidatesInCat = authorizedDeliveries.filter(d => {
        if (d.status !== 'مرشح') return false;
        return d.projectName.includes(cat.name) || d.aidTypeName.includes(cat.name);
      }).length;

      const baselineCount = Math.round((cat.count / 100) * (authorizedFamilies.length || 10));

      return {
        ...cat,
        activeDelivered: Math.max(deliveredInCat, baselineCount),
        pendingCandidates: candidatesInCat + Math.round(baselineCount * 0.4)
      };
    });
  }, [authorizedDeliveries, authorizedFamilies]);

  // إحصائيات المناطق المصرح بها
  const subAreasMetrics = useMemo(() => {
    return authorizedSubAreas.map(sub => {
      const famsInArea = authorizedFamilies.filter(f => f.currentSubArea === sub.name);
      const deliveredInArea = authorizedDeliveries.filter(d => d.family.currentSubArea === sub.name && d.status === 'تم التسليم').length;
      const candidatesInArea = authorizedDeliveries.filter(d => d.family.currentSubArea === sub.name && d.status === 'مرشح').length;
      const approvedDev = famsInArea.filter(f => f.developmentApproval === 'معتمد').length;
      const residents = famsInArea.filter(f => f.residentStatus === 'مقيم').length;

      const target = sub.targetFamiliesQuota || 2000;
      const progress = Math.min(100, Math.round((deliveredInArea / target) * 100));

      return {
        ...sub,
        currentFamiliesCount: famsInArea.length,
        deliveredCount: deliveredInArea,
        candidatesCount: candidatesInArea,
        approvedDevCount: approvedDev,
        residentsCount: residents,
        progressPct: progress,
        deficit: Math.max(0, target - deliveredInArea)
      };
    });
  }, [authorizedSubAreas, authorizedFamilies, authorizedDeliveries]);

  // الأسر المفلترة للجدول التفصيلي
  const filteredFamiliesTable = useMemo(() => {
    return authorizedFamilies.filter(f => {
      if (selectedSubAreaFilter !== 'all' && f.currentSubArea !== selectedSubAreaFilter) return false;
      if (selectedResidentFilter !== 'all' && f.residentStatus !== selectedResidentFilter) return false;
      if (selectedDevFilter !== 'all' && f.developmentApproval !== selectedDevFilter) return false;
      if (searchTerm.trim()) {
        const q = searchTerm.trim().toLowerCase();
        const match =
          f.name.toLowerCase().includes(q) ||
          f.nationalID.includes(q) ||
          f.primaryPhone.includes(q) ||
          f.currentSubArea.includes(q) ||
          f.currentMosque.includes(q) ||
          (f.rationCardNumber && f.rationCardNumber.includes(q));
        if (!match) return false;
      }
      return true;
    });
  }, [authorizedFamilies, selectedSubAreaFilter, selectedResidentFilter, selectedDevFilter, searchTerm]);

  // تصدير كشف القيادة الشامل لملف Excel متعدد الشيتات
  const handleExportFullSystemExcel = () => {
    try {
      const wb = XLSX.utils.book_new();

      // الورقة 1: ملخص المؤشرات والمناطق
      const sheet1Data = subAreasMetrics.map((s, idx) => ({
        'م': idx + 1,
        'المنطقة الفرعية': s.name,
        'الكود': s.code,
        'المحافظة / المحلية': s.localityName,
        'الحصة المستهدفة (أسرة)': s.targetFamiliesQuota,
        'الأسر المسجلة': s.currentFamiliesCount,
        'المستلمين فعلياً': s.deliveredCount,
        'المرشحين قيد الصرف': s.candidatesCount,
        'العجز المتبقي': s.deficit,
        'نسبة التغطية': `${s.progressPct}%`,
        'معتمدي التنمية': s.approvedDevCount,
        'المقيمين': s.residentsCount,
        'عدد المشرفين': s.activeSupervisorsCount
      }));
      const ws1 = XLSX.utils.json_to_sheet(sheet1Data);
      ws1['!cols'] = [{ wch: 6 }, { wch: 22 }, { wch: 14 }, { wch: 18 }, { wch: 16 }, { wch: 14 }, { wch: 16 }, { wch: 16 }, { wch: 14 }, { wch: 14 }, { wch: 16 }, { wch: 12 }, { wch: 14 }];
      XLSX.utils.book_append_sheet(wb, ws1, 'مؤشرات_المناطق_والحصص');

      // الورقة 2: المشاريع الإغاثية
      const sheet2Data = authorizedProjects.map((p, idx) => ({
        'م': idx + 1,
        'كود المشروع': p.projectNumber,
        'اسم المشروع الإغاثي': p.projectName,
        'نوع المساعدة': p.aidTypeName,
        'قيمة الطرد (₪)': p.aidValue,
        'المستودع المنفذ': p.warehouse,
        'الجهة الممولة': p.fundingOrg,
        'المستهدف (أسرة)': p.targetBeneficiaries,
        'المستلمين': p.deliveredCount,
        'المرشحين': p.candidatesCount,
        'الحالة': p.status,
        'تاريخ التوزيع': p.distributionDate
      }));
      const ws2 = XLSX.utils.json_to_sheet(sheet2Data);
      ws2['!cols'] = [{ wch: 6 }, { wch: 16 }, { wch: 30 }, { wch: 24 }, { wch: 14 }, { wch: 24 }, { wch: 24 }, { wch: 14 }, { wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 14 }];
      XLSX.utils.book_append_sheet(wb, ws2, 'سجل_المشاريع_الإغاثية');

      // الورقة 3: سجل الأسر والمساعدات
      const sheet3Data = filteredFamiliesTable.slice(0, 150).map((f, idx) => ({
        'م': idx + 1,
        'رقم الهوية الوطنية': f.nationalID,
        'اسم رب الأسرة': f.name,
        'رقم الجوال': f.primaryPhone,
        'المنطقة الفرعية': f.currentSubArea,
        'المسجد / الشعبة': f.currentMosque,
        'حالة اعتماد التنمية': f.developmentApproval,
        'صفة الإقامة': f.residentStatus,
        'أفراد الأسرة': f.membersCount,
        'آخر نوع مساعدة': f.lastAidType || 'طرد غذائي أساسي',
        'تاريخ آخر مساعدة': f.lastAidDate || '2024-11-10'
      }));
      const ws3 = XLSX.utils.json_to_sheet(sheet3Data);
      ws3['!cols'] = [{ wch: 6 }, { wch: 18 }, { wch: 28 }, { wch: 16 }, { wch: 20 }, { wch: 20 }, { wch: 18 }, { wch: 14 }, { wch: 12 }, { wch: 24 }, { wch: 16 }];
      XLSX.utils.book_append_sheet(wb, ws3, 'سجل_الأسر_والمساعدات');

      const fileName = `تقرير_القيادة_والبيانات_الشامل_${new Date().toISOString().slice(0, 10)}.xlsx`;
      XLSX.writeFile(wb, fileName);
      alert(`✅ تم تصدير التقرير الشامل بنجاح إلى ملف إكسل متعدد الشيتات: "${fileName}"`);
    } catch (err: any) {
      alert(`خطأ أثناء التصدير: ${err.message}`);
    }
  };

  return (
    <div className="space-y-4 text-right font-sans" dir="rtl">
      {/* ==================== شريط نطاق الصلاحيات الجغرافية والأمنية ومحاكي التبديل ==================== */}
      <div className="p-3.5 sm:p-4 rounded-3xl bg-slate-900 border-2 border-indigo-500/40 shadow-xl space-y-3 ring-1 ring-indigo-500/20">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-emerald-500 flex items-center justify-center text-white shadow-lg shadow-indigo-950/50 font-bold shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-base sm:text-lg font-black text-white">
                  مركز القيادة وشاشة العرض الموسعة لكافة بيانات النظام
                </h2>
                <span className="text-[10px] bg-indigo-500/20 text-indigo-300 font-bold px-2.5 py-0.5 rounded-full border border-indigo-500/30">
                  مقيّد بالصلاحيات الجغرافية 🔒
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                تكامل لحظي لكافة الأسر، المساعدات المصروفة، المشاريع، والحصص الجغرافية طبقاً لصلاحيات المستخدم النشط
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 flex-wrap">
            {onOpenDataLinking && (
              <button
                type="button"
                onClick={onOpenDataLinking}
                className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-sky-600 via-indigo-600 to-sky-700 hover:from-sky-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-sky-950/40 transition border border-sky-400/40"
                title="ربط ومزامنة البيانات الحقيقية بالجملة من الجوال والداخلي والسحابي"
              >
                <CloudLightning className="w-4 h-4 text-sky-200" />
                <span>ربط ومزامنة البيانات ⚡ (جوال / سحابي)</span>
              </button>
            )}

            {onOpenExcelAudit && (
              <button
                type="button"
                onClick={onOpenExcelAudit}
                className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md transition"
                title="فحص ومطابقة ملف إكسل الهويات مع الصلاحيات الجغرافية"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>فحص إكسل الهويات 📱</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleExportFullSystemExcel}
              className="py-2 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 font-bold text-xs flex items-center gap-1.5 transition"
              title="تصدير تقرير القيادة الشامل متعدد الأوراق إلى Excel"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>تصدير إكسل شامل 📊</span>
            </button>
          </div>
        </div>

        {/* شريط حالة صلاحيات المستخدم النشط + محاكي التبديل السريع */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs bg-slate-950/70 p-2.5 rounded-2xl border border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <UserCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-slate-400">المستخدم الحالي:</span>
                <span className="font-extrabold text-white text-xs">{currentUser?.fullName}</span>
                <span className="text-[10px] bg-slate-800 text-indigo-300 font-mono px-2 py-0.2 rounded border border-indigo-500/30">
                  {currentUser?.roleName}
                </span>
              </div>
              <div className="flex items-center gap-2 text-[11px] pt-0.5">
                <span className="text-slate-400">المناطق المصرح لك بمعاينتها:</span>
                <span className="font-bold text-emerald-400">
                  {isSuperAdmin ? 'كافة المناطق والمحليات الـ 5 (شامل *)' : userAllowedAreas.join('، ')}
                </span>
                {!isSuperAdmin && (
                  <span className="text-[10px] text-amber-300 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/20 font-bold">
                    حجب {5 - userAllowedAreas.length} مناطق خارج نطاقك
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* تبديل فوري لتجربة الصلاحيات */}
          <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-auto">
            <span className="text-[10px] text-slate-400 hidden md:inline">تبديل الحساب لفحص الصلاحيات:</span>
            <div className="flex gap-1 overflow-x-auto">
              {usersList.slice(0, 4).map(u => {
                const isSelected = currentUser?.id === u.id;
                return (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => onSelectUser(u)}
                    className={`py-1 px-2.5 rounded-xl text-[10.5px] font-bold border transition ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-400 shadow'
                        : 'bg-slate-900 text-slate-300 border-slate-750 hover:bg-slate-850'
                    }`}
                  >
                    <span>{u.username === 'admin' ? '👑 المدير' : u.fullName.split(' ')[1] || u.fullName.split(' ')[0]}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* ==================== 2. بطاقات مؤشرات الأداء الشاملة (Executive KPIs) ==================== */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
        {/* KPI 1 */}
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>الأسر المصرحة</span>
            <Users className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white font-mono">{kpis.totalFamilies.toLocaleString('ar-EG')}</div>
          <div className="text-[10px] text-slate-400">إجمالي {kpis.totalIndividuals.toLocaleString('ar-EG')} فرداً</div>
        </div>

        {/* KPI 2 */}
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>المساعدات المسلّمة</span>
            <PackageCheck className="w-4 h-4 text-teal-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-teal-400 font-mono">{kpis.totalDeliveredCount.toLocaleString('ar-EG')}</div>
          <div className="text-[10px] text-slate-400">{kpis.pendingCandidatesCount} قيد الصرف</div>
        </div>

        {/* KPI 3 */}
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>القيمة الإجمالية المصروفة</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-300 font-mono">{kpis.totalDeliveredValue.toLocaleString('ar-EG')} ₪</div>
          <div className="text-[10px] text-slate-400">تم صرفها ميدانياً</div>
        </div>

        {/* KPI 4 */}
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>المشاريع المشمولة</span>
            <FolderKanban className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-indigo-300 font-mono">{kpis.projectsCount}</div>
          <div className="text-[10px] text-slate-400">تغطي مناطقك المصرحة</div>
        </div>

        {/* KPI 5 */}
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>المناطق والمحليات</span>
            <MapPin className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-sky-300 font-mono">{kpis.subAreasCount} من 5</div>
          <div className="text-[10px] text-slate-400">إنجاز الحصص: {kpis.quotaAchievementPct}%</div>
        </div>

        {/* KPI 6 */}
        <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span>اعتماد التنمية والإقامة</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-base font-extrabold text-white">
            <span className="text-emerald-400 font-mono">{kpis.approvedDevCount}</span> معتمد
          </div>
          <div className="text-[10px] text-slate-400">
            {kpis.residentCount} مقيم • {kpis.displacedCount} نازح
          </div>
        </div>
      </div>

      {/* ==================== 3. التبويبات الرئيسية لشاشة العرض الموسعة ==================== */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-2">
        <div className="flex gap-1.5 overflow-x-auto text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('analytics')}
            className={`py-2 px-3.5 rounded-2xl border transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'analytics'
                ? 'bg-emerald-600 text-white border-emerald-400 shadow-lg shadow-emerald-950/50'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-emerald-300" />
            <span>1. الرؤية البيانية والتحليلية 📊</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('areas')}
            className={`py-2 px-3.5 rounded-2xl border transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'areas'
                ? 'bg-sky-600 text-white border-sky-400 shadow-lg shadow-sky-950/50'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <MapPin className="w-4 h-4 text-sky-300" />
            <span>2. مصفوفة المناطق والحصص ({kpis.subAreasCount}) 🗺️</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('projects')}
            className={`py-2 px-3.5 rounded-2xl border transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'projects'
                ? 'bg-indigo-600 text-white border-indigo-400 shadow-lg shadow-indigo-950/50'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <FolderKanban className="w-4 h-4 text-indigo-300" />
            <span>3. سجل المشاريع الإغاثية ({kpis.projectsCount}) 📋</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('families')}
            className={`py-2 px-3.5 rounded-2xl border transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'families'
                ? 'bg-teal-600 text-white border-teal-400 shadow-lg shadow-teal-950/50'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4 text-teal-300" />
            <span>4. سجل المستفيدين والمساعدات ({filteredFamiliesTable.length}) 👥</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('reports')}
            className={`py-2 px-3.5 rounded-2xl border transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'reports'
                ? 'bg-amber-600 text-white border-amber-400 shadow-lg shadow-amber-950/50'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4 text-amber-300" />
            <span>5. مركز التقارير والطباعة 📑</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('geo_permissions')}
            className={`py-2 px-3.5 rounded-2xl border transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'geo_permissions'
                ? 'bg-purple-600 text-white border-purple-400 shadow-lg shadow-purple-950/50'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-purple-300" />
            <span>6. مستكشف الصلاحيات الجغرافية 🛡️</span>
          </button>
        </div>
      </div>

      {/* ==================== محتوى التبويب 1: الرؤية البيانية والتحليلية ==================== */}
      {activeTab === 'analytics' && (
        <div className="space-y-4">
          {/* قسم الرسوم البيانية المتطورة */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* رسم بياني 1: مقارنة إنجاز الحصص في المناطق المصرح بها */}
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-sky-400" />
                  <h4 className="font-bold text-sm text-white">تحليل نسب إنجاز الحصص والتوزيع بالمناطق</h4>
                </div>
                <span className="text-[11px] text-slate-400 font-mono">حسب الصلاحيات الجغرافية</span>
              </div>

              <div className="space-y-3 pt-1">
                {subAreasMetrics.map(sub => (
                  <div key={sub.id} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-200">{sub.name}</span>
                      <div className="flex items-center gap-2 text-[11px]">
                        <span className="text-emerald-400 font-mono font-bold">{sub.deliveredCount} مستلم</span>
                        <span className="text-slate-500">/</span>
                        <span className="text-slate-400 font-mono">حصة {sub.targetFamiliesQuota}</span>
                        <span className="font-mono text-sky-300 font-bold bg-slate-800 px-1.5 py-0.2 rounded">
                          {sub.progressPct}%
                        </span>
                      </div>
                    </div>

                    {/* شريط الإنجاز */}
                    <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden flex">
                      <div
                        className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500"
                        style={{ width: `${sub.progressPct}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* رسم بياني 2: توزيع المساعدات عبر الـ 11 تصنيفاً */}
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-emerald-400" />
                  <h4 className="font-bold text-sm text-white">توزيع المساعدات عبر الـ 11 تصنيفاً معتمداً</h4>
                </div>
                <span className="text-[11px] text-emerald-400 font-mono">11 فئة إغاثية</span>
              </div>

              <div className="space-y-2 pt-1 max-h-72 overflow-y-auto pr-1">
                {aidCategoriesBreakdown.map(cat => {
                  const maxCount = Math.max(...aidCategoriesBreakdown.map(c => c.activeDelivered), 1);
                  const pct = Math.min(100, Math.round((cat.activeDelivered / maxCount) * 100));

                  return (
                    <div key={cat.id} className="space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className={`w-4 h-4 rounded flex items-center justify-center font-bold text-[9px] ${cat.color}`}>
                            {cat.id}
                          </span>
                          <span className="text-slate-200">{cat.name}</span>
                        </div>
                        <span className="font-mono font-bold text-slate-300 text-[11px]">
                          {cat.activeDelivered} مستفيد
                        </span>
                      </div>
                      <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-teal-500 to-indigo-500 rounded-full"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* لوحة بطاقات التحليل المعمق (Demographics & Vulnerability) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                <span>حالة اعتماد التنمية الاجتماعية</span>
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>معتمد رسمياً:</span>
                  <span className="font-bold text-emerald-400 font-mono">{kpis.approvedDevCount}</span>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>حجب اعتماد / غير معتمد:</span>
                  <span className="font-bold text-amber-400 font-mono">{kpis.totalFamilies - kpis.approvedDevCount}</span>
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                <span>صفة الإقامة والنزوح</span>
                <Building2 className="w-4 h-4 text-sky-400" />
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>مقيم في المنطقة:</span>
                  <span className="font-bold text-emerald-400 font-mono">{kpis.residentCount}</span>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>نازح من مناطق أخرى:</span>
                  <span className="font-bold text-sky-400 font-mono">{kpis.displacedCount}</span>
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                <span>رعاية الأطفال والأيتام</span>
                <Baby className="w-4 h-4 text-pink-400" />
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>إجمالي الأطفال والتابعين:</span>
                  <span className="font-bold text-pink-400 font-mono">{kpis.totalChildren}</span>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>متوسط أفراد الأسرة:</span>
                  <span className="font-mono text-slate-200">
                    {kpis.totalFamilies > 0 ? (kpis.totalIndividuals / kpis.totalFamilies).toFixed(1) : 0} أفراد
                  </span>
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-300">
                <span>التدقيق والمطابقة مع إكسل</span>
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="space-y-1 text-xs">
                <div className="flex justify-between text-slate-300">
                  <span>محرك الشيتات الثلاثية:</span>
                  <span className="font-bold text-emerald-400">مفعّل جاهز</span>
                </div>
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>فحص الهويات بالجوال:</span>
                  <span className="text-emerald-300 font-bold">يدعم 3 شيتات</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== محتوى التبويب 2: مصفوفة وتقارير المناطق والمحليات ==================== */}
      {activeTab === 'areas' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between pb-1 border-b border-slate-800">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-sky-400" />
              <span>مصفوفة المناطق والمحليات والحصص الميدانية المعتمدة</span>
            </h4>
            <span className="text-xs text-slate-400">
              {authorizedSubAreas.length} مناطق مصرحة لك
            </span>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-3">المنطقة الفرعية</th>
                  <th className="p-3">الكود</th>
                  <th className="p-3">الحصة المستهدفة</th>
                  <th className="p-3">المسجلين</th>
                  <th className="p-3">المستلمين</th>
                  <th className="p-3">المرشحين</th>
                  <th className="p-3">العجز المتبقي</th>
                  <th className="p-3">نسبة التغطية</th>
                  <th className="p-3">معتمدي التنمية</th>
                  <th className="p-3">المشرفين</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-200">
                {subAreasMetrics.map(sub => (
                  <tr key={sub.id} className="hover:bg-slate-850/50 transition">
                    <td className="p-3 font-bold text-white">{sub.name}</td>
                    <td className="p-3 font-mono text-slate-400">{sub.code}</td>
                    <td className="p-3 font-mono text-slate-300">{sub.targetFamiliesQuota}</td>
                    <td className="p-3 font-mono text-slate-300">{sub.currentFamiliesCount}</td>
                    <td className="p-3 font-mono text-emerald-400 font-bold">{sub.deliveredCount}</td>
                    <td className="p-3 font-mono text-teal-400">{sub.candidatesCount}</td>
                    <td className="p-3 font-mono text-amber-400 font-bold">{sub.deficit}</td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <div className="w-14 h-2 bg-slate-800 rounded-full overflow-hidden">
                          <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${sub.progressPct}%` }} />
                        </div>
                        <span className="font-mono text-[11px] text-emerald-300 font-bold">{sub.progressPct}%</span>
                      </div>
                    </td>
                    <td className="p-3 font-mono text-slate-300">{sub.approvedDevCount}</td>
                    <td className="p-3 font-mono text-sky-400 font-bold">{sub.activeSupervisorsCount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* المناطق المحجوبة أمنياً خارج نطاق صلاحيات المستخدم */}
          {restrictedSubAreas.length > 0 && (
            <div className="p-4 rounded-3xl bg-slate-950 border border-rose-500/30 space-y-3 mt-3">
              <div className="flex items-center justify-between pb-2 border-b border-rose-500/20">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-400" />
                  <h5 className="font-bold text-xs sm:text-sm text-rose-300">
                    المناطق المحجوبة أمنياً خارج نطاق صلاحيات حسابك ({restrictedSubAreas.length} مناطق)
                  </h5>
                </div>
                <span className="text-[10px] bg-rose-500/20 text-rose-300 font-bold px-2 py-0.5 rounded-full border border-rose-500/30">
                  مقيد الصلاحيات 🔒
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                حسابك الحالي ({currentUser?.fullName} - {currentUser?.roleName}) غير مصرح له باستعراض بيانات وحصص المناطق التالية، وتم حجبها تلقائياً وفقاً للسياسات الأمنية:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                {restrictedSubAreas.map(sub => (
                  <div key={sub.id} className="p-3 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5 opacity-80">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">{sub.name}</span>
                      <span className="text-[9px] bg-rose-950 text-rose-400 font-bold px-1.5 py-0.2 rounded border border-rose-800">
                        محظور 🔒
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-500">
                      الكود: <span className="font-mono text-slate-400">{sub.code}</span> • {sub.localityName}
                    </div>
                    <div className="text-[10px] text-amber-400/90 flex items-center gap-1 pt-0.5">
                      <Lock className="w-3 h-3 text-amber-400" />
                      <span>يتطلب دور إداري أعلى أو إذن جغرافي</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================== محتوى التبويب 3: سجل المشاريع الإغاثية الشامل ==================== */}
      {activeTab === 'projects' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between pb-1 border-b border-slate-800">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <FolderKanban className="w-4 h-4 text-indigo-400" />
              <span>سجل المشاريع الإغاثية ومؤشرات الصرف للمناطق المصرحة</span>
            </h4>
            <span className="text-xs text-slate-400 font-mono">
              {authorizedProjects.length} مشاريع معتمدة
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {authorizedProjects.map(p => {
              const target = p.targetBeneficiaries || (p.deliveredCount + p.candidatesCount) || 1;
              const progress = Math.min(100, Math.round((p.deliveredCount / target) * 100));

              return (
                <div key={p.projectNumber} className="p-4 rounded-3xl bg-slate-900 border border-slate-800 hover:border-indigo-500/50 transition space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] bg-slate-800 text-indigo-300 font-mono px-2 py-0.5 rounded font-bold border border-slate-700">
                        {p.projectNumber}
                      </span>
                      <h5 className="font-bold text-white text-sm mt-1">{p.projectName}</h5>
                      <span className="text-xs text-emerald-400 font-medium">{p.aidTypeName} ({p.aidValue} ₪)</span>
                    </div>

                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      p.status === 'جاري الصرف' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' :
                      p.status === 'قيد الترشيح' ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40' :
                      'bg-slate-800 text-slate-300'
                    }`}>
                      {p.status}
                    </span>
                  </div>

                  {/* Progress */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">إنجاز المستفيدين:</span>
                      <span className="font-mono text-white font-bold">{p.deliveredCount} من {target} ({progress}%)</span>
                    </div>
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div className="bg-gradient-to-r from-indigo-500 to-emerald-500 h-full rounded-full" style={{ width: `${progress}%` }} />
                    </div>
                  </div>

                  {/* Warehouse & Funding */}
                  <div className="pt-1 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="truncate">المستودع: <strong className="text-slate-200">{p.warehouse}</strong></span>
                    <span className="shrink-0 text-slate-500">{p.fundingOrg}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ==================== محتوى التبويب 4: سجل المستفيدين والأسر والمساعدات المفصل ==================== */}
      {activeTab === 'families' && (
        <div className="space-y-3">
          {/* Filters Bar */}
          <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
            {/* Search */}
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 absolute right-3 top-2.5 text-slate-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="بحث بالاسم، الهوية، الجوال، المسجد..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Filter by Area */}
            <div className="flex items-center gap-1.5 flex-wrap">
              <select
                value={selectedSubAreaFilter}
                onChange={(e) => setSelectedSubAreaFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-xs rounded-xl px-2.5 py-2 text-slate-200 focus:outline-none"
              >
                <option value="all">كافة المناطق المصرحة ({authorizedSubAreas.length})</option>
                {authorizedSubAreas.map(s => (
                  <option key={s.id} value={s.name}>{s.name}</option>
                ))}
              </select>

              <select
                value={selectedResidentFilter}
                onChange={(e) => setSelectedResidentFilter(e.target.value as any)}
                className="bg-slate-950 border border-slate-800 text-xs rounded-xl px-2.5 py-2 text-slate-200 focus:outline-none"
              >
                <option value="all">الإقامة: الكل</option>
                <option value="مقيم">مقيم فقط</option>
                <option value="نازح">نازح فقط</option>
              </select>

              <select
                value={selectedDevFilter}
                onChange={(e) => setSelectedDevFilter(e.target.value as any)}
                className="bg-slate-950 border border-slate-800 text-xs rounded-xl px-2.5 py-2 text-slate-200 focus:outline-none"
              >
                <option value="all">التنمية: الكل</option>
                <option value="معتمد">معتمد فقط</option>
                <option value="حجب اعتماد">حجب اعتماد</option>
                <option value="مجمد">مجمد</option>
              </select>
            </div>
          </div>

          {/* Families Table */}
          <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-900 max-h-96">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 sticky top-0 z-10">
                <tr>
                  <th className="p-3">رقم الهوية</th>
                  <th className="p-3">اسم رب الأسرة</th>
                  <th className="p-3">المنطقة الفرعية</th>
                  <th className="p-3">اعتماد التنمية</th>
                  <th className="p-3">الإقامة</th>
                  <th className="p-3">الأفراد</th>
                  <th className="p-3">آخر مساعدة مستلمة</th>
                  <th className="p-3">تاريخ الصرف</th>
                  <th className="p-3">الجوال</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-200">
                {filteredFamiliesTable.slice(0, 100).map((f) => (
                  <tr key={f.familyID} className="hover:bg-slate-850/50 transition">
                    <td className="p-3 font-mono text-emerald-400 font-bold">{f.nationalID}</td>
                    <td className="p-3 font-bold text-white">{f.name}</td>
                    <td className="p-3 text-sky-300">{f.currentSubArea}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                        f.developmentApproval === 'معتمد' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                      }`}>
                        {f.developmentApproval}
                      </span>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                        f.residentStatus === 'مقيم' ? 'bg-sky-500/20 text-sky-300' : 'bg-amber-500/20 text-amber-300'
                      }`}>
                        {f.residentStatus}
                      </span>
                    </td>
                    <td className="p-3 font-mono">{f.membersCount}</td>
                    <td className="p-3 truncate max-w-[140px] text-slate-300">{f.lastAidType || 'طرد غذائي أساسي'}</td>
                    <td className="p-3 font-mono text-slate-400 text-[11px]">{f.lastAidDate || '2024-11-10'}</td>
                    <td className="p-3 font-mono text-slate-400 text-[11px]">{f.primaryPhone}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================== محتوى التبويب 5: مركز التقارير الرسمية والتصدير ==================== */}
      {activeTab === 'reports' && (
        <div className="space-y-4">
          <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>التقارير الإدارية والتصدير المعتمد</span>
            </h4>
            <p className="text-xs text-slate-400">
              توليد وتحميل تقارير شاملة ومطابقة حسب النطاق الجغرافي المصرح لحسابك ({currentUser?.fullName})
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <button
                type="button"
                onClick={handleExportFullSystemExcel}
                className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/80 to-slate-900 border border-emerald-500/40 hover:border-emerald-400 text-right space-y-2 transition group"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <Download className="w-5 h-5" />
                </div>
                <h5 className="font-bold text-white text-xs sm:text-sm">تقرير القيادة الشامل (Excel 3 أوراق)</h5>
                <p className="text-[11px] text-slate-400">يتضمن إحصائيات المناطق، سجل المشاريع، وسجل الأسر المصرحة.</p>
              </button>

              {onOpenExcelAudit && (
                <button
                  type="button"
                  onClick={onOpenExcelAudit}
                  className="p-4 rounded-2xl bg-gradient-to-r from-teal-950/80 to-slate-900 border border-teal-500/40 hover:border-teal-400 text-right space-y-2 transition group"
                >
                  <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <h5 className="font-bold text-white text-xs sm:text-sm">فاحص كشوفات الإكسل (3 شيتات)</h5>
                  <p className="text-[11px] text-slate-400">فحص هويات المواطنين من الجوال مع تقييد الصلاحيات الجغرافية.</p>
                </button>
              )}

              <button
                type="button"
                onClick={() => window.print()}
                className="p-4 rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950/50 border border-slate-700 hover:border-indigo-400 text-right space-y-2 transition group"
              >
                <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
                  <Printer className="w-5 h-5" />
                </div>
                <h5 className="font-bold text-white text-xs sm:text-sm">طباعة ملخص القيادة التنفيذي</h5>
                <p className="text-[11px] text-slate-400">تجهيز مستند PDF رسمي للطباعة والأرشفة الورقية المعتمدة.</p>
              </button>
            </div>

            {/* Palestinian Ministry Official Printable Executive Layout */}
            <div className="p-5 sm:p-6 rounded-3xl bg-slate-950 border-2 border-slate-800 space-y-4 print:bg-white print:text-black print:border-none print:p-0">
              {/* Header */}
              <div className="flex items-start justify-between border-b-2 border-emerald-500/60 pb-3 text-right">
                <div className="space-y-1">
                  <div className="text-[11px] text-slate-400 font-bold">دولة فلسطين - السلطة الوطنية الفلسطينية</div>
                  <div className="text-sm font-black text-white">وزارة التنمية الاجتماعية - الإدارة العامة للمساعدات الإنسانية</div>
                  <div className="text-xs text-emerald-400 font-bold">نظام السجل الموحد لإدارة وتوزيع المساعدات والإغاثة الميدانية</div>
                </div>
                <div className="text-left space-y-0.5 text-xs text-slate-400 font-mono">
                  <div>كود التقرير: <strong className="text-white">REP-{Date.now().toString().slice(-6)}</strong></div>
                  <div>التاريخ: <strong className="text-white">{new Date().toISOString().slice(0, 10)}</strong></div>
                  <div>المستخدم: <strong className="text-emerald-400">{currentUser?.fullName}</strong></div>
                  <div className="text-[10px] text-indigo-300">نطاق الصلاحيات: {userAllowedAreas.join('، ')}</div>
                </div>
              </div>

              {/* Title Badge */}
              <div className="text-center py-2.5 bg-slate-900 rounded-2xl border border-slate-800">
                <h3 className="text-sm sm:text-base font-black text-white">
                  تقرير القيادة التنفيذي الشامل لكافة البيانات والمساعدات والمشاريع والمناطق
                </h3>
                <span className="text-[11px] text-emerald-400">
                  مستخرج رسمي معتمد طبقاً للصلاحيات الممنوحة لحساب: ({currentUser?.roleName})
                </span>
              </div>

              {/* Summary Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">الأسر المشمولة:</span>
                  <span className="font-black text-white text-sm sm:text-base font-mono">{kpis.totalFamilies.toLocaleString('ar-EG')} أسرة</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">المساعدات المنفذة:</span>
                  <span className="font-black text-emerald-400 text-sm sm:text-base font-mono">{kpis.totalDeliveredCount.toLocaleString('ar-EG')} طرد</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">القيمة الإجمالية:</span>
                  <span className="font-black text-amber-400 text-sm sm:text-base font-mono">{kpis.totalDeliveredValue.toLocaleString('ar-EG')} ₪</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800">
                  <span className="text-slate-400 text-[10px] block">نسبة الإنجاز:</span>
                  <span className="font-black text-sky-400 text-sm sm:text-base font-mono">{kpis.quotaAchievementPct}%</span>
                </div>
              </div>

              {/* Signatures */}
              <div className="pt-4 border-t border-slate-800 grid grid-cols-3 gap-3 text-center text-xs text-slate-300">
                <div className="space-y-4">
                  <span className="font-bold block text-[11px]">إعداد وتدقيق الباحث الميداني</span>
                  <div className="h-6 border-b border-dashed border-slate-700"></div>
                  <span className="text-[9.5px] text-slate-500">التوقيع والتاريخ</span>
                </div>
                <div className="space-y-4">
                  <span className="font-bold block text-[11px]">مسؤول النطاق الجغرافي والترشيح</span>
                  <div className="h-6 border-b border-dashed border-slate-700"></div>
                  <span className="text-[9.5px] text-slate-500">التوقيع والتاريخ</span>
                </div>
                <div className="space-y-4">
                  <span className="font-bold block text-[11px]">اعتماد المدير العام للإغاثة والتنمية</span>
                  <div className="h-6 border-b border-dashed border-slate-700"></div>
                  <span className="text-[9.5px] text-slate-500">الختم والتوقيع الرسمي</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== محتوى التبويب 6: مستكشف الصلاحيات الجغرافية والأمنية ==================== */}
      {activeTab === 'geo_permissions' && (
        <div className="space-y-4">
          <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-indigo-400" />
                <div>
                  <h4 className="font-bold text-sm text-white">مصفوفة الصلاحيات الجغرافية والأمنية للأدوار والمستخدمين</h4>
                  <p className="text-xs text-slate-400">توزيع الصلاحيات على المحليات الـ 5 وضوابط فحص ملفات الإكسل</p>
                </div>
              </div>
              <span className="text-xs bg-indigo-500/20 text-indigo-300 font-bold px-2.5 py-1 rounded-full border border-indigo-500/30">
                قواعد الوصول المبنية على الأدوار والمناطق
              </span>
            </div>

            {/* Matrix Table */}
            <div className="overflow-x-auto rounded-2xl border border-slate-800 bg-slate-950">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-900 text-slate-300 border-b border-slate-800 font-bold">
                  <tr>
                    <th className="p-3">الدور / المستخدم</th>
                    <th className="p-3">نوع الصلاحية</th>
                    {subAreasList.map(s => (
                      <th key={s.id} className="p-3 text-center">{s.name}</th>
                    ))}
                    <th className="p-3 text-center">فحص كشوفات إكسل</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-300">
                  {usersList.map(u => {
                    const isCurrent = currentUser?.id === u.id;
                    const hasAll = u.allowedViewSubAreas?.includes('*');
                    return (
                      <tr key={u.id} className={`transition ${isCurrent ? 'bg-indigo-950/40 font-bold text-white ring-1 ring-indigo-500/50' : 'hover:bg-slate-900/50'}`}>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            {isCurrent && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>}
                            <span>{u.fullName}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 block">{u.roleName}</span>
                        </td>
                        <td className="p-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${hasAll ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'}`}>
                            {hasAll ? 'شامل كافة المناطق (*)' : `مقيد (${u.allowedViewSubAreas?.length} مناطق)`}
                          </span>
                        </td>
                        {subAreasList.map(s => {
                          const isAllowed = hasAll || u.allowedViewSubAreas?.includes(s.name);
                          return (
                            <td key={s.id} className="p-3 text-center">
                              {isAllowed ? (
                                <span className="inline-flex items-center gap-1 text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full text-[10px] font-bold">
                                  <CheckCircle2 className="w-3 h-3" />
                                  <span>مصرح</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded-full text-[10px]">
                                  <Lock className="w-3 h-3 text-rose-500" />
                                  <span>محجوب</span>
                                </span>
                              )}
                            </td>
                          );
                        })}
                        <td className="p-3 text-center">
                          <span className="text-[10px] text-emerald-300 font-bold">
                            {hasAll ? 'كافة المناطق 3 شيتات' : 'مقيّد بمناطقه 3 شيتات'}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
