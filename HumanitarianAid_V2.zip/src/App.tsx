import React, { useState } from 'react';
import { AndroidEmulator } from './components/AndroidEmulator';
import { CodeExplorer } from './components/CodeExplorer';
import { BuildGuide } from './components/BuildGuide';
import { NominationVisualizer } from './components/NominationVisualizer';
import { AdminDashboard } from './components/AdminDashboard';
import { ComprehensiveSystemDisplayHub } from './components/ComprehensiveSystemDisplayHub';
import { ExcelIdAuditModal } from './components/ExcelIdAuditModal';
import { DataLinkingSyncModal } from './components/DataLinkingSyncModal';
import { downloadAndroidProjectZip } from './utils/zipDownloader';
import {
  INITIAL_FAMILIES,
  MOCK_CHILDREN,
  INITIAL_DELIVERY_RECORDS,
  INITIAL_DELIVERY_PROJECTS,
  MockFamily,
  DeliveryRecord,
  MockChild
} from './components/AndroidEmulator';
import { INITIAL_SUB_AREAS_DATA } from './types/subAreaService';
import {
  SystemRole,
  INITIAL_SYSTEM_ROLES,
  MockUser,
  INITIAL_USERS,
  AuditLog,
  INITIAL_AUDIT_LOGS
} from './types/adminSecurity';
import {
  Download,
  Smartphone,
  Code2,
  BookOpen,
  CheckCircle,
  ShieldCheck,
  Cpu,
  Layers,
  Sparkles,
  GitBranch,
  ShieldAlert,
  Sliders,
  Users,
  FileSpreadsheet,
  LayoutDashboard,
  BarChart3,
  Monitor,
  CloudLightning
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'hub' | 'emulator' | 'admin' | 'visualizer' | 'code' | 'guide'>('hub');
  const [downloading, setDownloading] = useState(false);
  const [excelAuditModalOpen, setExcelAuditModalOpen] = useState<boolean>(false);
  const [dataLinkingModalOpen, setDataLinkingModalOpen] = useState<boolean>(false);

  // Central state for Real Beneficiary Families, Deliveries & Children synced across Hub & Mobile
  const [familiesList, setFamiliesList] = useState<MockFamily[]>(INITIAL_FAMILIES);
  const [deliveryRecords, setDeliveryRecords] = useState<DeliveryRecord[]>(INITIAL_DELIVERY_RECORDS);
  const [childrenList, setChildrenList] = useState<MockChild[]>(MOCK_CHILDREN);

  // Shared state between Admin Dashboard and Mobile Android Emulator
  const [rolesList, setRolesList] = useState<SystemRole[]>(INITIAL_SYSTEM_ROLES);
  const [usersList, setUsersList] = useState<MockUser[]>(INITIAL_USERS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [selectedEmulatorUser, setSelectedEmulatorUser] = useState<string>('admin');

  const handleDownload = async () => {
    try {
      setDownloading(true);
      await downloadAndroidProjectZip();
    } catch (err) {
      console.error(err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30">
      {/* Top Application Header */}
      <header className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
          
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-slate-950 shadow-md shadow-emerald-500/20 font-bold">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-white">
                  نظام إدارة المساعدات الإنسانية
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Android Native • Kotlin
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                مشروع أندرويد نيتف كامل وجاهز للبناء إلى APK في Android Studio
              </p>
            </div>
          </div>

          {/* Download Action & Quick Stats */}
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <button
              onClick={() => setDataLinkingModalOpen(true)}
              className="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 via-indigo-600 to-sky-700 hover:from-sky-500 hover:to-indigo-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-sky-950/40 flex items-center gap-2 transition transform active:scale-95 border border-sky-400/40"
              title="ربط ومزامنة البيانات الحقيقية بالجملة من الجوال والداخلي والسحابي"
            >
              <CloudLightning className="w-4 h-4 text-sky-200 animate-pulse" />
              <span>ربط ومزامنة البيانات ⚡ (جوال / داخلي / سحابي)</span>
            </button>

            <button
              onClick={() => setExcelAuditModalOpen(true)}
              className="px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-teal-600 via-emerald-600 to-teal-700 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-teal-950/40 flex items-center gap-2 transition transform active:scale-95 border border-emerald-400/40"
              title="فحص ومطابقة ملف إكسل الهويات من الجوال مع قاعدة النظام وتوليد التقرير الثلاثي"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-100" />
              <span>فحص إكسل الهويات من الجوال (3 شيتات) 📱</span>
            </button>

            <button
              onClick={handleDownload}
              disabled={downloading}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white font-bold text-xs sm:text-sm shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition transform active:scale-95 disabled:opacity-50"
            >
              <Download className={`w-4 h-4 ${downloading ? 'animate-bounce' : ''}`} />
              <span>{downloading ? 'جاري تجهيز الـ ZIP...' : 'تحميل مشروع Android Studio (ZIP)'}</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex gap-2 border-t border-slate-800/60 pt-1 pb-1 overflow-x-auto">
          <button
            onClick={() => setActiveTab('hub')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition shrink-0 relative ${
              activeTab === 'hub'
                ? 'bg-gradient-to-r from-emerald-950/90 to-indigo-950/90 text-emerald-300 border-2 border-emerald-500/70 shadow-lg shadow-emerald-950/50'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 text-emerald-400" />
            <span>شاشة العرض الموسعة والتقارير الشاملة (Command Center)</span>
            <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
              كافة البيانات والمشاريع والمناطق 🌐
            </span>
          </button>

          <button
            onClick={() => setActiveTab('emulator')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition shrink-0 relative ${
              activeTab === 'emulator'
                ? 'bg-emerald-950/70 text-emerald-300 border border-emerald-500/60 shadow-lg shadow-emerald-950/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <span>معاينة التطبيق الكامل (Live App Preview)</span>
            <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-1.5 py-0.2 rounded border border-emerald-500/30">
              كافة الشاشات والمناطق الـ 5
            </span>
          </button>

          <button
            onClick={() => setActiveTab('admin')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition shrink-0 relative ${
              activeTab === 'admin'
                ? 'bg-indigo-900/60 text-indigo-300 border border-indigo-500/50 shadow'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <ShieldAlert className="w-4 h-4 text-indigo-400" />
            <span>لوحة التحكم الإدارية والرسوم البيانية (Admin Dashboard)</span>
            <span className="bg-indigo-500/20 text-indigo-300 text-[10px] font-bold px-1.5 py-0.2 rounded border border-indigo-500/30">
              الرسوم البيانية والصلاحيات
            </span>
          </button>

          <button
            onClick={() => setActiveTab('visualizer')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition shrink-0 relative ${
              activeTab === 'visualizer'
                ? 'bg-slate-800 text-emerald-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <GitBranch className="w-4 h-4 text-emerald-400" />
            <span>استوديو وتصوير آلية الترشيح (Nomination Visualizer)</span>
            <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-1.5 py-0.2 rounded border border-emerald-500/30">
              الخوارزمية
            </span>
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'code'
                ? 'bg-slate-800 text-emerald-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>متصفح ملفات وأكواد Kotlin و Room</span>
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'guide'
                ? 'bg-slate-800 text-emerald-400 border border-slate-700'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>دليل البناء إلى APK</span>
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {/* Banner with Architecture badges */}
        <div className="mb-4 p-3 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>حزمة التطبيق الرسمية: <code className="text-emerald-300 font-mono">com.humanitarian.aidmanagement</code></span>
          </div>
          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span>• Kotlin 2.0</span>
            <span>• Jetpack Compose Material 3</span>
            <span>• Room SQLite Database (13 Tables)</span>
            <span>• RTL Direction</span>
          </div>
        </div>

        {/* Tab: Comprehensive System Display Hub & Detailed Visual Analytics (شاشة العرض الموسعة والمتطورة) */}
        {activeTab === 'hub' && (
          <ComprehensiveSystemDisplayHub
            currentUser={usersList.find(u => u.username === selectedEmulatorUser) || usersList[0]}
            usersList={usersList}
            onSelectUser={(u) => setSelectedEmulatorUser(u.username)}
            familiesList={familiesList}
            childrenList={childrenList}
            deliveryRecords={deliveryRecords}
            comprehensiveProjectsList={INITIAL_DELIVERY_PROJECTS as any}
            subAreasList={INITIAL_SUB_AREAS_DATA}
            onOpenExcelAudit={() => setExcelAuditModalOpen(true)}
            onOpenDataLinking={() => setDataLinkingModalOpen(true)}
            onNavigateToScreen={() => setActiveTab('emulator')}
          />
        )}

        {/* Tab 0: Admin Dashboard */}
        {activeTab === 'admin' && (
          <AdminDashboard
            rolesList={rolesList}
            onUpdateRoles={setRolesList}
            usersList={usersList}
            onUpdateUsers={setUsersList}
            auditLogs={auditLogs}
            onAddAuditLog={(newLog) => setAuditLogs(prev => [{ ...newLog, id: `LOG-${Date.now().toString().slice(-4)}` }, ...prev])}
            onOpenEmulatorWithUser={(uname) => {
              setSelectedEmulatorUser(uname);
              setActiveTab('emulator');
            }}
          />
        )}

        {/* Tab 1: Live Interactive Emulator */}
        {activeTab === 'emulator' && (
          <div className="space-y-4">
            <div className="text-center max-w-xl mx-auto space-y-1">
              <h2 className="text-lg font-bold text-white">محاكي واجهات نظام إدارة المساعدات الإنسانية</h2>
              <p className="text-xs text-slate-400">
                يمكنك التفاعل مع كامل وظائف التطبيق، فحص محرك الترشيح، واختبار قفل الحساب، وتصفية الأسر وحصص المحليات مباشرة أدناه:
              </p>
            </div>
            <AndroidEmulator
              externalUsersList={usersList}
              onUpdateUsersList={setUsersList}
              externalRolesList={rolesList}
              onUpdateRolesList={setRolesList}
              externalAuditLogs={auditLogs}
              onAddAuditLog={(newLog) => setAuditLogs(prev => [{ ...newLog, id: `LOG-${Date.now().toString().slice(-4)}` }, ...prev])}
              initialSelectedUsername={selectedEmulatorUser}
              externalFamiliesList={familiesList}
              onUpdateFamiliesList={setFamiliesList}
              externalDeliveryRecords={deliveryRecords}
              onUpdateDeliveryRecords={setDeliveryRecords}
              externalChildrenList={childrenList}
              onUpdateChildrenList={setChildrenList}
            />
          </div>
        )}

        {/* Tab 2: Visualizer Studio */}
        {activeTab === 'visualizer' && (
          <NominationVisualizer />
        )}

        {/* Tab 3: Code Explorer */}
        {activeTab === 'code' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-lg font-bold text-white">أكواد مشروع Android Studio (Kotlin & Gradle)</h2>
                <p className="text-xs text-slate-400">
                  جميع الملفات مكتوبة بهيكلية Clean Architecture مع Room Entities و DAOs ومحرك الترشيح NominationEngine.
                </p>
              </div>
              <button
                onClick={handleDownload}
                className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تحميل الكل كـ ZIP</span>
              </button>
            </div>
            <CodeExplorer />
          </div>
        )}

        {/* Tab 3: Build Guide */}
        {activeTab === 'guide' && <BuildGuide />}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-900 bg-slate-950/80 p-4 text-center text-xs text-slate-500">
        نظام إدارة المساعدات الإنسانية • Android Native Kotlin & Jetpack Compose • خوارزميات الترشيح الميداني والأولوية المركبة
      </footer>

      {/* Modal: National ID Excel Multi-Sheet Verification with Geographic Permissions */}
      <ExcelIdAuditModal
        isOpen={excelAuditModalOpen}
        onClose={() => setExcelAuditModalOpen(false)}
        familiesList={familiesList}
        familyBenefitStore={{}}
        deliveryRecords={deliveryRecords}
        currentUser={usersList.find(u => u.username === selectedEmulatorUser) || usersList[0]}
        usersList={usersList}
        onSelectUser={(u) => setSelectedEmulatorUser(u.username)}
        onAddAuditLog={(action, status, details) => {
          setAuditLogs(prev => [
            {
              id: `LOG-${Date.now().toString().slice(-4)}`,
              userId: 1,
              username: selectedEmulatorUser,
              action,
              timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
              ip: '192.168.1.10',
              device: 'Executive Web Hub',
              status,
              details
            },
            ...prev
          ]);
        }}
      />

      {/* Modal: Bulk Data Linking & Cloud Sync Hub (ربط ومزامنة البيانات الحقيقية من الجوال والداخلي والسحابي) */}
      <DataLinkingSyncModal
        isOpen={dataLinkingModalOpen}
        onClose={() => setDataLinkingModalOpen(false)}
        currentFamilies={familiesList}
        currentDeliveries={deliveryRecords}
        currentChildren={childrenList}
        currentUser={usersList.find(u => u.username === selectedEmulatorUser) || usersList[0]}
        onApplyLinkedData={(updatedFamilies, updatedDeliveries, updatedChildren, report) => {
          setFamiliesList(updatedFamilies);
          setDeliveryRecords(updatedDeliveries);
          if (updatedChildren) setChildrenList(updatedChildren);
        }}
        onAddAuditLog={(action, status, details) => {
          setAuditLogs(prev => [
            {
              id: `LOG-${Date.now().toString().slice(-4)}`,
              userId: 1,
              username: selectedEmulatorUser,
              action,
              timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
              ip: '192.168.1.10',
              device: 'Executive Web & Cloud Hub',
              status,
              details
            },
            ...prev
          ]);
        }}
      />
    </div>
  );
}
