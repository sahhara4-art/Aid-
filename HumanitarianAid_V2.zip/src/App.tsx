import React, { useState } from 'react';
import { AndroidEmulator } from './components/AndroidEmulator';
import { CodeExplorer } from './components/CodeExplorer';
import { BuildGuide } from './components/BuildGuide';
import { NominationVisualizer } from './components/NominationVisualizer';
import { AdminDashboard } from './components/AdminDashboard';
import { ComprehensiveSystemDisplayHub } from './components/ComprehensiveSystemDisplayHub';
import { ExcelIdAuditModal } from './components/ExcelIdAuditModal';
import { DataLinkingSyncModal } from './components/DataLinkingSyncModal';
import { ExcelHubModal } from './components/ExcelHubModal';
import { GeographicDistributionMap } from './components/GeographicDistributionMap';
import { downloadAndroidProjectZip } from './utils/zipDownloader';
import {
  INITIAL_FAMILIES,
  MOCK_CHILDREN,
  INITIAL_DELIVERY_RECORDS,
  INITIAL_DELIVERY_PROJECTS,
  MockFamily,
  DeliveryRecord,
  MockChild
} from './components/AndroidEmulator';
import { INITIAL_SUB_AREAS_DATA } from './types/subAreaService';
import {
  SystemRole,
  INITIAL_SYSTEM_ROLES,
  MockUser,
  INITIAL_USERS,
  AuditLog,
  INITIAL_AUDIT_LOGS
} from './types/adminSecurity';
import {
  Download,
  Smartphone,
  Code2,
  BookOpen,
  CheckCircle,
  ShieldCheck,
  Cpu,
  Layers,
  Sparkles,
  GitBranch,
  ShieldAlert,
  Sliders,
  Users,
  FileSpreadsheet,
  LayoutDashboard,
  BarChart3,
  Monitor,
  CloudLightning,
  Calendar,
  Upload,
  Compass
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'hub' | 'map' | 'emulator' | 'admin' | 'visualizer' | 'code' | 'guide'>('hub');
  const [downloading, setDownloading] = useState(false);
  const [excelAuditModalOpen, setExcelAuditModalOpen] = useState<boolean>(false);
  const [dataLinkingModalOpen, setDataLinkingModalOpen] = useState<boolean>(false);
  const [excelHubModalOpen, setExcelHubModalOpen] = useState<boolean>(false);

  // Central state for Real Beneficiary Families, Deliveries & Children synced across Hub & Mobile
  const [familiesList, setFamiliesList] = useState<MockFamily[]>(INITIAL_FAMILIES);
  const [deliveryRecords, setDeliveryRecords] = useState<DeliveryRecord[]>(INITIAL_DELIVERY_RECORDS);
  const [childrenList, setChildrenList] = useState<MockChild[]>(MOCK_CHILDREN);

  // Shared state between Admin Dashboard and Mobile Android Emulator
  const [rolesList, setRolesList] = useState<SystemRole[]>(INITIAL_SYSTEM_ROLES);
  const [usersList, setUsersList] = useState<MockUser[]>(INITIAL_USERS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [selectedEmulatorUser, setSelectedEmulatorUser] = useState<string>('admin');

  const handleDownload = async () => {
    try {
      setDownloading(true);
      await downloadAndroidProjectZip();
    } catch (err) {
      console.error(err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col font-sans selection:bg-emerald-500/20">
      
      {/* شريط العلم الفلسطيني الوطني العلوي */}
      <div className="w-full h-1.5 flex sticky top-0 z-50">
        <div className="w-1/3 bg-black"></div>
        <div className="w-1/3 bg-white border-t border-b border-slate-200"></div>
        <div className="w-1/3 bg-emerald-600"></div>
        <div className="w-20 bg-red-600"></div>
      </div>

      {/* ترويسة التطبيق بالستايل الفاتح العصري مع البصمة الوطنية */}
      <header className="sticky top-1.5 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
          
          {/* عنوان المنظومة */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              Aid
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-slate-900">
                  نظام إدارة وتوزيع المساعدات الإنسانية
                </h1>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                  Android Native • Kotlin
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                منظومة إدارة المستفيدين والمشاريع • تطبيق أندرويد نيتف (Jetpack Compose & Room)
              </p>
            </div>
          </div>

          {/* أزرار العمليات السريعة والتصدير والاستيراد */}
          <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap">
            {/* زر منظومة الإكسل المتقدمة (تصدير فترة محددة + رفع واستيراد الأسر والمساعدات والأبناء) */}
            <button
              onClick={() => setExcelHubModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm shadow-md flex items-center gap-2 transition transform active:scale-95 border border-emerald-800"
              title="تصدير كشف إكسل بفترة زمنية محددة أو رفع واستيراد ملفات الأسر والمساعدات والأبناء"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
              <span>استيراد وتصدير إكسل 📊 (فترات محددة • رفع الأسر والمساعدات)</span>
            </button>

            <button
              onClick={() => setDataLinkingModalOpen(true)}
              className="px-3 py-2 rounded-xl bg-sky-700 hover:bg-sky-600 text-white font-bold text-xs sm:text-sm shadow-sm flex items-center gap-1.5 transition transform active:scale-95"
              title="ربط ومزامنة البيانات الحقيقية بالجملة من الجوال والداخلي والسحابي"
            >
              <CloudLightning className="w-4 h-4 text-sky-200" />
              <span>مزامنة البيانات ⚡</span>
            </button>

            <button
              onClick={() => setExcelAuditModalOpen(true)}
              className="px-3 py-2 rounded-xl bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs sm:text-sm shadow-sm flex items-center gap-1.5 transition transform active:scale-95"
              title="فحص ومطابقة ملف إكسل الهويات من الجوال"
            >
              <Smartphone className="w-4 h-4 text-slate-300" />
              <span>فحص إكسل الجوال 📱</span>
            </button>

            <button
              onClick={handleDownload}
              disabled={downloading}
              className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs sm:text-sm shadow-md flex items-center gap-2 transition transform active:scale-95 disabled:opacity-50"
            >
              <Download className={`w-4 h-4 ${downloading ? 'animate-bounce' : ''}`} />
              <span>{downloading ? 'جاري تجهيز الـ ZIP...' : 'تحميل مشروع Android Studio (ZIP)'}</span>
            </button>
          </div>
        </div>

        {/* شريط التبويبات الفاتح العصري */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex gap-1.5 border-t border-slate-200 pt-1.5 pb-1.5 overflow-x-auto bg-slate-50/70">
          <button
            onClick={() => setActiveTab('hub')}
            className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'hub'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>لوحة المؤشرات والتقارير الشاملة (Command Center)</span>
            <span className="bg-emerald-800/40 text-emerald-100 text-[10px] px-2 py-0.5 rounded-full font-bold">
              كافة البيانات 🌐
            </span>
          </button>

          <button
            onClick={() => setActiveTab('map')}
            className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'map'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <Compass className="w-4 h-4" />
            <span>خريطة التوزيع الجغرافي (Gaza Geo Map)</span>
            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.2 rounded border border-emerald-200">
              المناطق الـ 5 🇵🇸
            </span>
          </button>

          <button
            onClick={() => setActiveTab('emulator')}
            className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'emulator'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>معاينة تطبيق الجوال (Live App Preview)</span>
            <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.2 rounded border border-emerald-200">
              المناطق الـ 5
            </span>
          </button>

          <button
            onClick={() => setActiveTab('admin')}
            className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'admin'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <ShieldAlert className="w-4 h-4" />
            <span>لوحة التحكم الإدارية والصلاحيات التفصيلية (Admin Security)</span>
            <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-1.5 py-0.2 rounded border border-amber-200">
              المجموعات والشاشات
            </span>
          </button>

          <button
            onClick={() => setActiveTab('visualizer')}
            className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'visualizer'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <GitBranch className="w-4 h-4" />
            <span>محرك الترشيح والمفاضلة (Nomination Visualizer)</span>
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'code'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>متصفح ملفات وأكواد Kotlin و Room</span>
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-bold flex items-center gap-2 transition shrink-0 ${
              activeTab === 'guide'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>دليل البناء واستخراج الـ APK</span>
          </button>
        </div>
      </header>

      {/* الجسم الرئيسي للتطبيق */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {activeTab === 'hub' && (
          <ComprehensiveSystemDisplayHub
            families={familiesList}
            deliveries={deliveryRecords}
            childrenList={childrenList}
            users={usersList}
            roles={rolesList}
            onOpenExcelHub={() => setExcelHubModalOpen(true)}
          />
        )}

        {activeTab === 'map' && (
          <GeographicDistributionMap
            familiesList={familiesList}
            deliveryRecords={deliveryRecords}
            childrenList={childrenList}
            currentUser={usersList.find(u => u.username === selectedEmulatorUser) || usersList[0]}
          />
        )}

        {activeTab === 'emulator' && (
          <AndroidEmulator
            familiesList={familiesList}
            setFamiliesList={setFamiliesList}
            deliveryRecords={deliveryRecords}
            setDeliveryRecords={setDeliveryRecords}
            childrenList={childrenList}
            setChildrenList={setChildrenList}
            currentUser={usersList.find(u => u.username === selectedEmulatorUser) || usersList[0]}
            rolesList={rolesList}
            usersList={usersList}
            onOpenExcelHub={() => setExcelHubModalOpen(true)}
          />
        )}

        {activeTab === 'admin' && (
          <AdminDashboard
            roles={rolesList}
            setRoles={setRolesList}
            users={usersList}
            setUsers={setUsersList}
            auditLogs={auditLogs}
            setAuditLogs={setAuditLogs}
            selectedEmulatorUser={selectedEmulatorUser}
            setSelectedEmulatorUser={setSelectedEmulatorUser}
            onOpenExcelHub={() => setExcelHubModalOpen(true)}
          />
        )}

        {activeTab === 'visualizer' && (
          <NominationVisualizer />
        )}

        {activeTab === 'code' && (
          <CodeExplorer />
        )}

        {activeTab === 'guide' && (
          <BuildGuide onDownloadZip={handleDownload} isDownloading={downloading} />
        )}
      </main>

      {/* ==================== النوافذ التفاعلية (Modals) ==================== */}

      {/* 1. النافذة المتقدمة لتبادل ملفات الإكسل (فترات محددة + رفع واستيراد الأسر والمساعدات والأبناء) */}
      <ExcelHubModal
        isOpen={excelHubModalOpen}
        onClose={() => setExcelHubModalOpen(false)}
        familiesList={familiesList}
        setFamiliesList={setFamiliesList}
        deliveryRecords={deliveryRecords}
        setDeliveryRecords={setDeliveryRecords}
        childrenList={childrenList}
        setChildrenList={setChildrenList}
      />

      {/* 2. نافذة فحص ومطابقة إكسل الهويات من الجوال */}
      <ExcelIdAuditModal
        isOpen={excelAuditModalOpen}
        onClose={() => setExcelAuditModalOpen(false)}
        systemFamilies={familiesList}
        systemDeliveries={deliveryRecords}
        systemChildren={childrenList}
      />

      {/* 3. نافذة ربط ومزامنة البيانات الحقيقية من الجوال والسحابي */}
      <DataLinkingSyncModal
        isOpen={dataLinkingModalOpen}
        onClose={() => setDataLinkingModalOpen(false)}
        currentFamilies={familiesList}
        currentDeliveries={deliveryRecords}
        currentChildren={childrenList}
        currentUser={usersList.find(u => u.username === selectedEmulatorUser) || usersList[0]}
        onApplyLinkedData={(updatedFamilies, updatedDeliveries, updatedChildren) => {
          setFamiliesList(updatedFamilies);
          setDeliveryRecords(updatedDeliveries);
          if (updatedChildren) setChildrenList(updatedChildren);
        }}
        onAddAuditLog={(action, status, details) => {
          setAuditLogs(prev => [
            {
              id: `LOG-${Date.now().toString().slice(-4)}`,
              userId: 1,
              username: selectedEmulatorUser,
              action,
              timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
              ip: '192.168.1.10',
              device: 'Executive Web Hub',
              status,
              details
            },
            ...prev
          ]);
        }}
      />
    </div>
  );
}
