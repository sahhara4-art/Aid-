import * as XLSX from 'xlsx';
import { MockFamily, MockChild } from '../components/AndroidEmulator';

/**
 * دالة مساعدة لتنزيل ملف الإكسل باسم مخصص
 */
function downloadWorkbook(workbook: XLSX.WorkBook, filename: string) {
  XLSX.writeFile(workbook, filename, { bookType: 'xlsx', type: 'binary' });
}

export interface NominationExcelExportOptions {
  projectName: string;
  projectNumber: string;
  aidTypeName: string;
  aidValue: number | string;
  warehouse: string;
  fundingOrg: string;
  nominationDate: string;
  actualNominationDate?: string;
  nominationNotes?: string;
  stageUserName?: string;
  candidates: {
    family: MockFamily;
    type: 'يدوي' | 'آلي';
    score?: number;
    scoreDetails?: {
      sizeScore: number;
      childScore: number;
      damageScore: number;
      timeScore: number;
    };
  }[];
  allChildren: MockChild[];
}

/**
 * 1. تصدير كشف المرشحين وبيانات المشروع التفصيلي إلى ملف Excel متعدد الأوراق
 */
export function exportNominationToExcel(options: NominationExcelExportOptions): string {
  const wb = XLSX.utils.book_new();

  // الورقة 1: كشف المرشحين المعتمدين
  const candidatesData = options.candidates.map((cand, idx) => {
    const f = cand.family;
    const fChildren = options.allChildren.filter(c => c.parentNationalID === f.nationalID || c.familyID === f.familyID);
    
    return {
      'الرقم التسلسلي': idx + 1,
      'رقم الأسرة': f.familyID,
      'رقم الهوية الوطنية': f.nationalID,
      'الاسم رباعي': f.name,
      'الجنس': f.gender,
      'العمر': f.age,
      'الحالة الاجتماعية': f.maritalStatus,
      'اسم الزوج / الزوجة': f.wifeName || 'غير مسجل',
      'هوية الزوج / الزوجة': f.wifeNationalID || 'غير مسجل',
      'إجمالي أفراد الأسرة': f.membersCount,
      'عدد الأبناء والتابعين': fChildren.length,
      'أسماء وأعمار الأبناء': fChildren.map(c => `${c.name} (${c.age} سنة)`).join('، ') || 'لا يوجد أبناء مسجلين',
      'رقم الجوال الأساسي': f.primaryPhone,
      'رقم الجوال البديل': f.alternativePhone1 || '',
      'رقم كرت المؤن': f.rationCardNumber,
      'المحافظة': f.currentMainArea,
      'المنطقة الفرعية الحالية': f.currentSubArea,
      'المسجد الحالي': f.currentMosque,
      'حالة اعتماد التنمية': f.developmentApproval,
      'حالة الإقامة': f.residentStatus,
      'حالة الإيواء': f.shelterStatus || 'خارج الإيواء',
      'مركز / مخيم الإيواء': f.campOrCenterName || '',
      'اعتماد الأشغال': f.worksApproval || 'غير معتمد',
      'نوع الضرر': f.damageType,
      'آلية الترشيح المتبعة': cand.type === 'يدوي' ? 'ترشيح يدوي بأولوية عليا' : 'ترشيح وفرز آلي خوارزمي',
      'نقاط الأولوية والمفاضلة': cand.score || (cand.type === 'يدوي' ? 999 : 85),
      'اسم المشروع': options.projectName,
      'كود المشروع': options.projectNumber,
      'نوع المساعدة': options.aidTypeName,
      'قيمة المساعدة (₪)': options.aidValue,
      'المستودع المنفذ': options.warehouse,
      'الجهة الممولة': options.fundingOrg,
      'تاريخ الترشيح': options.nominationDate,
      'تاريخ الترشيح الفعلي': options.actualNominationDate || options.nominationDate,
      'الباحث / المستخدم المنفذ': options.stageUserName || 'مسؤول الترشيح الميداني',
      'ملاحظات وتوجيهات الترشيح': options.nominationNotes || 'مرشح معتمد رسمياً'
    };
  });

  const wsCandidates = XLSX.utils.json_to_sheet(candidatesData);
  // Auto-width adjustment for columns
  wsCandidates['!cols'] = [
    { wch: 10 }, { wch: 10 }, { wch: 15 }, { wch: 28 }, { wch: 8 }, { wch: 8 },
    { wch: 14 }, { wch: 24 }, { wch: 15 }, { wch: 12 }, { wch: 12 }, { wch: 40 },
    { wch: 14 }, { wch: 14 }, { wch: 16 }, { wch: 16 }, { wch: 18 }, { wch: 22 },
    { wch: 16 }, { wch: 12 }, { wch: 16 }, { wch: 20 }, { wch: 16 }, { wch: 20 },
    { wch: 24 }, { wch: 14 }, { wch: 30 }, { wch: 18 }, { wch: 20 }, { wch: 14 },
    { wch: 24 }, { wch: 24 }, { wch: 14 }, { wch: 18 }, { wch: 24 }, { wch: 35 }
  ];
  XLSX.utils.book_append_sheet(wb, wsCandidates, 'كشف المرشحين والمشروع');

  // الورقة 2: كشف الأبناء والتابعين لكافة الأسر المرشحة
  const candidateFamilyIds = options.candidates.map(c => c.family.familyID);
  const candidateParentNationalIds = options.candidates.map(c => c.family.nationalID);
  const relevantChildren = options.allChildren.filter(c => 
    (c.familyID && candidateFamilyIds.includes(c.familyID)) ||
    candidateParentNationalIds.includes(c.parentNationalID)
  );

  const childrenData = relevantChildren.map((child, idx) => {
    const parent = options.candidates.find(c => 
      c.family.nationalID === child.parentNationalID || (child.familyID && c.family.familyID === child.familyID)
    )?.family;

    return {
      'م': idx + 1,
      'رقم أسرة الوالد': parent?.familyID || child.familyID || '',
      'اسم رب الأسرة': parent?.name || '',
      'رقم هوية رب الأسرة': child.parentNationalID,
      'المنطقة الفرعية': parent?.currentSubArea || '',
      'اسم الابن / التابع': child.name,
      'رقم هوية الابن': child.nationalID,
      'الجنس': child.gender,
      'العمر (بالسنوات)': child.age,
      'تاريخ الميلاد': child.birthDate || '',
      'صلة القرابة': child.relation || (child.gender === 'ذكر' ? 'ابن' : 'ابنة'),
      'المرحلة التعليمية': child.educationLevel || (child.age < 5 ? 'دون سن الدراسة' : child.age <= 12 ? 'ابتدائي' : child.age <= 16 ? 'إعدادي' : 'ثانوي'),
      'الحالة الصحية': child.healthStatus || 'سليم',
      'ملاحظات خاصة': child.notes || ''
    };
  });

  const wsChildren = XLSX.utils.json_to_sheet(childrenData);
  wsChildren['!cols'] = [
    { wch: 6 }, { wch: 12 }, { wch: 28 }, { wch: 15 }, { wch: 18 },
    { wch: 26 }, { wch: 15 }, { wch: 8 }, { wch: 12 }, { wch: 14 },
    { wch: 14 }, { wch: 18 }, { wch: 16 }, { wch: 25 }
  ];
  XLSX.utils.book_append_sheet(wb, wsChildren, 'أبناء وتابعي الأسر المرشحة');

  // الورقة 3: ملخص المشروع والمعايير
  const projectSummaryData = [
    { 'المعيار / البيان': 'اسم المشروع الرسمي', 'القيمة المعتمدة': options.projectName },
    { 'المعيار / البيان': 'كود المشروع', 'القيمة المعتمدة': options.projectNumber },
    { 'المعيار / البيان': 'نوع المساعدة', 'القيمة المعتمدة': options.aidTypeName },
    { 'المعيار / البيان': 'قيمة المساعدة (₪)', 'القيمة المعتمدة': options.aidValue },
    { 'المعيار / البيان': 'المستودع المخصص للصرف', 'القيمة المعتمدة': options.warehouse },
    { 'المعيار / البيان': 'الجهة الممولة والمانحة', 'القيمة المعتمدة': options.fundingOrg },
    { 'المعيار / البيان': 'إجمالي الأسر المرشحة', 'القيمة المعتمدة': options.candidates.length },
    { 'المعيار / البيان': 'عدد المرشحين يدوياً', 'القيمة المعتمدة': options.candidates.filter(c => c.type === 'يدوي').length },
    { 'المعيار / البيان': 'عدد المرشحين آلياً', 'القيمة المعتمدة': options.candidates.filter(c => c.type === 'آلي').length },
    { 'المعيار / البيان': 'إجمالي الأبناء المشمولين', 'القيمة المعتمدة': relevantChildren.length },
    { 'المعيار / البيان': 'تاريخ ووقت استخراج التقرير', 'القيمة المعتمدة': new Date().toLocaleString('ar-EG') }
  ];
  const wsSummary = XLSX.utils.json_to_sheet(projectSummaryData);
  wsSummary['!cols'] = [{ wch: 26 }, { wch: 40 }];
  XLSX.utils.book_append_sheet(wb, wsSummary, 'بيانات ومعايير المشروع');

  const fileName = `كشف_ترشيح_${options.projectNumber || 'PRJ-2026'}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  downloadWorkbook(wb, fileName);
  return fileName;
}

/**
 * 2. تصدير سجل الأسر الكامل والمستفيدين مع الأبناء إلى إكسل
 */
export function exportFamiliesRegistryToExcel(families: MockFamily[], children: MockChild[]): string {
  const wb = XLSX.utils.book_new();

  // الورقة 1: سجل الأسر بجميع الحقول الـ 36
  const familiesData = families.map((f, idx) => {
    const fChildren = children.filter(c => c.parentNationalID === f.nationalID || c.familyID === f.familyID);
    return {
      'الرقم': idx + 1,
      'رقم الأسرة': f.familyID,
      'رقم الهوية': f.nationalID,
      'الاسم رباعي': f.name,
      'الجنس': f.gender,
      'تاريخ الميلاد': f.birthDate,
      'العمر': f.age,
      'الحالة الاجتماعية': f.maritalStatus,
      'حالة الوفاة': f.deathStatus,
      'جوال أساسي': f.primaryPhone,
      'جوال بديل 1': f.alternativePhone1 || '',
      'جوال بديل 2': f.alternativePhone2 || '',
      'اسم الزوج / الزوجة': f.wifeName || '',
      'هوية الزوج / الزوجة': f.wifeNationalID || '',
      'عدد أفراد الأسرة': f.membersCount,
      'عدد الأبناء المسجلين': fChildren.length,
      'أسماء الأبناء وأعمارهم': fChildren.map(c => `${c.name} (${c.age})`).join('، '),
      'حالة الضرر': f.damageType,
      'وصف الضرر': f.damageDescription || '',
      'حالة الإصابة': f.injuryStatus,
      'مصدر الدخل 1': f.incomeSource1,
      'مصدر الدخل 2': f.incomeSource2 || '',
      'رقم كرت المؤن': f.rationCardNumber,
      'المحافظة الأصلية': f.originalMainArea,
      'المنطقة الفرعية الأصلية': f.originalSubArea,
      'المسجد الأصلي': f.originalMosque,
      'المحافظة الحالية': f.currentMainArea,
      'المنطقة الفرعية الحالية': f.currentSubArea,
      'المسجد الحالي': f.currentMosque,
      'اعتماد التنمية': f.developmentApproval,
      'مقيم / نازح': f.residentStatus,
      'اعتماد الأشغال': f.worksApproval || 'غير معتمد',
      'حالة الإيواء': f.shelterStatus || 'خارج الإيواء',
      'مركز الإيواء': f.campOrCenterName || '',
      'آخر تاريخ مساعدة': f.lastAidDate || '',
      'ملاحظات الأسرة': f.notes || ''
    };
  });

  const wsFamilies = XLSX.utils.json_to_sheet(familiesData);
  wsFamilies['!cols'] = [
    { wch: 6 }, { wch: 10 }, { wch: 15 }, { wch: 28 }, { wch: 8 }, { wch: 12 },
    { wch: 8 }, { wch: 14 }, { wch: 12 }, { wch: 14 }, { wch: 14 }, { wch: 14 },
    { wch: 24 }, { wch: 15 }, { wch: 14 }, { wch: 14 }, { wch: 40 }, { wch: 18 },
    { wch: 30 }, { wch: 18 }, { wch: 20 }, { wch: 16 }, { wch: 16 }, { wch: 16 },
    { wch: 18 }, { wch: 22 }, { wch: 16 }, { wch: 18 }, { wch: 22 }, { wch: 14 },
    { wch: 12 }, { wch: 16 }, { wch: 16 }, { wch: 22 }, { wch: 16 }, { wch: 30 }
  ];
  XLSX.utils.book_append_sheet(wb, wsFamilies, 'سجل الأسر والمستفيدين');

  // الورقة 2: سجل الأبناء والتابعين الكامل
  const allChildrenData = children.map((child, idx) => {
    const parent = families.find(f => f.nationalID === child.parentNationalID || f.familyID === child.familyID);
    return {
      'الرقم': idx + 1,
      'رقم أسرة الوالد': parent?.familyID || child.familyID || '',
      'اسم رب الأسرة': parent?.name || '',
      'رقم هوية رب الأسرة': child.parentNationalID,
      'المنطقة الفرعية': parent?.currentSubArea || '',
      'اسم الابن': child.name,
      'رقم هوية الابن': child.nationalID,
      'الجنس': child.gender,
      'العمر (سنوات)': child.age,
      'تاريخ الميلاد': child.birthDate || '',
      'صلة القرابة': child.relation || (child.gender === 'ذكر' ? 'ابن' : 'ابنة'),
      'المرحلة التعليمية': child.educationLevel || '',
      'الحالة الصحية': child.healthStatus || 'سليم',
      'ملاحظات': child.notes || ''
    };
  });

  const wsChildren = XLSX.utils.json_to_sheet(allChildrenData);
  wsChildren['!cols'] = [
    { wch: 6 }, { wch: 12 }, { wch: 28 }, { wch: 15 }, { wch: 18 },
    { wch: 26 }, { wch: 15 }, { wch: 8 }, { wch: 12 }, { wch: 14 },
    { wch: 12 }, { wch: 16 }, { wch: 16 }, { wch: 25 }
  ];
  XLSX.utils.book_append_sheet(wb, wsChildren, 'سجل الأبناء والتابعين');

  const fileName = `سجل_الأسر_والأبناء_الكامل_${new Date().toISOString().slice(0, 10)}.xlsx`;
  downloadWorkbook(wb, fileName);
  return fileName;
}

/**
 * 3. تصدير كشف الصرف والتسليم الميداني إلى إكسل
 */
export function exportDeliveryManifestToExcel(deliveryRecords: any[], allChildren: MockChild[]): string {
  const wb = XLSX.utils.book_new();

  const data = deliveryRecords.map((d, idx) => {
    const f = d.family;
    const fChildren = allChildren.filter(c => c.parentNationalID === f.nationalID || c.familyID === f.familyID);
    return {
      'الرقم': idx + 1,
      'رقم سند الصرف': d.receiptVoucherNumber || `VOUCH-2026-00${f.familyID}`,
      'حالة الصرف والتسليم': d.status,
      'اسم المستفيد': f.name,
      'رقم الهوية الوطنية': f.nationalID,
      'رقم كرت المؤن': f.rationCardNumber,
      'رقم الجوال': f.primaryPhone,
      'المنطقة الفرعية': f.currentSubArea,
      'أفراد الأسرة': f.membersCount,
      'عدد الأبناء': fChildren.length,
      'أسماء الأبناء': fChildren.map((c: any) => `${c.name} (${c.age})`).join('، '),
      'اسم المشروع': d.projectName,
      'كود المشروع': d.projectNumber,
      'نوع وقيمة الطرد': `${d.aidTypeName || 'طرد غذائي'} (${d.aidValue || 250} ₪)`,
      'المستودع المنفذ': d.warehouse,
      'المستلم الفعلي': d.receiverName || f.name,
      'صفة المستلم': d.receiverType || 'المستفيد شخصياً',
      'تاريخ الاستلام': d.deliveryDate || '',
      'وقت الاستلام': d.deliveryTime || '',
      'الموظف المسلّم': d.deliveredByStaff || '',
      'التحقق من الهوية والتوقيع': d.signatureVerified ? 'تم التحقق وتوقيع المستند' : 'بانتظار الاستلام',
      'ملاحظات التسليم': d.deliveryNotes || ''
    };
  });

  const ws = XLSX.utils.json_to_sheet(data);
  ws['!cols'] = [
    { wch: 6 }, { wch: 18 }, { wch: 16 }, { wch: 28 }, { wch: 15 }, { wch: 16 },
    { wch: 14 }, { wch: 18 }, { wch: 12 }, { wch: 12 }, { wch: 35 }, { wch: 28 },
    { wch: 16 }, { wch: 22 }, { wch: 24 }, { wch: 26 }, { wch: 18 }, { wch: 14 },
    { wch: 14 }, { wch: 22 }, { wch: 22 }, { wch: 28 }
  ];
  XLSX.utils.book_append_sheet(wb, ws, 'كشف الصرف والتسليم الميداني');

  const fileName = `كشف_تسليم_المساعدات_${new Date().toISOString().slice(0, 10)}.xlsx`;
  downloadWorkbook(wb, fileName);
  return fileName;
}

/**
 * 4. تصدير سجل تتبع مسار الترشيح والمراجعين إلى إكسل
 */
export function exportTrackingRecordsToExcel(trackingRecords: any[], allChildren: MockChild[]): string {
  const wb = XLSX.utils.book_new();

  const data = trackingRecords.map((t, idx) => {
    const f = t.family;
    const fChildren = allChildren.filter(c => c.parentNationalID === f.nationalID || c.familyID === f.familyID);
    
    const step1 = t.steps.find((s: any) => s.stepNumber === 1);
    const step2 = t.steps.find((s: any) => s.stepNumber === 2);
    const step3 = t.steps.find((s: any) => s.stepNumber === 3);
    const step4 = t.steps.find((s: any) => s.stepNumber === 4);
    const step5 = t.steps.find((s: any) => s.stepNumber === 5);
    const step6 = t.steps.find((s: any) => s.stepNumber === 6);

    return {
      'الرقم': idx + 1,
      'رقم الأسرة': f.familyID,
      'اسم المستفيد': f.name,
      'رقم الهوية': f.nationalID,
      'المنطقة الفرعية': f.currentSubArea,
      'أفراد الأسرة': f.membersCount,
      'عدد الأبناء': fChildren.length,
      'أسماء الأبناء': fChildren.map((c: any) => `${c.name} (${c.age})`).join('، '),
      'الحالة العامة للملف': t.overallStatus,
      'نسبة الإنجاز': `${t.progressPercent}%`,
      'المراجع المسؤول الحالي': t.currentReviewerName,
      'مسمى المراجع الحالي': t.currentReviewerRole,
      // م1
      'م1: حالة طرح المشروع': step1?.statusLabel || '',
      'م1: مراجع الطرح': step1?.reviewer?.name || '',
      'م1: تاريخ الطرح': step1?.timestamp || '',
      // م2
      'م2: فحص الأهلية الخوارزمي': step2?.statusLabel || '',
      'م2: مراجع التدقيق الرقمي': step2?.reviewer?.name || '',
      // م3
      'م3: الترشيح الأولي الميداني': step3?.statusLabel || '',
      'م3: الباحث المنفذ': step3?.reviewer?.name || '',
      'م3: ملاحظة الترشيح الميداني': step3?.decisionNote || '',
      'م3: تاريخ الترشيح': step3?.timestamp || '',
      // م4
      'م4: رفع وتدقيق الكشف': step4?.statusLabel || '',
      'م4: مدقق الكشوفات': step4?.reviewer?.name || '',
      // م5
      'م5: قرار واعتماد المدير العام': step5?.statusLabel || '',
      'م5: مفوّض الاعتماد': step5?.reviewer?.name || '',
      'م5: قرار وملاحظة المدير': step5?.decisionNote || '',
      'م5: تاريخ قرار المدير': step5?.timestamp || '',
      // م6
      'م6: الصرف والتسليم الفعلي': step6?.statusLabel || '',
      'م6: أمين المستودع المسلّم': step6?.reviewer?.name || '',
      'م6: تاريخ التسليم': step6?.timestamp || ''
    };
  });

  const ws = XLSX.utils.json_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, ws, 'تتبع مسار الترشيح والمراجعين');

  const fileName = `سجل_تتبع_مسار_الترشيح_${new Date().toISOString().slice(0, 10)}.xlsx`;
  downloadWorkbook(wb, fileName);
  return fileName;
}

export interface ProjectFullExcelExportOptions {
  projectNumber: string;
  projectName: string;
  aidTypeName: string;
  aidValue: number;
  warehouse: string;
  fundingOrg: string;
  distributionDate: string;
  targetBeneficiaries: number;
  status: string;
  officer?: string;
  subAreas?: string[];
  description?: string;
  deliveredRecords: any[];
  candidateRecords: any[];
  allChildren: MockChild[];
}

/**
 * 5. تصدير ملف إكسل شامل ومفصل لبيانات المشروع والمستفيدين والمرشحين والأبناء
 */
export function exportProjectFullDataToExcel(options: ProjectFullExcelExportOptions): string {
  const wb = XLSX.utils.book_new();

  const totalDelivered = options.deliveredRecords.length;
  const totalCandidates = options.candidateRecords.length;
  const totalBeneficiaries = totalDelivered;
  const target = options.targetBeneficiaries || (totalDelivered + totalCandidates) || 1;
  const progressPercent = Math.min(100, Math.round((totalDelivered / target) * 100));
  const totalFinancialValue = (totalDelivered * options.aidValue).toLocaleString('ar-EG');
  const plannedFinancialValue = (target * options.aidValue).toLocaleString('ar-EG');

  // ورقة 1: بطاقة وبيانات المشروع الإحصائية
  const projectSummaryData = [
    { 'البيان': 'كود المشروع', 'القيمة': options.projectNumber },
    { 'البيان': 'اسم المشروع الرسمي', 'القيمة': options.projectName },
    { 'البيان': 'نوع المساعدة الإغاثية', 'القيمة': options.aidTypeName },
    { 'البيان': 'قيمة الطرد / الحصة (شيكل)', 'القيمة': options.aidValue },
    { 'البيان': 'حالة المشروع الحالية', 'القيمة': options.status },
    { 'البيان': 'الجهة المانحة والممولة', 'القيمة': options.fundingOrg },
    { 'البيان': 'المستودع ومركز التوزيع', 'القيمة': options.warehouse },
    { 'البيان': 'المشرف الميداني المسؤول', 'القيمة': options.officer || 'المشرف العام' },
    { 'البيان': 'المناطق الفرعية المشمولة', 'القيمة': options.subAreas?.join('، ') || 'كافة المناطق الفرعية الـ 5' },
    { 'البيان': 'تاريخ وفترة الصرف', 'القيمة': options.distributionDate },
    { 'البيان': 'المستهدف الإجمالي المخطط', 'القيمة': `${target} أسرة` },
    { 'البيان': 'عدد المستفيدين المسلمين فعلياً', 'القيمة': `${totalBeneficiaries} أسرة مستفيدة` },
    { 'البيان': 'عدد المرشحين بانتظار الاستلام', 'القيمة': `${totalCandidates} أسرة مرشحة` },
    { 'البيان': 'نسبة الإنجاز والتسليم', 'القيمة': `${progressPercent}%` },
    { 'البيان': 'الميزانية الفعلية المصروفة', 'القيمة': `${totalFinancialValue} ₪` },
    { 'البيان': 'الميزانية الكلية المرصودة', 'القيمة': `${plannedFinancialValue} ₪` },
    { 'البيان': 'وصف وتوجيهات المشروع', 'القيمة': options.description || 'مشروع معتمد للصرف الميداني المباشر' }
  ];
  const wsSummary = XLSX.utils.json_to_sheet(projectSummaryData);
  XLSX.utils.book_append_sheet(wb, wsSummary, 'بيانات_المشروع_العامة');

  // ورقة 2: كشف المستفيدين المسلمين
  const deliveredSheetData = options.deliveredRecords.map((r, idx) => {
    const fam = r.family;
    const famChildren = options.allChildren.filter(c => c.parentNationalID === (fam?.nationalID || r.nationalID) || c.familyID === (fam?.familyID || r.familyId));
    return {
      'الرقم': idx + 1,
      'رقم الأسرة': r.familyId || fam?.familyID,
      'رقم الهوية': r.nationalID || fam?.nationalID,
      'اسم المستفيد': r.headOfFamilyName || fam?.name,
      'رقم الهاتف': fam?.primaryPhone || 'غير متوفر',
      'المنطقة الفرعية': fam?.currentSubArea || r.warehouse,
      'كود التسليم / القسيمة': r.deliveryCode || 'N/A',
      'حالة الصرف': r.status,
      'تاريخ الاستحقاق': r.dueDistributionDate,
      'تاريخ وساعة التسليم الفعلي': r.deliveredAt || 'تم التسليم المسبق',
      'اسم المستلم الفعلي': r.receivedByName || r.headOfFamilyName,
      'هوية المستلم': r.receivedByNationalId || r.nationalID,
      'صفة المستلم': r.receiverRelationship || 'رب الأسرة شخصياً',
      'كود الطرد / الصندوق': r.boxCode || 'BX-001',
      'عدد أفراد الأسرة': fam?.membersCount || 1,
      'عدد الأبناء المسجلين': famChildren.length,
      'أسماء وأعمار الأبناء': famChildren.map(c => `${c.name} (${c.age} سنة)`).join('، ') || 'لا يوجد',
      'أمين المخزن المسلّم': r.warehouseOfficer || options.officer || 'المسؤول المناوب'
    };
  });
  const wsDelivered = XLSX.utils.json_to_sheet(deliveredSheetData.length > 0 ? deliveredSheetData : [{ 'تنبيه': 'لا توجد سجلات تسليم مكتملة حالياً' }]);
  XLSX.utils.book_append_sheet(wb, wsDelivered, 'المستفيدون_المسلمون');

  // ورقة 3: كشف المرشحين بانتظار التسليم
  const candidatesSheetData = options.candidateRecords.map((c, idx) => {
    const fam = c.family || c;
    const famChildren = options.allChildren.filter(child => child.parentNationalID === (fam?.nationalID || c.nationalID) || child.familyID === (fam?.familyID || c.familyID));
    return {
      'الرقم': idx + 1,
      'رقم الأسرة': fam?.familyID || c.familyID || idx + 1,
      'رقم الهوية': fam?.nationalID || c.nationalID,
      'اسم المرشح': fam?.name || c.headOfFamilyName,
      'نوع الترشيح': c.type || (c.score === 999 ? 'يدوي' : 'آلي'),
      'نقاط الأولوية': c.score || 'معتمد',
      'رقم الهاتف': fam?.primaryPhone || 'غير متوفر',
      'المنطقة الفرعية': fam?.currentSubArea || 'المنطقة المعتمدة',
      'الحالة الاجتماعية': fam?.maritalStatus || 'متزوج',
      'حالة السكن': fam?.shelterStatus || 'مقيم',
      'مستوى الضرر': fam?.damageLevel || 'لا يوجد',
      'أفراد الأسرة': fam?.membersCount || 1,
      'عدد الأبناء': famChildren.length,
      'أسماء الأبناء': famChildren.map(ch => `${ch.name} (${ch.age} سنة)`).join('، ') || 'لا يوجد',
      'حالة الاعتماد': 'معتمد بانتظار استلام الحصة'
    };
  });
  const wsCandidates = XLSX.utils.json_to_sheet(candidatesSheetData.length > 0 ? candidatesSheetData : [{ 'تنبيه': 'لا توجد أسر مرشحة بانتظار الصرف حالياً' }]);
  XLSX.utils.book_append_sheet(wb, wsCandidates, 'المرشحون_بانتظار_التسليم');

  // ورقة 4: كشف كامل بالأبناء والتابعين للأسر المشمولة بالمشروع
  const projectFamilyIds = new Set([
    ...options.deliveredRecords.map(r => r.familyId || r.family?.familyID),
    ...options.candidateRecords.map(c => c.familyId || c.family?.familyID || c.familyID)
  ].filter(Boolean));

  // Map to get parent name by parent national ID or familyID
  const parentNameMap = new Map<string, string>();
  options.deliveredRecords.forEach(r => {
    const f = r.family;
    if (f?.nationalID && f?.name) parentNameMap.set(f.nationalID, f.name);
    if (r.nationalID && r.headOfFamilyName) parentNameMap.set(r.nationalID, r.headOfFamilyName);
  });
  options.candidateRecords.forEach(c => {
    const f = c.family || c;
    if (f?.nationalID && f?.name) parentNameMap.set(f.nationalID, f.name);
    if (c.nationalID && c.headOfFamilyName) parentNameMap.set(c.nationalID, c.headOfFamilyName);
  });

  const projectChildren = options.allChildren.filter(c => projectFamilyIds.has(c.familyID));
  const childrenSheetData = projectChildren.map((ch, idx) => ({
    'م': idx + 1,
    'رقم الأسرة': ch.familyID,
    'اسم الابن / التابع': ch.name,
    'رقم هوية الابن': ch.nationalID,
    'تاريخ الميلاد': ch.birthDate,
    'العمر (سنوات)': ch.age,
    'الجنس': ch.gender,
    'الحالة الصحية / إعاقة': ch.healthStatus || 'سليم',
    'المرحلة التعليمية': ch.educationLevel || 'غير محدد',
    'اسم رب الأسرة': parentNameMap.get(ch.parentNationalID) || (ch as any).parentName || 'مسجل بالقيد العائلي',
    'هوية رب الأسرة': ch.parentNationalID
  }));
  const wsChildren = XLSX.utils.json_to_sheet(childrenSheetData.length > 0 ? childrenSheetData : [{ 'تنبيه': 'لا يوجد أبناء مسجلين لهذه الأسر' }]);
  XLSX.utils.book_append_sheet(wb, wsChildren, 'بيانات_الأبناء_والتابعين');

  const safePrjName = options.projectNumber.replace(/[^a-zA-Z0-9-]/g, '_');
  const fileName = `بيانات_مشروع_${safePrjName}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  downloadWorkbook(wb, fileName);
  return fileName;
}

/**
 * 6. تصدير ملخص شامل لكافة المشاريع الإغاثية مع إحصائيات المستفيدين والمرشحين
 */
export function exportAllProjectsSummaryToExcel(projects: {
  projectNumber: string;
  projectName: string;
  aidTypeName: string;
  aidValue: number;
  warehouse: string;
  fundingOrg: string;
  distributionDate: string;
  targetBeneficiaries: number;
  deliveredCount: number;
  candidatesCount: number;
  status: string;
  officer?: string;
  subAreas?: string[];
}[]): string {
  const wb = XLSX.utils.book_new();

  const data = projects.map((p, idx) => {
    const target = p.targetBeneficiaries || (p.deliveredCount + p.candidatesCount) || 1;
    const progress = Math.min(100, Math.round((p.deliveredCount / target) * 100));
    return {
      'الرقم': idx + 1,
      'كود المشروع': p.projectNumber,
      'اسم المشروع الإغاثي': p.projectName,
      'نوع المساعدة': p.aidTypeName,
      'قيمة المساعدة (₪)': p.aidValue,
      'الحالة التنفيذية': p.status,
      'المستهدف الكلي (أسرة)': target,
      'عدد المستفيدين المستلمين': p.deliveredCount,
      'عدد المرشحين قيد الانتظار': p.candidatesCount,
      'المتبقي للصرف': Math.max(0, target - p.deliveredCount),
      'نسبة الإنجاز': `${progress}%`,
      'إجمالي الميزانية المصروفة (₪)': (p.deliveredCount * p.aidValue).toLocaleString('ar-EG'),
      'المستودع / مركز التوزيع': p.warehouse,
      'الجهة المانحة والممولة': p.fundingOrg,
      'تاريخ التوزيع': p.distributionDate,
      'المسؤول الميداني': p.officer || 'المشرف العام',
      'المناطق المشمولة': p.subAreas?.join('، ') || 'كافة المناطق'
    };
  });

  const ws = XLSX.utils.json_to_sheet(data);
  XLSX.utils.book_append_sheet(wb, ws, 'كشف_المشاريع_الإغاثية_الشامل');

  const fileName = `كشف_المشاريع_الإغاثية_الشامل_${new Date().toISOString().slice(0, 10)}.xlsx`;
  downloadWorkbook(wb, fileName);
  return fileName;
}

// ==================== 7. نظام فحص وتدقيق ملف إكسل الهويات مع التقرير الثلاثي (3 شيتات) ====================

export interface NationalIdVerificationRowApproved {
  nationalID: string;
  name: string;
  primaryPhone: string;
  currentMainArea: string;
  currentSubArea: string;
  currentMosque?: string;
  developmentApproval: string; // 'معتمد'
  residentStatus: string; // 'مقيم'
  membersCount: number;
  totalAidsCount: number;
  lastAidType: string;
  lastAidDate: string;
  lastAidCategory: string;
  statusNotes?: string;
  isAreaPermitted?: boolean;
  geographicPermissionStatus?: string;
}

export interface NationalIdVerificationRowRejected {
  nationalID: string;
  name: string;
  primaryPhone: string;
  currentSubArea: string;
  developmentApproval: string;
  residentStatus: string;
  rejectionReason: string; // غير معتمد تنمية، نازح وليس مقيم، أو كلاهما
  membersCount: number;
  totalAidsCount: number;
  lastAidType: string;
  lastAidDate: string;
  isAreaPermitted?: boolean;
  geographicPermissionStatus?: string;
}

export interface NationalIdVerificationRowUnregistered {
  nationalID: string;
  status: string; // 'غير مسجل في النظام'
  actionRequired: string;
  checkedDate: string;
}

export interface NationalIdVerificationResult {
  sourceFileName?: string;
  totalChecked: number;
  approvedCount: number;
  rejectedCount: number;
  unregisteredCount: number;
  permittedAreaCount?: number;
  restrictedAreaCount?: number;
  userJurisdictionLabel?: string;
  approvedList: NationalIdVerificationRowApproved[];
  rejectedList: NationalIdVerificationRowRejected[];
  unregisteredList: NationalIdVerificationRowUnregistered[];
}

/**
 * تصدير تقرير فحص ومطابقة الهويات إلى ملف Excel مكون من 3 شيتات مستقلة كما طلب المستخدم:
 * الشيت 1: المعتمدين والمقيمين (معتمد + مقيم + بياناته ومساعداته + الصلاحية الجغرافية)
 * الشيت 2: غير المطابقين لشروط الاعتماد مع سبب الرفض + الصلاحية الجغرافية
 * الشيت 3: غير المسجلين في النظام (رقم الهوية وجنبه غير مسجل)
 */
export function exportNationalIdVerificationToExcel(
  result: NationalIdVerificationResult,
  filterOnlyPermittedAreas: boolean = false
): string {
  const wb = XLSX.utils.book_new();

  // تصفية القوائم بحسب الصلاحيات الجغرافية إن طُلب ذلك
  const approvedSource = filterOnlyPermittedAreas
    ? result.approvedList.filter(r => r.isAreaPermitted)
    : result.approvedList;

  const rejectedSource = filterOnlyPermittedAreas
    ? result.rejectedList.filter(r => r.isAreaPermitted)
    : result.rejectedList;

  // 1. الشيت الأول: المعتمدين والمقيمين (تنطبق عليهم شروط الاعتماد والإقامة)
  const sheet1Data = approvedSource.map((row, idx) => ({
    'الرقم': idx + 1,
    'رقم الهوية الوطنية': row.nationalID,
    'اسم رب الأسرة': row.name,
    'نطاق الصلاحية الجغرافية للمستخدم': row.geographicPermissionStatus || (row.isAreaPermitted ? 'مصرح بالمعاينة' : 'خارج النطاق الجغرافي'),
    'المنطقة الفرعية': row.currentSubArea,
    'المنطقة الرئيسية': row.currentMainArea,
    'المسجد / الشعبة': row.currentMosque || 'مركزي',
    'حالة اعتماد التنمية': row.developmentApproval,
    'صفة الإقامة': row.residentStatus,
    'عدد أفراد الأسرة': row.membersCount,
    'عدد المساعدات المستلمة': row.totalAidsCount,
    'آخر نوع مساعدة': row.lastAidType || 'لا يوجد صرف سابق',
    'تاريخ آخر مساعدة': row.lastAidDate || 'غير متوفر',
    'تصنيف المساعدة': row.lastAidCategory || 'عام',
    'رقم الجوال': row.primaryPhone,
    'حالة الأهلية': 'مستوفٍ لكافة الشروط (معتمد + مقيم)'
  }));

  const emptyMsg1 = filterOnlyPermittedAreas
    ? 'لا توجد أسر معتمدة ومقيمة تقع ضمن نطاق صلاحياتك الجغرافية'
    : 'لا توجد أسر مطابقة للشروط في هذا الملف';

  const ws1 = XLSX.utils.json_to_sheet(sheet1Data.length > 0 ? sheet1Data : [{ 'تنبيه': emptyMsg1 }]);
  // ضبط عروض الأعمدة للشيت 1
  ws1['!cols'] = [
    { wch: 8 },  // الرقم
    { wch: 18 }, // رقم الهوية الوطنية
    { wch: 28 }, // اسم رب الأسرة
    { wch: 32 }, // نطاق الصلاحية الجغرافية للمستخدم
    { wch: 20 }, // المنطقة الفرعية
    { wch: 18 }, // المنطقة الرئيسية
    { wch: 20 }, // المسجد / الشعبة
    { wch: 18 }, // حالة اعتماد التنمية
    { wch: 14 }, // صفة الإقامة
    { wch: 14 }, // عدد أفراد الأسرة
    { wch: 14 }, // عدد المساعدات المستلمة
    { wch: 24 }, // آخر نوع مساعدة
    { wch: 16 }, // تاريخ آخر مساعدة
    { wch: 20 }, // تصنيف المساعدة
    { wch: 16 }, // رقم الجوال
    { wch: 32 }  // حالة الأهلية
  ];
  XLSX.utils.book_append_sheet(wb, ws1, 'المعتمدين_والمقيمين');

  // 2. الشيت الثاني: المستبعدين وغير المطابقين لشروط الاعتماد والإقامة مع سبب الرفض الدقيق
  const sheet2Data = rejectedSource.map((row, idx) => ({
    'الرقم': idx + 1,
    'رقم الهوية الوطنية': row.nationalID,
    'اسم رب الأسرة': row.name,
    'نطاق الصلاحية الجغرافية للمستخدم': row.geographicPermissionStatus || (row.isAreaPermitted ? 'مصرح بالمعاينة' : 'خارج النطاق الجغرافي'),
    'سبب الرفض وعدم الاعتماد': row.rejectionReason,
    'حالة اعتماد التنمية': row.developmentApproval,
    'صفة الإقامة': row.residentStatus,
    'المنطقة الفرعية': row.currentSubArea,
    'رقم الجوال': row.primaryPhone,
    'عدد الأفراد': row.membersCount,
    'عدد المساعدات السابقة': row.totalAidsCount,
    'آخر مساعدة مستلمة': row.lastAidType || 'لا يوجد صرف سابق',
    'تاريخ آخر مساعدة': row.lastAidDate || 'غير متوفر'
  }));

  const emptyMsg2 = filterOnlyPermittedAreas
    ? 'لا توجد أسر مستبعدة تقع ضمن نطاق صلاحياتك الجغرافية'
    : 'لا توجد أسر مستبعدة';

  const ws2 = XLSX.utils.json_to_sheet(sheet2Data.length > 0 ? sheet2Data : [{ 'تنبيه': emptyMsg2 }]);
  // ضبط عروض الأعمدة للشيت 2
  ws2['!cols'] = [
    { wch: 8 },  // الرقم
    { wch: 18 }, // رقم الهوية الوطنية
    { wch: 28 }, // اسم رب الأسرة
    { wch: 32 }, // نطاق الصلاحية الجغرافية للمستخدم
    { wch: 38 }, // سبب الرفض وعدم الاعتماد
    { wch: 18 }, // حالة اعتماد التنمية
    { wch: 14 }, // صفة الإقامة
    { wch: 20 }, // المنطقة الفرعية
    { wch: 16 }, // رقم الجوال
    { wch: 12 }, // عدد الأفراد
    { wch: 14 }, // عدد المساعدات السابقة
    { wch: 24 }, // آخر مساعدة مستلمة
    { wch: 16 }  // تاريخ آخر مساعدة
  ];
  XLSX.utils.book_append_sheet(wb, ws2, 'غير_المطابقين_للشروط');

  // 3. الشيت الثالث: غير المسجلين في النظام (رقم الهوية وجنبه غير مسجل في النظام)
  const sheet3Data = result.unregisteredList.map((row, idx) => ({
    'الرقم': idx + 1,
    'رقم الهوية الوطنية': row.nationalID,
    'حالة القيد في النظام': row.status, // "غير مسجل في النظام"
    'الإجراء الموصى به': row.actionRequired,
    'تاريخ الفحص': row.checkedDate
  }));

  const ws3 = XLSX.utils.json_to_sheet(sheet3Data.length > 0 ? sheet3Data : [{ 'تنبيه': 'كافة الهويات مسجلة في قاعدة النظام' }]);
  // ضبط عروض الأعمدة للشيت 3
  ws3['!cols'] = [
    { wch: 8 },  // الرقم
    { wch: 20 }, // رقم الهوية الوطنية
    { wch: 24 }, // حالة القيد في النظام
    { wch: 45 }, // الإجراء الموصى به
    { wch: 16 }  // تاريخ الفحص
  ];
  XLSX.utils.book_append_sheet(wb, ws3, 'غير_المسجلين_في_النظام');

  // تنزيل الملف
  const nowStr = new Date().toISOString().slice(0, 10);
  const baseName = (result.sourceFileName || 'تقرير_مطابقة_الهويات_الثلاثي').replace(/\.[^/.]+$/, '');
  const prefix = filterOnlyPermittedAreas ? 'صلاحيات_مناطق_' : '';
  const fileName = `${prefix}${baseName}_3_شيتات_${nowStr}.xlsx`;
  downloadWorkbook(wb, fileName);
  return fileName;
}

/**
 * دالة ذكية لاستخراج وقراءة أرقام الهويات من ملف Excel (.xlsx / .xls) أو CSV من الجوال
 * تدعم فحص كافة الشيتات والصفوف وتجريد الفواصل ومعالجة الأرقام العشرية
 */
export function extractNationalIdsFromExcelBuffer(buffer: ArrayBuffer): string[] {
  try {
    const wb = XLSX.read(buffer, { type: 'array' });
    const foundIds: Set<string> = new Set();

    // فحص كافة أوراق العمل في الملف
    wb.SheetNames.forEach(sheetName => {
      const ws = wb.Sheets[sheetName];
      if (!ws) return;

      const rows = XLSX.utils.sheet_to_json(ws, { header: 1 }) as any[][];

      rows.forEach(row => {
        if (!Array.isArray(row)) return;
        row.forEach(cell => {
          if (cell !== null && cell !== undefined) {
            let str = String(cell).trim();
            // إزالة الأصفار العشرية إن كان الرقم محفوظاً كـ float مثل 901234561.0
            if (str.endsWith('.0')) {
              str = str.slice(0, -2);
            }
            // فحص أرقام الهوية المكونة من 9 أرقام
            const cleanDigits = str.replace(/\D/g, '');
            if (cleanDigits.length === 9) {
              foundIds.add(cleanDigits);
            } else if (cleanDigits.length > 9) {
              const matches = str.match(/\b\d{9}\b/g);
              if (matches) {
                matches.forEach(m => foundIds.add(m));
              }
            } else if (cleanDigits.length === 8) {
              // هويات تبدأ بصفر أحياناً يُحذف بواسطة الإكسل
              foundIds.add(`0${cleanDigits}`);
            }
          }
        });
      });
    });

    return Array.from(foundIds);
  } catch (err) {
    console.error('Failed to parse excel file for IDs:', err);
    return [];
  }
}


