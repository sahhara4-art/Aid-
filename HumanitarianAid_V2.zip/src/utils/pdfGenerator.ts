import jsPDF from 'jspdf';
import { MockFamily } from '../components/AndroidEmulator';

export interface PdfExportCandidate {
  familyID: number;
  nationalID: string;
  name: string;
  membersCount: number;
  localityName: string;
  shelterStatus?: string;
  nominationType?: 'يدوي' | 'آلي';
  score?: number;
}

export interface PdfExportOptions {
  reportTitle: string;
  projectName: string;
  aidTypeName: string;
  localityName: string;
  date: string;
  families: (MockFamily & { nominationType?: 'يدوي' | 'آلي' })[];
  projectNumber?: string;
  fundingOrg?: string;
  warehouse?: string;
  aidValue?: string | number;
  nominationNotes?: string;
  stageUserName?: string;
  actualNominationDate?: string;
}

export function generateAidDistributionPdf(options: PdfExportOptions): string {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 12;

  // Header Bar
  doc.setFillColor(13, 148, 136); // Emerald / Teal
  doc.rect(0, 0, pageWidth, 8, 'F');

  // Title
  doc.setFontSize(15);
  doc.setTextColor(30, 41, 59);
  doc.text(options.reportTitle, pageWidth / 2, 18, { align: 'center' });

  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text('Humanitarian Aid Distribution & Official Candidate Dispatch Manifest', pageWidth / 2, 23, { align: 'center' });

  // Count mechanisms
  const manualCount = options.families.filter(f => f.nominationType === 'يدوي').length;
  const autoCount = options.families.filter(f => f.nominationType !== 'يدوي').length;

  // Metadata Box
  doc.setFillColor(241, 245, 249);
  const metaHeight = options.nominationNotes ? 36 : 30;
  doc.roundedRect(margin, 26, pageWidth - margin * 2, metaHeight, 2.5, 2.5, 'F');

  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);

  // Left Column
  const col1X = margin + 4;
  doc.text(`Project Name: ${options.projectName} ${options.projectNumber ? `(#${options.projectNumber})` : ''}`, col1X, 31);
  doc.text(`Aid Type: ${options.aidTypeName} ${options.aidValue ? `| Value: ${options.aidValue}` : ''}`, col1X, 36);
  doc.text(`Funding Agency: ${options.fundingOrg || 'WFP / Humanitarian Partners'}`, col1X, 41);
  doc.text(`Warehouse: ${options.warehouse || 'Central Warehouse'}`, col1X, 46);

  // Right Column
  const col2X = pageWidth / 2 + 6;
  doc.text(`Nomination Date: ${options.date}`, col2X, 31);
  doc.text(`Actual Exec Date/Time: ${options.actualNominationDate || options.date}`, col2X, 36);
  doc.text(`Stage Operator / User: ${options.stageUserName || 'Humanitarian Field Coordinator'}`, col2X, 41);
  doc.text(`Candidates: ${options.families.length} Families (${manualCount} Manual + ${autoCount} Auto)`, col2X, 46);

  // Notes line if provided
  if (options.nominationNotes) {
    doc.setFillColor(254, 243, 199);
    doc.roundedRect(col1X, 49, pageWidth - margin * 2 - 8, 10, 1.5, 1.5, 'F');
    doc.setTextColor(146, 64, 14);
    doc.setFontSize(7.5);
    const safeNotes = options.nominationNotes.length > 110 ? options.nominationNotes.substring(0, 110) + '...' : options.nominationNotes;
    doc.text(`Nomination Notes: ${safeNotes}`, col1X + 3, 55);
  }

  // Table Header
  const startY = 26 + metaHeight + 4;
  const rowHeight = 8.5;
  const colWNumber = 10;
  const colWName = 48;
  const colWId = 28;
  const colWMembers = 16;
  const colWLocality = 30;
  const colWMechanism = 24;
  const colWSign = 28;

  doc.setFillColor(30, 41, 59); // Slate 800
  doc.rect(margin, startY, pageWidth - margin * 2, rowHeight, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(7.5);

  let curX = margin;
  doc.text('#', curX + colWNumber / 2, startY + 5.5, { align: 'center' });
  curX += colWNumber;
  doc.text('Beneficiary Name', curX + 3, startY + 5.5);
  curX += colWName;
  doc.text('National ID', curX + colWId / 2, startY + 5.5, { align: 'center' });
  curX += colWId;
  doc.text('Members', curX + colWMembers / 2, startY + 5.5, { align: 'center' });
  curX += colWMembers;
  doc.text('Locality', curX + 3, startY + 5.5);
  curX += colWLocality;
  doc.text('Mechanism (الآلية)', curX + colWMechanism / 2, startY + 5.5, { align: 'center' });
  curX += colWMechanism;
  doc.text('Signature / Stamp', curX + colWSign / 2, startY + 5.5, { align: 'center' });

  // Rows
  let curY = startY + rowHeight;
  doc.setFontSize(7.5);

  const displayFamilies = options.families.slice(0, 18); // fit on single page cleanly
  displayFamilies.forEach((f, idx) => {
    // Alternating background
    if (idx % 2 === 1) {
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, curY, pageWidth - margin * 2, rowHeight, 'F');
    }

    // Border line
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, curY + rowHeight, pageWidth - margin, curY + rowHeight);

    doc.setTextColor(30, 41, 59);
    let rowX = margin;

    // #
    doc.text(`${idx + 1}`, rowX + colWNumber / 2, curY + 5.5, { align: 'center' });
    rowX += colWNumber;

    // Name
    const safeName = f.name;
    doc.text(safeName, rowX + 3, curY + 5.5);
    rowX += colWName;

    // National ID
    doc.text(f.nationalID, rowX + colWId / 2, curY + 5.5, { align: 'center' });
    rowX += colWId;

    // Members count
    doc.text(`${f.membersCount}`, rowX + colWMembers / 2, curY + 5.5, { align: 'center' });
    rowX += colWMembers;

    // Locality
    doc.text(f.localityName, rowX + 3, curY + 5.5);
    rowX += colWLocality;

    // Nomination Mechanism (يدوي أو آلي)
    const isManual = f.nominationType === 'يدوي';
    if (isManual) {
      doc.setTextColor(2, 132, 199); // Sky-600
      doc.text('Manual / يدوي', rowX + colWMechanism / 2, curY + 5.5, { align: 'center' });
    } else {
      doc.setTextColor(16, 185, 129); // Emerald-600
      doc.text('Auto / آلي', rowX + colWMechanism / 2, curY + 5.5, { align: 'center' });
    }
    doc.setTextColor(30, 41, 59);
    rowX += colWMechanism;

    // Signature line
    doc.setDrawColor(203, 213, 225);
    doc.line(rowX + 3, curY + 6, rowX + colWSign - 3, curY + 6);

    curY += rowHeight;
  });

  // Table outer border
  doc.setDrawColor(203, 213, 225);
  doc.rect(margin, startY, pageWidth - margin * 2, curY - startY);

  // Summary box
  const totalMembers = displayFamilies.reduce((sum, f) => sum + f.membersCount, 0);
  doc.setFillColor(240, 253, 250);
  doc.roundedRect(margin, curY + 3, pageWidth - margin * 2, 8, 2, 2, 'F');
  doc.setTextColor(15, 118, 110);
  doc.setFontSize(8);
  doc.text(
    `Total Approved Families: ${displayFamilies.length}   |   Total Individuals: ${totalMembers}   |   Manual: ${manualCount}   |   Auto: ${autoCount}   |   Warehouse: ${options.warehouse || 'Central'}`,
    margin + 4,
    curY + 8
  );

  // Official Signatures with Stage User and Field Officers
  const footerY = pageHeight - 26;
  doc.setFontSize(8);
  doc.setTextColor(30, 41, 59);

  // Sign 1: Stage User / Nomination Officer
  const officerName = options.stageUserName ? `Nomination Officer: ${options.stageUserName}` : 'Stage Nomination Officer';
  doc.text(officerName, margin + 28, footerY, { align: 'center' });
  doc.setDrawColor(148, 163, 184);
  doc.line(margin + 6, footerY + 9, margin + 50, footerY + 9);

  // Sign 2: Warehouse Officer
  doc.text(`Warehouse Supervisor: ${options.warehouse || 'Store Officer'}`, pageWidth / 2, footerY, { align: 'center' });
  doc.line(pageWidth / 2 - 25, footerY + 9, pageWidth / 2 + 25, footerY + 9);

  // Sign 3: Project Manager
  doc.text('Project Director Approval', pageWidth - margin - 28, footerY, { align: 'center' });
  doc.line(pageWidth - margin - 50, footerY + 9, pageWidth - margin - 6, footerY + 9);

  // Copyright / Generated Notice
  doc.setFontSize(7);
  doc.setTextColor(148, 163, 184);
  doc.text(
    `System Generated: ${options.actualNominationDate || new Date().toISOString()} | Humanitarian Aid Management Platform`,
    pageWidth / 2,
    pageHeight - 6,
    { align: 'center' }
  );

  // Save / trigger download
  const dateStr = options.date.replace(/[^0-9]/g, '');
  const fileName = `Aid_Dispatch_Manifest_${options.projectNumber || 'PRJ'}_${dateStr}.pdf`;
  doc.save(fileName);

  return fileName;
}
