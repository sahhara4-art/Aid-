import { MockFamily } from '../components/AndroidEmulator';
import { CURRENT_SUB_AREAS } from '../types/adminSecurity';

export interface SubAreaQuotaSummary {
  subArea: string;
  code: string;
  localityId: number;
  localityName: string;
  approvedResidentCount: number; // عدد من هم (معتمد + مقيم)
  percentage: number; // النسبة المئوية من الإجمالي %
  targetQuota: number; // الحصة المستهدفة من العدد المطلوب
  criteriaPassedCount: number; // عدد من تنطبق عليهم معايير المفاضلة والاستثناء
  allocatedCount: number; // عدد من تم ترشيحهم فعلياً آلياً
  shortfall: number; // العجز / المتبقي لاستكمال الحصة
  fulfillmentRate: number; // نسبة الإنجاز %
}

export interface ProportionalNominationResult {
  requiredCount: number;
  totalApprovedResidents: number;
  totalCriteriaPassed: number;
  totalAllocated: number;
  totalShortfall: number;
  isComplete: boolean;
  quotas: SubAreaQuotaSummary[];
  allocatedFamilies: {
    family: MockFamily;
    type: 'آلي' | 'يدوي';
    score: number;
    scoreDetails: { sizeScore: number; childScore: number; damageScore: number; timeScore: number };
    quotaArea: string;
  }[];
}

// ==================== خوارزمية هاملتون لأكبر البواقي لحساب الحصص بدقة 100% ====================
export function calculateSubAreaProportions(
  families: MockFamily[],
  requiredCount: number,
  allowedSubAreas: string[] = ['*']
): { totalApprovedResidents: number; quotas: Record<string, { count: number; percentage: number; targetQuota: number }> } {
  // 1. قاعدة الفرز الأساسية: ممن يكون حالة اعتماد التنمية (معتمد) ومقيم/نازح (مقيم)
  const isAllAllowed = allowedSubAreas.includes('*');
  const baseApprovedResidents = families.filter(f => 
    f.developmentApproval === 'معتمد' && 
    f.residentStatus === 'مقيم' &&
    (isAllAllowed || allowedSubAreas.includes(f.currentSubArea))
  );

  const totalApprovedResidents = baseApprovedResidents.length;
  const quotas: Record<string, { count: number; percentage: number; targetQuota: number }> = {};

  if (totalApprovedResidents === 0 || requiredCount <= 0) {
    CURRENT_SUB_AREAS.forEach(area => {
      quotas[area] = { count: 0, percentage: 0, targetQuota: 0 };
    });
    return { totalApprovedResidents: 0, quotas };
  }

  // حساب الأعداد الدقيقة والنسب
  const exactShares: { area: string; count: number; percentage: number; exactQuota: number; floorQuota: number; remainder: number }[] = [];
  let allocatedFloorSum = 0;

  CURRENT_SUB_AREAS.forEach(area => {
    if (!isAllAllowed && !allowedSubAreas.includes(area)) {
      quotas[area] = { count: 0, percentage: 0, targetQuota: 0 };
      return;
    }

    const count = baseApprovedResidents.filter(f => f.currentSubArea === area).length;
    const percentage = totalApprovedResidents > 0 ? (count / totalApprovedResidents) * 100 : 0;
    const exactQuota = totalApprovedResidents > 0 ? (count / totalApprovedResidents) * requiredCount : 0;
    const floorQuota = Math.floor(exactQuota);
    const remainder = exactQuota - floorQuota;

    exactShares.push({
      area,
      count,
      percentage: parseFloat(percentage.toFixed(2)),
      exactQuota,
      floorQuota,
      remainder
    });

    allocatedFloorSum += floorQuota;
  });

  // توزيع البواقي وفق خوارزمية أكبر البواقي (Largest Remainder Method) لضمان أن المجموع = requiredCount بالضبط
  let remainderUnits = requiredCount - allocatedFloorSum;
  exactShares.sort((a, b) => b.remainder - a.remainder);

  exactShares.forEach((share, idx) => {
    let finalQuota = share.floorQuota;
    if (idx < remainderUnits) {
      finalQuota += 1;
    }
    quotas[share.area] = {
      count: share.count,
      percentage: share.percentage,
      targetQuota: finalQuota
    };
  });

  return { totalApprovedResidents, quotas };
}

// ==================== مولد بيانات السجل الواقعي الضخم (1,600 أسرة عبر الـ 5 مناطق) ====================
export function generateRealisticFamiliesDataset(): MockFamily[] {
  const families: MockFamily[] = [];

  const subAreaConfigs = [
    { name: 'الرمال الشمالي', code: 'GZ-RML-N', localityId: 1, localityName: 'الرمال الشمالي', targetCount: 350 },
    { name: 'الشيخ رضوان', code: 'GZ-SH-RDW', localityId: 2, localityName: 'الشيخ رضوان', targetCount: 420 },
    { name: 'الشاطئ الشمالي والنصر', code: 'GZ-SHT-NSR', localityId: 3, localityName: 'الشاطئ الشمالي والنصر', targetCount: 370 },
    { name: 'الشاطئ الجنوبي', code: 'GZ-SHT-SOU', localityId: 4, localityName: 'الشاطئ الجنوبي', targetCount: 260 },
    { name: 'مشروع عامر', code: 'GZ-PRJ-AMR', localityId: 5, localityName: 'مشروع عامر', targetCount: 220 }
  ];

  const firstNames = ['أحمد', 'محمد', 'محمود', 'خليل', 'إبراهيم', 'يوسف', 'خالد', 'سامي', 'عمر', 'طارق', 'حسن', 'علي', 'بلال', 'زياد', 'رامي', 'ماجد', 'سالم', 'توفيق', 'موسى', 'عيسى', 'عادل', 'سامر', 'كمال', 'هاني', 'نادر'];
  const fatherNames = ['عبد الله', 'عبد الرحمن', 'محمود', 'خليل', 'إبراهيم', 'حسن', 'صالح', 'جمال', 'توفيق', 'رمضان', 'شعبان', 'سليمان', 'فوزي', 'عزمي'];
  const familyNames = ['الأسطل', 'النجار', 'رضوان', 'الدحدوح', 'حسونة', 'أبو حصيرة', 'شبير', 'الودية', 'الغول', 'الجعبري', 'الهندي', 'كحيل', 'صيام', 'حلس', 'ساق الله', 'أبو شعبان', 'القواسمي', 'البورنو', 'الريفي', 'أبو عمرو', 'أبو شرخ'];
  const wifeNames = ['فاطمة', 'مريم', 'سميرة', 'إيمان', 'نهى', 'سعاد', 'هدى', 'رانية', 'آمنة', 'خديجة', 'زينب', 'منى', 'وفاء', 'هناء', 'دعاء'];
  const damageTypes = ['أضرار كلية', 'أضرار كلية', 'أضرار جزئية بليغة', 'أضرار جزئية'];
  const shelterTypes = ['إيواء داخلي', 'خارج الإيواء', 'إيواء داخلي', 'خارج الإيواء'];
  const mosques = ['مسجد فلسطين', 'مسجد الرضوان', 'مسجد السوسي', 'مسجد الميناء', 'مسجد الهدى', 'مسجد النور', 'مسجد القسام'];

  let globalId = 1;

  subAreaConfigs.forEach(sub => {
    for (let i = 0; i < sub.targetCount; i++) {
      const fName = firstNames[(globalId + i * 3) % firstNames.length];
      const mName = fatherNames[(globalId + i * 5) % fatherNames.length];
      const lName = familyNames[(globalId + i * 7) % familyNames.length];
      const fullName = `${fName} ${mName} ${lName}`;
      
      const wName = `${wifeNames[(globalId + i * 2) % wifeNames.length]} ${fatherNames[(globalId + i * 4) % fatherNames.length]} ${familyNames[(globalId + i * 6) % familyNames.length]}`;
      const nationalID = `9${String(10000000 + globalId * 137).slice(-8)}`;
      const wifeNationalID = `9${String(20000000 + globalId * 149).slice(-8)}`;

      // توزيع الاعتماد: 88% معتمد، 8% حجب اعتماد، 4% مجمد
      const devRoll = (globalId * 17) % 100;
      const developmentApproval = devRoll < 88 ? 'معتمد' : (devRoll < 96 ? 'حجب اعتماد' : 'مجمد');

      // توزيع الإقامة: 80% مقيم، 20% نازح
      const resRoll = (globalId * 23) % 100;
      const residentStatus = resRoll < 80 ? 'مقيم' : 'نازح';

      const membersCount = 2 + ((globalId * 11) % 11); // بين 2 إلى 12 أفراد
      const damageType = damageTypes[(globalId + i) % damageTypes.length];
      const shelterStatus = shelterTypes[(globalId + i * 3) % shelterTypes.length];
      const worksApproval = (globalId % 3 === 0) ? 'اعتماد أشغال' : 'فارغ';

      const birthYear = 1968 + (globalId % 32);
      const birthMonth = String(1 + (globalId % 12)).padStart(2, '0');
      const birthDay = String(1 + (globalId % 28)).padStart(2, '0');

      // آخر استلام للمساعدات بالأيام لتوليد استثناء وتفاوت بالأولوية
      const daysSinceAid = 15 + ((globalId * 19) % 200); // من 15 إلى 215 يوم
      const lastAidDateObj = new Date();
      lastAidDateObj.setDate(lastAidDateObj.getDate() - daysSinceAid);
      const lastAidDateStr = lastAidDateObj.toISOString().split('T')[0];

      families.push({
        familyID: globalId,
        nationalID,
        name: fullName,
        gender: 'ذكر',
        birthDate: `${birthYear}-${birthMonth}-${birthDay}`,
        age: 2026 - birthYear,
        maritalStatus: 'متزوج',
        deathStatus: 'على قيد الحياة',
        deathDate: '',
        primaryPhone: `0599${String(100000 + (globalId * 313) % 900000)}`,
        alternativePhone1: `0569${String(200000 + (globalId * 419) % 900000)}`,
        alternativePhone2: '',
        wifeName: wName,
        wifeNationalID,
        membersCount,
        damageType,
        damageDescription: damageType === 'أضرار كلية' ? 'تدمير كامل للمبنى المكون من طابقين' : 'تصدع وسقوط جدران وتشظي الأسقف',
        injuryStatus: (globalId % 4 === 0) ? 'مصاب حرب' : 'سليم',
        injuryDate: (globalId % 4 === 0) ? '2023-11-20' : '',
        incomeSource1: (globalId % 3 === 0) ? 'عمال مياومة' : 'بلا عمل',
        incomeSource2: '',
        rationCardNumber: `UN-${String(7000000 + globalId * 97).slice(-7)}-01`,
        originalMainArea: 'غزة',
        originalSubArea: sub.name,
        originalBranch: 'الشعبة المركزية',
        originalMosque: mosques[(globalId) % mosques.length],
        currentMainArea: 'غزة',
        currentSubArea: sub.name,
        currentBranch: 'الشعبة الميدانية',
        currentMosque: mosques[(globalId + 1) % mosques.length],
        developmentApproval,
        localityApproval: 'معتمد مناطق',
        residentStatus,
        worksApproval,
        shelterStatus,
        campOrCenterName: shelterStatus === 'إيواء داخلي' ? `مركز إيواء ${sub.name}` : '',
        notes: (globalId % 5 === 0) ? 'أسرة ذات أولوية خاصة بسبب أضرار جسيمة' : '',
        localityID: sub.localityId,
        localityName: sub.localityName,
        lastAidDate: lastAidDateStr,
        lastAidType: 'غذائي'
      });

      globalId++;
    }
  });

  return families;
}
