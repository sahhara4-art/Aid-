import JSZip from 'jszip';
import { androidProjectFiles } from '../androidProjectFiles';

export async function downloadAndroidProjectZip() {
  // First attempt: fetch pre-packaged complete APK source archive
  try {
    const response = await fetch('/humanitarian-aid-management-apk-source.zip');
    if (response.ok) {
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'HumanitarianAidManagement-APK-Ready.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      return;
    }
  } catch (e) {
    console.warn('Direct ZIP fetch unavailable, falling back to JSZip generator', e);
  }

  // Fallback: Generate via JSZip
  const zip = new JSZip();
  for (const file of androidProjectFiles) {
    if (file.isBinary) {
      zip.file(file.path, file.content, { base64: true });
    } else {
      zip.file(file.path, file.content);
    }
  }

  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 }
  });

  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'HumanitarianAidManagement-APK-Ready.zip';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
