export interface SubAreaItem {
  id: number;
  name: string;
  code: string;
  localityId: number;
  localityName: string;
  targetFamiliesQuota: number;
  registeredFamiliesCount: number;
  nominatedCount: number;
  deliveredCount: number;
  activeSupervisorsCount: number;
  isActive: boolean;
  notes?: string;
}

export const INITIAL_SUB_AREAS_DATA: SubAreaItem[] = [
  {
    id: 1,
    name: 'الرمال الشمالي',
    code: 'GZ-RML-N',
    localityId: 1,
    localityName: 'مدينة غزة',
    targetFamiliesQuota: 3500,
    registeredFamiliesCount: 3120,
    nominatedCount: 1850,
    deliveredCount: 1420,
    activeSupervisorsCount: 6,
    isActive: true,
    notes: 'تشمل شارع النصر، محيط مجمع الشفاء، وحي الميناء'
  },
  {
    id: 2,
    name: 'الشيخ رضوان',
    code: 'GZ-SH-RDW',
    localityId: 1,
    localityName: 'مدينة غزة',
    targetFamiliesQuota: 4200,
    registeredFamiliesCount: 3950,
    nominatedCount: 2600,
    deliveredCount: 2180,
    activeSupervisorsCount: 8,
    isActive: true,
    notes: 'مركزية توزيع كبرى - تضم مستودع الشيخ رضوان'
  },
  {
    id: 3,
    name: 'الشاطئ الشمالي والنصر',
    code: 'GZ-SHT-NSR',
    localityId: 1,
    localityName: 'مدينة غزة',
    targetFamiliesQuota: 3800,
    registeredFamiliesCount: 3410,
    nominatedCount: 1980,
    deliveredCount: 1540,
    activeSupervisorsCount: 5,
    isActive: true,
    notes: 'كثافة سكانية ونزوح مرتفع - مخيم الشاطئ والنصر'
  },
  {
    id: 4,
    name: 'الشاطئ الجنوبي',
    code: 'GZ-SHT-SOU',
    localityId: 1,
    localityName: 'مدينة غزة',
    targetFamiliesQuota: 2900,
    registeredFamiliesCount: 2640,
    nominatedCount: 1420,
    deliveredCount: 1190,
    activeSupervisorsCount: 4,
    isActive: true,
    notes: 'محاذاة الخط الساحلي'
  },
  {
    id: 5,
    name: 'مشروع عامر',
    code: 'GZ-PRJ-AMR',
    localityId: 2,
    localityName: 'شمال غزة',
    targetFamiliesQuota: 2200,
    registeredFamiliesCount: 1980,
    nominatedCount: 1100,
    deliveredCount: 920,
    activeSupervisorsCount: 3,
    isActive: true,
    notes: 'منطقة حدودية مستهدفة ببرامج الإغاثة السريعة'
  }
];

// Helper to evaluate geographic permissions for any role/user in Room DB or Backend
export interface SubAreaPermissionCheck {
  isAllowed: boolean;
  reason?: string;
  scope: 'all' | 'restricted' | 'none';
  matchedSubAreas: string[];
}

export function checkGeographicPermission(
  allowedList: string[] | undefined,
  targetSubArea: string,
  actionLabel: string,
  roleName: string
): SubAreaPermissionCheck {
  if (!allowedList || allowedList.length === 0) {
    return {
      isAllowed: false,
      reason: `الدور (${roleName}) غير مصرح له بأي منطقة جغرافية لإجراء [${actionLabel}].`,
      scope: 'none',
      matchedSubAreas: []
    };
  }

  if (allowedList.includes('*')) {
    return {
      isAllowed: true,
      scope: 'all',
      matchedSubAreas: ['*']
    };
  }

  const isMatched = allowedList.includes(targetSubArea);
  return {
    isAllowed: isMatched,
    reason: isMatched
      ? undefined
      : `الدور (${roleName}) مقيد جغرافياً وغير مصرح له بإجراء [${actionLabel}] في المنطقة (${targetSubArea}). المناطق المصرحة له: ${allowedList.join('، ')}.`,
    scope: 'restricted',
    matchedSubAreas: allowedList
  };
}
