// ==================== مصفوفة الشاشات والإجراءات التفصيلية ====================

export type AppScreenId = 'dashboard' | 'families' | 'nomination' | 'delivery' | 'reports' | 'users' | 'backup';

export interface ScreenActionDef {
  key: string;
  name: string;
  description: string;
  isDestructive?: boolean;
}

export interface ScreenDefinition {
  id: AppScreenId;
  name: string;
  shortName: string;
  iconName: string;
  description: string;
  badge: string;
  isManagerRestricted?: boolean;
  actions: ScreenActionDef[];
}

export const APP_SCREENS_CATALOG: ScreenDefinition[] = [
  {
    id: 'dashboard',
    name: 'الرئيسية ولوحة المؤشرات العامة',
    shortName: 'الرئيسية',
    iconName: 'Home',
    description: 'استعراض المؤشرات الحية، أعداد المستفيدين، نسب التوزيع، وحالة المنظومة',
    badge: 'مؤشرات',
    actions: [
      { key: 'view', name: 'معاينة المؤشرات والإحصائيات', description: 'الاطلاع على العدادات الحية ونسب المحليات' },
      { key: 'export', name: 'تصدير ملخص المؤشرات', description: 'تصدير وطباعة بطاقة أداء التوزيع' },
      { key: 'role_switch', name: 'استخدام محاكي تبديل الأدوار', description: 'اختبار واجهة النظام كأدوار أخرى' }
    ]
  },
  {
    id: 'families',
    name: 'سجل الأسر والمواطنين (36 حقلاً)',
    shortName: 'الأسر والمواطنون',
    iconName: 'Users',
    description: 'إدارة وتدقيق وتصفية بيانات الأسر، حالات الإيواء، واعتمادات التنمية والأشغال',
    badge: 'بيانات الأسر',
    actions: [
      { key: 'view', name: 'استعراض وبحث بيانات الأسر', description: 'تصفح كشوفات المواطنين والفرز حسب المحلية' },
      { key: 'create', name: 'تسجيل وإضافة مواطن جديد', description: 'إدخال بيانات رب أسرة وأفراد جدد' },
      { key: 'edit', name: 'تعديل السجلات وحالات الاعتماد', description: 'تعديل بيانات المواطن واعتماد التنمية والأشغال' },
      { key: 'delete', name: 'تجميد وحذف ملفات المواطنين', description: 'حذف السجلات أو تجميد حالتها', isDestructive: true },
      { key: 'export', name: 'تصدير الكشوفات (Excel / SQL)', description: 'توليد ملفات الجداول والنسخ' }
    ]
  },
  {
    id: 'nomination',
    name: 'محرك الترشيح والمفاضلة الخوارزمية',
    shortName: 'الترشيح والمفاضلة',
    iconName: 'Shield',
    description: 'تطبيق خوارزميات الأولوية، معايير الفلترة، استبعاد المستفيدين، والترشيح الميداني',
    badge: 'المفاضلة',
    actions: [
      { key: 'view', name: 'استعراض قوائم ومراحل الترشيح', description: 'معاينة شجرة المعايير وفلترة النتائج' },
      { key: 'run_auto', name: 'تشغيل محرك المفاضلة والترشيح الآلي', description: 'تنفيذ خوارزمية الفرز وحساب السكور المركب' },
      { key: 'manual', name: 'الترشيح اليدوي للحالات الخاصة', description: 'إدراج أسر استثنائية يدوياً في كشوفات المشروع' },
      { key: 'criteria', name: 'تعديل معايير واشتراطات الأولوية', description: 'تغيير شروط الأطفال وحجم الأسرة ونقاط الهشاشة' },
      { key: 'approve', name: 'اعتماد وترحيل المرشحين للصرف', description: 'إرسال قوائم المرشحين النهائية للمستودعات' }
    ]
  },
  {
    id: 'delivery',
    name: 'التسليم والصرف الميداني',
    shortName: 'التسليم والصرف',
    iconName: 'PackageCheck',
    description: 'تنفيذ التسليم الفوري، التحقق بالباركود و QR، وتوثيق استلام الطرود وسندات الصرف',
    badge: 'ميداني',
    actions: [
      { key: 'view', name: 'استعراض قوائم المستفيدين الجاهزين', description: 'معاينة المستحقين والبحث برقم الهوية' },
      { key: 'handover', name: 'تنفيذ صرف وتسليم المساعدات', description: 'توثيق التسليم، اسم المستلم، وملاحظات الطرد' },
      { key: 'print_receipt', name: 'طباعة وتصدير سند الاستلام الرسمي', description: 'إصدار سند صرف معتمد وتوقيع' },
      { key: 'undo', name: 'التراجع عن تسليم مساعدة', description: 'إلغاء عملية التسليم وإعادة السجل للانتظار', isDestructive: true },
      { key: 'scanner', name: 'استخدام كاميرا مسح الباركود و QR', description: 'التحقق السريع من الهوية وكرت المؤن' }
    ]
  },
  {
    id: 'reports',
    name: 'التقارير والكشوفات وتصدير PDF',
    shortName: 'التقارير والكشوفات',
    iconName: 'FileText',
    description: 'إصدار التقارير الإحصائية، كشوفات التوزيع الرسمية للطباعة، وتوليد وثائق PDF',
    badge: 'تقارير رسمية',
    actions: [
      { key: 'view', name: 'الاطلاع على المؤشرات والتقارير', description: 'استعراض تقارير التوزيع والأسر' },
      { key: 'pdf_export', name: 'توليد وتصدير كشوفات PDF رسمية', description: 'تحميل ملفات PDF عالية الدقة للمشاركة والطباعة' },
      { key: 'print', name: 'أمر الطباعة المباشرة', description: 'إرسال المستندات إلى طابعات الشبكة أو أندرويد' }
    ]
  },
  {
    id: 'users',
    name: 'لوحة التحكم الإدارية وإدارة الصلاحيات والأمان',
    shortName: 'الإدارة والأمان',
    iconName: 'ShieldAlert',
    description: 'تعريف الأدوار، ربط الصلاحيات بالشاشات، ضبط الفترات الزمنية ومحاولات الدخول، ومراقبة السجلات',
    badge: 'بيد المدير',
    isManagerRestricted: true,
    actions: [
      { key: 'view', name: 'الاطلاع على لوحة الأمان والمستخدمين', description: 'استعراض إحصائيات الأمان وقائمة الحسابات' },
      { key: 'manage_roles', name: 'تعريف وإدارة الأدوار وربط الشاشات', description: 'إنشاء وتعديل الأدوار وربطها بصلاحيات الشاشات' },
      { key: 'manage_users', name: 'إنشاء وتعديل وتجميد حسابات المستخدمين', description: 'تعديل بيانات الحسابات وكلمات المرور والحصص' },
      { key: 'manage_security', name: 'ضبط الفترات الزمنية ومحاولات الدخول', description: 'تحديد ساعات الدوام، أيام العمل، والحد الأقصى للمحاولات' },
      { key: 'audit_logs', name: 'فحص ومراقبة سجل التدقيق الأمني', description: 'استعراض محاولات الدخول الفاشلة وعمليات النظام' }
    ]
  },
  {
    id: 'backup',
    name: 'إدارة النسخ الاحتياطي للنظام (Room DB)',
    shortName: 'النسخ الاحتياطي',
    iconName: 'Database',
    description: 'توليد واستعادة النسخ الاحتياطية لقواعد البيانات المشفرة والدمج الميداني',
    badge: 'بيانات',
    actions: [
      { key: 'create', name: 'توليد نسخة احتياطية فورية (JSON/SQL)', description: 'تصدير كامل قاعدة البيانات للهاتف أو السحابة' },
      { key: 'restore', name: 'استعادة ودمج البيانات السابقة', description: 'تحميل ملف نسخة احتياطية وتحديث السجلات', isDestructive: true },
      { key: 'download', name: 'تنزيل وحفظ ملف النسخة محلياً', description: 'حفظ النسخة في مجلد التنزيلات' }
    ]
  }
];

// ==================== المناطق الفرعية الحالية (الـ 5 مناطق المعتمدة بالنظام) ====================
export const CURRENT_SUB_AREAS = [
  'الرمال الشمالي',
  'الشيخ رضوان',
  'الشاطئ الشمالي والنصر',
  'الشاطئ الجنوبي',
  'مشروع عامر'
] as const;

export type CurrentSubArea = typeof CURRENT_SUB_AREAS[number];

// ==================== أيام الأسبوع ====================
export const WEEK_DAYS = [
  'الأحد',
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت'
] as const;

// ==================== تعريف الدور الوظيفي ====================
export interface SystemRole {
  id: number;
  name: string;
  badge: string;
  color: 'rose' | 'indigo' | 'sky' | 'emerald' | 'amber' | 'purple' | 'teal';
  description: string;
  isManager: boolean;
  // الشاشات المصرح بها
  allowedScreens: AppScreenId[];
  defaultScreens?: AppScreenId[];
  defaultPermissions?: string[];
  // مصفوفة الصلاحيات التفصيلية لكل شاشة: { [screenId]: ['view', 'create', ...] }
  screenPermissions: Record<AppScreenId, string[]>;
  // النطاقات الجغرافية الافتراضية
  defaultViewSubAreas: string[];
  defaultNominationSubAreas: string[];
  defaultDeliverySubAreas: string[];
  defaultEditSubAreas: string[];
  // قيود أمان مقترحة للدور
  defaultMaxLogins: number; // 0 = غير محدود
  defaultMaxFailedAttempts: number; // الافتراضي لمحاولات الدخول الخاطئة
  defaultSessionDuration: number; // بالدقائق
  defaultStartTime: string;
  defaultEndTime: string;
}

// الأدوار الافتراضية المجهزة
export const INITIAL_SYSTEM_ROLES: SystemRole[] = [
  {
    id: 1,
    name: 'مدير النظام العام (Super Admin / Manager)',
    badge: 'مدير عام',
    color: 'rose',
    description: 'صلاحيات كاملة وشاملة في كافة الشاشات والمناطق. إدارة المستخدمين، تعريف الأدوار، ضبط الفترات الزمنية ومحاولات الدخول تكون بيده حصرياً.',
    isManager: true,
    allowedScreens: ['dashboard', 'families', 'nomination', 'delivery', 'reports', 'users', 'backup'],
    screenPermissions: {
      dashboard: ['view', 'export', 'role_switch'],
      families: ['view', 'create', 'edit', 'delete', 'export'],
      nomination: ['view', 'run_auto', 'manual', 'criteria', 'approve'],
      delivery: ['view', 'handover', 'print_receipt', 'undo', 'scanner'],
      reports: ['view', 'pdf_export', 'print'],
      users: ['view', 'manage_roles', 'manage_users', 'manage_security', 'audit_logs'],
      backup: ['create', 'restore', 'download']
    },
    defaultViewSubAreas: ['*'],
    defaultNominationSubAreas: ['*'],
    defaultDeliverySubAreas: ['*'],
    defaultEditSubAreas: ['*'],
    defaultMaxLogins: 0,
    defaultMaxFailedAttempts: 5,
    defaultSessionDuration: 480,
    defaultStartTime: '00:00',
    defaultEndTime: '23:59'
  },
  {
    id: 2,
    name: 'مسؤول الترشيح والمفاضلة (Nomination Officer)',
    badge: 'مسؤول ترشيح',
    color: 'indigo',
    description: 'تشغيل محرك المفاضلة، الترشيح الآلي واليدوي، وتعديل معايير الأولوية. مقيد بالمناطق الفرعية المصرح له بها (منطقة واحدة أو أكثر)، ومحجوب عن شاشات الصرف والإدارة.',
    isManager: false,
    allowedScreens: ['dashboard', 'families', 'nomination', 'reports'],
    screenPermissions: {
      dashboard: ['view', 'export'],
      families: ['view', 'export'],
      nomination: ['view', 'run_auto', 'manual', 'criteria', 'approve'],
      delivery: [],
      reports: ['view', 'pdf_export'],
      users: [],
      backup: []
    },
    defaultViewSubAreas: ['الشيخ رضوان', 'مشروع عامر'],
    defaultNominationSubAreas: ['الشيخ رضوان'],
    defaultDeliverySubAreas: [],
    defaultEditSubAreas: ['الشيخ رضوان'],
    defaultMaxLogins: 25,
    defaultMaxFailedAttempts: 3,
    defaultSessionDuration: 120,
    defaultStartTime: '08:00',
    defaultEndTime: '17:00'
  },
  {
    id: 3,
    name: 'أمين مستودع وصرف ميداني (Warehouse Delivery Officer)',
    badge: 'أمين مستودع',
    color: 'sky',
    description: 'تسليم الطرود، مسح الباركود، واعتماد سندات الصرف للمناطق والمستودعات المصرح بها فقط. محجوب عن محرك الترشيح وشاشات الإعدادات.',
    isManager: false,
    allowedScreens: ['dashboard', 'families', 'delivery'],
    screenPermissions: {
      dashboard: ['view'],
      families: ['view'],
      nomination: [],
      delivery: ['view', 'handover', 'print_receipt', 'undo', 'scanner'],
      reports: [],
      users: [],
      backup: []
    },
    defaultViewSubAreas: ['الرمال الشمالي', 'الشاطئ الجنوبي'],
    defaultNominationSubAreas: [],
    defaultDeliverySubAreas: ['الرمال الشمالي', 'الشاطئ الجنوبي'],
    defaultEditSubAreas: [],
    defaultMaxLogins: 15,
    defaultMaxFailedAttempts: 3,
    defaultSessionDuration: 60,
    defaultStartTime: '08:00',
    defaultEndTime: '16:00'
  },
  {
    id: 4,
    name: 'باحث ميداني ومدخل بيانات (Field Researcher / Data Entry)',
    badge: 'باحث ميداني',
    color: 'emerald',
    description: 'تسجيل وتحديث بيانات الأسر والمواطنين وتدقيق حالات الإيواء ضمن منطقة فرعية محددة فقط. لا يملك صلاحيات ترشيح أو تسليم أو وصول للشاشات الإدارية.',
    isManager: false,
    allowedScreens: ['dashboard', 'families'],
    screenPermissions: {
      dashboard: ['view'],
      families: ['view', 'create', 'edit'],
      nomination: [],
      delivery: [],
      reports: [],
      users: [],
      backup: []
    },
    defaultViewSubAreas: ['الرمال الشمالي'],
    defaultNominationSubAreas: [],
    defaultDeliverySubAreas: [],
    defaultEditSubAreas: ['الرمال الشمالي'],
    defaultMaxLogins: 10,
    defaultMaxFailedAttempts: 3,
    defaultSessionDuration: 45,
    defaultStartTime: '08:30',
    defaultEndTime: '15:30'
  },
  {
    id: 5,
    name: 'مدقق ومراقب جودة (Auditor / Inspector)',
    badge: 'مدقق ومراقب',
    color: 'amber',
    description: 'معاينة ورقابة الكشوفات، سندات الصرف، والتقارير في مناطق مخصصة (عرض ومعاينة فقط بدون حق التعديل أو الصرف أو الترشيح).',
    isManager: false,
    allowedScreens: ['dashboard', 'families', 'delivery', 'reports'],
    screenPermissions: {
      dashboard: ['view', 'export'],
      families: ['view'],
      nomination: [],
      delivery: ['view', 'print_receipt'],
      reports: ['view', 'pdf_export'],
      users: [],
      backup: []
    },
    defaultViewSubAreas: ['الشيخ رضوان', 'الشاطئ الشمالي والنصر', 'مشروع عامر'],
    defaultNominationSubAreas: [],
    defaultDeliverySubAreas: [],
    defaultEditSubAreas: [],
    defaultMaxLogins: 20,
    defaultMaxFailedAttempts: 4,
    defaultSessionDuration: 90,
    defaultStartTime: '08:00',
    defaultEndTime: '18:00'
  }
];

// ==================== تعريف حساب المستخدم ====================
export interface MockUser {
  id: number;
  username: string;
  password: string;
  fullName: string;
  nationalID: string;
  email?: string;
  phone?: string;
  roleId: number;
  roleName: string;
  
  // ================= ضوابط وقيود الفترات الزمنية (Time Periods) =================
  allowedStartTime: string; // "08:00"
  allowedEndTime: string; // "17:00"
  allowedDays?: string[]; // أيام الأسبوع المصرح بالدخول فيها
  accountExpiryDate?: string; // تاريخ انتهاء الصلاحية "2026-12-31"
  sessionDurationMinutes: number; // مدة الجلسة القصوى بالدقائق (e.g. 60)
  
  // ================= ضوابط وقيود محاولات الدخول (Login Attempts & Quota) =================
  maxFailedAttempts?: number; // الحد الأقصى للمحاولات الخاطئة المتتالية قبل قفل الحساب (e.g. 3 أو 5)
  failedAttempts: number; // عدد المحاولات الخاطئة الحالية
  isLocked: boolean; // هل الحساب مقفل؟
  lockReason?: string; // سبب قفل الحساب
  lockedAt?: string; // وقت القفل
  maxAllowedLogins: number; // الحد الأقصى الإجمالي لعدد مرات الدخول (0 = غير محدود)
  consumedLogins: number; // عدد مرات الدخول المستهلكة
  
  // ================= النطاق الجغرافي والتشغيلي =================
  allowedWarehouse: string;
  allowedLocalityName: string;
  allowedViewSubAreas: string[];
  allowedNominationSubAreas: string[];
  allowedDeliverySubAreas: string[];
  allowedEditSubAreas: string[];

  // ================= الشاشات والصلاحيات التفصيلية =================
  allowedScreens: AppScreenId[];
  screenPermissions?: Record<AppScreenId, string[]>;
  permissions: string[]; // المفاتيح العامة المتوافقة مع الكود القديم
  
  // الحالة والنشاط
  isActive: boolean;
  lastLogin?: string;
  createdDate: string;
  createdBy: string;
}

// الحسابات الافتراضية
export const INITIAL_USERS: MockUser[] = [
  {
    id: 1,
    username: 'admin',
    password: 'admin123',
    fullName: 'م. أحمد الشوا (مدير النظام العام)',
    nationalID: '401234567',
    email: 'admin@humanitarian-aid.ps',
    phone: '0599112233',
    roleId: 1,
    roleName: 'مدير النظام العام (Super Admin / Manager)',
    allowedStartTime: '00:00',
    allowedEndTime: '23:59',
    allowedDays: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'],
    sessionDurationMinutes: 480,
    maxFailedAttempts: 5,
    failedAttempts: 0,
    isLocked: false,
    maxAllowedLogins: 0, // غير محدود
    consumedLogins: 42,
    allowedWarehouse: 'كافة المستودعات (عام)',
    allowedLocalityName: 'كافة المحليات',
    allowedViewSubAreas: ['*'],
    allowedNominationSubAreas: ['*'],
    allowedDeliverySubAreas: ['*'],
    allowedEditSubAreas: ['*'],
    allowedScreens: ['dashboard', 'families', 'nomination', 'delivery', 'reports', 'users', 'backup'],
    screenPermissions: {
      dashboard: ['view', 'export', 'role_switch'],
      families: ['view', 'create', 'edit', 'delete', 'export'],
      nomination: ['view', 'run_auto', 'manual', 'criteria', 'approve'],
      delivery: ['view', 'handover', 'print_receipt', 'undo', 'scanner'],
      reports: ['view', 'pdf_export', 'print'],
      users: ['view', 'manage_roles', 'manage_users', 'manage_security', 'audit_logs'],
      backup: ['create', 'restore', 'download']
    },
    permissions: [
      'families_view', 'families_create', 'families_edit', 'families_delete', 'families_export',
      'nomination_run', 'nomination_manual', 'nomination_criteria', 'nomination_approve',
      'delivery_handover', 'delivery_receipt_print', 'delivery_undo', 'delivery_scanner',
      'projects_manage', 'warehouse_manage', 'reports_view', 'reports_pdf_export',
      'users_manage', 'permissions_edit', 'audit_logs_view', 'backup_restore'
    ],
    isActive: true,
    lastLogin: '2026-10-09 09:30',
    createdDate: '2026-01-01',
    createdBy: 'النظام الأساسي'
  },
  {
    id: 2,
    username: 'nomination_officer',
    password: 'nom123',
    fullName: 'أ. سامي رضوان (مسؤول الترشيح - الشيخ رضوان)',
    nationalID: '402345678',
    email: 'sami.nom@humanitarian-aid.ps',
    phone: '0599223344',
    roleId: 2,
    roleName: 'مسؤول الترشيح والمفاضلة (Nomination Officer)',
    allowedStartTime: '08:00',
    allowedEndTime: '17:00',
    allowedDays: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'],
    accountExpiryDate: '2026-12-31',
    sessionDurationMinutes: 120,
    maxFailedAttempts: 3,
    failedAttempts: 0,
    isLocked: false,
    maxAllowedLogins: 25,
    consumedLogins: 11,
    allowedWarehouse: 'مستودع الشيخ رضوان المركزي',
    allowedLocalityName: 'الشيخ رضوان',
    allowedViewSubAreas: ['الشيخ رضوان', 'مشروع عامر'],
    allowedNominationSubAreas: ['الشيخ رضوان'],
    allowedDeliverySubAreas: [],
    allowedEditSubAreas: ['الشيخ رضوان'],
    allowedScreens: ['dashboard', 'families', 'nomination', 'reports'],
    screenPermissions: {
      dashboard: ['view', 'export'],
      families: ['view', 'export'],
      nomination: ['view', 'run_auto', 'manual', 'criteria', 'approve'],
      delivery: [],
      reports: ['view', 'pdf_export'],
      users: [],
      backup: []
    },
    permissions: [
      'families_view', 'families_export',
      'nomination_run', 'nomination_manual', 'nomination_criteria', 'nomination_approve',
      'reports_view', 'reports_pdf_export'
    ],
    isActive: true,
    lastLogin: '2026-10-09 08:45',
    createdDate: '2026-01-15',
    createdBy: 'admin'
  },
  {
    id: 3,
    username: 'warehouse_officer',
    password: 'wh123',
    fullName: 'أ. خالد الرملاوي (أمين مستودع الرمال)',
    nationalID: '403456789',
    email: 'khaled.wh@humanitarian-aid.ps',
    phone: '0599334455',
    roleId: 3,
    roleName: 'أمين مستودع وصرف ميداني (Warehouse Delivery Officer)',
    allowedStartTime: '08:00',
    allowedEndTime: '16:00',
    allowedDays: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'],
    accountExpiryDate: '2026-11-30',
    sessionDurationMinutes: 60,
    maxFailedAttempts: 3,
    failedAttempts: 0,
    isLocked: false,
    maxAllowedLogins: 15,
    consumedLogins: 8,
    allowedWarehouse: 'مستودع الرمال الإغاثي',
    allowedLocalityName: 'الرمال الشمالي',
    allowedViewSubAreas: ['الرمال الشمالي', 'الشاطئ الجنوبي'],
    allowedNominationSubAreas: [],
    allowedDeliverySubAreas: ['الرمال الشمالي', 'الشاطئ الجنوبي'],
    allowedEditSubAreas: [],
    allowedScreens: ['dashboard', 'families', 'delivery'],
    screenPermissions: {
      dashboard: ['view'],
      families: ['view'],
      nomination: [],
      delivery: ['view', 'handover', 'print_receipt', 'undo', 'scanner'],
      reports: [],
      users: [],
      backup: []
    },
    permissions: [
      'families_view',
      'delivery_handover', 'delivery_receipt_print', 'delivery_undo', 'delivery_scanner',
      'warehouse_manage'
    ],
    isActive: true,
    lastLogin: '2026-10-08 14:10',
    createdDate: '2026-02-01',
    createdBy: 'admin'
  },
  {
    id: 4,
    username: 'field_researcher',
    password: 'field123',
    fullName: 'م. مريم حسونة (باحثة ميدانية - الرمال الشمالي)',
    nationalID: '404567890',
    email: 'maryam.field@humanitarian-aid.ps',
    phone: '0599445566',
    roleId: 4,
    roleName: 'باحث ميداني ومدخل بيانات (Field Researcher / Data Entry)',
    allowedStartTime: '08:30',
    allowedEndTime: '15:30',
    allowedDays: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'],
    accountExpiryDate: '2026-12-31',
    sessionDurationMinutes: 30,
    maxFailedAttempts: 3,
    failedAttempts: 0,
    isLocked: false,
    maxAllowedLogins: 10,
    consumedLogins: 3,
    allowedWarehouse: 'مركز التوزيع 02',
    allowedLocalityName: 'الرمال الشمالي',
    allowedViewSubAreas: ['الرمال الشمالي'],
    allowedNominationSubAreas: [],
    allowedDeliverySubAreas: [],
    allowedEditSubAreas: ['الرمال الشمالي'],
    allowedScreens: ['dashboard', 'families'],
    screenPermissions: {
      dashboard: ['view'],
      families: ['view', 'create', 'edit'],
      nomination: [],
      delivery: [],
      reports: [],
      users: [],
      backup: []
    },
    permissions: ['families_view', 'families_create', 'families_edit'],
    isActive: true,
    lastLogin: '2026-10-09 09:15',
    createdDate: '2026-02-10',
    createdBy: 'admin'
  },
  {
    id: 5,
    username: 'auditor_quality',
    password: 'audit123',
    fullName: 'د. يوسف النجار (مدقق ومراقب جودة)',
    nationalID: '405678901',
    email: 'yousef.audit@humanitarian-aid.ps',
    phone: '0599556677',
    roleId: 5,
    roleName: 'مدقق ومراقب جودة (Auditor / Inspector)',
    allowedStartTime: '08:00',
    allowedEndTime: '18:00',
    allowedDays: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'السبت'],
    accountExpiryDate: '2026-10-31',
    sessionDurationMinutes: 90,
    maxFailedAttempts: 4,
    failedAttempts: 0,
    isLocked: false,
    maxAllowedLogins: 20,
    consumedLogins: 14,
    allowedWarehouse: 'كافة المستودعات (عام)',
    allowedLocalityName: 'كافة المحليات',
    allowedViewSubAreas: ['الشيخ رضوان', 'الشاطئ الشمالي والنصر', 'مشروع عامر'],
    allowedNominationSubAreas: [],
    allowedDeliverySubAreas: [],
    allowedEditSubAreas: [],
    allowedScreens: ['dashboard', 'families', 'delivery', 'reports'],
    screenPermissions: {
      dashboard: ['view', 'export'],
      families: ['view'],
      nomination: [],
      delivery: ['view', 'print_receipt'],
      reports: ['view', 'pdf_export'],
      users: [],
      backup: []
    },
    permissions: ['families_view', 'reports_view'],
    isActive: true,
    lastLogin: '2026-10-07 11:20',
    createdDate: '2026-02-15',
    createdBy: 'admin'
  },
  {
    id: 6,
    username: 'test_locked_user',
    password: 'pass123',
    fullName: 'طارق المصري (حساب مقفل - اختبار تجاوز المحاولات)',
    nationalID: '406789012',
    email: 'tariq.locked@humanitarian-aid.ps',
    phone: '0599667788',
    roleId: 4,
    roleName: 'باحث ميداني ومدخل بيانات (Field Researcher / Data Entry)',
    allowedStartTime: '08:00',
    allowedEndTime: '17:00',
    allowedDays: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس'],
    accountExpiryDate: '2026-12-31',
    sessionDurationMinutes: 30,
    maxFailedAttempts: 3,
    failedAttempts: 3,
    isLocked: true,
    lockReason: 'تم قفل الحساب تلقائياً لتجاوز الحد الأقصى لمحاولات الدخول الخاطئة (3 محاولات)',
    lockedAt: '2026-10-09 08:12',
    maxAllowedLogins: 10,
    consumedLogins: 2,
    allowedWarehouse: 'مستودع الشيخ رضوان',
    allowedLocalityName: 'الشيخ رضوان',
    allowedViewSubAreas: ['الشيخ رضوان'],
    allowedNominationSubAreas: [],
    allowedDeliverySubAreas: [],
    allowedEditSubAreas: ['الشيخ رضوان'],
    allowedScreens: ['dashboard', 'families'],
    screenPermissions: {
      dashboard: ['view'],
      families: ['view'],
      nomination: [],
      delivery: [],
      reports: [],
      users: [],
      backup: []
    },
    permissions: ['families_view'],
    isActive: true,
    lastLogin: '2026-10-08 16:00',
    createdDate: '2026-03-01',
    createdBy: 'admin'
  }
];

// ==================== سجل التدقيق الأمني ====================
export interface AuditLog {
  id: string;
  userId: number;
  username: string;
  action: string;
  timestamp: string;
  ip: string;
  device: string;
  status: 'ناجح' | 'مرفوض' | 'تحذير أمني';
  details: string;
}

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'LOG-1001',
    userId: 1,
    username: 'admin',
    action: 'تسجيل دخول ناجح للمنظومة',
    timestamp: '2026-10-09 09:30:15',
    ip: '192.168.1.10',
    device: 'Chrome Windows / Admin Station',
    status: 'ناجح',
    details: 'بدء جلسة عمل جديدة بصلاحيات كاملة للمدير العام.'
  },
  {
    id: 'LOG-1002',
    userId: 2,
    username: 'nomination_officer',
    action: 'تشغيل محرك المفاضلة والترشيح الآلي',
    timestamp: '2026-10-09 08:52:40',
    ip: '192.168.1.45',
    device: 'Samsung Galaxy Tab A9',
    status: 'ناجح',
    details: 'تنفيذ الترشيح لمنطقة (الشيخ رضوان) - استخراج 250 أسرة مرشحة.'
  },
  {
    id: 'LOG-1003',
    userId: 6,
    username: 'test_locked_user',
    action: 'محاولة دخول فاشلة - كلمة مرور غير صحيحة',
    timestamp: '2026-10-09 08:11:10',
    ip: '192.168.1.92',
    device: 'Xiaomi Redmi Note 12',
    status: 'تحذير أمني',
    details: 'محاولة الدخول 3 من 3. تم قفل الحساب تلقائياً لتجاوز الحد المسموح.'
  },
  {
    id: 'LOG-1004',
    userId: 4,
    username: 'field_researcher',
    action: 'محاولة دخول خارج ساعات العمل',
    timestamp: '2026-10-08 21:15:00',
    ip: '192.168.1.66',
    device: 'Tecno Spark 10',
    status: 'مرفوض',
    details: 'رفض تسجيل الدخول: الوقت 21:15 يقع خارج نافذة ساعات الدوام (08:30 - 15:30).'
  },
  {
    id: 'LOG-1005',
    userId: 1,
    username: 'admin',
    action: 'تعديل مصفوفة صلاحيات الشاشات لدور الترشيح',
    timestamp: '2026-10-08 15:40:22',
    ip: '192.168.1.10',
    device: 'Admin Station Workstation',
    status: 'ناجح',
    details: 'ربط صلاحيات شاشة الترشيح والتقارير وسحب صلاحيات شاشات الصرف والمستودع.'
  }
];

// ==================== دوال فحص وتحقق الأمان ====================

/**
 * فحص ما إذا كان المستخدم مصرحاً له بدخول شاشة معينة
 */
export function isUserScreenAllowed(user: MockUser | null, screenId: AppScreenId): boolean {
  if (!user) return false;
  if (user.roleId === 1) return true;
  return user.allowedScreens.includes(screenId);
}

/**
 * فحص ما إذا كان المستخدم يملك إجراءً محدداً في شاشة معينة
 */
export function isUserActionAllowed(user: MockUser | null, screenId: AppScreenId, actionKey: string): boolean {
  if (!user) return false;
  if (user.roleId === 1) return true;
  if (!isUserScreenAllowed(user, screenId)) return false;
  
  const perms = user.screenPermissions?.[screenId];
  if (!perms) return false;
  return perms.includes(actionKey);
}

/**
 * فحص ما إذا كان الوقت الحالي يقع ضمن ساعات العمل المصرح بها للمستخدم
 */
export function checkUserWorkingHours(user: MockUser, checkTime?: string): { isAllowed: boolean; message?: string } {
  if (!user.allowedStartTime || !user.allowedEndTime) return { isAllowed: true };
  if (user.allowedStartTime === '00:00' && user.allowedEndTime === '23:59') return { isAllowed: true };
  if (user.roleId === 1) return { isAllowed: true }; // المدير مستثنى
  
  let currentHHMM = checkTime;
  if (!currentHHMM) {
    const now = new Date();
    currentHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  }

  if (currentHHMM < user.allowedStartTime || currentHHMM > user.allowedEndTime) {
    return {
      isAllowed: false,
      message: `الوقت الحالي (${currentHHMM}) خارج ساعات العمل المصرح بها لحسابك (${user.allowedStartTime} إلى ${user.allowedEndTime}).`
    };
  }

  return { isAllowed: true };
}

/**
 * فحص ما إذا كان اليوم الحالي مصرحاً به للمستخدم
 */
export function checkUserWorkingDay(user: MockUser, testDayName?: string): { isAllowed: boolean; message?: string } {
  if (!user.allowedDays || user.allowedDays.length === 0) return { isAllowed: true };
  if (user.roleId === 1) return { isAllowed: true };
  
  let currentDay = testDayName;
  if (!currentDay) {
    const daysArabic = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const now = new Date();
    currentDay = daysArabic[now.getDay()];
  }

  if (!user.allowedDays.includes(currentDay)) {
    return {
      isAllowed: false,
      message: `اليوم (${currentDay}) غير مصرح لك بالعمل فيه وفقاً لجدول العمل المحدد لحسابك.`
    };
  }

  return { isAllowed: true };
}
