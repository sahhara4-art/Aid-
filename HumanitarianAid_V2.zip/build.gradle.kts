plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.28" apply false
    id("com.google.gms.google-services") version "4.4.2" apply false
}

// =========================================================================
// مهمة أتمتة ضغط المشروع (Automated Clean Project Packaging Task)
// تضغط المشروع بالكامل في أرشيف ZIP نظيف ومستبعد منه كافة المجلدات المؤقتة
// =========================================================================
tasks.register<Zip>("zipProject") {
    group = "distribution"
    description = "Packs the entire clean Android project into a zip file excluding build and cache directories."

    from(rootDir) {
        exclude("**/build/**")
        exclude("**/.gradle/**")
        exclude("**/.idea/**")
        exclude("**/.git/**")
        exclude("**/*.apk")
        exclude("**/*.aab")
        exclude("**/*.hprof")
        exclude(".DS_Store")
    }

    archiveFileName.set("humanitarian-aid-management-apk-source.zip")
    destinationDirectory.set(file("${rootDir}/../public"))
}

tasks.register("packageProjectZip") {
    group = "distribution"
    description = "Alias for zipProject task."
    dependsOn("zipProject")
}


