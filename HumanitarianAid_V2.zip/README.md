# Android Project - نظام إدارة المساعدات الإنسانية

مشروع أندرويد حقيقي مكتوب بـ Kotlin و Jetpack Compose و Room Database.

للبناء الفوري:
```bash
./gradlew assembleDebug
```
ينتج الملف: `app/build/outputs/apk/debug/app-debug.apk`
