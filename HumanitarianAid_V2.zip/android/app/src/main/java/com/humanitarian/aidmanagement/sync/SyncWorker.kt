package com.humanitarian.aidmanagement.sync

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.humanitarian.aidmanagement.AidApplication
import com.humanitarian.aidmanagement.data.local.entities.SyncLogEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * SyncWorker - عامل التزامن الخلفي المعتمد على WorkManager
 * يشتغل تلقائياً فور توفر اتصال بالإنترنت (NetworkType.CONNECTED)
 * يقرأ جدول sync_queue ويبحث عن الحركات PENDING ويرفعها كـ Deltas إلى Firebase Realtime Database
 * تحت عقدة المحلية التابع لها المندوب، ثم يحدث حالة السجل محلياً إلى SYNCED.
 */
class SyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val TAG = "SyncWorker"
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val app = applicationContext as AidApplication
        val database = app.database
        val syncDao = database.syncQueueDao()
        val firebaseSyncManager = FirebaseSyncManager.getInstance(applicationContext)

        val pendingItems = syncDao.getPendingSyncItems()
        if (pendingItems.isEmpty()) {
            Log.d(TAG, "No pending sync items found in Room sync_queue.")
            return@withContext Result.success()
        }

        Log.i(TAG, "Starting delta sync for ${pendingItems.size} pending items...")

        // استخراج بيانات المستخدم / المندوب الحالي لتحديد المحلية
        val currentUser = app.repository.getCurrentUser()
        val userLocalityId = currentUser?.AllowedLocalityID ?: 0
        val userName = currentUser?.FullName ?: "مندوب ميداني"
        val userId = currentUser?.UserID ?: 1

        val localities = database.localityDao().getAllLocalitiesSync()
        val localityName = localities.find { it.LocalityID == userLocalityId }?.LocalityName ?: "المحلية المخصصة"

        var succeeded = 0
        var failed = 0

        for (item in pendingItems) {
            try {
                syncDao.markAsSyncing(item.syncId)

                // إنشاء كائن الـ Delta المستقل
                val delta = SyncDelta(
                    localityId = userLocalityId,
                    localityName = localityName,
                    userId = userId,
                    userName = userName,
                    entityType = item.entityType,
                    operation = item.operation,
                    recordId = item.recordId,
                    payloadJson = item.payloadJson,
                    timestamp = item.createdAt,
                    deviceId = firebaseSyncManager.deviceId
                )

                // الرفع السحابي الفعلي إلى Firebase Realtime Database
                val uploadSuccess = firebaseSyncManager.pushDelta(delta)

                if (uploadSuccess) {
                    syncDao.markAsSynced(item.syncId)
                    succeeded++
                    Log.d(TAG, "Synced item ${item.syncId} (${item.entityType}:${item.operation}) successfully")
                } else {
                    syncDao.markAsFailed(item.syncId, "فشل إرسال الحركة إلى Firebase Realtime Database")
                    failed++
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error syncing item ${item.syncId}: ${e.message}", e)
                syncDao.markAsFailed(item.syncId, e.message ?: "خطأ غير متوقع أثناء المزامنة")
                failed++
            }
        }

        // مسح العناصر المكتملة للحفاظ على خفة قاعدة بيانات Room
        if (succeeded > 0) {
            syncDao.clearSynced()
        }

        // تسجيل ملخص العملية في جدول سجلات المزامنة
        val status = if (failed == 0) "SUCCESS" else if (succeeded > 0) "PARTIAL" else "FAILED"
        val summary = "تمت مزامنة $succeeded حركة إلى Firebase Realtime Database بنجاح، و $failed حركات فاشلة من أصل ${pendingItems.size}."
        val log = SyncLogEntity(
            syncType = "FIREBASE_DELTA_AUTO",
            itemsProcessed = pendingItems.size,
            itemsSucceeded = succeeded,
            itemsFailed = failed,
            status = status,
            summary = summary,
            timestamp = System.currentTimeMillis()
        )
        syncDao.insertSyncLog(log)

        if (failed > 0 && succeeded == 0) {
            Result.retry()
        } else {
            Result.success()
        }
    }
}
