package com.humanitarian.aidmanagement.data.local.dao

import androidx.room.*
import com.humanitarian.aidmanagement.data.local.entities.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM tbl_Users WHERE UserName = :userName LIMIT 1")
    suspend fun getUserByUsername(userName: String): UserEntity?

    @Query("SELECT * FROM tbl_Users WHERE UserID = :userId LIMIT 1")
    suspend fun getUserById(userId: Int): UserEntity?

    @Query("SELECT * FROM tbl_Users")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM tbl_Users")
    suspend fun getAllUsersSync(): List<UserEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE tbl_Users SET FailedAttempts = FailedAttempts + 1 WHERE UserName = :userName")
    suspend fun incrementFailedAttempts(userName: String)

    @Query("UPDATE tbl_Users SET FailedAttempts = 0, LastLogin = :timestamp, LockedUntil = NULL WHERE UserID = :userId")
    suspend fun resetFailedAttempts(userId: Int, timestamp: Long)

    @Query("UPDATE tbl_Users SET LockedUntil = :lockedUntil WHERE UserName = :userName")
    suspend fun lockUser(userName: String, lockedUntil: Long)

    @Query("SELECT LocalityID FROM tbl_UserLocalities WHERE UserID = :userId")
    suspend fun getUserLocalityIds(userId: Int): List<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserLocality(userLocality: UserLocalityEntity)

    @Query("SELECT * FROM tbl_Roles WHERE RoleID = :roleId LIMIT 1")
    suspend fun getRoleById(roleId: Int): RoleEntity?

    @Query("SELECT * FROM tbl_Roles")
    fun getAllRoles(): Flow<List<RoleEntity>>

    @Query("SELECT * FROM tbl_Roles")
    suspend fun getAllRolesSync(): List<RoleEntity>

    @Query("DELETE FROM tbl_Users WHERE UserID = :userId")
    suspend fun deleteUserById(userId: Int)

    @Query("UPDATE tbl_Users SET IsActive = :isActive WHERE UserID = :userId")
    suspend fun setUserActive(userId: Int, isActive: Boolean)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRole(role: RoleEntity)

    // صلاحيات المستخدم التفصيلية (tbl_User_Permissions)
    @Query("SELECT * FROM tbl_User_Permissions WHERE UserID = :userId")
    fun getUserPermissions(userId: Int): Flow<List<UserPermissionEntity>>

    @Query("SELECT * FROM tbl_User_Permissions WHERE UserID = :userId")
    suspend fun getUserPermissionsSync(userId: Int): List<UserPermissionEntity>

    @Query("SELECT PermissionKey FROM tbl_User_Permissions WHERE UserID = :userId AND IsGranted = 1")
    suspend fun getGrantedPermissionKeys(userId: Int): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPermissions(permissions: List<UserPermissionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPermission(permission: UserPermissionEntity)

    @Query("DELETE FROM tbl_User_Permissions WHERE UserID = :userId")
    suspend fun clearUserPermissions(userId: Int)
}

@Dao
interface FamilyDao {
    @Query("SELECT * FROM families ORDER BY createdDate DESC")
    fun getAllFamilies(): Flow<List<FamilyEntity>>

    @Query("SELECT * FROM families ORDER BY createdDate DESC")
    suspend fun getAllFamiliesSync(): List<FamilyEntity>

    @Query("SELECT * FROM families WHERE localityID IN (:localityIds) ORDER BY createdDate DESC")
    fun getFamiliesByLocalities(localityIds: List<Int>): Flow<List<FamilyEntity>>

    @Query("SELECT * FROM families WHERE familyID = :id LIMIT 1")
    suspend fun getFamilyById(id: Long): FamilyEntity?

    @Query("SELECT * FROM families WHERE familyID = :id LIMIT 1")
    fun getFamilyByIdFlow(id: Long): Flow<FamilyEntity?>

    @Query("SELECT * FROM families WHERE nationalID = :nationalId LIMIT 1")
    suspend fun getFamilyByNationalId(nationalId: String): FamilyEntity?

    @Query("""
        SELECT * FROM families 
        WHERE (:query = '' OR name LIKE '%' || :query || '%' OR nationalID LIKE '%' || :query || '%')
        AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
        AND (:shelterStatus IS NULL OR :shelterStatus = '' OR shelterStatus = :shelterStatus)
        ORDER BY createdDate DESC
    """)
    fun searchFamilies(query: String, localityId: Int?, shelterStatus: String?): Flow<List<FamilyEntity>>

    @Query("""
        SELECT * FROM families 
        WHERE developmentApproval = 'معتمد'
        AND residentStatus = 'مقيم'
        AND worksApproval = 'معتمد أشغال'
        AND shelterStatus = 'إيواء داخلي'
        AND (:localityId IS NULL OR :localityId = 0 OR localityID = :localityId)
        ORDER BY familyMembersCount DESC
    """)
    suspend fun getEligibleFamiliesForNomination(localityId: Int?): List<FamilyEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFamily(family: FamilyEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFamilies(families: List<FamilyEntity>): List<Long>

    @Update
    suspend fun updateFamily(family: FamilyEntity)

    /**
     * معالجة دفعات الأسر بنظام Upsert داخل معاملة ذرية (@Transaction) لضمان السرعة الفائقة
     * ومنع تكرار الهويات (إذا وجد nationalID يتم التحديث، وإذا لم يوجد يتم الإضافة)
     */
    @Transaction
    suspend fun upsertFamiliesChunk(chunk: List<FamilyEntity>): Pair<Int, Int> {
        var inserted = 0
        var updated = 0
        chunk.forEach { family ->
            val existing = getFamilyByNationalId(family.nationalID)
            if (existing != null) {
                updateFamily(
                    family.copy(
                        familyID = existing.familyID,
                        createdDate = existing.createdDate,
                        modifiedDate = System.currentTimeMillis()
                    )
                )
                updated++
            } else {
                insertFamily(family)
                inserted++
            }
        }
        return Pair(inserted, updated)
    }

    @Delete
    suspend fun deleteFamily(family: FamilyEntity)

    @Query("SELECT COUNT(*) FROM families")
    suspend fun getTotalFamiliesCount(): Int

    @Query("SELECT SUM(familyMembersCount) FROM families")
    suspend fun getTotalBeneficiariesCount(): Int?

    // =========================================================================
    // استعلامات الاستحقاق الدقيقة وحساب النسب (المرحلة الأولى: منطق حساب النسب)
    // =========================================================================

    /**
     * استعلام إجمالي الأسر المستحقة حسب معيار الاستحقاق الصارم: (الوضع = مقيم) و (حالة الاعتماد = معتمد)
     */
    @Query("""
        SELECT COUNT(*) FROM families 
        WHERE (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
    """)
    suspend fun getExactEligibleFamiliesTotal(): Int

    /**
     * استعلام الأسر المستحقة لمنطقة فرعية محددة بدقة: (الوضع = مقيم) و (حالة الاعتماد = معتمد)
     */
    @Query("""
        SELECT COUNT(*) FROM families 
        WHERE (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
          AND currentSubArea = :subArea
    """)
    suspend fun getEligibleFamiliesCountForSubArea(subArea: String): Int

    /**
     * إجمالي كافة الأسر المسجلة في منطقة فرعية محددة
     */
    @Query("SELECT COUNT(*) FROM families WHERE currentSubArea = :subArea")
    suspend fun getTotalFamiliesCountForSubArea(subArea: String): Int

    /**
     * جلب قائمة كافة المناطق الفرعية المسجلة غير الفارغة
     */
    @Query("SELECT DISTINCT currentSubArea FROM families WHERE currentSubArea IS NOT NULL AND currentSubArea != '' ORDER BY currentSubArea ASC")
    suspend fun getAllSubAreasSync(): List<String>

    /**
     * استعلام إجمالي الأسر المستحقة لمحلية محددة: (الوضع = مقيم) و (حالة الاعتماد = معتمد)
     */
    @Query("""
        SELECT COUNT(*) FROM families 
        WHERE (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%')
          AND localityID = :localityId
    """)
    suspend fun getEligibleFamiliesCountForLocality(localityId: Int): Int

    /**
     * استعلام جلب الأسر المستحقة (معتمد ومقيم) حسب رقم المحلية
     */
    @Query("""
        SELECT * FROM families 
        WHERE localityID = :localityId 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%') 
          AND (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%')
        ORDER BY createdDate DESC
    """)
    suspend fun getFamiliesByLocalitySync(localityId: Int): List<FamilyEntity>

    /**
     * استعلام جلب الأسر المستحقة (معتمد ومقيم) حسب اسم المنطقة الفرعية
     */
    @Query("""
        SELECT * FROM families 
        WHERE currentSubArea = :locality 
          AND (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%') 
          AND (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%')
        ORDER BY createdDate DESC
    """)
    suspend fun getFamiliesByLocalitySync(locality: String): List<FamilyEntity>

    /**
     * استعلام حساب النسب بالاعتماد على المنطقة الفرعية الحالية فقط
     * مع تصفية البيانات بحيث تشمل حصراً الأسر المعتمدة والمقيمة
     */
    @Query("""
        SELECT 
            currentSubArea, 
            COUNT(*) AS familyCount,
            ROUND((COUNT(*) * 100.0 / NULLIF((SELECT COUNT(*) FROM families WHERE (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%') AND (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%') AND currentSubArea IS NOT NULL AND currentSubArea != ''), 0)), 2) AS ratio
        FROM families
        WHERE (developmentApproval = 'معتمد' OR developmentApproval LIKE '%معتمد%') 
          AND (residentStatus = 'مقيم' OR residentStatus LIKE '%مقيم%')
          AND currentSubArea IS NOT NULL 
          AND currentSubArea != ''
        GROUP BY currentSubArea
        ORDER BY familyCount DESC
    """)
    suspend fun calculateSubAreaDistributionRatios(): List<SubAreaShareRecord>

    @Query("SELECT nationalID FROM families")
    suspend fun getAllFamilyNationalIdsSync(): List<String>

    @Query("SELECT nationalID, familyID, localityID FROM families")
    suspend fun getAllFamilyReferencesSync(): List<FamilyReference>
}


data class FamilyReference(
    val nationalID: String,
    val familyID: Long,
    val localityID: Int
)

data class SubAreaShareRecord(
    val currentSubArea: String,
    val familyCount: Int = 0,
    val ratio: Double = 0.0
) {
    val totalFamilies: Int get() = familyCount
    val percentage: String get() = String.format(java.util.Locale.US, "%.2f%%", ratio)

    constructor(currentSubArea: String, totalFamilies: Int, percentage: String) : this(
        currentSubArea = currentSubArea,
        familyCount = totalFamilies,
        ratio = percentage.replace("%", "").trim().toDoubleOrNull() ?: 0.0
    )
}

@Dao
interface ChildDao {
    @Query("SELECT * FROM children WHERE familyNationalID = :familyNationalId")
    fun getChildrenByFamilyNationalId(familyNationalId: String): Flow<List<ChildEntity>>

    @Query("SELECT * FROM children WHERE nationalID = :nationalId LIMIT 1")
    suspend fun getChildByNationalId(nationalId: String): ChildEntity?

    @Query("SELECT * FROM children WHERE (:query = '' OR childName LIKE '%' || :query || '%' OR nationalID LIKE '%' || :query || '%')")
    fun searchChildren(query: String): Flow<List<ChildEntity>>

    @Query("SELECT COUNT(*) FROM children WHERE familyNationalID = :familyNationalId")
    suspend fun getChildrenCountForFamily(familyNationalId: String): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChild(child: ChildEntity): Long

    @Transaction
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChildren(children: List<ChildEntity>): List<Long>

    @Query("SELECT * FROM children")
    suspend fun getAllChildrenSync(): List<ChildEntity>

    @Query("SELECT nationalID FROM children")
    suspend fun getAllChildNationalIdsSync(): List<String>

    @Query("SELECT COUNT(*) FROM children")
    suspend fun getTotalChildrenCount(): Int

    @Delete
    suspend fun deleteChild(child: ChildEntity)
}


@Dao
interface AidTypeDao {
    @Query("SELECT * FROM aid_types WHERE isActive = 1 ORDER BY aidTypeID ASC")
    fun getAllActiveAidTypes(): Flow<List<AidTypeEntity>>

    @Query("SELECT * FROM aid_types ORDER BY aidTypeID ASC")
    fun getAllAidTypes(): Flow<List<AidTypeEntity>>

    @Query("SELECT * FROM aid_types WHERE isActive = 1 ORDER BY aidTypeID ASC")
    suspend fun getAllActiveAidTypesSync(): List<AidTypeEntity>

    @Query("SELECT * FROM aid_types ORDER BY aidTypeID ASC")
    suspend fun getAllAidTypesSync(): List<AidTypeEntity>

    @Query("SELECT * FROM aid_types WHERE aidTypeID = :id LIMIT 1")
    suspend fun getAidTypeById(id: Int): AidTypeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAidType(aidType: AidTypeEntity)
}

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects WHERE isActive = 1 ORDER BY projectDate DESC")
    fun getAllActiveProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE projectID = :id LIMIT 1")
    suspend fun getProjectById(id: Long): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Query("SELECT * FROM projects WHERE isActive = 1 ORDER BY projectDate DESC")
    suspend fun getAllActiveProjectsSync(): List<ProjectEntity>

    @Query("SELECT COUNT(*) FROM projects WHERE isActive = 1")
    suspend fun getTotalProjectsCount(): Int
}

@Dao
interface AidRecordDao {
    @Query("SELECT * FROM aid_records ORDER BY aidDate DESC")
    fun getAllAidRecords(): Flow<List<AidRecordEntity>>

    @Query("SELECT * FROM aid_records WHERE familyID = :familyId ORDER BY aidDate DESC")
    suspend fun getAidRecordsForFamily(familyId: Long): List<AidRecordEntity>

    @Query("SELECT * FROM aid_records WHERE familyID = :familyId ORDER BY aidDate DESC")
    fun getAidRecordsForFamilyFlow(familyId: Long): Flow<List<AidRecordEntity>>

    @Query("SELECT * FROM aid_records WHERE familyID = :familyId ORDER BY aidDate DESC LIMIT 1")
    suspend fun getLastAidForFamily(familyId: Long): AidRecordEntity?

    @Query("""
        SELECT * FROM aid_records 
        WHERE familyID = :familyId 
        AND aidTypeID = :aidTypeId 
        ORDER BY aidDate DESC 
        LIMIT 1
    """)
    suspend fun getLatestAidForFamilyAndType(familyId: Long, aidTypeId: Int): AidRecordEntity?

    @Query("SELECT * FROM aid_records WHERE aidRecordID = :recordId LIMIT 1")
    suspend fun getAidRecordById(recordId: Long): AidRecordEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAidRecord(record: AidRecordEntity): Long

    @Transaction
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAidRecords(records: List<AidRecordEntity>): List<Long>

    @Update
    suspend fun updateAidRecord(record: AidRecordEntity)

    @Query("UPDATE aid_records SET recipientStatus = :status, deliveryDate = :deliveryDate, notes = :notes WHERE aidRecordID = :recordId")
    suspend fun updateDeliveryStatus(recordId: Long, status: String, deliveryDate: String, notes: String?)

    @Query("DELETE FROM aid_records WHERE aidRecordID = :recordId")
    suspend fun deleteAidRecord(recordId: Long)

    @Query("SELECT COUNT(*) FROM aid_records")
    suspend fun getTotalAidRecordsCount(): Int

    @Query("SELECT * FROM aid_records")
    suspend fun getAllAidRecordsSync(): List<AidRecordEntity>

    @Query("SELECT COUNT(DISTINCT familyID) FROM aid_records WHERE recipientStatus = 'مستلم' OR recipientStatus = 'مستفيد'")
    suspend fun getDistinctBeneficiariesCount(): Int

    // =========================================================================
    // استعلامات أعداد المستفيدين الدقيقة لحساب نسب الاستفادة
    // =========================================================================

    /**
     * استعلام عدد الأسر المستفيدة فعلياً في منطقة فرعية محددة (التي استلمت معونة)
     */
    @Query("""
        SELECT COUNT(DISTINCT a.familyID) 
        FROM aid_records a 
        INNER JOIN families f ON a.familyID = f.familyID 
        WHERE f.currentSubArea = :subArea 
          AND (a.recipientStatus = 'مستلم' OR a.recipientStatus = 'مستفيد' OR a.recipientStatus LIKE '%تسليم%')
    """)
    suspend fun getDeliveredBeneficiariesCountForSubArea(subArea: String): Int

    /**
     * استعلام عدد الأسر المستفيدة فعلياً في محلية محددة
     */
    @Query("""
        SELECT COUNT(DISTINCT a.familyID) 
        FROM aid_records a 
        INNER JOIN families f ON a.familyID = f.familyID 
        WHERE f.localityID = :localityId 
          AND (a.recipientStatus = 'مستلم' OR a.recipientStatus = 'مستفيد' OR a.recipientStatus LIKE '%تسليم%')
    """)
    suspend fun getDeliveredBeneficiariesCountForLocality(localityId: Int): Int

    @Query("SELECT * FROM aid_records WHERE projectID = :projectId ORDER BY aidRecordID DESC")
    fun getAidRecordsForProject(projectId: Long): Flow<List<AidRecordEntity>>

    @Query("SELECT * FROM aid_records WHERE projectID = :projectId ORDER BY aidRecordID DESC")
    suspend fun getAidRecordsForProjectSync(projectId: Long): List<AidRecordEntity>

    @Query("SELECT COUNT(*) FROM aid_records WHERE projectID = :projectId")
    suspend fun getProjectCandidatesCount(projectId: Long): Int

    @Query("SELECT COUNT(*) FROM aid_records WHERE projectID = :projectId AND (recipientStatus = 'مستلم' OR recipientStatus = 'مستفيد' OR deliveryDate IS NOT NULL)")
    suspend fun getProjectDeliveredCount(projectId: Long): Int
}

@Dao
interface NominationDao {
    @Query("SELECT * FROM tbl_Manual_Selection WHERE AidTypeID = :aidTypeId AND ProjectID = :projectId")
    suspend fun getManualSelections(aidTypeId: Int, projectId: Long): List<ManualSelectionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertManualSelection(selection: ManualSelectionEntity): Long

    @Query("DELETE FROM tbl_Manual_Selection WHERE CitizenID = :citizenId AND AidTypeID = :aidTypeId AND ProjectID = :projectId")
    suspend fun removeManualSelection(citizenId: Long, aidTypeId: Int, projectId: Long)

    @Query("DELETE FROM tbl_Manual_Selection WHERE AidTypeID = :aidTypeId AND ProjectID = :projectId")
    suspend fun clearManualSelections(aidTypeId: Int, projectId: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSelectedCitizens(citizens: List<SelectedCitizenEntity>)

    @Query("""
        SELECT * FROM tbl_Selected_Citizens 
        WHERE (:aidTypeId = 0 OR AidTypeID = :aidTypeId) 
        AND (:projectId = 0 OR ProjectID = :projectId)
        ORDER BY ID DESC
    """)
    fun getSelectedCitizens(aidTypeId: Int, projectId: Long): Flow<List<SelectedCitizenEntity>>

    @Query("SELECT COUNT(*) FROM tbl_Selected_Citizens")
    suspend fun getTotalSelectedCount(): Int
}

@Dao
interface LocalityDao {
    @Query("SELECT * FROM tbl_Localities WHERE IsActive = 1 ORDER BY LocalityID ASC")
    fun getAllLocalities(): Flow<List<LocalityEntity>>

    @Query("SELECT * FROM tbl_Localities WHERE LocalityID = :id LIMIT 1")
    suspend fun getLocalityById(id: Int): LocalityEntity?

    @Query("SELECT * FROM tbl_Localities WHERE LocalityName = :name LIMIT 1")
    suspend fun getLocalityByName(name: String): LocalityEntity?

    @Query("SELECT * FROM tbl_Localities WHERE IsActive = 1 ORDER BY LocalityID ASC")
    suspend fun getAllLocalitiesSync(): List<LocalityEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocality(locality: LocalityEntity): Long

    @Query("SELECT * FROM locality_distribution WHERE isActive = 1 ORDER BY localityID ASC")
    fun getDistributions(): Flow<List<LocalityDistributionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDistributions(distributions: List<LocalityDistributionEntity>)

    @Query("DELETE FROM locality_distribution")
    suspend fun clearDistributions()
}

@Dao
interface SystemSettingDao {
    @Query("SELECT * FROM system_settings WHERE key = :key LIMIT 1")
    suspend fun getSetting(key: String): SystemSettingEntity?

    @Query("SELECT * FROM system_settings")
    fun getAllSettings(): Flow<List<SystemSettingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSetting(setting: SystemSettingEntity)
}

@Dao
interface SyncQueueDao {
    @Query("SELECT * FROM sync_queue WHERE status = 'PENDING' OR status = 'FAILED' ORDER BY createdAt ASC")
    fun getPendingSyncItemsFlow(): Flow<List<SyncQueueEntity>>

    @Query("SELECT * FROM sync_queue WHERE status = 'PENDING' OR status = 'FAILED' ORDER BY createdAt ASC")
    suspend fun getPendingSyncItems(): List<SyncQueueEntity>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status = 'PENDING' OR status = 'FAILED'")
    fun getPendingCountFlow(): Flow<Int>

    @Query("SELECT COUNT(*) FROM sync_queue WHERE status = 'PENDING' OR status = 'FAILED'")
    suspend fun getPendingCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(item: SyncQueueEntity): Long

    @Query("UPDATE sync_queue SET status = 'SYNCING' WHERE syncId = :id")
    suspend fun markAsSyncing(id: Long)

    @Query("UPDATE sync_queue SET status = 'SYNCED' WHERE syncId = :id")
    suspend fun markAsSynced(id: Long)

    @Query("UPDATE sync_queue SET status = 'FAILED', retryCount = retryCount + 1, errorMessage = :error WHERE syncId = :id")
    suspend fun markAsFailed(id: Long, error: String)

    @Query("DELETE FROM sync_queue WHERE status = 'SYNCED'")
    suspend fun clearSynced()

    @Query("DELETE FROM sync_queue WHERE syncId = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM sync_queue")
    suspend fun clearAll()

    // سجلات المزامنة
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSyncLog(log: SyncLogEntity)

    @Query("SELECT * FROM sync_log ORDER BY timestamp DESC LIMIT 20")
    fun getRecentSyncLogs(): Flow<List<SyncLogEntity>>

    @Query("SELECT * FROM sync_log ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLastSyncLog(): SyncLogEntity?
}

@Dao
interface AuditLogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLogEntity): Long

    @Query("SELECT * FROM tbl_Audit_Logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM tbl_Audit_Logs WHERE userId = :userId ORDER BY timestamp DESC")
    fun getLogsByUserId(userId: Int): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM tbl_Audit_Logs WHERE targetTable = :tableName ORDER BY timestamp DESC")
    fun getLogsByTable(tableName: String): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM tbl_Audit_Logs ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentLogsSync(limit: Int = 100): List<AuditLogEntity>

    @Query("DELETE FROM tbl_Audit_Logs")
    suspend fun clearLogs()
}
