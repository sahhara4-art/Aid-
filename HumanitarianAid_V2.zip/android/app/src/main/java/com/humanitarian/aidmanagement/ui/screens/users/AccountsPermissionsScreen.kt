package com.humanitarian.aidmanagement.ui.screens.users

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.RoleEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountsPermissionsScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val users by repository.getAllUsers().collectAsState(initial = emptyList())
    val roles by repository.getAllRoles().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())

    val roleMap = remember(roles) { roles.associateBy { it.RoleID } }
    val localityMap = remember(localities) { localities.associateBy { it.LocalityID } }

    var selectedRoleFilter by remember { mutableStateOf(0) } // 0 = الكل
    var showAddUserDialog by remember { mutableStateOf(false) }
    var userToEdit by remember { mutableStateOf<UserEntity?>(null) }
    var feedbackMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()
    val currentUser by repository.currentUserFlow.collectAsState(initial = repository.getCurrentUser())

    val filteredUsers = remember(users, selectedRoleFilter) {
        if (selectedRoleFilter == 0) users else users.filter { it.RoleID == selectedRoleFilter }
    }

    val activeCount = users.count { it.IsActive }
    val lockedCount = users.count { it.LockedUntil != null && it.LockedUntil > System.currentTimeMillis() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "إدارة الحسابات والصلاحيات والأمان",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "التحكم في المستخدمين، الأدوار، ومصفوفة الصلاحيات",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddUserDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = "إضافة مستخدم", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddUserDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مستخدم")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // بطاقة جلسة المدير الحالي
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFE11D48).copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFFE11D48), modifier = Modifier.size(26.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = currentUser?.FullName ?: "مدير النظام العام",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color(0xFFE11D48).copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "Super Admin",
                                    color = Color(0xFFE11D48),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "اسم المستخدم: ${currentUser?.UserName ?: "admin"} • صلاحيات كاملة لكافة الشاشات والمحليات",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // شريط إحصائيات الأمان السريعة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatPill(title = "المستخدمين", value = "${users.size}", color = Color(0xFF0D9488), modifier = Modifier.weight(1f))
                StatPill(title = "الحسابات النشطة", value = "$activeCount", color = Color(0xFF10B981), modifier = Modifier.weight(1f))
                StatPill(title = "الحسابات المقفلة", value = "$lockedCount", color = if (lockedCount > 0) Color(0xFFE11D48) else Color(0xFF64748B), modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(10.dp))

            // شريط تصفية الأدوار
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FilterChip(
                    selected = selectedRoleFilter == 0,
                    onClick = { selectedRoleFilter = 0 },
                    label = { Text("الكل", fontSize = 11.sp) }
                )
                roles.forEach { role ->
                    FilterChip(
                        selected = selectedRoleFilter == role.RoleID,
                        onClick = { selectedRoleFilter = role.RoleID },
                        label = { Text(role.RoleName, fontSize = 11.sp) }
                    )
                }
            }

            if (feedbackMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = feedbackMessage ?: "",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "قائمة حسابات المستخدمين (${filteredUsers.size}):",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(6.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                items(filteredUsers, key = { it.UserID }) { user ->
                    val role = roleMap[user.RoleID]
                    val isPrimaryAdmin = user.UserID == 1 || user.UserName.lowercase() == "admin"

                    UserCardItem(
                        user = user,
                        roleName = role?.RoleName ?: "دور #${user.RoleID}",
                        isPrimaryAdmin = isPrimaryAdmin,
                        onToggleActive = {
                            if (!isPrimaryAdmin) {
                                scope.launch {
                                    val newStatus = !user.IsActive
                                    repository.toggleUserActive(user.UserID, newStatus)
                                    feedbackMessage = "تم ${if (newStatus) "تفعيل" else "تعطيل"} حساب ${user.UserName}"
                                }
                            }
                        },
                        onUnlock = {
                            scope.launch {
                                repository.unlockUser(user.UserID)
                                feedbackMessage = "تم إلغاء قفل الحساب وإعادة ضبط المحاولات للمستخدم ${user.UserName}"
                            }
                        },
                        onEdit = { userToEdit = user },
                        onDelete = {
                            if (!isPrimaryAdmin) {
                                scope.launch {
                                    repository.deleteUser(user.UserID)
                                    feedbackMessage = "تم حذف حساب ${user.UserName}"
                                }
                            }
                        }
                    )
                }
            }
        }
    }

    // ==================== حوار إضافة مستخدم جديد ====================
    if (showAddUserDialog) {
        AddUserDialog(
            roles = roles,
            onDismiss = { showAddUserDialog = false },
            onSave = { newUser ->
                scope.launch {
                    repository.insertUser(newUser)
                    showAddUserDialog = false
                    feedbackMessage = "تم إنشاء المستخدم ${newUser.UserName} بنجاح"
                }
            }
        )
    }

    // ==================== حوار تعديل مستخدم ====================
    if (userToEdit != null) {
        val u = userToEdit!!
        EditUserDialog(
            user = u,
            roles = roles,
            onDismiss = { userToEdit = null },
            onSave = { updatedUser ->
                scope.launch {
                    repository.updateUser(updatedUser)
                    userToEdit = null
                    feedbackMessage = "تم تحديث بيانات المستخدم ${updatedUser.UserName} بنجاح"
                }
            }
        )
    }
}

@Composable
fun StatPill(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = color)
        }
    }
}

@Composable
fun UserCardItem(
    user: UserEntity,
    roleName: String,
    isPrimaryAdmin: Boolean,
    onToggleActive: () -> Unit,
    onUnlock: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val isLocked = (user.LockedUntil != null && user.LockedUntil > System.currentTimeMillis()) || user.FailedAttempts >= 5

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isPrimaryAdmin) Color(0xFFE11D48).copy(alpha = 0.15f)
                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPrimaryAdmin) Icons.Default.Security else Icons.Default.Person,
                            contentDescription = null,
                            tint = if (isPrimaryAdmin) Color(0xFFE11D48) else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = user.FullName,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = "@${user.UserName} • كلمة المرور: ${user.PasswordHash}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                }

                // شارة الدور
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isPrimaryAdmin) Color(0xFFE11D48).copy(alpha = 0.15f) else Color(0xFF6366F1).copy(alpha = 0.15f)
                ) {
                    Text(
                        text = roleName,
                        color = if (isPrimaryAdmin) Color(0xFFE11D48) else Color(0xFF6366F1),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // شارات الحالة والأمان
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (user.IsActive) Color(0xFF10B981).copy(alpha = 0.15f) else Color(0xFFEF4444).copy(alpha = 0.15f)
                ) {
                    Text(
                        text = if (user.IsActive) "حساب نشط" else "معطل",
                        color = if (user.IsActive) Color(0xFF10B981) else Color(0xFFEF4444),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                if (isLocked) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFFEF4444).copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "مقفل مؤقتاً (${user.FailedAttempts} محاولات)",
                            color = Color(0xFFEF4444),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = "محاولات خاطئة: ${user.FailedAttempts}/5",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(6.dp))

            // أزرار التحكم
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isLocked || user.FailedAttempts > 0) {
                    TextButton(onClick = onUnlock) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF10B981))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("فك القفل", color = Color(0xFF10B981), fontSize = 11.sp)
                    }
                }

                if (!isPrimaryAdmin) {
                    TextButton(onClick = onToggleActive) {
                        Text(if (user.IsActive) "تعطيل" else "تفعيل", fontSize = 11.sp)
                    }
                }

                IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }

                if (!isPrimaryAdmin) {
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AddUserDialog(
    roles: List<RoleEntity>,
    onDismiss: () -> Unit,
    onSave: (UserEntity) -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var selectedRoleId by remember { mutableStateOf(roles.firstOrNull()?.RoleID ?: 2) }
    var isActive by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة مستخدم جديد للنظام", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("الاسم الكامل للمستخدم") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("اسم المستخدم (Username)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("كلمة المرور") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text("الدور الوظيفي والصلاحيات:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    roles.forEach { role ->
                        FilterChip(
                            selected = selectedRoleId == role.RoleID,
                            onClick = { selectedRoleId = role.RoleID },
                            label = { Text(role.RoleName, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (username.isNotBlank() && password.isNotBlank() && fullName.isNotBlank()) {
                        val newUser = UserEntity(
                            UserName = username.trim(),
                            PasswordHash = password.trim(),
                            FullName = fullName.trim(),
                            RoleID = selectedRoleId,
                            IsActive = isActive,
                            CreatedBy = "مدير النظام"
                        )
                        onSave(newUser)
                    }
                }
            ) {
                Text("حفظ المستخدم")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun EditUserDialog(
    user: UserEntity,
    roles: List<RoleEntity>,
    onDismiss: () -> Unit,
    onSave: (UserEntity) -> Unit
) {
    var password by remember { mutableStateOf(user.PasswordHash) }
    var fullName by remember { mutableStateOf(user.FullName) }
    var selectedRoleId by remember { mutableStateOf(user.RoleID) }
    var isActive by remember { mutableStateOf(user.IsActive) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعديل حساب @${user.UserName}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("الاسم الكامل") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("تحديث كلمة المرور") },
                    modifier = Modifier.fillMaxWidth()
                )

                Text("الدور الوظيفي:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    roles.forEach { role ->
                        FilterChip(
                            selected = selectedRoleId == role.RoleID,
                            onClick = { selectedRoleId = role.RoleID },
                            label = { Text(role.RoleName, fontSize = 11.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = user.copy(
                        FullName = fullName,
                        PasswordHash = password,
                        RoleID = selectedRoleId,
                        IsActive = isActive
                    )
                    onSave(updated)
                }
            ) {
                Text("تحديث البيانات")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
