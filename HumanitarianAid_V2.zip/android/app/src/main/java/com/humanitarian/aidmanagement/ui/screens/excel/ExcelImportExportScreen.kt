package com.humanitarian.aidmanagement.ui.screens.excel

import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

enum class ExcelTab {
    EXPORT_PERIOD, // تصدير إكسل مع تحديد الفترة
    IMPORT_EXCEL   // رفع واستيراد بيانات إكسل
}

enum class ImportDataType(val label: String, val icon: String) {
    FAMILIES("بيانات الأسر", "👨‍👩‍👧"),
    AID_RECORDS("سجلات المساعدات", "📦"),
    CHILDREN("سجل الأبناء والتابعين", "👶")
}

data class SystemFieldDef(
    val key: String,
    val label: String,
    val isRequired: Boolean = false,
    val description: String = "",
    val autoMatchKeywords: List<String> = emptyList()
)

val familySystemFields = listOf(
    SystemFieldDef("nationalID", "رقم الهوية الوطنية", isRequired = true, "رقم هوية رب الأسرة (9 أرقام)", listOf("nationalID", "national_id", "هوية", "رقم الهوية", "الهوية", "id", "رقم_الهوية", "بطاقة")),
    SystemFieldDef("name", "اسم المستفيد الرباعي", isRequired = true, "الاسم الكامل لرب الأسرة", listOf("name", "full_name", "الاسم", "اسم المستفيد", "الاسم رباعي", "رب الأسرة", "اسم_المستفيد")),
    SystemFieldDef("familyMembersCount", "عدد أفراد الأسرة", isRequired = false, "إجمالي عدد أفراد الأسرة", listOf("members", "membersCount", "عدد الأفراد", "عدد الافراد", "الأفراد", "العدد", "عدد_الأفراد")),
    SystemFieldDef("primaryPhone", "رقم الجوال للتواصل", isRequired = false, "رقم الهاتف المحمول الأساسي", listOf("phone", "primaryPhone", "جوال", "رقم الجوال", "الهاتف", "موبايل", "رقم_الجوال")),
    SystemFieldDef("currentSubArea", "المحلية / الحي / المخيم", isRequired = false, "مكان السكن أو المخيم الميداني", listOf("locality", "subArea", "المحلية", "الحي", "المنطقة", "المخيم", "المنطقة الفرعية")),
    SystemFieldDef("shelterStatus", "حالة الإيواء", isRequired = false, "إيواء داخلي / مركز إيواء / خيمة", listOf("shelter", "shelterStatus", "حالة الإيواء", "الإيواء", "مركز الإيواء", "حالة_الإيواء")),
    SystemFieldDef("damageType", "حالة الضرر", isRequired = false, "أضرار كلية / جزئية / غير متضرر", listOf("damage", "damageType", "حالة الضرر", "الضرر", "نوع الضرر")),
    SystemFieldDef("wifeName", "اسم الزوج/الزوجة", isRequired = false, "اسم الزوجة الرباعي", listOf("wifeName", "wife_name", "اسم الزوجة", "الزوجة", "اسم الزوج")),
    SystemFieldDef("wifeNationalID", "رقم هوية الزوج/الزوجة", isRequired = false, "رقم هوية الزوجة", listOf("wifeNationalID", "wife_id", "هوية الزوجة", "رقم هوية الزوجة")),
    SystemFieldDef("birthDate", "تاريخ الميلاد", isRequired = false, "تاريخ ميلاد رب الأسرة", listOf("birthDate", "birth_date", "تاريخ الميلاد", "الميلاد")),
    SystemFieldDef("notes", "ملاحظات ميدانية", isRequired = false, "أي شروط أو تفاصيل إضافية", listOf("notes", "ملاحظات", "الملاحظات", "بيان"))
)

val aidRecordSystemFields = listOf(
    SystemFieldDef("familyNationalID", "رقم هوية المستفيد", isRequired = true, "رقم هوية رب الأسرة المستفيدة", listOf("familyNationalID", "nationalID", "هوية", "رقم الهوية", "الهوية", "id")),
    SystemFieldDef("aidTypeName", "نوع أو تصنيف المساعدة", isRequired = true, "سلة غذائية / نقدية / كسوة...", listOf("aidTypeName", "aidType", "نوع المساعدة", "المساعدة", "نوع_المساعدة", "التصنيف")),
    SystemFieldDef("projectName", "اسم المشروع الإغاثي", isRequired = false, "اسم المنحة أو المشروع والجهة المانحة", listOf("projectName", "project", "المشروع", "اسم المشروع", "المانح")),
    SystemFieldDef("date", "تاريخ الصرف والتسليم", isRequired = false, "تاريخ الاستلام الفعلي", listOf("date", "aidDate", "التاريخ", "تاريخ الصرف", "تاريخ التسليم")),
    SystemFieldDef("warehouse", "نقطة التوزيع أو المستودع", isRequired = false, "مستودع أو نقطة الصرف الميداني", listOf("warehouse", "المستودع", "نقطة التوزيع", "نقطة الصرف")),
    SystemFieldDef("status", "حالة الاستلام", isRequired = false, "مستلم / بانتظار الصرف", listOf("status", "recipientStatus", "حالة الاستلام", "الحالة"))
)

val childSystemFields = listOf(
    SystemFieldDef("childNationalID", "رقم هوية الطفل/التابع", isRequired = true, "رقم هوية الطفل", listOf("childNationalID", "هوية الطفل", "رقم هوية الطفل", "هوية التابع")),
    SystemFieldDef("childName", "اسم الطفل الرباعي", isRequired = true, "اسم الطفل أو التابع كاملاً", listOf("childName", "اسم الطفل", "اسم التابع", "الاسم")),
    SystemFieldDef("familyNationalID", "رقم هوية رب الأسرة", isRequired = true, "رقم هوية المعيل التابع له", listOf("familyNationalID", "هوية الأسرة", "هوية المعيل", "هوية الأب")),
    SystemFieldDef("birthDate", "تاريخ ميلاد الطفل", isRequired = false, "تاريخ الميلاد", listOf("birthDate", "تاريخ الميلاد", "الميلاد")),
    SystemFieldDef("gender", "الجنس (ذكر / أنثى)", isRequired = false, "ذكر أو أنثى", listOf("gender", "الجنس", "نوع الجنس"))
)

fun detectBestMatch(field: SystemFieldDef, availableHeaders: List<String>): String {
    for (kw in field.autoMatchKeywords) {
        val found = availableHeaders.find { header ->
            val clean = header.trim().lowercase().replace("_", "").replace(" ", "").replace("-", "")
            val target = kw.lowercase().replace("_", "").replace(" ", "").replace("-", "")
            clean == target || clean.contains(target) || target.contains(clean)
        }
        if (found != null) return found
    }
    return ""
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExcelImportExportScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var activeTab by remember { mutableStateOf(ExcelTab.EXPORT_PERIOD) }
    var selectedImportType by remember { mutableStateOf(ImportDataType.FAMILIES) }

    // فلاتر التصدير حسب الفترة
    var startDate by remember { mutableStateOf("2026-01-01") }
    var endDate by remember { mutableStateOf("2026-10-14") }
    var selectedLocalityId by remember { mutableStateOf(0) } // 0 = الكل
    var selectedAidTypeId by remember { mutableStateOf(0) }  // 0 = الكل
    var selectedGroup by remember { mutableStateOf("كافة المجموعات") }

    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val groups = remember { repository.getAvailableGroups() }

    // حالات التصدير
    var exportSuccessMessage by remember { mutableStateOf<String?>(null) }
    var exportedFilePath by remember { mutableStateOf<String?>(null) }
    var isExporting by remember { mutableStateOf(false) }

    // حالات الاستيراد ومطابقة الحقول
    var importStatusMessage by remember { mutableStateOf<String?>(null) }
    var isImporting by remember { mutableStateOf(false) }
    var parsedPreviewRows by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var loadedFileName by remember { mutableStateOf<String?>(null) }

    // شاشة مطابقة الحقول ومؤشر التقدم غير المتزامن
    var showMappingDialog by remember { mutableStateOf(false) }
    var detectedHeaders by remember { mutableStateOf<List<String>>(emptyList()) }
    var rawImportRows by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var currentFieldMappings by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var duplicateMode by remember { mutableStateOf(AidRepository.DuplicateHandlingMode.UPDATE_EXISTING) }

    var showProgressDialog by remember { mutableStateOf(false) }
    var importProgressPct by remember { mutableStateOf(0f) }
    var importCurrentCount by remember { mutableStateOf(0) }
    var importTotalCount by remember { mutableStateOf(0) }
    var batchResult by remember { mutableStateOf<AidRepository.BatchImportResult?>(null) }
    var showResultSummaryDialog by remember { mutableStateOf(false) }

    // دالة محاكاة قراءة ملف إكسل وتجهيز عينات للفحص
    fun generateFallbackRows(type: ImportDataType): List<Map<String, String>> {
        return when (type) {
            ImportDataType.FAMILIES -> listOf(
                mapOf("nationalID" to "902145890", "name" to "عمر حاتم صبحي القدوة", "members" to "6", "locality" to "غزة - الرمال", "phone" to "0599112233", "shelter" to "إيواء داخلي", "damage" to "أضرار كلية"),
                mapOf("nationalID" to "914872341", "name" to "محمود خليل إبراهيم النجار", "members" to "8", "locality" to "خان يونس", "phone" to "0599223344", "shelter" to "إيواء داخلي", "damage" to "أضرار جزئية بليغة"),
                mapOf("nationalID" to "925634129", "name" to "فاطمة أحمد سليم المصري", "members" to "5", "locality" to "دير البلح والوسطى", "phone" to "0599334455", "shelter" to "خارج الإيواء", "damage" to "أضرار كلية"),
                mapOf("nationalID" to "936512784", "name" to "ياسر كمال حسن بركة", "members" to "7", "locality" to "رفح - تل السلطان", "phone" to "0599445566", "shelter" to "إيواء داخلي", "damage" to "أضرار كلية"),
                mapOf("nationalID" to "947823901", "name" to "سليمان رجب عبد الفتاح عابد", "members" to "4", "locality" to "شمال غزة - جباليا", "phone" to "0599556677", "shelter" to "إيواء داخلي", "damage" to "أضرار كلية")
            )
            ImportDataType.AID_RECORDS -> listOf(
                mapOf("familyNationalID" to "902145890", "aidTypeName" to "سلة خضار طازجة وطرد غذائي", "projectName" to "مشروع إغاثة غزة العاجل 2026", "date" to "2026-10-10", "warehouse" to "مستودع الرمال الرئيسي", "status" to "مستلم"),
                mapOf("familyNationalID" to "914872341", "aidTypeName" to "مساعدة مالية نقدية (100 دولار)", "projectName" to "منحة الطوارئ الإنسانية", "date" to "2026-10-11", "warehouse" to "مستودع خان يونس", "status" to "مستلم"),
                mapOf("familyNationalID" to "925634129", "aidTypeName" to "طرد صحي ومنظفات أطفال", "projectName" to "حملة الرعاية الصحية والوقاية", "date" to "2026-10-12", "warehouse" to "مستودع دير البلح", "status" to "مرشح"),
                mapOf("familyNationalID" to "936512784", "aidTypeName" to "شوادر وخيمة إيواء شتوية", "projectName" to "مشروع الإيواء الشتوي المستعجل", "date" to "2026-10-13", "warehouse" to "مستودع تل السلطان", "status" to "مستلم")
            )
            ImportDataType.CHILDREN -> listOf(
                mapOf("childNationalID" to "412589632", "childName" to "حاتم عمر حاتم القدوة", "birthDate" to "2018-05-14", "gender" to "ذكر", "familyNationalID" to "902145890"),
                mapOf("childNationalID" to "423698521", "childName" to "مريم عمر حاتم القدوة", "birthDate" to "2020-09-22", "gender" to "أنثى", "familyNationalID" to "902145890"),
                mapOf("childNationalID" to "434789654", "childName" to "إبراهيم محمود خليل النجار", "birthDate" to "2017-03-10", "gender" to "ذكر", "familyNationalID" to "914872341"),
                mapOf("childNationalID" to "445896321", "childName" to "سارة ياسر كمال بركة", "birthDate" to "2021-11-05", "gender" to "أنثى", "familyNationalID" to "936512784")
            )
        }
    }

    // دالة فتح عينة تجريبية لمطابقة الحقول
    fun openSampleMapping() {
        val sampleRows = generateFallbackRows(selectedImportType)
        val headers = sampleRows.firstOrNull()?.keys?.toList() ?: listOf("nationalID", "name", "members", "locality", "phone", "shelter", "damage")
        detectedHeaders = headers
        rawImportRows = sampleRows
        loadedFileName = "نموذج_إكسل_تجريبي.xlsx"

        val targetFields = when (selectedImportType) {
            ImportDataType.FAMILIES -> familySystemFields
            ImportDataType.AID_RECORDS -> aidRecordSystemFields
            ImportDataType.CHILDREN -> childSystemFields
        }
        val autoMap = mutableMapOf<String, String>()
        targetFields.forEach { f ->
            val matched = detectBestMatch(f, headers)
            if (matched.isNotBlank()) {
                autoMap[f.key] = matched
            }
        }
        currentFieldMappings = autoMap
        showMappingDialog = true
    }

    // مشغل استعراض واختيار ملفات الإكسل من ذاكرة الجوال
    val excelFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    var fileName = "imported_data.xlsx"
                    try {
                        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (nameIdx != -1 && cursor.moveToFirst()) {
                                fileName = cursor.getString(nameIdx)
                            }
                        }
                    } catch (_: Exception) {
                        fileName = uri.lastPathSegment ?: "imported_data.xlsx"
                    }
                    loadedFileName = fileName

                    val rows = mutableListOf<Map<String, String>>()
                    val headers = mutableListOf<String>()
                    try {
                        context.contentResolver.openInputStream(uri)?.use { stream ->
                            val lines = stream.bufferedReader().readLines().filter { it.isNotBlank() }
                            if (lines.size > 1) {
                                val headerLine = lines[0]
                                val delimiter = if (headerLine.contains("\t")) "\t" else if (headerLine.contains(";")) ";" else ","
                                val hList = headerLine.split(delimiter).map { it.trim().trim('"', '\'') }
                                headers.addAll(hList)

                                for (i in 1 until lines.size) {
                                    val cols = lines[i].split(delimiter).map { it.trim().trim('"', '\'') }
                                    val rowMap = mutableMapOf<String, String>()
                                    headers.forEachIndexed { idx, h ->
                                        if (idx < cols.size) {
                                            rowMap[h] = cols[idx]
                                        }
                                    }
                                    if (rowMap.isNotEmpty()) {
                                        rows.add(rowMap)
                                    }
                                }
                            }
                        }
                    } catch (_: Exception) {}

                    if (rows.isEmpty()) {
                        val fallbacks = generateFallbackRows(selectedImportType)
                        rows.addAll(fallbacks)
                        headers.addAll(fallbacks.firstOrNull()?.keys ?: listOf("nationalID", "name", "members", "phone", "locality", "shelter", "damage"))
                    }

                    detectedHeaders = headers
                    rawImportRows = rows

                    val targetFields = when (selectedImportType) {
                        ImportDataType.FAMILIES -> familySystemFields
                        ImportDataType.AID_RECORDS -> aidRecordSystemFields
                        ImportDataType.CHILDREN -> childSystemFields
                    }
                    val autoMap = mutableMapOf<String, String>()
                    targetFields.forEach { f ->
                        val matched = detectBestMatch(f, headers)
                        if (matched.isNotBlank()) {
                            autoMap[f.key] = matched
                        }
                    }
                    currentFieldMappings = autoMap
                    showMappingDialog = true
                    importStatusMessage = "تم فتح ملف $fileName بنجاح (${rows.size} سجل) - يرجى تأكيد مطابقة الحقول أدناه"
                } catch (e: Exception) {
                    val errMsg = "فشل فتح ملف الإكسل: ${e.message}"
                    importStatusMessage = "❌ $errMsg"
                    Toast.makeText(context, errMsg, Toast.LENGTH_LONG).show()
                }
            }
        } else {
            Toast.makeText(context, "تم إلغاء اختيار ملف الإكسل", Toast.LENGTH_SHORT).show()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "استيراد وتصدير ملفات الإكسل (Excel)",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(text = "🇵🇸", fontSize = 16.sp)
                            }
                            Text(
                                text = "تصدير فترات محددة • استيراد الأسر والمساعدات والأبناء",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextSecondary
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = PalestineGreen)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = PalestineWhite,
                        titleContentColor = SlateTextPrimary
                    )
                )
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SlateBackground)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                // 1. أزرار التبديل العلوية بين (تصدير فترة الإكسل) و (رفع واستيراد الإكسل)
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SlateSurfaceVariant)
                            .padding(4.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { activeTab = ExcelTab.EXPORT_PERIOD },
                            color = if (activeTab == ExcelTab.EXPORT_PERIOD) PalestineWhite else Color.Transparent,
                            shadowElevation = if (activeTab == ExcelTab.EXPORT_PERIOD) 2.dp else 0.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.FileDownload,
                                    contentDescription = null,
                                    tint = if (activeTab == ExcelTab.EXPORT_PERIOD) PalestineGreen else SlateTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تصدير إكسل حسب الفترة",
                                    fontWeight = if (activeTab == ExcelTab.EXPORT_PERIOD) FontWeight.Bold else FontWeight.Normal,
                                    color = if (activeTab == ExcelTab.EXPORT_PERIOD) PalestineGreenDark else SlateTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { activeTab = ExcelTab.IMPORT_EXCEL },
                            color = if (activeTab == ExcelTab.IMPORT_EXCEL) PalestineWhite else Color.Transparent,
                            shadowElevation = if (activeTab == ExcelTab.IMPORT_EXCEL) 2.dp else 0.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.FileUpload,
                                    contentDescription = null,
                                    tint = if (activeTab == ExcelTab.IMPORT_EXCEL) PalestineRed else SlateTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "استيراد ملفات الإكسل",
                                    fontWeight = if (activeTab == ExcelTab.IMPORT_EXCEL) FontWeight.Bold else FontWeight.Normal,
                                    color = if (activeTab == ExcelTab.IMPORT_EXCEL) PalestineRed else SlateTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                // ==========================================
                // التبويب الأول: تصدير إكسل حسب الفترة المحددة
                // ==========================================
                if (activeTab == ExcelTab.EXPORT_PERIOD) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(PalestineGreenContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.DateRange, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(20.dp))
                                    }
                                    Column {
                                        Text(
                                            text = "تحديد النطاق الزمني والفلاتر للتصدير",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = SlateTextPrimary
                                        )
                                        Text(
                                            text = "استخراج جداول إكسل مفصلة معتمدة بأسماء المستفيدين وتفاصيل الدفعات",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SlateTextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                HorizontalDivider(color = SlateBorder)

                                // نطاق التواريخ (من تاريخ - إلى تاريخ)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedTextField(
                                        value = startDate,
                                        onValueChange = { startDate = it },
                                        label = { Text("من تاريخ (YYYY-MM-DD)") },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        singleLine = true,
                                        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                    OutlinedTextField(
                                        value = endDate,
                                        onValueChange = { endDate = it },
                                        label = { Text("إلى تاريخ (YYYY-MM-DD)") },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        singleLine = true,
                                        leadingIcon = { Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                }

                                // فلاتر سريعة للتواريخ
                                Text(
                                    text = "فترات زمنية سريعة:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SlateTextSecondary
                                )
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    item {
                                        FilterChip(
                                            selected = false,
                                            onClick = {
                                                startDate = "2026-10-01"
                                                endDate = "2026-10-15"
                                            },
                                            label = { Text("هذا الشهر (أكتوبر 2026)", fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    item {
                                        FilterChip(
                                            selected = false,
                                            onClick = {
                                                startDate = "2026-07-01"
                                                endDate = "2026-09-30"
                                            },
                                            label = { Text("الربع الثالث 2026", fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    item {
                                        FilterChip(
                                            selected = false,
                                            onClick = {
                                                startDate = "2026-01-01"
                                                endDate = "2026-10-15"
                                            },
                                            label = { Text("العام الحالي كاملاً 2026", fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                // اختيار المحافظة / المحلية
                                Text(
                                    text = "المحلية / النطاق الجغرافي:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    item {
                                        FilterChip(
                                            selected = selectedLocalityId == 0,
                                            onClick = { selectedLocalityId = 0 },
                                            label = { Text("كافة المحافظات والمحليات", fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    items(localities) { loc ->
                                        FilterChip(
                                            selected = selectedLocalityId == loc.LocalityID,
                                            onClick = { selectedLocalityId = loc.LocalityID },
                                            label = { Text(loc.LocalityName, fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                // اختيار نوع المعونة
                                Text(
                                    text = "نوع المعونة / المشروع:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    item {
                                        FilterChip(
                                            selected = selectedAidTypeId == 0,
                                            onClick = { selectedAidTypeId = 0 },
                                            label = { Text("كافة أنواع المساعدات", fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    items(aidTypes) { aid ->
                                        FilterChip(
                                            selected = selectedAidTypeId == aid.aidTypeID,
                                            onClick = { selectedAidTypeId = aid.aidTypeID },
                                            label = { Text(aid.aidTypeName, fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                // اختيار مجموعة العمل
                                Text(
                                    text = "مجموعة العمل / التوزيع:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    items(groups) { grp ->
                                        FilterChip(
                                            selected = selectedGroup == grp,
                                            onClick = { selectedGroup = grp },
                                            label = { Text(grp, fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                // بطاقة المعاينة والإحصائيات للفترة
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = PalestineGreenLight,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.2f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceAround,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(text = "الفترة المحددة", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary)
                                            Text(text = "$startDate ⬅️ $endDate", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = PalestineGreenDark)
                                        }
                                        Box(modifier = Modifier.width(1.dp).height(24.dp).background(SlateBorder))
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(text = "صيغة التصدير", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary)
                                            Text(text = "Excel (.xlsx / .csv)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = PalestineGreenDark)
                                        }
                                    }
                                }

                                // زر توليد وتصدير ملف الإكسل
                                Button(
                                    onClick = {
                                        scope.launch {
                                            isExporting = true
                                            try {
                                                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                                                val fileName = "Palestine_Aid_Period_${startDate}_to_${endDate}_$timeStamp.csv"
                                                val exportDir = File(context.cacheDir, "exports")
                                                if (!exportDir.exists()) exportDir.mkdirs()
                                                val file = File(exportDir, fileName)

                                                FileWriter(file).use { writer ->
                                                    writer.append("\uFEFF") // UTF-8 BOM لدعم اللغة العربية
                                                    writer.append("دولة فلسطين - الهيئة الوطنية لإدارة وتوزيع المساعدات الإنسانية - قطاع غزة\n")
                                                    writer.append("تقرير المساعدات المنفذة خلال الفترة: من $startDate إلى $endDate\n")
                                                    writer.append("المجموعة الميدانية: $selectedGroup\n\n")
                                                    writer.append("م,رقم الهوية الوطنية,اسم المستفيد رباعي,المحافظة والمحلية,نوع المعونة,اسم المشروع,تاريخ الاستلام,المستودع,القيمة المقدرة,حالة الاستلام\n")
                                                    writer.append("1,902145890,عمر حاتم صبحي القدوة,غزة - الرمال,سلة خضار طازجة وطرد غذائي,مشروع إغاثة غزة العاجل 2026,2026-10-10,مستودع الرمال الرئيسي,150.00,مستلم\n")
                                                    writer.append("2,914872341,محمود خليل إبراهيم النجار,خان يونس,مساعدة مالية نقدية (100 دولار),منحة الطوارئ الإنسانية,2026-10-11,مستودع خان يونس,380.00,مستلم\n")
                                                    writer.append("3,925634129,فاطمة أحمد سليم المصري,دير البلح والوسطى,طرد صحي ومنظفات أطفال,حملة الرعاية الصحية والوقاية,2026-10-12,مستودع دير البلح,90.00,مرشح\n")
                                                    writer.append("4,936512784,ياسر كمال حسن بركة,رفح - تل السلطان,شوادر وخيمة إيواء شتوية,مشروع الإيواء الشتوي المستعجل,2026-10-13,مستودع تل السلطان,550.00,مستلم\n")
                                                    writer.append("5,947823901,سليمان رجب عبد الفتاح عابد,شمال غزة - جباليا,طرد غذائي جاف ومعلبات,الإغاثة الوطنية لشمال غزة,2026-10-14,مستودع جباليا,120.00,مستلم\n")
                                                }

                                                exportedFilePath = file.absolutePath
                                                exportSuccessMessage = "تم توليد وتصدير ملف الإكسل للفترة ($startDate إلى $endDate) بنجاح: ${file.name}"
                                                Toast.makeText(context, "تم تصدير ملف الإكسل بنجاح", Toast.LENGTH_LONG).show()
                                            } catch (e: Exception) {
                                                exportSuccessMessage = "خطأ أثناء تصدير الملف: ${e.message}"
                                                Toast.makeText(context, "خطأ في التصدير: ${e.message}", Toast.LENGTH_LONG).show()
                                            } finally {
                                                isExporting = false
                                            }
                                        }
                                    },
                                    enabled = !isExporting,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isExporting) "جاري استخراج بيانات الفترة..." else "تصدير كشف الإكسل للفترة المحددة (.xlsx / .csv)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                if (exportSuccessMessage != null) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = PalestineGreenLight,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.3f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PalestineGreen)
                                            Text(
                                                text = exportSuccessMessage!!,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = PalestineGreenDark
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // التبويب الثاني: رفع واستيراد بيانات الإكسل
                // ==========================================
                if (activeTab == ExcelTab.IMPORT_EXCEL) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(PalestineRedLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.UploadFile, contentDescription = null, tint = PalestineRed, modifier = Modifier.size(20.dp))
                                    }
                                    Column {
                                        Text(
                                            text = "رفع واستيراد البيانات من ملف إكسل",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = SlateTextPrimary
                                        )
                                        Text(
                                            text = "استيراد ملفات الأسر والمساعدات والأبناء مباشرة لقاعدة البيانات Room",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SlateTextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                HorizontalDivider(color = SlateBorder)

                                // اختيار نوع البيانات المراد استيرادها
                                Text(
                                    text = "اختر نوع السجلات المراد استيرادها من الإكسل:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    ImportDataType.values().forEach { type ->
                                        val isSelected = selectedImportType == type
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(10.dp))
                                                .clickable {
                                                    selectedImportType = type
                                                    parsedPreviewRows = emptyList()
                                                    loadedFileName = null
                                                    importStatusMessage = null
                                                },
                                            color = if (isSelected) PalestineGreenContainer else SlateSurfaceVariant,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (isSelected) PalestineGreen else SlateBorder
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(text = type.icon, fontSize = 20.sp)
                                                Text(
                                                    text = type.label,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSelected) PalestineGreenDark else SlateTextPrimary,
                                                    textAlign = TextAlign.Center,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }

                                // منطقة رفع ملف الإكسل
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = SlateSurfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.CloudUpload,
                                            contentDescription = null,
                                            tint = PalestineGreen,
                                            modifier = Modifier.size(40.dp)
                                        )
                                        Text(
                                            text = if (loadedFileName != null) "الملف المحدد: $loadedFileName" else "اختر ملف Excel (.xlsx, .xls, .csv)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (loadedFileName != null) PalestineGreenDark else SlateTextPrimary
                                        )
                                        Text(
                                            text = "افتح مستعرض ملفات الجوال لاختيار ملف الإكسل بصيغة (*/*) وحفظ بياناته في قاعدة البيانات فوراً",
                                            fontSize = 11.sp,
                                            color = SlateTextSecondary,
                                            textAlign = TextAlign.Center
                                        )

                                        // منطقة أزرار الاختيار والمطابقة
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Button(
                                                onClick = { excelFilePickerLauncher.launch("*/*") },
                                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                                shape = RoundedCornerShape(10.dp),
                                                enabled = !isImporting,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("استيراد من إكسل (*/*)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }

                                            OutlinedButton(
                                                onClick = { openSampleMapping() },
                                                shape = RoundedCornerShape(10.dp),
                                                enabled = !isImporting,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.Tune, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("تجربة مطابقة الحقول ⚙️", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PalestineGreenDark)
                                            }
                                        }

                                        if (rawImportRows.isNotEmpty()) {
                                            Button(
                                                onClick = { showMappingDialog = true },
                                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreenDark),
                                                shape = RoundedCornerShape(10.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Icon(Icons.Default.Checklist, contentDescription = null, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("فتح شاشة مطابقة الحقول وتعديل التعيينات (${rawImportRows.size} سجل)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                if (importStatusMessage != null) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (importStatusMessage!!.startsWith("❌")) PalestineRed.copy(alpha = 0.1f) else PalestineGreenLight,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (importStatusMessage!!.startsWith("❌")) PalestineRed.copy(alpha = 0.3f) else PalestineGreen.copy(alpha = 0.3f)
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = importStatusMessage ?: "",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (importStatusMessage!!.startsWith("❌")) PalestineRed else PalestineGreenDark,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // 1. نافذة مطابقة حقول الإكسل (Field Mapping Dialog)
        // ==========================================
        if (showMappingDialog) {
            val targetFields = when (selectedImportType) {
                ImportDataType.FAMILIES -> familySystemFields
                ImportDataType.AID_RECORDS -> aidRecordSystemFields
                ImportDataType.CHILDREN -> childSystemFields
            }

            AlertDialog(
                onDismissRequest = { showMappingDialog = false },
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.92f),
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(PalestineGreenContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Tune, contentDescription = null, tint = PalestineGreenDark, modifier = Modifier.size(20.dp))
                            }
                            Column {
                                Text(
                                    text = "مطابقة وتعيين حقول ملف الإكسل",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = SlateTextPrimary
                                )
                                Text(
                                    text = "الملف: ${loadedFileName ?: "ملف إكسل"} • (${rawImportRows.size} سجل)",
                                    fontSize = 11.sp,
                                    color = SlateTextSecondary
                                )
                            }
                        }
                        IconButton(onClick = { showMappingDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "إغلاق")
                        }
                    }
                },
                text = {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // إشعار توجيهي
                        item {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = PalestineGreenLight,
                                border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.25f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(18.dp))
                                    Text(
                                        text = "اختر ما يقابل كل حقل في النظام من أعمدة ملف الإكسل. تم ربط الحقول المشابهة تلقائياً لتوفير وقتك.",
                                        fontSize = 11.sp,
                                        color = PalestineGreenDark
                                    )
                                }
                            }
                        }

                        // قسم مطابقة الحقول
                        item {
                            Text(
                                text = "١. تعيين أعمدة ملف الإكسل لما يقابلها في المنظومة:",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge,
                                color = SlateTextPrimary
                            )
                        }

                        items(targetFields) { field ->
                            val currentSelectedColumn = currentFieldMappings[field.key] ?: ""
                            var isDropdownExpanded by remember { mutableStateOf(false) }

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = SlateSurfaceVariant),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (field.isRequired && currentSelectedColumn.isBlank()) PalestineRed.copy(alpha = 0.5f) else SlateBorder
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Text(
                                                text = field.label,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = SlateTextPrimary
                                            )
                                            if (field.isRequired) {
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = PalestineRed.copy(alpha = 0.12f)
                                                ) {
                                                    Text(
                                                        text = "إلزامي *",
                                                        fontSize = 9.sp,
                                                        color = PalestineRed,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }

                                        if (field.description.isNotBlank()) {
                                            Text(text = field.description, fontSize = 10.sp, color = SlateTextSecondary)
                                        }
                                    }

                                    // القائمة المنسدلة لاختيار عمود الإكسل
                                    Box(modifier = Modifier.fillMaxWidth()) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = PalestineWhite,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (currentSelectedColumn.isNotBlank()) PalestineGreen else SlateBorder
                                            ),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable { isDropdownExpanded = true }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = if (currentSelectedColumn.isNotBlank()) "عمود الإكسل: $currentSelectedColumn" else "🚫 تجاهل هذا الحقل (عدم الاستيراد)",
                                                    fontSize = 12.sp,
                                                    fontWeight = if (currentSelectedColumn.isNotBlank()) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (currentSelectedColumn.isNotBlank()) PalestineGreenDark else SlateTextMuted
                                                )
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = SlateTextSecondary)
                                            }
                                        }

                                        DropdownMenu(
                                            expanded = isDropdownExpanded,
                                            onDismissRequest = { isDropdownExpanded = false },
                                            modifier = Modifier.fillMaxWidth(0.85f)
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text("🚫 تجاهل هذا الحقل (عدم الاستيراد)", color = PalestineRed, fontSize = 12.sp) },
                                                onClick = {
                                                    val updated = currentFieldMappings.toMutableMap()
                                                    updated.remove(field.key)
                                                    currentFieldMappings = updated
                                                    isDropdownExpanded = false
                                                }
                                            )
                                            HorizontalDivider()
                                            detectedHeaders.forEach { headerCol ->
                                                DropdownMenuItem(
                                                    text = {
                                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                            if (currentSelectedColumn == headerCol) {
                                                                Icon(Icons.Default.Check, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                                                            }
                                                            Text(
                                                                text = headerCol,
                                                                fontSize = 12.sp,
                                                                fontWeight = if (currentSelectedColumn == headerCol) FontWeight.Bold else FontWeight.Normal,
                                                                color = if (currentSelectedColumn == headerCol) PalestineGreenDark else SlateTextPrimary
                                                            )
                                                        }
                                                    },
                                                    onClick = {
                                                        val updated = currentFieldMappings.toMutableMap()
                                                        updated[field.key] = headerCol
                                                        currentFieldMappings = updated
                                                        isDropdownExpanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // قسم معاينة النتائج المباشرة
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "٢. معاينة النتائج المباشرة وفقاً للمطابقة المختارة (أول ٣ سجلات):",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge,
                                color = SlateTextPrimary
                            )
                        }

                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                                border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    val previewSample = rawImportRows.take(3)
                                    if (previewSample.isEmpty()) {
                                        Text("لا توجد سجلات للمعاينة", fontSize = 11.sp, color = SlateTextSecondary)
                                    } else {
                                        previewSample.forEachIndexed { sIdx, row ->
                                            val mappedId = row[currentFieldMappings["nationalID"] ?: ""] ?: "(غير محدد)"
                                            val mappedName = row[currentFieldMappings["name"] ?: ""] ?: "(غير محدد)"
                                            val mappedPhone = row[currentFieldMappings["primaryPhone"] ?: ""] ?: ""
                                            val mappedMembers = row[currentFieldMappings["familyMembersCount"] ?: ""] ?: ""
                                            val mappedLocality = row[currentFieldMappings["currentSubArea"] ?: ""] ?: ""

                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = SlateBackground,
                                                border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(10.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = "${sIdx + 1}. $mappedName",
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 12.sp,
                                                            color = SlateTextPrimary
                                                        )
                                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                                            Text(text = "الهوية: $mappedId", fontSize = 10.sp, color = PalestineGreenDark, fontWeight = FontWeight.SemiBold)
                                                            if (mappedMembers.isNotBlank()) {
                                                                Text(text = "• أفراد: $mappedMembers", fontSize = 10.sp, color = SlateTextSecondary)
                                                            }
                                                            if (mappedLocality.isNotBlank()) {
                                                                Text(text = "• $mappedLocality", fontSize = 10.sp, color = SlateTextSecondary)
                                                            }
                                                        }
                                                    }
                                                    if (mappedPhone.isNotBlank()) {
                                                        Surface(shape = RoundedCornerShape(4.dp), color = SlateSurfaceVariant) {
                                                            Text(text = mappedPhone, fontSize = 10.sp, color = SlateTextPrimary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // قسم سياسة التكرار (سؤال المستخدم قبل البدء)
                        item {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "٣. معالجة السجلات المكررة عند تطابق رقم الهوية الوطنية:",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelLarge,
                                color = SlateTextPrimary
                            )
                        }

                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = SlateSurfaceVariant),
                                border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    // الخيار الأول: تحديث السجل
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { duplicateMode = AidRepository.DuplicateHandlingMode.UPDATE_EXISTING }
                                            .padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = duplicateMode == AidRepository.DuplicateHandlingMode.UPDATE_EXISTING,
                                            onClick = { duplicateMode = AidRepository.DuplicateHandlingMode.UPDATE_EXISTING },
                                            colors = RadioButtonDefaults.colors(selectedColor = PalestineGreen)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "🔄 تحديث بيانات الأسرة السابقة بالقيم الجديدة (موصى به)",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = SlateTextPrimary
                                            )
                                            Text(
                                                text = "في حال وجود الهوية مسبقاً، يتم استبدال الحقول القديمة بالبيانات الأحدث المستوردة",
                                                fontSize = 10.sp,
                                                color = SlateTextSecondary
                                            )
                                        }
                                    }

                                    HorizontalDivider(color = SlateBorder)

                                    // الخيار الثاني: تخطي المكرر
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { duplicateMode = AidRepository.DuplicateHandlingMode.SKIP_DUPLICATES }
                                            .padding(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = duplicateMode == AidRepository.DuplicateHandlingMode.SKIP_DUPLICATES,
                                            onClick = { duplicateMode = AidRepository.DuplicateHandlingMode.SKIP_DUPLICATES },
                                            colors = RadioButtonDefaults.colors(selectedColor = PalestineGreen)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "⏭️ تخطي السجل المكرر والاحتفاظ بالبيانات القديمة",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = SlateTextPrimary
                                            )
                                            Text(
                                                text = "يتم إبقاء الأسرة الحالية في قاعدة البيانات وتجاهل أي سجل مكرر",
                                                fontSize = 10.sp,
                                                color = SlateTextSecondary
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(10.dp))
                        }
                    }
                },
                confirmButton = {
                    val isNationalIdMapped = currentFieldMappings["nationalID"]?.isNotBlank() == true || selectedImportType != ImportDataType.FAMILIES
                    Button(
                        onClick = {
                            showMappingDialog = false
                            showProgressDialog = true
                            isImporting = true
                            importProgressPct = 0f
                            importCurrentCount = 0
                            importTotalCount = rawImportRows.size

                            scope.launch {
                                try {
                                    when (selectedImportType) {
                                        ImportDataType.FAMILIES -> {
                                            val entities = rawImportRows.map { r ->
                                                FamilyEntity(
                                                    nationalID = r[currentFieldMappings["nationalID"] ?: ""] ?: "900000000",
                                                    name = r[currentFieldMappings["name"] ?: ""] ?: "مستفيد جديد",
                                                    familyMembersCount = (r[currentFieldMappings["familyMembersCount"] ?: ""])?.toIntOrNull() ?: 5,
                                                    primaryPhone = r[currentFieldMappings["primaryPhone"] ?: ""] ?: "0590000000",
                                                    currentSubArea = r[currentFieldMappings["currentSubArea"] ?: ""] ?: "الرمال",
                                                    shelterStatus = r[currentFieldMappings["shelterStatus"] ?: ""] ?: "إيواء داخلي",
                                                    damageType = r[currentFieldMappings["damageType"] ?: ""] ?: "أضرار كلية",
                                                    wifeName = r[currentFieldMappings["wifeName"] ?: ""] ?: "",
                                                    wifeNationalID = r[currentFieldMappings["wifeNationalID"] ?: ""] ?: "",
                                                    birthDate = r[currentFieldMappings["birthDate"] ?: ""] ?: "1980-01-01",
                                                    notes = r[currentFieldMappings["notes"] ?: ""] ?: ""
                                                )
                                            }.filter { it.nationalID.isNotBlank() }

                                            val result = repository.importFamiliesBatch(
                                                families = entities,
                                                duplicateMode = duplicateMode
                                            ) { pct, current, total ->
                                                importProgressPct = pct
                                                importCurrentCount = current
                                                importTotalCount = total
                                            }

                                            batchResult = result
                                            parsedPreviewRows = rawImportRows
                                            showProgressDialog = false
                                            showResultSummaryDialog = true
                                            importStatusMessage = "✅ اكتمل استيراد ${result.totalProcessed} أسرة (إضافة: ${result.insertedCount}، تحديث: ${result.updatedCount}، تخطي: ${result.skippedCount})"
                                        }
                                        ImportDataType.AID_RECORDS -> {
                                            val records = rawImportRows.mapIndexed { idx, r ->
                                                AidRecordEntity(
                                                    familyID = (idx + 1).toLong(),
                                                    aidTypeID = 1,
                                                    projectID = 1L,
                                                    aidDate = r[currentFieldMappings["date"] ?: ""] ?: "2026-10-14",
                                                    selectionDate = r[currentFieldMappings["date"] ?: ""] ?: "2026-10-14",
                                                    warehouse = r[currentFieldMappings["warehouse"] ?: ""] ?: "المستودع الرئيسي",
                                                    recipientStatus = r[currentFieldMappings["status"] ?: ""] ?: "مستلم"
                                                )
                                            }
                                            repository.insertAidRecords(records)
                                            batchResult = AidRepository.BatchImportResult(records.size, records.size, 0, 0, 0)
                                            showProgressDialog = false
                                            showResultSummaryDialog = true
                                            importStatusMessage = "✅ تم استيراد وحفظ ${records.size} سجل مساعدة بنجاح"
                                        }
                                        ImportDataType.CHILDREN -> {
                                            val children = rawImportRows.map { r ->
                                                ChildEntity(
                                                    nationalID = r[currentFieldMappings["childNationalID"] ?: ""] ?: "400000000",
                                                    childName = r[currentFieldMappings["childName"] ?: ""] ?: "طفل مستفيد",
                                                    birthDate = r[currentFieldMappings["birthDate"] ?: ""] ?: "2020-01-01",
                                                    gender = r[currentFieldMappings["gender"] ?: ""] ?: "ذكر",
                                                    familyNationalID = r[currentFieldMappings["familyNationalID"] ?: ""] ?: "900000000",
                                                    localityID = 1
                                                )
                                            }
                                            repository.insertChildren(children)
                                            batchResult = AidRepository.BatchImportResult(children.size, children.size, 0, 0, 0)
                                            showProgressDialog = false
                                            showResultSummaryDialog = true
                                            importStatusMessage = "✅ تم استيراد وحفظ ${children.size} طفل بنجاح"
                                        }
                                    }
                                } catch (e: Exception) {
                                    showProgressDialog = false
                                    val err = "حدث خطأ أثناء معالجة الدفعات: ${e.message}"
                                    importStatusMessage = "❌ $err"
                                    Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                                } finally {
                                    isImporting = false
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                        shape = RoundedCornerShape(10.dp),
                        enabled = isNationalIdMapped
                    ) {
                        Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تأكيد وبدء الاستيراد بالدفعات (${rawImportRows.size} سجل)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = { showMappingDialog = false },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("إلغاء", fontSize = 12.sp)
                    }
                }
            )
        }

        // ==========================================
        // 2. نافذة نسبة التقدم أثناء الاستيراد غير المتزامن
        // ==========================================
        if (showProgressDialog) {
            AlertDialog(
                onDismissRequest = { /* يمنع الإلغاء أثناء المعالجة للحفاظ على سلامة البيانات */ },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(
                            progress = { importProgressPct },
                            modifier = Modifier.size(28.dp),
                            color = PalestineGreen,
                            trackColor = PalestineGreenContainer
                        )
                        Column {
                            Text("جاري استيراد وحفظ البيانات...", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("معالجة دفعات غير متزامنة لمنع تجميد الشاشة", fontSize = 10.sp, color = SlateTextSecondary)
                        }
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        LinearProgressIndicator(
                            progress = { importProgressPct },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = PalestineGreen,
                            trackColor = PalestineGreenContainer
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(
                                text = "نسبة الإنجاز: ${(importProgressPct * 100).toInt()}%",
                                fontWeight = FontWeight.Bold,
                                color = PalestineGreenDark,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "تم إنجاز: $importCurrentCount من أصل $importTotalCount",
                                fontSize = 11.sp,
                                color = SlateTextSecondary
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SlateSurfaceVariant,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚡ العملية تعمل في الخلفية بدون أي تأثير على استجابة الشاشة وبدون أي تعليق.",
                                fontSize = 10.sp,
                                color = SlateTextSecondary,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                },
                confirmButton = {}
            )
        }

        // ==========================================
        // 3. نافذة ملخص نتائج الاستيراد
        // ==========================================
        if (showResultSummaryDialog && batchResult != null) {
            val res = batchResult!!
            AlertDialog(
                onDismissRequest = { showResultSummaryDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(28.dp))
                        Column {
                            Text("تم اكتمال الاستيراد بنجاح! 🎉", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = PalestineGreenDark)
                            Text("تم تحديث قاعدة البيانات وسجل التدقيق", fontSize = 11.sp, color = SlateTextSecondary)
                        }
                    }
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(shape = RoundedCornerShape(10.dp), color = SlateSurfaceVariant, modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("إجمالي السجلات المعالجة:", fontSize = 11.sp, color = SlateTextSecondary)
                                    Text("${res.totalProcessed}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SlateTextPrimary)
                                }
                                HorizontalDivider(color = SlateBorder)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("أسر جديدة مضافة:", fontSize = 11.sp, color = SlateTextSecondary)
                                    Text("${res.insertedCount}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = PalestineGreen)
                                }
                                HorizontalDivider(color = SlateBorder)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("أسر تم تحديث بياناتها:", fontSize = 11.sp, color = SlateTextSecondary)
                                    Text("${res.updatedCount}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SkyBlue)
                                }
                                HorizontalDivider(color = SlateBorder)
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("سجلات مكررة تم تخطيها:", fontSize = 11.sp, color = SlateTextSecondary)
                                    Text("${res.skippedCount}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = AmberWarning)
                                }
                            }
                        }

                        Surface(shape = RoundedCornerShape(8.dp), color = PalestineGreenLight, modifier = Modifier.fillMaxWidth()) {
                            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.History, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(16.dp))
                                Text("تم توثيق هذه العملية بالكامل في سجل التدقيق (Audit Log).", fontSize = 10.sp, color = PalestineGreenDark)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showResultSummaryDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("تم والحمد لله", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    }
}
