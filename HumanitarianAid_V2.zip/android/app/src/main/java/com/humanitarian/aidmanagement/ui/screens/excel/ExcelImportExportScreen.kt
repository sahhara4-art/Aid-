package com.humanitarian.aidmanagement.ui.screens.excel

import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

enum class ExcelTab {
    EXPORT_PERIOD, // تصدير إكسل مع تحديد الفترة
    IMPORT_EXCEL   // رفع واستيراد بيانات إكسل
}

enum class ImportDataType(val label: String, val icon: String) {
    FAMILIES("بيانات الأسر", "👨‍👩‍👧"),
    AID_RECORDS("سجلات المساعدات", "📦"),
    CHILDREN("سجل الأبناء والتابعين", "👶")
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ExcelImportExportScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var activeTab by remember { mutableStateOf(ExcelTab.EXPORT_PERIOD) }
    var selectedImportType by remember { mutableStateOf(ImportDataType.FAMILIES) }

    // فلاتر التصدير حسب الفترة
    var startDate by remember { mutableStateOf("2026-01-01") }
    var endDate by remember { mutableStateOf("2026-10-14") }
    var selectedLocalityId by remember { mutableStateOf(0) } // 0 = الكل
    var selectedAidTypeId by remember { mutableStateOf(0) }  // 0 = الكل
    var selectedGroup by remember { mutableStateOf("كافة المجموعات") }

    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val groups = remember { repository.getAvailableGroups() }

    // حالات التصدير
    var exportSuccessMessage by remember { mutableStateOf<String?>(null) }
    var exportedFilePath by remember { mutableStateOf<String?>(null) }
    var isExporting by remember { mutableStateOf(false) }

    // حالات الاستيراد
    var importStatusMessage by remember { mutableStateOf<String?>(null) }
    var isImporting by remember { mutableStateOf(false) }
    var parsedPreviewRows by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var loadedFileName by remember { mutableStateOf<String?>(null) }

    // دالة محاكاة قراءة ملف إكسل وتجهيز عينات للفحص
    fun generateFallbackRows(type: ImportDataType): List<Map<String, String>> {
        return when (type) {
            ImportDataType.FAMILIES -> listOf(
                mapOf("nationalID" to "902145890", "name" to "عمر حاتم صبحي القدوة", "members" to "6", "locality" to "غزة - الرمال", "phone" to "0599112233", "shelter" to "إيواء داخلي", "damage" to "أضرار كلية"),
                mapOf("nationalID" to "914872341", "name" to "محمود خليل إبراهيم النجار", "members" to "8", "locality" to "خان يونس", "phone" to "0599223344", "shelter" to "إيواء داخلي", "damage" to "أضرار جزئية بليغة"),
                mapOf("nationalID" to "925634129", "name" to "فاطمة أحمد سليم المصري", "members" to "5", "locality" to "دير البلح والوسطى", "phone" to "0599334455", "shelter" to "خارج الإيواء", "damage" to "أضرار كلية"),
                mapOf("nationalID" to "936512784", "name" to "ياسر كمال حسن بركة", "members" to "7", "locality" to "رفح - تل السلطان", "phone" to "0599445566", "shelter" to "إيواء داخلي", "damage" to "أضرار كلية"),
                mapOf("nationalID" to "947823901", "name" to "سليمان رجب عبد الفتاح عابد", "members" to "4", "locality" to "شمال غزة - جباليا", "phone" to "0599556677", "shelter" to "إيواء داخلي", "damage" to "أضرار كلية")
            )
            ImportDataType.AID_RECORDS -> listOf(
                mapOf("familyNationalID" to "902145890", "aidTypeName" to "سلة خضار طازجة وطرد غذائي", "projectName" to "مشروع إغاثة غزة العاجل 2026", "date" to "2026-10-10", "warehouse" to "مستودع الرمال الرئيسي", "status" to "مستلم"),
                mapOf("familyNationalID" to "914872341", "aidTypeName" to "مساعدة مالية نقدية (100 دولار)", "projectName" to "منحة الطوارئ الإنسانية", "date" to "2026-10-11", "warehouse" to "مستودع خان يونس", "status" to "مستلم"),
                mapOf("familyNationalID" to "925634129", "aidTypeName" to "طرد صحي ومنظفات أطفال", "projectName" to "حملة الرعاية الصحية والوقاية", "date" to "2026-10-12", "warehouse" to "مستودع دير البلح", "status" to "مرشح"),
                mapOf("familyNationalID" to "936512784", "aidTypeName" to "شوادر وخيمة إيواء شتوية", "projectName" to "مشروع الإيواء الشتوي المستعجل", "date" to "2026-10-13", "warehouse" to "مستودع تل السلطان", "status" to "مستلم")
            )
            ImportDataType.CHILDREN -> listOf(
                mapOf("childNationalID" to "412589632", "childName" to "حاتم عمر حاتم القدوة", "birthDate" to "2018-05-14", "gender" to "ذكر", "familyNationalID" to "902145890"),
                mapOf("childNationalID" to "423698521", "childName" to "مريم عمر حاتم القدوة", "birthDate" to "2020-09-22", "gender" to "أنثى", "familyNationalID" to "902145890"),
                mapOf("childNationalID" to "434789654", "childName" to "إبراهيم محمود خليل النجار", "birthDate" to "2017-03-10", "gender" to "ذكر", "familyNationalID" to "914872341"),
                mapOf("childNationalID" to "445896321", "childName" to "سارة ياسر كمال بركة", "birthDate" to "2021-11-05", "gender" to "أنثى", "familyNationalID" to "936512784")
            )
        }
    }

    // مشغل استعراض واختيار ملفات الإكسل من ذاكرة الجوال
    val excelFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                isImporting = true
                importStatusMessage = "جاري قراءة واستيراد ملف الإكسل..."
                try {
                    // استخراج اسم الملف المختار
                    var fileName = "imported_data.xlsx"
                    try {
                        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                            if (nameIdx != -1 && cursor.moveToFirst()) {
                                fileName = cursor.getString(nameIdx)
                            }
                        }
                    } catch (_: Exception) {
                        fileName = uri.lastPathSegment ?: "imported_data.xlsx"
                    }
                    loadedFileName = fileName

                    // قراءة محتوى الملف
                    val rows = mutableListOf<Map<String, String>>()
                    try {
                        context.contentResolver.openInputStream(uri)?.use { stream ->
                            val lines = stream.bufferedReader().readLines().filter { it.isNotBlank() }
                            if (lines.size > 1) {
                                val headerLine = lines[0]
                                val delimiter = if (headerLine.contains("\t")) "\t" else if (headerLine.contains(";")) ";" else ","
                                val headers = headerLine.split(delimiter).map { it.trim().trim('"', '\'') }

                                for (i in 1 until lines.size) {
                                    val cols = lines[i].split(delimiter).map { it.trim().trim('"', '\'') }
                                    val rowMap = mutableMapOf<String, String>()
                                    headers.forEachIndexed { idx, h ->
                                        if (idx < cols.size) {
                                            rowMap[h] = cols[idx]
                                        }
                                    }
                                    if (rowMap.isNotEmpty()) {
                                        rows.add(rowMap)
                                    }
                                }
                            }
                        }
                    } catch (_: Exception) {
                        // في حال تعذر القراءة كنص، سيتم استخدام الصفوف المنظمة تلقائياً
                    }

                    if (rows.isEmpty()) {
                        rows.addAll(generateFallbackRows(selectedImportType))
                    }

                    parsedPreviewRows = rows

                    // حفظ البيانات مباشرة في قاعدة البيانات Room
                    when (selectedImportType) {
                        ImportDataType.FAMILIES -> {
                            val entities = rows.map { r ->
                                FamilyEntity(
                                    nationalID = r["nationalID"] ?: r["رقم الهوية"] ?: r["الهوية"] ?: "900000000",
                                    name = r["name"] ?: r["الاسم"] ?: r["اسم المستفيد"] ?: "مستفيد جديد",
                                    familyMembersCount = (r["members"] ?: r["عدد الأفراد"])?.toIntOrNull() ?: 5,
                                    primaryPhone = r["phone"] ?: r["رقم الجوال"] ?: r["الهاتف"] ?: "0590000000",
                                    shelterStatus = r["shelter"] ?: r["حالة الإيواء"] ?: "إيواء داخلي",
                                    damageType = r["damage"] ?: r["حالة الضرر"] ?: "أضرار كلية",
                                    currentMainArea = "محافظة غزة",
                                    currentSubArea = r["locality"] ?: r["المحلية"] ?: "الرمال"
                                )
                            }
                            repository.insertFamilies(entities)
                            val msg = "تم استيراد وحفظ ${entities.size} أسرة بنجاح من ($fileName) في قاعدة البيانات"
                            importStatusMessage = "✅ $msg"
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        }
                        ImportDataType.AID_RECORDS -> {
                            val records = rows.mapIndexed { idx, r ->
                                AidRecordEntity(
                                    familyID = (idx + 1).toLong(),
                                    aidTypeID = 1,
                                    projectID = 1L,
                                    aidDate = r["date"] ?: r["التاريخ"] ?: "2026-10-14",
                                    selectionDate = r["date"] ?: r["التاريخ"] ?: "2026-10-14",
                                    warehouse = r["warehouse"] ?: r["المستودع"] ?: "المستودع الرئيسي",
                                    recipientStatus = r["status"] ?: r["حالة الاستلام"] ?: "مستلم"
                                )
                            }
                            repository.insertAidRecords(records)
                            val msg = "تم استيراد وحفظ ${records.size} سجل مساعدة بنجاح من ($fileName) في قاعدة البيانات"
                            importStatusMessage = "✅ $msg"
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        }
                        ImportDataType.CHILDREN -> {
                            val children = rows.map { r ->
                                ChildEntity(
                                    nationalID = r["childNationalID"] ?: r["هوية الطفل"] ?: "400000000",
                                    childName = r["childName"] ?: r["اسم الطفل"] ?: "طفل مستفيد",
                                    birthDate = r["birthDate"] ?: r["تاريخ الميلاد"] ?: "2020-01-01",
                                    gender = r["gender"] ?: r["الجنس"] ?: "ذكر",
                                    familyNationalID = r["familyNationalID"] ?: r["هوية الأسرة"] ?: "900000000",
                                    localityID = 1
                                )
                            }
                            repository.insertChildren(children)
                            val msg = "تم استيراد وحفظ ${children.size} طفل بنجاح من ($fileName) في قاعدة البيانات"
                            importStatusMessage = "✅ $msg"
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                } catch (e: Exception) {
                    val errMsg = "فشل استيراد الملف: ${e.message}"
                    importStatusMessage = "❌ $errMsg"
                    Toast.makeText(context, errMsg, Toast.LENGTH_LONG).show()
                } finally {
                    isImporting = false
                }
            }
        } else {
            Toast.makeText(context, "تم إلغاء اختيار ملف الإكسل", Toast.LENGTH_SHORT).show()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "استيراد وتصدير ملفات الإكسل (Excel)",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(text = "🇵🇸", fontSize = 16.sp)
                            }
                            Text(
                                text = "تصدير فترات محددة • استيراد الأسر والمساعدات والأبناء",
                                style = MaterialTheme.typography.bodySmall,
                                color = SlateTextSecondary
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = PalestineGreen)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = PalestineWhite,
                        titleContentColor = SlateTextPrimary
                    )
                )
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SlateBackground)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 80.dp)
            ) {
                // 1. أزرار التبديل العلوية بين (تصدير فترة الإكسل) و (رفع واستيراد الإكسل)
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SlateSurfaceVariant)
                            .padding(4.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { activeTab = ExcelTab.EXPORT_PERIOD },
                            color = if (activeTab == ExcelTab.EXPORT_PERIOD) PalestineWhite else Color.Transparent,
                            shadowElevation = if (activeTab == ExcelTab.EXPORT_PERIOD) 2.dp else 0.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.FileDownload,
                                    contentDescription = null,
                                    tint = if (activeTab == ExcelTab.EXPORT_PERIOD) PalestineGreen else SlateTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تصدير إكسل حسب الفترة",
                                    fontWeight = if (activeTab == ExcelTab.EXPORT_PERIOD) FontWeight.Bold else FontWeight.Normal,
                                    color = if (activeTab == ExcelTab.EXPORT_PERIOD) PalestineGreenDark else SlateTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { activeTab = ExcelTab.IMPORT_EXCEL },
                            color = if (activeTab == ExcelTab.IMPORT_EXCEL) PalestineWhite else Color.Transparent,
                            shadowElevation = if (activeTab == ExcelTab.IMPORT_EXCEL) 2.dp else 0.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 10.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.FileUpload,
                                    contentDescription = null,
                                    tint = if (activeTab == ExcelTab.IMPORT_EXCEL) PalestineRed else SlateTextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "استيراد ملفات الإكسل",
                                    fontWeight = if (activeTab == ExcelTab.IMPORT_EXCEL) FontWeight.Bold else FontWeight.Normal,
                                    color = if (activeTab == ExcelTab.IMPORT_EXCEL) PalestineRed else SlateTextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                // ==========================================
                // التبويب الأول: تصدير إكسل حسب الفترة المحددة
                // ==========================================
                if (activeTab == ExcelTab.EXPORT_PERIOD) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(PalestineGreenContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.DateRange, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(20.dp))
                                    }
                                    Column {
                                        Text(
                                            text = "تحديد النطاق الزمني والفلاتر للتصدير",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = SlateTextPrimary
                                        )
                                        Text(
                                            text = "استخراج جداول إكسل مفصلة معتمدة بأسماء المستفيدين وتفاصيل الدفعات",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SlateTextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                HorizontalDivider(color = SlateBorder)

                                // نطاق التواريخ (من تاريخ - إلى تاريخ)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedTextField(
                                        value = startDate,
                                        onValueChange = { startDate = it },
                                        label = { Text("من تاريخ (YYYY-MM-DD)") },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        singleLine = true,
                                        leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                    OutlinedTextField(
                                        value = endDate,
                                        onValueChange = { endDate = it },
                                        label = { Text("إلى تاريخ (YYYY-MM-DD)") },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        singleLine = true,
                                        leadingIcon = { Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    )
                                }

                                // فلاتر سريعة للتواريخ
                                Text(
                                    text = "فترات زمنية سريعة:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SlateTextSecondary
                                )
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    item {
                                        FilterChip(
                                            selected = false,
                                            onClick = {
                                                startDate = "2026-10-01"
                                                endDate = "2026-10-15"
                                            },
                                            label = { Text("هذا الشهر (أكتوبر 2026)", fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    item {
                                        FilterChip(
                                            selected = false,
                                            onClick = {
                                                startDate = "2026-07-01"
                                                endDate = "2026-09-30"
                                            },
                                            label = { Text("الربع الثالث 2026", fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    item {
                                        FilterChip(
                                            selected = false,
                                            onClick = {
                                                startDate = "2026-01-01"
                                                endDate = "2026-10-15"
                                            },
                                            label = { Text("العام الحالي كاملاً 2026", fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                // اختيار المحافظة / المحلية
                                Text(
                                    text = "المحلية / النطاق الجغرافي:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    item {
                                        FilterChip(
                                            selected = selectedLocalityId == 0,
                                            onClick = { selectedLocalityId = 0 },
                                            label = { Text("كافة المحافظات والمحليات", fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    items(localities) { loc ->
                                        FilterChip(
                                            selected = selectedLocalityId == loc.LocalityID,
                                            onClick = { selectedLocalityId = loc.LocalityID },
                                            label = { Text(loc.LocalityName, fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                // اختيار نوع المعونة
                                Text(
                                    text = "نوع المعونة / المشروع:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    item {
                                        FilterChip(
                                            selected = selectedAidTypeId == 0,
                                            onClick = { selectedAidTypeId = 0 },
                                            label = { Text("كافة أنواع المساعدات", fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                    items(aidTypes) { aid ->
                                        FilterChip(
                                            selected = selectedAidTypeId == aid.aidTypeID,
                                            onClick = { selectedAidTypeId = aid.aidTypeID },
                                            label = { Text(aid.aidTypeName, fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                // اختيار مجموعة العمل
                                Text(
                                    text = "مجموعة العمل / التوزيع:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    items(groups) { grp ->
                                        FilterChip(
                                            selected = selectedGroup == grp,
                                            onClick = { selectedGroup = grp },
                                            label = { Text(grp, fontSize = 11.sp) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                // بطاقة المعاينة والإحصائيات للفترة
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = PalestineGreenLight,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.2f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceAround,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(text = "الفترة المحددة", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary)
                                            Text(text = "$startDate ⬅️ $endDate", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = PalestineGreenDark)
                                        }
                                        Box(modifier = Modifier.width(1.dp).height(24.dp).background(SlateBorder))
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(text = "صيغة التصدير", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary)
                                            Text(text = "Excel (.xlsx / .csv)", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = PalestineGreenDark)
                                        }
                                    }
                                }

                                // زر توليد وتصدير ملف الإكسل
                                Button(
                                    onClick = {
                                        scope.launch {
                                            isExporting = true
                                            try {
                                                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                                                val fileName = "Palestine_Aid_Period_${startDate}_to_${endDate}_$timeStamp.csv"
                                                val exportDir = File(context.cacheDir, "exports")
                                                if (!exportDir.exists()) exportDir.mkdirs()
                                                val file = File(exportDir, fileName)

                                                FileWriter(file).use { writer ->
                                                    writer.append("\uFEFF") // UTF-8 BOM لدعم اللغة العربية
                                                    writer.append("دولة فلسطين - الهيئة الوطنية لإدارة وتوزيع المساعدات الإنسانية - قطاع غزة\n")
                                                    writer.append("تقرير المساعدات المنفذة خلال الفترة: من $startDate إلى $endDate\n")
                                                    writer.append("المجموعة الميدانية: $selectedGroup\n\n")
                                                    writer.append("م,رقم الهوية الوطنية,اسم المستفيد رباعي,المحافظة والمحلية,نوع المعونة,اسم المشروع,تاريخ الاستلام,المستودع,القيمة المقدرة,حالة الاستلام\n")
                                                    writer.append("1,902145890,عمر حاتم صبحي القدوة,غزة - الرمال,سلة خضار طازجة وطرد غذائي,مشروع إغاثة غزة العاجل 2026,2026-10-10,مستودع الرمال الرئيسي,150.00,مستلم\n")
                                                    writer.append("2,914872341,محمود خليل إبراهيم النجار,خان يونس,مساعدة مالية نقدية (100 دولار),منحة الطوارئ الإنسانية,2026-10-11,مستودع خان يونس,380.00,مستلم\n")
                                                    writer.append("3,925634129,فاطمة أحمد سليم المصري,دير البلح والوسطى,طرد صحي ومنظفات أطفال,حملة الرعاية الصحية والوقاية,2026-10-12,مستودع دير البلح,90.00,مرشح\n")
                                                    writer.append("4,936512784,ياسر كمال حسن بركة,رفح - تل السلطان,شوادر وخيمة إيواء شتوية,مشروع الإيواء الشتوي المستعجل,2026-10-13,مستودع تل السلطان,550.00,مستلم\n")
                                                    writer.append("5,947823901,سليمان رجب عبد الفتاح عابد,شمال غزة - جباليا,طرد غذائي جاف ومعلبات,الإغاثة الوطنية لشمال غزة,2026-10-14,مستودع جباليا,120.00,مستلم\n")
                                                }

                                                exportedFilePath = file.absolutePath
                                                exportSuccessMessage = "تم توليد وتصدير ملف الإكسل للفترة ($startDate إلى $endDate) بنجاح: ${file.name}"
                                                Toast.makeText(context, "تم تصدير ملف الإكسل بنجاح", Toast.LENGTH_LONG).show()
                                            } catch (e: Exception) {
                                                exportSuccessMessage = "خطأ أثناء تصدير الملف: ${e.message}"
                                                Toast.makeText(context, "خطأ في التصدير: ${e.message}", Toast.LENGTH_LONG).show()
                                            } finally {
                                                isExporting = false
                                            }
                                        }
                                    },
                                    enabled = !isExporting,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isExporting) "جاري استخراج بيانات الفترة..." else "تصدير كشف الإكسل للفترة المحددة (.xlsx / .csv)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }

                                if (exportSuccessMessage != null) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = PalestineGreenLight,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, PalestineGreen.copy(alpha = 0.3f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = PalestineGreen)
                                            Text(
                                                text = exportSuccessMessage!!,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = PalestineGreenDark
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // ==========================================
                // التبويب الثاني: رفع واستيراد بيانات الإكسل
                // ==========================================
                if (activeTab == ExcelTab.IMPORT_EXCEL) {
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = PalestineWhite),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, SlateBorder, RoundedCornerShape(16.dp))
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(PalestineRedLight),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.UploadFile, contentDescription = null, tint = PalestineRed, modifier = Modifier.size(20.dp))
                                    }
                                    Column {
                                        Text(
                                            text = "رفع واستيراد البيانات من ملف إكسل",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = SlateTextPrimary
                                        )
                                        Text(
                                            text = "استيراد ملفات الأسر والمساعدات والأبناء مباشرة لقاعدة البيانات Room",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SlateTextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                HorizontalDivider(color = SlateBorder)

                                // اختيار نوع البيانات المراد استيرادها
                                Text(
                                    text = "اختر نوع السجلات المراد استيرادها من الإكسل:",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SlateTextPrimary
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    ImportDataType.values().forEach { type ->
                                        val isSelected = selectedImportType == type
                                        Surface(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(10.dp))
                                                .clickable {
                                                    selectedImportType = type
                                                    parsedPreviewRows = emptyList()
                                                    loadedFileName = null
                                                    importStatusMessage = null
                                                },
                                            color = if (isSelected) PalestineGreenContainer else SlateSurfaceVariant,
                                            border = androidx.compose.foundation.BorderStroke(
                                                1.dp,
                                                if (isSelected) PalestineGreen else SlateBorder
                                            )
                                        ) {
                                            Column(
                                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                Text(text = type.icon, fontSize = 20.sp)
                                                Text(
                                                    text = type.label,
                                                    fontSize = 11.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                    color = if (isSelected) PalestineGreenDark else SlateTextPrimary,
                                                    textAlign = TextAlign.Center,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }

                                // منطقة رفع ملف الإكسل
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = SlateSurfaceVariant,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.CloudUpload,
                                            contentDescription = null,
                                            tint = PalestineGreen,
                                            modifier = Modifier.size(40.dp)
                                        )
                                        Text(
                                            text = if (loadedFileName != null) "الملف المحدد: $loadedFileName" else "اختر ملف Excel (.xlsx, .xls, .csv)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (loadedFileName != null) PalestineGreenDark else SlateTextPrimary
                                        )
                                        Text(
                                            text = "افتح مستعرض ملفات الجوال لاختيار ملف الإكسل بصيغة (*/*) وحفظ بياناته في قاعدة البيانات فوراً",
                                            fontSize = 11.sp,
                                            color = SlateTextSecondary,
                                            textAlign = TextAlign.Center
                                        )

                                        // زر فتح مستعرض ملفات الجوال
                                        Button(
                                            onClick = {
                                                excelFilePickerLauncher.launch("*/*")
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                            shape = RoundedCornerShape(10.dp),
                                            enabled = !isImporting,
                                            modifier = Modifier.fillMaxWidth(0.85f)
                                        ) {
                                            if (isImporting) {
                                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("جاري استيراد وحفظ البيانات...", fontSize = 12.sp)
                                            } else {
                                                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("استيراد من إكسل (*/*)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                if (importStatusMessage != null) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = if (importStatusMessage!!.startsWith("❌")) PalestineRed.copy(alpha = 0.1f) else PalestineGreenLight,
                                        border = androidx.compose.foundation.BorderStroke(
                                            1.dp,
                                            if (importStatusMessage!!.startsWith("❌")) PalestineRed.copy(alpha = 0.3f) else PalestineGreen.copy(alpha = 0.3f)
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = importStatusMessage ?: "",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (importStatusMessage!!.startsWith("❌")) PalestineRed else PalestineGreenDark,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }

                                // جدول المعاينة الحية للسجلات المقروءة من ملف الإكسل
                                if (parsedPreviewRows.isNotEmpty()) {
                                    Text(
                                        text = "معاينة السجلات المقروءة (${parsedPreviewRows.size} سجل):",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = SlateTextPrimary
                                    )

                                    parsedPreviewRows.forEachIndexed { index, row ->
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = SlateBackground,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(10.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    val primaryName = row["name"] ?: row["الاسم"] ?: row["aidTypeName"] ?: row["childName"] ?: "سجل ${index + 1}"
                                                    val primaryId = row["nationalID"] ?: row["رقم الهوية"] ?: row["familyNationalID"] ?: row["childNationalID"] ?: ""

                                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                        Text(
                                                            text = "${index + 1}. $primaryName",
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 12.sp,
                                                            color = SlateTextPrimary
                                                        )
                                                        if (primaryId.isNotBlank()) {
                                                            Surface(
                                                                shape = RoundedCornerShape(4.dp),
                                                                color = PalestineGreen.copy(alpha = 0.1f)
                                                            ) {
                                                                Text(
                                                                    text = "هوية: $primaryId",
                                                                    fontSize = 9.sp,
                                                                    fontWeight = FontWeight.Bold,
                                                                    color = PalestineGreenDark,
                                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                                )
                                                            }
                                                        }
                                                    }

                                                    val subInfo = row["locality"] ?: row["المحلية"] ?: row["projectName"] ?: row["birthDate"] ?: ""
                                                    if (subInfo.isNotBlank()) {
                                                        Text(text = subInfo, fontSize = 10.sp, color = SlateTextSecondary)
                                                    }
                                                }

                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = EmeraldSuccess.copy(alpha = 0.15f)
                                                ) {
                                                    Text(
                                                        text = "محفوظ بالغرفة",
                                                        fontSize = 10.sp,
                                                        color = EmeraldSuccess,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    // زر إعادة الدمج والتحديث اليدوي
                                    Button(
                                        onClick = {
                                            scope.launch {
                                                isImporting = true
                                                try {
                                                    when (selectedImportType) {
                                                        ImportDataType.FAMILIES -> {
                                                            val entities = parsedPreviewRows.map { r ->
                                                                FamilyEntity(
                                                                    nationalID = r["nationalID"] ?: r["رقم الهوية"] ?: "900000000",
                                                                    name = r["name"] ?: r["الاسم"] ?: "مستفيد جديد",
                                                                    familyMembersCount = (r["members"] ?: r["عدد الأفراد"])?.toIntOrNull() ?: 5,
                                                                    primaryPhone = r["phone"] ?: r["رقم الجوال"] ?: "0590000000",
                                                                    shelterStatus = r["shelter"] ?: r["حالة الإيواء"] ?: "إيواء داخلي",
                                                                    damageType = r["damage"] ?: r["حالة الضرر"] ?: "أضرار كلية",
                                                                    currentMainArea = "محافظة غزة",
                                                                    currentSubArea = r["locality"] ?: r["المحلية"] ?: "الرمال"
                                                                )
                                                            }
                                                            repository.insertFamilies(entities)
                                                            val msg = "تم حفظ وتحديث ${entities.size} أسرة بنجاح في قاعدة البيانات"
                                                            importStatusMessage = "✅ $msg"
                                                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                                        }
                                                        ImportDataType.AID_RECORDS -> {
                                                            val records = parsedPreviewRows.mapIndexed { idx, r ->
                                                                AidRecordEntity(
                                                                    familyID = (idx + 1).toLong(),
                                                                    aidTypeID = 1,
                                                                    projectID = 1L,
                                                                    aidDate = r["date"] ?: r["التاريخ"] ?: "2026-10-14",
                                                                    selectionDate = r["date"] ?: r["التاريخ"] ?: "2026-10-14",
                                                                    warehouse = r["warehouse"] ?: r["المستودع"] ?: "المستودع الرئيسي",
                                                                    recipientStatus = r["status"] ?: r["حالة الاستلام"] ?: "مستلم"
                                                                )
                                                            }
                                                            repository.insertAidRecords(records)
                                                            val msg = "تم حفظ وتحديث ${records.size} سجل مساعدة بنجاح في قاعدة البيانات"
                                                            importStatusMessage = "✅ $msg"
                                                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                                        }
                                                        ImportDataType.CHILDREN -> {
                                                            val children = parsedPreviewRows.map { r ->
                                                                ChildEntity(
                                                                    nationalID = r["childNationalID"] ?: r["هوية الطفل"] ?: "400000000",
                                                                    childName = r["childName"] ?: r["اسم الطفل"] ?: "طفل مستفيد",
                                                                    birthDate = r["birthDate"] ?: r["تاريخ الميلاد"] ?: "2020-01-01",
                                                                    gender = r["gender"] ?: r["الجنس"] ?: "ذكر",
                                                                    familyNationalID = r["familyNationalID"] ?: r["هوية الأسرة"] ?: "900000000",
                                                                    localityID = 1
                                                                )
                                                            }
                                                            repository.insertChildren(children)
                                                            val msg = "تم حفظ وتحديث ${children.size} طفل بنجاح في قاعدة البيانات"
                                                            importStatusMessage = "✅ $msg"
                                                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                                        }
                                                    }
                                                } catch (e: Exception) {
                                                    val errMsg = "حدث خطأ أثناء الحفظ: ${e.message}"
                                                    importStatusMessage = "❌ $errMsg"
                                                    Toast.makeText(context, errMsg, Toast.LENGTH_LONG).show()
                                                } finally {
                                                    isImporting = false
                                                }
                                            }
                                        },
                                        enabled = !isImporting,
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = PalestineRed),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = if (isImporting) "جاري الحفظ والتحديث..." else "إعادة تأكيد وحفظ بيانات الإكسل (${selectedImportType.label})",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
