package com.humanitarian.aidmanagement.ui.screens.delivery

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.components.SyncDetailsDialog
import com.humanitarian.aidmanagement.ui.components.SyncStatusBanner
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeliveryScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val aidRecords by repository.getAllAidRecords().collectAsState(initial = emptyList())
    val families by repository.getFamilies().collectAsState(initial = emptyList())
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val projects by repository.getActiveProjects().collectAsState(initial = emptyList())
    val syncState by repository.getSyncState().collectAsState()

    val familyMap = remember(families) { families.associateBy { it.familyID } }
    val aidTypeMap = remember(aidTypes) { aidTypes.associateBy { it.aidTypeID } }
    val projectMap = remember(projects) { projects.associateBy { it.projectID } }

    var searchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf("الكل") } // "الكل", "بانتظار التسليم", "تم التسليم"

    // حوارات التسليم والسند والمسح
    var recordToDeliver by remember { mutableStateOf<AidRecordEntity?>(null) }
    var recordForReceipt by remember { mutableStateOf<AidRecordEntity?>(null) }
    var showScannerDialog by remember { mutableStateOf(false) }
    var showSyncDialog by remember { mutableStateOf(false) }
    var actionMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()

    // تصفية السجلات
    val filteredRecords = remember(aidRecords, searchQuery, selectedStatusFilter, familyMap) {
        aidRecords.filter { record ->
            val family = familyMap[record.familyID]
            val familyName = family?.name ?: ""
            val nationalId = family?.nationalID ?: ""
            val projectNumber = projectMap[record.projectID]?.projectNumber ?: ""

            val matchesSearch = searchQuery.isBlank() ||
                    familyName.contains(searchQuery, ignoreCase = true) ||
                    nationalId.contains(searchQuery) ||
                    projectNumber.contains(searchQuery, ignoreCase = true)

            val isDelivered = record.recipientStatus.contains("مستلم") || record.recipientStatus.contains("تم التسليم")
            val matchesStatus = when (selectedStatusFilter) {
                "تم التسليم" -> isDelivered
                "بانتظار التسليم" -> !isDelivered
                else -> true
            }

            matchesSearch && matchesStatus
        }
    }

    val totalCount = aidRecords.size
    val deliveredCount = aidRecords.count { it.recipientStatus.contains("مستلم") || it.recipientStatus.contains("تم التسليم") }
    val pendingCount = totalCount - deliveredCount
    val deliveryRate = if (totalCount > 0) (deliveredCount * 100 / totalCount) else 0

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "تسليم وصرف المساعدات الميدانية",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "نقطة التوزيع وتوثيق الاستلام بالباركود",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { showSyncDialog = true }) {
                        Icon(
                            imageVector = if (syncState.isOnline) Icons.Default.CloudSync else Icons.Default.CloudOff,
                            contentDescription = "التزامن والعمل دون اتصال",
                            tint = if (syncState.isOnline) MaterialTheme.colorScheme.primary else Color(0xFFF59E0B)
                        )
                    }
                    IconButton(onClick = { showScannerDialog = true }) {
                        Icon(Icons.Default.Search, contentDescription = "مسح باركود الهوية", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            // شريط حالة المزامنة والعمل دون اتصال
            SyncStatusBanner(
                repository = repository,
                onOpenSyncDetails = { showSyncDialog = true }
            )

            Spacer(modifier = Modifier.height(6.dp))

            // شريط إحصائيات التسليم السريعة (KPIs)
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("إجمالي الكشوفات", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$totalCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    }
                    Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("تم التسليم", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$deliveredCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color(0xFF10B981))
                    }
                    Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("بانتظار الصرف", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$pendingCount", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color(0xFFF59E0B))
                    }
                    Divider(modifier = Modifier.height(28.dp).width(1.dp), color = MaterialTheme.colorScheme.surfaceVariant)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("نسبة الإنجاز", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                        Text("$deliveryRate%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color(0xFF0284C7))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // مربع البحث
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("بحث برقم الهوية (9 أرقام) أو اسم المواطن أو رقم المشروع...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "مسح")
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))

            // أزرار تصفية الحالة
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("الكل", "بانتظار التسليم", "تم التسليم").forEach { filterLabel ->
                    FilterChip(
                        selected = selectedStatusFilter == filterLabel,
                        onClick = { selectedStatusFilter = filterLabel },
                        label = { Text(filterLabel) }
                    )
                }
            }

            if (actionMessage != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF10B981).copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = actionMessage ?: "", color = Color(0xFF10B981), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "سجلات الصرف والتسليم (${filteredRecords.size} مستفيد):",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (filteredRecords.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f), modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("لا توجد سجلات مطابقة للبحث", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredRecords, key = { it.recordID }) { record ->
                        val family = familyMap[record.familyID]
                        val aidTypeName = aidTypeMap[record.aidTypeID]?.aidTypeName ?: "مساعدة #${record.aidTypeID}"
                        val projectNumber = projectMap[record.projectID]?.projectNumber ?: "مشروع #${record.projectID}"
                        val isDelivered = record.recipientStatus.contains("مستلم") || record.recipientStatus.contains("تم التسليم")

                        DeliveryCardItem(
                            record = record,
                            family = family,
                            aidTypeName = aidTypeName,
                            projectNumber = projectNumber,
                            isDelivered = isDelivered,
                            onDeliverClick = { recordToDeliver = record },
                            onReceiptClick = { recordForReceipt = record },
                            onUndoClick = {
                                scope.launch {
                                    repository.undoDelivery(record.recordID)
                                    actionMessage = "تم التراجع عن تسليم المساعدة للمواطن ${family?.name ?: ""}"
                                }
                            },
                            onDeleteClick = {
                                scope.launch {
                                    repository.deleteAidRecord(record.recordID)
                                    actionMessage = "تم حذف السجل بنجاح"
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // ==================== حوار تأكيد التسليم والصرف ====================
    if (recordToDeliver != null) {
        val targetRecord = recordToDeliver!!
        val targetFamily = familyMap[targetRecord.familyID]
        var recipientName by remember { mutableStateOf(targetFamily?.name ?: "") }
        var recipientRelation by remember { mutableStateOf("نفسه") }
        var notes by remember { mutableStateOf("تم التحقق من الهوية الأصلية وكرت المؤن") }

        AlertDialog(
            onDismissRequest = { recordToDeliver = null },
            title = {
                Text("تأكيد تسليم وصرف المساعدة", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "المستفيد الأساسي: ${targetFamily?.name ?: "غير محدد"}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "رقم الهوية الوطنية: ${targetFamily?.nationalID ?: "-"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )

                    Divider()

                    OutlinedTextField(
                        value = recipientName,
                        onValueChange = { recipientName = it },
                        label = { Text("اسم المستلم الفعلي") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Text("صفة المستلم:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("نفسه", "الزوجة", "ابن بالغ", "وكيل").forEach { rel ->
                            FilterChip(
                                selected = recipientRelation == rel,
                                onClick = {
                                    recipientRelation = rel
                                    if (rel == "نفسه") recipientName = targetFamily?.name ?: ""
                                    else if (rel == "الزوجة" && targetFamily?.wifeName != null) recipientName = targetFamily.wifeName ?: ""
                                },
                                label = { Text(rel, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("ملاحظات الصرف والتحقق") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            val combinedNotes = "المستلم: $recipientName ($recipientRelation) - $notes"
                            repository.deliverAid(targetRecord.recordID, recipientName, combinedNotes)
                            recordToDeliver = null
                            actionMessage = "تم تسليم المساعدة بنجاح للمواطن ${targetFamily?.name ?: ""}"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تأكيد الصرف والتسليم", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToDeliver = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // ==================== حوار سند الاستلام الرسمي ====================
    if (recordForReceipt != null) {
        val r = recordForReceipt!!
        val f = familyMap[r.familyID]
        val aidName = aidTypeMap[r.aidTypeID]?.aidTypeName ?: "مساعدة إغاثية"
        val prjNum = projectMap[r.projectID]?.projectNumber ?: "PRJ-2025"

        AlertDialog(
            onDismissRequest = { recordForReceipt = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("سند استلام مساعدة إنسانية معتمد", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ReceiptRow("رقم السند الميداني:", "REC-${r.recordID}-2025")
                        ReceiptRow("اسم رب الأسرة:", f?.name ?: "غير محدد")
                        ReceiptRow("رقم الهوية الوطنية:", f?.nationalID ?: "-")
                        ReceiptRow("عدد أفراد الأسرة:", "${f?.familyMembersCount ?: 0} أفراد")
                        ReceiptRow("نوع المساعدة:", aidName)
                        ReceiptRow("المشروع الإغاثي:", prjNum)
                        ReceiptRow("تاريخ التسليم:", r.deliveryDate ?: r.aidDate)
                        ReceiptRow("المستودع:", r.warehouse)
                        ReceiptRow("ملاحظات الصرف:", r.notes ?: "تم التسليم بحالة جيدة")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        recordForReceipt = null
                        actionMessage = "تم إرسال أمر طباعة السند REC-${r.recordID}"
                    }
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاركة / طباعة")
                }
            },
            dismissButton = {
                TextButton(onClick = { recordForReceipt = null }) {
                    Text("إغلاق")
                }
            }
        )
    }

    // ==================== حوار محاكي مسح الباركود ====================
    if (showScannerDialog) {
        var scannedIdInput by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showScannerDialog = false },
            title = { Text("مسح باركود الهوية الوطنية / كرت المؤن") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "وجّه الكاميرا نحو باركود الهوية أو أدخل رقم الهوية السريع:",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = scannedIdInput,
                        onValueChange = { scannedIdInput = it },
                        label = { Text("رقم الهوية (9 أرقام)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    searchQuery = scannedIdInput
                    showScannerDialog = false
                }) {
                    Text("بحث فوري")
                }
            },
            dismissButton = {
                TextButton(onClick = { showScannerDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    if (showSyncDialog) {
        SyncDetailsDialog(
            repository = repository,
            onDismiss = { showSyncDialog = false }
        )
    }
}

@Composable
fun DeliveryCardItem(
    record: AidRecordEntity,
    family: FamilyEntity?,
    aidTypeName: String,
    projectNumber: String,
    isDelivered: Boolean,
    onDeliverClick: () -> Unit,
    onReceiptClick: () -> Unit,
    onUndoClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = family?.name ?: "مواطن رقم #${record.familyID}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "الهوية: ${family?.nationalID ?: "-"} • الأفراد: ${family?.familyMembersCount ?: 0}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                }

                // حالة التسليم
                if (isDelivered) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تم التسليم", color = Color(0xFF10B981), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF59E0B).copy(alpha = 0.15f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("جاهز للصرف", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // تفاصيل نوع المساعدة والمشروع
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = aidTypeName,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = projectNumber,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }

            if (!record.notes.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = record.notes ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // أزرار الإجراءات
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isDelivered) {
                    Button(
                        onClick = onDeliverClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تسليم فوري", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                } else {
                    OutlinedButton(
                        onClick = onReceiptClick,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.List, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("سند الاستلام", fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    TextButton(
                        onClick = onUndoClick,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("تراجع", color = Color(0xFFF59E0B), fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.width(4.dp))
                IconButton(onClick = onDeleteClick, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun ReceiptRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
        Text(text = value, style = MaterialTheme.typography.bodySmall)
    }
}
