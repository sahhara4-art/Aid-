package com.humanitarian.aidmanagement.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.humanitarian.aidmanagement.data.local.dao.*
import com.humanitarian.aidmanagement.data.local.entities.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Database(
    entities = [
        UserEntity::class,
        RoleEntity::class,
        LocalityEntity::class,
        UserLocalityEntity::class,
        FamilyEntity::class,
        ChildEntity::class,
        AidTypeEntity::class,
        ProjectEntity::class,
        AidRecordEntity::class,
        ManualSelectionEntity::class,
        SelectedCitizenEntity::class,
        LocalityDistributionEntity::class,
        SystemSettingEntity::class,
        SyncQueueEntity::class,
        SyncLogEntity::class,
        UserPermissionEntity::class,
        UserAccessLogEntity::class,
        AuditLogEntity::class,
        NominationWorkflowEntity::class,
        ProjectQuotaEntity::class
    ],
    views = [
        EligibleFamiliesView::class
    ],
    version = 7,
    exportSchema = false
)
abstract class AidDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun familyDao(): FamilyDao
    abstract fun childDao(): ChildDao
    abstract fun aidTypeDao(): AidTypeDao
    abstract fun projectDao(): ProjectDao
    abstract fun aidRecordDao(): AidRecordDao
    abstract fun nominationDao(): NominationDao
    abstract fun localityDao(): LocalityDao
    abstract fun systemSettingDao(): SystemSettingDao
    abstract fun syncQueueDao(): SyncQueueDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun nominationWorkflowDao(): NominationWorkflowDao
    abstract fun projectQuotaDao(): ProjectQuotaDao
    abstract fun eligibleFamiliesDao(): EligibleFamiliesDao

    companion object {
        private const val TAG = "AidDatabase"
        const val DATABASE_NAME = "humanitarian_aid_database.db"

        @Volatile
        private var INSTANCE: AidDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AidDatabase {
            return INSTANCE ?: synchronized(this) {
                // 1. تحميل مكتبة تشفير SQLCipher قبل تهيئة المصنع
                try {
                    System.loadLibrary("sqlcipher")
                } catch (e: Throwable) {
                    android.util.Log.w(TAG, "SQLCipher System.loadLibrary: ${e.message}")
                }

                // 2. الحصول على مفتاح التشفير وتهيئة SupportOpenHelperFactory
                val passphrase = com.humanitarian.aidmanagement.data.security.DatabaseKeyManager.getOrCreateDatabaseKey(context)
                val factory = SupportOpenHelperFactory(passphrase)

                // 3. بناء قاعدة بيانات Room مع منع الانهيارات التدميرية وتعارض الإصدارات
                val builder = Room.databaseBuilder(
                    context.applicationContext,
                    AidDatabase::class.java,
                    DATABASE_NAME
                )
                    .openHelperFactory(factory)
                    .fallbackToDestructiveMigration()
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .addCallback(AidDatabaseCallback(scope))

                val instance = try {
                    builder.build()
                } catch (e: Exception) {
                    android.util.Log.e(TAG, "Failed to build encrypted database, clearing corrupted files for clean start", e)
                    try {
                        context.applicationContext.deleteDatabase(DATABASE_NAME)
                    } catch (_: Exception) {}
                    Room.databaseBuilder(
                        context.applicationContext,
                        AidDatabase::class.java,
                        DATABASE_NAME
                    )
                        .openHelperFactory(factory)
                        .fallbackToDestructiveMigration()
                        .fallbackToDestructiveMigrationOnDowngrade()
                        .addCallback(AidDatabaseCallback(scope))
                        .build()
                }

                INSTANCE = instance
                instance
            }
        }
    }

    private class AidDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(db: AidDatabase) {
            // 1. الأدوار
            val roles = listOf(
                RoleEntity(1, "مدير النظام", "صلاحيات كاملة لجميع العمليات والمحليات", true),
                RoleEntity(2, "مشرف محليات", "إدارة وترشيح الأسر ضمن محليات محددة", true),
                RoleEntity(3, "باحث ميداني", "عرض وإدخال بيانات الأسر والأطفال", true)
            )
            roles.forEach { db.userDao().insertRole(it) }

            // 2. مستخدم مدير النظام الافتراضي (admin / admin123)
            val adminUser = UserEntity(
                UserID = 1,
                UserName = "admin",
                PasswordHash = "admin123", // في بيئة الإنتاج يتم استخدام bcrypt/argon2
                fullName = "مهندس النظام - إدارة المساعدات",
                RoleID = 1,
                IsActive = true,
                CreatedBy = "النظام الأولي"
            )
            db.userDao().insertUser(adminUser)
            // ربط الأدمن بكل المحليات (0 تعني الكل)
            db.userDao().insertUserLocality(UserLocalityEntity(UserID = 1, LocalityID = 0))

            // 2.2 منح كافة الصلاحيات الإدارية والميدانية الشاملة لحساب الأدمن
            val allAdminPermissions = listOf(
                UserPermissionEntity(UserID = 1, PermissionKey = "families_view", Category = "الأسر", Description = "استعراض وبحث بيانات الأسر والمواطنين"),
                UserPermissionEntity(UserID = 1, PermissionKey = "families_create", Category = "الأسر", Description = "تسجيل وإضافة أسر جديدة"),
                UserPermissionEntity(UserID = 1, PermissionKey = "families_edit", Category = "الأسر", Description = "تعديل بيانات الأسر واعتماد التنمية"),
                UserPermissionEntity(UserID = 1, PermissionKey = "families_delete", Category = "الأسر", Description = "حذف وتجميد ملفات المواطنين"),
                UserPermissionEntity(UserID = 1, PermissionKey = "families_export", Category = "الأسر", Description = "تصدير كشوفات الأسر"),
                UserPermissionEntity(UserID = 1, PermissionKey = "children_view", Category = "الأطفال", Description = "استعراض سجل الأطفال"),
                UserPermissionEntity(UserID = 1, PermissionKey = "children_manage", Category = "الأطفال", Description = "إضافة وتعديل بيانات الأطفال"),
                UserPermissionEntity(UserID = 1, PermissionKey = "nomination_run", Category = "الترشيح", Description = "تشغيل محرك المفاضلة والترشيح الآلي"),
                UserPermissionEntity(UserID = 1, PermissionKey = "nomination_manual", Category = "الترشيح", Description = "الترشيح اليدوي للحالات الخاصة"),
                UserPermissionEntity(UserID = 1, PermissionKey = "nomination_criteria", Category = "الترشيح", Description = "تعديل معايير واشتراطات الأولوية"),
                UserPermissionEntity(UserID = 1, PermissionKey = "nomination_approve", Category = "الترشيح", Description = "اعتماد وترحيل المرشحين للصرف"),
                UserPermissionEntity(UserID = 1, PermissionKey = "delivery_view", Category = "التسليم", Description = "استعراض كشوفات التسليم والصرف"),
                UserPermissionEntity(UserID = 1, PermissionKey = "delivery_handover", Category = "التسليم", Description = "تنفيذ تسليم وصرف المساعدات"),
                UserPermissionEntity(UserID = 1, PermissionKey = "delivery_receipt_print", Category = "التسليم", Description = "طباعة وتصدير سندات الاستلام"),
                UserPermissionEntity(UserID = 1, PermissionKey = "delivery_undo", Category = "التسليم", Description = "التراجع عن تسليم مساعدة وإلغاؤها"),
                UserPermissionEntity(UserID = 1, PermissionKey = "delivery_scanner", Category = "التسليم", Description = "مسح الباركود و QR كود"),
                UserPermissionEntity(UserID = 1, PermissionKey = "projects_manage", Category = "المشاريع", Description = "إدارة المشاريع الإنسانية وأنواع المساعدات"),
                UserPermissionEntity(UserID = 1, PermissionKey = "warehouse_manage", Category = "المستودعات", Description = "إدارة المستودعات وحركات الصرف"),
                UserPermissionEntity(UserID = 1, PermissionKey = "reports_view", Category = "التقارير", Description = "الاطلاع على التقارير والمؤشرات"),
                UserPermissionEntity(UserID = 1, PermissionKey = "reports_pdf_export", Category = "التقارير", Description = "توليد وتصدير كشوفات PDF رسمية"),
                UserPermissionEntity(UserID = 1, PermissionKey = "users_manage", Category = "الأمان", Description = "إنشاء وتعديل وتجميد حسابات المستخدمين"),
                UserPermissionEntity(UserID = 1, PermissionKey = "permissions_edit", Category = "الأمان", Description = "تعريف وتعديل صلاحيات الأدوار والمستخدمين"),
                UserPermissionEntity(UserID = 1, PermissionKey = "security_policies", Category = "الأمان", Description = "ضبط سياسات الأمان وساعات الدوام"),
                UserPermissionEntity(UserID = 1, PermissionKey = "audit_logs_view", Category = "الأمان", Description = "فحص ومراقبة سجل التدقيق الأمني"),
                UserPermissionEntity(UserID = 1, PermissionKey = "backup_restore", Category = "الأمان", Description = "النسخ الاحتياطي واستعادة قاعدة البيانات"),
                UserPermissionEntity(UserID = 1, PermissionKey = "sync_manage", Category = "المزامنة", Description = "إدارة التزامن السحابي والميداني")
            )
            db.userDao().insertPermissions(allAdminPermissions)

            // 3. المحليات الرسمية
            val localities = listOf(
                LocalityEntity(1, "الرمال الشمالي", true),
                LocalityEntity(2, "الشيخ رضوان", true),
                LocalityEntity(3, "الشاطئ الشمالي والنصر", true),
                LocalityEntity(4, "الشاطئ الجنوبي", true),
                LocalityEntity(5, "مشروع عامر", true)
            )
            localities.forEach { db.localityDao().insertLocality(it) }

            // 4. نسب توزيع المحليات (المثال المطلوب: 20%, 30%, 20%, 15%, 15%)
            val distributions = listOf(
                LocalityDistributionEntity(1, 1, 20.0, 20, true),
                LocalityDistributionEntity(2, 2, 30.0, 30, true),
                LocalityDistributionEntity(3, 3, 20.0, 20, true),
                LocalityDistributionEntity(4, 4, 15.0, 15, true),
                LocalityDistributionEntity(5, 5, 15.0, 15, true)
            )
            db.localityDao().insertDistributions(distributions)

            // 5. أنواع المساعدات الإحدى عشرة بالترتيب
            val aidTypes = listOf(
                AidTypeEntity(1, "غذائي", "طرود وسلات غذائية أساسية", defaultExclusionDays = 30),
                AidTypeEntity(2, "خضروات وفواكه", "سلات خضار طازجة ومواد مكملة", defaultExclusionDays = 21),
                AidTypeEntity(3, "لحوم", "معلبات لحوم تنمية ولحوم طازجة", defaultExclusionDays = 45),
                AidTypeEntity(4, "مساعدات نقدية", "مساعدات مالية عاجلة ومباشرة", defaultExclusionDays = 60),
                AidTypeEntity(5, "كسوة", "ملابس شتوية وصيفية للأسر", defaultExclusionDays = 90),
                AidTypeEntity(6, "مساعدات صحية", "قوائم استلام الصحي ومستلزمات النظافة", defaultExclusionDays = 30),
                AidTypeEntity(7, "فرشات وشوادر", "استلام فرشات وشوادر وحرامات للإيواء", defaultExclusionDays = 120),
                AidTypeEntity(8, "أدوات مطبخ", "قائمة استلام أدوات مطبخ وأواني طهي", defaultExclusionDays = 180),
                AidTypeEntity(9, "بامبرز أطفال", "استلام بامبرز وحفاظات أطفال", defaultExclusionDays = 25),
                AidTypeEntity(10, "فارس الشهم", "مساعدات عملية الفارس الشهم المتنوعة", defaultExclusionDays = 30),
                AidTypeEntity(11, "تنمية اجتماعية", "مساعدات التنمية 2025 والتمكين", defaultExclusionDays = 60)
            )
            aidTypes.forEach { db.aidTypeDao().insertAidType(it) }

            // 6. مشاريع أولية
            val initialProjects = listOf(
                ProjectEntity(
                    projectID = 1,
                    projectNumber = "PRJ-2025-001",
                    projectName = "مشروع الإغاثة الغذائية العاجلة",
                    aidTypeID = 1,
                    detailedDescription = "توزيع 500 طرد غذائي عائلي للأسر المتضررة في مراكز الإيواء",
                    projectDate = "2025-02-15",
                    fundingInstitution = "الهيئة الخيرية للإغاثة",
                    quantity = 500,
                    isActive = true
                ),
                ProjectEntity(
                    projectID = 2,
                    projectNumber = "PRJ-2025-002",
                    projectName = "مشروع كسوة الشتاء والفرشات",
                    aidTypeID = 7,
                    detailedDescription = "توفير فرشات وشوادر وحرامات شتوية للأسر النازحة",
                    projectDate = "2025-02-20",
                    fundingInstitution = "صندوق الدعم الإنساني",
                    quantity = 250,
                    isActive = true
                )
            )
            initialProjects.forEach { db.projectDao().insertProject(it) }

            // 7. إعدادات فترات الاستثناء وشروط الترشيح
            val settings = listOf(
                SystemSettingEntity("max_failed_attempts", "5", "الحد الأقصى لمحاولات تسجيل الدخول الفاشلة"),
                SystemSettingEntity("lockout_duration_minutes", "15", "مدة قفل الحساب بالدقائق عند تجاوز المحاولات"),
                SystemSettingEntity("exclusion_aid_1", "30", "فترة استثناء السلة الغذائية (أيام)"),
                SystemSettingEntity("exclusion_aid_2", "21", "فترة استثناء الخضروات (أيام)"),
                SystemSettingEntity("exclusion_aid_3", "45", "فترة استثناء اللحوم (أيام)"),
                SystemSettingEntity("exclusion_aid_4", "60", "فترة استثناء المساعدات النقدية (أيام)"),
                SystemSettingEntity("exclusion_aid_5", "90", "فترة استثناء الكسوة (أيام)"),
                SystemSettingEntity("exclusion_aid_6", "30", "فترة استثناء المساعدات الصحية (أيام)"),
                SystemSettingEntity("exclusion_aid_7", "120", "فترة استثناء الفرشات والشوادر (أيام)"),
                SystemSettingEntity("exclusion_aid_8", "180", "فترة استثناء أدوات المطبخ (أيام)"),
                SystemSettingEntity("exclusion_aid_9", "25", "فترة استثناء بامبرز الأطفال (أيام)"),
                SystemSettingEntity("exclusion_aid_10", "30", "فترة استثناء فارس الشهم (أيام)"),
                SystemSettingEntity("exclusion_aid_11", "60", "فترة استثناء التنمية الاجتماعية (أيام)")
            )
            settings.forEach { db.systemSettingDao().setSetting(it) }

            // 8. بذر أسر أولية نموذجية للاختبار والتشغيل الميداني
            val sampleFamilies = listOf(
                FamilyEntity(
                    name = "أحمد محمود خليل الأسطل",
                    nationalID = "901234561",
                    birthDate = "1978-05-12",
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 8,
                    wifeName = "فاطمة إبراهيم رضوان",
                    wifeNationalID = "901234562",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    worksApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "أضرار كلية",
                    shelterStatus = "إيواء داخلي",
                    localityID = 1,
                    notes = "أسرة مهدم بيتها كلياً تعيش في مركز إيواء"
                ),
                FamilyEntity(
                    name = "محمد سالم عبد الرحمن النجار",
                    nationalID = "902345672",
                    birthDate = "1982-11-20",
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 9,
                    wifeName = "مريم كمال دغمش",
                    wifeNationalID = "902345673",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    worksApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "أضرار كلية",
                    shelterStatus = "إيواء داخلي",
                    localityID = 2,
                    notes = "أولوية قصوى - 7 أطفال صغار"
                ),
                FamilyEntity(
                    name = "خالد سليم حسن بربخ",
                    nationalID = "903456783",
                    birthDate = "1975-02-14",
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 7,
                    wifeName = "سعاد عمر شعت",
                    wifeNationalID = "903456784",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    worksApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "أضرار كلية",
                    shelterStatus = "إيواء داخلي",
                    localityID = 3,
                    notes = "حالة إنسانية عاجلة"
                ),
                FamilyEntity(
                    name = "ياسر مصطفى علي فياض",
                    nationalID = "904567894",
                    birthDate = "1985-09-03",
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 6,
                    wifeName = "أمينة حسن صيام",
                    wifeNationalID = "904567895",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    worksApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "أضرار جزئية بليغة",
                    shelterStatus = "إيواء داخلي",
                    localityID = 4,
                    notes = "معيل مريض"
                ),
                FamilyEntity(
                    name = "عبد الكريم جابر مسعود عابد",
                    nationalID = "905678905",
                    birthDate = "1980-07-25",
                    gender = "ذكر",
                    maritalStatus = "متزوج",
                    familyMembersCount = 10,
                    wifeName = "زينب فريد حسونة",
                    wifeNationalID = "905678906",
                    developmentApproval = "معتمد",
                    localityApproval = "معتمد",
                    worksApproval = "معتمد أشغال",
                    residentStatus = "مقيم",
                    damageType = "أضرار كلية",
                    shelterStatus = "إيواء داخلي",
                    localityID = 5,
                    notes = "أسرة كبيرة العدد بدون أي معيل"
                )
            )

            sampleFamilies.forEach { db.familyDao().insertFamily(it) }

            // بذر أطفال
            val sampleChildren = listOf(
                ChildEntity(nationalID = "410111221", childName = "عمر أحمد الأسطل", birthDate = "2018-04-10", gender = "ذكر", familyNationalID = "901234561", localityID = 1),
                ChildEntity(nationalID = "410111222", childName = "سارة أحمد الأسطل", birthDate = "2020-09-15", gender = "أنثى", familyNationalID = "901234561", localityID = 1),
                ChildEntity(nationalID = "410222331", childName = "يوسف محمد النجار", birthDate = "2017-01-22", gender = "ذكر", familyNationalID = "902345672", localityID = 2),
                ChildEntity(nationalID = "410222332", childName = "تسنيم محمد النجار", birthDate = "2021-06-30", gender = "أنثى", familyNationalID = "902345672", localityID = 2)
            )
            sampleChildren.forEach { db.childDao().insertChild(it) }
        }
    }
}
