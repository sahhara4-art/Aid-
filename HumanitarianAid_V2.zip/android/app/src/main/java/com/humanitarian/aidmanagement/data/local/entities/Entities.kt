package com.humanitarian.aidmanagement.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Index

/**
 * tbl_Users - جدول المستخدمين ومنظومة الأمان والتحكم في الدخول
 */
@Entity(
    tableName = "tbl_Users",
    indices = [
        Index(value = ["UserName"], unique = true),
        Index(value = ["NationalID"])
    ]
)
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val UserID: Int = 0,
    val UserName: String,
    val PasswordHash: String,
    val FullName: String,
    val NationalID: String = "",
    val Email: String? = null,
    val PhoneNumber: String? = null,
    val RoleID: Int,
    val RoleName: String = "مدير النظام",
    // ضوابط وقيود الدخول والاستخدام المتقدمة
    val MaxAllowedLogins: Int = 0, // الحد الأقصى لمرات الدخول المسموح بها (0 = غير محدود)
    val ConsumedLogins: Int = 0, // عدد مرات الدخول المستهلكة
    val SessionDurationMinutes: Int = 60, // مدة الجلسة المسموح بها بالدقائق
    val AccountExpiryDate: String? = null, // تاريخ انتهاء صلاحية الحساب (YYYY-MM-DD)
    val AllowedStartTime: String = "08:00", // نافذة بدء ساعات العمل
    val AllowedEndTime: String = "17:00", // نافذة نهاية ساعات العمل
    val AllowedWarehouse: String = "كافة المستودعات", // تقييد المستودع
    val AllowedLocalityID: Int = 0, // تقييد المنطقة/المحلية (0 = الكل)
    val AllowedGroup: String = "كافة المجموعات", // مجموعة العمل والتوزيع الميداني (مجموعة أ، مجموعة ب، فريق المخيمات، إلخ)
    // الصلاحيات الجغرافية المعتمدة على المناطق الفرعية الحالية
    val AllowedViewSubAreas: String = "*", // المناطق الفرعية الحالية المصرح بمشاهدتها (* أو قائمة محددة)
    val AllowedNominationSubAreas: String = "*", // المناطق الفرعية الحالية المصرح بالترشيح فيها
    val AllowedDeliverySubAreas: String = "*", // المناطق الفرعية الحالية المصرح بالتسليم والصرف فيها
    val AllowedEditSubAreas: String = "*", // المناطق الفرعية الحالية المصرح بتعديل أسرها
    val AllowedScreens: String = "dashboard,families,nomination,delivery,reports,excel_import_export,users,backup", // الشاشات المصرح بظهورها واستخدامها
    val IsActive: Boolean = true,
    val IsLocked: Boolean = false,
    val FailedAttempts: Int = 0,
    val LastLogin: Long? = null,
    val MustChangePassword: Boolean = false,
    val CreatedDate: Long = System.currentTimeMillis(),
    val CreatedBy: String = "System",
    val ModifiedDate: Long? = null,
    val ModifiedBy: String? = null,
    val LockedUntil: Long? = null // توقيت انتهاء قفل الحساب عند تجاوز المحاولات الفاشلة
) {
    val userId: Int @androidx.room.Ignore get() = UserID
    val fullName: String @androidx.room.Ignore get() = FullName
    val allowedLocalityId: Int @androidx.room.Ignore get() = AllowedLocalityID
    val isActive: Boolean @androidx.room.Ignore get() = IsActive
}

/**
 * tbl_User_Permissions - جدول الصلاحيات الدقيقة المفصلة لكل مستخدم
 */
@Entity(
    tableName = "tbl_User_Permissions",
    indices = [
        Index(value = ["UserID", "PermissionKey"], unique = true)
    ]
)
data class UserPermissionEntity(
    @PrimaryKey(autoGenerate = true)
    val PermissionID: Long = 0,
    val UserID: Int,
    val PermissionKey: String, // e.g. "delivery_handover", "nomination_run"
    val Category: String, // أسر، ترشيح، تسليم، مشاريع، تقارير، أمان
    val Description: String,
    val IsGranted: Boolean = true
)

/**
 * tbl_User_Access_Logs - سجل التدقيق الأمني وعمليات الدخول والنشاط
 */
@Entity(
    tableName = "tbl_User_Access_Logs",
    indices = [
        Index(value = ["UserID"]),
        Index(value = ["Timestamp"])
    ]
)
data class UserAccessLogEntity(
    @PrimaryKey(autoGenerate = true)
    val LogID: Long = 0,
    val UserID: Int,
    val UserName: String,
    val ActionType: String, // تسجيل دخول ناجح، محاولة مرفوضة، نفاد الحصة، خارج ساعات الدوام
    val Timestamp: String,
    val IPAddress: String = "192.168.1.100",
    val DeviceName: String = "Android Mobile Terminal",
    val Status: String = "ناجح", // ناجح، مرفوض، تحذير
    val Details: String
)

/**
 * tbl_Roles - جدول الأدوار والصلاحيات
 */
@Entity(tableName = "tbl_Roles")
data class RoleEntity(
    @PrimaryKey
    val RoleID: Int,
    val RoleName: String,
    val Description: String,
    val IsActive: Boolean = true
)

/**
 * tbl_Localities - جدول المحليات
 */
@Entity(tableName = "tbl_Localities")
data class LocalityEntity(
    @PrimaryKey(autoGenerate = true)
    val LocalityID: Int = 0,
    val LocalityName: String,
    val IsActive: Boolean = true
)

/**
 * tbl_UserLocalities - ربط المستخدم بالمحليات المسموح له التعامل معها
 */
@Entity(tableName = "tbl_UserLocalities")
data class UserLocalityEntity(
    @PrimaryKey(autoGenerate = true)
    val UserLocalityID: Int = 0,
    val UserID: Int,
    val LocalityID: Int // 0 يعني كل المحليات
)

/**
 * families - جدول بيانات المواطنين والأسر المعتمد رسمياً (36 حقلاً شاملاً)
 */
@Entity(
    tableName = "families",
    indices = [
        Index(value = ["nationalID"], unique = true),
        Index(value = ["localityID"]),
        Index(value = ["developmentApproval"]),
        Index(value = ["rationCardNumber"])
    ]
)
data class FamilyEntity(
    @PrimaryKey(autoGenerate = true)
    val familyID: Long = 0,
    // 1. رقم الهوية
    val nationalID: String,
    // 2. الاسم رباعي
    val name: String,
    // 3. الجنس (ذكر / أنثى)
    val gender: String = "ذكر",
    // 4. تاريخ الميلاد
    val birthDate: String = "1985-01-01",
    // 5. العمر
    val age: Int = 40,
    // 6. الحالة الاجتماعية (متزوج / أعزب / أرمل / مطلق)
    val maritalStatus: String = "متزوج",
    // 7. الوفاة (على قيد الحياة / متوفى)
    val deathStatus: String = "على قيد الحياة",
    // 8. تاريخ الوفاة
    val deathDate: String? = null,
    // 9. جوال أساسي
    val primaryPhone: String = "",
    // 10. جوال بديل ١
    val alternativePhone1: String? = null,
    // 11. جوال بديل ٢
    val alternativePhone2: String? = null,

    // 👨‍👩‍👧 بيانات الأسرة
    // 12. اسم الزوج/الزوجة
    val wifeName: String? = null,
    // 13. هوية الزوج/الزوجة
    val wifeNationalID: String? = null,
    // 14. عدد أفراد الأسرة
    val familyMembersCount: Int = 1,
    // 15. حالة الضرر (كلي، جزئي بليغ، جزئي غير صالح للسكن، جزئي صالح للسكن، لا يوجد)
    val damageType: String = "أضرار كلية",
    // 16. وصف الضرر
    val damageDescription: String? = null,
    // 17. حالة الإصابة (سليم، مصاب، مبتور، شهيد...)
    val injuryStatus: String = "سليم",
    // 18. تاريخ الإصابة
    val injuryDate: String? = null,
    // 19. مصدر الدخل ١
    val incomeSource1: String = "بلا عمل",
    // 20. مصدر الدخل ٢
    val incomeSource2: String? = null,
    // 21. رقم كرت المؤن
    val rationCardNumber: String? = null,

    // بيانات المناطق الأصلية
    // 22. المنطقة الرئيسية الأصلية
    val originalMainArea: String = "",
    // 23. المنطقة الفرعية الأصلية
    val originalSubArea: String = "",
    // 24. الشعبة الأصلية
    val originalBranch: String = "",
    // 25. المسجد الأصلي
    val originalMosque: String = "",

    // بيانات المناطق الحالية
    // 26. المنطقة الرئيسية الحالية
    val currentMainArea: String = "",
    // 27. المنطقة الفرعية الحالية
    val currentSubArea: String = "",
    // 28. الشعبة الحالية
    val currentBranch: String = "",
    // 29. المسجد الحالي
    val currentMosque: String = "",

    // حالات الاعتماد والإيواء
    // 30. حالة اعتماد التنمية: معتمد ، حجب اعتماد ، مجمد
    val developmentApproval: String = "معتمد",
    // 31. حالة اعتماد المناطق
    val localityApproval: String = "معتمد",
    // 32. مقيم/نازح
    val residentStatus: String = "مقيم",
    // 33. حالة اعتماد الأشغال: "اعتماد أشغال" أو فارغ أو ما يكتب في الحقل
    val worksApproval: String = "اعتماد أشغال",
    // 34. حالة الإيواء: "إيواء داخلي" أو فارغ (يعني خارج الإيواء)
    val shelterStatus: String = "إيواء داخلي",
    // 35. اسم المخيم/ مركز الإيواء
    val campOrCenterName: String? = null,
    // 36. ملاحظات
    val notes: String? = null,

    val localityID: Int = 1,
    val createdDate: Long = System.currentTimeMillis(),
    val modifiedDate: Long? = null
)

// خصائص مساعدة لتسهيل الوصول والتوافق البرمجي لبيانات الأسرة
val FamilyEntity.mobileNumber: String get() = primaryPhone
val FamilyEntity.originalAddress: String get() = listOf(originalMainArea, originalSubArea, originalBranch, originalMosque).filter { it.isNotBlank() }.joinToString(" - ").ifEmpty { "غير محدد" }

/**
 * children - جدول الأطفال التابعين للأسرة
 */
@Entity(
    tableName = "children",
    indices = [
        Index(value = ["familyNationalID"]),
        Index(value = ["nationalID"])
    ]
)
data class ChildEntity(
    @PrimaryKey(autoGenerate = true)
    val childID: Long = 0,
    val nationalID: String,
    val childName: String,
    val birthDate: String,
    val gender: String,
    val familyNationalID: String,
    val localityID: Int,
    val shelterStatus: String = "إيواء داخلي"
)

/**
 * aid_types - أنواع المساعدات
 */
@Entity(tableName = "aid_types")
data class AidTypeEntity(
    @PrimaryKey
    val aidTypeID: Int,
    val aidTypeName: String,
    val description: String,
    val defaultExclusionDays: Int = 30, // فترة الاستثناء بالأيام
    val isActive: Boolean = true
)

// خاصية مساعدة لتسهيل الوصول والتوافق البرمجي لاسم المعونة
val AidTypeEntity.typeName: String get() = aidTypeName

/**
 * projects - المشاريع الإنسانية المنفذة
 */
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true)
    val projectID: Long = 0,
    val projectNumber: String,
    val projectName: String, // اسم المشروع المكتوب يدوياً
    val aidTypeID: Int,
    val detailedDescription: String,
    val projectDate: String, // تاريخ الترشيح
    val actualNominationDate: String? = null, // تاريخ الترشيح الفعلي مع الوقت
    val fundingInstitution: String, // الجهة الممولة
    val warehouseName: String = "المستودع الرئيسي", // المخزن المنفذ منه
    val aidValue: Double = 0.0, // قيمة المساعدات
    val stageUserName: String? = null, // اسم المستخدم لمراحل الترشيح
    val quantity: Int,
    val notes: String? = null, // ملاحظات الترشيح
    val isActive: Boolean = true
)

/**
 * aid_records - سجلات المساعدات الموزعة
 */
@Entity(
    tableName = "aid_records",
    indices = [
        Index(value = ["familyID"]),
        Index(value = ["aidTypeID"]),
        Index(value = ["projectID"])
    ]
)
data class AidRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val aidRecordID: Long = 0,
    val familyID: Long,
    val aidTypeID: Int,
    val projectID: Long,
    val aidDate: String,
    val selectionDate: String, // تاريخ الترشيح
    val actualNominationDate: String? = null, // تاريخ الترشيح الفعلي
    val nominationMechanism: String = "آلي", // آلية الترشيح لكل شخص ("يدوي" أو "آلي")
    val stageUserName: String? = null, // اسم المستخدم لمراحل الترشيح
    val recipientStatus: String = "مرشح", // مرشح / مستفيد / مستلم
    val warehouse: String = "المستودع الرئيسي",
    val aidValue: Double = 0.0,
    val deliveryDate: String? = null,
    val deliveryTime: String? = null,
    val notes: String? = null // ملاحظات الترشيح
)

// خاصية مساعدة لتسهيل الوصول والتوافق البرمجي دون التأثير على أعمدة Room
val AidRecordEntity.recordID: Long get() = aidRecordID

/**
 * tbl_Manual_Selection - جدول الترشيح اليدوي
 */
@Entity(tableName = "tbl_Manual_Selection")
data class ManualSelectionEntity(
    @PrimaryKey(autoGenerate = true)
    val ID: Long = 0,
    val CitizenID: Long, // familyID
    val SelectionDate: String,
    val ActualNominationDate: String? = null,
    val UserID: Int,
    val StageUserName: String? = null,
    val AidTypeID: Int = 0,
    val ProjectID: Long = 0,
    val Notes: String? = null
)

/**
 * tbl_Selected_Citizens - جدول المواطنين المرشحين المعتمدين
 */
@Entity(
    tableName = "tbl_Selected_Citizens",
    indices = [
        Index(value = ["CitizenID", "AidTypeID", "ProjectID"])
    ]
)
data class SelectedCitizenEntity(
    @PrimaryKey(autoGenerate = true)
    val ID: Long = 0,
    val CitizenID: Long, // familyID
    val SelectionDate: String, // تاريخ الترشيح
    val ActualNominationDate: String? = null, // تاريخ الترشيح الفعلي
    val SelectionType: String, // آلية الترشيح: "يدوي" أو "آلي"
    val AidTypeID: Int,
    val ProjectID: Long,
    val UserID: Int,
    val StageUserName: String? = null, // اسم المستخدم لمراحل الترشيح
    val NominationNotes: String? = null // ملاحظات الترشيح
)

/**
 * locality_distribution - نسب وتوزيع المحليات
 */
@Entity(tableName = "locality_distribution")
data class LocalityDistributionEntity(
    @PrimaryKey(autoGenerate = true)
    val distributionID: Int = 0,
    val localityID: Int,
    val distributionPercentage: Double, // مثلاً 20.0 لـ 20%
    val distributionCount: Int,
    val isActive: Boolean = true
)

/**
 * system_settings - إعدادات فترات الاستثناء وشروط الترشيح
 */
@Entity(tableName = "system_settings")
data class SystemSettingEntity(
    @PrimaryKey
    val key: String,
    val value: String,
    val description: String
)

/**
 * sync_queue - طابور التزامن المحلي للعمل دون اتصال بالإنترنت (Offline-First Sync Queue)
 */
@Entity(tableName = "sync_queue")
data class SyncQueueEntity(
    @PrimaryKey(autoGenerate = true)
    val syncId: Long = 0,
    val entityType: String,      // "FAMILY", "AID_RECORD", "NOMINATION_SELECTION", "USER"
    val operation: String,       // "INSERT", "UPDATE", "DELETE"
    val recordId: String,        // المعرف المحلي للسجل
    val payloadJson: String,     // محتوى السجل بتنسيق JSON للمزامنة
    val createdAt: Long = System.currentTimeMillis(),
    val status: String = "PENDING", // "PENDING", "SYNCING", "SYNCED", "FAILED"
    val retryCount: Int = 0,
    val errorMessage: String? = null
)

/**
 * sync_log - سجل تاريخ عمليات التزامن التلقائي واليدوي
 */
@Entity(tableName = "sync_log")
data class SyncLogEntity(
    @PrimaryKey(autoGenerate = true)
    val logId: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val syncType: String,        // "AUTO_RECONNECT", "MANUAL", "PERIODIC_BACKGROUND"
    val itemsProcessed: Int,
    val itemsSucceeded: Int,
    val itemsFailed: Int,
    val status: String,          // "SUCCESS", "PARTIAL", "FAILED"
    val summary: String
)

/**
 * tbl_Audit_Logs - جدول سجل التعديلات والعمليات الخاص بكل مستخدم (Audit Log)
 * يقوم بتسجيل أي عملية إضافة أو تعديل أو حذف للبيانات مع الطابع الزمني
 */
@Entity(
    tableName = "tbl_Audit_Logs",
    indices = [
        Index(value = ["userId"]),
        Index(value = ["timestamp"]),
        Index(value = ["operationType"]),
        Index(value = ["targetTable"])
    ]
)
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val logId: Long = 0,
    val userId: Int,
    val userName: String,
    val userFullName: String = "",
    val operationType: String, // "إضافة" (INSERT) | "تعديل" (UPDATE) | "حذف" (DELETE)
    val targetTable: String,   // "الأسر" | "المساعدات" | "الأطفال" | "المستخدمين"
    val recordId: String,      // معرّف السجل (مثل رقم الهوية أو رقم السجل)
    val description: String,   // تفاصيل العملية والتعديل المنفذ
    val timestamp: Long = System.currentTimeMillis(),
    val formattedDate: String = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(timestamp))
)

/**
 * سجل حصة وتوزيع المنطقة الفرعية
 */
data class SubAreaShareRecord(
    val currentSubArea: String,
    val familyCount: Int = 0,
    val ratio: Double = 0.0
) {
    val totalFamilies: Int get() = familyCount
    val percentage: String get() = String.format(java.util.Locale.US, "%.2f%%", ratio)

    constructor(currentSubArea: String, totalFamilies: Int, percentage: String) : this(
        currentSubArea = currentSubArea,
        familyCount = totalFamilies,
        ratio = percentage.replace("%", "").trim().toDoubleOrNull() ?: 0.0
    )
}
