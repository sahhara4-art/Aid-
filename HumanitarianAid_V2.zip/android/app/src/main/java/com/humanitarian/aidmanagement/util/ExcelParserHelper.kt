package com.humanitarian.aidmanagement.util

import org.apache.poi.ss.usermodel.*
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.InputStream
import java.io.OutputStream

object ExcelParserHelper {
    /**
     * العناوين القياسية الخاصة ببيانات الأسر FamilyEntity (36 حقلاً بالإضافة لـ "المحلية المعتمدة")
     */
    val FAMILY_TEMPLATE_HEADERS = listOf(
        "رقم الهوية الوطنية",
        "اسم المستفيد الرباعي",
        "الجنس",
        "تاريخ الميلاد",
        "العمر",
        "الحالة الاجتماعية",
        "حالة الوفاة",
        "تاريخ الوفاة",
        "رقم الجوال للتواصل",
        "رقم جوال بديل 1",
        "رقم جوال بديل 2",
        "اسم الزوج/الزوجة",
        "رقم هوية الزوج/الزوجة",
        "عدد أفراد الأسرة",
        "حالة الضرر",
        "وصف أضرار المنزل",
        "حالة الإصابة",
        "تاريخ الإصابة",
        "مصدر الدخل الأول",
        "مصدر الدخل الثاني",
        "رقم كرت المؤن / الوكالة",
        "المنطقة الرئيسية الأصلية",
        "المنطقة الفرعية الأصلية",
        "الشعبة الأصلية",
        "المسجد الأصلي",
        "المنطقة الرئيسية الحالية",
        "المنطقة الفرعية الحالية",
        "الشعبة الحالية",
        "المسجد الحالي",
        "حالة الاعتماد",
        "اعتماد المناطق والمحليات",
        "صفة الإقامة (مقيم / نازح)",
        "اعتماد وزارة الأشغال",
        "حالة الإيواء",
        "اسم المخيم أو مركز الإيواء",
        "ملاحظات ميدانية",
        "المحلية المعتمدة"
    )

    /**
     * العناوين القياسية الخاصة ببيانات الأبناء والتابعين ChildEntity
     */
    val CHILDREN_TEMPLATE_HEADERS = listOf(
        "رقم هوية الطفل",
        "اسم الطفل الرباعي",
        "تاريخ الميلاد",
        "الجنس",
        "رقم هوية رب الأسرة",
        "رقم المحلية",
        "حالة الإيواء"
    )

    /**
     * العناوين القياسية الخاصة بسجلات المساعدات AidRecordEntity
     */
    val AID_RECORDS_TEMPLATE_HEADERS = listOf(
        "رقم هوية الأسرة",
        "نوع المساعدة",
        "رقم أو اسم المشروع",
        "تاريخ المساعدة",
        "تاريخ الترشيح",
        "حالة الاستلام",
        "تاريخ التسليم الفعلي",
        "اسم المستلم الفعلي",
        "المستودع",
        "قيمة المساعدة",
        "ملاحظات"
    )

    /**
     * قراءة وتفكيك أي ملف إكسل وتحويله إلى قائمة صفوف كخرائط مفتاح-قيمة
     */
    fun parseExcelFile(inputStream: InputStream): List<Map<String, String>> {
        val parsedData = mutableListOf<Map<String, String>>()
        try {
            val workbook = WorkbookFactory.create(inputStream)
            val sheet = workbook.getSheetAt(0)
            val headerRow = sheet.getRow(0) ?: return emptyList()
            val headers = mutableListOf<String>()
            val formatter = DataFormatter()

            for (cell in headerRow) {
                headers.add(formatter.formatCellValue(cell).trim())
            }

            for (i in 1..sheet.lastRowNum) {
                val row = sheet.getRow(i) ?: continue
                val rowData = mutableMapOf<String, String>()
                var hasAnyData = false
                for (j in 0 until headers.size) {
                    val cell = row.getCell(j, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK)
                    val value = formatter.formatCellValue(cell).trim()
                    if (value.isNotBlank()) hasAnyData = true
                    rowData[headers[j]] = value
                }
                if (hasAnyData) {
                    parsedData.add(rowData)
                }
            }
            workbook.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return parsedData
    }

    /**
     * استيراد وتفكيك ملف إكسل الخاص بالأبناء
     */
    fun parseChildrenExcelFile(inputStream: InputStream): List<Map<String, String>> {
        return parseExcelFile(inputStream)
    }

    /**
     * استيراد وتفكيك ملف إكسل الخاص بسجلات المساعدات
     */
    fun parseAidRecordsExcelFile(inputStream: InputStream): List<Map<String, String>> {
        return parseExcelFile(inputStream)
    }

    /**
     * توليد قالب إكسل رسمي (.xlsx) للأسر
     */
    fun generateFamilyTemplate(outputStream: OutputStream) {
        generateWorkbookWithHeaders("قالب_استيراد_الأسر", FAMILY_TEMPLATE_HEADERS, IndexedColors.SEA_GREEN.index, outputStream)
    }

    /**
     * توليد قالب إكسل رسمي (.xlsx) للأبناء
     */
    fun generateChildrenTemplate(outputStream: OutputStream) {
        generateWorkbookWithHeaders("قالب_استيراد_الأبناء", CHILDREN_TEMPLATE_HEADERS, IndexedColors.ROYAL_BLUE.index, outputStream)
    }

    /**
     * توليد قالب إكسل رسمي (.xlsx) لسجلات المساعدات
     */
    fun generateAidRecordsTemplate(outputStream: OutputStream) {
        generateWorkbookWithHeaders("قالب_سجلات_المساعدات", AID_RECORDS_TEMPLATE_HEADERS, IndexedColors.DARK_TEAL.index, outputStream)
    }

    private fun generateWorkbookWithHeaders(
        sheetTitle: String,
        headers: List<String>,
        headerColorIndex: Short,
        outputStream: OutputStream
    ) {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet(sheetTitle)
        sheet.isRightToLeft = true

        val headerRow = sheet.createRow(0)

        val headerFont = workbook.createFont().apply {
            bold = true
            color = IndexedColors.WHITE.index
            fontHeightInPoints = 11.toShort()
        }

        val headerStyle = workbook.createCellStyle().apply {
            setFont(headerFont)
            fillForegroundColor = headerColorIndex
            fillPattern = FillPatternType.SOLID_FOREGROUND
            alignment = HorizontalAlignment.CENTER
            verticalAlignment = VerticalAlignment.CENTER
        }

        for (i in headers.indices) {
            val cell = headerRow.createCell(i)
            cell.setCellValue(headers[i])
            cell.cellStyle = headerStyle
            sheet.setColumnWidth(i, 22 * 256)
        }

        workbook.write(outputStream)
        workbook.close()
    }
}
