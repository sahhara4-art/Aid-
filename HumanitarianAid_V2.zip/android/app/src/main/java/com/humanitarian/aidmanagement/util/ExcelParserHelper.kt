package com.humanitarian.aidmanagement.util

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.poi.ss.usermodel.*
import java.io.BufferedInputStream
import java.io.InputStream
import java.nio.charset.Charset
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.*

/**
 * نتيجة قراءة ملف الإكسل
 */
data class ExcelParseResult(
    val headers: List<String>,
    val rows: List<Map<String, String>>,
    val rowCount: Int,
    val sourceFormat: String // XLSX, XLS, CSV_UTF8, etc.
)

/**
 * معالج قراءة ملفات الإكسل (ExcelParserHelper)
 * يدعم قراءة ملفات .xlsx و .xls المباشرة عبر مكتبة Apache POI مع التعامل السليم مع نصوص اللغة العربية والترميز UTF-8
 * ويدعم أيضاً ملفات CSV/TSV ذات الترميزات المتعددة مع تنظيف الخلايا (trim) لمنع الأخطاء.
 */
object ExcelParserHelper {

    /**
     * قراءة واستخراج البيانات من أي ملف إكسل أو جدول بيانات على Dispatchers.IO
     */
    suspend fun parseFromUri(
        context: Context,
        uri: Uri,
        fileName: String
    ): ExcelParseResult = withContext(Dispatchers.IO) {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            parseStream(stream, fileName)
        } ?: ExcelParseResult(emptyList(), emptyList(), 0, "ERROR_OPENING_STREAM")
    }

    /**
     * قراءة دفق الملف وتحويله إلى جداول وسجلات نقية
     */
    fun parseStream(
        inputStream: InputStream,
        fileName: String
    ): ExcelParseResult {
        val bufferedStream = if (inputStream is BufferedInputStream) inputStream else BufferedInputStream(inputStream)
        bufferedStream.mark(15 * 1024 * 1024) // 15MB limit for mark/reset

        val isBinary = isExcelBinaryFormat(bufferedStream, fileName)

        if (isBinary) {
            try {
                return parseWithApachePoi(bufferedStream, fileName)
            } catch (e: Exception) {
                // في حال تعذر القراءة كملف ثنائي عبر POI، نعيد ضبط الدفق للتجربة كنص مرمز
                try {
                    bufferedStream.reset()
                } catch (_: Exception) {}
            }
        }

        // قراءة كنص مرمز (CSV / TSV / UTF-8 / Windows-1256) مع كشف الترميز الصارم
        return parseTextBasedTable(bufferedStream, fileName)
    }

    /**
     * التحقق من بصمة الملف الثنائية (Magic Bytes) أو امتداده لتحديد ملفات الإكسل (.xlsx / .xls)
     */
    private fun isExcelBinaryFormat(stream: BufferedInputStream, fileName: String): Boolean {
        val lower = fileName.lowercase(Locale.US)
        if (lower.endsWith(".xlsx") || lower.endsWith(".xls") || lower.endsWith(".xlsm") || lower.endsWith(".xltx")) {
            return true
        }

        return try {
            stream.mark(16)
            val header = ByteArray(8)
            val bytesRead = stream.read(header, 0, 8)
            stream.reset()

            if (bytesRead >= 4) {
                // بصمة ZIP (PK\u0003\u0004) لملفات .xlsx الحديثة
                val isZip = header[0] == 0x50.toByte() && header[1] == 0x4B.toByte() && header[2] == 0x03.toByte() && header[3] == 0x04.toByte()
                // بصمة OLE2 (D0 CF 11 E0) لملفات .xls الكلاسيكية
                val isOle2 = header[0] == 0xD0.toByte() && header[1] == 0xCF.toByte() && header[2] == 0x11.toByte() && header[3] == 0xE0.toByte()
                isZip || isOle2
            } else false
        } catch (_: Exception) {
            false
        }
    }

    /**
     * القراءة عبر Apache POI لملفات .xlsx و .xls
     * تضمن استخراج النصوص العربية كـ StringCellValue بدون تشويه وبأعلى درجات الدقة
     */
    private fun parseWithApachePoi(
        inputStream: InputStream,
        fileName: String
    ): ExcelParseResult {
        val workbook: Workbook = WorkbookFactory.create(inputStream)
        val sheet: Sheet = if (workbook.numberOfSheets > 0) {
            workbook.getSheetAt(0)
        } else {
            workbook.close()
            throw IllegalStateException("ملف الإكسل فارغ ولا يحتوي على أي صفحات")
        }

        val headers = mutableListOf<String>()
        val rows = mutableListOf<Map<String, String>>()
        val headerColIndices = mutableListOf<Int>()

        // 1. تحديد سطر العناوين (Headers) بالبحث في أول 25 سطراً
        var headerRowIndex = -1
        val maxHeaderScan = sheet.lastRowNum.coerceAtMost(25)
        for (r in 0..maxHeaderScan) {
            val row = sheet.getRow(r) ?: continue
            val potentialHeaders = mutableListOf<String>()
            val potentialIndices = mutableListOf<Int>()

            val lastCol = row.lastCellNum.coerceAtLeast(1)
            for (c in 0 until lastCol) {
                val cell = row.getCell(c)
                val str = extractCellValue(cell).trim()
                if (str.isNotBlank()) {
                    potentialHeaders.add(sanitizeHeader(str))
                    potentialIndices.add(c)
                }
            }

            // إذا عثرنا على سطر به عمودين أو أكثر من النصوص غير الرقمية، يُعتبر رأس الجدول
            if (potentialHeaders.size >= 2) {
                headers.addAll(potentialHeaders)
                headerColIndices.addAll(potentialIndices)
                headerRowIndex = r
                break
            }
        }

        if (headerRowIndex == -1 || headers.isEmpty()) {
            workbook.close()
            return ExcelParseResult(emptyList(), emptyList(), 0, "POI_EMPTY")
        }

        // 2. قراءة صفوف البيانات واستخراج نصوص الخلايا مع الـ trim
        val lastRow = sheet.lastRowNum
        for (r in (headerRowIndex + 1)..lastRow) {
            val row = sheet.getRow(r) ?: continue
            val rowMap = mutableMapOf<String, String>()
            var hasAnyValue = false

            for (i in headers.indices) {
                val colIdx = headerColIndices[i]
                val headerName = headers[i]
                val cell = row.getCell(colIdx)
                val value = extractCellValue(cell).trim()

                if (value.isNotBlank()) {
                    hasAnyValue = true
                }
                rowMap[headerName] = value
            }

            if (hasAnyValue) {
                rows.add(rowMap)
            }
        }

        workbook.close()
        val format = if (fileName.lowercase(Locale.US).endsWith(".xlsx")) "APACHE_POI_XLSX" else "APACHE_POI_XLS"
        return ExcelParseResult(headers, rows, rows.size, format)
    }

    /**
     * استخراج قيمة الخلية بشكل نظيف مع الحفاظ على ترميز UTF-8 وتنسيق الأرقام والهويات
     */
    fun extractCellValue(cell: Cell?): String {
        if (cell == null) return ""
        return try {
            when (cell.cellType) {
                CellType.STRING -> {
                    val str = cell.richStringCellValue?.string ?: cell.stringCellValue ?: ""
                    sanitizeCellString(str)
                }
                CellType.NUMERIC -> {
                    if (DateUtil.isCellDateFormatted(cell)) {
                        try {
                            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                            cell.dateCellValue?.let { sdf.format(it) } ?: ""
                        } catch (_: Exception) {
                            cell.numericCellValue.toLong().toString()
                        }
                    } else {
                        val num = cell.numericCellValue
                        // التحقق إذا كان الرقم هوية وطنية أو جوال أو عدد صحيح لمنع ظهور .0 أو الصيغة العلمية
                        if (num == Math.floor(num) && !num.isInfinite() && !num.isNaN()) {
                            num.toLong().toString()
                        } else {
                            val df = java.text.DecimalFormat("0.##", java.text.DecimalFormatSymbols(Locale.US))
                            df.format(num).trim()
                        }
                    }
                }
                CellType.BOOLEAN -> cell.booleanCellValue.toString()
                CellType.FORMULA -> {
                    try {
                        when (cell.cachedFormulaResultType) {
                            CellType.STRING -> {
                                val str = cell.richStringCellValue?.string ?: cell.stringCellValue ?: ""
                                sanitizeCellString(str)
                            }
                            CellType.NUMERIC -> {
                                if (DateUtil.isCellDateFormatted(cell)) {
                                    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                                    cell.dateCellValue?.let { sdf.format(it) } ?: ""
                                } else {
                                    val num = cell.numericCellValue
                                    if (num == Math.floor(num) && !num.isInfinite() && !num.isNaN()) {
                                        num.toLong().toString()
                                    } else {
                                        val df = java.text.DecimalFormat("0.##", java.text.DecimalFormatSymbols(Locale.US))
                                        df.format(num).trim()
                                    }
                                }
                            }
                            CellType.BOOLEAN -> cell.booleanCellValue.toString()
                            else -> sanitizeCellString(cell.stringCellValue ?: "")
                        }
                    } catch (_: Exception) {
                        ""
                    }
                }
                CellType.BLANK -> ""
                else -> sanitizeCellString(cell.toString())
            }.trim()
        } catch (_: Exception) {
            ""
        }
    }

    /**
     * تنظيف نصوص الخلايا من المحارف المخفية وفراغات الـ Zero-width والـ BOM
     */
    fun sanitizeCellString(input: String): String {
        return input
            .replace("\uFEFF", "") // Byte Order Mark
            .replace("\u200B", "") // Zero-Width Space
            .replace("\u200C", "") // Zero-Width Non-Joiner
            .replace("\u200D", "") // Zero-Width Joiner
            .replace("\u00A0", " ") // Non-breaking space
            .trim()
    }

    /**
     * قراءة الجداول النصية (CSV / TSV) مع الكشف الذكي لترميز اللغة العربية (UTF-8 / Windows-1256)
     */
    private fun parseTextBasedTable(
        inputStream: InputStream,
        fileName: String
    ): ExcelParseResult {
        val bytes = inputStream.readBytes()
        if (bytes.isEmpty()) return ExcelParseResult(emptyList(), emptyList(), 0, "EMPTY_TEXT")

        // كشف الترميز المناسب (UTF-8, UTF-8 BOM, Windows-1256)
        val charset = detectArabicCharset(bytes)
        val text = String(bytes, charset)
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }

        if (lines.size < 2) {
            return ExcelParseResult(emptyList(), emptyList(), 0, "INSUFFICIENT_LINES")
        }

        // تحديد الفاصل (Delimiter): الفاصلة، الفاصلة المنقوطة، أو Tab
        val headerLine = lines[0].removePrefix("\uFEFF") // إزالة UTF-8 BOM إن وجد
        val delimiter = when {
            headerLine.contains("\t") -> "\t"
            headerLine.contains(";") -> ";"
            headerLine.contains(",") -> ","
            headerLine.contains("|") -> "|"
            else -> ","
        }

        val rawHeaders = splitDelimited(headerLine, delimiter).map { sanitizeHeader(it) }
        val rows = mutableListOf<Map<String, String>>()

        for (i in 1 until lines.size) {
            val cols = splitDelimited(lines[i], delimiter)
            val rowMap = mutableMapOf<String, String>()
            var hasAnyVal = false

            rawHeaders.forEachIndexed { idx, h ->
                val v = if (idx < cols.size) sanitizeCellString(cols[idx]) else ""
                if (v.isNotBlank()) hasAnyVal = true
                rowMap[h] = v
            }

            if (hasAnyVal) {
                rows.add(rowMap)
            }
        }

        return ExcelParseResult(rawHeaders, rows, rows.size, "CSV_${charset.name()}")
    }

    /**
     * تقسيم السطر مع احترام علامات التنصيص
     */
    private fun splitDelimited(line: String, delimiter: String): List<String> {
        val result = mutableListOf<String>()
        val sb = java.lang.StringBuilder()
        var inQuotes = false

        var i = 0
        while (i < line.length) {
            val c = line[i]
            if (c == '"') {
                inQuotes = !inQuotes
            } else if (!inQuotes && line.startsWith(delimiter, i)) {
                result.add(sb.toString().trim().trim('"', '\''))
                sb.setLength(0)
                i += delimiter.length - 1
            } else {
                sb.append(c)
            }
            i++
        }
        result.add(sb.toString().trim().trim('"', '\''))
        return result
    }

    /**
     * تنظيف اسم العمود من الأحرف المخفية والـ BOM
     */
    fun sanitizeHeader(header: String): String {
        return header
            .removePrefix("\uFEFF")
            .replace("\u200B", "") // Zero-width space
            .replace("\u200C", "")
            .replace("\u200D", "")
            .replace("\u00A0", " ")
            .trim()
    }

    /**
     * كشف الترميز الأنسب للنصوص العربية
     * يمنع تشوه النصوص (Mojibake) عند قراءة ملفات الإكسل المصدرة بترميز Windows-1256 أو UTF-8
     */
    private fun detectArabicCharset(bytes: ByteArray): Charset {
        // 1. فحص BOM UTF-8 (EF BB BF)
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) {
            return StandardCharsets.UTF_8
        }

        // 2. محاولة صارمة لفك ترميز UTF-8 مع إطلاق استثناء عند وجود بايت غير متوافق
        try {
            val utf8Decoder = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
            utf8Decoder.decode(java.nio.ByteBuffer.wrap(bytes))
            return StandardCharsets.UTF_8
        } catch (_: Exception) {}

        // 3. التحقق من وجود بايتات عربية بترميز Windows-1256 (0xC0 .. 0xFE)
        val hasWindows1256ArabicBytes = bytes.any { b ->
            val unsigned = b.toInt() and 0xFF
            unsigned in 0xC0..0xFE
        }

        if (hasWindows1256ArabicBytes) {
            try {
                return Charset.forName("windows-1256")
            } catch (_: Exception) {}
        }

        // 4. المحاولة مع windows-1256 كافتراضي لملفات الإكسل العربية
        return try {
            Charset.forName("windows-1256")
        } catch (_: Exception) {
            StandardCharsets.UTF_8
        }
    }
}
