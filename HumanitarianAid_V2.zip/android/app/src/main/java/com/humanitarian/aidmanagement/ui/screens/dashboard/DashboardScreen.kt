package com.humanitarian.aidmanagement.ui.screens.dashboard

import android.app.DatePickerDialog
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.dao.KeyCountRecord
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.DashboardStats
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.ui.components.charts.InteractiveAnalyticsChartsCard
import com.humanitarian.aidmanagement.ui.components.SyncDetailsDialog
import com.humanitarian.aidmanagement.ui.components.SyncStatusBanner
import java.util.Calendar
import java.util.Locale

data class AidCategoryUi(
    val id: Int,
    val name: String,
    val count: Int,
    val icon: ImageVector,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigateToFamilies: () -> Unit = {},
    onNavigateToNomination: () -> Unit = {},
    onNavigateToReports: () -> Unit = {},
    onNavigateToDelivery: () -> Unit = {},
    onNavigateToAccounts: () -> Unit = {},
    onNavigateToBackup: () -> Unit = {},
    onNavigateToGeographic: () -> Unit = {},
    onNavigateToProjects: () -> Unit = {},
    onLogout: () -> Unit = {}
) {
    val repository = viewModel.repository
    val uiState by viewModel.uiState.collectAsState()
    val fromDateState by viewModel.fromDate.collectAsState()
    val toDateState by viewModel.toDate.collectAsState()

    var showSyncDialog by remember { mutableStateOf(false) }
    val syncState by viewModel.syncState.collectAsState()

    // التحكم في طي / توسيع ترويسة إدارة المساعدات لتوفير مساحة الشاشة (Compact / Collapsible Header)
    var isHeaderExpanded by remember { mutableStateOf(false) }

    val context = LocalContext.current

    // دوال فتح منتقي التاريخ التفاعلي (DatePickerDialog)
    fun openDatePicker(isFrom: Boolean) {
        val calendar = Calendar.getInstance()
        val currentStr = if (isFrom) fromDateState else toDateState
        val parts = currentStr.split("-")
        val y = parts.getOrNull(0)?.toIntOrNull() ?: calendar.get(Calendar.YEAR)
        val m = ((parts.getOrNull(1)?.toIntOrNull() ?: 1) - 1).coerceIn(0, 11)
        val d = (parts.getOrNull(2)?.toIntOrNull() ?: 1).coerceIn(1, 31)

        DatePickerDialog(context, { _, year, month, dayOfMonth ->
            val formatted = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, dayOfMonth)
            if (isFrom) {
                viewModel.onDateRangeChanged(formatted, toDateState)
            } else {
                viewModel.onDateRangeChanged(fromDateState, formatted)
            }
        }, y, m, d).show()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. شريط حالة المزامنة والاتصال الحي
            item {
                SyncStatusBanner(
                    repository = repository,
                    onOpenSyncDetails = { showSyncDialog = true }
                )
            }

            // 2. ترويسة مدمجة قابلة للطي (Compact Collapsible TopAppBar / Header) لتوفير مساحة الشاشة
            item {
                CompactDashboardHeader(
                    fromDate = fromDateState,
                    toDate = toDateState,
                    isExpanded = isHeaderExpanded,
                    onToggleExpand = { isHeaderExpanded = !isHeaderExpanded },
                    onPickFromDate = { openDatePicker(true) },
                    onPickToDate = { openDatePicker(false) },
                    onSelectPreset = { from, to -> viewModel.onDateRangeChanged(from, to) },
                    onOpenSync = { showSyncDialog = true },
                    onNavigateToAccounts = onNavigateToAccounts,
                    isOnline = syncState.isOnline,
                    isManager = repository.getCurrentUser()?.RoleID == 1 || repository.isSuperAdmin(),
                    userName = repository.getCurrentUser()?.fullName ?: "مهندس النظام (admin)"
                )
            }

            // 3. محتوى لوحة القيادة بناءً على Sealed Interface UiState
            when (val state = uiState) {
                is DashboardUiState.Loading -> {
                    item {
                        DashboardLoadingState()
                    }
                }
                is DashboardUiState.Error -> {
                    item {
                        DashboardErrorState(
                            message = state.message,
                            onRetry = { viewModel.refresh() }
                        )
                    }
                }
                is DashboardUiState.Success -> {
                    // ظهور متحرك وسلس للمحتوى بنعومة عالية (Smooth AnimatedVisibility)
                    item {
                        AnimatedVisibility(
                            visible = true,
                            enter = fadeIn(tween(400)) + expandVertically(tween(400))
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                // أ) شريط ملخص الفترة الزمنية المحددة والعمليات
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 14.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Icon(Icons.Default.DateRange, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                            Text(
                                                text = "الفترة: ${state.fromDate} إلى ${state.toDate}",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                        }

                                        Text(
                                            text = "مساعدات الفترة: ${state.totalDeliveriesInPeriod}",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                // ب) شبكة بطاقات العمليات الميدانية السريعة
                                QuickActionsGrid(
                                    onNavigateToDelivery = onNavigateToDelivery,
                                    onNavigateToGeographic = onNavigateToGeographic,
                                    onNavigateToFamilies = onNavigateToFamilies,
                                    onNavigateToNomination = onNavigateToNomination
                                )

                                // ج) شبكة البطاقات الإحصائية الست الرئيسية
                                PrimaryStatsGrid(
                                    stats = state.stats,
                                    onNavigateToFamilies = onNavigateToFamilies,
                                    onNavigateToReports = onNavigateToReports,
                                    onNavigateToProjects = onNavigateToProjects,
                                    onNavigateToNomination = onNavigateToNomination,
                                    onNavigateToDelivery = onNavigateToDelivery
                                )

                                // د) بطاقة التوزيعات الديناميكية المعقدة (Dynamic Room Aggregation Card)
                                DynamicBreakdownsCard(
                                    injuryStats = state.injuryStats,
                                    damageStats = state.damageStats,
                                    approvalStats = state.approvalStats,
                                    residentStats = state.residentStats,
                                    localityStats = state.localityStats
                                )

                                // هـ) بطاقة الرسوم البيانية التفاعلية
                                InteractiveAnalyticsChartsCard(
                                    localityStats = state.localityStats,
                                    aidTypeStats = state.aidTypeStats,
                                    onNavigateToReports = onNavigateToReports
                                )

                                // و) قائمة تصنيفات المساعدات الفعلية
                                AidCategoriesSection(categories = state.categories)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSyncDialog) {
        SyncDetailsDialog(
            repository = repository,
            onDismiss = { showSyncDialog = false }
        )
    }
}

/**
 * ترويسة مدمجة ذكية (Compact Collapsible Header)
 */
@Composable
private fun CompactDashboardHeader(
    fromDate: String,
    toDate: String,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onPickFromDate: () -> Unit,
    onPickToDate: () -> Unit,
    onSelectPreset: (String, String) -> Unit,
    onOpenSync: () -> Unit,
    onNavigateToAccounts: () -> Unit,
    isOnline: Boolean,
    isManager: Boolean,
    userName: String
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // الشريط المدمج السطحي الدائم
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                if (isManager) Color(0xFFE11D48).copy(alpha = 0.12f)
                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isManager) Icons.Default.Security else Icons.Default.Person,
                            contentDescription = null,
                            tint = if (isManager) Color(0xFFE11D48) else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = userName,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isManager) Color(0xFFE11D48).copy(alpha = 0.15f) else Color(0xFF10B981).copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = if (isManager) "مهندس النظام" else "مشرف",
                                    color = if (isManager) Color(0xFFE11D48) else Color(0xFF10B981),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                        Text(
                            text = "نطاق الفلترة: $fromDate إلى $toDate",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // أزرار سريعة ومفتاح طي/توسيع النطاق الزمني
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(onClick = onOpenSync, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (isOnline) Icons.Default.CloudSync else Icons.Default.CloudOff,
                            contentDescription = "التزامن",
                            tint = if (isOnline) MaterialTheme.colorScheme.primary else Color(0xFFF59E0B),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    if (isManager) {
                        IconButton(onClick = onNavigateToAccounts, modifier = Modifier.size(32.dp)) {
                            Icon(
                                Icons.Default.AdminPanelSettings,
                                contentDescription = "الصلاحيات",
                                tint = Color(0xFFE11D48),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // زر التوسيع / الطي
                    IconButton(onClick = onToggleExpand, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "توسيع النطاق الزمني",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // محتوى النطاق الزمني القابل للطي (Collapsible Date Filter)
            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                    Text(
                        text = "منتقي النطاق الزمني الذكي (تحديث فوري للإحصائيات):",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // زر من تاريخ
                        Surface(
                            onClick = onPickFromDate,
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("من تاريخ", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(fromDate, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Icon(Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }

                        // زر إلى تاريخ
                        Surface(
                            onClick = onPickToDate,
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("إلى تاريخ", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(toDate, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }

                    // خيارات سريعة للنطاق الزمني
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        QuickDateChip(label = "الشهر الحالي") {
                            onSelectPreset("2026-10-01", "2026-10-31")
                        }
                        QuickDateChip(label = "آخر 3 شهور") {
                            onSelectPreset("2026-08-01", "2026-10-31")
                        }
                        QuickDateChip(label = "العام 2026") {
                            onSelectPreset("2026-01-01", "2026-12-31")
                        }
                        QuickDateChip(label = "كافة الفترات") {
                            onSelectPreset("2020-01-01", "2030-12-31")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickDateChip(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

/**
 * حالة التحميل مع تأثير CircularProgressIndicator والتنسيق الحديث
 */
@Composable
private fun DashboardLoadingState() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(40.dp),
                color = MaterialTheme.colorScheme.primary,
                strokeWidth = 3.dp
            )
            Text(
                text = "جاري تجميع الإحصائيات الحية واستعلامات Room التجميعية...",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * حالة الخطأ مع زر إعادة المحاولة
 */
@Composable
private fun DashboardErrorState(message: String, onRetry: () -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEE2E2)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(36.dp))
            Text(text = message, color = Color(0xFFDC2626), fontSize = 12.sp, textAlign = TextAlign.Center)
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("إعادة المحاولة")
            }
        }
    }
}

/**
 * شبكة العمليات السريعة الميدانية
 */
@Composable
private fun QuickActionsGrid(
    onNavigateToDelivery: () -> Unit,
    onNavigateToGeographic: () -> Unit,
    onNavigateToFamilies: () -> Unit,
    onNavigateToNomination: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "العمليات الميدانية السريعة",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DashboardActionCard(
                title = "تسليم المساعدات",
                subtitle = "صرف وتسجيل مباشر",
                icon = Icons.Default.QrCodeScanner,
                color = Color(0xFF0284C7),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToDelivery
            )
            DashboardActionCard(
                title = "التوزيع الجغرافي",
                subtitle = "المحليات والمناطق",
                icon = Icons.Default.Map,
                color = Color(0xFF0D9488),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToGeographic
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DashboardActionCard(
                title = "سجل الأسر",
                subtitle = "إدارة وبيانات المستفيدين",
                icon = Icons.Default.People,
                color = Color(0xFF10B981),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToFamilies
            )
            DashboardActionCard(
                title = "محرك الترشيح",
                subtitle = "الترشيح الذكي والقواعد",
                icon = Icons.Default.FilterList,
                color = Color(0xFF8B5CF6),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToNomination
            )
        }
    }
}

@Composable
private fun DashboardActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = subtitle, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/**
 * شبكة البطاقات الإحصائية الست
 */
@Composable
private fun PrimaryStatsGrid(
    stats: DashboardStats,
    onNavigateToFamilies: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToProjects: () -> Unit,
    onNavigateToNomination: () -> Unit,
    onNavigateToDelivery: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "المؤشرات الإحصائية الميدانية",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(
                title = "إجمالي الأسر",
                value = "${stats.totalFamilies}",
                unit = "أسرة",
                icon = Icons.Default.FamilyRestroom,
                color = Color(0xFF0D9488),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToFamilies
            )
            StatCard(
                title = "إجمالي الأفراد",
                value = "${stats.totalBeneficiaries}",
                unit = "فرد",
                icon = Icons.Default.Group,
                color = Color(0xFF0284C7),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToFamilies
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(
                title = "إجمالي المساعدات",
                value = "${stats.totalAidRecords}",
                unit = "طرد/سجل",
                icon = Icons.Default.Inventory2,
                color = Color(0xFF8B5CF6),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToReports
            )
            StatCard(
                title = "المشاريع المنفذة",
                value = "${stats.totalProjects}",
                unit = "مشروع",
                icon = Icons.Default.AssignmentTurnedIn,
                color = Color(0xFFF59E0B),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToProjects
            )
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(
                title = "عدد المرشحين",
                value = "${stats.totalSelectedCandidates}",
                unit = "مرشح",
                icon = Icons.Default.HowToReg,
                color = Color(0xFF10B981),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToNomination
            )
            StatCard(
                title = "المستلمون الفعليون",
                value = "${stats.distinctBeneficiaries}",
                unit = "مستفيد",
                icon = Icons.Default.CheckCircle,
                color = Color(0xFFEC4899),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToDelivery
            )
        }
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    unit: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = unit, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/**
 * بطاقة التوزيعات الديناميكية المعقدة (Dynamic Room Aggregation Card)
 * تستخرج البيانات حصراً عبر استعلامات GROUP BY و COUNT
 */
@Composable
private fun DynamicBreakdownsCard(
    injuryStats: List<KeyCountRecord>,
    damageStats: List<KeyCountRecord>,
    approvalStats: List<KeyCountRecord>,
    residentStats: List<KeyCountRecord>,
    localityStats: List<LocalityDistributionStat>
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabTitles = listOf("المحليات والنسب", "أضرار الحرب", "حالة الإصابة", "الاعتماد والإقامة")

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Default.PieChart, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Text("الإحصائيات التجميعية الحية (Room Dynamic Aggregation)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Surface(shape = RoundedCornerShape(4.dp), color = Color(0xFF10B981).copy(alpha = 0.15f)) {
                    Text("SQL حقيقي 100%", color = Color(0xFF10B981), fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
            }

            // تبويبات التبديل بين التوزيعات
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                tabTitles.forEachIndexed { index, title ->
                    val isSelected = selectedTab == index
                    Surface(
                        onClick = { selectedTab = index },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                    ) {
                        Text(
                            text = title,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

            when (selectedTab) {
                0 -> {
                    // توزيع المحليات مع حساب النسبة المئوية الدقيقة: (عدد المسجلين في المحلية / الإجمالي) * 100
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "معادلة النسبة: (عدد المسجلين في المحلية ÷ إجمالي الأسر) × 100",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        localityStats.forEach { loc ->
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(loc.localityName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${loc.familiesCount} أسرة (${String.format(Locale.US, "%.1f%%", loc.quotaPercent)})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                LinearProgressIndicator(
                                    progress = { (loc.quotaPercent / 100.0).toFloat().coerceIn(0f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp)),
                                    color = MaterialTheme.colorScheme.primary,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }
                        }
                    }
                }
                1 -> {
                    // توزيع أضرار الحرب
                    RenderKeyValueDistribution(
                        items = damageStats,
                        emptyText = "لا توجد بيانات أضرار مسجلة بعد"
                    )
                }
                2 -> {
                    // توزيع حالات الإصابة
                    RenderKeyValueDistribution(
                        items = injuryStats,
                        emptyText = "لا توجد بيانات إصابات مسجلة بعد"
                    )
                }
                3 -> {
                    // توزيع الاعتماد والإقامة
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("حالة الاعتماد في التنمية الاجتماعية:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        RenderKeyValueDistribution(items = approvalStats, emptyText = "لا توجد بيانات اعتماد")

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("حالة الإقامة (مقيم / نازح):", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        RenderKeyValueDistribution(items = residentStats, emptyText = "لا توجد بيانات إقامة")
                    }
                }
            }
        }
    }
}

@Composable
private fun RenderKeyValueDistribution(items: List<KeyCountRecord>, emptyText: String) {
    if (items.isEmpty()) {
        Text(emptyText, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        return
    }
    val total = items.sumOf { it.count }.coerceAtLeast(1)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach { record ->
            val percent = (record.count.toDouble() / total.toDouble()) * 100.0
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(record.keyName, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "${record.count} (${String.format(Locale.US, "%.1f%%", percent)})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                LinearProgressIndicator(
                    progress = { (percent / 100.0).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
    }
}

/**
 * قسم تصنيفات المساعدات
 */
@Composable
private fun AidCategoriesSection(categories: List<AidCategoryUi>) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Default.Category, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Text("المساعدات المسلمة حسب النوع في الفترة المحددة", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))

            if (categories.isEmpty()) {
                Text("لا توجد مساعدات مسلمة في هذه الفترة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                categories.forEach { category ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(category.color.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(category.icon, contentDescription = null, tint = category.color, modifier = Modifier.size(16.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = category.name,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f)
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = category.color.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "${category.count} مساعدة",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = category.color,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * دالة توافقية تقبل AidRepository وتنشئ DashboardViewModel تلقائياً
 */
@Composable
fun DashboardScreen(
    repository: AidRepository,
    viewModel: DashboardViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = DashboardViewModel.Factory(repository)
    ),
    onNavigateToFamilies: () -> Unit,
    onNavigateToNomination: () -> Unit,
    onNavigateToReports: () -> Unit,
    onNavigateToDelivery: () -> Unit = {},
    onNavigateToAccounts: () -> Unit = {},
    onNavigateToBackup: () -> Unit = {},
    onNavigateToGeographic: () -> Unit = {},
    onNavigateToProjects: () -> Unit = {},
    onLogout: () -> Unit = {}
) {
    DashboardScreen(
        viewModel = viewModel,
        onNavigateToFamilies = onNavigateToFamilies,
        onNavigateToNomination = onNavigateToNomination,
        onNavigateToReports = onNavigateToReports,
        onNavigateToDelivery = onNavigateToDelivery,
        onNavigateToAccounts = onNavigateToAccounts,
        onNavigateToBackup = onNavigateToBackup,
        onNavigateToGeographic = onNavigateToGeographic,
        onNavigateToProjects = onNavigateToProjects,
        onLogout = onLogout
    )
}
