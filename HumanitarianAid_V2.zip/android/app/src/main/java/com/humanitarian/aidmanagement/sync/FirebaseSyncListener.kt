package com.humanitarian.aidmanagement.sync

import android.util.Log
import com.google.firebase.database.*
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.AuditLogEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * FirebaseSyncListener - محرك الدمج التلقائي المركزي في جهاز المدير (Master Auto-Merge)
 * يراقب عقد Firebase Realtime Database الخاصة بالمحليات في الوقت الحقيقي
 * ويقوم بدمج الحركات الميدانية الواصلة مباشرة (Event Sourcing) داخل قاعدة Room
 * دون مسح أو استبدال أي بيانات سابقة، مع منع التعارض والتكرار (Idempotent Merge).
 */
class FirebaseSyncListener(
    private val database: AidDatabase,
    private val firebaseSyncManager: FirebaseSyncManager
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeListeners = ConcurrentHashMap<String, Pair<DatabaseReference, ChildEventListener>>()

    // سجل المعرفات المدمجة لمنع التكرار (Deduplication Cache)
    private val mergedDeltaIds = Collections.synchronizedSet(HashSet<String>())

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _lastMergedDelta = MutableStateFlow<SyncDelta?>(null)
    val lastMergedDelta: StateFlow<SyncDelta?> = _lastMergedDelta.asStateFlow()

    private val _recentMergedDeltas = MutableStateFlow<List<SyncDelta>>(emptyList())
    val recentMergedDeltas: StateFlow<List<SyncDelta>> = _recentMergedDeltas.asStateFlow()

    private val _totalMergedCount = MutableStateFlow(0)
    val totalMergedCount: StateFlow<Int> = _totalMergedCount.asStateFlow()

    companion object {
        private const val TAG = "FirebaseSyncListener"
    }

    /**
     * بدء الاستماع لمسار المحليات المطلوب مراقبتها
     * @param targetLocalityId إذا كانت 0 يستمع لجميع المحليات (صلاحية مدير النظام)، أو محلية محددة
     */
    fun startListening(targetLocalityId: Int = 0) {
        val fbDb = firebaseSyncManager.getDatabaseInstance()
        if (fbDb == null) {
            Log.w(TAG, "Cannot start listener: FirebaseDatabase is not ready.")
            return
        }

        stopListening()

        val rootRef = fbDb.getReference(FirebaseSyncManager.ROOT_NODE)
            .child(FirebaseSyncManager.DELTAS_NODE)

        if (targetLocalityId == 0) {
            // مدير النظام: يستمع لكافة عقد المحليات
            attachGlobalListener(rootRef)
        } else {
            // مستمع لمحلية محددة
            val localityRef = rootRef.child("locality_$targetLocalityId")
            attachLocalityListener("locality_$targetLocalityId", localityRef)
        }

        _isListening.value = true
        Log.i(TAG, "Firebase Master Auto-Merge listener started for locality: $targetLocalityId")
    }

    private fun attachGlobalListener(rootRef: DatabaseReference) {
        val childListener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                // snapshot هو عقدة محلية (locality_X)، نقوم بالاستماع لأحداث الأطفال داخلها
                val localityKey = snapshot.key ?: return
                if (!activeListeners.containsKey(localityKey)) {
                    attachLocalityListener(localityKey, snapshot.ref)
                }
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Global listener error: ${error.message}")
            }
        }

        rootRef.addChildEventListener(childListener)
        activeListeners["__ROOT__"] = Pair(rootRef, childListener)
    }

    private fun attachLocalityListener(key: String, localityRef: DatabaseReference) {
        val listener = object : ChildEventListener {
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                handleIncomingDeltaSnapshot(snapshot)
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                handleIncomingDeltaSnapshot(snapshot)
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {}
            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Locality listener for $key cancelled: ${error.message}")
            }
        }

        localityRef.addChildEventListener(listener)
        activeListeners[key] = Pair(localityRef, listener)
        Log.d(TAG, "Attached ChildEventListener to node: $key")
    }

    /**
     * معالجة حركة قادمة من Firebase في مسار الخلفية (Dispatchers.IO)
     */
    private fun handleIncomingDeltaSnapshot(snapshot: DataSnapshot) {
        scope.launch {
            try {
                @Suppress("UNCHECKED_CAST")
                val map = snapshot.value as? Map<String, Any?> ?: return@launch
                val delta = SyncDelta.fromMap(map)

                // 1. استبعاد الحركات المنبثقة من نفس هذا الجهاز منعاً للحلقات المرتدة (Self Echo Prevention)
                if (delta.deviceId == firebaseSyncManager.deviceId && delta.deviceId.isNotBlank()) {
                    return@launch
                }

                // 2. فحص التكرار: إذا كانت الحركة قد دُمجت بالفعل يتم تجاوزها
                if (mergedDeltaIds.contains(delta.deltaId)) {
                    return@launch
                }

                // 3. تنفيذ الدمج الفعلي في Room DB
                val success = mergeDeltaIntoRoom(delta)

                if (success) {
                    mergedDeltaIds.add(delta.deltaId)
                    _totalMergedCount.value += 1
                    _lastMergedDelta.value = delta

                    val list = _recentMergedDeltas.value.toMutableList()
                    list.add(0, delta)
                    if (list.size > 50) list.removeAt(list.lastIndex)
                    _recentMergedDeltas.value = list

                    Log.i(TAG, "Successfully auto-merged delta: ${delta.deltaId} [${delta.entityType}:${delta.operation}]")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error handling incoming delta snapshot: ${e.message}", e)
            }
        }
    }

    /**
     * تطبيق الدمج الحصري غير المتلف (Non-Destructive Delta Merge)
     */
    private suspend fun mergeDeltaIntoRoom(delta: SyncDelta): Boolean = withContext(Dispatchers.IO) {
        try {
            when (delta.entityType.uppercase()) {
                "AID_RECORD" -> mergeAidRecordDelta(delta)
                "FAMILY" -> mergeFamilyDelta(delta)
                "NOMINATION_SELECTION" -> mergeNominationDelta(delta)
                else -> {
                    Log.w(TAG, "Unknown entityType in delta: ${delta.entityType}")
                    false
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to merge delta into Room: ${e.message}", e)
            false
        }
    }

    /**
     * دمج حركات تسليم وتوثيق المساعدات (Aid Record Deliveries)
     */
    private suspend fun mergeAidRecordDelta(delta: SyncDelta): Boolean {
        val recordId = delta.recordId.toLongOrNull() ?: return false
        val aidRecordDao = database.aidRecordDao()
        val payload = SyncDelta.parsePayload(delta.payloadJson)

        val existingRecord = aidRecordDao.getAidRecordById(recordId)

        when (delta.operation.uppercase()) {
            "DELIVER" -> {
                val status = payload["status"] ?: "تم التسليم"
                val date = payload["date"] ?: java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
                val recipient = payload["recipient"] ?: ""
                val notes = payload["notes"] ?: ""
                val combinedNotes = if (recipient.isNotBlank()) "المستلم: $recipient | $notes" else notes

                if (existingRecord != null) {
                    aidRecordDao.updateDeliveryStatus(recordId, status, date, combinedNotes)
                } else {
                    // إذا لم يكن السجل موجوداً محلياً، يمكن إنشاؤه بناء على بيانات الـ Payload
                    Log.i(TAG, "Record $recordId not found locally, skipping direct update")
                }

                // تسجيل حركة التدقيق الأمني
                recordAuditLog(
                    userId = delta.userId,
                    userName = delta.userName,
                    operationType = "AUTO_MERGE_DELIVERY",
                    targetTable = "tbl_Aid_Records",
                    recordId = recordId.toString(),
                    description = "تم دمج حركة تسليم سحابية من المندوب ${delta.userName} (محلية ${delta.localityId}) للسجل $recordId للمستلم $recipient"
                )
                return true
            }

            "UNDO_DELIVERY" -> {
                val date = payload["date"] ?: java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
                if (existingRecord != null) {
                    aidRecordDao.updateDeliveryStatus(recordId, "مرشح", date, "تم التراجع عن التسليم سحابياً")
                }
                recordAuditLog(
                    userId = delta.userId,
                    userName = delta.userName,
                    operationType = "AUTO_MERGE_UNDO_DELIVERY",
                    targetTable = "tbl_Aid_Records",
                    recordId = recordId.toString(),
                    description = "تم التراجع عن تسليم المساعدة سحابياً للسجل $recordId بواسطة ${delta.userName}"
                )
                return true
            }

            "DELETE" -> {
                aidRecordDao.deleteAidRecord(recordId)
                recordAuditLog(
                    userId = delta.userId,
                    userName = delta.userName,
                    operationType = "AUTO_MERGE_DELETE",
                    targetTable = "tbl_Aid_Records",
                    recordId = recordId.toString(),
                    description = "حذف سجل المساعدة $recordId بناءً على حركة سحابية من ${delta.userName}"
                )
                return true
            }

            else -> {
                Log.w(TAG, "Unsupported AidRecord operation: ${delta.operation}")
                return false
            }
        }
    }

    /**
     * دمج حركات الأسر (إضافة أسرة جديدة أو تعديل بياناتها عبر Upsert)
     */
    private suspend fun mergeFamilyDelta(delta: SyncDelta): Boolean {
        val familyDao = database.familyDao()
        val payload = SyncDelta.parsePayload(delta.payloadJson)

        when (delta.operation.uppercase()) {
            "INSERT", "UPDATE" -> {
                val nationalId = payload["nationalID"] ?: ""
                val name = payload["name"] ?: ""
                if (nationalId.isBlank() && name.isBlank()) return false

                val existing = if (nationalId.isNotBlank()) familyDao.getFamilyByNationalId(nationalId) else null

                if (existing != null) {
                    // تحديث الأسرة القائمة مع الحفاظ على البيانات الأساسية
                    val updated = existing.copy(
                        name = if (name.isNotBlank()) name else existing.name,
                        familyMembersCount = payload["members"]?.toIntOrNull() ?: existing.familyMembersCount,
                        localityID = delta.localityId.takeIf { it > 0 } ?: existing.localityID,
                        primaryPhone = payload["primaryPhone"] ?: existing.primaryPhone,
                        currentSubArea = payload["currentSubArea"] ?: payload["addressDetails"] ?: existing.currentSubArea
                    )
                    familyDao.updateFamily(updated)
                } else {
                    // إدراج أسرة جديدة
                    val newFamily = FamilyEntity(
                        nationalID = nationalId,
                        name = name,
                        familyMembersCount = payload["members"]?.toIntOrNull() ?: 1,
                        localityID = delta.localityId.takeIf { it > 0 } ?: 1,
                        currentSubArea = delta.localityName.ifBlank { payload["currentSubArea"] ?: "المنطقة التابعة للمحلية" },
                        primaryPhone = payload["primaryPhone"] ?: "",
                        developmentApproval = "معتمد",
                        localityApproval = "معتمد",
                        residentStatus = "مقيم",
                        notes = "أضيفت سحابياً عبر المندوب ${delta.userName}"
                    )
                    familyDao.insertFamily(newFamily)
                }

                recordAuditLog(
                    userId = delta.userId,
                    userName = delta.userName,
                    operationType = "AUTO_MERGE_FAMILY_${delta.operation}",
                    targetTable = "tbl_Families",
                    recordId = nationalId.ifBlank { delta.recordId },
                    description = "تم دمج بيانات الأسرة ($name - هوية $nationalId) بنجاح من المندوب ${delta.userName}"
                )
                return true
            }

            "DELETE" -> {
                val famId = delta.recordId.toLongOrNull()
                if (famId != null) {
                    val fam = familyDao.getFamilyById(famId)
                    if (fam != null) familyDao.deleteFamily(fam)
                }
                return true
            }

            else -> return false
        }
    }

    /**
     * دمج ترشيحات يدوية
     */
    private suspend fun mergeNominationDelta(delta: SyncDelta): Boolean {
        // دعم مرن لترشيحات المناديب
        recordAuditLog(
            userId = delta.userId,
            userName = delta.userName,
            operationType = "AUTO_MERGE_NOMINATION",
            targetTable = "tbl_Nominations",
            recordId = delta.recordId,
            description = "حركة ترشيح سحابية من المندوب ${delta.userName} للسجل ${delta.recordId}"
        )
        return true
    }

    private suspend fun recordAuditLog(
        userId: Int,
        userName: String = "مندوب سحابي",
        operationType: String,
        targetTable: String,
        recordId: String = "",
        description: String
    ) {
        try {
            database.auditLogDao().insertLog(
                AuditLogEntity(
                    userId = userId,
                    userName = userName,
                    userFullName = userName,
                    operationType = operationType,
                    targetTable = targetTable,
                    recordId = recordId,
                    description = description,
                    timestamp = System.currentTimeMillis()
                )
            )
        } catch (e: Exception) {
            Log.w(TAG, "Could not write audit log for merged delta: ${e.message}")
        }
    }

    /**
     * إيقاف كافة المستمعين النشطين
     */
    fun stopListening() {
        for ((key, pair) in activeListeners) {
            val (ref, listener) = pair
            try {
                ref.removeEventListener(listener)
            } catch (e: Exception) {
                Log.w(TAG, "Error removing listener for $key: ${e.message}")
            }
        }
        activeListeners.clear()
        _isListening.value = false
        Log.i(TAG, "All Firebase Realtime listeners stopped.")
    }
}
