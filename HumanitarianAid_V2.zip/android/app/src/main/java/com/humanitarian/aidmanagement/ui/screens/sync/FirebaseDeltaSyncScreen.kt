package com.humanitarian.aidmanagement.ui.screens.sync

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.sync.FirestoreSyncDelta
import com.humanitarian.aidmanagement.sync.SyncConnectionStatus
import com.humanitarian.aidmanagement.ui.components.sync.DynamicSyncStatusIndicator
import java.text.SimpleDateFormat
import java.util.*

private val PalestineGreen = Color(0xFF007A3D)
private val PalestineRed = Color(0xFFE4312B)
private val FirestoreAmber = Color(0xFFF57C00)
private val SkyBlue = Color(0xFF0284C7)

/**
 * FirebaseDeltaSyncScreen - شاشة إدارة ومراقبة التزامن المركزي اللحظي (Google Firebase Firestore Master Node)
 *
 * تجسد الهيكلة المعمارية المتقدمة:
 * 1. Offline-First Single Source of Truth: قاعدة بيانات Room هي مصدر الحقيقة الوحيد.
 * 2. Bridge Engine & SnapshotListeners: الاستماع المباشر في أجزاء من الثانية وتحديث Room عبر StateFlow.
 * 3. Background Sync & WorkManager: رفع التعديلات التلقائي عند توفر الشبكة مع NetworkConstraints.
 * 4. Conflict Resolution & Override Priority: أولوية مطلقة لحساب المدير العام (SUPER_ADMIN) تلغي أي تعارض محلي.
 * 5. Cloud RBAC & Security Rules: قواعد أمان سيرفرات جوجل المطبقة بدقة.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirebaseDeltaSyncScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val syncState by repository.getSyncState().collectAsState()
    val pendingItems by repository.getPendingSyncItems().collectAsState(initial = emptyList())
    val recentMergedDeltas by repository.getRecentMergedDeltas().collectAsState()
    val currentUser by repository.currentUserFlow.collectAsState()

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: الحركات المدمجة في Room, 1: طابور Room المعلق, 2: الأمان وفض النزاعات

    val userLocalityId = currentUser?.AllowedLocalityID ?: 0
    val isSuperAdmin = userLocalityId == 0 || repository.isSuperAdmin()

    // تشغيل مستمع المزامنة الحية عند فتح الشاشة
    LaunchedEffect(userLocalityId) {
        repository.startMasterSyncListener(userLocalityId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "التزامن المركزي اللحظي",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = FirestoreAmber.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "Firestore Master",
                                    color = FirestoreAmber,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "قاعدة Room هي مصدر الحقيقة الوحيد (Single Source of Truth)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    // مؤشر الحالة الديناميكي بـ AnimatedContent
                    DynamicSyncStatusIndicator(
                        syncState = syncState,
                        onClick = { repository.triggerSyncNow() }
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(onClick = { repository.triggerSyncNow() }) {
                        Icon(Icons.Default.Sync, contentDescription = "تزامن فوري", tint = PalestineGreen)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. بطاقة الهيكلة المركزية وحالة الاتصال اللحظي
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when (syncState.connectionStatus) {
                            SyncConnectionStatus.ONLINE -> PalestineGreen.copy(alpha = 0.08f)
                            SyncConnectionStatus.SYNCING -> SkyBlue.copy(alpha = 0.08f)
                            SyncConnectionStatus.OFFLINE -> FirestoreAmber.copy(alpha = 0.08f)
                        }
                    ),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(
                            when (syncState.connectionStatus) {
                                SyncConnectionStatus.ONLINE -> PalestineGreen.copy(alpha = 0.35f)
                                SyncConnectionStatus.SYNCING -> SkyBlue.copy(alpha = 0.35f)
                                SyncConnectionStatus.OFFLINE -> FirestoreAmber.copy(alpha = 0.35f)
                            }
                        )
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when (syncState.connectionStatus) {
                                                SyncConnectionStatus.ONLINE -> PalestineGreen
                                                SyncConnectionStatus.SYNCING -> SkyBlue
                                                SyncConnectionStatus.OFFLINE -> FirestoreAmber
                                            }
                                        )
                                )
                                Column {
                                    AnimatedContent(
                                        targetState = syncState.connectionStatus,
                                        label = "status_text_anim"
                                    ) { status ->
                                        Text(
                                            text = when (status) {
                                                SyncConnectionStatus.ONLINE -> "متصل بخوادم Google Firestore (Master Node)"
                                                SyncConnectionStatus.SYNCING -> "جاري التزامن اللحظي مع السحابة..."
                                                SyncConnectionStatus.OFFLINE -> "العمل دون اتصال (Room Offline-First نشط)"
                                            },
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = when (status) {
                                                SyncConnectionStatus.ONLINE -> PalestineGreen
                                                SyncConnectionStatus.SYNCING -> SkyBlue
                                                SyncConnectionStatus.OFFLINE -> FirestoreAmber
                                            }
                                        )
                                    }
                                    Text(
                                        text = "المسار السحابي: humanitarian_master/deltas_hub • الصلاحية: ${if (isSuperAdmin) "مدير عام (أولوية مطلقة)" else "مشرف محلية $userLocalityId"}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Button(
                                onClick = { repository.triggerSyncNow() },
                                enabled = !syncState.isSyncing,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                            ) {
                                if (syncState.isSyncing) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(Icons.Default.CloudSync, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تزامن فوري", fontSize = 11.sp)
                                }
                            }
                        }

                        // عدادات الإحصائيات الذكية
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SyncStatBox(
                                title = "حركات معلقة بـ Room",
                                count = syncState.pendingCount.toString(),
                                icon = Icons.Default.Storage,
                                color = if (syncState.pendingCount > 0) FirestoreAmber else PalestineGreen,
                                modifier = Modifier.weight(1f)
                            )
                            SyncStatBox(
                                title = "رُفعت لسيرفر جوجل",
                                count = syncState.totalUploaded.toString(),
                                icon = Icons.Default.CloudUpload,
                                color = SkyBlue,
                                modifier = Modifier.weight(1f)
                            )
                            SyncStatBox(
                                title = "دُمجت في Room",
                                count = syncState.totalMerged.toString(),
                                icon = Icons.Default.DoneAll,
                                color = PalestineGreen,
                                modifier = Modifier.weight(1f)
                            )
                            SyncStatBox(
                                title = "أولوية المدير 👑",
                                count = syncState.adminOverridesCount.toString(),
                                icon = Icons.Default.Security,
                                color = PalestineRed,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // شريط تشغيل مستمع الدمج اللحظي (SnapshotListener)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = if (syncState.isListening) PalestineGreen else Color.Gray,
                                    modifier = Modifier.size(18.dp)
                                )
                                Column {
                                    Text(
                                        text = "مستمع SnapshotListener اللحظي:",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (syncState.isListening) "نشط ويحدث قاعدة Room في أجزاء من الثانية" else "متوقف مؤقتاً",
                                        fontSize = 10.sp,
                                        color = if (syncState.isListening) PalestineGreen else Color.Gray
                                    )
                                }
                            }

                            Switch(
                                checked = syncState.isListening,
                                onCheckedChange = { active ->
                                    if (active) repository.startMasterSyncListener(userLocalityId)
                                    else repository.stopMasterSyncListener()
                                }
                            )
                        }
                    }
                }
            }

            // 2. بطاقة اختبار العمل الميداني بدون إنترنت (Offline-First Simulation)
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "محاكاة انقطاع الإنترنت (Offline Field Test):",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "اختبر تسجيل المساعدات أو الترشيحات بدون إنترنت (تُحفظ في Room أولاً)، ثم أعد الاتصال ليرفعها WorkManager تلقائياً في الخلفية.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Switch(
                            checked = syncState.isSimulatedOffline,
                            onCheckedChange = { repository.toggleOfflineSimulation() }
                        )
                    }
                }
            }

            // 3. شريط التبويب الثلاثي
            item {
                PrimaryTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = PalestineGreen,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Text(
                                "المدمجة في Room (${recentMergedDeltas.size})",
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Text(
                                "طابور Room المعلق (${pendingItems.size})",
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        text = {
                            Text(
                                "قواعد الأمان وفض النزاعات",
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            // محتوى التبويب المختار
            when (selectedTab) {
                0 -> {
                    // تبويب الحركات المدمجة لحظياً في Room
                    if (recentMergedDeltas.isEmpty()) {
                        item {
                            EmptyStateCard(
                                title = "بانتظار وصول حركات سحابية جديدة من السيرفر",
                                description = "مستمعات SnapshotListeners تعمل في الخلفية وتراقب Google Cloud Firestore Master Node. فور قيام المدير باعتماد ترشيح أو قيام مندوب بتسليم مساعدة، ستظهر الحركة هنا وتُدمج فوراً في جداول Room دون استبدال أي ملفات."
                            )
                        }
                    } else {
                        items(recentMergedDeltas) { delta ->
                            FirestoreDeltaCard(delta = delta, dateFormat = dateFormat)
                        }
                    }
                }

                1 -> {
                    // تبويب الحركات المعلقة في Room وطابور الرفع الخلفي
                    if (pendingItems.isEmpty()) {
                        item {
                            EmptyStateCard(
                                title = "طابور التزامن في Room نظيف تماماً ✅",
                                description = "كافة العمليات المحلية تم رفعها وتأكيد وصولها إلى Google Firebase Firestore Master Node بنجاح."
                            )
                        }
                    } else {
                        item {
                            Text(
                                text = "حركات قيد الرفع الخلفي بواسطة WorkManager مع شرط توفر الإنترنت:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = FirestoreAmber
                            )
                        }
                        items(pendingItems) { item ->
                            PendingRoomQueueCard(item = item, dateFormat = dateFormat)
                        }
                    }
                }

                2 -> {
                    // تبويب الهيكلة المعمارية وقواعد الأمان السحابية
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = PalestineGreen)
                                    Text(
                                        text = "الهندسة المعمارية لمنظومة التزامن المركزي",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = PalestineGreen
                                    )
                                }

                                ArchitecturePillar(
                                    stepNumber = "1",
                                    title = "Room Database كـ Single Source of Truth",
                                    description = "الواجهة البرمجية (UI) لا تقرأ أبداً من خوادم السحابة مباشرة. قاعدة بيانات Room المحلية هي المصدر الوحيد، وتُحدث الواجهة تلقائياً عبر StateFlow عند دمج أي Delta."
                                )

                                ArchitecturePillar(
                                    stepNumber = "2",
                                    title = "خوارزمية فض النزاعات والأسبقية المطلقة للمدير (Override Priority)",
                                    description = "إذا تعارض تعديل من مشرف المحلية مع تعديل صادر من المدير العام (SUPER_ADMIN)، فإن تعديل المدير يُطبّق قسراً ويلغي تعديل المحلية فوراً. أما بين المحليات، فيفوز السجل الأحدث بناءً على ServerTimestamp المعتمد من خوادم جوجل."
                                )

                                ArchitecturePillar(
                                    stepNumber = "3",
                                    title = "التزامن الخلفي التلقائي (WorkManager & NetworkConstraints)",
                                    description = "يعمل FirestoreSyncWorker في الخلفية مع قيود NetworkType.CONNECTED لضمان مزامنة كافة العمليات بمجرد عودة الإنترنت حتى لو كان التطبيق مغلقاً تماماً."
                                )

                                ArchitecturePillar(
                                    stepNumber = "4",
                                    title = "قواعد الأمان السحابية والصلاحيات (Firebase Security Rules)",
                                    description = "تضمن قواعد الأمان المطبقة على Firestore أن للمدير صلاحية قراءة وكتابة واعتماد شاملة، بينما مشرف المحلية مقيد بقراءة المشاريع وتعديل ترشيحات منطقته الجغرافية فقط."
                                )

                                HorizontalDivider()

                                Text(
                                    text = "ملف قواعد الأمان المطبق في سيرفر جوجل (firestore.rules):",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFF1E293B),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = """rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function isSuperAdmin() {
      return request.auth != null && request.auth.token.role == 'SUPER_ADMIN';
    }
    function isLocalitySupervisor(locId) {
      return request.auth != null && 
        (isSuperAdmin() || request.auth.token.localityId == locId);
    }
    match /humanitarian_master/deltas_hub/sync_deltas/{deltaId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null && 
        (isSuperAdmin() || isLocalitySupervisor(request.resource.data.localityId));
      allow update, delete: if isSuperAdmin();
    }
  }
}""",
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp,
                                        color = Color(0xFF38BDF8),
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SyncStatBox(
    title: String,
    count: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = color.copy(alpha = 0.10f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.25f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = count, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = title, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
fun ArchitecturePillar(
    stepNumber: String,
    title: String,
    description: String
) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(
            modifier = Modifier
                .size(26.dp)
                .clip(CircleShape)
                .background(PalestineGreen),
            contentAlignment = Alignment.Center
        ) {
            Text(text = stepNumber, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
fun FirestoreDeltaCard(
    delta: FirestoreSyncDelta,
    dateFormat: SimpleDateFormat
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (delta.operation.uppercase()) {
                            "DELIVER" -> PalestineGreen.copy(alpha = 0.15f)
                            "UNDO_DELIVERY" -> FirestoreAmber.copy(alpha = 0.15f)
                            "APPROVE_NOMINATION" -> Color(0xFF0284C7).copy(alpha = 0.15f)
                            "DELETE" -> PalestineRed.copy(alpha = 0.15f)
                            else -> SkyBlue.copy(alpha = 0.15f)
                        }
                    ) {
                        Text(
                            text = when (delta.operation.uppercase()) {
                                "DELIVER" -> "تسليم مساعدة"
                                "UNDO_DELIVERY" -> "تراجع عن تسليم"
                                "APPROVE_NOMINATION" -> "اعتماد ترشيح"
                                "INSERT" -> "إضافة جديدة"
                                "UPDATE" -> "تحديث بيانات"
                                "DELETE" -> "حذف"
                                else -> delta.operation
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (delta.operation.uppercase()) {
                                "DELIVER" -> PalestineGreen
                                "UNDO_DELIVERY" -> FirestoreAmber
                                "APPROVE_NOMINATION" -> Color(0xFF0284C7)
                                "DELETE" -> PalestineRed
                                else -> SkyBlue
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }

                    if (delta.isMasterAdminOverride || delta.userRole == "SUPER_ADMIN") {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = PalestineRed.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "👑 أولوية المدير",
                                fontSize = 9.sp,
                                color = PalestineRed,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Text(
                        text = "${delta.userName} • ${delta.localityName.ifBlank { "محلية ${delta.localityId}" }}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "دُمجت في Room ✅",
                    fontSize = 10.sp,
                    color = PalestineGreen,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Text(
                text = "الكيان: ${delta.entityType} | معرف السجل: #${delta.recordId}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (delta.payloadJson.isNotBlank() && delta.payloadJson != "{}") {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = delta.payloadJson,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(6.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = dateFormat.format(Date(delta.clientTimestamp)),
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                Text(
                    text = "ServerTimestamp: ${delta.serverTimestamp?.let { dateFormat.format(Date(it)) } ?: "موثق من جوجل"}",
                    fontSize = 9.sp,
                    color = FirestoreAmber
                )
            }
        }
    }
}

@Composable
fun PendingRoomQueueCard(
    item: com.humanitarian.aidmanagement.data.local.entities.SyncQueueEntity,
    dateFormat: SimpleDateFormat
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "${item.entityType} [${item.operation}] - سجل #${item.recordId}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Text(
                    text = dateFormat.format(Date(item.createdAt)),
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = FirestoreAmber.copy(alpha = 0.15f)
            ) {
                Text(
                    text = item.status,
                    color = FirestoreAmber,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}
