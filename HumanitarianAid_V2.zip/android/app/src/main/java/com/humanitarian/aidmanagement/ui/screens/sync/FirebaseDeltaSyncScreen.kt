package com.humanitarian.aidmanagement.ui.screens.sync

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.sync.SyncDelta
import java.text.SimpleDateFormat
import java.util.*

private val PalestineGreen = Color(0xFF007A3D)
private val PalestineRed = Color(0xFFE4312B)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirebaseDeltaSyncScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val syncState by repository.getSyncState().collectAsState()
    val pendingItems by repository.getPendingSyncItems().collectAsState(initial = emptyList())
    val recentMergedDeltas by repository.getRecentMergedDeltas().collectAsState()
    val recentUploadedDeltas by repository.getRecentUploadedDeltas().collectAsState()
    val currentUser by repository.currentUserFlow.collectAsState()

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }
    var selectedStreamTab by remember { mutableStateOf(0) } // 0: المدمجة تلقائياً, 1: المعلقة والمرفوعة, 2: بنية النظام
    var customDbUrl by remember { mutableStateOf("") }
    var saveUrlMessage by remember { mutableStateOf<String?>(null) }

    val userLocalityId = currentUser?.AllowedLocalityID ?: 0
    val isSuperAdmin = userLocalityId == 0 || repository.isSuperAdmin()

    // تشغيل مستمع الدمج التلقائي عند فتح الشاشة
    LaunchedEffect(userLocalityId) {
        repository.startMasterSyncListener(userLocalityId)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "منظومة التزامن الفوري (Modern Delta Sync)",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "بنية Offline-First المتطورة مع وسيط Firebase Realtime Database",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                actions = {
                    IconButton(onClick = { repository.triggerSyncNow() }) {
                        Icon(Icons.Default.Sync, contentDescription = "مزامنة فورية", tint = PalestineGreen)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // بطاقة حالة الاتصال السحابي اللحظي
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (syncState.firebaseConnected && syncState.isOnline)
                            PalestineGreen.copy(alpha = 0.12f)
                        else if (!syncState.isOnline)
                            Color(0xFFD97706).copy(alpha = 0.12f)
                        else
                            Color(0xFF0284C7).copy(alpha = 0.10f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (syncState.firebaseConnected && syncState.isOnline) PalestineGreen
                                            else if (!syncState.isOnline) Color(0xFFD97706)
                                            else Color(0xFF0284C7)
                                        )
                                )
                                Column {
                                    Text(
                                        text = if (syncState.firebaseConnected && syncState.isOnline) "متصل بـ Firebase Realtime Database"
                                        else if (!syncState.isOnline) "وضع عدم الاتصال (Offline-First نشط)"
                                        else "متصل بالإنترنت • جاهز للرفع السحابي",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = if (syncState.firebaseConnected && syncState.isOnline) PalestineGreen
                                        else if (!syncState.isOnline) Color(0xFFD97706)
                                        else Color(0xFF0284C7)
                                    )
                                    Text(
                                        text = "عقدة المحلية: deltas/locality_${if (isSuperAdmin) "ALL (مدير النظام)" else userLocalityId}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Button(
                                onClick = { repository.triggerSyncNow() },
                                enabled = syncState.isOnline && !syncState.isSyncing,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen)
                            ) {
                                if (syncState.isSyncing) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("رفع الآن", fontSize = 12.sp)
                                }
                            }
                        }

                        // عدادات الإحصائيات السريعة
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StatBox(
                                title = "حركات معلقة (Room)",
                                count = syncState.pendingCount.toString(),
                                color = if (syncState.pendingCount > 0) Color(0xFFD97706) else PalestineGreen,
                                modifier = Modifier.weight(1f)
                            )
                            StatBox(
                                title = "حركات رُفعت لسحابياً",
                                count = syncState.totalDeltasUploaded.toString(),
                                color = Color(0xFF0284C7),
                                modifier = Modifier.weight(1f)
                            )
                            StatBox(
                                title = "حركات دُمجت تلقائياً",
                                count = syncState.totalDeltasMerged.toString(),
                                color = PalestineGreen,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // شريط مستمع الدمج التلقائي
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.8f))
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    Icons.Default.Hearing,
                                    contentDescription = null,
                                    tint = if (syncState.isMasterListenerActive) PalestineGreen else Color.Gray,
                                    modifier = Modifier.size(18.dp)
                                )
                                Column {
                                    Text(
                                        text = "المستمع المركزي للدمج (Master Auto-Merge):",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (syncState.isMasterListenerActive) "نشط ويراقب حركات المناديب اللحظية" else "متوقف مؤقتاً",
                                        fontSize = 10.sp,
                                        color = if (syncState.isMasterListenerActive) PalestineGreen else Color.Gray
                                    )
                                }
                            }

                            Switch(
                                checked = syncState.isMasterListenerActive,
                                onCheckedChange = { active ->
                                    if (active) repository.startMasterSyncListener(userLocalityId)
                                    else repository.stopMasterSyncListener()
                                }
                            )
                        }
                    }
                }
            }

            // بطاقة محاكاة وضع عدم الاتصال (Offline Simulation)
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "محاكاة انقطاع الإنترنت (Offline Field Test):",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "فعّل هذا الخيار لاختبار تسجيل تسليم مساعدات أثناء انقطاع الشبكة، ثم أعد تشغيله لتشاهد رفع الـ Deltas تلقائياً ودمجها في قاعدة المدير.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Switch(
                            checked = syncState.isSimulatedOffline,
                            onCheckedChange = { repository.toggleOfflineSimulation() }
                        )
                    }
                }
            }

            // شريط تبويب تدفق الأحداث (Stream Tabs)
            item {
                PrimaryTabRow(
                    selectedTabIndex = selectedStreamTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = PalestineGreen,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedStreamTab == 0,
                        onClick = { selectedStreamTab = 0 },
                        text = {
                            Text(
                                "المدمجة تلقائياً (${recentMergedDeltas.size})",
                                fontSize = 12.sp,
                                fontWeight = if (selectedStreamTab == 0) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                    Tab(
                        selected = selectedStreamTab == 1,
                        onClick = { selectedStreamTab = 1 },
                        text = {
                            Text(
                                "المعلقة والمرفوعة (${pendingItems.size})",
                                fontSize = 12.sp,
                                fontWeight = if (selectedStreamTab == 1) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                    Tab(
                        selected = selectedStreamTab == 2,
                        onClick = { selectedStreamTab = 2 },
                        text = {
                            Text(
                                "بنية النظام والتهيئة",
                                fontSize = 12.sp,
                                fontWeight = if (selectedStreamTab == 2) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            // تفاصيل التبويب المختار
            when (selectedStreamTab) {
                0 -> {
                    // تبويب الحركات المدمجة تلقائياً في جهاز المدير
                    if (recentMergedDeltas.isEmpty()) {
                        item {
                            EmptyStateCard(
                                title = "بانتظار وصول حركات جديدة من المناديب",
                                description = "المستمع يعمل في الخلفية ويراقب عقدة Firebase Realtime Database. فور قيام أي مندوب بتسليم مساعدة أو تعديل سجل أسرة، ستظهر الحركة هنا وتُدمج فوراً في قاعدة بياناتك دون استبدال أي ملفات."
                            )
                        }
                    } else {
                        items(recentMergedDeltas) { delta ->
                            DeltaItemCard(delta = delta, isMerged = true, dateFormat = dateFormat)
                        }
                    }
                }

                1 -> {
                    // تبويب الحركات المعلقة في هاتف المندوب
                    if (pendingItems.isEmpty()) {
                        item {
                            EmptyStateCard(
                                title = "طابور التزامن المحلي نظيف تماماً ✅",
                                description = "كافة العمليات والحركات التي سُجلت على هذا الهاتف تم رفعها وتزامنها سحابياً مع Firebase Realtime Database."
                            )
                        }
                    } else {
                        items(pendingItems) { item ->
                            PendingQueueItemCard(item = item, dateFormat = dateFormat)
                        }
                    }

                    if (recentUploadedDeltas.isNotEmpty()) {
                        item {
                            Text(
                                text = "أحدث الحركات المرفوعة من هذا الجهاز (${recentUploadedDeltas.size}):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF0284C7)
                            )
                        }
                        items(recentUploadedDeltas) { delta ->
                            DeltaItemCard(delta = delta, isMerged = false, dateFormat = dateFormat)
                        }
                    }
                }

                2 -> {
                    // تبويب معمارية النظام وتهيئة Firebase
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "معمارية التزامن الجزئي (Delta Event Sourcing Architecture)",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = PalestineGreen
                                )

                                Text(
                                    text = "1. وسيط خفيف (Firebase Realtime Database as Middleman):\n" +
                                            "يتم تخصيص عقدة لكل محلية:\n" +
                                            "humanitarian_aid_sync/deltas/locality_{localityId}/{deltaId}\n\n" +
                                            "2. منع التعارض والتكرار (Event Sourcing & Conflict Resolution):\n" +
                                            "بدلاً من استبدال قاعدة البيانات بالكامل أو تبادل ملفات الإكسل، يتم تسجيل الأحداث كـ Deltas مستقلة (مثل حركة تسليم مساعدة). عند وصول الحركة لجهاز المدير، يقرأ الـ JSON ويقوم بـ Update أو Insert مباشر في Room DB.\n\n" +
                                            "3. العزل الجغرافي الصارم (Locality Isolation):\n" +
                                            "كل مندوب يرفع حصراً إلى عقدة محليته، بينما يراقب المدير العام كافة المحليات.",
                                    fontSize = 12.sp,
                                    lineHeight = 20.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                HorizontalDivider()

                                Text(
                                    text = "تهيئة رابط قاعدة بيانات Firebase المخصص:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )

                                OutlinedTextField(
                                    value = customDbUrl,
                                    onValueChange = { customDbUrl = it },
                                    label = { Text("رابط Firebase Database URL (اختياري)") },
                                    placeholder = { Text("https://your-project-rtdb.firebaseio.com") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )

                                Button(
                                    onClick = {
                                        com.humanitarian.aidmanagement.sync.FirebaseSyncManager.getInstance(repository.database.openHelper.writableDatabase.let {
                                            // Context lookup through repository
                                        })
                                        saveUrlMessage = "تم حفظ الإعدادات وتهيئة الاتصال بـ Firebase"
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = PalestineGreen),
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Text("تطبيق وتحديث")
                                }

                                saveUrlMessage?.let { msg ->
                                    Text(text = msg, fontSize = 11.sp, color = PalestineGreen)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatBox(
    title: String,
    count: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = color.copy(alpha = 0.12f),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = count, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = title, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun EmptyStateCard(title: String, description: String) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.DoneAll, contentDescription = null, tint = PalestineGreen, modifier = Modifier.size(36.dp))
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(
                text = description,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun DeltaItemCard(
    delta: SyncDelta,
    isMerged: Boolean,
    dateFormat: SimpleDateFormat
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = when (delta.operation.uppercase()) {
                            "DELIVER" -> PalestineGreen.copy(alpha = 0.15f)
                            "UNDO_DELIVERY" -> Color(0xFFD97706).copy(alpha = 0.15f)
                            "DELETE" -> PalestineRed.copy(alpha = 0.15f)
                            else -> Color(0xFF0284C7).copy(alpha = 0.15f)
                        }
                    ) {
                        Text(
                            text = when (delta.operation.uppercase()) {
                                "DELIVER" -> "تسليم مساعدة"
                                "UNDO_DELIVERY" -> "تراجع عن تسليم"
                                "INSERT" -> "إضافة جديدة"
                                "UPDATE" -> "تحديث بيانات"
                                "DELETE" -> "حذف"
                                else -> delta.operation
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (delta.operation.uppercase()) {
                                "DELIVER" -> PalestineGreen
                                "UNDO_DELIVERY" -> Color(0xFFD97706)
                                "DELETE" -> PalestineRed
                                else -> Color(0xFF0284C7)
                            },
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }

                    Text(
                        text = "${delta.userName} • محلية ${delta.localityName.ifBlank { delta.localityId.toString() }}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (isMerged) "تم الدمج في Room ✅" else "مرفوع لسحابياً ☁️",
                    fontSize = 10.sp,
                    color = PalestineGreen,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Text(
                text = "الكيان: ${delta.entityType} | سجل #${delta.recordId}",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (delta.payloadJson.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = delta.payloadJson,
                        fontSize = 9.sp,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        modifier = Modifier.padding(6.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = dateFormat.format(Date(delta.timestamp)),
                fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}

@Composable
fun PendingQueueItemCard(
    item: com.humanitarian.aidmanagement.data.local.entities.SyncQueueEntity,
    dateFormat: SimpleDateFormat
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "${item.entityType} [${item.operation}] - سجل #${item.recordId}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
                Text(
                    text = dateFormat.format(Date(item.createdAt)),
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = Color(0xFFF59E0B).copy(alpha = 0.15f)
            ) {
                Text(
                    text = item.status,
                    color = Color(0xFFD97706),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}
