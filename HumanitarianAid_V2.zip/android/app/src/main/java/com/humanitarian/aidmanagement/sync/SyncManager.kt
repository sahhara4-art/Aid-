package com.humanitarian.aidmanagement.sync

import android.content.Context
import android.util.Log
import androidx.work.*
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.SyncLogEntity
import com.humanitarian.aidmanagement.data.local.entities.SyncQueueEntity
import com.humanitarian.aidmanagement.data.local.entities.UserEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.concurrent.TimeUnit

data class SyncUiState(
    val isOnline: Boolean = true,
    val isSyncing: Boolean = false,
    val pendingCount: Int = 0,
    val lastSyncTime: Long? = null,
    val lastSyncStatus: String? = null,
    val isSimulatedOffline: Boolean = false,
    val firebaseConnected: Boolean = false,
    val isMasterListenerActive: Boolean = false,
    val totalDeltasUploaded: Int = 0,
    val totalDeltasMerged: Int = 0,
    val lastMergedDelta: SyncDelta? = null
)

/**
 * SyncManager - المنسق العام لمنظومة التزامن الميداني الحديثة (Modern Delta Sync Engine)
 * يربط بين WorkManager، وقاعدة بيانات Room المحلية، وFirebase Realtime Database الوسيطة
 * ويدير تشغيل مستمع الدمج التلقائي (FirebaseSyncListener) على أجهزة المدراء.
 */
object SyncManager {
    private const val TAG = "SyncManager"

    private var appContext: Context? = null
    private var database: AidDatabase? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _syncState = MutableStateFlow(SyncUiState())
    val syncState: StateFlow<SyncUiState> = _syncState.asStateFlow()

    private var connectivityObserver: NetworkConnectivityObserver? = null
    private var firebaseSyncManager: FirebaseSyncManager? = null
    private var firebaseSyncListener: FirebaseSyncListener? = null
    private var wasOffline = false

    fun initialize(context: Context, db: AidDatabase) {
        this.appContext = context.applicationContext
        this.database = db

        connectivityObserver = NetworkConnectivityObserver(context)
        val fbManager = FirebaseSyncManager.getInstance(context)
        this.firebaseSyncManager = fbManager

        val fbListener = FirebaseSyncListener(db, fbManager)
        this.firebaseSyncListener = fbListener

        // 1. مراقبة التغيرات في عدد السجلات المعلقة في طابور Room DB
        scope.launch {
            db.syncQueueDao().getPendingCountFlow().collect { count ->
                _syncState.update { it.copy(pendingCount = count) }
            }
        }

        // 2. قراءة آخر عملية مزامنة من جدول السجلات
        scope.launch {
            val lastLog = db.syncQueueDao().getLastSyncLog()
            if (lastLog != null) {
                _syncState.update {
                    it.copy(
                        lastSyncTime = lastLog.timestamp,
                        lastSyncStatus = lastLog.summary
                    )
                }
            }
        }

        // 3. مراقبة اتصال Firebase الفعلي
        scope.launch {
            fbManager.isConnected.collect { connected ->
                _syncState.update { it.copy(firebaseConnected = connected) }
            }
        }

        // 4. مراقبة إحصائيات الرفع والدمج في الوقت الحقيقي
        scope.launch {
            fbManager.totalUploadedCount.collect { count ->
                _syncState.update { it.copy(totalDeltasUploaded = count) }
            }
        }

        scope.launch {
            fbListener.totalMergedCount.collect { count ->
                _syncState.update { it.copy(totalDeltasMerged = count) }
            }
        }

        scope.launch {
            fbListener.lastMergedDelta.collect { delta ->
                _syncState.update { it.copy(lastMergedDelta = delta) }
            }
        }

        scope.launch {
            fbListener.isListening.collect { active ->
                _syncState.update { it.copy(isMasterListenerActive = active) }
            }
        }

        // 5. مراقبة الاتصال بالإنترنت وتشغيل المزامنة التلقائية فور استعادة الشبكة
        scope.launch {
            connectivityObserver?.observe()?.collect { status ->
                val realOnline = status == NetworkStatus.Available
                val effectiveOnline = realOnline && !_syncState.value.isSimulatedOffline

                val previouslyOffline = wasOffline
                wasOffline = !effectiveOnline

                _syncState.update { it.copy(isOnline = effectiveOnline) }

                // إذا كان الجهاز غير متصل ثم عادت الشبكة، نفذ التزامن التلقائي عبر WorkManager أو فورياً
                if (previouslyOffline && effectiveOnline) {
                    triggerImmediateSync("AUTO_RECONNECT")
                }
            }
        }

        // 6. جدولة التزامن الخلفي الدوري عبر WorkManager عند توفر الاتصال
        schedulePeriodicSync(context)
    }

    private fun schedulePeriodicSync(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val periodicWork = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "AidSystemPeriodicSync",
            ExistingPeriodicWorkPolicy.KEEP,
            periodicWork
        )
    }

    /**
     * بدء مستمع الدمج التلقائي المركزي (Master Auto-Merge)
     * يُستدعى عند تسجيل دخول مدير النظام أو عند فتح شاشة التزامن
     */
    fun startMasterSyncListener(targetLocalityId: Int = 0) {
        firebaseSyncListener?.startListening(targetLocalityId)
    }

    /**
     * إيقاف مستمع الدمج التلقائي
     */
    fun stopMasterSyncListener() {
        firebaseSyncListener?.stopListening()
    }

    fun getRecentMergedDeltas(): StateFlow<List<SyncDelta>> {
        return firebaseSyncListener?.recentMergedDeltas ?: MutableStateFlow(emptyList())
    }

    fun getRecentUploadedDeltas(): StateFlow<List<SyncDelta>> {
        return firebaseSyncManager?.recentUploadedDeltas ?: MutableStateFlow(emptyList())
    }

    /**
     * إدراج عملية جديدة في طابور التزامن في Room DB
     */
    suspend fun enqueueItem(
        entityType: String,
        operation: String,
        recordId: String,
        payloadJson: String
    ): Long {
        val db = database ?: return -1L
        val item = SyncQueueEntity(
            entityType = entityType,
            operation = operation,
            recordId = recordId,
            payloadJson = payloadJson,
            createdAt = System.currentTimeMillis(),
            status = "PENDING"
        )
        val id = db.syncQueueDao().enqueue(item)

        // إذا كان الجهاز متصلاً بالإنترنت حالياً، نطلق المزامنة الفورية لرفع الحركة فوراً
        if (_syncState.value.isOnline && !_syncState.value.isSimulatedOffline) {
            scope.launch {
                triggerImmediateSync("AUTO_INSTANT")
            }
        }

        return id
    }

    /**
     * تشغيل المزامنة الفورية ورفع كافة الحركات المعلقة في Room إلى Firebase Realtime Database
     */
    fun triggerImmediateSync(reason: String = "MANUAL") {
        val db = database ?: return
        val fb = firebaseSyncManager ?: return
        if (_syncState.value.isSyncing) return

        scope.launch {
            _syncState.update { it.copy(isSyncing = true) }

            val syncDao = db.syncQueueDao()
            val pendingItems = syncDao.getPendingSyncItems()

            if (pendingItems.isEmpty()) {
                _syncState.update { it.copy(isSyncing = false) }
                return@launch
            }

            var succeeded = 0
            var failed = 0

            // قراءة معلومات المستخدم الحالية مع تحديد الأنواع صراحة (Explicit Typing & Generics)
            val users: List<UserEntity> = db.userDao().getAllUsersSync()
            val currentUser: UserEntity? = users.firstOrNull<UserEntity> { it.IsActive } ?: users.firstOrNull<UserEntity>()
            val localityId: Int = currentUser?.AllowedLocalityID ?: 0
            val userName: String = currentUser?.FullName ?: "مندوب ميداني"
            val userId: Int = currentUser?.UserID ?: 1

            val localities = db.localityDao().getAllLocalitiesSync()
            val localityName = localities.find { it.LocalityID == localityId }?.LocalityName ?: "المحلية"

            for (item in pendingItems) {
                try {
                    syncDao.markAsSyncing(item.syncId)

                    val delta = SyncDelta(
                        localityId = localityId,
                        localityName = localityName,
                        userId = userId,
                        userName = userName,
                        entityType = item.entityType,
                        operation = item.operation,
                        recordId = item.recordId,
                        payloadJson = item.payloadJson,
                        timestamp = item.createdAt,
                        deviceId = fb.deviceId
                    )

                    val ok = fb.pushDelta(delta)
                    if (ok) {
                        syncDao.markAsSynced(item.syncId)
                        succeeded++
                    } else {
                        syncDao.markAsFailed(item.syncId, "تعذر رفع الحركة إلى Firebase")
                        failed++
                    }
                } catch (e: Exception) {
                    syncDao.markAsFailed(item.syncId, e.message ?: "خطأ في الاتصال")
                    failed++
                }
            }

            // تنظيف العمليات المتزامنة بنجاح من الطابور
            if (succeeded > 0) {
                syncDao.clearSynced()
            }

            val now = System.currentTimeMillis()
            val status = if (failed == 0) "SUCCESS" else if (succeeded > 0) "PARTIAL" else "FAILED"
            val summary = "تمت مزامنة $succeeded حركة إلى Firebase Realtime Database، وفشل $failed حركات (السبب: $reason)"

            val log = SyncLogEntity(
                syncType = reason,
                itemsProcessed = pendingItems.size,
                itemsSucceeded = succeeded,
                itemsFailed = failed,
                status = status,
                summary = summary,
                timestamp = now
            )
            syncDao.insertSyncLog(log)

            _syncState.update {
                it.copy(
                    isSyncing = false,
                    lastSyncTime = now,
                    lastSyncStatus = summary
                )
            }
        }
    }

    /**
     * تفعيل أو إيقاف وضع عدم الاتصال التجريبي لمحاكاة انقطاع وعودة الإنترنت
     */
    fun toggleSimulatedOffline() {
        val newSimulatedState = !_syncState.value.isSimulatedOffline
        val realOnline = connectivityObserver?.isCurrentlyOnline() ?: true
        val effectiveOnline = realOnline && !newSimulatedState

        val wasOff = !_syncState.value.isOnline
        _syncState.update {
            it.copy(
                isSimulatedOffline = newSimulatedState,
                isOnline = effectiveOnline
            )
        }

        // إذا تم إلغاء وضع عدم الاتصال وأصبح الجهاز أونلاين، نقوم بالمزامنة التلقائية فوراً
        if (wasOff && effectiveOnline) {
            triggerImmediateSync("AUTO_RECONNECT_SIMULATED")
        }
    }

    /**
     * تحديث وتهيئة رابط Firebase Realtime Database المخصص
     */
    fun configureFirebaseDatabaseUrl(customUrl: String?) {
        firebaseSyncManager?.initialize(customUrl?.takeIf { it.isNotBlank() })
    }
}
