package com.humanitarian.aidmanagement.ui.screens.families

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * شاشة الملف الشامل للأسرة (FamilyDetailsScreen)
 * تعرض ملفاً متكاملاً واحترافياً للأسرة مقسماً إلى 3 تبويبات رئيسية:
 * 1. البيانات الأساسية والتفصيلية للأسرة
 * 2. قائمة الأبناء والتابعين
 * 3. سجل المساعدات المستفادة وتواريخ التسليم
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamilyDetailsScreen(
    familyId: Long,
    repository: AidRepository,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // جلب بيانات الأسرة والتابعين وسجل المساعدات تفاعلياً وآمناً من قاعدة البيانات
    val family by repository.getFamilyById(familyId).collectAsState(initial = null)
    val children by remember(family?.nationalID) {
        repository.getChildrenByFamily(family?.nationalID ?: "")
    }.collectAsState(initial = emptyList())

    val aidRecords by remember(familyId) {
        repository.getAidRecordsForFamily(familyId)
    }.collectAsState(initial = emptyList())

    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val projects by repository.getActiveProjects().collectAsState(initial = emptyList())

    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabTitles = listOf("البيانات التفصيلية", "الأبناء والتابعون (${children.size})", "سجل المساعدات (${aidRecords.size})")

    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    // التحقق الصارم من صلاحيات المنطقة الجغرافية والصلاحيات الإدارية (Area & Role Based Access)
    val isAreaAllowed = family == null || repository.canUserViewSubArea(family?.currentSubArea)
    val canEdit = family != null && repository.canUserEditFamily(family!!)
    val canDelete = family != null && repository.canUserDeleteFamily(family!!)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "الملف الشامل للأسرة",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            if (family != null) {
                                Text(
                                    text = family!!.name,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        if (family != null && isAreaAllowed) {
                            if (canEdit) {
                                IconButton(onClick = { showEditDialog = true }) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "تعديل بيانات الأسرة",
                                        tint = PalestineGreen
                                    )
                                }
                            }
                            if (canDelete) {
                                IconButton(onClick = { showDeleteConfirmDialog = true }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف الأسرة",
                                        tint = PalestineRed
                                    )
                                }
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            if (family == null) {
                // حالة التحميل أو البحث عن الأسرة
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = PalestineGreen)
                        Text(
                            text = "جاري تحميل الملف الشامل للأسرة...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else if (!isAreaAllowed) {
                // شاشة منع الوصول بسبب تقييد المنطقة الفرعية (Area-Based Access Restriction)
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .padding(paddingValues)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(PalestineRed.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = PalestineRed,
                                    modifier = Modifier.size(36.dp)
                                )
                            }

                            Text(
                                text = "تقييد أمني للمنطقة الفرعية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = PalestineRed
                            )

                            Text(
                                text = "عذراً، ليس لديك صلاحية للاطلاع على بيانات هذه الأسرة نظراً لتقييد حسابك الجغرافي.\nالأسرة مسجلة في المنطقة الفرعية: (${family!!.currentSubArea.ifBlank { "غير محددة" }}).",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                lineHeight = 22.sp
                            )

                            Button(
                                onClick = onNavigateBack,
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("العودة لقائمة الأسر", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                val currentFamily = family!!
                val localityName = localities.find { it.LocalityID == currentFamily.localityID }?.LocalityName
                    ?: "محلية #${currentFamily.localityID}"

                // حوار تعديل الأسرة
                if (showEditDialog) {
                    EditFamilyDialog(
                        family = currentFamily,
                        localities = localities,
                        onDismiss = { showEditDialog = false },
                        onSave = { updatedFamily ->
                            scope.launch(Dispatchers.IO) {
                                try {
                                    repository.updateFamily(updatedFamily)
                                    launch(Dispatchers.Main) {
                                        Toast.makeText(context, "تم حفظ وتحديث بيانات الأسرة بنجاح", Toast.LENGTH_SHORT).show()
                                        showEditDialog = false
                                    }
                                } catch (e: Exception) {
                                    launch(Dispatchers.Main) {
                                        Toast.makeText(context, "خطأ أثناء حفظ التعديل: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }
                    )
                }

                // حوار تأكيد حذف الأسرة
                if (showDeleteConfirmDialog) {
                    AlertDialog(
                        onDismissRequest = { showDeleteConfirmDialog = false },
                        icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = PalestineRed) },
                        title = { Text("تأكيد حذف الأسرة", fontWeight = FontWeight.Bold) },
                        text = {
                            Text("هل أنت متأكد من رغبتك في حذف أسرة \"${currentFamily.name}\" (رقم الهوية: ${currentFamily.nationalID}) نهائياً من قاعدة البيانات؟\nهذا الإجراء نهائي ولا يمكن التراجع عنه.")
                        },
                        confirmButton = {
                            Button(
                                onClick = {
                                    showDeleteConfirmDialog = false
                                    scope.launch(Dispatchers.IO) {
                                        try {
                                            repository.deleteFamily(currentFamily)
                                            launch(Dispatchers.Main) {
                                                Toast.makeText(context, "تم حذف الأسرة بنجاح", Toast.LENGTH_SHORT).show()
                                                onNavigateBack()
                                            }
                                        } catch (e: Exception) {
                                            launch(Dispatchers.Main) {
                                                Toast.makeText(context, "خطأ أثناء الحذف: ${e.message}", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PalestineRed),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("نعم، حذف نهائي", fontWeight = FontWeight.Bold)
                            }
                        },
                        dismissButton = {
                            OutlinedButton(
                                onClick = { showDeleteConfirmDialog = false },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("إلغاء")
                            }
                        }
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .padding(paddingValues)
                ) {
                    // البطاقة الرأسية الموجزة (Hero Card)
                    FamilyHeroCard(
                        family = currentFamily,
                        localityName = localityName,
                        childrenCount = children.size,
                        aidCount = aidRecords.size
                    )

                    // شريط التبويبات المتطور
                    PrimaryTabRow(
                        selectedTabIndex = selectedTabIndex,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = PalestineGreen,
                        indicator = {
                            TabRowDefaults.PrimaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(selectedTabIndex),
                                color = PalestineGreen
                            )
                        }
                    ) {
                        tabTitles.forEachIndexed { index, title ->
                            Tab(
                                selected = selectedTabIndex == index,
                                onClick = { selectedTabIndex = index },
                                text = {
                                    Text(
                                        text = title,
                                        fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp,
                                        color = if (selectedTabIndex == index) PalestineGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                },
                                icon = {
                                    Icon(
                                        imageVector = when (index) {
                                            0 -> Icons.Default.Badge
                                            1 -> Icons.Default.People
                                            else -> Icons.Default.History
                                        },
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = if (selectedTabIndex == index) PalestineGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            )
                        }
                    }

                    // محتوى التبويب المختار
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        when (selectedTabIndex) {
                            0 -> FamilyBasicDetailsTab(family = currentFamily, localityName = localityName)
                            1 -> FamilyChildrenTab(children = children)
                            2 -> FamilyAidRecordsTab(
                                aidRecords = aidRecords,
                                aidTypes = aidTypes,
                                projects = projects
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * بطاقة الملخص الرأسي للأسرة
 */
@Composable
fun FamilyHeroCard(
    family: FamilyEntity,
    localityName: String,
    childrenCount: Int,
    aidCount: Int
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(PalestineGreenContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FamilyRestroom,
                        contentDescription = null,
                        modifier = Modifier.size(30.dp),
                        tint = PalestineGreen
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = family.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(3.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = "هوية: ${family.nationalID}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }

                        Text(
                            text = localityName,
                            style = MaterialTheme.typography.bodySmall,
                            color = PalestineGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // شريط إحصائيات سريعة للأسرة
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(SlateSurfaceVariant)
                    .padding(vertical = 10.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                QuickMetric(label = "أفراد الأسرة", value = "${family.familyMembersCount}", icon = Icons.Default.People)
                Divider(modifier = Modifier.height(28.dp).width(1.dp), color = SlateBorder)
                QuickMetric(label = "الأبناء المسجلون", value = "$childrenCount", icon = Icons.Default.ChildCare)
                Divider(modifier = Modifier.height(28.dp).width(1.dp), color = SlateBorder)
                QuickMetric(label = "المساعدات المستلمة", value = "$aidCount", icon = Icons.Default.VolunteerActivism)
                Divider(modifier = Modifier.height(28.dp).width(1.dp), color = SlateBorder)
                QuickMetric(label = "حالة الإيواء", value = family.shelterStatus, icon = Icons.Default.Home)
            }
        }
    }
}

@Composable
fun QuickMetric(label: String, value: String, icon: ImageVector) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(13.dp), tint = PalestineGreen)
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = SlateTextPrimary
            )
        }
        Text(
            text = label,
            fontSize = 11.sp,
            color = SlateTextMuted
        )
    }
}

/**
 * التبويب الأول: البيانات الأساسية والتفصيلية الشاملة لكافة حقول الأسرة
 * مصممة وفق أحدث معايير Jetpack Compose و Material 3 باستخدام LazyColumn و ElevatedCard
 * مع أيقونة مميزة بجوار كل حقل لعرض تفصيلي استثنائي بدون ملل.
 */
@Composable
fun FamilyBasicDetailsTab(
    family: FamilyEntity,
    localityName: String
) {
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. بطاقة المعلومات الأساسية والهوية الديموغرافية
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "المعلومات الأساسية والهوية الديموغرافية",
                        icon = Icons.Default.Person,
                        badgeText = "هوية: ${family.nationalID}",
                        badgeColor = PalestineGreen
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    DetailFieldWithIcon(Icons.Default.Person, "الاسم الرباعي الكامل", family.name)
                    DetailFieldWithIcon(Icons.Default.Badge, "رقم الهوية الوطنية", family.nationalID)
                    DetailFieldWithIcon(Icons.Default.CalendarToday, "تاريخ الميلاد", family.birthDate.ifBlank { "غير مسجل" })
                    DetailFieldWithIcon(Icons.Default.Cake, "العمر المسجل", "${family.age} سنة")
                    DetailFieldWithIcon(Icons.Default.Wc, "الجنس", family.gender)
                    DetailFieldWithIcon(Icons.Default.Favorite, "الحالة الاجتماعية", family.maritalStatus)
                    DetailFieldWithIcon(
                        icon = Icons.Default.HeartBroken,
                        label = "حالة الحياة والوفاة",
                        value = family.deathStatus,
                        badgeColor = if (family.deathStatus.contains("وفاة") || family.deathStatus.contains("متوفى")) PalestineRed else PalestineGreen
                    )
                    if (!family.deathDate.isNullOrBlank()) {
                        DetailFieldWithIcon(Icons.Default.EventBusy, "تاريخ الوفاة", family.deathDate!!, iconTint = PalestineRed)
                    }
                    DetailFieldWithIcon(Icons.Default.CreditCard, "رقم البطاقة التموينية (كرت المؤن)", family.rationCardNumber ?: "غير مسجل")
                }
            }
        }

        // 2. بطاقة التركيبة الأسرية والتبعية ومصادر الدخل
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "التركيبة الأسرية ومصادر الدخل",
                        icon = Icons.Default.FamilyRestroom,
                        badgeText = "${family.familyMembersCount} أفراد",
                        badgeColor = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    DetailFieldWithIcon(Icons.Default.Face, "اسم الزوج/الزوجة", family.wifeName ?: "غير مسجل")
                    DetailFieldWithIcon(Icons.Default.Badge, "رقم هوية الزوج/الزوجة", family.wifeNationalID ?: "غير مسجل")
                    DetailFieldWithIcon(Icons.Default.Groups, "إجمالي عدد أفراد الأسرة", "${family.familyMembersCount} أفراد")
                    DetailFieldWithIcon(Icons.Default.Payments, "مصدر الدخل الأساسي (١)", family.incomeSource1)
                    if (!family.incomeSource2.isNullOrBlank()) {
                        DetailFieldWithIcon(Icons.Default.AccountBalanceWallet, "مصدر الدخل الإضافي (٢)", family.incomeSource2!!)
                    }
                }
            }
        }

        // 3. بطاقة بيانات السكن والعناوين الجغرافية والنزوح
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "بيانات السكن والموقع الجغرافي والنزوح",
                        icon = Icons.Default.LocationOn,
                        badgeText = localityName,
                        badgeColor = PalestineGreen
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    DetailFieldWithIcon(Icons.Default.LocationCity, "المحلية المعتمدة", localityName)
                    DetailFieldWithIcon(Icons.Default.PinDrop, "المنطقة الرئيسية الحالية", family.currentMainArea.ifBlank { "غير محددة" })
                    DetailFieldWithIcon(Icons.Default.Place, "المنطقة الفرعية الحالية", family.currentSubArea.ifBlank { "غير محددة" })
                    DetailFieldWithIcon(Icons.Default.AltRoute, "الشعبة الحالية", family.currentBranch.ifBlank { "غير محددة" })
                    DetailFieldWithIcon(Icons.Default.Mosque, "المسجد الحالي", family.currentMosque.ifBlank { "غير محدد" })

                    Spacer(modifier = Modifier.height(4.dp))
                    Divider(color = SlateBorder.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(4.dp))

                    DetailFieldWithIcon(Icons.Default.History, "المنطقة الرئيسية الأصلية (قبل النزوح)", family.originalMainArea.ifBlank { "غير محددة" })
                    DetailFieldWithIcon(Icons.Default.Map, "المنطقة الفرعية الأصلية", family.originalSubArea.ifBlank { "غير محددة" })
                    DetailFieldWithIcon(Icons.Default.ShareLocation, "الشعبة الأصلية", family.originalBranch.ifBlank { "غير محددة" })
                    DetailFieldWithIcon(Icons.Default.Mosque, "المسجد الأصلي", family.originalMosque.ifBlank { "غير محدد" })

                    Spacer(modifier = Modifier.height(4.dp))
                    Divider(color = SlateBorder.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(4.dp))

                    DetailFieldWithIcon(Icons.Default.NightShelter, "حالة الإيواء الحالية", family.shelterStatus)
                    if (!family.campOrCenterName.isNullOrBlank()) {
                        DetailFieldWithIcon(Icons.Default.HolidayVillage, "اسم المخيم / مركز الإيواء", family.campOrCenterName!!)
                    }
                }
            }
        }

        // 4. بطاقة الحالة الصحية والإصابات وأضرار الحرب
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الحالة الصحية والإصابات وأضرار الحرب",
                        icon = Icons.Default.LocalHospital,
                        badgeText = family.injuryStatus,
                        badgeColor = if (family.injuryStatus.contains("سليم")) PalestineGreen else PalestineRed
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    DetailFieldWithIcon(
                        icon = Icons.Default.HomeWork,
                        label = "نوع الضرر المسجل للمنزل",
                        value = family.damageType,
                        badgeColor = when {
                            family.damageType.contains("كلي") -> PalestineRed
                            family.damageType.contains("جزئي") -> Color(0xFFD97706)
                            else -> PalestineGreen
                        }
                    )
                    if (!family.damageDescription.isNullOrBlank()) {
                        DetailFieldWithIcon(Icons.Default.ReportProblem, "وصف تفاصيل أضرار المنزل", family.damageDescription!!)
                    }

                    DetailFieldWithIcon(
                        icon = Icons.Default.LocalHospital,
                        label = "حالة الإصابة المسجلة",
                        value = family.injuryStatus,
                        badgeColor = if (family.injuryStatus.contains("سليم")) PalestineGreen else PalestineRed
                    )
                    if (!family.injuryDate.isNullOrBlank()) {
                        DetailFieldWithIcon(Icons.Default.Event, "تاريخ الإصابة", family.injuryDate!!)
                    }
                }
            }
        }

        // 5. بطاقة الاعتمادات الرسمية والتصنيفات الحكومية
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الاعتمادات الرسمية والتصنيفات الحكومية",
                        icon = Icons.Default.Verified,
                        badgeText = family.developmentApproval,
                        badgeColor = if (family.developmentApproval.contains("معتمد")) PalestineGreen else PalestineRed
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    DetailFieldWithIcon(
                        icon = Icons.Default.Verified,
                        label = "اعتماد وزارة التنمية الاجتماعية",
                        value = family.developmentApproval,
                        badgeColor = if (family.developmentApproval.contains("معتمد")) PalestineGreen else PalestineRed
                    )
                    DetailFieldWithIcon(
                        icon = Icons.Default.Gavel,
                        label = "اعتماد وزارة الأشغال العامة",
                        value = family.worksApproval.ifBlank { "غير معتمد" }
                    )
                    DetailFieldWithIcon(
                        icon = Icons.Default.DomainVerification,
                        label = "اعتماد المناطق والمحليات",
                        value = family.localityApproval,
                        badgeColor = if (family.localityApproval.contains("معتمد")) PalestineGreen else Color(0xFFD97706)
                    )
                    DetailFieldWithIcon(
                        icon = Icons.Default.PersonPin,
                        label = "حالة الإقامة الرسمية",
                        value = family.residentStatus
                    )
                }
            }
        }

        // 6. بطاقة أرقام وبيانات الاتصال
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "أرقام وبيانات الاتصال والتواصل",
                        icon = Icons.Default.Phone,
                        badgeText = family.primaryPhone.ifBlank { "لا يوجد هاتف" },
                        badgeColor = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    DetailFieldWithIcon(Icons.Default.Phone, "رقم الجوال الأساسي", family.primaryPhone.ifBlank { "غير مسجل" })
                    if (!family.alternativePhone1.isNullOrBlank()) {
                        DetailFieldWithIcon(Icons.Default.PhoneIphone, "رقم جوال بديل (١)", family.alternativePhone1!!)
                    }
                    if (!family.alternativePhone2.isNullOrBlank()) {
                        DetailFieldWithIcon(Icons.Default.Call, "رقم جوال بديل (٢)", family.alternativePhone2!!)
                    }
                }
            }
        }

        // 7. بطاقة الملاحظات وتواريخ القيد بالنظام
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    SectionHeaderWithBadge(
                        title = "الملاحظات الإدارية وتواريخ القيد",
                        icon = Icons.Default.Description,
                        badgeText = "سجل معتمد",
                        badgeColor = PalestineGreen
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Divider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    if (!family.notes.isNullOrBlank()) {
                        DetailFieldWithIcon(Icons.Default.Notes, "الملاحظات الإدارية والميدانية", family.notes!!)
                    } else {
                        DetailFieldWithIcon(Icons.Default.Notes, "الملاحظات الإدارية", "لا توجد ملاحظات مسجلة على هذه الأسرة")
                    }

                    DetailFieldWithIcon(
                        icon = Icons.Default.Schedule,
                        label = "تاريخ التسجيل الأولي بالقاعدة",
                        value = dateFormat.format(Date(family.createdDate))
                    )

                    if (family.modifiedDate != null) {
                        DetailFieldWithIcon(
                            icon = Icons.Default.Update,
                            label = "تاريخ آخر تعديل للملف",
                            value = dateFormat.format(Date(family.modifiedDate!!))
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

/**
 * التبويب الثاني: قائمة الأبناء والتابعين
 */
@Composable
fun FamilyChildrenTab(
    children: List<ChildEntity>
) {
    if (children.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ChildCare,
                        contentDescription = null,
                        modifier = Modifier.size(36.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
                Text(
                    text = "لا يوجد أبناء أو تابعون مسجلون",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "لم يتم تسجيل بيانات أطفال مرتبطين بهذه الأسرة في النظام حتى الآن.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "قائمة الأبناء والتابعين المسجلين (${children.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    val boysCount = children.count { it.gender.contains("ذكر") }
                    val girlsCount = children.size - boysCount
                    Text(
                        text = "$boysCount ذكور • $girlsCount إناث",
                        style = MaterialTheme.typography.labelSmall,
                        color = PalestineGreen,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            items(children, key = { it.childID }) { child ->
                ChildItemCard(child = child)
            }
        }
    }
}

@Composable
fun ChildItemCard(child: ChildEntity) {
    val isMale = child.gender.contains("ذكر")
    val avatarBg = if (isMale) Color(0xFFE0F2FE) else Color(0xFFFCE7F3)
    val avatarTint = if (isMale) Color(0xFF0284C7) else Color(0xFFDB2777)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(avatarBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ChildCare,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                    tint = avatarTint
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = child.childName,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "هوية: ${child.nationalID}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(text = "•", color = MaterialTheme.colorScheme.outline)
                    Text(
                        text = "الميلاد: ${child.birthDate}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = avatarBg
            ) {
                Text(
                    text = child.gender,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = avatarTint,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

/**
 * التبويب الثالث: سجل المساعدات المستفادة وتواريخ الاستلام
 */
@Composable
fun FamilyAidRecordsTab(
    aidRecords: List<AidRecordEntity>,
    aidTypes: List<com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity>,
    projects: List<com.humanitarian.aidmanagement.data.local.entities.ProjectEntity>
) {
    if (aidRecords.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Inventory,
                        contentDescription = null,
                        modifier = Modifier.size(36.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    )
                }
                Text(
                    text = "لا توجد مساعدات مسجلة",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "لم يتم تسليم أو صرف أي مساعدات إنسانية لهذه الأسرة حتى تاريخه.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                // شريط ملخص المساعدات
                val deliveredCount = aidRecords.count { it.recipientStatus.contains("تسليم") || it.recipientStatus.contains("مستلم") }
                val totalValue = aidRecords.sumOf { it.aidValue }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = PalestineGreenContainer)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "${aidRecords.size}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PalestineGreenDark)
                            Text(text = "إجمالي السجلات", fontSize = 11.sp, color = PalestineGreenDark)
                        }
                        Divider(modifier = Modifier.height(26.dp).width(1.dp), color = PalestineGreen.copy(alpha = 0.3f))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "$deliveredCount", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PalestineGreenDark)
                            Text(text = "تم التسليم", fontSize = 11.sp, color = PalestineGreenDark)
                        }
                        Divider(modifier = Modifier.height(26.dp).width(1.dp), color = PalestineGreen.copy(alpha = 0.3f))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "${totalValue.toInt()} $", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = PalestineGreenDark)
                            Text(text = "القيمة التقديرية", fontSize = 11.sp, color = PalestineGreenDark)
                        }
                    }
                }
            }

            items(aidRecords, key = { it.aidRecordID }) { record ->
                val aidTypeName = aidTypes.find { it.aidTypeID == record.aidTypeID }?.aidTypeName
                    ?: "مساعدة إنسانية #${record.aidTypeID}"
                val projectName = projects.find { it.projectID == record.projectID }?.projectName
                    ?: "مشروع إنساني رقم #${record.projectID}"

                AidRecordCard(
                    record = record,
                    aidTypeName = aidTypeName,
                    projectName = projectName
                )
            }
        }
    }
}

@Composable
fun AidRecordCard(
    record: AidRecordEntity,
    aidTypeName: String,
    projectName: String
) {
    val isDelivered = record.recipientStatus.contains("تسليم") || record.recipientStatus.contains("مستلم")
    val statusBg = if (isDelivered) Color(0xFFD1FAE5) else Color(0xFFFEF3C7)
    val statusTextColor = if (isDelivered) Color(0xFF065F46) else Color(0xFF92400E)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (isDelivered) PalestineGreenContainer else Color(0xFFFEF3C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isDelivered) Icons.Default.CheckCircle else Icons.Default.Schedule,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = if (isDelivered) PalestineGreen else Color(0xFFD97706)
                        )
                    }

                    Column {
                        Text(
                            text = aidTypeName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = projectName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = statusBg
                ) {
                    Text(
                        text = record.recipientStatus,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusTextColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = SlateBorder)
            Spacer(modifier = Modifier.height(10.dp))

            // تفاصيل الاستلام
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                DetailMini(label = "تاريخ الصرف/الترشيح", value = record.aidDate)
                if (!record.deliveryDate.isNullOrBlank()) {
                    DetailMini(label = "تاريخ التسليم الفعلي", value = record.deliveryDate!!)
                }
                DetailMini(label = "آلية الترشيح", value = record.nominationMechanism)
            }

            if (!record.notes.isNullOrBlank() || record.aidValue > 0.0) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (record.aidValue > 0.0) {
                        Text(
                            text = "القيمة: ${record.aidValue} $",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = PalestineGreen
                        )
                    }
                    if (!record.notes.isNullOrBlank()) {
                        Text(
                            text = record.notes!!,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DetailMini(label: String, value: String) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = SlateTextMuted, fontSize = 10.sp)
        Text(text = value, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = SlateTextPrimary)
    }
}

/**
 * ترويسة بطاقة القسم مع شارة توضيحية
 */
@Composable
fun SectionHeaderWithBadge(
    title: String,
    icon: ImageVector,
    badgeText: String? = null,
    badgeColor: Color = PalestineGreen
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PalestineGreenContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    modifier = Modifier.size(19.dp),
                    tint = PalestineGreen
                )
            }

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (!badgeText.isNullOrBlank()) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = badgeColor.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(1.dp, badgeColor.copy(alpha = 0.25f))
            ) {
                Text(
                    text = badgeText,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = badgeColor,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * سطر عرض تفصيلي مع أيقونة وحماية من الالتفاف النصي المشوه
 */
@Composable
fun DetailFieldWithIcon(
    icon: ImageVector,
    label: String,
    value: String,
    iconTint: Color = PalestineGreen,
    badgeColor: Color? = null,
    textColor: Color? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(0.48f)
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(14.dp)
                )
            }

            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (badgeColor != null) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = badgeColor.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(0.8.dp, badgeColor.copy(alpha = 0.3f))
            ) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.bodySmall,
                    color = textColor ?: badgeColor,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    maxLines = 1,
                    softWrap = false,
                    overflow = TextOverflow.Ellipsis
                )
            }
        } else {
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                color = textColor ?: MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.52f),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * بطاقة قسم التفاصيل (ترقية إلى ElevatedCard)
 */
@Composable
fun SectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(PalestineGreenContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = PalestineGreen
                    )
                }

                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = SlateBorder)
            Spacer(modifier = Modifier.height(10.dp))

            content()
        }
    }
}

/**
 * سطر عرض تفصيل واحد
 */
@Composable
fun DetailField(
    label: String,
    value: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(0.42f),
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(0.58f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}
