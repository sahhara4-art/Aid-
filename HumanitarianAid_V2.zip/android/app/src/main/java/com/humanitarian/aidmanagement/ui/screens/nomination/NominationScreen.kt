package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.LocalityQuota
import com.humanitarian.aidmanagement.engine.NominationCandidate
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NominationScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToManualSelection: (aidTypeId: Int, projectId: Long) -> Unit,
    onNavigateToResults: () -> Unit
) {
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val projects by repository.getActiveProjects().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())

    // اختيار تصنيفات متعددة
    val selectedAidTypeIds = remember { mutableStateListOf<Int>(1) } // الافتراضي: غذائي
    var exclusionMode by remember { mutableStateOf("DAYS") } // "DAYS" أو "DATE"
    var exclusionDaysText by remember { mutableStateOf("30") } // أيام الاستثناء
    var exclusionDateText by remember { mutableStateOf("2024-12-01") } // تاريخ الاستثناء

    // شروط ومعايير الترشيح المخصصة
    var requireChildren by remember { mutableStateOf(false) }
    var selectedChildAge by remember { mutableStateOf(5) }
    var selectedShelter by remember { mutableStateOf("الكل") }
    var selectedWorks by remember { mutableStateOf("الكل") }
    var selectedDamage by remember { mutableStateOf("الكل") }
    var selectedMinMembers by remember { mutableStateOf(1) }

    var selectedProjectId by remember { mutableStateOf(1L) }
    var selectedLocalityId by remember { mutableStateOf(0) } // 0 = كل المحليات
    var requiredCountText by remember { mutableStateOf("100") }

    var isProcessing by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var quotasDialogList by remember { mutableStateOf<List<LocalityQuota>?>(null) }
    val scope = rememberCoroutineScope()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "ترشيح المساعدات والشروط المخصصة",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                "فحص الاستثناء، معايير الأهلية، وتوزيع الحصص",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // 1. بطاقة تصنيفات المساعدات المفحوصة والمستثناة
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "تصنيفات المساعدات المفحوصة والمستثناة",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "تم تحديد (${selectedAidTypeIds.size} من ${aidTypes.size}) نوعاً",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                TextButton(
                                    onClick = {
                                        selectedAidTypeIds.clear()
                                        selectedAidTypeIds.addAll(aidTypes.map { it.aidTypeID })
                                    }
                                ) {
                                    Text("تحديد الكل", style = MaterialTheme.typography.labelSmall)
                                }
                                TextButton(
                                    onClick = {
                                        selectedAidTypeIds.clear()
                                        if (aidTypes.isNotEmpty()) selectedAidTypeIds.add(aidTypes.first().aidTypeID)
                                    }
                                ) {
                                    Text("إعادة ضبط", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }

                        // تصنيفات المساعدات عبر FlowRow لالتفاف متجاوب تام
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            aidTypes.forEach { aid ->
                                val isSelected = selectedAidTypeIds.contains(aid.aidTypeID)
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        if (isSelected) {
                                            if (selectedAidTypeIds.size > 1) {
                                                selectedAidTypeIds.remove(aid.aidTypeID)
                                            }
                                        } else {
                                            selectedAidTypeIds.add(aid.aidTypeID)
                                        }
                                    },
                                    leadingIcon = {
                                        if (isSelected) {
                                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        }
                                    },
                                    label = { Text(aid.aidTypeName, style = MaterialTheme.typography.bodySmall) },
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        // تحديد مدة وطريقة الاستثناء
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "طريقة الاستثناء والحد الزمني:",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                FilterChip(
                                    selected = exclusionMode == "DAYS",
                                    onClick = { exclusionMode = "DAYS" },
                                    label = { Text("بالأيام السابقة") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                FilterChip(
                                    selected = exclusionMode == "DATE",
                                    onClick = { exclusionMode = "DATE" },
                                    label = { Text("بتاريخ مخصص") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }

                            if (exclusionMode == "DAYS") {
                                OutlinedTextField(
                                    value = exclusionDaysText,
                                    onValueChange = { exclusionDaysText = it },
                                    label = { Text("عدد أيام الاستثناء") },
                                    supportingText = { Text("استبعاد من استلم في آخر ${exclusionDaysText.toIntOrNull() ?: 30} يوماً") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true
                                )

                                Text(
                                    text = "فترات استثناء سريعة:",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )

                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val periods = listOf(15, 30, 45, 60, 90, 180)
                                    items(periods) { days ->
                                        FilterChip(
                                            selected = exclusionDaysText == days.toString(),
                                            onClick = { exclusionDaysText = days.toString() },
                                            label = { Text("$days يوم", style = MaterialTheme.typography.labelSmall) },
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                    }
                                }
                            } else {
                                OutlinedTextField(
                                    value = exclusionDateText,
                                    onValueChange = { exclusionDateText = it },
                                    label = { Text("تاريخ الاستثناء (YYYY-MM-DD)") },
                                    supportingText = { Text("استبعاد أي أسرة استلمت في أو بعد $exclusionDateText", color = MaterialTheme.colorScheme.error) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true
                                )
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        // شروط الترشيح المخصصة
                        Text(
                            text = "شروط ومعايير الأهلية المخصصة:",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // 1. اعتماد التنمية
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF10B981).copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "اعتماد التنمية الاجتماعية: معتمد",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color(0xFF065F46)
                                )
                                Text(
                                    text = "إلزامي ودائم 🔒",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF047857)
                                )
                            }
                        }

                        // 2. شرط الأطفال
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "اشتراط وجود أطفال بالأسرة:",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    FilterChip(
                                        selected = requireChildren,
                                        onClick = { requireChildren = !requireChildren },
                                        label = { Text(if (requireChildren) "مفعل" else "غير مشروط") },
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                }

                                if (requireChildren) {
                                    Text(
                                        "الحد الأقصى لعمر الطفل:",
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                    LazyRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        items(listOf(2, 5, 10, 18)) { age ->
                                            FilterChip(
                                                selected = selectedChildAge == age,
                                                onClick = { selectedChildAge = age },
                                                label = { Text("حتى $age سنوات") },
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // 3. حالة الإيواء
                        Text("حالة الإيواء:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("الكل", "إيواء داخلي", "إيواء خارجي / مخيمات", "مستضاف").forEach { sh ->
                                FilterChip(
                                    selected = selectedShelter == sh,
                                    onClick = { selectedShelter = sh },
                                    label = { Text(sh) },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }

                        // 4. اعتماد الأشغال
                        Text("اعتماد وزارة الأشغال:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("الكل", "معتمد أشغال", "غير معتمد").forEach { w ->
                                FilterChip(
                                    selected = selectedWorks == w,
                                    onClick = { selectedWorks = w },
                                    label = { Text(w) },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }

                        // 5. حالة الضرر
                        Text("حالة الضرر المسجل:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf("الكل", "أضرار كلية", "أضرار جزئية بليغة", "أضرار جزئية").forEach { d ->
                                FilterChip(
                                    selected = selectedDamage == d,
                                    onClick = { selectedDamage = d },
                                    label = { Text(d) },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }

                        // 6. الحد الأدنى لأفراد الأسرة
                        Text("الحد الأدنى لأفراد الأسرة:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(listOf(1, 4, 6, 8)) { m ->
                                FilterChip(
                                    selected = selectedMinMembers == m,
                                    onClick = { selectedMinMembers = m },
                                    label = { Text(if (m == 1) "الكل (1+)" else "$m+ أفراد") },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))

                        // اختيار المشروع والعدد المطلوب
                        OutlinedTextField(
                            value = projects.find { it.projectID == selectedProjectId }?.projectName ?: "مشروع الإغاثة العاجلة وتوزيع الطرود",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("المشروع الإغاثي المعتمد") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = requiredCountText,
                            onValueChange = { requiredCountText = it },
                            label = { Text("العدد المطلوب ترشيحه (حصص)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        // نطاق المحليات
                        Text("نطاق التوزيع الجغرافي:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                FilterChip(
                                    selected = selectedLocalityId == 0,
                                    onClick = { selectedLocalityId = 0 },
                                    label = { Text("جميع المحليات بنسب التوزيع") },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                            items(localities) { loc ->
                                FilterChip(
                                    selected = selectedLocalityId == loc.LocalityID,
                                    onClick = { selectedLocalityId = loc.LocalityID },
                                    label = { Text(loc.LocalityName) },
                                    shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }
                    }
                }

                // بطاقة ملخص القواعد المطبقة
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "ملخص القواعد المطبقة على الترشيح:",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text("• استبعاد فوري لأي أسرة استلمت أحد التصنيفات المحددة خلال فترة الاستثناء.", style = MaterialTheme.typography.bodySmall)
                        Text("• اعتماد التنمية = معتمد، والأولوية للأسر الأكبر عدداً وذوي الأضرار البليغة.", style = MaterialTheme.typography.bodySmall)
                    }
                }

                if (statusMessage != null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = statusMessage ?: "",
                            color = MaterialTheme.colorScheme.primary,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                // أزرار العمليات والتنفيذ
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // زر تنفيذ الترشيح الآلي الرئيسي
                    Button(
                        onClick = {
                            val total = requiredCountText.toIntOrNull() ?: 100
                            scope.launch {
                                isProcessing = true
                                statusMessage = "جاري تشغيل محرك الترشيح وفحص الاستثناءات لـ ${selectedAidTypeIds.size} تصنيفات..."
                                val criteria = com.humanitarian.aidmanagement.engine.NominationCriteria(
                                    developmentApprovalRequired = true,
                                    requireChildren = requireChildren,
                                    maxChildAge = if (requireChildren) selectedChildAge else null,
                                    shelterStatus = if (selectedShelter == "الكل") null else selectedShelter,
                                    worksApproval = if (selectedWorks == "الكل") null else selectedWorks,
                                    damageType = if (selectedDamage == "الكل") null else selectedDamage,
                                    minFamilyMembers = selectedMinMembers,
                                    exclusionMode = exclusionMode,
                                    exclusionDays = exclusionDaysText.toIntOrNull() ?: 30,
                                    exclusionDateCutoff = exclusionDateText,
                                    aidTypeIds = selectedAidTypeIds.toList()
                                )
                                val candidates = repository.runNominationWithCriteria(
                                    localityId = selectedLocalityId,
                                    criteria = criteria,
                                    projectId = selectedProjectId,
                                    requiredCount = total
                                )
                                isProcessing = false
                                statusMessage = "تم ترشيح ${candidates.size} أسرة مستحقة وفقاً للشروط المحددة وتم ترحيلهم لشاشة الاعتماد."
                                onNavigateToResults()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                        } else {
                            Icon(Icons.Default.AutoMode, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تنفيذ الترشيح والترحيل للاعتماد ($requiredCountText حصة)", fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // زر عرض نسب المحليات
                        OutlinedButton(
                            onClick = {
                                val total = requiredCountText.toIntOrNull() ?: 100
                                scope.launch {
                                    val quotas = repository.calculateQuotas(total)
                                    quotasDialogList = quotas
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.PieChart, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("حصص المحليات", style = MaterialTheme.typography.bodySmall)
                        }

                        // زر ترشيح يدوي
                        Button(
                            onClick = {
                                val primaryAidId = selectedAidTypeIds.firstOrNull() ?: 1
                                onNavigateToManualSelection(primaryAidId, selectedProjectId)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                        ) {
                            Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ترشيح يدوي", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    // زر عرض قائمة المرشحين الحالية
                    OutlinedButton(
                        onClick = onNavigateToResults,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.FormatListNumbered, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("عرض نتائج الترشيح والترحيل")
                    }

                    // زر مسح الاختيارات
                    TextButton(
                        onClick = {
                            scope.launch {
                                val primaryAidId = selectedAidTypeIds.firstOrNull() ?: 1
                                repository.clearManualSelections(primaryAidId, selectedProjectId)
                                statusMessage = "تم مسح الاختيارات المؤقتة بنجاح"
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("مسح الاختيارات المؤقتة", color = MaterialTheme.colorScheme.error)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }

        // نافذة عرض حصص المحليات بنظام أكبر الكسور
        if (quotasDialogList != null) {
            val total = requiredCountText.toIntOrNull() ?: 100
            AlertDialog(
                onDismissRequest = { quotasDialogList = null },
                title = {
                    Text("توزيع الحصص على المحليات (المجموع: $total)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "تم حساب الحصص بخوارزمية تقريب الكسور لضمان تطابق المجموع بدقة:",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        quotasDialogList!!.forEach { q ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${q.localityName} (${q.percentage}%)", style = MaterialTheme.typography.bodyMedium)
                                Text("${q.allocatedCount} أسرة", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { quotasDialogList = null },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("حسناً")
                    }
                }
            )
        }
    }
}
