package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.LocalityQuota
import com.humanitarian.aidmanagement.engine.NominationCandidate
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NominationScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToManualSelection: (aidTypeId: Int, projectId: Long) -> Unit,
    onNavigateToResults: () -> Unit
) {
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())
    val projects by repository.getActiveProjects().collectAsState(initial = emptyList())
    val localities by repository.getLocalities().collectAsState(initial = emptyList())

    // اختيار تصنيفات متعددة في نفس الوقت
    val selectedAidTypeIds = remember { mutableStateListOf<Int>(1) } // القيمة الافتراضية: غذائي
    var exclusionMode by remember { mutableStateOf("DAYS") } // "DAYS" أو "DATE"
    var exclusionDaysText by remember { mutableStateOf("30") } // فترة الاستثناء المحددة بالأيام
    var exclusionDateText by remember { mutableStateOf("2024-12-01") } // تاريخ الاستثناء المحدد يدوياً (YYYY-MM-DD)

    // شروط ومعايير الترشيح المخصصة كما طلب المستخدم
    var requireChildren by remember { mutableStateOf(false) }
    var selectedChildAge by remember { mutableStateOf(5) }
    var selectedShelter by remember { mutableStateOf("الكل") }
    var selectedWorks by remember { mutableStateOf("الكل") }
    var selectedDamage by remember { mutableStateOf("الكل") }
    var selectedMinMembers by remember { mutableStateOf(1) }

    var selectedProjectId by remember { mutableStateOf(1L) }
    var description by remember { mutableStateOf("توزيع حصص طارئة للأسر المتضررة في مراكز الإيواء") }
    var aidDate by remember { mutableStateOf("2025-02-25") }
    var selectedLocalityId by remember { mutableStateOf(0) } // 0 يعني كل المحليات
    var requiredCountText by remember { mutableStateOf("100") }

    var isProcessing by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var quotasDialogList by remember { mutableStateOf<List<LocalityQuota>?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ترشيح المساعدات والشروط المخصصة", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // بطاقة معايير الترشيح والتصنيفات المتعددة
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تصنيفات المساعدات المفحوصة والمستثناة (${selectedAidTypeIds.size} محدد)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            TextButton(
                                onClick = {
                                    selectedAidTypeIds.clear()
                                    selectedAidTypeIds.addAll(aidTypes.map { it.aidTypeID })
                                }
                            ) {
                                Text("تحديد الكل", style = MaterialTheme.typography.labelSmall)
                            }
                            TextButton(
                                onClick = {
                                    selectedAidTypeIds.clear()
                                    if (aidTypes.isNotEmpty()) selectedAidTypeIds.add(aidTypes.first().aidTypeID)
                                }
                            ) {
                                Text("إعادة ضبط", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    // اختيار تصنيفات متعددة عبر FlowRow
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        aidTypes.forEach { aid ->
                            val isSelected = selectedAidTypeIds.contains(aid.aidTypeID)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    if (isSelected) {
                                        if (selectedAidTypeIds.size > 1) {
                                            selectedAidTypeIds.remove(aid.aidTypeID)
                                        }
                                    } else {
                                        selectedAidTypeIds.add(aid.aidTypeID)
                                    }
                                },
                                leadingIcon = {
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                },
                                label = { Text(aid.aidTypeName, style = MaterialTheme.typography.bodySmall) }
                            )
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.surfaceVariant)

                    // تحديد مدة وطريقة الاستثناء (بالأيام أو بتاريخ يكتبه بنفسه)
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "مدة وطريقة الاستثناء:",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(
                                    selected = exclusionMode == "DAYS",
                                    onClick = { exclusionMode = "DAYS" },
                                    label = { Text("بالأيام") }
                                )
                                FilterChip(
                                    selected = exclusionMode == "DATE",
                                    onClick = { exclusionMode = "DATE" },
                                    label = { Text("بتاريخ أكتبه بنفسي") }
                                )
                            }
                        }

                        if (exclusionMode == "DAYS") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = exclusionDaysText,
                                    onValueChange = { exclusionDaysText = it },
                                    label = { Text("عدد الأيام") },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    singleLine = true
                                )
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                                    modifier = Modifier.padding(top = 6.dp)
                                ) {
                                    Text(
                                        text = "استبعاد من استلم في آخر ${exclusionDaysText.toIntOrNull() ?: 30} يوماً",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                                    )
                                }
                            }
                            // أزرار سريعة
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(15, 30, 45, 60, 90, 180).forEach { days ->
                                    FilterChip(
                                        selected = exclusionDaysText == days.toString(),
                                        onClick = { exclusionDaysText = days.toString() },
                                        label = { Text("$days يوم", style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        } else {
                            OutlinedTextField(
                                value = exclusionDateText,
                                onValueChange = { exclusionDateText = it },
                                label = { Text("تاريخ الاستثناء (YYYY-MM-DD)") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                            Text(
                                text = "سيتم استبعاد أي أسرة استلمت أي تصنيف محدد في أو بعد تاريخ $exclusionDateText.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.surfaceVariant)

                    // شروط الترشيح المخصصة
                    Text("شروط الترشيح المخصصة:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                    // 1. اعتماد التنمية: دائم
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF10B981).copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("اعتماد التنمية الاجتماعية: معتمد", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF065F46))
                            Text("دائم وإلزامي 🔒", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = Color(0xFF047857))
                        }
                    }

                    // 2. شرط الأطفال وعمر الطفل
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("اشتراط وجود أطفال:", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                FilterChip(
                                    selected = requireChildren,
                                    onClick = { requireChildren = !requireChildren },
                                    label = { Text(if (requireChildren) "مفعل (اشتراط أطفال)" else "غير مفعل (لا يشترط)") }
                                )
                            }
                            if (requireChildren) {
                                Text("تحديد الحد الأقصى لعمر الطفل:", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf(2, 5, 10, 18).forEach { age ->
                                        FilterChip(
                                            selected = selectedChildAge == age,
                                            onClick = { selectedChildAge = age },
                                            label = { Text("حتى $age سنوات") }
                                        )
                                    }
                                }
                            } else {
                                Text("• ما اخترت عمر الابن: لا يشكل الأطفال شرطاً (يشمل كل الأسر).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            }
                        }
                    }

                    // 3. الإيواء
                    Text("حالة الإيواء:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("الكل", "إيواء داخلي", "إيواء خارجي / مخيمات", "مستضاف").forEach { sh ->
                            FilterChip(
                                selected = selectedShelter == sh,
                                onClick = { selectedShelter = sh },
                                label = { Text(sh) }
                            )
                        }
                    }

                    // 4. اعتماد الأشغال
                    Text("اعتماد الأشغال:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("الكل", "معتمد أشغال", "غير معتمد").forEach { w ->
                            FilterChip(
                                selected = selectedWorks == w,
                                onClick = { selectedWorks = w },
                                label = { Text(w) }
                            )
                        }
                    }

                    // 5. حالة الضرر
                    Text("حالة الضرر:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("الكل", "أضرار كلية", "أضرار جزئية بليغة", "أضرار جزئية").forEach { d ->
                            FilterChip(
                                selected = selectedDamage == d,
                                onClick = { selectedDamage = d },
                                label = { Text(d) }
                            )
                        }
                    }

                    // 6. عدد أفراد الأسرة
                    Text("الحد الأدنى لعدد أفراد الأسرة:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1, 4, 6, 8).forEach { m ->
                            FilterChip(
                                selected = selectedMinMembers == m,
                                onClick = { selectedMinMembers = m },
                                label = { Text(if (m == 1) "الكل (1+)" else "$m+ أفراد") }
                            )
                        }
                    }

                    Divider(color = MaterialTheme.colorScheme.surfaceVariant)

                    // اختيار المشروع
                    OutlinedTextField(
                        value = projects.find { it.projectID == selectedProjectId }?.projectName ?: "مشروع الإغاثة العاجلة",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("المشروع الإغاثي") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // العدد المطلوب
                    OutlinedTextField(
                        value = requiredCountText,
                        onValueChange = { requiredCountText = it },
                        label = { Text("العدد المطلوب ترشيحه") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // نطاق المحليات
                    Text("نطاق التوزيع:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedLocalityId == 0,
                            onClick = { selectedLocalityId = 0 },
                            label = { Text("جميع المحليات بنسب التوزيع") }
                        )
                        localities.take(3).forEach { loc ->
                            FilterChip(
                                selected = selectedLocalityId == loc.LocalityID,
                                onClick = { selectedLocalityId = loc.LocalityID },
                                label = { Text(loc.LocalityName) }
                            )
                        }
                    }
                }
            }

            // بطاقة الشروط المطبقة تلقائياً
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "قواعد الاستثناء والترشيح المطبقة:",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text("✓ اعتماد التنمية = معتمد  •  حالة الإقامة = مقيم  •  إيواء داخلي", style = MaterialTheme.typography.bodySmall)
                    Text("✓ فحص جميع التصنيفات المختارة (${selectedAidTypeIds.size} تصنيفاً)", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    Text("✓ استثناء أي أسرة استلمت أياً من هذه التصنيفات خلال آخر ${exclusionDaysText.toIntOrNull() ?: 30} يوماً", style = MaterialTheme.typography.bodySmall, color = Color(0xFFEF4444))
                    Text("✓ الأولوية لعدد أفراد الأسرة الأكبر ووجود أطفال", style = MaterialTheme.typography.bodySmall)
                }
            }

            if (statusMessage != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = statusMessage ?: "",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // أزرار الترشيح والتنفيذ
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // 1. زر "عرض نسب وحصص المحليات"
                OutlinedButton(
                    onClick = {
                        val total = requiredCountText.toIntOrNull() ?: 100
                        scope.launch {
                            val quotas = repository.calculateQuotas(total)
                            quotasDialogList = quotas
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.PieChart, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("عرض نسب وحصص المحليات")
                }

                // 2. زر "ترشيح يدوي"
                Button(
                    onClick = {
                        val primaryAidId = selectedAidTypeIds.firstOrNull() ?: 1
                        onNavigateToManualSelection(primaryAidId, selectedProjectId)
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Icon(Icons.Default.TouchApp, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ترشيح يدوي (تحديد أسر محددة)")
                }

                // 3. زر "ترشيح آلي مع الاستثناء المتعدد والشروط المخصصة"
                Button(
                    onClick = {
                        val total = requiredCountText.toIntOrNull() ?: 100
                        scope.launch {
                            isProcessing = true
                            statusMessage = "جاري تشغيل محرك الترشيح وفحص الاستثناءات لـ ${selectedAidTypeIds.size} تصنيفات..."
                            val criteria = com.humanitarian.aidmanagement.engine.NominationCriteria(
                                developmentApprovalRequired = true,
                                requireChildren = requireChildren,
                                maxChildAge = if (requireChildren) selectedChildAge else null,
                                shelterStatus = if (selectedShelter == "الكل") null else selectedShelter,
                                worksApproval = if (selectedWorks == "الكل") null else selectedWorks,
                                damageType = if (selectedDamage == "الكل") null else selectedDamage,
                                minFamilyMembers = selectedMinMembers,
                                exclusionMode = exclusionMode,
                                exclusionDays = exclusionDaysText.toIntOrNull() ?: 30,
                                exclusionDateCutoff = exclusionDateText,
                                aidTypeIds = selectedAidTypeIds.toList()
                            )
                            val candidates = repository.runNominationWithCriteria(
                                localityId = selectedLocalityId,
                                criteria = criteria,
                                projectId = selectedProjectId,
                                requiredCount = total
                            )
                            isProcessing = false
                            statusMessage = "تم ترشيح ${candidates.size} أسرة مستحقة وفقاً للشروط المحددة وتم ترحيلهم لشاشة الاعتماد."
                            onNavigateToResults()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                    } else {
                        Icon(Icons.Default.AutoMode, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تنفيذ الترشيح والترحيل لشاشة الاعتماد (إكمال لـ $requiredCountText)")
                    }
                }

                // 4. زر "عرض المرشحين والنتائج"
                OutlinedButton(
                    onClick = onNavigateToResults,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.FormatListNumbered, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("عرض قائمة المرشحين الحالية")
                }

                // 5. زر "مسح الاختيارات"
                TextButton(
                    onClick = {
                        scope.launch {
                            val primaryAidId = selectedAidTypeIds.firstOrNull() ?: 1
                            repository.clearManualSelections(primaryAidId, selectedProjectId)
                            statusMessage = "تم مسح الاختيارات المؤقتة بنجاح"
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مسح الاختيارات المؤقتة", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    // نافذة عرض حصص المحليات بنظام أكبر الكسور
    if (quotasDialogList != null) {
        val total = requiredCountText.toIntOrNull() ?: 100
        AlertDialog(
            onDismissRequest = { quotasDialogList = null },
            title = {
                Text("توزيع الحصص على المحليات (المجموع: $total)", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "تم حساب الحصص بخوارزمية تقريب الكسور لضمان تطابق المجموع بدقة:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    quotasDialogList!!.forEach { q ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${q.localityName} (${q.percentage}%)", style = MaterialTheme.typography.bodyMedium)
                            Text("${q.allocatedCount} أسرة", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { quotasDialogList = null }) { Text("حسناً") }
            }
        )
    }
}
