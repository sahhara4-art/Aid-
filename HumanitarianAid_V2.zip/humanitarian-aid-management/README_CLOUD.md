# دليل تهيئة النسخ الاحتياطي السحابي عبر Google Drive
## Humanitarian Aid Management System - Cloud Infrastructure Guide

يوثق هذا الدليل الخطوات اللازمة لمدير المشروع لتهيئة مشروع Google Cloud Console وتفعيل واجهة برمجة تطبيقات Google Drive API لربط تطبيق الأندرويد بالنسخ السحابي المشفر.

---

### الخطوة الأولى: استخراج بصمة الشهادة الرقمية (SHA-1 Fingerprint)

لتسجيل تطبيق الأندرويد مع حساب Google والحصول على إذن OAuth 2.0، يلزم توفير بصمة شهادة التوقيع (SHA-1):

#### الخيار 1: باستخدام أمر Gradle (الأسهل والأسرع):
من مجلد المشروع `android` في موجه الأوامر (Terminal):
```bash
./gradlew signingReport
```
ابحث في المخرجات تحت `Variant: debug` عن سطر `SHA1:` وانسخ القيمة (تكون على شكل: `AA:BB:CC:...`).

#### الخيار 2: باستخدام أداة `keytool` القياسية:
```bash
# على نظام Linux أو macOS:
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android

# على نظام Windows (PowerShell):
keytool -list -v -keystore $env:USERPROFILE\.android\debug.keystore -alias androiddebugkey -storepass android -keypass android
```
انسخ قيمة **SHA-1** الظاهرة في شهادة التوقيع.

---

### الخطوة الثانية: إعداد Google Cloud Console

1. افتح متصفحك وسجل الدخول إلى **[Google Cloud Console](https://console.cloud.google.com/)**.
2. أنشئ مشروعاً جديداً باسم: `Humanitarian Aid Management` (أو اختر مشروعك الحالي).
3. من القائمة الجانبية (Navigation Menu)، توجه إلى **APIs & Services** > **Library**.
4. ابحث عن **Google Drive API** واضغط على زر **Enable (تفعيل)**.

---

### الخطوة الثالثة: ضبط شاشة موافقة OAuth (OAuth Consent Screen)

1. من القائمة الجانبية، اذهب إلى **APIs & Services** > **OAuth consent screen**.
2. اختر نوع المستخدم: **External (خارجي)** ثم اضغط **Create**.
3. عبئ البيانات الأساسية:
   - **App name**: `Humanitarian Aid Management`
   - **User support email**: بريدك الإلكتروني كمدير للنظام
   - **Developer contact information**: بريدك الإلكتروني
4. في خطوة **Scopes (الصلاحيات)**:
   - اضغط **Add or Remove Scopes**.
   - اختر: `.../auth/drive.file` (Per-file access - تتيح للتطبيق إنشاء والوصول إلى الملفات التي أنشأها فقط لضمان الخصوصية التامة لحساب المستخدم).
5. في خطوة **Test users (المستخدمون التجريبيون)**:
   - أضف البريد الإلكتروني لحسابك ولأي مستخدمين سيقومون بعمل نسخ احتياطي سحابي.
6. احفظ الإعدادات.

---

### الخطوة الرابعة: إنشاء معرف العميل (OAuth 2.0 Client ID) لتطبيق الأندرويد

1. اذهب إلى **APIs & Services** > **Credentials**.
2. اضغط **+ CREATE CREDENTIALS** في الأعلى واختر **OAuth client ID**.
3. في خانة **Application type**، اختر **Android**.
4. أدخل البيانات التالية بدقة:
   - **Name**: `Android Aid Management Client`
   - **Package name**: 
     ```
     com.humanitarian.aidmanagement
     ```
   - **SHA-1 certificate fingerprint**: 
     الصق بصمة الـ SHA-1 التي استخرجتها في الخطوة الأولى.
5. اضغط **CREATE**.

---

### الخطوة الخامسة: تجربة النسخ الاحتياطي في التطبيق

1. افتح شاشة **"النسخ الاحتياطي واستعادة البيانات"** داخل التطبيق.
2. ستجد قسماً مخصصاً بعنوان **"النسخ السحابي عبر Google Drive"**.
3. اضغط على زر **"تسجيل الدخول بحساب Google"**.
4. بعد الموافقة ومنح الإذن، سيظهر بريدك الإلكتروني وحالة الربط.
5. اضغط **"رفع نسخة احتياطية سحابية الآن"**؛ سيقوم التطبيق بإنشاء مجلد مخصص باسم `HumanitarianAid_Backups` على حسابك في Google Drive ورفع أرشيف قواعد بيانات Room المشفرة تلقائياً.
6. عند الحاجة للاستعادة، اضغط على النسخة المحفوظة سحابياً، وسيتم استبدال قاعدة البيانات تلقائياً مع إعادة تشغيل نظيفة للتطبيق.
