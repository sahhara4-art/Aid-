package com.humanitarian.aidmanagement.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.sync.SyncUiState

@Composable
fun SyncStatusBanner(
    repository: AidRepository,
    onOpenSyncDetails: () -> Unit,
    modifier: Modifier = Modifier
) {
    val syncState by repository.getSyncState().collectAsState()

    AnimatedVisibility(
        visible = !syncState.isOnline || syncState.isSyncing || syncState.pendingCount > 0,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
        modifier = modifier
    ) {
        val backgroundColor = when {
            syncState.isSyncing -> Color(0xFF0284C7) // أزرق للمزامنة الجارية
            !syncState.isOnline -> Color(0xFFD97706) // برتقالي عند انقطاع الإنترنت
            else -> Color(0xFF10B981) // أخضر
        }

        Surface(
            color = backgroundColor,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .clickable { onOpenSyncDetails() }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = when {
                            syncState.isSyncing -> Icons.Default.Refresh
                            !syncState.isOnline -> Icons.Default.Warning
                            else -> Icons.Default.CheckCircle
                        },
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = when {
                                syncState.isSyncing -> "جارٍ التزامن التلقائي مع السحابة..."
                                !syncState.isOnline -> "وضع العمل دون اتصال (Offline Mode)"
                                else -> "متصل بالإنترنت"
                            },
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = when {
                                syncState.isSyncing -> "جارٍ ترحيل ${syncState.pendingCount} عملية من قاعدة Room..."
                                !syncState.isOnline -> "العمل مستمر بالكامل محلياً • ${syncState.pendingCount} عملية بانتظار المزامنة التلقائية فور عودة الشبكة"
                                else -> "${syncState.pendingCount} عمليات بانتظار المزامنة"
                            },
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 10.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.White.copy(alpha = 0.25f)
                ) {
                    Text(
                        text = if (syncState.isSyncing) "تزامن ⚡" else "تفاصيل ⚙️",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}
