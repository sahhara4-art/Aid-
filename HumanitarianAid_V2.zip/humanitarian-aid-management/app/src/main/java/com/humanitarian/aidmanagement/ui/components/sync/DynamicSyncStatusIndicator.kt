package com.humanitarian.aidmanagement.ui.components.sync

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.sync.SyncConnectionStatus
import com.humanitarian.aidmanagement.sync.SyncUiState

private val PalestineGreen = Color(0xFF007A3D)
private val BlueSyncing = Color(0xFF1976D2)
private val AmberOffline = Color(0xFFD97706)
private val RedAlert = Color(0xFFDC2626)

/**
 * DynamicSyncStatusIndicator - مؤشر حالة التزامن الديناميكي اللحظي في شريط التطبيق العلوي (TopAppBar)
 * يعتمد على AnimatedContent للتنقل السلس والفوري بين الحالات: (متصل، يتم التزامن، غير متصل).
 */
@Composable
fun DynamicSyncStatusIndicator(
    syncState: SyncUiState,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {}
) {
    // حركة دوران مستمرة لأيقونة التزامن أثناء التشغيل
    val infiniteTransition = rememberInfiniteTransition(label = "sync_rotation")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = when (syncState.connectionStatus) {
            SyncConnectionStatus.ONLINE -> PalestineGreen.copy(alpha = 0.12f)
            SyncConnectionStatus.SYNCING -> BlueSyncing.copy(alpha = 0.14f)
            SyncConnectionStatus.OFFLINE -> if (syncState.pendingCount > 0) RedAlert.copy(alpha = 0.12f) else AmberOffline.copy(alpha = 0.12f)
        },
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = when (syncState.connectionStatus) {
                SyncConnectionStatus.ONLINE -> PalestineGreen.copy(alpha = 0.4f)
                SyncConnectionStatus.SYNCING -> BlueSyncing.copy(alpha = 0.4f)
                SyncConnectionStatus.OFFLINE -> if (syncState.pendingCount > 0) RedAlert.copy(alpha = 0.4f) else AmberOffline.copy(alpha = 0.4f)
            }
        ),
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() }
    ) {
        AnimatedContent(
            targetState = syncState.connectionStatus,
            transitionSpec = {
                (slideInVertically { height -> height } + fadeIn()) togetherWith
                        (slideOutVertically { height -> -height } + fadeOut())
            },
            label = "sync_status_anim"
        ) { status ->
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                when (status) {
                    SyncConnectionStatus.ONLINE -> {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(PalestineGreen)
                        )
                        Icon(
                            imageVector = Icons.Default.CloudDone,
                            contentDescription = "متصل بالسحابة",
                            tint = PalestineGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "متصل",
                            color = PalestineGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    SyncConnectionStatus.SYNCING -> {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = "جاري التزامن",
                            tint = BlueSyncing,
                            modifier = Modifier
                                .size(14.dp)
                                .rotate(rotationAngle)
                        )
                        Text(
                            text = "تزامن...",
                            color = BlueSyncing,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    SyncConnectionStatus.OFFLINE -> {
                        val tintColor = if (syncState.pendingCount > 0) RedAlert else AmberOffline
                        Icon(
                            imageVector = Icons.Default.CloudOff,
                            contentDescription = "غير متصل",
                            tint = tintColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (syncState.pendingCount > 0) "${syncState.pendingCount} معلق" else "محلي",
                            color = tintColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
