package com.humanitarian.aidmanagement.sync

import org.json.JSONObject
import java.util.UUID

/**
 * SyncDelta - نموذج حركة التزامن الجزئي (Delta Event)
 * يمثل حدثاً تشغيلياً مستقلاً (Event Sourcing) يطرأ على البيانات في هاتف المندوب
 * ويُرفع مباشرة إلى Firebase Realtime Database تحت عقدة المحلية المعنية.
 */
data class SyncDelta(
    val deltaId: String = UUID.randomUUID().toString(),
    val localityId: Int = 0,
    val localityName: String = "",
    val userId: Int = 0,
    val userName: String = "",
    val entityType: String = "",    // "AID_RECORD", "FAMILY", "NOMINATION_SELECTION", "USER"
    val operation: String = "",     // "DELIVER", "UNDO_DELIVERY", "INSERT", "UPDATE", "DELETE"
    val recordId: String = "",      // المعرف الفرعي للسجل الهدف
    val payloadJson: String = "",   // بيانات الحركة بصيغة JSON
    val timestamp: Long = System.currentTimeMillis(),
    val deviceId: String = "",
    val version: Int = 1
) {
    /**
     * تحويل الكائن إلى Map متوافق مع Firebase Realtime Database
     */
    fun toMap(): Map<String, Any?> = mapOf(
        "deltaId" to deltaId,
        "localityId" to localityId,
        "localityName" to localityName,
        "userId" to userId,
        "userName" to userName,
        "entityType" to entityType,
        "operation" to operation,
        "recordId" to recordId,
        "payloadJson" to payloadJson,
        "timestamp" to timestamp,
        "deviceId" to deviceId,
        "version" to version
    )

    companion object {
        /**
         * بناء SyncDelta من Map مستلم من Firebase Realtime Database
         */
        @Suppress("UNCHECKED_CAST")
        fun fromMap(map: Map<String, Any?>): SyncDelta {
            return SyncDelta(
                deltaId = (map["deltaId"] as? String) ?: UUID.randomUUID().toString(),
                localityId = ((map["localityId"] as? Number)?.toInt()) ?: 0,
                localityName = (map["localityName"] as? String) ?: "",
                userId = ((map["userId"] as? Number)?.toInt()) ?: 0,
                userName = (map["userName"] as? String) ?: "",
                entityType = (map["entityType"] as? String) ?: "",
                operation = (map["operation"] as? String) ?: "",
                recordId = (map["recordId"] as? String) ?: "",
                payloadJson = (map["payloadJson"] as? String) ?: "{}",
                timestamp = ((map["timestamp"] as? Number)?.toLong()) ?: System.currentTimeMillis(),
                deviceId = (map["deviceId"] as? String) ?: "",
                version = ((map["version"] as? Number)?.toInt()) ?: 1
            )
        }

        /**
         * قراءة قيم محددة من الـ JSON المخزن في payloadJson بسهولة
         */
        fun parsePayload(payloadJson: String): Map<String, String> {
            val result = mutableMapOf<String, String>()
            if (payloadJson.isBlank()) return result
            try {
                val json = JSONObject(payloadJson)
                val keys = json.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    result[key] = json.optString(key, "")
                }
            } catch (e: Exception) {
                // Ignore parse errors, return best effort
            }
            return result
        }
    }
}
