package com.humanitarian.aidmanagement.ui.screens.families

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.dao.DamageTypeBreakdown
import com.humanitarian.aidmanagement.data.local.dao.LocalityFamilyCount
import com.humanitarian.aidmanagement.data.local.dao.SubAreaFamilyCount
import com.humanitarian.aidmanagement.data.local.dao.WarDamageStats
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.ChildEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

/**
 * حالة واجهة المستخدم لشاشة تفاصيل الأسرة (Family Details UI State)
 */
data class FamilyDetailsUiState(
    val family: FamilyEntity? = null,
    val children: List<ChildEntity> = emptyList(),
    val aidRecords: List<AidRecordEntity> = emptyList(),
    val localities: List<LocalityEntity> = emptyList(),
    val localityName: String = "",
    val isAreaAllowed: Boolean = true,
    val canEdit: Boolean = false,
    val canDelete: Boolean = false,
    val isLoading: Boolean = true,
    val errorMessage: String? = null,

    // الحقول الديناميكية للتجميع والإحصاء الجغرافي
    val selectedLocalityId: Int = 1,
    val selectedSubArea: String = "",
    val availableSubAreas: List<String> = emptyList(),
    val localityFamilyCount: Int = 0,
    val subAreaFamilyCount: Int = 0,
    val warDamageStats: WarDamageStats = WarDamageStats(0, 0, 0, 0, 0),
    val damageDistribution: List<DamageTypeBreakdown> = emptyList(),
    val completelyDestroyedCount: Int = 0,
    val allLocalityFamilyCounts: List<LocalityFamilyCount> = emptyList()
)

/**
 * ViewModel لإدارة منطق وتدفقات بيانات شاشة تفاصيل الأسرة
 * - حساب العمر الديناميكي اللحظي من تاريخ الميلاد (date_of_birth)
 * - تحديث منسدل الشعب والمناطق الفرعية وفق المحلية المختارة
 * - حساب التجميعات والإحصاءات الحية للأسر وأضرار الحرب
 */
class FamilyDetailsViewModel(
    private val repository: AidRepository,
    private val familyId: Long
) : ViewModel() {

    private val _uiState = MutableStateFlow(FamilyDetailsUiState())
    val uiState: StateFlow<FamilyDetailsUiState> = _uiState.asStateFlow()

    init {
        loadFamilyDetails()
        loadLocalitiesAndAggregations()
    }

    /**
     * حساب دقيق وحصري للعمر الحالي ديناميكياً من حقل date_of_birth
     * بصيغة (YYYY-MM-DD أو YYYY/MM/DD) بدون استخدام أي قيمة عمر ثابتة ومخزنة
     * يُرجع null إذا كان تاريخ الميلاد فارغاً أو غير صالح لإخفاء المكون بالكامل
     */
    fun calculateAge(dobString: String?): Int? {
        if (dobString.isNullOrBlank()) return null
        return try {
            val parts = dobString.trim().split("-", "/")
            if (parts.size >= 3) {
                val year = parts[0].toIntOrNull() ?: return null
                val month = parts[1].toIntOrNull() ?: 1
                val day = parts[2].toIntOrNull() ?: 1
                val birthCal = Calendar.getInstance().apply { set(year, month - 1, day) }
                val today = Calendar.getInstance()
                var age = today.get(Calendar.YEAR) - birthCal.get(Calendar.YEAR)
                if (today.get(Calendar.DAY_OF_YEAR) < birthCal.get(Calendar.DAY_OF_YEAR)) {
                    age--
                }
                age.coerceAtLeast(0)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun loadFamilyDetails() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                // مراقبة بيانات الأسرة الحية
                repository.getFamilyById(familyId).collect { family ->
                    if (family != null) {
                        val isAllowed = repository.canUserViewSubArea(family.currentSubArea)
                        val canEdit = repository.canUserEditFamily(family)
                        val canDelete = repository.canUserDeleteFamily(family)

                        _uiState.update { current ->
                            current.copy(
                                family = family,
                                selectedLocalityId = if (current.selectedLocalityId == 1 && family.localityID != 0) family.localityID else current.selectedLocalityId,
                                selectedSubArea = if (current.selectedSubArea.isBlank()) family.currentSubArea else current.selectedSubArea,
                                isAreaAllowed = isAllowed,
                                canEdit = canEdit,
                                canDelete = canDelete,
                                isLoading = false
                            )
                        }

                        // مراقبة الأبناء والتابعين
                        launch {
                            repository.getChildrenByFamily(family.nationalID).collect { childList ->
                                _uiState.update { it.copy(children = childList) }
                            }
                        }

                        // مراقبة سجل المساعدات
                        launch {
                            repository.getAidRecordsForFamily(family.familyID).collect { records ->
                                _uiState.update { it.copy(aidRecords = records) }
                            }
                        }

                        // جلب اسم المحلية
                        launch {
                            val localities = repository.getAllLocalitiesSync()
                            val locName = localities.find { it.LocalityID == family.localityID }?.LocalityName
                                ?: "محلية #${family.localityID}"
                            _uiState.update { it.copy(localityName = locName, localities = localities) }
                        }

                        // تحديث الشعب والإحصائيات الجغرافية
                        refreshDynamicGeoStats(family.localityID, family.currentSubArea)
                    } else {
                        _uiState.update { it.copy(family = null, isLoading = false) }
                    }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, errorMessage = e.message) }
            }
        }
    }

    private fun loadLocalitiesAndAggregations() {
        viewModelScope.launch {
            // مراقبة المحليات وقوائم إجمالي الأسر لكل محلية
            repository.getLocalities().collect { locs ->
                _uiState.update { it.copy(localities = locs) }
            }
        }

        viewModelScope.launch {
            repository.getFamilyCountForEachLocalityFlow().collect { counts ->
                _uiState.update { current ->
                    val currentLocCount = counts.find { it.localityID == current.selectedLocalityId }?.familyCount ?: 0
                    current.copy(
                        allLocalityFamilyCounts = counts,
                        localityFamilyCount = currentLocCount
                    )
                }
            }
        }
    }

    /**
     * تحديث الشعب المتاحة والإحصائيات التجميعية عند تغيير اختيار المحلية
     */
    fun onLocalitySelected(localityId: Int) {
        _uiState.update { it.copy(selectedLocalityId = localityId, selectedSubArea = "") }
        viewModelScope.launch {
            refreshDynamicGeoStats(localityId, "")
        }
    }

    /**
     * تحديث الإحصائيات التجميعية عند اختيار شعبة معينة
     */
    fun onSubAreaSelected(subArea: String) {
        _uiState.update { it.copy(selectedSubArea = subArea) }
        viewModelScope.launch {
            val locId = _uiState.value.selectedLocalityId
            refreshDynamicGeoStats(locId, subArea)
        }
    }

    private suspend fun refreshDynamicGeoStats(localityId: Int, subArea: String) = withContext(Dispatchers.IO) {
        try {
            // 1. جلب الشعب المتاحة حصراً لهذه المحلية
            val subAreas = repository.getSubAreasByLocality(localityId)

            // 2. إحصائيات أسر الشعبة الحالية
            val subAreaCounts = repository.getFamilyCountForEachSubArea(localityId)
            val selectedSubCount = if (subArea.isNotBlank()) {
                subAreaCounts.find { it.subArea == subArea }?.familyCount ?: 0
            } else {
                0
            }

            // 3. عدد أسر المحلية الحالية
            val allLocCounts = repository.getFamilyCountForEachLocality()
            val currentLocCount = allLocCounts.find { it.localityID == localityId }?.familyCount ?: 0

            // 4. أضرار الحرب والمنازل المهدمة كلياً حصراً للنطاق المختار
            val targetSub = if (subArea.isNotBlank()) subArea else null
            val warStats = repository.getWarDamageStatsFiltered(localityId, targetSub)
            val destroyedCount = repository.getCompletelyDestroyedCountFiltered(localityId, targetSub)
            val damageBreakdown = repository.getWarDamageDistributionFiltered(localityId, targetSub)

            _uiState.update { current ->
                current.copy(
                    availableSubAreas = subAreas,
                    subAreaFamilyCount = selectedSubCount,
                    localityFamilyCount = currentLocCount,
                    warDamageStats = warStats,
                    completelyDestroyedCount = destroyedCount,
                    damageDistribution = damageBreakdown
                )
            }
        } catch (e: Exception) {
            // صامت أو توثيق الخطأ
        }
    }

    fun updateFamily(updatedFamily: FamilyEntity, onComplete: (Boolean, String?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.updateFamily(updatedFamily)
                withContext(Dispatchers.Main) {
                    onComplete(true, null)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onComplete(false, e.message)
                }
            }
        }
    }

    fun deleteFamily(onComplete: (Boolean, String?) -> Unit) {
        val currentFam = _uiState.value.family ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.deleteFamily(currentFam)
                withContext(Dispatchers.Main) {
                    onComplete(true, null)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onComplete(false, e.message)
                }
            }
        }
    }

    class Factory(
        private val repository: AidRepository,
        private val familyId: Long
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return FamilyDetailsViewModel(repository, familyId) as T
        }
    }
}
