package com.humanitarian.aidmanagement.sync

import android.content.Context
import android.util.Log
import androidx.work.*
import com.humanitarian.aidmanagement.AidApplication
import com.humanitarian.aidmanagement.data.local.entities.SyncLogEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * FirestoreSyncWorker - عامل التزامن الخلفي المعتمد على WorkManager
 *
 * الميزات:
 * 1. Network Constraints: يشتغل تلقائياً بمجرد توفر اتصال بالإنترنت (NetworkType.CONNECTED).
 * 2. Background Execution: يرفع حركات وبيانات المحليات إلى Google Cloud Firestore حتى لو كان التطبيق مغلقاً.
 * 3. Master Node Alignment: يرفع الحركات كـ FirestoreSyncDelta مع تسجيل هوية المنفذ وصلاحيته لدعم حل النزاعات.
 */
class FirestoreSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val TAG = "FirestoreSyncWorker"
        const val WORK_NAME_PERIODIC = "FirestoreSyncWorker_Periodic"
        const val WORK_NAME_ONETIME = "FirestoreSyncWorker_OneTime"

        /**
         * جدولة المزامنة الدورية الخلفية مع قيود الشبكة
         */
        fun schedulePeriodicSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val periodicRequest = PeriodicWorkRequestBuilder<FirestoreSyncWorker>(
                15, TimeUnit.MINUTES,
                5, TimeUnit.MINUTES
            )
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME_PERIODIC,
                ExistingPeriodicWorkPolicy.KEEP,
                periodicRequest
            )
            Log.i(TAG, "Periodic Firestore sync scheduled with network constraints.")
        }

        /**
         * تشغيل مزامنة فورية بالخلفية بمجرد توفر الشبكة
         */
        fun triggerImmediateSync(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val oneTimeRequest = OneTimeWorkRequestBuilder<FirestoreSyncWorker>()
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                WORK_NAME_ONETIME,
                ExistingWorkPolicy.REPLACE,
                oneTimeRequest
            )
            Log.i(TAG, "Immediate Firestore sync work enqueued.")
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val app = applicationContext as? AidApplication ?: AidApplication.instance
        val database = app.database
        val syncDao = database.syncQueueDao()
        val firestoreSyncManager = FirestoreSyncManager.getInstance(applicationContext)

        val pendingItems = syncDao.getPendingSyncItems()
        if (pendingItems.isEmpty()) {
            Log.d(TAG, "No pending items found in sync_queue.")
            return@withContext Result.success()
        }

        Log.i(TAG, "Starting background Firestore sync for ${pendingItems.size} pending items...")

        val currentUser = app.repository.getCurrentUser()
        val userLocalityId = currentUser?.AllowedLocalityID ?: 0
        val isSuperAdmin = currentUser?.RoleID == 1 || currentUser?.UserName.equals("admin", ignoreCase = true)
        val roleStr = if (isSuperAdmin) "SUPER_ADMIN" else "LOCALITY_SUPERVISOR"
        val userName = currentUser?.fullName ?: currentUser?.UserName ?: "مندوب ميداني"
        val userId = currentUser?.UserID ?: 1

        val localities = database.localityDao().getAllLocalitiesSync()
        val localityName = localities.find { it.LocalityID == userLocalityId }?.LocalityName ?: "المحلية المخصصة"

        var succeeded = 0
        var failed = 0

        for (item in pendingItems) {
            try {
                syncDao.markAsSyncing(item.syncId)

                val delta = FirestoreSyncDelta(
                    deltaId = "sync_${item.syncId}_${item.createdAt}",
                    localityId = userLocalityId,
                    localityName = localityName,
                    userId = userId,
                    userName = userName,
                    userRole = roleStr,
                    entityType = item.entityType,
                    operation = item.operation,
                    recordId = item.recordId,
                    payloadJson = item.payloadJson,
                    clientTimestamp = item.createdAt,
                    deviceId = firestoreSyncManager.deviceId,
                    isMasterAdminOverride = isSuperAdmin
                )

                val uploadSuccess = firestoreSyncManager.pushDelta(delta)
                if (uploadSuccess) {
                    syncDao.markAsSynced(item.syncId)
                    succeeded++
                    Log.d(TAG, "Uploaded delta ${item.syncId} (${item.entityType}:${item.operation}) to Firestore.")
                } else {
                    syncDao.markAsFailed(item.syncId, "فشل الرفع إلى Google Cloud Firestore")
                    failed++
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in FirestoreSyncWorker item ${item.syncId}: ${e.message}", e)
                syncDao.markAsFailed(item.syncId, e.message ?: "خطأ أثناء رفع التزامن")
                failed++
            }
        }

        if (succeeded > 0) {
            syncDao.clearSynced()
        }

        val status = if (failed == 0) "SUCCESS" else if (succeeded > 0) "PARTIAL" else "FAILED"
        val summary = "تم رفع $succeeded حركة إلى Google Cloud Firestore Master Node بنجاح، وفشل $failed حركات."
        val log = SyncLogEntity(
            syncType = "FIRESTORE_MASTER_BACKGROUND",
            itemsProcessed = pendingItems.size,
            itemsSucceeded = succeeded,
            itemsFailed = failed,
            status = status,
            summary = summary
        )
        database.syncQueueDao().insertSyncLog(log)

        if (failed > 0 && succeeded == 0) {
            Result.retry()
        } else {
            Result.success()
        }
    }
}
