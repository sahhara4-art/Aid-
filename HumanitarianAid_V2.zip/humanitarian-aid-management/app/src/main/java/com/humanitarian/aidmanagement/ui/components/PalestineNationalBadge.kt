package com.humanitarian.aidmanagement.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.ui.theme.*

/**
 * بصمة فلسطين الوطنية - مكون شريطي أنيق يعبر عن الهوية الوطنية الفلسطينية
 * يتضمن ألوان العلم الفلسطيني الأربعة (الأسود، الأبيض، الأخضر، المثلث الأحمر)
 */
@Composable
fun PalestineNationalBanner(
    modifier: Modifier = Modifier,
    subtitle: String = "الهيئة الوطنية لإدارة وتوزيع المساعدات الإنسانية • قطاع غزة"
) {
    // تم حذف الشعار بالكامل بناءً على طلب المستخدم لضمان عدم تغطية البيانات في الشاشات
}
