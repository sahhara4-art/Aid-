package com.humanitarian.aidmanagement.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidGraphicsColor
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.repository.AidTypeDistributionStat
import com.humanitarian.aidmanagement.data.repository.LocalityDistributionStat
import com.humanitarian.aidmanagement.data.repository.SubAreaBenefitRatioStat
import org.apache.poi.ss.usermodel.BorderStyle
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.CellStyle
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.HorizontalAlignment
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.ss.usermodel.Sheet
import org.apache.poi.ss.usermodel.VerticalAlignment
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.util.CellRangeAddress
import org.apache.poi.xssf.usermodel.XSSFCellStyle
import org.apache.poi.xssf.usermodel.XSSFColor
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * بيانات سجل مساعدة مع تفاصيل الأسرة المستفيدة
 */
data class AidRecordWithBeneficiary(
    val record: AidRecordEntity,
    val family: FamilyEntity?
)

/**
 * بيانات تقرير المشروع والمستفيدين
 */
data class ProjectReportData(
    val project: ProjectEntity,
    val aidTypeName: String,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String,
    val notes: String? = null
)

/**
 * بيانات تقرير المحلية والشعب التابعة
 */
data class LocalityReportData(
    val localityName: String,
    val subAreas: List<SubAreaBenefitRatioStat>,
    val totalFamilies: Int,
    val totalBeneficiaries: Int,
    val totalDelivered: Int,
    val dateGenerated: String,
    val supervisorName: String
)

/**
 * بيانات تقرير التوزيع الشامل حسب الفترة الزمنية
 */
data class ComprehensivePeriodReportData(
    val fromDate: String,
    val toDate: String,
    val totalDeliveries: Int,
    val localityStats: List<LocalityDistributionStat>,
    val aidTypeStats: List<AidTypeDistributionStat>,
    val records: List<AidRecordWithBeneficiary>,
    val dateGenerated: String,
    val supervisorName: String
)

/**
 * فئة احترافية متكاملة لتوليد تقارير A4 PDF رسمية وتصدير ملفات Excel (.xlsx) عبر Apache POI
 */
class ProfessionalReportExporter(private val context: Context) {

    // أبعاد صفحة A4 القياسية بنظام النقاط (Standard A4 Dimensions at 72 DPI)
    private val a4Width = 595
    private val a4Height = 842
    private val marginH = 28f
    private val contentWidth = a4Width - (marginH * 2) // 539 pt

    // =========================================================================
    // 1. توليد تقرير المشروع ومستفيديه بصيغة A4 PDF
    // =========================================================================
    fun generateProjectBeneficiariesPdf(data: ProjectReportData): File {
        val pdfDocument = PdfDocument()

        val deliveredCount = data.records.count { it.record.recipientStatus.contains("مستلم") || it.record.recipientStatus.contains("تم التسليم") }
        val pendingCount = data.records.size - deliveredCount
        val ratePercent = if (data.records.isNotEmpty()) (deliveredCount * 100 / data.records.size) else 0

        val itemsPerPage = 22
        val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = "كشف مستفيدي المشروع الإنساني المعتمد",
                subtitle = "المشروع: ${data.project.projectName} (${data.project.projectNumber})",
                periodOrFilter = "الممول: ${data.project.fundingInstitution} | نوع المعونة: ${data.aidTypeName}",
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem("إجمالي الكشف", "${data.records.size}", "مستفيد", android.graphics.Color.rgb(13, 148, 136)),
                        KpiItem("تم التسليم", "$deliveredCount", "طرد", android.graphics.Color.rgb(16, 185, 129)),
                        KpiItem("بانتظار الصرف", "$pendingCount", "مرشح", android.graphics.Color.rgb(245, 158, 11)),
                        KpiItem("نسبة الإنجاز", "$ratePercent%", "مكتمل", android.graphics.Color.rgb(2, 132, 199))
                    )
                )
            } else {
                currentY += 8f
            }

            // رسم جدول المستفيدين
            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
            val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

            currentY = drawProjectBeneficiaryTable(
                canvas = canvas,
                records = pageRecords,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            // التذييل والتواقيع
            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, "Project_${data.project.projectNumber}_$timeStamp.pdf")

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    // =========================================================================
    // 2. توليد تقرير المحلية والشعب التابعة بصيغة A4 PDF
    // =========================================================================
    fun generateLocalitySubAreasPdf(data: LocalityReportData): File {
        val pdfDocument = PdfDocument()

        val itemsPerPage = 20
        val totalPages = if (data.subAreas.isEmpty()) 1 else ((data.subAreas.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = "تقرير التغطية الميدانية ونسب الاستفادة للمحلية",
                subtitle = "المحلية المعتمدة: ${data.localityName}",
                periodOrFilter = "حساب الاستحقاق الصارم: المستفيدين / الأسر المستحقة (مقيم + معتمد)",
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                val totalEligible = data.subAreas.sumOf { it.eligibleFamiliesCount }
                val totalDelivered = data.subAreas.sumOf { it.deliveredBeneficiariesCount }
                val overallRatio = if (totalEligible > 0) (totalDelivered * 100 / totalEligible) else 0

                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem("إجمالي الأسر", "${data.totalFamilies}", "أسرة", android.graphics.Color.rgb(13, 148, 136)),
                        KpiItem("المستحقين", "$totalEligible", "مقيم+معتمد", android.graphics.Color.rgb(2, 132, 199)),
                        KpiItem("المستفيدين الفعليين", "$totalDelivered", "مستفيد", android.graphics.Color.rgb(16, 185, 129)),
                        KpiItem("معدل التغطية", "$overallRatio%", "إنجاز", android.graphics.Color.rgb(245, 158, 11))
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.subAreas.size)
            val pageSubAreas = if (data.subAreas.isNotEmpty()) data.subAreas.subList(startIndex, endIndex) else emptyList()

            currentY = drawLocalitySubAreaTable(
                canvas = canvas,
                subAreas = pageSubAreas,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, "Locality_${data.localityName}_$timeStamp.pdf")

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    // =========================================================================
    // 3. توليد تقرير التوزيع الشامل حسب الفترة بصيغة A4 PDF
    // =========================================================================
    fun generateComprehensivePeriodPdf(data: ComprehensivePeriodReportData): File {
        val pdfDocument = PdfDocument()

        val itemsPerPage = 22
        val totalPages = if (data.records.isEmpty()) 1 else ((data.records.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(a4Width, a4Height, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            var currentY = 16f
            currentY = drawOfficialHeader(
                canvas = canvas,
                reportTitle = "تقرير التوزيع الشامل والعمليات الميدانية",
                subtitle = "نطاق الفترة الزمنية المحددة: من ${data.fromDate} إلى ${data.toDate}",
                periodOrFilter = "إجمالي المحليات النشطة: ${data.localityStats.size} | أصناف المساعدات: ${data.aidTypeStats.size}",
                dateStr = data.dateGenerated,
                startY = currentY
            )

            if (pageIndex == 0) {
                currentY = drawKpiCards(
                    canvas = canvas,
                    startY = currentY + 6f,
                    kpis = listOf(
                        KpiItem("مساعدات الفترة", "${data.totalDeliveries}", "سجل/طرد", android.graphics.Color.rgb(13, 148, 136)),
                        KpiItem("المستفيدين الموثقين", "${data.records.size}", "مستلم", android.graphics.Color.rgb(16, 185, 129)),
                        KpiItem("المحليات المشمولة", "${data.localityStats.size}", "محلية", android.graphics.Color.rgb(2, 132, 199)),
                        KpiItem("أنواع المعونة", "${data.aidTypeStats.size}", "صنف", android.graphics.Color.rgb(139, 92, 246))
                    )
                )
            } else {
                currentY += 8f
            }

            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.records.size)
            val pageRecords = if (data.records.isNotEmpty()) data.records.subList(startIndex, endIndex) else emptyList()

            currentY = drawProjectBeneficiaryTable(
                canvas = canvas,
                records = pageRecords,
                startIndex = startIndex,
                startY = currentY + 8f
            )

            if (pageIndex == totalPages - 1) {
                drawOfficialFooterWithSignatures(
                    canvas = canvas,
                    supervisorName = data.supervisorName,
                    pageIndex = pageIndex + 1,
                    totalPages = totalPages
                )
            } else {
                drawPageNumberOnly(canvas, pageIndex + 1, totalPages)
            }

            pdfDocument.finishPage(page)
        }

        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, "Comprehensive_${data.fromDate}_to_${data.toDate}_$timeStamp.pdf")

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()
        return outputFile
    }

    // =========================================================================
    // 4. تصدير تقرير المشروع ومستفيديه إلى Excel (.xlsx) عبر Apache POI
    // =========================================================================
    fun generateProjectBeneficiariesExcel(data: ProjectReportData): File {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("كشف_مستفيدي_المشروع")
        sheet.isRightToLeft = true

        val headerStyle: XSSFCellStyle = createHeaderCellStyle(workbook)
        val titleStyle: XSSFCellStyle = createTitleCellStyle(workbook)
        val dataStyleEven: XSSFCellStyle = createDataCellStyle(workbook, isEven = true)
        val dataStyleOdd: XSSFCellStyle = createDataCellStyle(workbook, isEven = false)
        val metaLabelStyle: XSSFCellStyle = createMetaLabelStyle(workbook)
        val metaValueStyle: XSSFCellStyle = createMetaValueStyle(workbook)

        var rowIdx = 0

        // عنوان التقرير
        val titleRow = sheet.createRow(rowIdx++)
        titleRow.heightInPoints = 30f
        val titleCell = titleRow.createCell(0)
        titleCell.setCellValue("كشف مستفيدي المشروع الإنساني المعتمد - ${data.project.projectName}")
        titleCell.cellStyle = titleStyle
        sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 7))

        rowIdx++ // سطر فارغ

        // البيانات التعريفية للمشروع
        val metaRow1 = sheet.createRow(rowIdx++)
        metaRow1.createCell(0).apply { setCellValue("رقم المشروع:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(1).apply { setCellValue(data.project.projectNumber); cellStyle = metaValueStyle }
        metaRow1.createCell(2).apply { setCellValue("الجهة الممولة:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(3).apply { setCellValue(data.project.fundingInstitution ?: ""); cellStyle = metaValueStyle }

        val metaRow2 = sheet.createRow(rowIdx++)
        metaRow2.createCell(0).apply { setCellValue("نوع المساعدة:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(1).apply { setCellValue(data.aidTypeName); cellStyle = metaValueStyle }
        metaRow2.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

        val metaRow3 = sheet.createRow(rowIdx++)
        metaRow3.createCell(0).apply { setCellValue("المشرف الميداني:"); cellStyle = metaLabelStyle }
        metaRow3.createCell(1).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }
        metaRow3.createCell(2).apply { setCellValue("إجمالي السجلات:"); cellStyle = metaLabelStyle }
        metaRow3.createCell(3).apply { setCellValue("${data.records.size} مستفيد"); cellStyle = metaValueStyle }

        rowIdx++ // سطر فارغ

        // ترويسة الجدول
        val tableHeaderRow = sheet.createRow(rowIdx++)
        tableHeaderRow.heightInPoints = 24f
        val headers = listOf(
            "م",
            "اسم رب الأسرة الرباعي",
            "رقم الهوية الوطنية",
            "أفراد الأسرة",
            "رقم الجوال",
            "المنطقة / الشعبة",
            "حالة الاستلام",
            "ملاحظات الصرف والتحقق"
        )
        headers.forEachIndexed { colIdx, header ->
            tableHeaderRow.createCell(colIdx).apply {
                setCellValue(header)
                cellStyle = headerStyle
            }
        }

        // صفوف البيانات
        data.records.forEachIndexed { i, item ->
            val row = sheet.createRow(rowIdx++)
            row.heightInPoints = 20f
            val style: XSSFCellStyle = if (i % 2 == 0) dataStyleEven else dataStyleOdd

            row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
            row.createCell(1).apply { setCellValue(item.family?.name ?: "-"); cellStyle = style }
            row.createCell(2).apply { setCellValue(item.family?.nationalID ?: "-"); cellStyle = style }
            row.createCell(3).apply { setCellValue((item.family?.familyMembersCount ?: 0).toDouble()); cellStyle = style }
            row.createCell(4).apply { setCellValue(item.family?.primaryPhone ?: "-"); cellStyle = style }
            row.createCell(5).apply { setCellValue(item.family?.currentSubArea ?: "-"); cellStyle = style }
            row.createCell(6).apply { setCellValue(item.record.recipientStatus); cellStyle = style }
            row.createCell(7).apply { setCellValue(item.record.notes ?: ""); cellStyle = style }
        }

        // ضبط عرض الأعمدة
        for (c in headers.indices) {
            sheet.autoSizeColumn(c)
            sheet.setColumnWidth(c, (sheet.getColumnWidth(c) + 1400).coerceAtMost(10000))
        }

        val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, "Project_${data.project.projectNumber}_$timeStamp.xlsx")

        FileOutputStream(outputFile).use { fos ->
            workbook.write(fos)
        }
        workbook.close()
        return outputFile
    }

    // =========================================================================
    // 5. تصدير تقرير المحلية والشعب إلى Excel (.xlsx) عبر Apache POI
    // =========================================================================
    fun generateLocalitySubAreasExcel(data: LocalityReportData): File {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("تغطية_المحلية_والشعب")
        sheet.isRightToLeft = true

        val headerStyle: XSSFCellStyle = createHeaderCellStyle(workbook)
        val titleStyle: XSSFCellStyle = createTitleCellStyle(workbook)
        val dataStyleEven: XSSFCellStyle = createDataCellStyle(workbook, isEven = true)
        val dataStyleOdd: XSSFCellStyle = createDataCellStyle(workbook, isEven = false)
        val metaLabelStyle: XSSFCellStyle = createMetaLabelStyle(workbook)
        val metaValueStyle: XSSFCellStyle = createMetaValueStyle(workbook)

        var rowIdx = 0

        val titleRow = sheet.createRow(rowIdx++)
        titleRow.heightInPoints = 30f
        val titleCell = titleRow.createCell(0)
        titleCell.setCellValue("تقرير التغطية الميدانية ونسب الاستفادة - محلية ${data.localityName}")
        titleCell.cellStyle = titleStyle
        sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 6))

        rowIdx++

        val metaRow1 = sheet.createRow(rowIdx++)
        metaRow1.createCell(0).apply { setCellValue("المحلية المعتمدة:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(1).apply { setCellValue(data.localityName); cellStyle = metaValueStyle }
        metaRow1.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

        val metaRow2 = sheet.createRow(rowIdx++)
        metaRow2.createCell(0).apply { setCellValue("المشرف الميداني:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(1).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }
        metaRow2.createCell(2).apply { setCellValue("إجمالي الأسر المسجلة:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(3).apply { setCellValue("${data.totalFamilies} أسرة"); cellStyle = metaValueStyle }

        rowIdx++

        val tableHeaderRow = sheet.createRow(rowIdx++)
        tableHeaderRow.heightInPoints = 24f
        val headers = listOf(
            "م",
            "الشعبة / المنطقة الفرعية",
            "المستحقين (مقيم + معتمد)",
            "المستفيدين الفعليين",
            "إجمالي الأسر المسجلة",
            "نسبة التغطية والاستفادة",
            "حالة التغطية الميدانية"
        )
        headers.forEachIndexed { colIdx, header ->
            tableHeaderRow.createCell(colIdx).apply {
                setCellValue(header)
                cellStyle = headerStyle
            }
        }

        data.subAreas.forEachIndexed { i, sub ->
            val row = sheet.createRow(rowIdx++)
            row.heightInPoints = 20f
            val style: XSSFCellStyle = if (i % 2 == 0) dataStyleEven else dataStyleOdd

            row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
            row.createCell(1).apply { setCellValue(sub.subAreaName); cellStyle = style }
            row.createCell(2).apply { setCellValue(sub.eligibleFamiliesCount.toDouble()); cellStyle = style }
            row.createCell(3).apply { setCellValue(sub.deliveredBeneficiariesCount.toDouble()); cellStyle = style }
            row.createCell(4).apply { setCellValue(sub.totalFamiliesCount.toDouble()); cellStyle = style }
            row.createCell(5).apply { setCellValue(sub.formattedRatio); cellStyle = style }
            row.createCell(6).apply {
                val statusText = if (sub.ratioPercentage >= 50) "تغطية ممتازة" else "قيد التوزيع والمتابعة"
                setCellValue(statusText)
                cellStyle = style
            }
        }

        for (c in headers.indices) {
            sheet.autoSizeColumn(c)
            sheet.setColumnWidth(c, (sheet.getColumnWidth(c) + 1400).coerceAtMost(10000))
        }

        val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, "Locality_${data.localityName}_$timeStamp.xlsx")

        FileOutputStream(outputFile).use { fos ->
            workbook.write(fos)
        }
        workbook.close()
        return outputFile
    }

    // =========================================================================
    // 6. تصدير تقرير التوزيع الشامل إلى Excel (.xlsx) عبر Apache POI
    // =========================================================================
    fun generateComprehensivePeriodExcel(data: ComprehensivePeriodReportData): File {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("تقرير_التوزيع_الشامل")
        sheet.isRightToLeft = true

        val headerStyle: XSSFCellStyle = createHeaderCellStyle(workbook)
        val titleStyle: XSSFCellStyle = createTitleCellStyle(workbook)
        val dataStyleEven: XSSFCellStyle = createDataCellStyle(workbook, isEven = true)
        val dataStyleOdd: XSSFCellStyle = createDataCellStyle(workbook, isEven = false)
        val metaLabelStyle: XSSFCellStyle = createMetaLabelStyle(workbook)
        val metaValueStyle: XSSFCellStyle = createMetaValueStyle(workbook)

        var rowIdx = 0

        val titleRow = sheet.createRow(rowIdx++)
        titleRow.heightInPoints = 30f
        val titleCell = titleRow.createCell(0)
        titleCell.setCellValue("تقرير التوزيع الشامل والعمليات الميدانية (${data.fromDate} إلى ${data.toDate})")
        titleCell.cellStyle = titleStyle
        sheet.addMergedRegion(CellRangeAddress(0, 0, 0, 7))

        rowIdx++

        val metaRow1 = sheet.createRow(rowIdx++)
        metaRow1.createCell(0).apply { setCellValue("نطاق الفترة:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(1).apply { setCellValue("${data.fromDate} إلى ${data.toDate}"); cellStyle = metaValueStyle }
        metaRow1.createCell(2).apply { setCellValue("تاريخ التقرير:"); cellStyle = metaLabelStyle }
        metaRow1.createCell(3).apply { setCellValue(data.dateGenerated); cellStyle = metaValueStyle }

        val metaRow2 = sheet.createRow(rowIdx++)
        metaRow2.createCell(0).apply { setCellValue("إجمالي مساعدات الفترة:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(1).apply { setCellValue("${data.totalDeliveries} طرد"); cellStyle = metaValueStyle }
        metaRow2.createCell(2).apply { setCellValue("المشرف المسؤول:"); cellStyle = metaLabelStyle }
        metaRow2.createCell(3).apply { setCellValue(data.supervisorName); cellStyle = metaValueStyle }

        rowIdx++

        val tableHeaderRow = sheet.createRow(rowIdx++)
        tableHeaderRow.heightInPoints = 24f
        val headers = listOf(
            "م",
            "اسم المستفيد الرباعي",
            "رقم الهوية",
            "المحلية / المنطقة",
            "المشروع الإغاثي",
            "تاريخ التسليم",
            "حالة الاستلام",
            "المستلم الفعلي والملاحظات"
        )
        headers.forEachIndexed { colIdx, header ->
            tableHeaderRow.createCell(colIdx).apply {
                setCellValue(header)
                cellStyle = headerStyle
            }
        }

        data.records.forEachIndexed { i, item ->
            val row = sheet.createRow(rowIdx++)
            row.heightInPoints = 20f
            val style: XSSFCellStyle = if (i % 2 == 0) dataStyleEven else dataStyleOdd

            row.createCell(0).apply { setCellValue((i + 1).toDouble()); cellStyle = style }
            row.createCell(1).apply { setCellValue(item.family?.name ?: "-"); cellStyle = style }
            row.createCell(2).apply { setCellValue(item.family?.nationalID ?: "-"); cellStyle = style }
            row.createCell(3).apply { setCellValue(item.family?.currentSubArea ?: "-"); cellStyle = style }
            row.createCell(4).apply { setCellValue("مشروع #${item.record.projectID}"); cellStyle = style }
            row.createCell(5).apply { setCellValue(item.record.deliveryDate ?: item.record.aidDate); cellStyle = style }
            row.createCell(6).apply { setCellValue(item.record.recipientStatus); cellStyle = style }
            row.createCell(7).apply { setCellValue(item.record.notes ?: ""); cellStyle = style }
        }

        for (c in headers.indices) {
            sheet.autoSizeColumn(c)
            sheet.setColumnWidth(c, (sheet.getColumnWidth(c) + 1400).coerceAtMost(10000))
        }

        val reportsDir = File(context.getExternalFilesDir(null), "excel_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val outputFile = File(reportsDir, "Comprehensive_${data.fromDate}_to_${data.toDate}_$timeStamp.xlsx")

        FileOutputStream(outputFile).use { fos ->
            workbook.write(fos)
        }
        workbook.close()
        return outputFile
    }

    // =========================================================================
    // دوال رسم وتنسيق مستند A4 PDF
    // =========================================================================

    private fun drawOfficialHeader(
        canvas: Canvas,
        reportTitle: String,
        subtitle: String,
        periodOrFilter: String,
        dateStr: String,
        startY: Float
    ): Float {
        var y = startY

        // شريط علوي ملون متدرج بلون التركواز الداكن المؤسسي
        val topBarPaint = Paint().apply { color = android.graphics.Color.rgb(13, 148, 136) }
        canvas.drawRect(0f, 0f, a4Width.toFloat(), 12f, topBarPaint)

        // شريط ذهبي خفيف للرقي
        val accentBarPaint = Paint().apply { color = android.graphics.Color.rgb(245, 158, 11) }
        canvas.drawRect(0f, 12f, a4Width.toFloat(), 15f, accentBarPaint)

        y = 38f
        val orgPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(15, 23, 42) // Dark Slate
            textSize = 14f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("نظام إدارة المساعدات الإنسانية والعمليات الميدانية المعتمد", a4Width - marginH, y, orgPaint)

        y += 18f
        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(13, 148, 136)
            textSize = 15f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText(reportTitle, a4Width - marginH, y, titlePaint)

        // صندوق البيانات الوصفية (Metadata Box)
        y += 10f
        val boxHeight = 44f
        val boxRect = RectF(marginH, y, a4Width - marginH, y + boxHeight)
        val boxPaint = Paint().apply { color = android.graphics.Color.rgb(248, 250, 252) }
        val boxStroke = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(boxRect, 6f, 6f, boxPaint)
        canvas.drawRoundRect(boxRect, 6f, 6f, boxStroke)

        val metaPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(51, 65, 85)
            textSize = 8.5f
            textAlign = Paint.Align.RIGHT
        }

        val datePaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(100, 116, 139)
            textSize = 8f
            textAlign = Paint.Align.LEFT
        }

        canvas.drawText(subtitle, a4Width - marginH - 10f, y + 16f, metaPaint)
        canvas.drawText(periodOrFilter, a4Width - marginH - 10f, y + 32f, metaPaint)
        canvas.drawText("تاريخ الإصدار: $dateStr", marginH + 10f, y + 16f, datePaint)
        canvas.drawText("المقاس: A4 Standard (رسمي للطباعة)", marginH + 10f, y + 32f, datePaint)

        return y + boxHeight
    }

    private data class KpiItem(val label: String, val value: String, val unit: String, val colorInt: Int)

    private fun drawKpiCards(
        canvas: Canvas,
        startY: Float,
        kpis: List<KpiItem>
    ): Float {
        val count = kpis.size
        val gap = 8f
        val totalGaps = gap * (count - 1)
        val cardWidth = (contentWidth - totalGaps) / count
        val cardHeight = 40f

        var currentX = a4Width - marginH

        kpis.forEach { kpi ->
            val left = currentX - cardWidth
            val rect = RectF(left, startY, currentX, startY + cardHeight)

            val bgPaint = Paint().apply { color = android.graphics.Color.rgb(255, 255, 255) }
            val borderPaint = Paint().apply {
                color = kpi.colorInt
                style = Paint.Style.STROKE
                strokeWidth = 1f
            }
            canvas.drawRoundRect(rect, 6f, 6f, bgPaint)
            canvas.drawRoundRect(rect, 6f, 6f, borderPaint)

            // علامة شريطية بلون الـ KPI
            val sideBar = RectF(currentX - 4f, startY, currentX, startY + cardHeight)
            val sidePaint = Paint().apply { color = kpi.colorInt }
            canvas.drawRoundRect(sideBar, 2f, 2f, sidePaint)

            val labelPaint = Paint().apply {
                isAntiAlias = true
                color = android.graphics.Color.rgb(100, 116, 139)
                textSize = 7.5f
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText(kpi.label, currentX - 10f, startY + 14f, labelPaint)

            val valPaint = Paint().apply {
                isAntiAlias = true
                color = kpi.colorInt
                textSize = 12f
                isFakeBoldText = true
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawText("${kpi.value} ${kpi.unit}", currentX - 10f, startY + 31f, valPaint)

            currentX -= (cardWidth + gap)
        }

        return startY + cardHeight
    }

    private fun drawProjectBeneficiaryTable(
        canvas: Canvas,
        records: List<AidRecordWithBeneficiary>,
        startIndex: Int,
        startY: Float
    ): Float {
        var y = startY
        val colWidths = floatArrayOf(24f, 155f, 75f, 40f, 90f, 85f, 70f)
        val colHeaders = arrayOf("م", "اسم المستفيد الرباعي", "رقم الهوية", "الأفراد", "المنطقة / الشعبة", "حالة الاستلام", "التوقيع / البصمة")

        // رأس الجدول
        val headerHeight = 22f
        val headerBg = Paint().apply { color = android.graphics.Color.rgb(13, 148, 136) }
        canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, headerBg)

        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textSize = 8.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        var curX = a4Width - marginH
        colHeaders.forEachIndexed { i, title ->
            val w = colWidths[i]
            canvas.drawText(title, curX - (w / 2f), y + 14f, headerTextPaint)
            curX -= w
        }
        y += headerHeight

        // صفوف الجدول
        val rowHeight = 18f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = android.graphics.Color.rgb(248, 250, 252) }

        records.forEachIndexed { idx, item ->
            val isEven = idx % 2 == 0
            if (isEven) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            // 0: م
            canvas.drawText("${startIndex + idx + 1}", x - (colWidths[0] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[0]

            // 1: اسم المستفيد
            val name = item.family?.name ?: "مستفيد #${item.record.familyID}"
            val clippedName = if (name.length > 32) name.substring(0, 30) + "..." else name
            canvas.drawText(clippedName, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[1]

            // 2: الهوية
            canvas.drawText(item.family?.nationalID ?: "-", x - (colWidths[2] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[2]

            // 3: أفراد
            canvas.drawText("${item.family?.familyMembersCount ?: 0}", x - (colWidths[3] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[3]

            // 4: المنطقة
            val area = item.family?.currentSubArea ?: "-"
            val clippedArea = if (area.length > 18) area.substring(0, 16) + ".." else area
            canvas.drawText(clippedArea, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[4]

            // 5: حالة الاستلام
            val status = item.record.recipientStatus
            val statusPaint = Paint().apply {
                isAntiAlias = true
                textSize = 7.5f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
                color = if (status.contains("مستلم") || status.contains("تم التسليم")) android.graphics.Color.rgb(16, 185, 129) else android.graphics.Color.rgb(217, 119, 6)
            }
            canvas.drawText(status, x - (colWidths[5] / 2f), y + 12f, statusPaint)
            x -= colWidths[5]

            // 6: التوقيع / البصمة (مربع منقط خفيف)
            val boxPaint = Paint().apply {
                color = android.graphics.Color.rgb(203, 213, 225)
                style = Paint.Style.STROKE
                strokeWidth = 0.5f
            }
            canvas.drawRect(x - colWidths[6] + 8f, y + 3f, x - 8f, y + rowHeight - 3f, boxPaint)

            y += rowHeight
        }

        return y
    }

    private fun drawLocalitySubAreaTable(
        canvas: Canvas,
        subAreas: List<SubAreaBenefitRatioStat>,
        startIndex: Int,
        startY: Float
    ): Float {
        var y = startY
        val colWidths = floatArrayOf(24f, 155f, 80f, 80f, 70f, 65f, 65f)
        val colHeaders = arrayOf("م", "الشعبة / المنطقة الفرعية", "المستحقين (مقيم+معتمد)", "المستفيدين الفعليين", "إجمالي الأسر", "نسبة الإنجاز", "حالة التغطية")

        val headerHeight = 22f
        val headerBg = Paint().apply { color = android.graphics.Color.rgb(13, 148, 136) }
        canvas.drawRoundRect(RectF(marginH, y, a4Width - marginH, y + headerHeight), 4f, 4f, headerBg)

        val headerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.WHITE
            textSize = 8f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        var curX = a4Width - marginH
        colHeaders.forEachIndexed { i, title ->
            val w = colWidths[i]
            canvas.drawText(title, curX - (w / 2f), y + 14f, headerTextPaint)
            curX -= w
        }
        y += headerHeight

        val rowHeight = 18f
        val rowTextCenter = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        val rowTextRight = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(30, 41, 59)
            textSize = 7.5f
            textAlign = Paint.Align.RIGHT
        }
        val linePaint = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            strokeWidth = 0.5f
        }
        val evenBg = Paint().apply { color = android.graphics.Color.rgb(248, 250, 252) }

        subAreas.forEachIndexed { idx, sub ->
            val isEven = idx % 2 == 0
            if (isEven) {
                canvas.drawRect(marginH, y, a4Width - marginH, y + rowHeight, evenBg)
            }
            canvas.drawLine(marginH, y + rowHeight, a4Width - marginH, y + rowHeight, linePaint)

            var x = a4Width - marginH
            // 0: م
            canvas.drawText("${startIndex + idx + 1}", x - (colWidths[0] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[0]

            // 1: اسم الشعبة
            canvas.drawText(sub.subAreaName, x - 6f, y + 12f, rowTextRight)
            x -= colWidths[1]

            // 2: المستحقين
            canvas.drawText("${sub.eligibleFamiliesCount}", x - (colWidths[2] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[2]

            // 3: المستفيدين
            canvas.drawText("${sub.deliveredBeneficiariesCount}", x - (colWidths[3] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[3]

            // 4: إجمالي الأسر
            canvas.drawText("${sub.totalFamiliesCount}", x - (colWidths[4] / 2f), y + 12f, rowTextCenter)
            x -= colWidths[4]

            // 5: نسبة الإنجاز
            val ratioPaint = Paint().apply {
                isAntiAlias = true
                textSize = 8f
                isFakeBoldText = true
                textAlign = Paint.Align.CENTER
                color = if (sub.ratioPercentage >= 50) android.graphics.Color.rgb(16, 185, 129) else android.graphics.Color.rgb(245, 158, 11)
            }
            canvas.drawText(sub.formattedRatio, x - (colWidths[5] / 2f), y + 12f, ratioPaint)
            x -= colWidths[5]

            // 6: الحالة
            val statusPaint = Paint().apply {
                isAntiAlias = true
                textSize = 7f
                textAlign = Paint.Align.CENTER
                color = if (sub.ratioPercentage >= 50) android.graphics.Color.rgb(4, 120, 87) else android.graphics.Color.rgb(180, 83, 9)
            }
            val statusStr = if (sub.ratioPercentage >= 50) "تغطية ممتازة" else "قيد التوزيع"
            canvas.drawText(statusStr, x - (colWidths[6] / 2f), y + 12f, statusPaint)

            y += rowHeight
        }

        return y
    }

    private fun drawOfficialFooterWithSignatures(
        canvas: Canvas,
        supervisorName: String,
        pageIndex: Int,
        totalPages: Int
    ) {
        val y = a4Height - 85f

        // خط فاصل علوي
        val divPaint = Paint().apply {
            color = android.graphics.Color.rgb(203, 213, 225)
            strokeWidth = 1f
        }
        canvas.drawLine(marginH, y, a4Width - marginH, y, divPaint)

        // 3 مربعات توقيع وخاتم رسمي
        val boxWidth = (contentWidth - 24f) / 3f
        val boxHeight = 44f
        val boxY = y + 8f

        val boxPaint = Paint().apply {
            color = android.graphics.Color.rgb(248, 250, 252)
        }
        val borderPaint = Paint().apply {
            color = android.graphics.Color.rgb(226, 232, 240)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val sigHeaderPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(71, 85, 105)
            textSize = 7.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val sigSubPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(100, 116, 139)
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }

        // 1. المشرف الميداني
        val b1 = RectF(a4Width - marginH - boxWidth, boxY, a4Width - marginH, boxY + boxHeight)
        canvas.drawRoundRect(b1, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b1, 4f, 4f, borderPaint)
        canvas.drawText("المشرف الميداني المسؤول", b1.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText(supervisorName, b1.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText("التوقيع: .....................", b1.centerX(), boxY + 36f, sigSubPaint)

        // 2. مدقق الرقابة والمطابقة
        val b2 = RectF(a4Width - marginH - (boxWidth * 2) - 12f, boxY, a4Width - marginH - boxWidth - 12f, boxY + boxHeight)
        canvas.drawRoundRect(b2, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b2, 4f, 4f, borderPaint)
        canvas.drawText("التدقيق والمطابقة الرقابية", b2.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText("مطابق لكشوفات الاستحقاق", b2.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText("التوقيع: .....................", b2.centerX(), boxY + 36f, sigSubPaint)

        // 3. خاتم الاعتماد الرسمي
        val b3 = RectF(marginH, boxY, marginH + boxWidth, boxY + boxHeight)
        canvas.drawRoundRect(b3, 4f, 4f, boxPaint)
        canvas.drawRoundRect(b3, 4f, 4f, borderPaint)
        canvas.drawText("الختم والاعتماد الرسمي", b3.centerX(), boxY + 12f, sigHeaderPaint)
        canvas.drawText("إدارة المنظومة الإنسانية", b3.centerX(), boxY + 24f, sigSubPaint)
        canvas.drawText("[ ختم المنظمة المعتمد ]", b3.centerX(), boxY + 36f, sigSubPaint)

        // التذييل السفلي وأرقام الصفحات
        val footerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(148, 163, 184)
            textSize = 7f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("صفحة $pageIndex من $totalPages  •  نظام إدارة المساعدات الإنسانية - مستند رسمي معتمد وغير قابل للتعديل", a4Width / 2f, a4Height - 12f, footerTextPaint)
    }

    private fun drawPageNumberOnly(canvas: Canvas, pageIndex: Int, totalPages: Int) {
        val footerTextPaint = Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.rgb(148, 163, 184)
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("صفحة $pageIndex من $totalPages  •  نظام إدارة المساعدات الإنسانية", a4Width / 2f, a4Height - 14f, footerTextPaint)
    }

    // =========================================================================
    // دوال مساعدة لإنشاء أنماط خلايا Apache POI
    // =========================================================================

    private fun createTitleCellStyle(workbook: XSSFWorkbook): XSSFCellStyle {
        val style = workbook.createCellStyle() as XSSFCellStyle
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 14
            color = IndexedColors.DARK_TEAL.index
        }
        style.setFont(font)
        style.alignment = HorizontalAlignment.CENTER
        style.verticalAlignment = VerticalAlignment.CENTER
        return style
    }

    private fun createHeaderCellStyle(workbook: XSSFWorkbook): XSSFCellStyle {
        val style = workbook.createCellStyle() as XSSFCellStyle
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 10
            color = IndexedColors.WHITE.index
        }
        style.setFont(font)
        style.fillForegroundColor = IndexedColors.TEAL.index
        style.fillPattern = FillPatternType.SOLID_FOREGROUND
        style.alignment = HorizontalAlignment.CENTER
        style.verticalAlignment = VerticalAlignment.CENTER
        setThinBorders(style)
        return style
    }

    private fun createDataCellStyle(workbook: XSSFWorkbook, isEven: Boolean): XSSFCellStyle {
        val style = workbook.createCellStyle() as XSSFCellStyle
        val font = workbook.createFont().apply {
            fontHeightInPoints = 9.toShort()
        }
        style.setFont(font)
        if (isEven) {
            style.fillForegroundColor = IndexedColors.GREY_25_PERCENT.index
            style.fillPattern = FillPatternType.SOLID_FOREGROUND
        }
        style.alignment = HorizontalAlignment.CENTER
        style.verticalAlignment = VerticalAlignment.CENTER
        setThinBorders(style)
        return style
    }

    private fun createMetaLabelStyle(workbook: XSSFWorkbook): XSSFCellStyle {
        val style = workbook.createCellStyle() as XSSFCellStyle
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 9.toShort()
            color = IndexedColors.DARK_BLUE.index
        }
        style.setFont(font)
        style.alignment = HorizontalAlignment.RIGHT
        return style
    }

    private fun createMetaValueStyle(workbook: XSSFWorkbook): XSSFCellStyle {
        val style = workbook.createCellStyle() as XSSFCellStyle
        val font = workbook.createFont().apply {
            fontHeightInPoints = 9.toShort()
        }
        style.setFont(font)
        style.alignment = HorizontalAlignment.RIGHT
        return style
    }

    private fun setThinBorders(style: CellStyle) {
        style.borderTop = BorderStyle.THIN
        style.borderBottom = BorderStyle.THIN
        style.borderLeft = BorderStyle.THIN
        style.borderRight = BorderStyle.THIN
    }

    // =========================================================================
    // دوال المشاركة، الطباعة، وفتح الملفات
    // =========================================================================

    fun shareFile(file: File, mimeType: String, title: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, "مرفق مستند معتمد: $title - صادر عن نظام إدارة المساعدات الإنسانية.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "مشاركة المستند المعتمد:")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    fun openFile(file: File, mimeType: String) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(Intent.createChooser(intent, "فتح المستند بواسطة:"))
    }

    fun printPdfReport(pdfFile: File, jobName: String = "Aid_Management_Report") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return

        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = android.print.PrintDocumentInfo.Builder(jobName)
                    .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out android.print.PageRange>?,
                destination: android.os.ParcelFileDescriptor?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    val input = java.io.FileInputStream(pdfFile)
                    val output = java.io.FileOutputStream(destination?.fileDescriptor)

                    val buf = ByteArray(1024)
                    var bytesRead: Int
                    while (input.read(buf).also { bytesRead = it } > 0) {
                        output.write(buf, 0, bytesRead)
                    }

                    callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                    input.close()
                    output.close()
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                }
            }
        }

        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    }
}
