package com.humanitarian.aidmanagement.ui.screens.families

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FamiliesUiState(
    val families: List<FamilyEntity> = emptyList(),
    val totalCount: Int = 0,
    val isLoading: Boolean = false,
    val isLoadingMore: Boolean = false,
    val hasMorePages: Boolean = true,
    val currentPage: Int = 0,
    val searchQuery: String = "",
    val selectedLocalityId: Int = 0,
    val selectedShelterStatus: String = "",
    val errorMessage: String? = null
)

class FamiliesViewModel(
    private val repository: AidRepository
) : ViewModel() {

    private val pageSize = 50
    private val _uiState = MutableStateFlow(FamiliesUiState())
    val uiState: StateFlow<FamiliesUiState> = _uiState.asStateFlow()

    private var loadJob: Job? = null

    init {
        val user = repository.getCurrentUser()
        val initialLoc = if ((user?.AllowedLocalityID ?: 0) != 0 && !repository.isSuperAdmin()) {
            user?.AllowedLocalityID ?: 0
        } else 0
        _uiState.update { it.copy(selectedLocalityId = initialLoc) }
        loadInitialPage()
    }

    fun onSearchQueryChanged(newQuery: String) {
        if (_uiState.value.searchQuery == newQuery) return
        _uiState.update { it.copy(searchQuery = newQuery) }
        loadInitialPage()
    }

    fun onLocalitySelected(localityId: Int) {
        if (_uiState.value.selectedLocalityId == localityId) return
        _uiState.update { it.copy(selectedLocalityId = localityId) }
        loadInitialPage()
    }

    fun onShelterStatusSelected(shelterStatus: String) {
        if (_uiState.value.selectedShelterStatus == shelterStatus) return
        _uiState.update { it.copy(selectedShelterStatus = shelterStatus) }
        loadInitialPage()
    }

    fun loadInitialPage() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, currentPage = 0, errorMessage = null) }
            try {
                val state = _uiState.value
                val shelter = if (state.selectedShelterStatus.isBlank()) null else state.selectedShelterStatus
                val total = repository.getFamiliesCount(
                    query = state.searchQuery,
                    localityId = state.selectedLocalityId,
                    shelterStatus = shelter
                )
                val initialList = repository.getFamiliesPaged(
                    query = state.searchQuery,
                    localityId = state.selectedLocalityId,
                    shelterStatus = shelter,
                    limit = pageSize,
                    offset = 0
                )
                _uiState.update {
                    it.copy(
                        families = initialList,
                        totalCount = total,
                        isLoading = false,
                        currentPage = 1,
                        hasMorePages = initialList.size < total
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, errorMessage = e.message) }
            }
        }
    }

    fun loadNextPage() {
        val state = _uiState.value
        if (state.isLoading || state.isLoadingMore || !state.hasMorePages) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingMore = true) }
            try {
                val offset = state.families.size
                val shelter = if (state.selectedShelterStatus.isBlank()) null else state.selectedShelterStatus
                val nextChunk = repository.getFamiliesPaged(
                    query = state.searchQuery,
                    localityId = state.selectedLocalityId,
                    shelterStatus = shelter,
                    limit = pageSize,
                    offset = offset
                )

                _uiState.update { current ->
                    val combined = current.families + nextChunk
                    current.copy(
                        families = combined,
                        isLoadingMore = false,
                        currentPage = current.currentPage + 1,
                        hasMorePages = nextChunk.isNotEmpty() && combined.size < current.totalCount
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoadingMore = false, errorMessage = e.message) }
            }
        }
    }

    fun refresh() {
        loadInitialPage()
    }

    /**
     * حساب العمر الدقيق ديناميكياً من تاريخ الميلاد date_of_birth بدون أي قيم ثابتة
     */
    fun calculateAge(birthDateString: String?): Int? {
        if (birthDateString.isNullOrBlank()) return null
        return try {
            val parts = birthDateString.trim().split("-", "/")
            if (parts.size >= 3) {
                val year = parts[0].toIntOrNull() ?: return null
                val month = parts[1].toIntOrNull() ?: 1
                val day = parts[2].toIntOrNull() ?: 1
                val birthCal = java.util.Calendar.getInstance().apply { set(year, month - 1, day) }
                val today = java.util.Calendar.getInstance()
                var calculatedAge = today.get(java.util.Calendar.YEAR) - birthCal.get(java.util.Calendar.YEAR)
                if (today.get(java.util.Calendar.DAY_OF_YEAR) < birthCal.get(java.util.Calendar.DAY_OF_YEAR)) {
                    calculatedAge--
                }
                calculatedAge.coerceAtLeast(0)
            } else null
        } catch (_: Exception) {
            null
        }
    }

    class Factory(private val repository: AidRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return FamiliesViewModel(repository) as T
        }
    }
}
