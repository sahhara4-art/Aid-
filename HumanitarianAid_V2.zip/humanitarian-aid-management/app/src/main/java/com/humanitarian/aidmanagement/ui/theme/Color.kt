package com.humanitarian.aidmanagement.ui.theme

import androidx.compose.ui.graphics.Color

// ==================== ألوان الهوية الوطنية الفلسطينية ====================
// ألوان العلم الفلسطيني الأربعة: الأخضر الزيتوني، الأحمر القاني، الأبيض الناصع، الأسود الفحمي
val PalestineGreen = Color(0xFF007A3D)        // الأخضر الفلسطيني الأصيل (رمز الأرض والزيتون)
val PalestineGreenDark = Color(0xFF005A2C)    // الأخضر الداكن
val PalestineGreenLight = Color(0xFFE8F5E9)   // أخضر فاتح جداً للخلفيات
val PalestineGreenContainer = Color(0xFFDCFCE7)

val PalestineRed = Color(0xFFCE1126)          // الأحمر القاني (رمز التضحية والصمود)
val PalestineRedDark = Color(0xFFA50E1E)      // أحمر داكن
val PalestineRedLight = Color(0xFFFEE2E2)     // أحمر فاتح للبطاقات التحذيرية
val PalestineRedContainer = Color(0xFFFFE4E6)

val PalestineBlack = Color(0xFF111827)        // الأسود الفحمي (رمز العزة والكرامة)
val PalestineWhite = Color(0xFFFFFFFF)        // الأبيض الناصع (رمز السلام والصفاء)

val PalestineGold = Color(0xFFD97706)         // الذهبي العتيق / زيت الزيتون الصافي
val PalestineGoldLight = Color(0xFFFEF3C7)

// درجات الرمادي الفاتح الحديث (Light Theme Palette)
val SlateBackground = Color(0xFFF8FAFC)      // خلفية التطبيق الفاتحة والمريحة للعين
val SlateSurface = Color(0xFFFFFFFF)         // سطح البطاقات ناصع البياض
val SlateSurfaceVariant = Color(0xFFF1F5F9)  // الحاويات الداخلية الفاتحة
val SlateBorder = Color(0xFFE2E8F0)          // حدود البطاقات
val SlateBorderSubtle = Color(0xFFCBD5E1)

val SlateTextPrimary = Color(0xFF0F172A)     // النص الأساسي عالي التباين
val SlateTextSecondary = Color(0xFF475569)   // النص الثانوي
val SlateTextMuted = Color(0xFF64748B)       // النصوص الإرشادية والتاريخ

// ألوان تكميلية للعمليات
val SkyBlue = Color(0xFF0284C7)
val SkyBlueLight = Color(0xFFE0F2FE)
val AmberWarning = Color(0xFFF59E0B)
val EmeraldSuccess = Color(0xFF10B981)
val RoseDanger = Color(0xFFF43F5E)

// ==================== ألوان محرك الترشيح الديناميكي (Dynamic Nomination Engine) ====================
val BluePrimary = Color(0xFF1976D2)           // اللون الأساسي: الأزرار الرئيسية والعناوين وحالة التحميل
val GreenSecondary = Color(0xFF2E7D32)        // لون النجاح/القبول: عائلات مطابقة 100% واعتماد الترشيح
val AmberWarningNomination = Color(0xFFD97706)// لون التحذير: تنبيهات الاستلام القريب واكتمال الحصة (Quota)
val RedError = Color(0xFFDC2626)              // لون الرفض/الاستبعاد: سبب الاستبعاد بخط صغير
val Slate50 = Color(0xFFF8FAFC)               // لون الخلفية لكامل الشاشة لراحة العين
val BlueLight = Color(0xFFE3F2FD)             // خلفية الرقاقات التفاعلية المحددة مع التأثير الحركي

