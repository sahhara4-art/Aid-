package com.humanitarian.aidmanagement.sync

import android.content.Context
import android.provider.Settings
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.database.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * FirebaseSyncManager - محرك التزامن السحابي عبر Firebase Realtime Database
 * يعمل كـ Middleman وسيط لتخزين وتمرير حركات المناديب الميدانية (Deltas)
 * مع عزل تام لكل محلية تحت عقدة: deltas/locality_{localityId}
 */
class FirebaseSyncManager private constructor(private val context: Context) {

    private var database: FirebaseDatabase? = null
    private var isInitialized = false

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _recentUploadedDeltas = MutableStateFlow<List<SyncDelta>>(emptyList())
    val recentUploadedDeltas: StateFlow<List<SyncDelta>> = _recentUploadedDeltas.asStateFlow()

    private val _totalUploadedCount = MutableStateFlow(0)
    val totalUploadedCount: StateFlow<Int> = _totalUploadedCount.asStateFlow()

    private val _customDatabaseUrl = MutableStateFlow<String?>(null)
    val customDatabaseUrl: StateFlow<String?> = _customDatabaseUrl.asStateFlow()

    val deviceId: String by lazy {
        try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
                ?: java.util.UUID.randomUUID().toString()
        } catch (e: Exception) {
            java.util.UUID.randomUUID().toString()
        }
    }

    companion object {
        private const val TAG = "FirebaseSyncManager"
        const val ROOT_NODE = "humanitarian_aid_sync"
        const val DELTAS_NODE = "deltas"
        const val NODES_STATUS = "mandoob_heartbeats"

        @Volatile
        private var INSTANCE: FirebaseSyncManager? = null

        fun getInstance(context: Context): FirebaseSyncManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: FirebaseSyncManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    /**
     * تهيئة الاتصال بـ Firebase Realtime Database
     * يدعم التهيئة التلقائية عبر google-services.json أو تحديد رابط قاعدة البيانات المخصص
     */
    fun initialize(customUrl: String? = null) {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }

            _customDatabaseUrl.value = customUrl

            database = if (!customUrl.isNullOrBlank()) {
                FirebaseDatabase.getInstance(customUrl.trim())
            } else {
                FirebaseDatabase.getInstance()
            }

            try {
                // تفعيل التخزين المؤقت المحلي لـ Firebase لتوفير دعم Offline أصيل
                database?.setPersistenceEnabled(true)
            } catch (e: Exception) {
                // قد يتم رمي استثناء إذا كانت التهيئة قد تمت مسبقاً
            }

            // مراقبة حالة اتصال Firebase الفعلية بالخادم عبر العقدة الخاصة .info/connected
            val connectedRef = database?.getReference(".info/connected")
            connectedRef?.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val connected = snapshot.getValue(Boolean::class.java) ?: false
                    _isConnected.value = connected
                    Log.d(TAG, "Firebase Realtime connection status: $connected")
                }

                override fun onCancelled(error: DatabaseError) {
                    _isConnected.value = false
                }
            })

            isInitialized = true
            Log.i(TAG, "FirebaseSyncManager initialized successfully.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Firebase Realtime Database: ${e.message}", e)
            isInitialized = false
        }
    }

    fun getDatabaseInstance(): FirebaseDatabase? {
        if (database == null && !isInitialized) {
            initialize()
        }
        return database
    }

    /**
     * رفع حركة واحدة (Delta) إلى Firebase Realtime Database تحت عقدة المحلية
     * المسار: humanitarian_aid_sync/deltas/locality_{localityId}/{deltaId}
     */
    suspend fun pushDelta(delta: SyncDelta): Boolean = withContext(Dispatchers.IO) {
        val db = getDatabaseInstance()
        if (db == null) {
            Log.w(TAG, "FirebaseDatabase instance is null. Unable to push delta.")
            return@withContext false
        }

        val targetLocality = if (delta.localityId > 0) delta.localityId else 0
        val localityNode = "locality_$targetLocality"
        val ref = db.getReference(ROOT_NODE)
            .child(DELTAS_NODE)
            .child(localityNode)
            .child(delta.deltaId)

        return@withContext suspendCancellableCoroutine { continuation ->
            ref.setValue(delta.toMap())
                .addOnSuccessListener {
                    Log.d(TAG, "Successfully pushed delta ${delta.deltaId} [${delta.entityType}:${delta.operation}] to $localityNode")
                    
                    // تحديث الإحصائيات في الذاكرة
                    _totalUploadedCount.value += 1
                    val currentList = _recentUploadedDeltas.value.toMutableList()
                    currentList.add(0, delta)
                    if (currentList.size > 50) currentList.removeAt(currentList.lastIndex)
                    _recentUploadedDeltas.value = currentList

                    // إرسال نبضة استمرارية المندوب (Heartbeat)
                    updateMandoobHeartbeat(delta.localityId, delta.userId, delta.userName)

                    continuation.resume(true)
                }
                .addOnFailureListener { exception ->
                    Log.e(TAG, "Failed to push delta ${delta.deltaId}: ${exception.message}", exception)
                    continuation.resume(false)
                }
        }
    }

    /**
     * تحديث نبضة حضور المندوب في Firebase للمراقبة الميدانية المباشرة
     */
    private fun updateMandoobHeartbeat(localityId: Int, userId: Int, userName: String) {
        try {
            val db = getDatabaseInstance() ?: return
            val heartbeatRef = db.getReference(ROOT_NODE)
                .child(NODES_STATUS)
                .child("locality_$localityId")
                .child("user_$userId")

            val statusData = mapOf(
                "userId" to userId,
                "userName" to userName,
                "localityId" to localityId,
                "deviceId" to deviceId,
                "lastActive" to System.currentTimeMillis()
            )
            heartbeatRef.setValue(statusData)
        } catch (e: Exception) {
            // Non-critical heartbeat failure
        }
    }

    /**
     * حذف حركة تمت معالجتها ودمجها (اختياري لتنظيف قاعدة البيانات السحابية بعد فترات محددة)
     */
    suspend fun removeDelta(localityId: Int, deltaId: String): Boolean = withContext(Dispatchers.IO) {
        val db = getDatabaseInstance() ?: return@withContext false
        val localityNode = "locality_$localityId"
        val ref = db.getReference(ROOT_NODE)
            .child(DELTAS_NODE)
            .child(localityNode)
            .child(deltaId)

        return@withContext suspendCancellableCoroutine { cont ->
            ref.removeValue()
                .addOnSuccessListener { cont.resume(true) }
                .addOnFailureListener { cont.resume(false) }
        }
    }
}
