package com.humanitarian.aidmanagement.sync

import android.content.Context
import android.provider.Settings
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.*
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AuditLogEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/**
 * FirestoreSyncManager - محرك التزامن السحابي المركزي اللحظي (Google Firebase Firestore Master Node)
 *
 * الهيكلة المعمارية:
 * 1. Offline-First Single Source of Truth: قاعدة بيانات Room المحلية هي مصدر الحقيقة الوحيد للواجهة.
 * 2. Bridge Engine: يستمع لتعديلات Firestore اللحظية عبر SnapshotListeners، ويقوم بتحديث Room في أجزاء من الثانية.
 * 3. Master Node: خوادم جوجل هي النسخة الرسمية المركزية التي يتحكم بها المدير العام.
 * 4. Conflict Resolution: تطبيق شرط Override Priority لصالح حساب المدير.
 */
class FirestoreSyncManager private constructor(private val context: Context) {

    private var firestore: FirebaseFirestore? = null
    private var isInitialized = false

    private val _isConnected = MutableStateFlow(false)
    val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _totalUploadedCount = MutableStateFlow(0)
    val totalUploadedCount: StateFlow<Int> = _totalUploadedCount.asStateFlow()

    private val _totalMergedCount = MutableStateFlow(0)
    val totalMergedCount: StateFlow<Int> = _totalMergedCount.asStateFlow()

    private val _adminOverridesCount = MutableStateFlow(0)
    val adminOverridesCount: StateFlow<Int> = _adminOverridesCount.asStateFlow()

    private val _lastMergedDelta = MutableStateFlow<FirestoreSyncDelta?>(null)
    val lastMergedDelta: StateFlow<FirestoreSyncDelta?> = _lastMergedDelta.asStateFlow()

    private val _recentDeltas = MutableStateFlow<List<FirestoreSyncDelta>>(emptyList())
    val recentDeltas: StateFlow<List<FirestoreSyncDelta>> = _recentDeltas.asStateFlow()

    private val listenerRegistrations = ConcurrentHashMap<String, ListenerRegistration>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val deviceId: String by lazy {
        try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
                ?: java.util.UUID.randomUUID().toString()
        } catch (_: Exception) {
            java.util.UUID.randomUUID().toString()
        }
    }

    companion object {
        private const val TAG = "FirestoreSyncManager"
        const val ROOT_COLLECTION = "humanitarian_master"
        const val DELTAS_SUBCOLLECTION = "sync_deltas"
        const val FAMILIES_COLLECTION = "families"
        const val AID_RECORDS_COLLECTION = "aid_records"
        const val PROJECTS_COLLECTION = "projects"

        @Volatile
        private var INSTANCE: FirestoreSyncManager? = null

        fun getInstance(context: Context): FirestoreSyncManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: FirestoreSyncManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    /**
     * تهيئة الاتصال بـ Cloud Firestore وتفعيل التخزين المؤقت المحلي (Offline Persistence)
     */
    fun initialize() {
        if (isInitialized) return

        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }

            val db = FirebaseFirestore.getInstance()
            try {
                // تفعيل التخزين المؤقت المحلي لـ Firestore لدعم العمل بدون إنترنت أصلياً
                val settings = FirebaseFirestoreSettings.Builder()
                    .setPersistenceEnabled(true)
                    .build()
                db.firestoreSettings = settings
            } catch (e: Exception) {
                Log.w(TAG, "Firestore settings adjustment note: ${e.message}")
            }

            firestore = db
            isInitialized = true
            _isConnected.value = true
            Log.i(TAG, "Google Cloud Firestore Master Node initialized successfully with offline persistence.")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Firestore: ${e.message}", e)
            _isConnected.value = false
        }
    }

    fun getFirestoreInstance(): FirebaseFirestore? {
        if (!isInitialized) initialize()
        return firestore
    }

    /**
     * تشغيل مستمعات SnapshotListeners الحية للمراقبة اللحظية وتحديث Room
     * @param database قاعدة بيانات Room المحلية لتحديثها مباشرة
     * @param userLocalityId إذا كانت 0 يستمع لكافة التعديلات (مدير النظام)، أو يقيد بمحلية معينة
     */
    fun startRealtimeListener(database: AidDatabase, userLocalityId: Int = 0) {
        val db = getFirestoreInstance()
        if (db == null) {
            Log.w(TAG, "Firestore instance is null. Cannot start realtime listener.")
            return
        }

        stopRealtimeListener()

        try {
            val deltasRef = db.collection(ROOT_COLLECTION)
                .document("deltas_hub")
                .collection(DELTAS_SUBCOLLECTION)

            // بناء الاستعلام: إما لكافة المحليات أو للمحلية المخصصة
            val query = if (userLocalityId > 0) {
                deltasRef.whereEqualTo("localityId", userLocalityId)
                    .orderBy("clientTimestamp", Query.Direction.DESCENDING)
                    .limit(100)
            } else {
                deltasRef.orderBy("clientTimestamp", Query.Direction.DESCENDING)
                    .limit(100)
            }

            val registration = query.addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.e(TAG, "SnapshotListener error: ${error.message}")
                    _isConnected.value = false
                    return@addSnapshotListener
                }

                _isConnected.value = true
                if (snapshots == null || snapshots.isEmpty) return@addSnapshotListener

                scope.launch {
                    processIncomingSnapshots(snapshots, database)
                }
            }

            listenerRegistrations["DELTAS_HUB"] = registration
            _isListening.value = true
            Log.i(TAG, "SnapshotListener active on Firestore Master Node for locality: $userLocalityId")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start SnapshotListener: ${e.message}", e)
        }
    }

    fun stopRealtimeListener() {
        listenerRegistrations.values.forEach { it.remove() }
        listenerRegistrations.clear()
        _isListening.value = false
    }

    /**
     * معالجة الوثائق الواردة وتطبيق خوارزمية حل النزاعات ودمجها في Room
     */
    private suspend fun processIncomingSnapshots(snapshots: QuerySnapshot, database: AidDatabase) {
        for (docChange in snapshots.documentChanges) {
            if (docChange.type == DocumentChange.Type.ADDED || docChange.type == DocumentChange.Type.MODIFIED) {
                val data = docChange.document.data
                val delta = FirestoreSyncDelta.fromFirestoreMap(data)

                // تخطي الحركات الصادرة من هذا الجهاز نفسه لمنع ارتداد الحركات (Echo Prevention)
                if (delta.deviceId.isNotBlank() && delta.deviceId == deviceId) {
                    continue
                }

                // تطبيق خوارزمية حل النزاعات (Conflict Resolution)
                val decision = ConflictResolver.resolve(
                    incomingDelta = delta,
                    localRecordRole = null, // يفحص من قاعدة البيانات
                    localTimestamp = null
                )

                when (decision) {
                    ConflictResolver.ConflictDecision.DISCARD -> {
                        Log.d(TAG, "Delta ${delta.deltaId} discarded by ConflictResolver.")
                    }
                    ConflictResolver.ConflictDecision.APPLY,
                    ConflictResolver.ConflictDecision.OVERRIDE_LOCAL -> {
                        if (decision == ConflictResolver.ConflictDecision.OVERRIDE_LOCAL) {
                            _adminOverridesCount.value += 1
                        }
                        // الدمج الفعلي في Room DB
                        mergeDeltaIntoRoom(delta, database)
                    }
                }
            }
        }
    }

    /**
     * دمج التعديل القادم من سحابة Firestore داخل جداول Room DB المحلية
     */
    private suspend fun mergeDeltaIntoRoom(delta: FirestoreSyncDelta, database: AidDatabase) {
        withContext(Dispatchers.IO) {
            try {
                when (delta.entityType) {
                    "AID_RECORD" -> {
                        val recordId = delta.recordId.toLongOrNull() ?: return@withContext
                        val json = JSONObject(delta.payloadJson)

                        val existing = database.aidRecordDao().getAidRecordById(recordId)
                        val recipientStatus = json.optString("recipientStatus", existing?.recipientStatus ?: "مستلم")
                        val actualDeliveryDate = json.optString("deliveryDate", existing?.deliveryDate ?: "2026-10-22")
                        val notes = json.optString("notes", existing?.notes)

                        database.aidRecordDao().updateDeliveryStatus(
                            recordId = recordId,
                            status = recipientStatus,
                            deliveryDate = actualDeliveryDate,
                            notes = notes
                        )
                        Log.i(TAG, "Merged AID_RECORD #$recordId into Room from Firestore.")
                    }

                    "FAMILY" -> {
                        val familyId = delta.recordId.toLongOrNull() ?: return@withContext
                        val json = JSONObject(delta.payloadJson)

                        val devApproval = json.optString("developmentApproval", "معتمد")
                        val resStatus = json.optString("residentStatus", "مقيم")
                        val shelter = json.optString("shelterStatus", "إيواء داخلي")

                        database.familyDao().updateFamilyStatus(
                            familyId = familyId,
                            developmentApproval = devApproval,
                            residentStatus = resStatus,
                            shelterStatus = shelter
                        )
                        Log.i(TAG, "Merged FAMILY #$familyId into Room from Firestore.")
                    }

                    "PROJECT" -> {
                        val projectId = delta.recordId.toLongOrNull() ?: return@withContext
                        val json = JSONObject(delta.payloadJson)
                        val isActive = json.optBoolean("isActive", true)
                        val projectName = json.optString("projectName", "مشروع إنساني جديد")
                        val projectNumber = json.optString("projectNumber", "")
                        database.projectDao().setProjectActive(projectId, isActive)

                        // إرسال إشعار محلي فوري عند طرح أو تحديث مشروع جديد عبر سيرفرات جوجل المركزية
                        try {
                            com.humanitarian.aidmanagement.notifications.AidNotificationHelper.notifyNewProjectCreated(
                                context = context,
                                projectName = projectName,
                                projectNumber = projectNumber
                            )
                        } catch (e: Exception) {
                            Log.w(TAG, "Notification failed for project #$projectId: ${e.message}")
                        }
                        Log.i(TAG, "Merged PROJECT #$projectId into Room from Firestore.")
                    }
                }

                _lastMergedDelta.value = delta
                _totalMergedCount.value += 1

                val currentList = _recentDeltas.value.toMutableList()
                currentList.add(0, delta)
                if (currentList.size > 50) currentList.removeAt(currentList.lastIndex)
                _recentDeltas.value = currentList

                // تسجيل في جدول التدقيق الأمني
                database.auditLogDao().insertLog(
                    AuditLogEntity(
                        userId = delta.userId,
                        userName = delta.userName,
                        userFullName = if (delta.isMasterAdminOverride) "مدير النظام (Master)" else "مشرف محلية (${delta.localityName})",
                        operationType = "مزامنة لحظية (${delta.operation})",
                        targetTable = delta.entityType,
                        recordId = delta.recordId,
                        description = "تم دمج التعديل لحظياً من Google Firestore: ${delta.operation} على السجل #${delta.recordId}"
                    )
                )
            } catch (e: Exception) {
                Log.e(TAG, "Failed to merge delta into Room: ${e.message}", e)
            }
        }
    }

    /**
     * رفع حركة Delta محلية إلى Google Cloud Firestore
     */
    suspend fun pushDelta(delta: FirestoreSyncDelta): Boolean = withContext(Dispatchers.IO) {
        val db = getFirestoreInstance() ?: return@withContext false

        suspendCancellableCoroutine { continuation ->
            try {
                val docRef = db.collection(ROOT_COLLECTION)
                    .document("deltas_hub")
                    .collection(DELTAS_SUBCOLLECTION)
                    .document(delta.deltaId)

                docRef.set(delta.toFirestoreMap(), SetOptions.merge())
                    .addOnSuccessListener {
                        _totalUploadedCount.value += 1
                        Log.d(TAG, "Delta ${delta.deltaId} pushed to Firestore Master Node successfully.")
                        continuation.resume(true)
                    }
                    .addOnFailureListener { e ->
                        Log.e(TAG, "Failed to push delta ${delta.deltaId} to Firestore: ${e.message}")
                        continuation.resume(false)
                    }
            } catch (e: Exception) {
                Log.e(TAG, "Exception pushing delta to Firestore: ${e.message}", e)
                continuation.resume(false)
            }
        }
    }

    /**
     * فحص الاتصال بخوادم Google Firestore
     */
    suspend fun pingFirestore(): Boolean = withContext(Dispatchers.IO) {
        val db = getFirestoreInstance() ?: return@withContext false
        suspendCancellableCoroutine { continuation ->
            db.collection(ROOT_COLLECTION).document("health_check")
                .set(mapOf("lastPing" to FieldValue.serverTimestamp(), "deviceId" to deviceId))
                .addOnSuccessListener {
                    _isConnected.value = true
                    continuation.resume(true)
                }
                .addOnFailureListener {
                    continuation.resume(false)
                }
        }
    }
}
