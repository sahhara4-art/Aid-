package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.NominationCandidate
import com.humanitarian.aidmanagement.engine.ProjectDispatchInfo
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NominationResultsScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateHome: () -> Unit
) {
    val candidatesList = remember { mutableStateListOf<NominationCandidate>() }
    var isConfirming by remember { mutableStateOf(false) }
    var isSuccessDialogOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val localities by repository.getLocalities().collectAsState(initial = emptyList())
    val aidTypes by repository.getActiveAidTypes().collectAsState(initial = emptyList())

    val todayStr = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    // بيانات المشروع المنفذ واعتماد أين يتم ترحيله
    var dispatchTargetAidId by remember { mutableStateOf(1) }
    var dispatchNominationDate by remember { mutableStateOf(todayStr) }
    var dispatchProjectNumber by remember { mutableStateOf("PRJ-2025-089") }
    var dispatchAidTypeName by remember { mutableStateOf("طرد غذائي عائلي طارئ") }
    var dispatchFundingOrg by remember { mutableStateOf("برنامج الأغذية العالمي WFP") }
    var dispatchWarehouse by remember { mutableStateOf("المستودع المركزي - دير البلح") }
    var dispatchAidValue by remember { mutableStateOf("250 ₪") }

    var expandedCandidateId by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(Unit) {
        val cached = repository.getLatestNominatedCandidates()
        if (!cached.isNullOrEmpty()) {
            candidatesList.clear()
            candidatesList.addAll(cached)
        } else {
            val initialCandidates = repository.runNomination(null, 1, 1L, 100)
            candidatesList.clear()
            candidatesList.addAll(initialCandidates)
        }
    }

    val manualCount = candidatesList.count { it.selectionType == "يدوي" }
    val autoCount = candidatesList.count { it.selectionType == "آلي" }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ترحيل واعتماد المرشحين وبيانات المشروع", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "الإجمالي: ${candidatesList.size} أسرة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "($manualCount يدوي + $autoCount آلي)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }

                    Button(
                        onClick = {
                            scope.launch {
                                isConfirming = true
                                val info = ProjectDispatchInfo(
                                    targetAidTypeId = dispatchTargetAidId,
                                    projectNumber = dispatchProjectNumber,
                                    nominationDate = dispatchNominationDate,
                                    aidTypeName = dispatchAidTypeName,
                                    fundingOrganization = dispatchFundingOrg,
                                    warehouseName = dispatchWarehouse,
                                    aidValue = dispatchAidValue
                                )
                                repository.dispatchNominatedAid(candidatesList, info)
                                isConfirming = false
                                isSuccessDialogOpen = true
                            }
                        },
                        enabled = candidatesList.isNotEmpty() && !isConfirming,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        if (isConfirming) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                        } else {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اعتماد وترحيل المساعدة رسمياً")
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(paddingValues)
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 20.dp)
        ) {
            // كرت بيانات المشروع المنفذ واعتماد الترحيل
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "بيانات المشروع المنفذ واعتماد الترحيل",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // وجهة الترحيل - أي تصنيف
                        Text("اعتماد أين يتم ترحيله (أي تصنيف):", style = MaterialTheme.typography.labelMedium)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            aidTypes.forEach { cat ->
                                FilterChip(
                                    selected = dispatchTargetAidId == cat.aidTypeID,
                                    onClick = {
                                        dispatchTargetAidId = cat.aidTypeID
                                        dispatchAidTypeName = "مساعدة ${cat.aidTypeName} طارئة"
                                    },
                                    label = { Text("${cat.aidTypeID}. ${cat.aidTypeName}", fontSize = 11.sp) }
                                )
                            }
                        }

                        // شبكة إدخال بيانات المشروع
                        OutlinedTextField(
                            value = dispatchNominationDate,
                            onValueChange = { dispatchNominationDate = it },
                            label = { Text("تاريخ الترشيح (تاريخ اليوم)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = dispatchProjectNumber,
                            onValueChange = { dispatchProjectNumber = it },
                            label = { Text("رقم المشروع (أكتبه أنا)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = dispatchAidTypeName,
                            onValueChange = { dispatchAidTypeName = it },
                            label = { Text("نوع المساعدة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = dispatchFundingOrg,
                            onValueChange = { dispatchFundingOrg = it },
                            label = { Text("المؤسسة الممولة") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = dispatchWarehouse,
                                onValueChange = { dispatchWarehouse = it },
                                label = { Text("المخزن") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = dispatchAidValue,
                                onValueChange = { dispatchAidValue = it },
                                label = { Text("قيمة المساعدة") },
                                modifier = Modifier.weight(1f),
                                singleLine = true
                            )
                        }
                    }
                }
            }

            // بطاقة الإحصائيات السريعة
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ترشيح يدوي", style = MaterialTheme.typography.bodySmall)
                            Text("$manualCount", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0284C7))
                        }
                        Divider(modifier = Modifier.height(28.dp).width(1.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("ترشيح آلي مكتمل", style = MaterialTheme.typography.bodySmall)
                            Text("$autoCount", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                        }
                        Divider(modifier = Modifier.height(28.dp).width(1.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("الإجمالي", style = MaterialTheme.typography.bodySmall)
                            Text("${candidatesList.size}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }

            item {
                Text(
                    text = "كشف المرشحين مع بيان آخر استفادة من كل تصنيف وتاريخها:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // كشف المرشحين
            itemsIndexed(candidatesList, key = { _, item -> item.family.familyID }) { index, candidate ->
                val locName = localities.find { it.LocalityID == candidate.family.localityID }?.LocalityName ?: "المحلية"
                val isExpanded = expandedCandidateId == candidate.family.familyID

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = "${index + 1}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = candidate.family.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (candidate.selectionType == "يدوي") Color(0xFF0284C7).copy(alpha = 0.15f)
                                        else Color(0xFF10B981).copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = candidate.selectionType,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (candidate.selectionType == "يدوي") Color(0xFF0284C7) else Color(0xFF10B981),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = "رقم الهوية: ${candidate.family.nationalID} • محلية: $locName • هاتف: ${candidate.family.primaryPhone}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                    fontWeight = FontWeight.Medium
                                )

                                Text(
                                    text = "${candidate.family.familyMembersCount} أفراد • ${candidate.family.shelterStatus} • ${candidate.family.damageType} • ${candidate.family.worksApproval} • أولوية: ${candidate.priorityScore.toInt()} نقطة",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            IconButton(onClick = { candidatesList.remove(candidate) }) {
                                Icon(Icons.Default.Close, contentDescription = "إزالة الأسرة", tint = MaterialTheme.colorScheme.error)
                            }
                        }

                        // سجل آخر استفادة من كل تصنيف وتاريخ آخر استفادة
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "آخر استفادة من كل تصنيف وتاريخها:",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFD97706)
                                    )
                                    TextButton(
                                        onClick = {
                                            expandedCandidateId = if (isExpanded) null else candidate.family.familyID
                                        },
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Text(
                                            if (isExpanded) "طي التفاصيل ▲" else "عرض الـ 11 تصنيف ▼",
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                }

                                val displayedHistories = if (isExpanded) {
                                    candidate.categoryHistories
                                } else {
                                    candidate.categoryHistories.take(4)
                                }

                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    displayedHistories.forEach { hist ->
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (hist.lastDate != null) Color(0xFF065F46).copy(alpha = 0.2f)
                                            else MaterialTheme.colorScheme.surfaceVariant,
                                            border = androidx.compose.foundation.BorderStroke(
                                                0.5.dp,
                                                if (hist.lastDate != null) Color(0xFF10B981) else Color.Gray.copy(alpha = 0.3f)
                                            )
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "${hist.categoryId}. ${hist.categoryName}:",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = hist.lastDate ?: "لم يستفد قط",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (hist.lastDate != null) Color(0xFF10B981) else Color.Gray,
                                                    fontWeight = if (hist.lastDate != null) FontWeight.Bold else FontWeight.Normal
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (isSuccessDialogOpen) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("تم اعتماد وترحيل المساعدة رسمياً بنجاح") },
            text = {
                Text(
                    "تم اعتماد وترحيل ${candidatesList.size} أسرة مرشحة للتصنيف رقم $dispatchTargetAidId.\n" +
                    "رقم المشروع: $dispatchProjectNumber\n" +
                    "المؤسسة: $dispatchFundingOrg\n" +
                    "المخزن: $dispatchWarehouse\n" +
                    "تاريخ الترشيح: $dispatchNominationDate"
                )
            },
            confirmButton = {
                Button(onClick = {
                    isSuccessDialogOpen = false
                    onNavigateHome()
                }) {
                    Text("العودة للوحة التحكم")
                }
            }
        )
    }
}
