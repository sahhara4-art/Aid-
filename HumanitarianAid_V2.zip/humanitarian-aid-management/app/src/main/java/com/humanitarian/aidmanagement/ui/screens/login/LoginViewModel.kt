package com.humanitarian.aidmanagement.ui.screens.login

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.biometric.BiometricManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.repository.AidRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * حالة واجهة المستخدم لشاشة تسجيل الدخول
 */
data class LoginUiState(
    val username: String = "",
    val password: String = "",
    val passwordVisible: Boolean = false,
    val rememberMe: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val isBiometricSupported: Boolean = false,
    val hasEnrolledBiometrics: Boolean = false,
    val hasSavedCredentials: Boolean = false,
    val canLoginWithBiometric: Boolean = false
)

/**
 * ViewModel لإدارة تسجيل الدخول، الحفظ المشفر لبيانات الاعتماد (تذكرني)، والمصادقة بالبصمة
 */
class LoginViewModel(
    application: Application,
    private val database: AidDatabase,
    private val repository: AidRepository
) : AndroidViewModel(application) {

    private val prefs: SharedPreferences = createSecurePreferences(application)

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    private var hasAutoPromptedBiometric = false

    init {
        loadSavedCredentials()
        checkBiometricStatus()
    }

    private fun createSecurePreferences(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                "secure_aid_login_prefs",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            context.getSharedPreferences("secure_aid_login_prefs", Context.MODE_PRIVATE)
        }
    }

    /**
     * تحميل بيانات الدخول المحفوظة مسبقاً إذا تم اختيار "تذكر بيانات الدخول"
     */
    private fun loadSavedCredentials() {
        val isRemembered = prefs.getBoolean(KEY_REMEMBER_ME, false)
        val savedUser = prefs.getString(KEY_SAVED_USERNAME, "") ?: ""
        val savedPass = prefs.getString(KEY_SAVED_PASSWORD, "") ?: ""

        val hasValidSaved = isRemembered && savedUser.isNotBlank() && savedPass.isNotBlank()

        _uiState.update {
            it.copy(
                username = if (hasValidSaved) savedUser else "",
                password = if (hasValidSaved) savedPass else "",
                rememberMe = isRemembered,
                hasSavedCredentials = hasValidSaved
            )
        }
    }

    /**
     * التحقق من دعم الجهاز للبصمة ووجود بيانات اعتماد محفوظة للدخول الفوري
     */
    fun checkBiometricStatus() {
        val context = getApplication<Application>()
        val biometricManager = BiometricManager.from(context)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL

        val authStatus = biometricManager.canAuthenticate(authenticators)
        val isSupported = authStatus != BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE &&
                authStatus != BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE
        val hasEnrolled = authStatus == BiometricManager.BIOMETRIC_SUCCESS

        val hasSaved = _uiState.value.hasSavedCredentials

        _uiState.update {
            it.copy(
                isBiometricSupported = isSupported,
                hasEnrolledBiometrics = hasEnrolled,
                canLoginWithBiometric = hasEnrolled && hasSaved
            )
        }
    }

    fun onUsernameChange(newUsername: String) {
        _uiState.update { it.copy(username = newUsername, errorMessage = null) }
    }

    fun onPasswordChange(newPassword: String) {
        _uiState.update { it.copy(password = newPassword, errorMessage = null) }
    }

    fun togglePasswordVisibility() {
        _uiState.update { it.copy(passwordVisible = !it.passwordVisible) }
    }

    fun onRememberMeChange(checked: Boolean) {
        _uiState.update { it.copy(rememberMe = checked) }
    }

    fun setErrorMessage(msg: String?) {
        _uiState.update { it.copy(errorMessage = msg, isLoading = false) }
    }

    fun shouldAutoPromptBiometric(): Boolean {
        if (!hasAutoPromptedBiometric && _uiState.value.canLoginWithBiometric) {
            hasAutoPromptedBiometric = true
            return true
        }
        return false
    }

    /**
     * تسجيل الدخول التقليدي بالاسم وكلمة المرور
     */
    fun login(onSuccess: () -> Unit) {
        val usernameInput = _uiState.value.username.trim()
        val passwordInput = _uiState.value.password

        if (usernameInput.isBlank() || passwordInput.isBlank()) {
            setErrorMessage("يرجى إدخال اسم المستخدم وكلمة المرور")
            return
        }

        executeLogin(usernameInput, passwordInput, onSuccess)
    }

    /**
     * تسجيل الدخول التلقائي عند نجاح فحص البصمة باستخدام بيانات الدخول المشفرة المحفوظة
     */
    fun loginWithBiometric(onSuccess: () -> Unit) {
        val savedUser = prefs.getString(KEY_SAVED_USERNAME, "") ?: ""
        val savedPass = prefs.getString(KEY_SAVED_PASSWORD, "") ?: ""

        if (savedUser.isBlank() || savedPass.isBlank()) {
            setErrorMessage("لا توجد بيانات دخول محفوظة للبصمة. يرجى تسجيل الدخول أولاً واختيار 'تذكر بيانات الدخول'")
            return
        }

        executeLogin(savedUser, savedPass, onSuccess)
    }

    private fun executeLogin(userStr: String, passStr: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val currentTime = System.currentTimeMillis()
            val user = database.userDao().getUserByUsername(userStr)

            if (user == null) {
                setErrorMessage("اسم المستخدم أو كلمة المرور غير صحيحة")
                return@launch
            }

            // 1. التحقق من قفل الحساب
            if (user.LockedUntil != null && user.LockedUntil > currentTime) {
                val remainingMinutes = ((user.LockedUntil - currentTime) / (1000 * 60)) + 1
                setErrorMessage("تم قفل الحساب مؤقتًا لتجاوز محاولات الدخول. يرجى الانتظار $remainingMinutes دقيقة.")
                return@launch
            }

            // 2. التحقق من تفعيل الحساب
            if (!user.IsActive) {
                setErrorMessage("هذا الحساب معطل، يرجى مراجعة إدارة المنظومة.")
                return@launch
            }

            // 3. فحص كلمة المرور
            if (user.PasswordHash != passStr) {
                val newAttempts = user.FailedAttempts + 1
                if (newAttempts >= 5) {
                    val lockDuration = 15 * 60 * 1000L // 15 دقيقة
                    database.userDao().lockUser(user.UserName, currentTime + lockDuration)
                    setErrorMessage("تم تجاوز الحد الأقصى للمحاولات (5 محاولات). تم قفل الحساب لمدة 15 دقيقة.")
                } else {
                    database.userDao().incrementFailedAttempts(user.UserName)
                    val remaining = 5 - newAttempts
                    setErrorMessage("كلمة المرور غير صحيحة. متبقي لديك $remaining محاولات قبل قفل الحساب.")
                }
                return@launch
            }

            // 4. تسجيل دخول ناجح: تصفير المحاولات الفاشلة وتحديث التوقيت
            database.userDao().resetFailedAttempts(user.UserID, currentTime)
            val localityIds = database.userDao().getUserLocalityIds(user.UserID)
            repository.setCurrentUser(user, localityIds)

            // 5. حفظ أو إزالة بيانات الاعتماد وفق خيار "تذكرني"
            val shouldRemember = _uiState.value.rememberMe
            prefs.edit().apply {
                putBoolean(KEY_REMEMBER_ME, shouldRemember)
                if (shouldRemember) {
                    putString(KEY_SAVED_USERNAME, userStr)
                    putString(KEY_SAVED_PASSWORD, passStr)
                } else {
                    remove(KEY_SAVED_USERNAME)
                    remove(KEY_SAVED_PASSWORD)
                }
                apply()
            }

            _uiState.update { it.copy(isLoading = false, errorMessage = null) }
            onSuccess()
        }
    }

    companion object {
        private const val KEY_REMEMBER_ME = "pref_remember_me"
        private const val KEY_SAVED_USERNAME = "pref_saved_username"
        private const val KEY_SAVED_PASSWORD = "pref_saved_password"
    }

    class Factory(
        private val application: Application,
        private val database: AidDatabase,
        private val repository: AidRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
                return LoginViewModel(application, database, repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
