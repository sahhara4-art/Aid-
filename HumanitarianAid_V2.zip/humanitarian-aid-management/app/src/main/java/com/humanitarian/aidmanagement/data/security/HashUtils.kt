package com.humanitarian.aidmanagement.data.security

import java.security.MessageDigest

object HashUtils {
    fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(plainPassword: String, storedHash: String?): Boolean {
        if (storedHash == null) return false
        // يدعم التحقق المباشر (مثل admin123 للمستخدمين الأوليين) أو تجزئة SHA-256
        if (plainPassword == storedHash) return true
        val hashed = sha256(plainPassword)
        return hashed.equals(storedHash, ignoreCase = true)
    }
}
