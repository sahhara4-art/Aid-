package com.humanitarian.aidmanagement.sync

import android.util.Log
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * ConflictResolver - خوارزمية حل النزاعات والتعارضات السحابية المتقدمة
 *
 * القواعد الصارمة:
 * 1. Override Priority: تعديلات حساب المدير العام (SUPER_ADMIN) لها الأولوية القصوى وتلغي أي تعديل متعارض من المحليات.
 * 2. ServerTimestamp Resolution: في حال تعارض تعديلات متكافئة الصلاحية، فإن السجل ذو الطابع الزمني الأحدث من خادم جوجل يفوز.
 * 3. Idempotency: منع التكرار وإعادة تطبيق الحركات القديمة عبر سجل معرفات ذكي (Deduplication Cache).
 */
object ConflictResolver {
    private const val TAG = "ConflictResolver"

    // سجل الحركات المعالجة لمنع تكرار الأحداث (Deduplication Cache)
    private val processedDeltaIds = Collections.synchronizedSet(HashSet<String>())

    // خريطة تتبع آخر تعديل لكل سجل محلي (RecordId -> LastDelta)
    private val recordLastModificationMap = ConcurrentHashMap<String, FirestoreSyncDelta>()

    enum class ConflictDecision {
        APPLY,      // تطبيق الحركة (إما لعدم وجود تعارض أو لأن الحركة تملك أولوية أعلى)
        DISCARD,    // تجاهل الحركة (لأن السجل المحلي أحدث أو تم تعديله بواسطة المدير)
        OVERRIDE_LOCAL // الحركة قادمة من المدير وتلغي التعديل المحلي القائم
    }

    /**
     * فحص ما إذا كانت الحركة مكررة تم دمجها مسبقاً
     */
    fun isDuplicate(deltaId: String): Boolean {
        return processedDeltaIds.contains(deltaId)
    }

    /**
     * تقييم النزاع وحله بناءً على معايير الصلاحية والطابع الزمني للخادم
     *
     * @param incomingDelta الحركة القادمة من Firestore
     * @param localRecordRole صفة صاحب آخر تعديل محلي ("SUPER_ADMIN" أو "LOCALITY_SUPERVISOR")
     * @param localTimestamp وقت آخر تعديل محلي
     */
    fun resolve(
        incomingDelta: FirestoreSyncDelta,
        localRecordRole: String? = null,
        localTimestamp: Long? = null
    ): ConflictDecision {
        val deltaKey = "${incomingDelta.entityType}_${incomingDelta.recordId}"

        // 1. فحص التكرار (Idempotency)
        if (processedDeltaIds.contains(incomingDelta.deltaId)) {
            Log.d(TAG, "Delta ${incomingDelta.deltaId} already processed. Discarding duplicate.")
            return ConflictDecision.DISCARD
        }

        // 2. الشرط الصارم الأول: تعديل المدير له الأولوية القصوى (Override Priority)
        if (incomingDelta.isMasterAdminOverride || incomingDelta.userRole.equals("SUPER_ADMIN", ignoreCase = true)) {
            Log.i(TAG, "👑 Master Admin Override applied for $deltaKey from user ${incomingDelta.userName}.")
            markProcessed(incomingDelta)
            return ConflictDecision.OVERRIDE_LOCAL
        }

        // 3. الشرط الصارم الثاني: إذا كان التعديل المحلي السابق صادراً من المدير، فإنه يحجب تعديلات المحليات
        if (localRecordRole != null && localRecordRole.equals("SUPER_ADMIN", ignoreCase = true)) {
            Log.w(TAG, "🛡️ Rejecting locality delta for $deltaKey: Protected by previous Master Admin edit.")
            markProcessed(incomingDelta)
            return ConflictDecision.DISCARD
        }

        // 4. خوارزمية الطابع الزمني ServerTimestamp للتعارضات بين المحليات
        val incomingTime = incomingDelta.serverTimestamp ?: incomingDelta.clientTimestamp
        val lastLocalTime = localTimestamp ?: recordLastModificationMap[deltaKey]?.let {
            it.serverTimestamp ?: it.clientTimestamp
        } ?: 0L

        if (incomingTime >= lastLocalTime) {
            Log.d(TAG, "Applying newer delta for $deltaKey (incoming: $incomingTime >= local: $lastLocalTime)")
            markProcessed(incomingDelta)
            return ConflictDecision.APPLY
        } else {
            Log.w(TAG, "Discarding outdated delta for $deltaKey (incoming: $incomingTime < local: $lastLocalTime)")
            markProcessed(incomingDelta)
            return ConflictDecision.DISCARD
        }
    }

    private fun markProcessed(delta: FirestoreSyncDelta) {
        processedDeltaIds.add(delta.deltaId)
        val deltaKey = "${delta.entityType}_${delta.recordId}"
        recordLastModificationMap[deltaKey] = delta

        // تنظيف الكاش عند تضخمه للحفاظ على خفة الذاكرة
        if (processedDeltaIds.size > 20000) {
            val toRemove = processedDeltaIds.take(5000)
            processedDeltaIds.removeAll(toRemove.toSet())
        }
    }

    fun clearCache() {
        processedDeltaIds.clear()
        recordLastModificationMap.clear()
    }
}
