package com.humanitarian.aidmanagement.ui.screens.projects

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.data.repository.ProjectWithStats
import com.humanitarian.aidmanagement.ui.theme.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * شاشة إدارة المشاريع الإنسانية المنفذة (ProjectsScreen)
 * تعرض قائمة بطاقات بالمشاريع المنفذة مع:
 * (اسم/رقم المشروع، نوع المساعدة، العدد الكلي المستهدف، عدد المرشحين، وعدد المستلمين الفعليين)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreen(
    repository: AidRepository,
    onNavigateBack: () -> Unit,
    onNavigateToProjectDetails: (Long) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var searchQuery by remember { mutableStateOf("") }
    var projectsList by remember { mutableStateOf<List<ProjectWithStats>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var projectToDelete by remember { mutableStateOf<com.humanitarian.aidmanagement.data.local.entities.ProjectEntity?>(null) }

    LaunchedEffect(Unit) {
        isLoading = true
        projectsList = repository.getProjectsWithStats()
        isLoading = false
    }

    val filteredProjects = remember(projectsList, searchQuery) {
        if (searchQuery.isBlank()) {
            projectsList
        } else {
            val q = searchQuery.trim().lowercase()
            projectsList.filter {
                it.project.projectName.lowercase().contains(q) ||
                it.project.projectNumber.lowercase().contains(q) ||
                it.aidTypeName.lowercase().contains(q) ||
                it.project.fundingInstitution.lowercase().contains(q)
            }
        }
    }

    val totalTarget = remember(projectsList) { projectsList.sumOf { it.project.quantity } }
    val totalCandidates = remember(projectsList) { projectsList.sumOf { it.candidatesCount } }
    val totalDelivered = remember(projectsList) { projectsList.sumOf { it.deliveredCount } }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "المشاريع الإنسانية المنفذة",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${projectsList.size} مشاريع مسجلة في المنظومة",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "رجوع")
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            coroutineScope.launch {
                                isLoading = true
                                projectsList = repository.getProjectsWithStats()
                                isLoading = false
                            }
                        }) {
                            Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = PalestineGreen)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // إحصائيات علوية سريعة للمشاريع
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ProjectQuickMetric(
                            title = "المستهدف الكلي",
                            value = "$totalTarget",
                            icon = Icons.Default.TrackChanges,
                            color = PalestineGreen
                        )
                        Divider(modifier = Modifier.height(30.dp).width(1.dp), color = SlateBorder)
                        ProjectQuickMetric(
                            title = "المرشحون",
                            value = "$totalCandidates",
                            icon = Icons.Default.HowToReg,
                            color = Color(0xFF3B82F6)
                        )
                        Divider(modifier = Modifier.height(30.dp).width(1.dp), color = SlateBorder)
                        ProjectQuickMetric(
                            title = "المستلمون الفعليون",
                            value = "$totalDelivered",
                            icon = Icons.Default.CheckCircle,
                            color = Color(0xFF10B981)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // شريط البحث
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("بحث برقم المشروع، الاسم، نوع المعونة أو الجهة الممولة...", fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = PalestineGreen) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = PalestineGreen)
                    }
                } else if (filteredProjects.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                Icons.Default.FolderOpen,
                                contentDescription = null,
                                modifier = Modifier.size(54.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                            )
                            Text(
                                text = "لا توجد مشاريع منفذة مطابقة للبحث",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 24.dp)
                    ) {
                        items(filteredProjects, key = { it.project.projectID }) { projectStat ->
                            ProjectCardItem(
                                item = projectStat,
                                onClick = { onNavigateToProjectDetails(projectStat.project.projectID) },
                                onDelete = { projectToDelete = projectStat.project }
                            )
                        }
                    }
                }
            }
        }

        if (projectToDelete != null) {
            com.humanitarian.aidmanagement.ui.components.TypeToConfirmDeleteDialog(
                title = "حذف المشروع وسجلاته نهائياً",
                itemTypeLabel = "المشروع",
                expectedName = projectToDelete!!.projectName,
                onConfirm = {
                    val prj = projectToDelete!!
                    projectToDelete = null
                    coroutineScope.launch {
                        repository.deleteProject(prj.projectID)
                        isLoading = true
                        projectsList = repository.getProjectsWithStats()
                        isLoading = false
                    }
                },
                onDismiss = { projectToDelete = null }
            )
        }
    }
}

/**
 * بطاقة المشروع المنفذ
 * تعرض: (اسم/رقم المشروع، نوع المساعدة، العدد الكلي المستهدف، عدد المرشحين، وعدد المستلمين الفعليين)
 */
@Composable
fun ProjectCardItem(
    item: ProjectWithStats,
    onClick: () -> Unit,
    onDelete: (() -> Unit)? = null
) {
    val project = item.project
    val percentDelivered = if (project.quantity > 0) {
        ((item.deliveredCount.toDouble() / project.quantity.toDouble()) * 100).toInt().coerceIn(0, 100)
    } else {
        0
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // ترويسة البطاقة: اسم المشروع ورقمه ونوع المساعدة وزر الحذف
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = project.projectName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "رقم المشروع: ${project.projectNumber} • ${project.fundingInstitution}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = PalestineGreenContainer
                    ) {
                        Text(
                            text = item.aidTypeName,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = PalestineGreen,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    if (onDelete != null) {
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "حذف المشروع",
                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // مصفوفة الأعداد المطلوبة في نص السؤال بدقة:
            // (العدد الكلي المستهدف، عدد المرشحين، وعدد المستلمين الفعليين)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SlateSurfaceVariant)
                    .padding(vertical = 10.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                MetricColumn(
                    title = "العدد المستهدف",
                    value = "${project.quantity}",
                    color = MaterialTheme.colorScheme.onSurface
                )
                Divider(modifier = Modifier.height(24.dp).width(1.dp), color = SlateBorder)
                MetricColumn(
                    title = "عدد المرشحين",
                    value = "${item.candidatesCount}",
                    color = Color(0xFF2563EB)
                )
                Divider(modifier = Modifier.height(24.dp).width(1.dp), color = SlateBorder)
                MetricColumn(
                    title = "المستلمون الفعليون",
                    value = "${item.deliveredCount}",
                    color = Color(0xFF059669)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // شريط تقدم الإنجاز والتسليم
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "نسبة التنفيذ والتسليم الفعلي:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "$percentDelivered%",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = if (percentDelivered >= 80) PalestineGreen else if (percentDelivered >= 40) Color(0xFFF59E0B) else PalestineRed
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { percentDelivered / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (percentDelivered >= 80) PalestineGreen else if (percentDelivered >= 40) Color(0xFFF59E0B) else PalestineRed,
                trackColor = SlateBorder
            )

            Spacer(modifier = Modifier.height(10.dp))

            // أسفل البطاقة: تاريخ المشروع وزر تفاصيل المستفيدين
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CalendarToday,
                        contentDescription = null,
                        modifier = Modifier.size(13.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "التاريخ: ${project.projectDate}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "عرض المستفيدين",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = PalestineGreen
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = PalestineGreen
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricColumn(
    title: String,
    value: String,
    color: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = SlateTextMuted,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun ProjectQuickMetric(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        }
        Column {
            Text(text = value, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
            Text(text = title, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
