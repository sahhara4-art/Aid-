package com.humanitarian.aidmanagement.sync

import android.content.Context
import android.util.Log
import com.humanitarian.aidmanagement.data.local.AidDatabase
import com.humanitarian.aidmanagement.data.local.entities.SyncQueueEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

enum class SyncConnectionStatus(val label: String) {
    ONLINE("متصل بالسحابة"),
    SYNCING("جاري التزامن..."),
    OFFLINE("غير متصل (محلي)")
}

data class SyncUiState(
    val connectionStatus: SyncConnectionStatus = SyncConnectionStatus.ONLINE,
    val isOnline: Boolean = true,
    val isSyncing: Boolean = false,
    val isMasterConnected: Boolean = true,
    val isListening: Boolean = true,
    val pendingCount: Int = 0,
    val totalUploaded: Int = 0,
    val totalMerged: Int = 0,
    val adminOverridesCount: Int = 0,
    val lastSyncTime: Long? = null,
    val lastSyncStatus: String? = null,
    val lastMergedDelta: FirestoreSyncDelta? = null,
    val recentDeltas: List<FirestoreSyncDelta> = emptyList(),
    // توافق مع الكود السابق
    val isSimulatedOffline: Boolean = false,
    val firebaseConnected: Boolean = true,
    val isMasterListenerActive: Boolean = true,
    val totalDeltasUploaded: Int = 0,
    val totalDeltasMerged: Int = 0
)

/**
 * SyncManager - المنسق العام لمنظومة التزامن السحابي المركزي اللحظي (MVI Pattern)
 *
 * يربط بين:
 * 1. قاعدة بيانات Room المحلية كـ "مصدر وحيد للحقيقة" (Single Source of Truth).
 * 2. خوادم Google Cloud Firestore كـ "Master Node" تديره الإدارة المركزية.
 * 3. نظام WorkManager مع قيود اتصال الشبكة للتزامن الخلفي التلقائي.
 * 4. مستمعات SnapshotListeners الفرعية فائقة السرعة للمفاضلة والدمج.
 */
object SyncManager {
    private const val TAG = "SyncManager"

    private var appContext: Context? = null
    private var database: AidDatabase? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _syncState = MutableStateFlow(SyncUiState())
    val syncState: StateFlow<SyncUiState> = _syncState.asStateFlow()

    private var connectivityObserver: NetworkConnectivityObserver? = null
    private var firestoreSyncManager: FirestoreSyncManager? = null

    fun initialize(context: Context, db: AidDatabase) {
        this.appContext = context.applicationContext
        this.database = db

        // 1. تهيئة مراقب الشبكة
        connectivityObserver = NetworkConnectivityObserver(context)

        // 2. تهيئة محرك Firestore
        val fsManager = FirestoreSyncManager.getInstance(context)
        this.firestoreSyncManager = fsManager
        fsManager.initialize()

        // 3. بدء جدولة WorkManager الخلفية مع قيود الشبكة
        FirestoreSyncWorker.schedulePeriodicSync(context)

        // 4. مراقبة طابور السجلات المعلقة في Room
        scope.launch {
            db.syncQueueDao().getPendingCountFlow().collect { count ->
                _syncState.update { current ->
                    current.copy(
                        pendingCount = count,
                        connectionStatus = if (!current.isOnline) SyncConnectionStatus.OFFLINE
                        else if (current.isSyncing) SyncConnectionStatus.SYNCING
                        else SyncConnectionStatus.ONLINE
                    )
                }
            }
        }

        // 5. مراقبة سجلات المزامنة التاريخية
        scope.launch {
            val lastLog = db.syncQueueDao().getLastSyncLog()
            if (lastLog != null) {
                _syncState.update {
                    it.copy(
                        lastSyncTime = lastLog.timestamp,
                        lastSyncStatus = lastLog.summary
                    )
                }
            }
        }

        // 6. مراقبة حالة اتصال الشبكة الفعلية
        scope.launch {
            connectivityObserver?.observe()?.collect { status ->
                val online = status == NetworkStatus.Available
                _syncState.update { current ->
                    current.copy(
                        isOnline = online,
                        connectionStatus = if (!online) SyncConnectionStatus.OFFLINE
                        else if (current.isSyncing) SyncConnectionStatus.SYNCING
                        else SyncConnectionStatus.ONLINE
                    )
                }

                if (online) {
                    Log.i(TAG, "Network connection restored. Enqueuing immediate Firestore sync...")
                    FirestoreSyncWorker.triggerImmediateSync(context)
                }
            }
        }

        // 7. مراقبة اتصال Firestore ومستمعات اللحظية
        scope.launch {
            fsManager.isConnected.collect { connected ->
                _syncState.update { current ->
                    current.copy(
                        isMasterConnected = connected,
                        firebaseConnected = connected
                    )
                }
            }
        }

        scope.launch {
            fsManager.isListening.collect { listening ->
                _syncState.update { it.copy(isListening = listening, isMasterListenerActive = listening) }
            }
        }

        scope.launch {
            fsManager.totalUploadedCount.collect { count ->
                _syncState.update { it.copy(totalUploaded = count, totalDeltasUploaded = count) }
            }
        }

        scope.launch {
            fsManager.totalMergedCount.collect { count ->
                _syncState.update { it.copy(totalMerged = count, totalDeltasMerged = count) }
            }
        }

        scope.launch {
            fsManager.adminOverridesCount.collect { count ->
                _syncState.update { it.copy(adminOverridesCount = count) }
            }
        }

        scope.launch {
            fsManager.lastMergedDelta.collect { delta ->
                _syncState.update { it.copy(lastMergedDelta = delta) }
            }
        }

        scope.launch {
            fsManager.recentDeltas.collect { deltas ->
                _syncState.update { it.copy(recentDeltas = deltas) }
            }
        }

        // تشغيل مستمع المزامنة الحية
        fsManager.startRealtimeListener(db, 0)
        Log.i(TAG, "SyncManager initialized with Google Cloud Firestore Master Node.")
    }

    /**
     * تشغيل مستمع المزامنة اللحظية بحسب الصلاحية والمحلية
     */
    fun startRealtimeSync(userLocalityId: Int = 0) {
        val db = database ?: return
        firestoreSyncManager?.startRealtimeListener(db, userLocalityId)
    }

    /**
     * إدراج حركة تعديل في طابور التزامن ومحاولة رفعها فورياً إلى Firestore
     */
    fun pushChange(
        entityType: String,
        operation: String,
        recordId: String,
        payloadJson: String
    ) {
        val db = database ?: return
        val context = appContext ?: return

        scope.launch {
            val syncQueueEntity = SyncQueueEntity(
                entityType = entityType,
                operation = operation,
                recordId = recordId,
                payloadJson = payloadJson,
                createdAt = System.currentTimeMillis(),
                status = "PENDING"
            )

            // 1. الحفظ أولاً في جدول Room DB محلياً (Offline-First Single Source of Truth)
            db.syncQueueDao().enqueue(syncQueueEntity)

            // 2. محاولة الرفع الفوري عبر WorkManager إذا كانت الشبكة متوفرة
            FirestoreSyncWorker.triggerImmediateSync(context)
        }
    }

    /**
     * إدراج حركة تعديل في طابور التزامن (متوافق مع كود AidRepository و WorkManager)
     */
    fun enqueueItem(
        entityType: String,
        operation: String,
        recordId: String,
        payloadJson: String
    ) {
        pushChange(entityType, operation, recordId, payloadJson)
    }

    /**
     * تشغيل مزامنة يدوية فورية بالضغط على الزر
     */
    fun triggerSyncNow() {
        val context = appContext ?: return
        val fsManager = firestoreSyncManager

        scope.launch {
            _syncState.update { it.copy(isSyncing = true, connectionStatus = SyncConnectionStatus.SYNCING) }
            try {
                fsManager?.pingFirestore()
                FirestoreSyncWorker.triggerImmediateSync(context)
                delay(1200) // لإظهار مؤشر التزامن اللحظي بسلاسة
            } finally {
                _syncState.update { current ->
                    current.copy(
                        isSyncing = false,
                        connectionStatus = if (current.isOnline) SyncConnectionStatus.ONLINE else SyncConnectionStatus.OFFLINE
                    )
                }
            }
        }
    }

    fun getPendingCountFlow(): Flow<Int> {
        val db = database ?: return flowOf(0)
        return db.syncQueueDao().getPendingCountFlow()
    }

    /**
     * محاكاة قطع/إعادة اتصال الإنترنت لاختبار قدرات Offline-First ميدانياً
     */
    fun toggleOfflineSimulation() {
        _syncState.update { current ->
            val newSimulated = !current.isSimulatedOffline
            val realOnline = connectivityObserver?.isCurrentlyOnline() ?: true
            val effectiveOnline = if (newSimulated) false else realOnline
            current.copy(
                isSimulatedOffline = newSimulated,
                isOnline = effectiveOnline,
                connectionStatus = if (!effectiveOnline) SyncConnectionStatus.OFFLINE else SyncConnectionStatus.ONLINE
            )
        }
    }
}
