package com.humanitarian.aidmanagement.util

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintManager
import androidx.core.content.FileProvider
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.engine.NominationCandidate
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * بيانات تقرير التوزيع لتوليد ملف PDF
 */
data class DistributionPdfReportData(
    val reportTitle: String,
    val projectName: String,
    val aidTypeName: String,
    val localityName: String,
    val date: String,
    val supervisorName: String,
    val candidates: List<NominationCandidate>,
    val notes: String? = null
)

/**
 * فئة تصدير تقارير التوزيع إلى PDF باستخدام مكتبة طباعة المستندات في أندرويد
 */
class PdfReportExporter(private val context: Context) {

    private val pageHeight = 842 // A4 Standard Height (points)
    private val pageWidth = 595  // A4 Standard Width (points)

    /**
     * توليد ملف PDF رسمي لكشف توزيع المساعدات مع دعم التعدد في الصفحات
     */
    fun generateDistributionReportPdf(data: DistributionPdfReportData): File {
        val pdfDocument = PdfDocument()

        val paint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
        }

        val titlePaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(13, 148, 136) // Teal / Emerald
            textSize = 16f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }

        val subtitlePaint = Paint().apply {
            isAntiAlias = true
            color = Color.DKGRAY
            textSize = 10f
            textAlign = Paint.Align.RIGHT
        }

        val headerCellPaint = Paint().apply {
            isAntiAlias = true
            color = Color.WHITE
            textSize = 9f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        val cellPaint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 8.5f
            textAlign = Paint.Align.CENTER
        }

        val cellRightPaint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 8.5f
            textAlign = Paint.Align.RIGHT
        }

        val itemsPerPage = 20
        val totalPages = if (data.candidates.isEmpty()) 1 else ((data.candidates.size - 1) / itemsPerPage) + 1

        for (pageIndex in 0 until totalPages) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageIndex + 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            // 1. ترويسة الصفحة والإطار
            drawPageHeader(canvas, data, pageIndex + 1, totalPages, titlePaint, subtitlePaint, paint)

            // 2. جدول المرشحين والمستلمين
            val startIndex = pageIndex * itemsPerPage
            val endIndex = minOf(startIndex + itemsPerPage, data.candidates.size)
            val subList = if (data.candidates.isNotEmpty()) data.candidates.subList(startIndex, endIndex) else emptyList()

            drawTable(canvas, subList, startIndex, headerCellPaint, cellPaint, cellRightPaint, paint)

            // 3. التذييل والتواقيع الرسمية في الصفحة الأخيرة
            if (pageIndex == totalPages - 1) {
                drawPageFooter(canvas, data, paint, subtitlePaint)
            } else {
                drawPaginationOnly(canvas, pageIndex + 1, totalPages, subtitlePaint)
            }

            pdfDocument.finishPage(page)
        }

        // حفظ الملف في مجلد المستندات الخاص بالتطبيق
        val reportsDir = File(context.getExternalFilesDir(null), "pdf_reports").apply { mkdirs() }
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "Aid_Distribution_Report_$timeStamp.pdf"
        val outputFile = File(reportsDir, fileName)

        FileOutputStream(outputFile).use { fos ->
            pdfDocument.writeTo(fos)
        }
        pdfDocument.close()

        return outputFile
    }

    private fun drawPageHeader(
        canvas: Canvas,
        data: DistributionPdfReportData,
        currentPage: Int,
        totalPages: Int,
        titlePaint: Paint,
        subtitlePaint: Paint,
        linePaint: Paint
    ) {
        // شريط علوي ملون
        val topBarPaint = Paint().apply { color = Color.rgb(13, 148, 136) }
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 12f, topBarPaint)

        // العنوان الرئيسي
        canvas.drawText(data.reportTitle, pageWidth - 30f, 40f, titlePaint)
        canvas.drawText("نظام إدارة المساعدات الإنسانية الميداني", pageWidth - 30f, 54f, subtitlePaint)

        // بيانات المشروع والتاريخ (صندوق معلومات)
        val infoBgPaint = Paint().apply { color = Color.rgb(241, 245, 249) }
        canvas.drawRoundRect(30f, 65f, pageWidth - 30f, 115f, 8f, 8f, infoBgPaint)

        val metaPaint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 8.5f
            textAlign = Paint.Align.RIGHT
        }

        canvas.drawText("المشروع: ${data.projectName}", pageWidth - 45f, 82f, metaPaint)
        canvas.drawText("نوع المساعدة: ${data.aidTypeName}", pageWidth - 45f, 96f, metaPaint)
        canvas.drawText("المحلية: ${data.localityName}", pageWidth - 45f, 110f, metaPaint)

        canvas.drawText("تاريخ الكشف: ${data.date}", 260f, 82f, metaPaint)
        canvas.drawText("مشرف التوزيع: ${data.supervisorName}", 260f, 96f, metaPaint)
        canvas.drawText("إجمالي المرشحين: ${data.candidates.size} أسرة", 260f, 110f, metaPaint)

        // خط فاصل
        linePaint.apply {
            color = Color.LTGRAY
            strokeWidth = 1f
        }
        canvas.drawLine(30f, 125f, pageWidth - 30f, 125f, linePaint)
    }

    private fun drawTable(
        canvas: Canvas,
        items: List<NominationCandidate>,
        startIndex: Int,
        headerCellPaint: Paint,
        cellPaint: Paint,
        cellRightPaint: Paint,
        linePaint: Paint
    ) {
        val startY = 135f
        val rowHeight = 24f
        val tableLeft = 30f
        val tableRight = pageWidth - 30f

        // أعمدة الجدول (الاتجاه من اليمين إلى اليسار):
        // 1. التوقيع/البصمة (80)
        // 2. نوع الترشيح (50)
        // 3. عدد الأفراد (50)
        // 4. رقم الهوية الوطنية (80)
        // 5. اسم رب الأسرة (240)
        // 6. الرقم (#) (35)
        val colWNumber = 30f
        val colWName = 200f
        val colWId = 85f
        val colWMembers = 50f
        val colWType = 55f
        val colWSign = 115f

        // خلفية ترويسة الجدول
        val headerBgPaint = Paint().apply { color = Color.rgb(30, 41, 59) }
        canvas.drawRect(tableLeft, startY, tableRight, startY + rowHeight, headerBgPaint)

        var currentX = tableRight
        // الرقم
        canvas.drawText("م", currentX - (colWNumber / 2), startY + 16f, headerCellPaint)
        currentX -= colWNumber

        // الاسم
        canvas.drawText("اسم رب الأسرة", currentX - (colWName / 2), startY + 16f, headerCellPaint)
        currentX -= colWName

        // الهوية
        canvas.drawText("رقم الهوية", currentX - (colWId / 2), startY + 16f, headerCellPaint)
        currentX -= colWId

        // الأفراد
        canvas.drawText("الأفراد", currentX - (colWMembers / 2), startY + 16f, headerCellPaint)
        currentX -= colWMembers

        // نوع الترشيح
        canvas.drawText("الترشيح", currentX - (colWType / 2), startY + 16f, headerCellPaint)
        currentX -= colWType

        // التوقيع
        canvas.drawText("توقيع / بصمة المستلم", currentX - (colWSign / 2), startY + 16f, headerCellPaint)

        // رسم الصفوف
        var currentY = startY + rowHeight
        val altBgPaint = Paint().apply { color = Color.rgb(248, 250, 252) }

        items.forEachIndexed { i, candidate ->
            val indexNum = startIndex + i + 1

            // تظليل متبادل للصفوف
            if (i % 2 == 1) {
                canvas.drawRect(tableLeft, currentY, tableRight, currentY + rowHeight, altBgPaint)
            }

            // حدود الصف
            linePaint.apply {
                color = Color.rgb(226, 232, 240)
                strokeWidth = 0.8f
            }
            canvas.drawLine(tableLeft, currentY + rowHeight, tableRight, currentY + rowHeight, linePaint)

            var cellX = tableRight

            // رقم
            canvas.drawText("$indexNum", cellX - (colWNumber / 2), currentY + 15f, cellPaint)
            cellX -= colWNumber

            // الاسم
            canvas.drawText(candidate.family.name, cellX - 8f, currentY + 15f, cellRightPaint)
            cellX -= colWName

            // الهوية
            canvas.drawText(candidate.family.nationalID, cellX - (colWId / 2), currentY + 15f, cellPaint)
            cellX -= colWId

            // الأفراد
            canvas.drawText("${candidate.family.familyMembersCount}", cellX - (colWMembers / 2), currentY + 15f, cellPaint)
            cellX -= colWMembers

            // نوع الترشيح
            canvas.drawText(candidate.selectionType, cellX - (colWType / 2), currentY + 15f, cellPaint)
            cellX -= colWType

            // خط التوقيع
            val signLinePaint = Paint().apply {
                color = Color.rgb(203, 213, 225)
                strokeWidth = 0.5f
            }
            canvas.drawLine(cellX + 10f, currentY + 18f, cellX + colWSign - 10f, currentY + 18f, signLinePaint)

            currentY += rowHeight
        }

        // إطار خارجي للجدول
        linePaint.apply {
            color = Color.rgb(203, 213, 225)
            strokeWidth = 1f
            style = Paint.Style.STROKE
        }
        canvas.drawRect(tableLeft, startY, tableRight, currentY, linePaint)
        linePaint.style = Paint.Style.FILL
    }

    private fun drawPageFooter(
        canvas: Canvas,
        data: DistributionPdfReportData,
        paint: Paint,
        subtitlePaint: Paint
    ) {
        val footerY = pageHeight - 110f

        // بطاقة ملخص الإحصائيات
        val summaryBg = Paint().apply { color = Color.rgb(240, 253, 250) }
        canvas.drawRoundRect(30f, footerY - 45f, pageWidth - 30f, footerY - 10f, 6f, 6f, summaryBg)

        val summaryTextPaint = Paint().apply {
            isAntiAlias = true
            color = Color.rgb(15, 118, 110)
            textSize = 9f
            isFakeBoldText = true
            textAlign = Paint.Align.RIGHT
        }
        val totalMembers = data.candidates.sumOf { it.family.familyMembersCount }
        canvas.drawText(
            "إجمالي الأسر: ${data.candidates.size}  •  إجمالي المستفيدين: $totalMembers فرداً  •  حالة الإيواء: إيواء داخلي معتمد",
            pageWidth - 45f,
            footerY - 24f,
            summaryTextPaint
        )

        // قسم التواقيع والاعتمادات الرسمية
        val signTitlePaint = Paint().apply {
            isAntiAlias = true
            color = Color.BLACK
            textSize = 9.5f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }

        val signSubPaint = Paint().apply {
            isAntiAlias = true
            color = Color.GRAY
            textSize = 8f
            textAlign = Paint.Align.CENTER
        }

        // توقيع الباحث الميداني
        canvas.drawText("الباحث الميداني", 100f, footerY + 10f, signTitlePaint)
        canvas.drawText("التوقيع: .....................", 100f, footerY + 35f, signSubPaint)

        // توقيع أمين المستودع
        canvas.drawText("أمين المستودع", 297f, footerY + 10f, signTitlePaint)
        canvas.drawText("التوقيع: .....................", 297f, footerY + 35f, signSubPaint)

        // اعتماد مشرف المحلية وختم الإدارة
        canvas.drawText("اعتماد مشرف المحلية", 495f, footerY + 10f, signTitlePaint)
        canvas.drawText("الختم والتوقيع: .....................", 495f, footerY + 35f, signSubPaint)

        // سطر الحقوق
        val copyPaint = Paint().apply {
            isAntiAlias = true
            color = Color.LTGRAY
            textSize = 7.5f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("تم استخراج هذا التقرير آلياً عبر نظام إدارة المساعدات الإنسانية • صادر عن المنظومة الميدانية", 297f, pageHeight - 20f, copyPaint)
    }

    private fun drawPaginationOnly(
        canvas: Canvas,
        currentPage: Int,
        totalPages: Int,
        subtitlePaint: Paint
    ) {
        val pPaint = Paint().apply {
            isAntiAlias = true
            color = Color.GRAY
            textSize = 8f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("صفحة $currentPage من $totalPages", pageWidth / 2f, pageHeight - 25f, pPaint)
    }

    /**
     * إرسال ومشاركة ملف الـ PDF عبر تطبيقات التواصل (واتساب، بريد إلكتروني، تليجرام)
     */
    fun sharePdfReport(pdfFile: File) {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "كشف توزيع مساعدات إنسانية - ${pdfFile.name}")
            putExtra(Intent.EXTRA_TEXT, "مرفق كشف توزيع المساعدات الإنسانية الميداني المعتمد بصيغة PDF.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val chooser = Intent.createChooser(intent, "مشاركة تقرير المساعدات (PDF)")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }

    /**
     * طباعة مستند الـ PDF مباشرة باستخدام PrintManager الرسمي في نظام أندرويد
     */
    fun printPdfReport(pdfFile: File, jobName: String = "Aid_Report_Print") {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager ?: return

        val printAdapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: LayoutResultCallback?,
                extras: android.os.Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = android.print.PrintDocumentInfo.Builder(jobName)
                    .setContentType(android.print.PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out android.print.PageRange>?,
                destination: android.os.ParcelFileDescriptor?,
                cancellationSignal: android.os.CancellationSignal?,
                callback: WriteResultCallback?
            ) {
                try {
                    val input = java.io.FileInputStream(pdfFile)
                    val output = java.io.FileOutputStream(destination?.fileDescriptor)

                    val buf = ByteArray(1024)
                    var bytesRead: Int
                    while (input.read(buf).also { bytesRead = it } > 0) {
                        output.write(buf, 0, bytesRead)
                    }

                    callback?.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
                    input.close()
                    output.close()
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                }
            }
        }

        printManager.print(jobName, printAdapter, PrintAttributes.Builder().build())
    }
}
