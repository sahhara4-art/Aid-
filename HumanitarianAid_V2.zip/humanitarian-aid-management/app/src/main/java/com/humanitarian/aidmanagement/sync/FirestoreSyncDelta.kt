package com.humanitarian.aidmanagement.sync

/**
 * FirestoreSyncDelta - نموذج حركة التزامن السحابي عبر Google Firebase Firestore
 * يمثل كل تغيير أو حدث يتم تنفيذه في النظام مع دعم الأولوية القصوى للمدير وحل النزاعات.
 */
data class FirestoreSyncDelta(
    val deltaId: String = java.util.UUID.randomUUID().toString(),
    val localityId: Int = 0,
    val localityName: String = "",
    val userId: Int = 1,
    val userName: String = "",
    val userRole: String = "LOCALITY_SUPERVISOR", // "SUPER_ADMIN" أو "LOCALITY_SUPERVISOR"
    val entityType: String = "AID_RECORD",        // "AID_RECORD", "FAMILY", "PROJECT", "NOMINATION", "CHILD"
    val operation: String = "DELIVER",             // "INSERT", "UPDATE", "DELETE", "DELIVER", "APPROVE_NOMINATION"
    val recordId: String = "",
    val payloadJson: String = "{}",
    val clientTimestamp: Long = System.currentTimeMillis(),
    val serverTimestamp: Long? = null,
    val deviceId: String = "",
    val isMasterAdminOverride: Boolean = (userRole == "SUPER_ADMIN")
) {
    // خريطة بيانات للإرسال إلى Cloud Firestore
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "deltaId" to deltaId,
            "localityId" to localityId,
            "localityName" to localityName,
            "userId" to userId,
            "userName" to userName,
            "userRole" to userRole,
            "entityType" to entityType,
            "operation" to operation,
            "recordId" to recordId,
            "payloadJson" to payloadJson,
            "clientTimestamp" to clientTimestamp,
            "serverTimestamp" to com.google.firebase.firestore.FieldValue.serverTimestamp(),
            "deviceId" to deviceId,
            "isMasterAdminOverride" to isMasterAdminOverride
        )
    }

    companion object {
        fun fromFirestoreMap(map: Map<String, Any?>): FirestoreSyncDelta {
            val sTimestamp = when (val st = map["serverTimestamp"]) {
                is com.google.firebase.Timestamp -> st.toDate().time
                is Long -> st
                is Number -> st.toLong()
                else -> null
            }

            return FirestoreSyncDelta(
                deltaId = (map["deltaId"] as? String) ?: java.util.UUID.randomUUID().toString(),
                localityId = ((map["localityId"] as? Number)?.toInt()) ?: 0,
                localityName = (map["localityName"] as? String) ?: "",
                userId = ((map["userId"] as? Number)?.toInt()) ?: 1,
                userName = (map["userName"] as? String) ?: "",
                userRole = (map["userRole"] as? String) ?: "LOCALITY_SUPERVISOR",
                entityType = (map["entityType"] as? String) ?: "AID_RECORD",
                operation = (map["operation"] as? String) ?: "DELIVER",
                recordId = (map["recordId"] as? String) ?: "",
                payloadJson = (map["payloadJson"] as? String) ?: "{}",
                clientTimestamp = ((map["clientTimestamp"] as? Number)?.toLong()) ?: System.currentTimeMillis(),
                serverTimestamp = sTimestamp,
                deviceId = (map["deviceId"] as? String) ?: "",
                isMasterAdminOverride = (map["isMasterAdminOverride"] as? Boolean) ?: false
            )
        }
    }
}
