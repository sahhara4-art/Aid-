# دليل معمارية التزامن اللحظي (Modern Delta Sync Architecture)
## Humanitarian Aid Management System - Firebase Realtime Engine

يوثق هذا الدليل المعمارية المتطورة المعتمدة على **Offline-First** و **Event Sourcing** باستخدام **Firebase Realtime Database** كوسيط ذكي (Middleman) بين هواتف المناديب الميدانيين وجهاز الإدارة المركزية، دون الحاجة لتبادل ملفات إكسل يومية أو استبدال قواعد البيانات.

---

### 1. الفلسفة المعمارية (Modern Delta Sync)

```
[هاتف المندوب - Offline First]
   │
   ├─► تنفيذ حركة تسليم (Aid Delivery) أو إضافة أسرة
   │
   ├─► حفظ فوري في SQLite/Room DB (المحلية)
   │
   └─► إدراج الحركة كحدث جزئي (Delta) في جدول sync_queue بحالة PENDING
          │
          ▼ [فور توفر الإنترنت - WorkManager / SyncWorker]
   ┌────────────────────────────────────────────────────────┐
   │ رفع الـ Delta (Payload JSON) إلى المسار المخصص:        │
   │ humanitarian_aid_sync/deltas/locality_{id}/{deltaId}   │
   │ تحديث حالة السجل محلياً إلى SYNCED                     │
   └────────────────────────────────────────────────────────┘
          │
          ▼ [Firebase Realtime Database - Middleman]
   ┌────────────────────────────────────────────────────────┐
   │ عقد سحابية معزولة جغرافياً لكل محلية                   │
   │ deltas/locality_1/{deltaId}                            │
   │ deltas/locality_2/{deltaId}                            │
   └────────────────────────────────────────────────────────┘
          │
          ▼ [تطبيق المدير - Master Auto-Merge Listener]
   ┌────────────────────────────────────────────────────────┐
   │ FirebaseSyncListener يستمع لحظياً للأحداث القادمة      │
   │ يقوم بفك الـ JSON وتنفيذ INSERT أو UPDATE مباشر         │
   │ في Room DB دون مسح أو استبدال أي بيانات سابقة           │
   │ تسجيل تدقيق أمني في tbl_Audit_Logs لكل حركة            │
   └────────────────────────────────────────────────────────┘
```

---

### 2. نموذج حركة الـ Delta (`SyncDelta`)

تتكون كل حركة مرسلة من الحقول القياسية التالية:
- `deltaId`: معرف فريد عالمي للحركة (UUID) لمنع التكرار (Idempotency).
- `localityId`: المعرف الرقمي للمحلية التابع لها المندوب (`AllowedLocalityID`).
- `localityName`: الاسم المعتمد للمحلية.
- `userId`: معرف المندوب الذي نفذ الحركة.
- `userName`: الاسم الرباعي للمندوب.
- `entityType`: الكيان الهدف (`AID_RECORD`, `FAMILY`, `NOMINATION`).
- `operation`: العملية التشغيلية (`DELIVER`, `UNDO_DELIVERY`, `INSERT`, `UPDATE`, `DELETE`).
- `recordId`: المعرف المحلي للسجل الهدف في جدول Room.
- `payloadJson`: تفاصيل الحركة بصيغة JSON (مثل اسم المستلم الفعلي، التاريخ، الملاحظات).
- `timestamp`: الطابع الزمني بالمللي ثانية.
- `deviceId`: معرف فريد لجهاز المندوب لمنع ارتداد الحركات لنفس الجهاز (Echo Prevention).

---

### 3. قواعد أمان Firebase Realtime Database المقترحة (`database.rules.json`)

لضمان العزل الجغرافي وحماية البيانات في Firebase Console:

```json
{
  "rules": {
    "humanitarian_aid_sync": {
      "deltas": {
        "$locality_id": {
          ".read": "auth != null",
          ".write": "auth != null",
          "$delta_id": {
            ".validate": "newData.hasChildren(['deltaId', 'localityId', 'operation', 'payloadJson'])"
          }
        }
      },
      "mandoob_heartbeats": {
        "$locality_id": {
          ".read": "auth != null",
          ".write": "auth != null"
        }
      }
    }
  }
}
```

---

### 4. كيفية ربط مشروع Firebase الخاص بك بالتطبيق

1. توجه إلى **[Firebase Console](https://console.firebase.google.com/)**.
2. أنشئ مشروعاً جديداً باسم `Humanitarian Aid Management`.
3. اضغط **Add App** واختر **Android**:
   - **Package name**: `com.humanitarian.aidmanagement`
4. قم بتحميل ملف **`google-services.json`** وضعه في المسار:
   `android/app/google-services.json`
5. من القائمة الجانبية في Firebase Console، اذهب إلى **Build** > **Realtime Database** واضغط **Create Database**.
6. اختر الموقع المناسب (مثال: `europe-west1` أو `us-central1`).
7. في تبويب **Rules**، الصق القواعد المذكورة أعلاه.
8. (اختياري) يمكنك تحديد رابط قاعدة البيانات المباشر عبر شاشة:
   **النسخ الاحتياطي والتزامن** > **تزامن لحظي (Firebase)** > **بنية النظام والتهيئة**.

---

### 5. آلية معالجة التعارض والدمج غير المتلف (Conflict Resolution)

1. **إضافة الأحداث بدلاً من استبدال الملفات (Event Sourcing)**:
   - لا يتم إرسال ملف قاعدة بيانات كامل مطلقا؛ فقط حدث التسليم الفعلي يُرسل.
2. **منع التكرار (Deduplication Cache)**:
   - يحتفظ `FirebaseSyncListener` بذاكرة للمعرفات `mergedDeltaIds`. إذا وصلت نفس الحركة أكثر من مرة، يتم تجاهلها فوراً دون تكرار العمليات.
3. **التحديث المستهدف (Targeted Atomic Updates)**:
   - عند دمج حركة `DELIVER`، يتم تحديث حالة السجل المعني فقط في `AidRecordDao`:
     ```kotlin
     aidRecordDao.updateDeliveryStatus(recordId, status, date, combinedNotes)
     ```
     دون التأثير على أي مشاريع أو أسر أخرى.
4. **التدقيق الأمني المركزي (Audit Trail)**:
   - كل حركة تُدمج تلقائياً تسجل في جدول `tbl_Audit_Logs` مع اسم المندوب ومحليته ووقت الدمج.
