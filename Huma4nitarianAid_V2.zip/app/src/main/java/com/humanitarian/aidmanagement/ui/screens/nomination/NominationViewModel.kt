package com.humanitarian.aidmanagement.ui.screens.nomination

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.humanitarian.aidmanagement.data.local.entities.AidRecordEntity
import com.humanitarian.aidmanagement.data.local.entities.AidTypeEntity
import com.humanitarian.aidmanagement.data.local.entities.FamilyEntity
import com.humanitarian.aidmanagement.data.local.entities.LocalityEntity
import com.humanitarian.aidmanagement.data.local.entities.ProjectEntity
import com.humanitarian.aidmanagement.data.local.entities.donor
import com.humanitarian.aidmanagement.data.local.entities.isOpen
import com.humanitarian.aidmanagement.data.local.entities.residencyStatus
import com.humanitarian.aidmanagement.data.local.entities.socialAffairsStatus
import com.humanitarian.aidmanagement.data.local.entities.targetQuota
import com.humanitarian.aidmanagement.data.repository.AidRepository
import com.humanitarian.aidmanagement.engine.CandidateStatus
import com.humanitarian.aidmanagement.engine.DynamicCandidateModel
import com.humanitarian.aidmanagement.engine.DynamicNominationCriteria
import com.humanitarian.aidmanagement.engine.DynamicNominationResult
import com.humanitarian.aidmanagement.engine.ExclusionMode
import com.humanitarian.aidmanagement.engine.LocalityQuota
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * حالة شريحة الفلترة متعددة الحالات (Multi-State FilterChip)
 * 3 حالات: غير محدد، متضمن (أخضر)، مستثنى (أحمر)
 */
enum class ChipFilterState {
    UNSELECTED,
    INCLUDED, // تضمين (Checkmark)
    EXCLUDED  // استثناء (Cross)
}

/**
 * إحصائية حصة المحلية المعتمدة والترشيح الفعلي والعجز/الفائض
 */
data class LocalityQuotaStatsItem(
    val localityName: String,
    val baseX: Int,
    val totalBase: Int,
    val percentage: Double,
    val targetQuota: Int,
    val nominatedCount: Int
) {
    val shortageExcess: Int get() = nominatedCount - targetQuota
    val isComplete: Boolean get() = nominatedCount >= targetQuota && targetQuota > 0
    val formattedPercentage: String get() = String.format(Locale.US, "%.1f%%", percentage)
}

/**
 * MASTER ARCHITECTURE V3.0: THE ULTIMATE HYBRID NOMINATION VIEWMODEL
 * يدمج إدارة الوصول الجغرافي (RBAC)، الحسابات الرياضية للتوزيع النسبي،
 * وفلاتر الشرائح ثلاثية الحالات والاختيار الهجين المحمي بالأقفال.
 */
class NominationViewModel(
    val repository: AidRepository,
    initialAssignedSubRegion: String = "All"
) : ViewModel() {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    // ==========================================
    // MODULE 2: GEOGRAPHICAL RBAC (المنطقة المخصصة)
    // ==========================================
    val assignedSubRegion = MutableStateFlow(initialAssignedSubRegion)

    fun setAssignedSubRegion(region: String) {
        assignedSubRegion.value = region.ifBlank { "All" }
    }

    // ==========================================
    // تدفقات قاعدة البيانات والمشاريع
    // ==========================================
    val allActiveProjects: StateFlow<List<ProjectEntity>> = repository.getActiveProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Step 1: المشاريع المفتوحة حصراً للترشيح (isOpen == true)
    val openProjects: StateFlow<List<ProjectEntity>> = repository.getActiveProjects()
        .map { list -> list.filter { it.isOpen } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeAidTypes: StateFlow<List<AidTypeEntity>> = repository.getActiveAidTypes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dbLocalities: StateFlow<List<LocalityEntity>> = repository.getLocalities()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // المشروع المختار حالياً
    val selectedProject = MutableStateFlow<ProjectEntity?>(null)

    // وضع القراءة فقط (إذا تم فتح مشروع مقفل isOpen == false)
    val isReadOnlyMode: StateFlow<Boolean> = selectedProject.map { project ->
        project != null && !project.isOpen
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    // ==========================================
    // تدفق الأسر المصفى جغرافياً من المصدر (RBAC Pre-Filtered Master Stream)
    // ==========================================
    private val rawFamiliesFlow: Flow<List<FamilyEntity>> = flow {
        emit(repository.getAllFamiliesSync())
    }

    val rbacFamiliesStream: StateFlow<List<FamilyEntity>> = combine(
        rawFamiliesFlow,
        assignedSubRegion
    ) { families, region ->
        val effectiveRegion = region.trim()
        val isRestricted = effectiveRegion.isNotBlank() &&
                !effectiveRegion.equals("All", ignoreCase = true) &&
                effectiveRegion != "الكل" &&
                effectiveRegion != "*"
        if (isRestricted) {
            families.filter { it.currentSubArea.trim() == effectiveRegion }
        } else {
            families
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ==========================================
    // MODULE 3: PROPORTIONAL DISTRIBUTION MATH (التوزيع النسبي)
    // القاعدة الرياضية الصارمة: (socialAffairsStatus == "معتمد" AND residencyStatus == "مقيم")
    // ==========================================
    val localityQuotasMap: StateFlow<Map<String, Int>> = combine(
        rbacFamiliesStream,
        selectedProject
    ) { families, project ->
        if (project == null || project.targetQuota <= 0) {
            emptyMap()
        } else {
            // تصفية أسر القاعدة الأساسية المؤهلة للحساب النسبي
            val baseFamilies = families.filter { fam ->
                fam.socialAffairsStatus.trim() == "معتمد" && fam.residencyStatus.trim() == "مقيم"
            }
            val totalBase = baseFamilies.size
            if (totalBase == 0) {
                emptyMap()
            } else {
                val groups = baseFamilies.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }
                groups.mapValues { (_, list) ->
                    val baseX = list.size
                    Math.round((baseX.toDouble() / totalBase.toDouble()) * project.targetQuota).toInt()
                }
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // ==========================================
    // MODULE 4: THE SUPER DYNAMIC FILTER ENGINE
    // خيارات الفلاتر المستخرجة ديناميكياً من FamilyEntity (مع تحويل Null/فارغ إلى "غير مصنف")
    // ==========================================
    val dynamicShelterOptions: StateFlow<List<String>> = rbacFamiliesStream.map { families ->
        families.map { it.shelterStatus.ifBlank { "غير مصنف" } }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dynamicInjuryOptions: StateFlow<List<String>> = rbacFamiliesStream.map { families ->
        families.map { it.injuryStatus.ifBlank { "غير مصنف" } }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dynamicDamageOptions: StateFlow<List<String>> = rbacFamiliesStream.map { families ->
        families.map { it.damageType.ifBlank { "غير مصنف" } }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dynamicIncomeOptions: StateFlow<List<String>> = rbacFamiliesStream.map { families ->
        families.map { it.incomeSource1.ifBlank { "غير مصنف" } }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dynamicSubAreaOptions: StateFlow<List<String>> = rbacFamiliesStream.map { families ->
        families.map { it.currentSubArea.ifBlank { "غير مصنف" } }.distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // حالات الشرائح متعددة الحالات (Multi-State Filter Chips)
    val shelterChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val injuryChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val damageChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val incomeChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())
    val localityChipStates = MutableStateFlow<Map<String, ChipFilterState>>(emptyMap())

    // فلاتر الاستثناء الزمني وحجم الأسرة
    val exclusionMode = MutableStateFlow(ExclusionMode.DAYS)
    val exclusionDaysText = MutableStateFlow("30")
    val exclusionDateCutoffText = MutableStateFlow("")
    val hasChildrenOnly = MutableStateFlow(false)
    val minFamilyMembers = MutableStateFlow(1)
    val searchQuery = MutableStateFlow("")

    // تبديل حالة الشريحة: غير محدد -> متضمن (أخضر) -> مستثنى (أحمر) -> غير محدد
    fun cycleChipState(category: String, key: String) {
        val targetFlow = when (category) {
            "shelter" -> shelterChipStates
            "injury" -> injuryChipStates
            "damage" -> damageChipStates
            "income" -> incomeChipStates
            "locality" -> localityChipStates
            else -> return
        }
        val current = targetFlow.value.toMutableMap()
        val nextState = when (current[key] ?: ChipFilterState.UNSELECTED) {
            ChipFilterState.UNSELECTED -> ChipFilterState.INCLUDED
            ChipFilterState.INCLUDED -> ChipFilterState.EXCLUDED
            ChipFilterState.EXCLUDED -> ChipFilterState.UNSELECTED
        }
        if (nextState == ChipFilterState.UNSELECTED) {
            current.remove(key)
        } else {
            current[key] = nextState
        }
        targetFlow.value = current
    }

    fun clearAllFilterChips() {
        shelterChipStates.value = emptyMap()
        injuryChipStates.value = emptyMap()
        damageChipStates.value = emptyMap()
        incomeChipStates.value = emptyMap()
        localityChipStates.value = emptyMap()
        exclusionMode.value = ExclusionMode.DAYS
        exclusionDaysText.value = "30"
        exclusionDateCutoffText.value = ""
        hasChildrenOnly.value = false
        minFamilyMembers.value = 1
        searchQuery.value = ""
    }

    // ==========================================
    // MODULE 5: SMART HYBRID SELECTION & DASHBOARD (The Core)
    // ==========================================
    // الأسر المختارة للترشيح الفعلي (Selected Nominees)
    val selectedNominees = MutableStateFlow<Set<FamilyEntity>>(emptySet())

    // تدفق الأسر المطابقة للشروط الصارمة (Filtered Families) مرتبة تنازلياً حسب حجم الأسرة
    val filteredFamilies: StateFlow<List<FamilyEntity>> = combine(
        rbacFamiliesStream,
        selectedProject,
        shelterChipStates,
        injuryChipStates,
        damageChipStates,
        incomeChipStates,
        localityChipStates
    ) { args ->
        @Suppress("UNCHECKED_CAST")
        val families = args[0] as List<FamilyEntity>
        val project = args[1] as ProjectEntity?
        val shelterChips = args[2] as Map<String, ChipFilterState>
        val injuryChips = args[3] as Map<String, ChipFilterState>
        val damageChips = args[4] as Map<String, ChipFilterState>
        val incomeChips = args[5] as Map<String, ChipFilterState>
        val localityChips = args[6] as Map<String, ChipFilterState>

        executeCascadingFilter(
            families = families,
            project = project,
            shelterChips = shelterChips,
            injuryChips = injuryChips,
            damageChips = damageChips,
            incomeChips = incomeChips,
            localityChips = localityChips
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // لوحة مراجعة الحصص النسبية مقارنة بالمرشحين الفعليين
    val localityQuotaStats: StateFlow<List<LocalityQuotaStatsItem>> = combine(
        rbacFamiliesStream,
        selectedProject,
        localityQuotasMap,
        selectedNominees
    ) { families, project, quotasMap, nominees ->
        if (project == null) {
            emptyList()
        } else {
            val baseFamilies = families.filter { fam ->
                fam.socialAffairsStatus.trim() == "معتمد" && fam.residencyStatus.trim() == "مقيم"
            }
            val totalBase = baseFamilies.size
            val groups = baseFamilies.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }
            val nomineesByLocality = nominees.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }

            groups.map { (locName, list) ->
                val baseX = list.size
                val quota = quotasMap[locName] ?: 0
                val nominated = nomineesByLocality[locName]?.size ?: 0
                val pct = if (totalBase > 0) (baseX.toDouble() / totalBase.toDouble()) * 100.0 else 0.0
                LocalityQuotaStatsItem(
                    localityName = locName,
                    baseX = baseX,
                    totalBase = totalBase,
                    percentage = pct,
                    targetQuota = quota,
                    nominatedCount = nominated
                )
            }.sortedByDescending { it.targetQuota }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * فلترة السلاسل المجمعة (Cascading Filter Execution)
     */
    private fun executeCascadingFilter(
        families: List<FamilyEntity>,
        project: ProjectEntity?,
        shelterChips: Map<String, ChipFilterState>,
        injuryChips: Map<String, ChipFilterState>,
        damageChips: Map<String, ChipFilterState>,
        incomeChips: Map<String, ChipFilterState>,
        localityChips: Map<String, ChipFilterState>
    ): List<FamilyEntity> {
        return families.asSequence()
            // 1. الشرط الإلزامي الصارم: (معتمد AND مقيم)
            .filter { fam ->
                fam.socialAffairsStatus.trim() == "معتمد" && fam.residencyStatus.trim() == "مقيم"
            }
            // 2. فلتر شرائح الإيواء ثلاثية الحالات
            .filter { fam ->
                val key = fam.shelterStatus.ifBlank { "غير مصنف" }
                evaluateChipFilter(key, shelterChips)
            }
            // 3. فلتر شرائح الإصابات
            .filter { fam ->
                val key = fam.injuryStatus.ifBlank { "غير مصنف" }
                evaluateChipFilter(key, injuryChips)
            }
            // 4. فلتر شرائح الضرر
            .filter { fam ->
                val key = fam.damageType.ifBlank { "غير مصنف" }
                evaluateChipFilter(key, damageChips)
            }
            // 5. فلتر شرائح الدخل
            .filter { fam ->
                val key = fam.incomeSource1.ifBlank { "غير مصنف" }
                evaluateChipFilter(key, incomeChips)
            }
            // 6. فلتر شرائح المحليات/المناطق
            .filter { fam ->
                val key = fam.currentSubArea.ifBlank { "غير مصنف" }
                evaluateChipFilter(key, localityChips)
            }
            // 7. حد أفراد الأسرة
            .filter { fam ->
                fam.familyMembersCount >= minFamilyMembers.value
            }
            // 8. الترتيب الأولوية الإلزامي: الأكبر حجماً أولاً
            .sortedByDescending { it.familyMembersCount }
            .toList()
    }

    private fun evaluateChipFilter(value: String, chips: Map<String, ChipFilterState>): Boolean {
        if (chips.isEmpty()) return true
        val included = chips.filter { it.value == ChipFilterState.INCLUDED }.keys
        val excluded = chips.filter { it.value == ChipFilterState.EXCLUDED }.keys

        // إذا كان هناك عناصر مستثناة وتحتوي على القيمة -> استبعاد فوري
        if (excluded.contains(value)) return false
        // إذا كان هناك عناصر متضمنة -> يجب أن تطابق أحدها
        if (included.isNotEmpty() && !included.contains(value)) return false
        return true
    }

    // ==========================================
    // الترشيح الآلي واليدوي المحمي بالأقفال (Auto-Nominate & Manual Override)
    // ==========================================

    /**
     * الترشيح الآلي: يوزع الحصص بنزاهة تامة ويلتقط أعلى الأسر أولوية حتى سقف حصة كل محلية
     * ولا يتجاوز بأي حال سقف الحصة الكلية للمشروع.
     */
    fun runAutoNomination() {
        val project = selectedProject.value ?: return
        if (!project.isOpen) return // منع التعديل في وضع القراءة فقط

        val maxCapacity = project.targetQuota
        val quotas = localityQuotasMap.value
        val pool = filteredFamilies.value
        val result = mutableSetOf<FamilyEntity>()

        // تجميع الأسر المؤهلة حسب المنطقة
        val poolByLocality = pool.groupBy { it.currentSubArea.ifBlank { "منطقة غير محددة" } }

        // التوزيع الحصري حتى استيفاء حصة كل محلية
        quotas.forEach { (locName, quota) ->
            if (quota > 0 && result.size < maxCapacity) {
                val availableInLoc = poolByLocality[locName] ?: emptyList()
                val needed = (quota).coerceAtMost(maxCapacity - result.size)
                result.addAll(availableInLoc.take(needed))
            }
        }

        // إذا تبقى عجز ولم يكتمل المشروع، ملء الفارق من باقي الأسر المؤهلة
        if (result.size < maxCapacity) {
            val remaining = pool.filter { !result.contains(it) }
            val needed = maxCapacity - result.size
            result.addAll(remaining.take(needed))
        }

        selectedNominees.value = result
    }

    /**
     * الإضافة اليدوية لأسرة مع فرض عدم تجاوز الحصة الكلية
     */
    fun addNomineeManually(family: FamilyEntity): Boolean {
        val project = selectedProject.value ?: return false
        if (!project.isOpen) return false
        if (selectedNominees.value.size >= project.targetQuota) return false

        val current = selectedNominees.value.toMutableSet()
        val added = current.add(family)
        if (added) {
            selectedNominees.value = current
        }
        return added
    }

    /**
     * الاستبعاد اليدوي (Swipe to Dismiss / Remove)
     */
    fun removeNominee(family: FamilyEntity) {
        val project = selectedProject.value ?: return
        if (!project.isOpen) return

        val current = selectedNominees.value.toMutableSet()
        if (current.remove(family)) {
            selectedNominees.value = current
        }
    }

    fun clearNominees() {
        val project = selectedProject.value ?: return
        if (!project.isOpen) return
        selectedNominees.value = emptySet()
    }

    /**
     * اعتماد وترحيل الترشيحات رسمياً إلى قاعدة البيانات
     */
    suspend fun commitNomination(): Result<Int> = withContext(Dispatchers.IO) {
        val project = selectedProject.value
            ?: return@withContext Result.failure(IllegalStateException("لم يتم اختيار أي مشروع"))
        if (!project.isOpen) {
            return@withContext Result.failure(IllegalStateException("المشروع مغلق أو مقفل ولا يمكن اعتماد ترشيحات له"))
        }

        val nominees = selectedNominees.value
        if (nominees.isEmpty()) {
            return@withContext Result.failure(IllegalStateException("قائمة المرشحين فارغة"))
        }

        try {
            val insertedCount = repository.commitNomineesToProject(
                projectId = project.projectID,
                aidTypeId = project.aidTypeID,
                familyIds = nominees.map { it.familyID },
                mechanism = "هجين (آلي/يدوي)"
            )
            Result.success(insertedCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ==========================================
    // حقول ودوال التوافق البرمجي مع الشاشات السابقة
    // ==========================================
    val isFiltering = MutableStateFlow(false)
    val dynamicNominationResult = MutableStateFlow<DynamicNominationResult?>(null)
    val calculatedQuotas = MutableStateFlow<List<LocalityQuota>>(emptyList())
    val filteredEligibleFamilies = MutableStateFlow<List<FamilyEntity>>(emptyList())
    val targetBeneficiariesText = MutableStateFlow("100")
    val resultLimitText = MutableStateFlow("300")
    val selectedLocalities = MutableStateFlow<Set<String>>(emptySet())
    val excludeLocalities = MutableStateFlow(false)
    val selectedAidCategories = MutableStateFlow<Set<String>>(emptySet())
    val excludeAidCategories = MutableStateFlow(true)
    val selectedDamageTypes = MutableStateFlow<Set<String>>(emptySet())
    val excludeDamageTypes = MutableStateFlow(false)
    val selectedShelterStatuses = MutableStateFlow<Set<String>>(emptySet())
    val excludeShelterStatuses = MutableStateFlow(false)
    val selectedWorksApprovals = MutableStateFlow<Set<String>>(emptySet())
    val excludeWorksApprovals = MutableStateFlow(false)
    val selectedMaritalStatuses = MutableStateFlow<Set<String>>(emptySet())
    val excludeMaritalStatuses = MutableStateFlow(false)
    val selectedIncomeSources = MutableStateFlow<Set<String>>(emptySet())
    val excludeIncomeSources = MutableStateFlow(false)
    val selectedInjuryStatuses = MutableStateFlow<Set<String>>(emptySet())
    val excludeInjuryStatuses = MutableStateFlow(false)
    val selectedSubAreas = MutableStateFlow<Set<String>>(emptySet())
    val excludeSubAreas = MutableStateFlow(false)
    val selectedLocalityId = MutableStateFlow(0)
    val excludeLocality = MutableStateFlow(false)
    val selectedProjectId = MutableStateFlow(1L)
    val selectedAidTypeId = MutableStateFlow(1)
    val statusFilterTab = MutableStateFlow<CandidateStatus?>(null)
    val customLocalityQuotas = MutableStateFlow<Map<String, String>>(emptyMap())

    val localities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pureLocalities: StateFlow<List<String>> = repository.getDistinctLocalities()
        .map { it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val pureAidCategories: StateFlow<List<String>> = repository.getDistinctAidCategories()
        .map { it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val damageTypes: StateFlow<List<String>> = repository.getDistinctDamageTypesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val shelterStatuses: StateFlow<List<String>> = repository.getDistinctShelterStatusesFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    val worksApprovals: StateFlow<List<String>> = repository.getDistinctWorksApprovalsFlow()
        .map { listOf("الكل") + it.filter { s -> s.isNotBlank() } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("الكل"))

    fun toggleLocality(name: String) = cycleChipState("locality", name)
    fun toggleCategory(cat: String) {
        val cur = selectedAidCategories.value.toMutableSet()
        if (cur.contains(cat)) cur.remove(cat) else cur.add(cat)
        selectedAidCategories.value = cur
    }
    fun toggleDamageType(type: String) = cycleChipState("damage", type)
    fun toggleShelterStatus(status: String) = cycleChipState("shelter", status)
    fun toggleWorksApproval(approval: String) {
        val cur = selectedWorksApprovals.value.toMutableSet()
        if (cur.contains(approval)) cur.remove(approval) else cur.add(approval)
        selectedWorksApprovals.value = cur
    }
    fun resetFilters() = clearAllFilterChips()
    fun runFilteringEngine() {
        // legacy placeholder - cascade flow handles this reactively
    }

    init {
        viewModelScope.launch {
            // اختيار المشروع المفتوح الأول تلقائياً
            openProjects.collect { list ->
                if (selectedProject.value == null && list.isNotEmpty()) {
                    selectedProject.value = list.first()
                }
            }
        }
    }

    class Factory(
        private val repository: AidRepository,
        private val initialAssignedSubRegion: String = "All"
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return NominationViewModel(repository, initialAssignedSubRegion) as T
        }
    }
}
